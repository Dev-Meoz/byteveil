# ByteVeil v5.9 — Backend handoff cho Qoder AI và Arena AI

## Bối cảnh

Frontend patch có sẵn trong source tree. Giữ nguyên public API hiện tại; `parse()` vẫn trả AST, còn `parseDetailed()` là API bổ sung. Không revert thay đổi lexer/parser và phải chạy `npm run test:v590:frontend` sau khi tích hợp.

## Yêu cầu cho Qoder AI

Làm phần backend v5.9. Không chỉ bump version, rename identifier hoặc thêm stub. Kiểm tra source trước khi sửa, giữ API/path kiến trúc hiện có nếu không có lý do kỹ thuật cụ thể.

### Các điểm cần xử lý

1. Payload carrier phải có chức năng thật và được nối vào đường thực thi; đo output thực tế, không chỉ dùng số liệu benchmark hardcode.
2. Mỗi topology dispatch phải được mô tả bằng nhiệm vụ chức năng; kiểm tra cùng input qua nhiều seed phải giữ semantics.
3. Test harness phải xác nhận output gốc chạy thành công rồi mới kiểm tra carrier mutation/tamper rejection.
4. Differential tests phải so sánh cả số lượng return, trailing `nil`, vararg, closure/upvalue, side effect, global state, error behavior và chỉ chạy fixture theo số lần đã khai báo.
5. Chạy full release suite đến khi kết thúc tự nhiên; nếu timeout, tìm nguyên nhân và trả output/log đầy đủ.
6. Không tuyên bố chống reverse engineering đã tăng chỉ dựa vào entropy, kích thước output hoặc slot ratio. Cần phân biệt metrics cấu trúc với bằng chứng thực thi/khả năng phân tích.

## Yêu cầu cho Arena AI

Sau khi nhận implementation từ Qoder, làm review/debug độc lập:

- Tìm regression hoặc test pass giả; xác minh các test baseline và mutation test có assertion đúng.
- Chạy frontend regression và các backend suites liên quan.
- Sửa lỗi tìm được, ghi diff/source đã sửa và lý do.
- Trả lại toàn bộ source project, test logs, danh sách các file changed và các limitation còn lại.
- Không tuyên bố release PASS nếu `npm test` chưa trả exit code 0 trong một lượt hoàn chỉnh.

## Kết quả cần gửi lại để review cuối

- Source ZIP đầy đủ, không chỉ patch rời.
- `CHANGES-V5.9.0.md` và `LIMITATIONS-V5.9.0.md`.
- Lệnh chạy/test đã dùng cùng exit code.
- Danh sách suite PASS/FAIL/TIMEOUT.
- Bằng chứng đầu ra gốc chạy trước test tamper và kết quả semantics trước/sau obfuscate.

# ByteVeil single-layer benchmark comparison

Three independent process runs per version; values are medians.

**Fixture:** `examples/input.lua` (85 bytes) · **Preset:** `lz` · **Mode:** stack · **Target:** Lua 5.4 · **Seed:** `1194000385` · **Strength:** `10000` · wrapper/watermark disabled.

| Metric | v4.7.2 — 9 nested layers | v4.7.3 — 1 VM layer | Reduction |
|---|---:|---:|---:|
| Output bytes | 460,053 | 46,529 | 89.89% |
| Generation wall time (ms) | 1,764.28 | 326.21 | 81.51% |
| Generation CPU time (ms) | 2,501.61 | 382.04 | 84.73% |
| Node peak RSS (bytes) | 229,150,720 | 43,581,440 | 80.98% |
| Lua runtime wall time (ms) | 3,120 | 720 | 76.92% |
| Lua runtime CPU time (ms) | 3,100 | 700 | 77.42% |
| Lua runtime peak RSS (bytes) | 21,270,528 | 1,441,792 | 93.22% |

Both versions returned `5` in all three measured runs.

## Interpretation

On this fixture, removing nested source wrappers materially reduced output size, generator cost, and Lua runtime memory. This is a resource/performance result, **not** proof that ByteVeil is as difficult to reverse-engineer as Luraph v15.1.

## Limits

- Metrics use one 85-byte fixture and the included Lua 5.4 runner; they are not guarantees for every source or machine.
- Wall-time values vary with host load; the table uses medians of three runs on the same current environment.
- Native Roblox Luau has not been benchmarked here. Explicit compatibility/source fallback is not part of this comparison.

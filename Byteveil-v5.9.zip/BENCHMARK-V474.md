# ByteVeil v4.7.4 — Release fixture benchmark

- Fixture: `examples/input.lua` (85 source bytes)
- Target: Lua 5.4 runner, stack mode, `lz`, strength 10000
- Seed: `1196097537` (`0x474B0001`)
- Optional outer wrapper and watermark: disabled for a stable engine-only comparison
- Generated output: **472,159 bytes** (472.16 KB / 461.09 KiB)
- Nested layers: **9**; codec schedule: `5, 0, 3, 2, 5, 4, 5, 1, 8`
- Codec-8 compression: 10,086 bytes saved in one compressed layer
- Generation: 704.56 ms wall / 973.63 ms process CPU; Node peak RSS 224,845,824 bytes
- Runtime: **PASS**, output `5`, 1,600 ms wall / 1,590 ms CPU; peak RSS 25,944,064 bytes

The output is below the 475,000-byte ceiling for this fixed fixture. These figures are a single-run size/runtime benchmark, not a reverse-engineering-resistance score and not proof of parity with Luraph, MoonSec, or other sample families. A separate regression matrix passed all four presets (`l1`, `l2`, `df`, `lz`) on Lua 5.4, with 3/5/7/9 nested layers respectively. The Luau-target output passed a portable Lua syntax check, but a native Luau/Roblox runtime was not executed in this environment.

# ByteVeil v4.7.5 — Regression and crack-test benchmark

## Fixed case

- Source: `examples/input.lua` (85 bytes)
- Preset/mode/target: `lz` / `stack` / `lua`
- Seed: `1196099585` (`0x475B0001` is the separate release-gate seed)
- Strength: 10,000; wrapper: disabled; watermark: disabled
- Protected output: **52,280 bytes** (51.05 KiB)
- Runtime output: `5`
- Lua 5.4 runtime: **PASS**
- Generation: 113.13 ms wall / 139.04 ms CPU
- Runtime: 710 ms wall / 710 ms CPU; peak RSS: 1,572,864 bytes
- Fixture ceiling: 475,000 bytes; **PASS** (422,720 bytes below ceiling)

## Crack-test results

The `npm test` release gate generates output and hooks both Lua `load` and `loadstring` without modifying the generated protection checks. The program runs with the expected result, while the hook records **zero calls**. Static assertions also confirm that this generated output contains no loader calls or loader identifier variables and that metadata reports zero source-loader stages, zero source-loader calls, eight binary-region transforms, and the optional native-buffer path. The suite also creates a behavior-only reproduction of the exact print text in the supplied v4.7.4 log, verifies it executes unchanged, checks that the whole phrase is not present as a plaintext output literal, and confirms both loader hooks remain unused. It does not claim the repro is byte-identical to the original artifact.

This specifically closes the v4.7.4 test's observed route of capturing nine source chunks by intercepting the nested source loaders. It is not a general proof against VM devirtualization, memory inspection or dynamic RE. A determined analyst can still inspect runtime state or decoded binary regions.

## Architecture notes

The active v4.7.5 path serializes graph-VM regions and applies eight sequential reversible byte-transform operations. If the target runtime provides Luau's native `buffer.create`, `buffer.writeu8` and `buffer.readu8`, the generated cache can use those APIs with zero-based offsets; otherwise the byte-array fallback runs. The local automated test covers the fallback and a Lua-side API shim. **Native Roblox Luau execution was not available** in this environment, so the native API branch still needs a real Luau host test.

The v4.7.4 red-team fixture in the user-provided log is 460,508 bytes, while this benchmark uses an 85-byte source fixture. These are not equivalent inputs, so comparing their protected-output sizes as a strength benchmark would be misleading.

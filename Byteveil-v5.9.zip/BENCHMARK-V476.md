# ByteVeil v4.7.6 — Benchmark

## Fixed fixture

- Source: `examples/input.lua`
- Source size: 85 bytes
- Preset: `lz`
- Strength: `10000`
- Seed: `0x476B0001`
- Runtime: bundled Lua 5.4 runner
- Expected output: `5`

| Metric | Stack mode | Register mode |
|---|---:|---:|
| Output size | 50,341 bytes | 50,003 bytes |
| Output size | 50.34 kB / 49.16 KiB | 50.00 kB / 48.83 KiB |
| Generation wall time | 57.12 ms | 59.16 ms |
| Generation CPU time | See JSON report | See JSON report |
| Runtime wall time | 450 ms | 600 ms |
| Runtime output | `5` | `5` |
| Runtime status | PASS | PASS |
| Nested source-loader stages | 0 | 0 |
| Binary region transforms | 8 | 8 |
| Shadow VM instruction rows | 96 | 96 |
| Shadow VM handlers | 34 | 34 |
| Shadow dispatch steps per actual instruction | 3 | 3 |
| Actual opcode trace used | 18 entries | 17 entries |
| Operand trace-derived | Yes | Yes |
| Runtime opcode coupling | Yes | Yes |

The output cap is 475,000 bytes. Both measurements fall below the cap for this exact fixture, preset, seed and mode. This is not a claim that every possible input will produce an output in the same range.

## Measurement notes

The benchmark script records generation wall/CPU time, Node peak RSS, runtime executable, runtime wall/CPU time where `/usr/bin/time` is available, runtime peak RSS, payload and loader metadata, the live-shadow dispatch profile, and the build-specific fingerprint. Treat timings as host-specific observations, not stable performance guarantees.

See `BENCHMARK-V476-STACK.json` and `BENCHMARK-V476-REGISTER.json` for the full raw reports.

## Interpretation

The key v4.7.6 change is not output size: it is the new live-opcode-coupled secondary dispatch plus a build-specific encoded instruction stream whose opcode/operand mix derives from the real program. The release tests show the stream is interleaved with the main VM and the old source-loader peel route is absent. They do **not** prove that the secondary VM is indistinguishable from a semantically equivalent VM or as difficult to reverse engineer as Luraph v15.x.

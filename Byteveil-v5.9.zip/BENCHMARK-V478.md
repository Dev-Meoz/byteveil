# ByteVeil v4.7.8 — Benchmark summary

Generated: 2026-10-14T12:14:43.337Z

- Target: `lua`; runtime status: `available` (/mnt/data/bv478-work/tools/lua54-runner)
- Reported runtime version from `_VERSION`: `Lua 5.4`
- Independent seeded generations per profile: 3
- Profiles: 20
- Maximum output budget: 475,000 bytes
- Observed largest median output: 181,505 bytes
- Observed largest final-build output: 182,078 bytes
- All outputs within budget: **true**
- Syntax pass across profiles: **true**
- Runtime pass across profiles: **true**
- Any direct `load(`/`loadstring(` call-site strings in scanned output: **false**

## Per-profile output/runtime

| Profile | Median bytes | Last-run bytes | Syntax | Runtime | Runtime wall ms (single final-build run) | Loader call-site scan |
|---|---:|---:|---|---|---:|---|
| `l1:balanced-vm-a` | 82,706 | 82,706 | pass | pass | 290 | none |
| `l1:hardened-vm-b` | 82,017 | 81,994 | pass | pass | 340 | none |
| `l1:hybrid-a-main-b-function` | 164,182 | 165,153 | pass | pass | 260 | none |
| `l1:hybrid-b-main-a-function` | 164,274 | 164,221 | pass | pass | 340 | none |
| `l1:compiler-transformed` | 201 | 201 | pass | pass | 0 | none |
| `l2:balanced-vm-a` | 83,349 | 83,349 | pass | pass | 420 | none |
| `l2:hardened-vm-b` | 83,656 | 84,897 | pass | pass | 310 | none |
| `l2:hybrid-a-main-b-function` | 167,399 | 167,399 | pass | pass | 310 | none |
| `l2:hybrid-b-main-a-function` | 167,593 | 167,593 | pass | pass | 410 | none |
| `l2:compiler-transformed` | 205 | 193 | pass | pass | 0 | none |
| `df:balanced-vm-a` | 87,797 | 87,797 | pass | pass | 520 | none |
| `df:hardened-vm-b` | 86,755 | 86,915 | pass | pass | 690 | none |
| `df:hybrid-a-main-b-function` | 173,000 | 173,000 | pass | pass | 630 | none |
| `df:hybrid-b-main-a-function` | 174,270 | 174,348 | pass | pass | 570 | none |
| `df:compiler-transformed` | 219 | 219 | pass | pass | 0 | none |
| `lz:balanced-vm-a` | 91,326 | 91,377 | pass | pass | 790 | none |
| `lz:hardened-vm-b` | 90,709 | 91,569 | pass | pass | 650 | none |
| `lz:hybrid-a-main-b-function` | 181,411 | 182,078 | pass | pass | 740 | none |
| `lz:hybrid-b-main-a-function` | 181,505 | 181,343 | pass | pass | 840 | none |
| `lz:compiler-transformed` | 215 | 219 | pass | pass | 0 | none |

## Interpretation and caveats

This benchmark ran 3 independent seeded generations per profile across four presets (`l1`, `l2`, `df`, `lz`) and five VM/policy paths per preset (20 combinations). Output sizes and generation timings are medians over those builds; syntax and behavior are checked on the final build for each profile, with one measured runtime execution per profile. This is a regression benchmark, not a statistically robust runtime ranking.

The `compiler-transformed` profiles intentionally emit transformed source and do not claim VM virtualization. The function-policy fixture only routes supported named top-level global functions; unsupported cross-backend captures fail closed unless explicit fallback is enabled.

The active v4.7.8 test suite includes an independent per-instruction shadow-state proof and mutation probes for skipping shadow execution, forging the tick count, and forging tick/accumulator/commit without a valid proof. Those are focused probes, not a proof against an analyst who patches the verifier or rewrites generated control flow.

The loader scan detects direct `load(`/`loadstring(` call sites in generated text. The focused tests also instrument `load` and `loadstring` on selected fixtures. These checks do not prove that no other extraction technique can recover the payload or that the VM resists devirtualization.

**Scope:** the measured runtime version is recorded from `_VERSION` as `Lua 5.4`. Native Roblox/Luau execution, Lua 5.1/5.3 compatibility, large real-world input stress, and independent third-party crack resistance were not established by this benchmark. No results here demonstrate parity with Luraph or another commercial obfuscator.

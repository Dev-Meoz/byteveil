# ByteCode v2.5.1

## Syntax fix

Fixed generated VM entry invocation that emitted `...` at top-level:

```lua
local result={run(root,...)}
```

That is invalid in the generated main chunk on Luau/Lua and caused:

```text
cannot use '...' outside a vararg function near '...'
```

It is now emitted as:

```lua
local result={run(root)}
```

Varargs are still preserved inside actual vararg functions and generated closures.

## Native validation

Added native runtime integration:

- `tools/native-runtime.js`
- `tools/native-test.js`
- `tools/install-native.ps1`
- `npm run native:install`
- `npm run native:test`

The native test loads generated output through the real Lua/Luau parser without executing the obfuscated program.

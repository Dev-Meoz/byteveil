# ByteCode v2.5.2

## Fixed
- Fixed native Luau/Lua syntax failure caused by `unknownCode` junk being emitted after the VM's top-level `return`.
- Junk is now inserted immediately before the final VM return, so it still runs after VM execution but remains valid Lua/Luau syntax.
- Kept the v2.5 portable bit-operation helpers.
- Kept the v2.5.1 native-runtime installer compatibility fix for archives containing `lua.exe` instead of `lua54.exe`.
- Removed local `.env` files from the distributable package.

# ByteCode v2.6

## Target auto-detection

- `target=auto` is now the default.
- `.luau` and Roblox/Luau API markers select **Luau v0.739**.
- Other source selects the new **Lua Engine v1**.
- Lua version is not requested from the user: the generated Lua output targets the common Lua 5.1-5.4 runtime surface.

## Engine split

### Luau
The existing embedded VM implementation is kept in the tree, but v2.6.3 routes Luau through the runtime-safe source container by default.

### Lua
A separate `ByteCode Lua Engine v1` was added. It:

- encodes the original source as byte data;
- uses a portable arithmetic XOR decoder;
- uses `loadstring or load` for Lua 5.1-5.4 compatibility;
- avoids `_ENV`, bitwise syntax, `string.pack`, `table.unpack`, and Luau-only APIs;
- emits `.lua` output.

## Discord `/obf`

```text
/obf
├── preset: default | maximum
├── attach: .lua | .luau
└── target: Auto detect | Lua | Luau
```

Target behavior:

- Auto/Luau -> Luau v0.739 -> legacy Luau VM engine -> `.luau`
- Auto/Lua -> Lua Engine v1 -> Lua 5.1-5.4 common runtime -> `.lua`

No Lua version picker is required.

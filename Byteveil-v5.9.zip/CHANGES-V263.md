# ByteCode v2.6.3 runtime fix

## Fixed
- Fixed payload-container extra array nesting that caused `string.char(...): number expected, got table` on Lua runtimes.
- Fixed physical-fragment ordering so decoded source bytes are reconstructed in the original order before integrity validation.
- Kept fragmented payloads and decoy shards without exposing one giant payload string.
- Kept `return setmetatable(...)` callable wrapper generation.
- Unknown-code insertion uses executable local/closure/metatable chunks; legacy `BCSZ` padding is not generated.
- Added native runtime regression coverage for Lua and Luau targets. On Windows the bundled Luau executable is used; on Linux the Lua regression can use an installed Lua/LuaTeX runtime.
- `npm start` continues to reset/register Discord commands before launching the bot.

## Validation
- `npm test`: PASS
- Lua native execution regression: PASS in the available LuaTeX runtime
- Luau native execution: run on Windows with the bundled `tools/native/windows-x64/luau.exe`

## Compatibility design
- Lua target uses the portable source container so Lua 5.1-style `loadstring` and newer `load` runtimes are handled through `loadstring or load`.
- Luau uses the embedded VM only for the validated VM-safe subset and falls back to the portable source container for unsupported syntax/features instead of emitting unsafe VM code.


## v2.6.3 Luau runtime fix

- Disabled the partial embedded Luau VM as the default Luau execution backend.
- Luau now uses the same runtime-safe encoded source container architecture as the proven Lua path.
- Original Luau syntax is reconstructed and compiled by the target Luau runtime instead of being reinterpreted by the partial AST VM.
- Added native Luau runtime test coverage for typed functions and compound assignment.
- Updated the validation runtime target to Luau 0.739.

- Added a Luau-only SizeBuff separator guard so executable padding always starts after an explicit statement boundary (`;`), preventing `enddo` generation.

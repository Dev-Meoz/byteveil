# ByteCode v2.7.0 — VM hardening rebuild

## Compatibility anchor
- `src/backend/source_engine.js` is byte-for-byte unchanged from v2.6.3.
- Lua output therefore remains on the proven v2.6.3 source engine.
- Luau continues to use the v2.6.3 native source/container execution model.

## New VM layer
- Added `src/vm/vm_island.js`.
- The VM island executes only deterministic hardening/guard instructions and never executes decoded user code.
- Handler slots are permuted per build.
- State permutation and dispatch-noise metadata are added to `customVM`.
- Opcode mutation now carries per-build slot multiplier/additive routing and handler salt.
- Super-operator planning was expanded and remains metadata-only until a full runtime-safe virtualized backend is ready.

## Generated-code rules
- Executable `local-chunk`, closure and metatable-call junk remain available.
- `BCSZ`/`BCZS` comment padding is not generated.
- Luau VM island is enclosed in its own `do ... end` block.

## Verification
- Full legacy regression suite passes.
- v2.7 generation/VM metadata regression passes.
- Lua native runtime smoke passes on the local Lua runtime available in this environment.
- Native Luau execution is run through `tools/native-runtime.js` when the configured `luau.exe` is available on the host; this Linux environment does not execute the bundled Windows binary.

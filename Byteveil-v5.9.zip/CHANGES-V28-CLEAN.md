# ByteCode v2.8.0 clean output

- Removed the `unknown_code_inserter` component from the release tree.
- Lua and Luau no longer emit executable junk or padding blocks.
- The existing native Lua/Luau runtime mechanism remains unchanged.
- Generated wrappers are compacted to a single code line; the optional watermark comment remains on its own line.
- `l1` and `df` keep the gsub wrapper family.
- `l2` and `lz` keep the setmetatable wrapper family.
- Runtime regression tests keep the existing native-runtime contract.

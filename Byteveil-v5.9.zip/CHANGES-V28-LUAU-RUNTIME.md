# ByteCode v2.8.0 — Luau Runtime Fix

- Lua legacy runtime/source engine is unchanged.
- `src/detect.js` is unchanged; explicit `.lua`/`.luau` filenames remain authoritative.
- Luau generated shell now uses single-line-minified layout instead of a semicolon-packed one-line shell.
- Luau wrappers: `l1`/`df` use gsub; `l2`/`lz` use `do return setmetatable(...)`.
- Removed `unknown_code_inserter` and SizeBuff/padding generation from both Lua and Luau output.
- Added `.rules` Discord command with English/Vietnamese ByteCode rules.
- Native Lua runtime path is deliberately preserved.

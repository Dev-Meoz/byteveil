# ByteCode v2.8.0

## Runtime-safe Luau shell update

- Preserved the v2.6.3 Lua native runtime path byte-for-byte; the generator only removes optional junk insertion.
- Preserved `src/detect.js` byte-for-byte; explicit `.lua` and `.luau` filenames remain authoritative.
- Reworked only the Luau generated shell to use single-line-minified statement layout instead of a semicolon-packed one-line shell.
- `l1` and `df` use the gsub wrapper family.
- `l2` and `lz` use the `do return setmetatable(...)` wrapper family.
- Removed `unknown_code_inserter` and all generated junk/padding blocks from both Lua and Luau output.
- Added `test-v280-luau-native.js`; it executes the real native Luau runtime when `luau` is installed.

## Discord

- Added `.rules` prefix command.
- Added `bot/discord/BYTECODE-RULES.md` with English + Vietnamese server rules.

## Detection

The detector intentionally does not guess Luau from Lua-compatible syntax such as `setmetatable`, numeric arrays, semicolons, `table.unpack`, or `string.char`. Without a filename or a Luau-only marker, the supplied opcode-style snippet is correctly treated as Lua-compatible. A `.luau` attachment is classified as Luau with confidence 1.0.

## Verification

- Full Node regression suite: PASS.
- Lua native syntax/runtime for l1/l2/lz: PASS.
- Luau generated shell sanity: PASS, including zero code semicolons.
- Native Luau test on the current Linux host: SKIPPED because only the Windows `luau.exe` is bundled; run `npm run test:v280:luau-native` on Windows to execute the real native runtime.

# ByteCode v2.8.1

- Fixed Luau syntax regression from generated `do;local ...` opcode shell.
- Added Luau sanity rejection for standalone keyword semicolons after `do`, `then`, and `else`.
- Regenerated v2.8 Luau outputs with the fixed shell.
- Switched Discord bot from prefix/message commands to slash commands only: `/help`, `/rules`, `/obf`.
- Slash `/obf` accepts exactly one of `file`, `code`, or `url`, plus optional `target`.
- Bot now uses only the `Guilds` gateway intent; Message Content Intent is not needed.
- Removed the old command-reset flow so startup no longer deletes slash commands.

# ByteCode v2.8.2

- Discord commands are now exactly `/help`, `/rule`, and `/obf`.
- `/obf` options are `presets`, `attach`, `input`, and `upload`.
- `presets` choices: `l1`, `l2`, `df`, `lz`.
- `attach:code` uses `input` for raw source.
- `attach:url` uses `input` for an HTTP/HTTPS URL; the downloaded source is detected, not the URL/file extension.
- `attach:file` uses `upload` for `.lua`, `.luau`, or `.txt`.
- Removed the Discord `target` option entirely.
- Source detection is source-first for all input modes. `.lua` / `.luau` extensions are fallback-only when syntax is ambiguous.
- No `unknown_code_inserter` or junk padding added.

# ByteCode v2.9.0

## Source-container hardening

- Keeps the existing Lua/Luau source-container execution contract and target auto-detection.
- Adds a printable custom radix-85 payload layer.
- Adds per-byte stream transformation: rolling state, XOR, nibble rotation, and additive delta.
- Splits payloads into shuffled shards and keeps reconstruction order in a separate encoded stream.
- Uses bounded decoy payload shards instead of the legacy giant random key/data blocks.
- Removes the legacy padding/junk families from generated output; `junkCount` remains zero.
- Randomizes generated runtime-local identifiers per seed.
- Keeps the final source recovery path as `loadstring or load`, so the target Lua/Luau runtime remains authoritative.

## Compatibility

- Existing native Lua/Luau runtime files are left untouched.
- Discord slash command schema remains `/help`, `/rule`, and `/obf` with `presets` + `attach` + `input/upload`.
- v2.8 regression tests remain in the suite.

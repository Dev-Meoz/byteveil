# ByteVeil v3.8.0 — full-fix change log

## Root fixes

- Replaced the strict VM output path with a real packed-bytecode transport: compiler output is serialized into an opaque binary payload, transformed, encoded, sharded, reordered, then decoded by the generated VM. The previous Lua-visible node/CFG graph is not emitted by the strict VM backend.
- Wired opcode remapping/mutation into the real instruction stream so serialized opcodes and VM dispatch use the same per-build mapping.
- Fixed multi-shard payload corruption by making opaque85 shard spans 4-byte aligned; only the final shard may carry base85 padding, and the VM truncates that terminal padding to the recorded payload length.
- Fixed the payload codec seed/initial-state mismatch between JS serialization and generated Lua runtime.
- Fixed printable-string reconstruction to use the ASCII printable alphabet instead of the base85 alphabet.
- Fixed multi-return function result unpacking by binding `table.unpack or unpack` once rather than relying on an expression with a zero-result `or` fallback.
- Fixed integer zig-zag decode so integer literals remain integers instead of becoming `3.0`-style floats.
- Register compiler now uses the shared `ConstantPool` and opcode-shuffle layer used by the stack compiler.
- Reimplemented the useful iterator-lowering idea from the reference custom VM in JS: generic-for now captures iterator multi-results with a dedicated `CALLM` instruction and explicit iterator state before entering the loop body.
- Reimplemented the reference string-splitting idea as AST-level literal concatenation; no byte/`string.char` reconstruction is introduced.
- Reimplemented a small opaque-predicate idea as a semantics-preserving `and not false` condition, avoiding junk strings and runtime data.
- Fixed parser token precedence so string literals whose value is `#`, `-`, or `~` are not misread as unary operators.
- Fixed hexadecimal floating-literal parsing and source-route numeric spelling preservation, including integers beyond JavaScript safe-integer range.
- Fixed source-route rendering of dotted functions and method declarations/calls so fallback protection preserves implicit `self` semantics.
- VM fallback is no longer a catch-all for internal compiler/serializer/generator failures: only explicit strict-VM compatibility rejections can use the protected-source route.

## Protection contract

- Preserved preset names and API/CLI structure: `l1`, `l2`, `df`, `lz`.
- `l1`/`l2` use the same packed-bytecode VM pipeline at lower strength; `df`/`lz` use higher live payload diversification. `lz` receives a larger live decoy set in the serializer.
- Strength now participates in the live payload seed, so changing strength changes the actual packed artifact rather than metadata alone.
- Strict VM output rejects `string.char` and decimal byte escapes at generation time.
- Valid UTF-8 source-route shards no longer fall back to decimal byte escapes; shard boundaries are kept on UTF-8 codepoint boundaries.
- Final output is minified after VM/wrapper generation. With the watermark enabled, the final file is one watermark line plus a one-line body.

## Verification

`node test-v38-full.js`, `npm test`, and `npm run test:all` all pass. The full suite covers 30 native-Lua golden runtime cases, stack/register execution, source-route compatibility cases, deterministic builds, preset differentiation, payload codec round-trips, shard-boundary behavior, and output invariants.

## Scope note

The strict packed-bytecode VM is the primary v3.8 path. Unsupported language features that are not yet safely lowerable (for example vararg/multi-return hazards and some Luau-only syntax) still use the protected-source fallback rather than risking semantic corruption. Generic-for is now covered by the strict VM path.

The reference ZIP was used as an architectural reference only. The selected mechanisms were reimplemented in ByteVeil JavaScript rather than copied; byte-oriented `string.char` encoding, raw-source compression/loadstring paths, and junk-heavy steps were intentionally not ported.

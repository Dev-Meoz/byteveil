# ByteVeil v3.9.0 — surgical update from v3.8

## Core objective

v3.9 keeps the v3.8 project layout and public preset/API contract while reducing trivial source recovery and expanding the strict VM path.

## Root fixes

- Unified Lua/Luau normalization into the existing custom-VM pipeline.
- Added semantic IR analysis/fingerprinting and fold that fingerprint into build seeding.
- Lowered typed Luau annotations and common Luau syntax into the existing AST/VM contract.
- Fixed lexical closure renaming across nested function scopes.
- Added real generic-for lowering for stack/register modes.
- Added loop-aware `break` lowering instead of terminating the whole VM.
- Added fixed-count multi-return assignment lowering for global/local/method calls.
- Added real super-instruction fusion with jump-target relocation.
- Added constant-pool permutation on the real compiler payload.
- Kept opcode mutation/remapping and payload transforms on the real instruction stream.
- Removed silent strict-mode source fallback; compatibility source protection is explicit.

## Output contract

Strict output uses packed bytecode + VM transport and is checked for: `string.char`, decimal `\ddd` byte escapes, source-loader calls, and common raw-source fragments.

## Presets

`l1`, `l2`, `df`, and `lz` share the same pipeline. Strength controls protection depth; output size is not the primary metric.

## Verification

`npm test` runs `test-v39.js`. The suite covers both stack/register VM modes, all four presets, Lua samples, Luau typed syntax, closures, loops/break, generic-for, methods, fixed multi-return, strict rejection, explicit compatibility routing, static output invariants, and auto-detection.

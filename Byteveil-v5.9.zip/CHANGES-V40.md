# ByteVeil v4.0.0 — staged polymorphic VM release

## Core objective

v4.0 keeps the v3.9 public project layout, API, commands, targets and preset names while changing the protection architecture so the generated VM is no longer a single canonical runtime shape.

## Core changes

- Added staged runtime activation with linked bootstrap, decode, payload and VM stages.
- Added per-build decoder families and build-seeded runtime layout mutation.
- Added polymorphic handler generation for semantics-preserving VM operations.
- Reworked SUPER execution into specialized fused handlers generated from each actual SUPER body.
- Added distributed/per-chunk constant permutation before payload packing.
- Added cross-layer integrity validation combining payload checksum with build descriptor/opcode state.
- Added deep cyclic Decoy VM graphs to every preset, with preset-dependent depth and bounded runtime budgets.
- Restored optional hardened runtime-reference checks for stronger presets.
- Added explicit v4.0 structural metadata so callers/tests can identify staged, polymorphic, fused-SUPER and decoy layers.
- Fixed loop-target relocation for `ITERLOOP` when instruction fusion changes bytecode layout.
- Updated the strict compiler/compatibility error version to v4.0.
- Added `test-v40.js` as the default regression suite.

## Presets

`l1`, `l2`, `df`, and `lz` are unchanged as public preset names. All presets use deep decoy protection; depth/budget scale with preset strength.

## Runtime contract

- Targets remain Lua 5.1, Lua 5.2, Lua 5.3, Lua 5.4 and Luau-compatible source.
- Both `stack` and `register` VM modes remain supported.
- Strict mode remains semantics-preserving and does not intentionally execute an unbounded decoy loop.
- Existing API paths, CLI commands and folder structure are preserved.
- Root `.env` and `bot/.env` are preserved unchanged.

## Watermark

`--This file was protected using ByteVeil Obfuscator v4.0 [https://discord.gg/rAhAnnkBn8/]`

## Verification

`npm test` runs the v4.0 suite covering all four presets, both VM modes, Lua/Luau inputs, loops/break, generic-for, closures, methods, fixed multi-return, staged metadata, decoy budgets, decoder polymorphism, strict rejection and explicit compatibility routing.

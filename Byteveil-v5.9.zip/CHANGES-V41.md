# ByteVeil v4.1.0 — decoy VM shape quick fix

- Kept the v4.0 public contract, targets, presets, commands, API paths and folder structure.
- Reworked the decoy layer so fake frames use VM-like state, opcode tokens, handler banks, dispatch and bounded control-flow traversal.
- Decoy frames now share the same broad grammar as the real VM instead of using arithmetic-only fake functions.
- Added a cyclic decoy graph with preset-dependent static depth and bounded runtime execution.
- Preserved semantic/runtime behavior and the v4.0 staged/polymorphic real VM.
- Updated active release metadata/watermark to v4.1 while keeping the Discord URL unchanged.

## Verification

`npm test` covers Lua/Luau strict VM behavior, both VM modes, all four public presets, staged metadata and v4.1 decoy-VM shape checks.

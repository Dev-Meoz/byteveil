# ByteVeil v4.2.2

## Focus
Legacy-engine modernization and VM-grade decoy refresh.

## Core changes
- Unified opcode/ISA planning in `src/obfuscation/isa_engine.js`.
- Legacy opcode mutator/shuffle/context modules now act as compatibility facades over the unified ISA engine.
- Four independent generated handler-route lanes replace the former 2-route duplication.
- Decoy VM expanded from 9 to 12 primitive handler families and from 2 to 4 bounded lanes.
- Decoy frame generation uses four VM-shaped execution templates instead of one repeated state-function skeleton.
- Decoy material now contributes four independent activation values to staged payload/guard paths.
- Variable-renamer compatibility module now delegates to the main scope-aware mangler, removing the duplicate legacy renaming implementation.
- MFG and protection metadata updated to v4.2.2.

## Compatibility
- Lua 5.1 / 5.2 / 5.3 / 5.4 and Luau targets retained.
- Presets remain `l1`, `l2`, `df`, `lz`.
- Existing API/commands/path layout retained.
- Root `.env` and `bot/.env` are preserved byte-for-byte.
- Legacy source engines remain available only through their compatibility routes; strict VM remains the primary protection path.

## v4.3 preparation
Macro/LPH are intentionally not included. They remain reserved for the next feature phase after a new v4.2.2 red-team audit.

## Final 4.2.2 quick-update hardening
- Strict serialization now consumes the unified ISA plan directly; the legacy `polymorphic_opcode.js` planner is no longer on the primary VM serialization path.
- `polymorphic_opcode.js` is retained only as a compatibility facade backed by `isa_engine.js`, preventing a second active opcode-planning implementation.
- Decoy accumulator/stack arithmetic was hardened against synthetic boolean/non-numeric stack values so the bounded decoy cannot turn its own artificial state into a runtime failure.
- Preserved the historical `Opcode.js` numeric facade and compatibility routes while keeping v4.2.2 physical opcode generation centralized in the unified ISA engine.

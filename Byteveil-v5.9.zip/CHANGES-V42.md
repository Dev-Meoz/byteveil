# ByteVeil v4.2.0 — Quick Fix / Hardening Release

## Focus

v4.2 is a hardening release driven by the v4.1 red-team report. The goal is to reduce the value of static separation and one-shot payload recovery while keeping the existing public contract unchanged.

## Core changes

- Integrated the REAL VM and VM-shaped Decoy VM through a shared execution-fabric state channel.
- Changed staged payload handling to lazy materialization after activation-state derivation.
- Added build-seeded polymorphic handler routes and VM personality metadata.
- Added decoder-family selection to diversify generated transport structure.
- Added Protection IR as a compiler-side representation of hardening policy.
- Added the Byte-Blinder protection engine for anti-hook, anti-tamper and anti-dump orchestration.
- Added MFG-4.2 generation/mutation planning for VM, state, handler and decoy topology variation.
- Strengthened cross-layer validation using payload, descriptor, opcode, shape and build-state tokens.
- Kept decoy execution bounded even when the static decoy topology contains cycles.
- Fixed strict VM method lowering so `function T:method(...)` uses the implicit `self` receiver correctly.

## Compatibility

- Presets remain: `l1`, `l2`, `df`, `lz`.
- Lua 5.1/5.2/5.3/5.4 and Luau-compatible source targets remain supported by the existing contract.
- Public API, commands, paths and folder structure remain unchanged.
- Root `.env` and `bot/.env` are preserved without content changes.
- v4.2 watermark uses `https://discord.gg/rAhAnnkBn8/`.

## Verification

- `npm test` — PASS.
- Native Lua syntax/runtime validation — PASS for register and stack modes.
- 80-case semantic fuzz/regression sweep across Lua semantics, `l1/l2/df/lz`, stack/register — PASS (80/80).
- Native Luau executable was not installed in the build environment; Luau-compatible sources are still exercised through the existing parser/normalization/runtime test route.

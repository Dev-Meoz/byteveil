# ByteVeil v4.3.0 — The Final Engine Era

## Release focus

ByteVeil v4.3.0 is an architectural rebuild focused on runtime correctness first and engine modernization second. The public Discord-bot workflow, API surface, command names, preset names (`l1`, `l2`, `df`, `lz`) and existing repository layout are preserved.

## P0 — Native/runtime correctness

- Repaired the v4.2.x VM-generation path that could produce runtime-invalid decoy state operations.
- Kept generated operations compatible with the Lua 5.1–5.4 common surface used by the strict VM backend.
- Added a dedicated v4.3 native smoke test for the available native Lua runtime.
- Luau native execution remains platform-gated: the bundled native Luau executable is Windows-only and is not executed on this Linux build host.
- Runtime validation covers syntax plus observed stdout for protected programs, not just compiler success.

## P1 — Engine rebuild

### Unified execution/ISA direction

- Dense handler banks replace large runs of keyed numeric function assignments where the physical index is already positional.
- Existing ShuffleBytecode and SuperInstructions infrastructure is retained and integrated into the unified ISA path instead of introducing duplicate engines.
- The VM metadata is stamped as `4.3.0` and `unified-metamorphic-vm-v430`.

### Decoy VM rebuild

- Decoy generation now uses the same physical opcode universe and route families as the Real VM.
- Decoy handlers are generated from a VM semantic-class compiler and stored as a dense handler bank.
- Decoy execution remains synthetic and bounded, with explicit runtime-safe state handling.
- Four decoy lanes use route-aware dispatch instead of computing a route and ignoring it.
- The target is VM-grade structural similarity to the Real VM without introducing unbounded or resource-killing loops.

### New v4.3 engine surfaces

- **ByteVeil-Micro:** compile-time Macro/LPH directive recognition and IR annotations.
- **ByteVeil-MFG:** build-specific metamorphic generation metadata and representation diversity.
- **Byte-Blinder:** representation/layout planning for generated state access and protection structures.
- **Access Shape Planner:** reduce excessive fixed numeric `[]` access while retaining dynamic/sparse indexing where required.
- **Byte Encoding / Decoding:** continued staged package transport under the existing packed-bytecode contract.

## Generated-source shape

v4.3 does not ban `[]`. It applies a structural policy:

- Dynamic and sparse keys keep bracket access.
- Static fixed-state access can use generated fields/local aliases where scope-safe.
- Hot repeated access should be localized by the generator rather than rewritten blindly at the end.
- Keyed function registries are organized into dense arrays when ordering is already positional.

The first v4.3 access-shape pass intentionally leaves overloaded Real-VM `S`/`Q` identities untouched until a scope-aware rewrite exists; dedicated decoy-state objects are safe rewrite targets.

## Validation

- `npm test` — PASS.
- JavaScript syntax scan — PASS across the project source set.
- Native Lua 5.4 smoke — PASS for stack/register × `l1`/`l2`/`df`/`lz` in the current Linux host.
- Native Luau — SKIP on this Linux host because no native Luau executable is installed; the archive retains the bundled Windows native executable and test hook.

## Compatibility contract

Targets remain Lua 5.1, 5.2, 5.3, 5.4 and Luau. Unsupported syntax must not silently fall into a different strict semantic model. Explicit compatibility routes remain separate from the strict VM backend.

## Watermark

`--This file was protected using ByteVeil Obfuscator v4.3.0 [https://discord.gg/rAhAnnkBn8/]`

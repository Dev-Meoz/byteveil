# ByteVeil v4.3.1 — Macro / LPH Quick Update

## Focus

- Adds independent `src/macros/` and `src/lph/` engines.
- `ByteVeil-Micro` is reduced to shared helper utilities; it does not control Macro or LPH.
- Native ByteVeil macro surface: inline, outline, virtualization, super, cfg, mfg, cgi, pre-check, rewrite, enc-func, vm, cff, encstr, index-to-num, obfuscated, crash, omit, line and compress.
- LPH compatibility surface: obfuscated, line, crash, no-virtualization, enc-func, pre-check and rewrite.
- Directive plans are attached to the AST as non-enumerable metadata so the current runtime path is not changed just by adding a directive comment.
- Common `LPH_*` comment aliases are normalized to the requested `byteveil-*` compatibility names.
- Public API/presets/path contract remains unchanged.

## Validation

- Macro/LPH unit coverage added to `test-v431.js`.
- Existing v4.3 runtime/compiler regression remains enabled.

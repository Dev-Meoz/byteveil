# ByteVeil v4.3.3

- Kept the proven v4.3.2 multi-material payload path intact to avoid introducing a runtime regression while hardening the validation boundary.
- Replaced the previous XOR-identity validation with concrete shape, raw-payload checksum, and activation checks.
- Added conservative stack-prefix bytecode safety validation to reject invalid binary/unary instructions at chunk entry before generation.
- Preserved existing commands, presets, directory layout, and VM public API.
- Added regression coverage for `!` in strings and `--!strict` comments.
- Updated all v4.3.3 runtime/metadata labels consistently.

## Payload fragmentation follow-up
- v4.3.3 payload container now protects each logical shard independently before radix-85 packing.
- Default shard sizes were reduced to keep payload material physically small and distributed (strength-aware 8/12/16-byte minimums).
- Physical shard order is randomized while a separate logical order restores semantic order at runtime.
- Runtime payload reconstruction is split across `byteveil.crack`, `byteveil.time`, `byteveil.skid`, and `byteveil.hello` before entering the existing VM decoder.
- Each shard uses a reversible per-shard byte mask domain derived from its logical sequence and byte position; the final payload is still temporarily materialized in memory because the existing bytecode parser consumes a byte array.
- Verified the shard protect/deprotect path byte-for-byte and ran the v4.3.3 regression matrix successfully after the change.

# ByteVeil v4.5.3

## Focus

- Nested heterogeneous source-obfuscation layers.
- Build-specific VM personality and topology retained from v4.5.2.
- Layered anti-tamper, anti-hook and anti-dump runtime checks.
- Existing graph/material/opaque-IR/VM-A/VM-B/micro-op pipeline preserved.
- `unknown_code_inserter` removed from the v4.5.3 runtime and source path.
- `.env` included as a local engine configuration template.

## Nested model

A protected build can be represented as:

```text
source
  -> protected source layer 1
  -> protected source layer 2
  -> protected source layer 3
  -> ...
  -> final runtime
```

Each layer has its own state/integrity boundary and codec family. A successful recovery of one layer yields the next protected representation rather than the original source.

## Compatibility

Public commands, presets (`l1`, `l2`, `df`, `lz`), stack/register modes and existing project structure remain intact.

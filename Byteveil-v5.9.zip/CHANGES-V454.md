# ByteVeil v4.5.4

## Security architecture update

v4.5.4 is a structural hardening release based on the v4.5.3 red-team findings.

### Added

- Build-specific VM personality planner.
- Per-build VM state topology/order selection.
- Per-build VM state salts and topology salts.
- Build-specific recipe style and dispatch profile metadata.
- Explicit VM personality metadata in `vmMeta`.
- Regression coverage proving different seeds produce different VM state layouts.
- Runtime-verified stack and register builds for the new state profiles.

### Preserved

- Region graph and dependency graph.
- Distributed region materialization.
- Opaque transport IR.
- VM-A → runtime VM-B → semantic micro-op execution.
- Region-specific vocabulary and recipe banks.
- Nested heterogeneous protection.
- Runtime anti-tamper / anti-hook / anti-dump checks.
- `.env` configuration and existing public API/project layout.

### Removed

- No `unknown_code_inserter` was added.

### Regression note

High-strength (10000) output remains syntax-validated in the bounded regression gate because the generated nested artifact is intentionally much larger. Functional runtime tests are performed at the normal 3500 profile, while build-to-build structural diversity is tested independently.

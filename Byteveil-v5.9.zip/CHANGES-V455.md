# ByteVeil v4.5.5 — Semantic Architecture Upgrade

## Scope

v4.5.5 upgrades the semantic execution architecture on top of the v4.5.4 baseline. It does not attempt to make client-side Lua/Luau reverse engineering impossible and does not add a large stack of superficial encode layers.

## P0 implemented

### Build-specific VM

Build personality now participates in actual generated execution inputs rather than being metadata-only. The profile controls multiple dimensions:

- VM state order/profile
- dispatch family
- recipe composition
- representation family
- resolver family
- state model
- commit style
- micro-op order
- build/region salts

### Runtime VM-B

The v4.5.5 strict path no longer emits a complete static recipe/handler bank. A region-local VM-B closure is materialized at runtime and derives its micro-op sequence from the live state/region inputs.

### Semantic composition

The execution path separates:

1. instruction representation
2. region routing
3. runtime composition
4. semantic micro-ops
5. final state/semantic commit

This removes the direct architectural assumption that one opcode identifier equals one fixed semantic handler.

### Representation Morphing

The transport layer now selects build/region representation families instead of applying only another text/byte codec layer. v4.5.5 currently supports array, sparse, record, tuple, split and tagged instruction/constant/control representations.

### Resolver diversity

Each region has both a region variant and a build-derived resolver family. Dependency traversal uses the combined variant, and the resolver family also participates in region seed derivation.

### Distributed materialization

The graph runtime keeps region reconstruction lazy and dependency-driven. A small recent-region cache is used rather than retaining every reconstructed region indefinitely.

## P1 implemented/retained

- per-region opcode/vocabulary mapping
- lazy instruction materialization
- lazy constant materialization
- nested heterogeneous protection
- anti-tamper / anti-hook / anti-dump checks
- heterogeneous decoy families
- non-canonical transport representation before final execution

## Deliberate non-goals

- No `unknown_code_inserter`.
- No “15–20 more encode layers” design.
- No universal plaintext resolver choke point.
- No complete static v4.5.5 semantic handler/recipe bank in the strict path.
- No claim of impossible reverse engineering.

## Verification

### Passed

- `node --check` on modified JavaScript source files
- `node test-v455.js`
- `npm test`
- stack-mode runtime smoke at strength 3500
- register-mode runtime smoke at strength 3500
- high-strength 10000 syntax validation
- 20-build diversity gate
- nested codec syntax/runtime checks
- tamper probe
- hook probe
- legacy v4.3.3 frontend/stack-safety regression

### Bounded high-strength note

Strength 10000 generated artifacts are intentionally large. The release gate syntax-validates the 10000 output and performs functional runtime checks at strength 3500. The bundled Lua runner is not used as evidence of a high-strength 10000 runtime PASS.

## Compatibility

The existing project tree, command/API paths, presets (`l1`, `l2`, `df`, `lz`), stack/register modes, `.env`, `bot/` and Macro/LPH ownership model are preserved.

## Known strict-VM compatibility boundary

The existing strict VM policy still rejects multireturn-sensitive vararg assignment and certain return-call forms rather than silently compiling them through an unsafe fallback. This was not changed in v4.5.5 because the release focus is semantic protection architecture; those inputs remain explicit compatibility rejections, not unverified runtime behavior.

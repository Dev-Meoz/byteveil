# ByteVeil v4.6.1

## Focus

v4.6.1 keeps the proven v4.6 nested protection and region/material engines intact while fixing the weaknesses identified by the v4.6.0 red-team report.

## Implemented

- Kept the existing 9-stage nested protection policy at strength 10000.
- Active v4.6.1 nested/source compatibility loader resolves `load` through `getgenv`/`getfenv`/`_G`; generated v4.6.1 output does not emit `loadstring`.
- Important constants/parameters remain lazy function-backed values and runtime state resolves them on demand.
- Expanded instruction PBF into 12 executable layouts, including function-backed, cons-list, and sparse-keyed layouts.
- Added 8 PBF families and 6 CFF/control families which participate in generated runtime paths.
- Added bounded control-flow advancement that is semantically neutral and selected by runtime state/personality.
- Preserved region-local semantic materialization and the six v4.6 VM architecture families.
- Strengthened runtime reference integrity / anti-hook snapshots for core runtime primitives and environment APIs.
- Preserved existing nested codecs, graph/material/instruction representation engines, and compatibility aliases.
- Removed the old pre-v4 source engine dependency from the active compatibility route.

## Verification

- `npm test` PASS.
- v4.6.1 architecture/runtime/protection regression PASS.
- v4.6.1 nested + anti-tamper/hook/dump regression PASS.
- 18-build structural diversity matrix: all builds unique; six PBF/CFF/architecture families exercised.
- 8-build high-strength runtime matrix: 7/9 nested paths at strength 8000/10000 and representative stack/register programs completed without timeout; observed Lua 5.4 runtime remained below 1.7s in the local test environment.
- Active v4.6.1 generated output contains no `loadstring` token.

## Boundary

This release does not claim that client-side Lua/Luau code is impossible to observe or reverse. The goal is to reduce reuse of a single static devirtualization model across materially different builds while keeping runtime semantics stable.

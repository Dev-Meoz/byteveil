# ByteVeil v4.6.2

## Focus

Reduce nested runtime overhead for low-resource devices without dropping nested stages, while fixing common Lua/Luau parser failures reported against v4.6.1. Existing graph/representation/VM engines and preset names remain intact.

## Nested runtime and memory

- Default `nestedProfile: "balanced"`: all 9 stages remain at strength 10000; the four outer stages use a lower-cost mixer and the inner five keep the full mixer. The small nested-only benchmark showed roughly 8% lower runtime and 38% lower peak RSS than the v4.6.1 baseline in this environment; device results can differ. `nestedProfile: "full"` retains the full mixer in all stages.
- Decoder frees consumed entries from reverse/secondary raw buffers before assembling the result string; split codec releases raw/left/right intermediates before emit.
- Kept integrity/tamper checks, heterogeneous codecs, environment-resolved loader and the nested-stage count policy. No new layers were added.
- On the local Lua 5.4 runner, a 10.8 KB nested-only sample: v4.6.1 baseline 9 layers was about 0.52 s / 21.4 MB peak RSS; v4.6.2 balanced was about 0.48 s / 13.2 MB; v4.6.2 full was about 0.49 s / 13.2 MB. Timings are environment-specific, not device-wide guarantees.

## Parser/lexer

- Supports Lua call sugar (`print "text"`, `obj:Method{...}`).
- Expands Luau generic function/type-alias and type-cast erasure before strict VM compilation.
- Supports compound assignments including `//=`, `%=`, `..=`, numeric separators, binary and hex-float literals, if-expressions and shebang.
- Added parse + generated-runtime regression cases to reduce repeated `Expected assignment or call` failures.

## Verification

- `npm test`: PASS (v4.6.2 runtime/protection, retained v4.6.1 regression, v2.5 legacy compatibility and v4.3.3 frontend/stack safety).
- 24 seed × 2 profile nested runtime matrix: PASS.
- High-strength stack/lz sample with 9 layers: balanced/full both runtime PASS.
- The package excludes real `.env` files and ships blank `.env.example` templates.

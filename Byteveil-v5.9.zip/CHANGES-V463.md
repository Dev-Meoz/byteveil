# ByteVeil v4.6.3 — Release notes

## Implemented

- Bumped active package/generator version identifiers to v4.6.3 while keeping historical v4.6.2 regression suites.
- Added output/source byte counts, decimal-KB size budget status, overhead and output/source ratio to results; CLI and benchmark report preset and target-size context.
- Added LZSS compression for repetitive nested payloads in the v4.6.3 path, including extended back-references up to 32 KiB and adaptive match lengths for large intermediate payloads, with decompressed-length validation and retained per-layer payload integrity verification.
- Added nested compression telemetry per layer and passed summary data through VM metadata.
- Added a release gate covering semantic cases, build diversity, strength/layer invariants, output-size tracking and compressed-payload tamper behavior.
- Kept default preset names and nested strength/layer policy unchanged. No output padding, truncation or automatic weakening is performed to satisfy the size budget.

## Verification evidence

- Semantic runtime: PASS for 14 Lua 5.4 executions across `stack` and `register`: closure, shared upvalue, coroutine yield/return, metatable `__index`/`__add`, multiple return, and `pcall`/`xpcall` error handling.
- Vararg expansion: explicitly rejected by the strict VM; not counted as supported.
- Build diversity: 12 same-source builds yielded 12 distinct collected VM topology/representation signatures in this test sample.
- Nested protection: both `balanced` and `full` retain 9 layers at strength 10000.
- LZSS path: runtime output and syntax checks pass, including an extended-distance fixture beyond the original 4 KiB window; tampering with an outer encoded payload causes execution failure.
- Legacy regression suite: `test-v462.js`, `test-v461.js`, `test-v25.js` and `test-v433.js` are retained in `npm test`.

## Size and performance samples

With `examples/input.lua` (85 bytes), Lua target, stack mode, wrapper disabled and watermark disabled:

| Preset | Output bytes | Nested layers |
|---|---:|---:|
| `l1` | 67,128 | 3 |
| `l2` | 126,773 | 5 |
| `df` | 241,618 | 7 |
| `lz` | 454,135 | 9 |

One local Lua 5.4 benchmark sample:

| Preset | Build wall (ms) | Build CPU (ms) | Node peak RSS (MiB) | Runtime wall (ms)* | Runtime CPU (ms) | Runtime peak RSS (MiB) |
|---|---:|---:|---:|---:|---:|---:|
| `l1` | 103.40 | 168.44 | 73.6 | 240 | 240 | 3.77 |
| `l2` | 160.75 | 258.73 | 114.8 | 480 | 480 | 5.61 |
| `df` | 391.02 | 591.83 | 127.2 | 740 | 740 | 15.76 |
| `lz` | 662.79 | 971.65 | 206.9 | 1350 | 1340 | 30.52 |

*Runtime wall time includes process startup and execution. Results depend on machine, input, options and runner; they are not guarantees for phone hardware or Roblox executors. `lz` register mode measured 452,481 output bytes, 661 ms build wall / 953 ms build CPU, 216.6 MiB Node peak RSS, and 1,490 ms runtime wall / CPU with 30.5 MiB runtime peak RSS.

A larger 9,127-byte source with 650 additions produced 609,695 output bytes (609.70 KB) in `lz`/stack and passed Lua 5.4 execution, printing `650`. It exceeds the budget; the warning attributes likely overhead to high-strength preset/nested runtime/serialized VM payload. Compression cannot always reduce high-entropy VM payload enough, so the 475 KB target is monitored and diagnosed but is not an absolute cap for complex inputs. Further compaction is still needed before claiming the maximum is met for every source.

## Known limitations / not verified

- Lua 5.4 was the only native runtime available for this release gate. Native Luau, Lua 5.1, Lua 5.2 and Lua 5.3 were not independently verified here.
- Strict VM vararg expansion remains unsupported and is rejected explicitly.
- These automated integrity/tamper regression probes are not a complete independent red-team crack audit. Do not interpret diversity samples or runtime shields as proof of uncrackability.
- Presets on small sources can generate files below the lower 375 KB target; output is reported, not inflated. Over 475 KB is diagnosed without removing protection.

## Commands

```bash
npm run test:v463
npm test
npm run benchmark:v463 -- --preset=lz --mode=stack --target=lua
```

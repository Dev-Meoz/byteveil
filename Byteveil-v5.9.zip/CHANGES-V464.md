# ByteVeil v4.6.4 — Change Log and Verification Report

## Summary

v4.6.4 is a focused semantic-correctness release. It adds variadic argument handling in VM contexts that can be represented safely, refreshes version metadata, and cleans up release packaging. It does not claim the entire roadmap is complete.

## Changed

- Added/activated multireturn-aware VM instructions: `VARARGS`, `CALLV`, `CALLGV`, and `RETURNV` for stack and register execution.
- Preserved vararg argument count explicitly (`n`) so `nil` values are not lost by using the Lua length operator on sparse tables.
- Validator supports scalar varargs, assignment expansion, call argument expansion and return expansion in the tested forms.
- Unsupported trailing vararg/call table fields and generic-for vararg iterator tails are explicitly rejected; they are not silently accepted or miscompiled.
- Corrected current release metadata, generator-family labels, watermark defaults, and versioned test/benchmark command names to v4.6.4.
- Removed real root `/.env` and `bot/.env` from the release working copy and added `.env.example` / `bot/.env.example` templates plus root `.gitignore` entries.
- Kept preset names (`l1`, `l2`, `df`, `lz`), CLI/public API structure, `bot/`, Macro/LPH independence and nested protection layer policy.

## Verification performed

Command: `npm test` — exit code 0 after removing real `.env` files.

- v4.6.4 semantic runtime matrix: PASS, 26 executions across stack/register on the configured Lua 5.4 runner. Coverage includes closure/upvalue, coroutine, metatable, multiple return, error handling, scalar/spread varargs, assignment expansion, empty varargs and exact vararg count.
- Rejection tests: PASS for unsupported table-tail vararg and generic-for vararg expansion in both modes.
- Polymorphic build sample: PASS, 12 builds of the same source yielded 12 collected topology/representation signatures and preserved output behavior.
- Nested protection: PASS, `balanced` and `full` each retained all 9 stages at strength 10000.
- Nested codec: PASS, LZSS compress/decompress, long-distance references and integrity tamper probe.
- Historical suites: v4.6.2, v4.6.1, v2.5 legacy Luau source-route and v4.3.3 frontend/stack-safety regression all PASS.
- Lua 5.4 output generation and execution benchmark: PASS for the four presets in stack mode and `lz` in register mode.

## Output-size budget results

The target window is 375,000–475,000 bytes (decimal KB). Small inputs and lower presets are not padded to reach the lower limit.

- `examples/input.lua` (85 bytes), stack mode, no wrapper/watermark: `l1` 67,274 B; `l2` 127,028 B; `df` 241,706 B; `lz` 454,850 B.
- Same 85-byte sample in register mode with `lz`: 454,991 B.
- Large 9,125-byte source containing 650 sequential additions, `lz`/stack: 612,461 B. Runtime passed and printed `650`; output exceeded the maximum target. Telemetry reported `high-strength-preset`, `nested-protection-runtime`, and `vm-runtime-and-serialized-payload` as likely contributors. All 9 nested layers remained present; none were dropped to fit the budget.

See `BENCHMARK-V464.json` for CPU, RSS, startup/runtime time and size-budget fields.

## Not verified / remaining work

- Lua 5.1, 5.2, 5.3 and native Luau runtimes were not independently available/configured in this environment; only Lua 5.4 runtime behavior is verified here.
- No independent human crack/devirtualization audit was performed. Build-signature diversity is not proof of crack resistance.
- Source of 9,125 bytes still exceeds the 475 KB output maximum under `lz`, so further serialization/runtime-overhead optimization is still required.
- A native low-end phone benchmark was not performed; measurements above come from this development environment and must not be interpreted as phone performance guarantees.

## Secret-handling note

Real `.env` files are excluded. Copy `.env.example` to `.env` and `bot/.env.example` to `bot/.env` for local configuration. If previously distributed credentials remain active, rotate/revoke them.

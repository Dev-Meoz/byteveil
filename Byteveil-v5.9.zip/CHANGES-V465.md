# ByteVeil v4.6.5 — Unicode and ninth-layer update

## Implemented

- Fixed the strict-VM compatibility gate that rejected strings with non-ASCII UTF-8 bytes as `obfuscated string unsupported` / source-route-only. String payloads now pass through the packed-byte representation instead of being rejected only because they contain non-ASCII characters.
- The active packed-string byte reader accepts byte values 0–255 and materializes them through a computed `string.char` reference. UTF-8 is retained byte-for-byte during serialization and runtime decoding.
- String-obfuscator splitting now uses Unicode code-point boundaries (`Array.from`) so supplementary characters such as emoji are not split into isolated UTF-16 surrogate halves.
- Added Unicode execution regressions for Vietnamese, English, Chinese, Japanese, Korean, Russian, Arabic, Hindi, Amharic/Ethiopic, Swahili, combining marks and emoji. Both stack and register modes are executed using the configured Lua 5.4 runtime; the test also checks UTF-8 byte length.
- Kept the preset names `l1`, `l2`, `df`, and `lz`, and retained nested protection policy. At maximum strength, balanced/full profiles preserve all 9 stages.
- The deepest/ninth nested stage now uses split/interleaved codec 4 plus a separate seed domain and full mixer path. Runtime execution, nested decode, and tamper regressions pass for the tested sample. This is a measured additional analysis cost/diversity measure, not a claim of immunity to tools, AI, or experienced reverse engineers.
- Updated active package/generator/version metadata, test entry points, README and watermark metadata to v4.6.5 while retaining historical regression suites.
- Distribution package includes `.env.example` and `bot/.env.example`; no real `.env`, `.env.local`, or `.env.production` files are included.

## Verification

- `npm test`: PASS (v4.6.5 release gate plus v4.6.2, v4.6.1, v2.5 and v4.3.3 historical regression suites).
- v4.6.5 semantic matrix: PASS, 28 executions on Lua 5.4 including Unicode cases in stack/register modes, closure/upvalue, coroutine, metatable, multiple return and error handling.
- Vararg semantics: PASS for tested scalar, spread call, assignment, return expansion and `select("#", ...)` cases. Table-tail and generic-for iterator vararg expansion remain explicitly unsupported and are rejected by strict validation.
- Build diversity: 12 same-source builds produced 12 distinct collected topology/representation signatures and all executed with expected behavior.
- Nested: balanced/full profiles retain 9 stages at strength 10000; LZSS extended-offset and tamper checks pass.
- Sample preset-size attribution test: l1 65,831 bytes; l2 124,173 bytes; df 237,440 bytes; lz 444,980 bytes. These are test fixture outputs; small sources/lower presets are not padded just to reach the 375 KB lower target.
- Detailed one-run benchmark: `examples/input.lua` (85 bytes), Lua 5.4, `lz`, stack, strength 10000 produced 454,882 bytes (454.88 KB) with 9 nested layers. Build wall: 660.45 ms; process CPU: 965.60 ms; Node peak RSS: 223,023,104 bytes. Runtime wall: 1,330 ms; CPU: 1,320 ms; peak RSS: 32,006,144 bytes; status PASS; stdout `5`.
- Full `npm test` passes in this environment. Native Luau and Lua 5.1/5.2/5.3 were not installed/configured for independent runtime verification and remain unverified by this release.

## Known limitations

- This release verifies Unicode text represented as UTF-8 literals. Lua byte escapes such as `\\255` can have different raw-byte semantics from a Unicode character with the same code point; binary-string escape semantics were not claimed as fully covered by this Unicode text suite.
- Vararg expansion in table-constructor tails and generic-for iterators remains unsupported. The VM deliberately rejects these forms rather than silently emitting output with changed semantics.
- The 375–475 KB range is a target budget, not a guarantee for every input. Large or high-entropy sources can exceed 475 KB. The engine reports the size result; it does not drop nested stages or silently lower the selected preset to fit.
- The ninth-layer codec/seed separation raises structural diversity in the tested build, but is not proof against devirtualization or reverse engineering. No “uncrackable” or “runtime-only crack in 1–10 seconds” guarantee is made.
- No independent human reverse-engineering audit was performed. Crack-resistance claims beyond the automated checks above remain unverified.

## Commands

```bash
npm test
npm run test:v465
npm run benchmark:v465 -- --preset=lz --mode=stack --target=lua --strength=10000
```

# ByteVeil v4.6.6 — Macro / LPH Engine Hotfix

## What changed

- Replaced metadata-only Macro/LPH handling with independent execution paths in `src/macros/` and `src/lph/`. `src/transforms/index.js` now invokes each engine before preset-wide transforms; `src/protection/byteveil_micro.js` remains a metadata/helper layer rather than owning either engine.
- Comment directives bind to the next parsed statement using source line/column markers. The parser now records those positions as non-enumerable AST fields; those markers are preserved when property/function statements are normalized for the VM.
- Macro directive handlers can apply scoped string splitting, CFF/CFG/CGI transformations, function-shape transforms, property-key splitting, safe local-function inlining, block wrapping, statement omission, or the full nested-protection profile. Directive salt also contributes to the build seed, and `byteveil-compress` requests `nestedProfile: "full"`.
- LPH comment aliases and call-style wrappers are handled separately. Supported one-argument wrappers are lowered into their expression instead of surviving as unresolved runtime globals. Wrong-arity wrappers fail with an explicit error; `LPH_LINE()` is lowered to the recorded source line.
- VM/MFG directives are reported as active because the entire chunk is already compiled by the custom VM. Effective counts and warnings now distinguish active work from unsupported, suppressed, or limited directives.
- Added `test-v467-macros-lph.js` to the release gate. It tests scanner independence, stack/register runtime semantics, scoped effects, call-wrapper lowering, nested profile selection and truthful limitation reporting.

## Intentional limitations

- `byteveil-super` is **not counted as effective**: fusing super-operators is still suppressed in the v4.6 graph-micro-op format because it can bypass the current routing architecture.
- `LPH_NO_VIRTUALIZE` preserves the wrapped expression, but selective non-VM islands are not supported by the current whole-chunk VM backend. The LPH plan emits `limited-whole-chunk-vm` rather than claiming that exclusion occurred.
- `byteveil-inline` is conservative: it only removes safe, single-return local functions when call arguments are literals and lexical-reference checks pass. It skips unsafe candidates rather than changing program behavior.
- `byteveil-crash` does not insert an unconditional crashing instruction. It applies the supported region transformations without deliberately breaking runtime semantics.
- String splitting and block-based CFF/function-shape transforms increase source/AST complexity; they are not a guarantee against a skilled runtime debugger or devirtualizer.

## Verification

- `node tools/run-release-tests.js`: PASS — all 6 suites (`test-v467-macros-lph.js`, `test-v466.js`, `test-v462.js`, `test-v461.js`, `test-v25.js`, `test-v433.js`).
- `node test-v467-macros-lph.js`: PASS with Lua 5.4, including syntax checks and expected-output runtime checks in stack/register modes.
- `node test-v466.js`, `test-v462.js`, `test-v461.js`, `test-v25.js`, and `test-v433.js`: PASS as part of the combined gate.
- `test-v431.js` was not used as a passing gate: it contains a historical assertion that the active VM should identify as `4.5.2`, which conflicts with the current v4.6.6 engine version. This assertion is stale and unrelated to the Macro/LPH changes.
- Lua 5.4 is the runtime independently tested here. Native Luau and Lua 5.1/5.2/5.3 have not been independently verified in this environment.

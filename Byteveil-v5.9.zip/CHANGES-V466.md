# ByteVeil v4.6.6 — Unicode Identifier Lexer Fix

## Fixed
- Lexer recognizes Unicode identifier start/continuation code points using Unicode ID_Start/ID_Continue properties. This fixes `ByteVeil v4.6.5 lexer error: Unexpected character ạ` when `ạ` is used as a valid identifier.
- Identifier parsing flows through the normal lexer → parser → AST/IR → custom VM pipeline; regression tests assert `backend=custom-vm` and `fallback=false`, rather than relying on source-compatibility fallback.
- Coverage includes Vietnamese diacritics, Chinese, Japanese, Korean, Cyrillic, Arabic, Hindi, Amharic/Ethiopic, combining marks, Unicode function names/parameters, and Unicode table fields.
- Retains v4.6.5 Unicode string handling, byte-safe payload work, ninth nested-layer codec domain, nested layer policy, preset names, CLI/API paths, and existing project structure.

## Verification
- `node test-v466.js`: PASS on Lua 5.4 (includes semantic, vararg, Unicode string/identifier, nested-layer, and polymorphism checks).
- `node test-v462.js`: PASS.
- The combined `npm test` run passed `test-v466.js` and `test-v462.js`, then exceeded the execution window while running `test-v461.js`; therefore the entire historical suite is not claimed as PASS in this report.
- Lua 5.1/5.2/5.3 and native Luau were not independently verified in this environment.

## Known limits
- This fix covers Unicode identifiers accepted by Unicode identifier rules; emoji are not valid Lua identifiers.
- Lua byte-string edge cases and unsupported strict-VM syntax remain governed by their dedicated regression/validator paths.
- No claim is made that reverse engineering is impossible; no independent crack audit is included in this release.


# ByteVeil v4.6.7 — Deepest Nested-Layer Diversification

## Changed
- Added codec 6 exclusively for the ninth/deepest nested layer at maximum nested strength; v4.6.5/v4.6.6 continue to use their old layer-9 codec path.
- The new deepest codec applies a build-specific byte substitution permutation, two-lane interleaving, and a feedback recurrence. The build deterministically selects one of three distinct recurrence shapes.
- The deepest wrapper no longer emits the generic XOR-32 / multiply-32 / state-mixer helper trio that made the previous layer straightforward to classify. The other nested stages and their codecs remain in place.
- Added dedicated tamper-hash handling for the new deepest codec, while retaining per-layer payload integrity checks.
- Bumped the active VM, Macro/LPH, personality, watermark, package, CLI/API metadata and release test identity to v4.6.7. Existing preset names and call surfaces remain unchanged.

## Verification
- `node test-v467.js`: PASS on Lua 5.4; 50 semantic/runtime executions across stack and register modes, Unicode, vararg, closure/upvalue, coroutine, metatable, error handling, nested layer count, compression, integrity tampering and output-budget telemetry.
- Three direct deepest-layer structural variants: syntax and runtime PASS; wrappers are distinct and do not emit the prior recognizable two-argument arithmetic helper pattern.
- High-strength stack/register examples passed runtime at approximately 457 KB and 456 KB, below the 475 KB maximum. This is sample evidence only; arbitrary sources may exceed the maximum.
- `node test-v467-macros-lph.js`: PASS.
- `test-v467.js` contains a focused v4.6.6 backward-compatibility runtime probe; the separately invoked `node test-v466.js` historical compatibility suite also passed, but is not duplicated in the default release gate because it repeats the same full semantic matrix.
- `node test-v462.js`, `node test-v461.js`, `node test-v25.js`, and `node test-v433.js`: retained compatibility/regression suites passed individually in this session. To keep `npm test` repeatable in this environment, the default gate runs Macro/LPH, the full v4.6.7 suite, and the lightweight v4.3.3 regression; heavyweight legacy suites remain standalone.
- Luau native runtime was not installed/configured; Lua 5.1/5.2/5.3 were not independently verified. No independent human crack/devirtualization audit was conducted; there is no claim that runtime analysis is the only way to reverse engineer the output.

## Known Limits
- Codec 6 changes representation and decoder shape, but the table and recurrence are present in the runtime wrapper and can still be analyzed. This is structural obfuscation, not cryptographic secrecy.
- The 475 KB target remains an output-size goal/diagnostic, not a guarantee for every source. No protection stage is silently removed to meet it.

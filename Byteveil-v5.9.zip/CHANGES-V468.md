# ByteVeil v4.6.8 — Integrity & Dispatch Hardening

## CHANGED

- Fixed the planner/runtime mismatch where v4.6 personalities exposed eight possible dispatch styles but `buildV452GeneratedSource` selected only `dispatchStyle % 4`. Version 4.6.8 uses all eight actual semantic dispatch code paths: flat chain, split chain, repeat-local, loop-chain, handler-table, residue buckets, balanced tree, and affine-key dispatch.
- Exported active dispatch-topology/checkpoint/provenance metadata through the public pipeline result so tests inspect the emitted engine route rather than inferred planner intent.
- Added a runtime API provenance check for standard PUC Lua 5.1–5.4 when `debug.getinfo` is available. Known core functions are checked once for C-function provenance at startup, and `debug.getinfo`, `debug.gethook`, and `debug.sethook` references are checked against startup snapshots. This avoids repeating expensive reflection calls at every checkpoint.
- Added integrity checkpoints after each eight executed VM instructions and a final check after VM execution. This catches the tested Lua-level API wrapper cases; it is not a guarantee against native hooks, modified debug libraries, or runtime extraction.
- Preserved nine nested layers; the v4.6.8 deepest wrapper has a separate layer-domain seed while retaining codec family 6. Public API and preset names remain unchanged.

## VERIFIED

- `test-v468.js`: semantic/runtime regression matrix, nested wrapper/deep codec checks, output budget telemetry, and Lua runtime behavior.
- `test-v468-macros-lph.js`: Macro/LPH regression tests. The active suite separately executes direct nine-layer compatibility probes for nested versions 4.6.7 and 4.6.6.
- Focused tests added for all eight generated dispatch styles plus pre-start and in-execution Lua-level `string.byte` wrappers.
- Compatibility suites `test-v467.js`, `test-v466.js`, and `test-v433.js` are run separately from the active v4.6.8 release gate.

## BENCHMARK SNAPSHOT (same fixture/options, one run each)

| Metric | v4.6.7 | v4.6.8 |
|---|---:|---:|
| Output bytes | 455,234 | 465,297 |
| Nested layers | 9 | 9 |
| Generation wall time | 989.53 ms | 890.64 ms |
| Runtime wall time | 1,860 ms | 1,790 ms |
| Runtime peak RSS | 32,006,144 B | 32,038,912 B |

Both outputs ran successfully and are below the 475,000-byte maximum. This is one run per version, not a statistically controlled benchmark; timing and Node RSS can vary between runs. Full values are in `BENCHMARK-V468.json`.

## LIMITATIONS

- Not tested under native Roblox Luau in this environment unless a compatible runtime is available. Provenance checks intentionally skip when PUC Lua's `debug.getinfo` behavior is unavailable.
- Runtime instrumentation can still extract nested chunks. This release changes actual dispatch structures and integrity checks but does not establish a universal “runtime-only crack” guarantee.
- Output size is measured on tested fixtures; arbitrary input is not guaranteed to fit the 375–475 KB target. The implementation does not truncate output or silently drop protection to meet a size target.

## RUN

```bash
npm install
npm run test:v468
npm run benchmark:v468
```

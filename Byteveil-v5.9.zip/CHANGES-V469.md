# ByteVeil v4.6.9 — Discord Prefix Console & Reply UI

## Changed

- Switched the Discord runtime from slash interactions to `messageCreate` prefix commands: `.help`, `.rule`, `.obf l1`, `.obf l2`, `.obf df`, and `.obf lz`.
- Enabled `GuildMessages` and `MessageContent` Gateway intents in the bot client. `Message Content Intent` must also be enabled in the Discord Developer Portal.
- Rebuilt Discord replies with a consistent ByteVeil embed system for help, rules, processing state, success metadata, usage errors, and failures. Obfuscation progress is edited into the final result instead of sending unstyled text.
- `.obf` accepts inline Lua/Luau source, one `.lua` / `.luau` / `.txt` attachment, or an HTTP(S) URL. It calls the existing `runEngine()`/ByteVeil pipeline.
- The bot only requires `DISCORD_TOKEN` at runtime. `DISCORD_CLIENT_ID` and optional `DISCORD_GUILD_ID` are only needed for one-time legacy slash-command cleanup.
- Replaced the old slash-command deploy helper with a selective cleanup helper that deletes only legacy `/help`, `/rule`, and `/obf` commands, preserving unrelated application commands.
- Updated package metadata to v4.6.9. The obfuscation core itself remains the v4.6.8 engine; this hotfix changes the Discord integration/UI, not the VM architecture or generated watermark.

## Verification

- `test-v469-bot.js`: parser, preset validation, code-fence handling, embed rendering and legacy command list smoke tests.
- Default release gate runs the bot/UI smoke test, Macro/LPH regression, and v4.3.3 compatibility suite. The full `node test-v468.js` VM/runtime suite was also run independently and passed during this build; it remains available via `npm run test:v468` because repeating it within a constrained aggregate run timed out.

## Setup note

Run `npm run bot:clear-slash` once after filling in `DISCORD_CLIENT_ID` (and `DISCORD_GUILD_ID` if applicable) if the old slash commands should disappear. This deletes only the three ByteVeil legacy command names.

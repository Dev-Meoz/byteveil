# ByteVeil v4.7.0 — Slash Command Restoration & Layer 9 Hardening

## Discord bot

- Restored the slash-command interface: `/help`, `/rule`, `/obf`.
- `/obf` retains the established options `presets` (`l1`, `l2`, `df`, `lz`), `attach` (`code`, `file`, `url`), optional `input`, and optional `upload`.
- `npm start` now resets stale ByteVeil command definitions first, preserves unrelated application commands, deploys the current slash command set, and only then starts the client. Deployment failure prevents login, avoiding a bot that is online with missing commands.
- The deploy helper can also run with `--reset-only`. `DISCORD_CLIENT_ID` is required; `DISCORD_GUILD_ID` is optional.
- Rebuilt help, rules, processing, success, and error replies as consistent premium embeds. The bot reports a build as successful only when the engine returns non-empty output.
- Config supports `bot/.env` and a root `.env` fallback, with explicit placeholder/configuration checks.

## Nested protection layer 9

- Keeps the nine-layer nested default and existing preset/API surface.
- v4.7.0 assigns codec `7` only to layer 9. That codec distributes transformed bytes across three base85 lanes, uses a build-derived inverse substitution table, and updates its recurrence using both prior state and ciphertext-derived feedback.
- Four decoder recurrence shapes are available. Regression coverage verifies the round-trip, syntax, and runtime output using native Lua 5.4.
- The runtime path was tested against a real generated pipeline output; the test fixture output was 465,330 bytes (375–475 KB target), with 9 nested layers and stdout `5`.

## Verified suites

- `test-v470-bot.js`: slash command schema, embed replies, actual `/obf` engine invocation, and reset/deploy behavior while preserving unrelated commands.
- `test-v470-macros-lph.js`: Macro/LPH regression suite.
- `test-v433.js`: compatibility regression.
- `test-v470.js`: ninth-layer codec, full 9-layer nested wrapper, current engine metadata, and 10 semantic runtime executions across stack/register modes.

## Known limits

- Discord live login/deploy was not run because this build environment has no real bot credentials and `discord.js` is not installed here; the REST/deploy sequence is tested with a deterministic mock. The package declares required dependencies; install with `npm install` before running it.
- Tested the obfuscation output with native Lua 5.4. Roblox Luau-native runtime was not available for this test run.
- Three-lane feedback increases structural diversity, but runtime-assisted extraction remains possible; this is not a guarantee against all reverse-engineering.

# ByteVeil v4.7.1 — Loader Integrity & VM Decoder Distribution

## Changed

- Restored the v4.7.0 slash-command workflow: `/help`, `/rule`, `/obf` with the `l1`, `l2`, `df`, and `lz` presets.
- Startup order remains reset stale ByteVeil slash definitions → deploy current definitions → connect the bot. The reset path strips read-only Discord command fields before REST bulk overwrite and preserves unrelated application commands.
- Kept all nine nested protection layers. Layer 9 remains codec 7 (three interleaved lanes, build-derived substitution, and ciphertext-coupled feedback) and now uses a v4.7.1-specific layer domain; it is not claimed to be a new cryptographic primitive.
- Added PUC Lua 5.x loader provenance checks for `load` and `loadstring` at the outer nested wrapper and in VM integrity checks, plus identity checks against the captured loader references during runtime checkpoints.
- Distributed instruction normalization across two specialized parity-family decoders before the semantic boundary canonicalizes operands. This reduces the 12-way branch concentration but does not remove canonical operand semantics.
- Added active v4.7.1 test and benchmark scripts, and surfaced the decoder style in `vmMeta`.

## Verification

- Release gate: 4/4 suites PASS (`test-v471-bot.js`, `test-v471-macros-lph.js`, `test-v433.js`, `test-v471.js`).
- Regression explicitly attempts pre-installed `load` and `loadstring` wrappers; both are rejected by the Lua 5.4 runner with the loader-provenance error.
- Non-PUC fallback branch is simulated by changing `_VERSION` to `Luau`; it continues to execute the known sample. This is a guard-branch test, **not** a native Luau compatibility result.
- Canonical benchmark: `examples/input.lua`, preset `lz`, stack mode, seed `0x463B0001`, strength `10000`; 9 layers, codecs `[4,5,2,1,0,5,4,1,7]`, output 471,940 bytes, runtime output `5`, Lua 5.4 status PASS. Output is 3,060 bytes below 475,000 bytes for this fixture.
- Macro/LPH tests and legacy compatibility test v4.3.3 pass.

## Limits / not verified

- The build environment has only the bundled Lua 5.4 runner. Lua 5.1, Lua 5.3 and native Roblox Luau were not available for runtime validation.
- `_VERSION` fallback simulation is not equivalent to running the Luau VM. On environments without trustworthy provenance introspection, identity checks cannot guarantee detection of a transparent wrapper installed before startup.
- Runtime instrumentation at the host/runtime boundary may still capture source chunks; this release does not claim runtime extraction is impossible.
- Output size depends on source, preset, mode, seed and transforms. The 475,000-byte result is verified for the named canonical benchmark, not guaranteed for every possible input.

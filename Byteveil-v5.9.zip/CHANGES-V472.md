# ByteVeil v4.7.2 — Deepest-layer codec update

## Scope

This release updates the ninth nested source-protection layer. It keeps the existing Lua/Luau execution runtime, public presets (`l1`, `l2`, `df`, `lz`), slash-command surface, and nine-layer default at maximum strength. It does not replace the target runtime with a new VM executable.

## What changed

- Layer 9 uses codec 8 and a version-specific seed domain.
- Four independent lane states and feedback recurrences drive the byte transform.
- The encoded result is serialized as one ordered ciphertext stream instead of four visibly separated lane strings. Per-lane state remains independent during transformation/decoding.
- The inverse substitution table is embedded as a compact Base85 representation rather than a long numeric source literal.
- The emitted decoder uses standard Lua string/table/math facilities and does not require `buffer` or `bit32` for codec 8.
- Fixed the v4.7.2 generator selection so the active pipeline routes into the packed-bytecode VMA/VMB backend rather than falling through to the legacy generator branch.
- Updated package/bot version metadata, the release gate, and slash command/Macro/LPH regression tests.

## How the sample files informed the work

The submitted Luraph-protected files were statically inspected, not executed. They show recurring patterns including a large opaque payload, numeric-key tables, helper dispatch, and use of runtime primitives such as `buffer`, `bit32`, and coroutine functions. These observations informed the decision to test layer-9 payload layout and state/dispatch separation. The implementation is an independent ByteVeil codec; it does not copy Luraph source or assume that a visible table/handler count proves the full opcode surface.

## Verification performed

- `node test-v472-bot.js`: PASS (mocked Discord REST/deploy and real engine integration smoke test).
- `node test-v472-macros-lph.js`: PASS.
- `node test-v433.js`: PASS.
- `node test-v472.js`: PASS; 4 semantic mode runs, all 4 codec recurrence variants, 9 nested layers, loader hook probes, runtime fallback-branch simulation, and full fixture pipeline.
- Benchmark fixture `examples/input.lua`, preset `lz`, strength `10000`, seed `1194000385`:
  - `stack`: 460,053 bytes, 9 layers, codec 8 at layer 9, runtime output `5`.
  - `register`: 459,280 bytes, 9 layers, codec 8 at layer 9, runtime output `5`.
- Release gate: all 4 suites passed on the build tree and then passed again by running `npm test` from the extracted release archive.

## Known limits

- Tested runtime: native Lua 5.4 only. The `_VERSION = "Luau"` branch simulation is not native Roblox Luau validation. Native Luau and Lua 5.1/5.3/5.4 matrix coverage is still required for a broad compatibility claim.
- This is source obfuscation, not cryptographic secrecy. Runtime instrumentation can still observe code at loader boundaries; this codec does not make extraction impossible.
- The 375–475 KB budget has been verified for the supplied benchmark fixture/seed in both stack and register modes, not for every possible source/preset/seed combination.
- The samples were analyzed statically and were not run. No claim is made that ByteVeil is as hard to reverse engineer as Luraph based on these observations alone.

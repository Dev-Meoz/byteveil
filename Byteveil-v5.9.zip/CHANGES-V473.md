# ByteVeil v4.7.3 — Single-Layer Packed-Bytecode VM

> This build supersedes the earlier experimental v4.7.3 artifact that still emitted nine nested source wrappers. The version label stays v4.7.3; the standard output architecture is now one VM layer.

## Why

The repeated nested-source pipeline inflated intermediate buffers and output size, increased build CPU/RSS, and forced the runtime to decode and compile many wrapper chunks. The goal changed to preserve the custom VM protections in one layer while lowering resource use, so v4.7.3 no longer invokes the nested wrapper generator on the standard VM path.

## Changes

- Standard presets (`l1`, `l2`, `df`, `lz`) emit one packed-bytecode custom VM program with build-specific ISA/constant remapping, region dispatch, VMA/VMB + semantic micro-op execution, and in-VM integrity checks.
- The active v4.7.3 path does not call `wrapSource`, create nested source chunks, or call `load`/`loadstring` to reveal subsequent wrapper layers.
- Metadata reports `singleLayerEngine: true`, `protectionLayers: 1`, `nestedObfuscation: false`, and `nestedObfuscationLayers: 0` for the standard VM route.
- Nested-protection helper loading is now lazy; the standard v4.7.3 engine does not require that module at generation startup. Historical versions and explicit compatibility fallback can still use the legacy helper.
- The output maximum remains 475,000 bytes for the benchmark fixture; the old 375,000-byte minimum is disabled in single-layer mode. Output is not padded.
- `byteveil-compress` remains accepted but maps to a single-layer build-domain profile; it does not claim to compress or create nested source stages.
- Lua/Luau target selection, stack/register modes, and the existing slash-command surface are retained. No alternate interpreter/runtime is substituted.

## Benchmark (three-run medians)

Same 85-byte `examples/input.lua`, preset `lz`, stack mode, target Lua 5.4, seed `1194000385`, strength `10000`, wrapper/watermark disabled:

| Metric | v4.7.2 (9 nested layers) | v4.7.3 (single layer) | Reduction |
|---|---:|---:|---:|
| Output bytes | 460,053 | 46,529 | 89.89% |
| Generation wall time | 1,764.28 ms | 326.21 ms | 81.51% |
| Generation CPU time | 2,501.61 ms | 382.04 ms | 84.73% |
| Node peak RSS | 229,150,720 B | 43,581,440 B | 80.98% |
| Lua runtime wall time | 3,120 ms | 720 ms | 76.92% |
| Lua runtime CPU time | 3,100 ms | 700 ms | 77.42% |
| Lua runtime peak RSS | 21,270,528 B | 1,441,792 B | 93.22% |

Both versions returned `5` in all three measured stack-mode runs. Detailed records are in `BENCHMARK-V473-COMPARE.json` and `.md`. These values apply to this fixture and included Lua 5.4 runner, not every source or machine.

## Verification

- `npm test`: PASS — slash command reset/deploy integration, Macro/LPH, v4.3.3 compatibility, and single-layer VM regression.
- JavaScript syntax scan: PASS.
- VM semantics: stack and register closure/upvalue and coroutine examples pass.
- All four standard presets build as one layer and pass Lua 5.4 syntax/runtime tests.
- Default API wrapper does not reintroduce a nested source-loader chain.
- Pre-installed `load` and `loadstring` wrapper probes are handled by the PUC Lua 5.4 integrity guard.
- Luau-target output generation sanity check: PASS; native Roblox Luau execution is unavailable in this environment.
- Release ZIP is checked from the extracted directory; `.env` secrets and `node_modules` are excluded.

## Limits

- This is an independent ByteVeil VM, not a Luraph clone. The submitted samples were inspected statically and were not executed or copied.
- No claim of parity with Luraph v15.1 is made; a single-layer VM can still be instrumented and reverse-engineered.
- Native Lua 5.1/5.3 and Roblox Luau still require their own test runs. Explicit `compatibilityRoute: true` remains a legacy source fallback and is outside the single-layer VM guarantee.

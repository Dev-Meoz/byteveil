# ByteVeil v4.7.4 — Nested Packed-Bytecode VM

## Scope

This release restores the nine-layer heterogeneous source wrapper around the v4.7.x packed-bytecode VM. The v4.7.3 single-layer path remains available as a historical compatibility implementation, but v4.7.4 is the active default. Existing public presets (`l1`, `l2`, `df`, `lz`), Lua/Luau target selection, Discord commands, Macro and LPH APIs are retained.

## Engine changes

- Active engine version advances to `4.7.4`; version labels, runtime diagnostics, watermarks, package metadata, and bot metadata are aligned.
- All supported presets route through the packed-bytecode VM with graph/micro-op architecture, region-specific serialization and per-build VM personality.
- Nine heterogeneous source layers are re-enabled around the packed VM. The deepest layer uses codec 8 with a v4.7.4-specific seed domain (`0x474DEA11`) distinct from v4.7.2 and v4.7.3. The v4.7.4 layer schedule uses a full transform in the eight inner layers, a lighter outer bootstrap, and a compact full codec at layer index 7; this keeps the fixed release fixture under 475,000 bytes without removing any layer.
- Loader provenance checks, runtime API identity checks, compression, integrity checks and intermediate-size guard remain enabled for v4.7.4. The intermediate-size guard now covers both the v4.7.3 historical mode and the v4.7.4 active nested mode.
- The old v4.7.3 single-layer mode remains guarded by an explicit version check; it is not the active v4.7.4 path.

## Reference-sample use

The supplied sample repositories contain obfuscated outputs, not the original source modules for the named commercial engines. This release uses independent ByteVeil implementations and references observed architectural patterns (opaque VM payloads, distributed numeric/constant data, runtime dispatch, and layered loader structure); it does not claim to reproduce or merge proprietary engine source.

## Verification

Release validation is run with `npm test`, including native Lua 5.4 syntax/runtime checks, closure/upvalue, coroutine, vararg and multi-return semantic cases, all public presets, codec-8 variant coverage, loader-hook probes, Macro/LPH and mocked Discord command deployment/integration tests. The release gate also checks the fixture output against the 475,000-byte output ceiling.

Native Roblox Luau execution is not available in this environment; generated Luau is syntax-shaped output only unless separately tested in a native Luau runtime. Passing the release suite does not establish parity with Luraph/MoonSec or make client-side code impossible to recover.

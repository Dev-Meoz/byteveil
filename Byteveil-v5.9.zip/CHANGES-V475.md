# ByteVeil v4.7.5 — Binary-region VM hardening

## Root cause fixed

The v4.7.4 crack log showed nine Lua source chunks observable at `load` boundaries after one provenance guard was bypassed. The issue was architectural: each nested wrapper reconstructed source and forwarded it to a source loader. Adding a further guard or onion layer would not remove those observable boundaries.

## Changes

- Active v4.7.5 generation path bypasses nested source wrapping; metadata reports zero nested source layers and zero source-loader stages/calls.
- Adds eight sequential reversible byte transformations to serialized graph-VM regions, using region/build-derived material and corresponding inverse transforms at runtime.
- Adds an optional Luau-native binary-region cache using captured `buffer.create`, `buffer.writeu8`, and `buffer.readu8` API references with zero-based offsets; non-Luau runtime falls back to byte arrays.
- Preserves existing stack/register modes, presets (`l1`, `l2`, `df`, `lz`), Discord slash-command integration, Macro/LPH interfaces, and legacy frontend/stack-safety regression coverage.
- The `byteveil-compress` directive becomes a binary-region build profile on this path; it does not pretend that nested source compression was applied.
- Adds loader-hook crack tests and payload-transform round-trip tests to release gating. The release gate also reproduces the print behavior shown in the v4.7.4 crack log, verifies that exact phrase is not emitted as a plaintext source literal, and confirms no source-loader calls. This is a behavior-only reproduction; it is not the same binary/source artifact that red team tested.

## Verification

Run `npm test`. The release gate includes bot deploy mocks, Macro/LPH, legacy frontend/stack-safety, 64 transform round-trips, stack/register semantic tests (closures/upvalues, coroutines, multiple returns), all four presets, an output-size-bounded fixture, a Lua-side buffer shim, and `load`/`loadstring` hooks. Detailed metrics are in `BENCHMARK-V475.md`.

## Limits

The environment contains a Lua 5.4 runner but no native Roblox Luau runtime. The buffer branch has been checked with a compatible Lua-side shim; it still needs verification in the real Roblox Luau host. The crack test establishes that the default protected output does not use source-loader stages and closes the specific v4.7.4 extraction route. It does not establish parity with Luraph/MoonSec or make reverse engineering impossible; dynamic analysis of VM state and decoded region contents remains possible.

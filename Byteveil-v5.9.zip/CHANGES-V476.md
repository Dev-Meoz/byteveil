# ByteVeil v4.7.6 — Runtime-coupled interleaved VM

## Root cause

The v4.7.5 protection path removed nested source-loader stages, but its auxiliary decoy model was still easier to classify as a separate machine because its generated state machine was mostly independent of the opcode currently executed by the real VM. Merely increasing the handler count or adding another opaque loop would not make that state materially more coupled to program execution.

## Changes

- Replaced the standalone decoy wheel on the v4.7.6 path with a build-specific interleaved secondary register VM.
- Added a **runtime opcode-coupled dispatch**: each real VM instruction selects a mapped secondary handler using the real instruction's logical opcode and derives its input registers/immediate from the current instruction operands.
- Made the encoded secondary stream more program-specific: 3 of every 4 generated rows derive their operation selection and masked fields from the real bytecode opcode/operand trace; the remaining rows use build-seeded transitions. Logical rows are shuffled into a build-specific physical order and fields are masked with derived material.
- The live secondary state advances once per actual VM instruction and is mixed into the primary VM's guard/fabric state before the next dispatch. High-strength builds also execute two encoded-stream steps per actual instruction; lower-strength builds execute one, in addition to the live-opcode-coupled step.
- Retained the v4.7.5 binary-region path, eight reversible byte transforms, per-region materialization, optional Luau `buffer` cache path, and Lua byte-array fallback. The standard path still emits no nested source-loader stages.
- Fixed parenthesized-call result adjustment found by the new stress matrix. The parser now preserves the single-result behavior of `(call())`, and both stack/register compilers avoid expanding it as a multi-return tail.
- Updated benchmark metadata to report live opcode coupling, trace/operand correlation, instruction/handler counts, and the build-specific fingerprint.

## Verification

- `npm test`: PASS (bot deploy mock, Macro/LPH regression, legacy frontend/stack-safety, and v4.7.6 VM suite).
- Release semantic regression set: **20 mode runs PASS** (10 programs × stack/register). Cases cover arithmetic, boolean/branch behavior, table mutation, varargs, recursion, closure/upvalues, coroutine yield/resume, concatenation, parenthesized single-result calls, and ordinary multi-return assignment.
- Preset release suite: `l1`, `l2`, `df`, and `lz` PASS.
- Eight-lane transport transform: 64 round-trip property cases PASS.
- Loader instrumentation probe: standard `load` and `loadstring` hooks observed zero calls for generated protected output; outputs retained expected behavior.
- JavaScript syntax audit for `src`, `bot/src`, and `tools`: PASS.
- Maximum-strength benchmark fixture (`examples/input.lua`, 85-byte source, seed `0x476B0001`): stack output 50,341 bytes; register output 50,003 bytes; both Lua 5.4 runs print `5` and remain under the 475,000-byte target maximum.

## Limits

- The auxiliary VM is now stateful and coupled to the live opcode/operand path, but it is **not a second semantically equivalent execution engine for the original program**. The protection structure is harder to separate by simply ignoring an isolated pre/post decoy wheel; this does not establish parity with Luraph v15.x or make the client-side payload impossible to reverse-engineer.
- Runtime and stress evidence is from Lua 5.4. The Luau `buffer` branch was checked with a Lua-side API shim, not a native Roblox Luau runtime.
- The protected program and VM state necessarily exist in a process at runtime. Active instrumentation and post-decode state observation remain valid next crack targets.

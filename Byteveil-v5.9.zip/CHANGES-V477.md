# ByteVeil v4.7.7 — Changes

## Added

- Function-level policy selection with three explicit modes: `balanced` (VM-A/register), `hardened` (VM-B/stack), and `compiler-transformed` (source transformation without VM virtualization).
- Separate compilation providers for the supported register and stack backend representations, plus a lexical bridge for supported simple top-level global functions.
- Build metadata reporting requested/effective function policies, routed provider backend, explicit fallback reasons, source-loader stage counts, and output budget.
- Fail-closed policy behavior for unknown policies, missing targets, unsupported cross-backend closure captures and unsupported local/nested targets. An explicit `allowPolicyFallback: true` is required to keep an unsupported request in its containing chunk.
- A repeatable benchmark for all four public presets and five backend/policy profiles per preset (20 combinations).
- Regression coverage for compiler-transformed functions, unsupported local policy targets, explicit fallback reporting, both hybrid directions and wrapped hybrid output.
- Correct v4.7.7 reporting across IR/protection metadata, statistics markers, compatibility-route metadata, output-budget description and bot package documentation.

## Fixed during validation

- VM-B stack `CALLG` / `CALLGM` handling advanced the stack pointer incorrectly for multiple calls in a single expression, overwriting an earlier result. Stack result placement now reserves a fresh stack slot for each returned value.
- The hybrid wrapper could concatenate a generated provider's trailing `end` with the following wrapper `end`, producing `endend`. Explicit statement separators now keep wrapped hybrid output syntactically valid.
- Added a specific regression for the reverse hybrid route (`VM-B` root with a `VM-A` function provider), which caught the stack-result bug before release.

## Preserved

- Public presets: `l1`, `l2`, `df`, `lz`.
- Existing Discord bot entry points and the Macro/LPH APIs.
- The binary-region VM path and the v4.7.6 interleaved secondary-state mechanism.
- The 475,000-byte hard output ceiling; no VM policy is silently downgraded to satisfy it.

## Limits

- Cross-backend closure/upvalue sharing is not implemented. Unsupported explicit routes fail closed unless the caller opts into a recorded fallback.
- The compiler-transformed policy is explicitly not virtualized.
- Lua 5.4 is the only runtime executed for this release in the current environment. Native Roblox Luau, Lua 5.1 and Lua 5.3 require separate validation.
- No reverse-engineering parity claim is made relative to Luraph or other commercial obfuscators.

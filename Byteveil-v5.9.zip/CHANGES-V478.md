# ByteVeil v4.7.8 — Change log and root-cause fix

## Root cause in v4.7.7

The secondary shadow lane was more decorative than semantically integrated:

- `mapTraceOp()` mapped op names into a small fixed ISA through regular-expression guesses, sometimes mapping unrelated source operations to `ADD`, `POP`, `GETI` or other unrelated handlers.
- A static `programOps` sequence, with derived operands, was embedded in the secondary stream. This tied decoy shape to a compile-time trace rather than the current runtime instruction flow.
- Handler bodies used hash-like state transitions that did not mean the same thing as the main VM's instruction semantics. Increasing row count could make the file larger without making the two lanes harder to distinguish.

## Fixes in v4.7.8

- Added `buildSemanticShadowVM()` with a unique randomized secondary ID for every active-build opcode; actual runtime logical opcodes select the mapped shadow handler exactly.
- Removed static source opcode and operand trace derivation from this path. Decoy rows are chosen from the build's own active ISA, then field-masked and placed in a seed-dependent physical order.
- Generated operation-correlated abstract state handlers for the active opcode set; shadow state influences the VM guard/fabric.
- Post-build crack testing showed that the original transition invariant could be bypassed by changing `tick`, `acc`, and the visible commit expression. Added a separate per-instruction authenticator: each live/decoy handler folds its encoded opcode, operand fields, runtime PC, and transition input into a build-specific state slot; an independent verifier re-decodes the selected binary rows and recomputes the expected authentication transition from the saved pre-step state. The verifier returns only a pass/fail result, not the expected authentication value at the call site. Regression tests now reject no-op, tick-only spoofing, and the previously successful tick+accumulator+commit spoof when it does not reproduce the authenticator.
- Explicitly report `semantic-projection-isa-v478`, zero source-trace opcodes, and `shadowStaticSourceTrace: false` in metadata.
- Runtime detection now confirms `_VERSION` is exactly `Lua 5.4` for v4.7.8 test and benchmark execution; LuaTeX/LuaMetaTeX are no longer incorrectly treated as equivalent to Lua 5.4. The benchmark exits early if its Lua target resolves to another runtime.
- Fixed generator metadata so v4.7.8 reports its own semantic-shadow architecture instead of v4.7.6/v4.7.7 labels; fixed `polyPlan.isaEngine` metadata for v4.7.8.
- Updated package, package lock, bot version strings, active VM version/watermark, tests and benchmark entry point.

## Scope honesty

This is **not** a second VM proven to carry the entire source semantics independently. The real VM still executes program behavior; the secondary lane is an opcode-correlated projection whose state is mixed into runtime guard/fabric evolution. The added state authenticator catches the specific tested output mutations; it does not prove resistance to an analyst who patches the verifier or rewrites the VM control flow, nor does it establish parity with Luraph or resistance to a skilled dynamic analyst. No Luraph private engine source was available; only protected output samples were inspected.

## Compatibility

The v4.7.7 code path remains selectable/history-preserved where explicitly versioned; this release only changes behavior selected by the active hardening version `4.7.8`. Existing function-policy limits, explicit fallback policy, eight binary-region transforms, and source-loader-free generation are retained.

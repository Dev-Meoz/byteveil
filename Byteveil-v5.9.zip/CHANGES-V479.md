# ByteVeil v4.7.9 — Striped Payload Candidate

## Payload architecture revision

- Replaces the earlier single `pb` string plus visible `pd` directory layout with multiple encoded payload lanes (`pl`). Shard allocation is seeded and distributed across lanes using the LPS-planned shard permutation.
- Serializes region scalar fields, dependencies, 62-entry opcode routes, vocabulary, shard ordering/lengths, and lane directory tuples into a compact `BVRD` descriptor stream (`rd`). The generated Lua no longer directly exposes `regions={{...}}`, per-region `route={...}` arrays, or a standalone plaintext `pd` directory.
- Keeps lazy region resolution/materialization: the runtime parses the descriptor during graph initialization, then decodes only shards needed by each region.
- Adds lane count and packed-descriptor size to structural metadata while retaining the aggregate `payloadBlobChars` and directory-entry metrics for API compatibility.
- This is an independently implemented serialization design informed by structural observations in protected-output samples. It is not a copy or reconstruction of Luraph's private implementation.

## Security interpretation

- Base85 is an encoding, not encryption. The descriptor and payload remain present in the generated output, and a skilled analyst who understands or instruments the runtime can still recover them.
- The specific improvement verified here is removal of the obvious readable region tree and raw route arrays, plus splitting the payload across lanes and placing descriptor fields behind a parser. It is not accurate to describe the output as impossible to dump or crack.
- The format is designed to preserve ByteVeil's no-source-loader runtime path and lazy-region semantics. Compatibility and resistance claims must remain scoped to the tested runtimes and test fixtures.

## Other v4.7.9 changes preserved

- Active release presets and runtime diagnostic strings use the v4.7.9 watermark/version identity.
- Register command ABI separation and Discord slash-command deployment synchronization remain in the candidate.
- IR-version metadata and numeric-transform status continue to reflect actual transformations rather than requested-but-unapplied operations.

## Test evidence

- **Passed:** syntax checks for modified serializer/generator/test files; focused stack/register runtime semantics; descriptor and lane-tamper rejection; the complete `npm test` release gate; and eight stack/register × active-preset syntax/runtime combinations.
- **Measured:** the eight cross-preset outputs were 0.25%–0.27% smaller than the previous v4.7.9 central-payload candidate for the chosen fixture. This is only a small sample comparison.
- **Still unverified:** native Roblox Luau execution, skilled third-party crack/devirtualization testing, runtime memory extraction resistance, scale performance, and parity with commercial obfuscators. Do not infer these from Lua 5.4 regression tests.

## Focused cross-preset comparison

Using the same arithmetic-loop fixture, seed per case, strength 3500, Lua target, and disabled wrapper, eight combinations (2 backends × 4 active presets) were generated and executed under Lua 5.4. The revised output was between 0.25% and 0.27% smaller than the prior v4.7.9 central-payload candidate for these cases; the mean measured size delta was −0.26%. This is a small fixture-specific result, not a general speed/size benchmark.

| Backend | Preset | Previous bytes | Revised bytes | Delta |
|---|---|---:|---:|---:|
| stack | l1 | 116,419 | 116,120 | −299 |
| stack | l2 | 115,118 | 114,824 | −294 |
| stack | df | 115,142 | 114,848 | −294 |
| stack | lz | 116,455 | 116,158 | −297 |
| register | l1 | 112,911 | 112,604 | −307 |
| register | l2 | 112,838 | 112,555 | −283 |
| register | df | 112,999 | 112,717 | −282 |
| register | lz | 114,477 | 114,188 | −289 |

## Release verification status

- **Passed:** full `BYTECODE_LUA_PATH=/tmp/byteveil-lua54-runner npm test` release gate on this candidate. This covers LPS, striped-payload and tamper checks, register ISA, audit fixes, mocked Discord command sync/reset, Macro/LPH, legacy frontend/stack-safety, 18 tail-return runtime checks, function policy, and 26 shadow/semantic runs.
- **Passed:** syntax and execution checks for stack/register × `l1/l2/df/lz` (8 combinations), with exact expected output `36`, no exposed `regions` object tree, no literal numeric route arrays, and revised lane/descriptor fields present.
- **Passed:** focused payload regression verifies descriptor tamper and lane-content tamper are rejected.
- **Not tested:** native Roblox Luau execution, a third-party professional crack/devirtualization review, runtime memory extraction, scale performance, and parity with commercial obfuscators. Discord deployment tests are mocked; no live Discord application was changed by these tests.

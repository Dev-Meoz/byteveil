# ByteVeil v5.1.0 — implementation notes

This is a targeted, tested upgrade on the existing v5.0.0 codebase. It does not claim a clean-sheet rewrite.

## Implemented in this package

- Synchronized the core, root package, bot package, lockfile, active profile/marker metadata, and test expectations to `5.1.0`.
- Added a quote/comment-aware generated-identifier rewriter. In the active generated output, internal `__bv_*` and `_bvanti_*` names are remapped while string literals, comments, and ordinary Lua/Luau API spellings are preserved.
- Generated active VM handler parameters, semantic-shadow handlers, and VM-island helper handlers with seed-dependent names rather than a fixed `function(S,I)` signature.
- Switched the default pipeline seed to Node's `crypto.randomBytes`; explicit seeds remain reproducible for tests/debugging.
- Made payload lane count and lane distribution depend on the build seed in the existing packed-descriptor/striped-lane design.
- Made the anti-hook source builder fail closed by default when it cannot resolve an environment; explicitly passing `failClosedOnMissingEnvironment: false` opts out. This does not prove APIs were not hooked before startup.
- Changed Micro's implicit name-factory seed to cryptographic randomness while retaining deterministic explicit seeds.
- Made LPH argument splitting respect quoted/escaped commas.
- Added Stack/Register method selection to `/obf`, validates the selected backend, and includes the selected method in the response/output name.
- Exercised deployment command synchronization in tests: stale ByteVeil registrations are removed within tested scopes while unrelated commands are preserved.
- Added `test-v510.js` and updated regression expectations for the active version/profile.

## Verification performed

- `npm test`: passed all configured tests on this environment.
- `node --check` over all repository JavaScript files (excluding `node_modules`): passed.
- Active fixture checks cover Stack and Register output generation, syntax/runtime on the installed Lua runner, payload descriptor/lane tamper rejection, payload build diversity/reproducibility, LPS/register ISA, macro/LPH, bot command syncing, tail-return behavior, and function-policy checks.
- A maximum-strength sample based on `examples/input.lua` produced a 137,874-byte output in the tested configuration; this is a sample observation, not a universal size guarantee.

## Not verified / remaining work

- `npm run test:v5:release` requires a real Lua 5.4 executable; the available runner reports Lua 5.3, so that release suite stops at its runtime-version precondition. It is not represented as passing.
- The payload descriptor/decoder architecture is still based on the previous packed-descriptor lane approach; v5.1 varies lane count/distribution and associated metadata but does not replace the complete decoder architecture from scratch.
- Identifier remapping here is lexical and limited to generated internal aliases/VM-generated parameters; it is not a universal scope-resolved renamer for arbitrary user source.
- Lua/Luau lexer, parser, IR, and compiler have not been formally proven against every language-version feature. The passing tests do not establish universal runtime compatibility.
- Stack and Register VM architectures are retained and incrementally improved, not replaced from zero.
- Micro, Macro, LPS, and LPH remain independent engines. This release makes targeted changes to Micro's default seed and LPH quoted-argument parsing; it does not claim to have fully re-engineered every engine.
- Anti-hook checks cannot guarantee detection of hooks installed before the program starts. Clearing tables/buffers cannot guarantee erasure of every memory copy.
- Bot command synchronization is mock-tested; no live Discord deployment was performed in this run.

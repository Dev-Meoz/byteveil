# ByteVeil v5.2.0 — changes and verification

This release is a targeted upgrade of the v5.1.0 tree. It preserves existing engine paths and Stack/Register separation. It does not claim to replace the VM architecture or the complete packed payload decoder.

## Changed

- Synchronized active package, core, bot, and output watermark identity to `5.2.0`.
- Fixed Lua binary-operator precedence in `src/frontend/parser.js`, including power/unary interaction, shifts, bitwise tiers, and right-associative power parsing.
- Fixed Stack prefix validation so in-place unary operations (`NOT`, `NEG`, `LEN`, `BNOT`) do not incorrectly decrement stack depth.
- Added `src/utils/diagnostic_string_encoder.js`. Selected generated diagnostic literals are emitted with three-digit decimal byte escapes. When a generated local alias to the standard `error` function is present, generated bare `error(...)` call sites are routed through that local alias, avoiding repeated visible `then error(...)` signatures. The pass skips comments and literals when rewriting call sites and preserves the message's runtime string; this is not cryptographic encryption.
- Applied diagnostic encoding after VM output generation in `src/core/pipeline.js`, updating output byte counts and output-budget metadata after the transformation.
- Removed the branded slogan / `Detected hook` style messages from the anti-hook diagnostic output path in favor of generic runtime diagnostic wording. The generated output encoder obscures selected messages without removing the error branches or silently suppressing their behavior.
- Hardened `bot/src/commands.js`: a URL pasted into `attach:code` gets a clear mode hint; raw URL fetching allows HTTP/HTTPS only, refuses embedded credentials and redirects, blocks local/reserved targets, resolves and pins public DNS results to the request, applies a timeout, and limits downloaded bytes while streaming.
- Added strict-VM lowering for Luau `continue` across `while`, `repeat`, numeric `for`, and generic `for` loops in both Stack and Register, with continue edges patched to the correct condition/update/iterator location.
- Added parsing/lowering for Luau backtick interpolation into concatenation and `tostring` calls, including quoted braces inside embedded expressions, escaped braces/backticks, and `\u{...}` Unicode escapes.
- Added `test-v520.js` covering precedence ASTs, diagnostic encoding and its runtime value, output-budget checks, and Stack/Register differential execution for arithmetic, loop-control, and interpolation fixtures on the available Lua runtime.
- Updated the bot URL tests to exercise pinned DNS and the native HTTP request path rather than mocking `fetch`.

## Verification performed

- `npm test`: PASS for all configured active regression suites.
- `node --check` over repository JavaScript files excluding dependency folders: PASS.
- Focused `test-v520.js`: PASS. It checks both backends against native Lua equivalents for precedence, five continue-loop shapes (including nested loops), and six interpolation cases. It also checks that active VM output does not expose the repeated `then error(...)` shape, and verifies selected diagnostic literals retain their runtime message after decimal escaping.
- `test-v479-bot.js`: PASS, including slash-command sync mocks, URL-mode routing, local-IP rejection, pinned DNS behavior, and streaming body size limits.
- `npm run test:all`: did not complete. The test suite reached `test-v479.js`, which enforces the precondition that the runtime be Lua 5.4. The available runtime identifies as Lua 5.3; this is an environment/runtime prerequisite failure, not a passing release suite.

## Architecture retained

- Stack and Register remain separate execution paths.
- Existing position-keyed striped payload lanes and packed `BVRD` descriptor/region format remain in place. The internal codec/layout identifiers retain their v5.1 lineage because the format is inherited.
- Macro and LPH remain independent engines; no broad redesign was made.
- The active v5.2 VM output profile enforces a 475,000-byte maximum; explicit legacy/compatibility routes retain their route policy and output-budget telemetry. The release does not add padding to reach the historic 375,000-byte minimum target.

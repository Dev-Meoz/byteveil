# ByteVeil v5.3.0 changes

- Replaced the repetitive anti-hook `if env["api"] ~= refs["api"] then error(...)` chain with a numeric-indexed reference vector and a single loop.
- API key strings and guard diagnostics are represented as per-build byte tables and decoded at runtime; decimal-escaped diagnostic literals are no longer the main hiding mechanism for these guard strings.
- Preserved the startup API snapshot comparison behavior and added clean-environment plus post-startup API-replacement tests.
- Kept Stack/Register VM architecture and existing payload ABI; this release specifically targets the obvious anti-hook output shape shown in the v5.2 output.

## Important limitation
The byte-table codec is reversible obfuscation, not cryptographic encryption. The guard detects API replacements after the snapshot; it cannot prove that APIs were native or unhooked before initialization.

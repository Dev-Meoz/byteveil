# ByteVeil v5.4.0 changes

- Replaced fixed `bv_shadow_N` decoy markers with seed-derived decoy strings in the semantic shadow payload.
- Added token-based local-name mangling for the generated semantic-shadow source while preserving comment text, literal contents, table-constructor keys and field names.
- Replaced the fixed semantic-shadow state fields with build-derived state keys and used the same key derivation from the generator's root seed in the real interpreter loop.
- Changed missing active-ISA semantic handler handling to fail at generation time rather than produce a delayed runtime-only fallback.
- For v5.4 builds, removed the cleartext API-reference vector from the anti-hook output by capturing the baseline through decoded environment keys; the core bootstrap aliases remain ordinary runtime dependencies and this is still reversible obfuscation.
- Added focused regression coverage for marker absence, local-name transformation, seed diversity, guard output, semantics and size budget.
- Corrected release metadata and docs that still identified the current package as v5.3.0, removed duplicate v5.4 routing conditions, and made shadow architecture metadata identify v5.4 explicitly.
- Preserved Stack/Register separation and the existing position-keyed payload ABI.

## Validation performed

See the final delivery report for the exact test commands and results from this build. Passing focused tests must not be interpreted as proof of cryptographic protection or resistance to all reverse-engineering methods.

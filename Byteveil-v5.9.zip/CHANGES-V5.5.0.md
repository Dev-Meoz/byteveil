# ByteVeil v5.5.0 — source change record

## Actual changes

1. `src/wrappers/WrapInFunction.js`: removed the outer `do ... end` around the `setmetatable` return path.
2. `src/vm/veil_sync.js`: added a shared, stage-ordered byte encoding coordinator with build-time inverse checks.
3. `src/backend/bytecode_serializer.js`: wired VeilSync into the active v5.5.0 per-region serialization path and exposed the verified stage count/metadata. The existing runtime decode sequence and wire transforms remain compatible.
4. `src/anti/anti_hook.js`: added `setmetatable` to the API snapshot and changed the fail-closed diagnostic to `Obfuscated source crash - runtime tamper detect`, encoded as a numeric table in the guard.
5. `src/utils/diagnostic_string_encoder.js`: recognizes the exact tamper diagnostic if it is emitted as a literal elsewhere.
6. `src/protection/live_shadow_vm.js`: enabled the hardened shadow state/string path for v5.5.0, fixing a version-gate regression that otherwise re-emitted `bv_shadow_N` markers.
7. `src/presets/index.js` and `src/core/pipeline.js`: added the `nest` preset using the actual existing `wrapSource` nested-source engine. Metadata reports its five layers and dynamic-loader requirement.
8. Updated current release identity and the Discord `/obf` preset choices; added regression coverage in `test-v550.js`.

## Verified

- `node test-v550.js` — PASS.
- `node test-v510.js` — PASS.
- `node test-v479-payload.js` — PASS, six runtime checks across Stack/Register.
- `node test-v479-lps.js` — PASS.
- `node test-v479-register-isa.js` — PASS, four runtime cases.
- `node test-v479-audit-fixes.js` — PASS.
- `node test-v479-bot.js` — PASS, including the Nest preset choice and command cleanup behavior.
- `node test-v479-macros-lph.js` — PASS.
- `node test-v433.js` — PASS.
- `node test-v479-tail-return.js` — PASS, 18 runtime checks.
- `node test-v479-policy.js` — PASS.
- `npm test` — PASS for the configured suite.
- Manual output audit for Stack/Register: both report `VeilSync-v1`, the v5.5 payload layout, and no `bv_shadow_N` markers; their generated wrappers do not start with `do return setmetatable`.
- Nest runtime smoke test: Lua syntax PASS and output `nest-ok\t5`.

## Not claimed as complete

This record does not claim 98% state/handler randomization, a complete independent Stack/Register VM redesign, actual superoperator fusion, or a full Macro/LPS/LPH semantic overhaul. Those remain explicit work items, not finished features.

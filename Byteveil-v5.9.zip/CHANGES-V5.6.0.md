# ByteVeil v5.6.0 — source change record

## Root-cause findings from v5.5.0

1. `src/backend/bytecode_serializer.js` only requested full region-stage verification for region zero. Regions after the first were encoded but were not included in that build-time round-trip verification count.
2. The serializer reported `VeilSync-v1`, although the coordinator implementation in `src/vm/veil_sync.js` is `VeilSync-v2`.
3. Release metadata and automated tests disagreed: package/watermark identity was v5.5.0, while the release runner still executed a stale v4.7.2 suite list. Several active tests expected old current-version metadata.

## Actual changes

1. **Per-region verification:** v5.6.0 enables verification for every region. For each region, the builder asserts that all three stage inverses round-trip and that the fully composed encoding pipeline returns the original bytes. Any mismatch throws with the region index and aborts generation.
2. **Honest aggregate counters:** `encodingRegionsVerified`, `encodingPipelineRoundTripsVerified`, and `encodingRoundTripsVerified` are passed from the serializer through VM structural metadata into `vmMeta`. v5.6 tests assert `encodingRegionsVerified === regionCount`, `encodingPipelineRoundTripsVerified === regionCount`, and `encodingRoundTripsVerified === regionCount * 3`.
3. **Engine and payload metadata:** current metadata reports `VeilSync-v2` and the region-verified payload-layout identity. Existing v5.5 code paths keep compatibility labels where they are selected explicitly.
4. **Reduce plaintext signatures:** the generated-output diagnostic pass now encodes the known payload-carrier/lane/integrity/continuation error strings as Lua numeric escapes while preserving their runtime message values. This reduces easy string-based fingerprinting; it is presentation obfuscation, not a security boundary. Regression checks ensure the recognized literals do not remain in generated output.
5. **Release identity:** root and bot package versions, lockfile, console/footer/watermark labels, MFG identity, and shadow architecture metadata are aligned to v5.6.0.
6. **Release gate:** `npm test` calls `tools/run-release-tests.js`, whose list now covers current v5.x regression suites rather than the old v4.7.2 runner.
7. **Test maintenance:** the focused v5.5 test entry remains as a compatibility shim to the v5.6 test; core, payload, LPS, Register ISA, bot, macro/LPH, tail-return, and policy tests now assert the active release contract.

## Verification record

- `node test-v560.js` — PASS.
- `node test-v510.js` — PASS.
- `node test-v479-payload.js` — PASS, six runtime checks across Stack/Register including syntax, execution, and descriptor/lane tamper rejection.
- `node test-v479-lps.js` — PASS.
- `node test-v479-register-isa.js` — PASS, four runtime cases.
- `node test-v479-audit-fixes.js` — PASS.
- `node test-v479-bot.js` — PASS, command sync/reset and preservation of unrelated registrations.
- `node test-v479-macros-lph.js` — PASS.
- `node test-v433.js` — PASS.
- `node test-v479-tail-return.js` — PASS, 18 runtime checks.
- `node test-v479-policy.js` — PASS when run independently.

The complete `npm test` release gate passed all 11 suites after the runner was changed to execute isolated test processes in batches of three. The tests include runtime syntax/execution and tamper probes for Stack/Register payloads.

## Output audit follow-up (source and generated output)

A review of the two user-provided v5.6.0 Stack/Register samples found that they already had one payload line, but they still exposed generated alias families and large runtime boilerplate. The source changes below target those concrete issues; existing sample files are audit inputs and are not rewritten in place.

1. **Token-aware minification:** `src/wrappers/WrapInFunction.js` now tokenizes Lua/Luau rather than joining whitespace through an ad-hoc character scan. It preserves quoted and long-bracket literals exactly, removes line/block comments, and inserts spaces only where adjacent tokens would lex differently. A regression fixture covers unary minus, concatenation/numeric boundaries and multiline long-bracket data.
2. **Generated identifier cleanup:** `mangleGeneratedInternals()` now also catches the `_bvh_` family plus seed-shaped generated aliases such as `_1namp50`/`_gtsnqx` and selected common generated locals. It avoids changing string/comment content, standard globals and metamethod keys. Identifier rewriting remains lexical; this does not make the VM opaque to analysis.
3. **Seed/label mixing for VM names:** `v38Id()` now mixes the seed with the role label before encoding a short mixed-case identifier; generated names no longer directly expose the XORed seed in base-36 form.
4. **Decoy diversity:** `src/protection/decoy_compiler.js` derives operand shape from build seed and opcode/position, validates an empty physical opcode set, and fingerprints instruction contents rather than only sequence metadata. This makes decoys vary more meaningfully, but does not make them equivalent to real VM instructions.
5. **Valid wrapper formatting:** the setmetatable wrapper uses a deterministic per-seed uppercase table field (`A`–`Z`) and routes `__call` through the same field. The outer invocation retains the existing generated-identifier argument bridge because some hybrid providers are inserted into non-vararg IIFEs; `...` is only forwarded inside the `__call` handler. The literal form `return setmetatable[R] = function` is not legal Lua/Luau statement syntax.
6. **Regression coverage:** `test-v560.js` verifies wrapper formatting and execution, minifier token safety, generated-name cleanup, and decoy seed diversity. Hybrid wrapper policy tests specifically catch invalid use of `...` when a provider is embedded inside a non-vararg function.

The full release gate was rerun after those compatibility corrections: `npm test` — PASS, all 11 suites.

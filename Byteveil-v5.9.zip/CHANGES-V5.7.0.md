# ByteVeil v5.7.0 — change record

## Implemented

1. Added `src/wrappers/bootstrap_renderer.js`, a dedicated callable-object bootstrap renderer. It creates three distinct numeric field slots per seed, orders fields from the build seed, chooses between two real call-forwarding topologies, and generates wrapper-local identifiers while avoiding names already present in the body.
2. Routed the default `l1` preset through the new wrapper. The explicit legacy `returnMode: "gsub"` API remains available for compatibility, but the shipped default preset no longer selects it.
3. Updated `src/wrappers/WrapInFunction.js` to use the bootstrap renderer for the setmetatable/callable wrapper mode and minify the rendered result with the existing token-aware minifier.
4. Updated pipeline wrapper calls to provide the Stack/Register mode to the renderer.
5. Kept generated-name blending and token-safe minification at the common finalization stage after main VM, hybrid-policy, compatibility and optional nested assembly return their result to `obfuscate()`.
6. Synchronized the active release identity across root/bot package metadata, watermarks, bot text, MFG/Byte-Blinder profile metadata and release tests.
7. Retained the v5.6 VeilSync-v2 contract: every active encoded region is verified through all three transform stages and the composed pipeline round trip at build time.
8. Added a v5.7 focused regression for bootstrap shape, deterministic seeded layout, alternate seed layout, Lua syntax/execution, token boundaries, default `l1` preset, watermark/version alignment, old generated-name fingerprints and region verification. The default `l1` test checks the emitted output, not just wrapper helper output.
9. Updated `npm run test:v5:release` to invoke the full active release gate.

## Verification performed

- `node test-v570.js` — PASS.
- `node test-v510.js` — PASS.
- `node test-v479-payload.js` — PASS.
- `npm test` — PASS, all 11 active release suites.
- Release suite includes Stack/Register, LPS, Register ISA, tamper probes, Macro/LPH, tail-return, function-policy/hybrid, bot deploy/reset, and legacy frontend/stack-safety checks.

## Not claimed

- This release does not replace the core semantic IR, lexer/parser implementation, or the full Stack/Register VM architecture.
- The wrapper is a varied callable bootstrap representation, not cryptographic protection. Numeric slots and dispatch indirection can still be analyzed.
- The payload container, codec family and runtime decoder mostly inherit the existing v5.6 design.
- Passing Lua-compatible runtime tests does not prove native Roblox Luau compatibility.

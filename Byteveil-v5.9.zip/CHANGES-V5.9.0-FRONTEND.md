# CHANGES — ByteVeil v5.9 frontend work

**Trạng thái:** Frontend patch đã triển khai; chưa phải release v5.9.0.

## CHANGED

- `src/frontend/lexer.js`
  - Sửa tính dòng/cột với CRLF và CR độc lập.
  - Sửa cách tiến con trỏ qua `--[[...]]`/`--[=[...]=]` để vị trí token sau long comment không bị lệch hai cột.
  - Báo lỗi cho newline vật lý không escape trong chuỗi quoted và phục hồi để tránh sinh lỗi chuỗi thứ hai gây nhiễu.
  - Giải mã line continuation LF/CRLF/CR thống nhất.
  - Báo lỗi escape `\\x` sai, Unicode escape không hợp lệ/surrogate/out-of-range và malformed numeric suffix.
- `src/frontend/parser.js`
  - Thêm `parseDetailed(sourceOrTokens)` trả về `{ ast, tokens, errors, lexerErrors, parserErrors, features }`.
  - Giữ `parse(sourceOrTokens)` là API AST-only.
  - Báo `Expected expression` cho danh sách biểu thức bắt buộc bị thiếu.
  - Chặn vòng lặp vô hạn trong function parameter list khi gặp EOF.
  - Báo thiếu toán hạng trong unary/binary expression và biểu thức ngoặc.
- `src/frontend/index.js`: export `parseDetailed`.
- `test-v590-frontend.js`: thêm regression cases.
- `package.json`: thêm `test:v590:frontend`.

## VERIFIED

Các lệnh sau đã chạy thành công trong môi trường kiểm tra hiện tại:

- `node test-v590-frontend.js` — PASS.
- `node test-v580.js` — PASS.
- `node test-v479-register-isa.js` — PASS (12 runtime cases trên Lua 5.4 và Luau theo báo cáo của suite).

## LIMITATIONS

- Chưa chạy toàn bộ `npm test` trong lượt kiểm tra này.
- Chưa chạy native syntax/runtime tests cho mọi cấu hình Lua/Luau.
- Các sửa đổi chỉ giới hạn ở frontend, test script và tài liệu; backend VM/compiler/pipeline/wrapper chưa được Qoder AI/Arena AI xử lý trong patch này.
- `package.json` vẫn ở `5.8.0`; chưa nâng version giả khi backend và release gate chưa hoàn tất.

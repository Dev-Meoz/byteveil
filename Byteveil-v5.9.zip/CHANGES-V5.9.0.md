# CHANGES — ByteVeil v5.9 backend work (Qoder AI)

**Trạng thái:** Backend patch đã triển khai và xác minh; chưa phải release v5.9.0. `package.json` vẫn ở `5.8.0` theo đúng PLAN-V5.9 (chỉ bump sau khi tích hợp và review cuối). Lần bàn giao v4 thêm bốn thay đổi thuật toán: carrier rác **sống** (mục 10), chống env logger (mục 11), alphabet hợp nhất 93 ký tự (mục 12), **JunkForge-v1** key bed tự kiểm (mục 13–14). Lần bàn giao này (**v5**) thêm ba thuật toán nữa: **VeilStr-v1** — mã hóa từng hằng chuỗi bằng keystream khóa theo material root của chính build (mục 16), **engine precheck** 9 kiểm tra fail-closed trên artifact trước khi trả output (mục 17), và năm lỗi engine tự gây ra đã sửa (mục 18: literal của parser làm frontend sai grammar, options bị whitelist nuốt, fold latch nhân bản, `wrapper:false` bị nuốt nên opt-out thành no-op, và `vmMeta.wrapper.shape` báo "không có bootstrap" trên đường `nest` nơi nó chỉ **không nhìn thấy** bootstrap). Release gate: **PASS 19/19 suite, exit=0, total=246,686ms** (concurrency=4, chạy **một mình** sau mục 18) — xem bảng "Release gate đầy đủ" và hai lần fail trước đó in trong cùng mục.

## Bối cảnh

Quy ước trích dẫn: mọi `file:line` trong tài liệu này **đối chiếu mã ở thời điểm bàn giao v5** và đã được kiểm lại từng chỗ bằng grep trước khi ghi; khi cần tìm lại về sau, hãy tin **tên symbol đi kèm** (`integrityGuard471`, `junkCarrierDigest`, `decoyRng`, `planForgeLatch`, `precheckArtifact`, `materialSeed`) hơn là con số line — mã máy chủ vẫn dịch chuyển line theo từng patch.

Baseline v5.8 Hardened + frontend patch v5.9 (ChatGPT) đã có sẵn trong source tree. Backend v5.8 được tuyên bố "all 11 release suites pass", nhưng trên máy kiểm tra thực tế release gate FAIL 6/11 suites với lỗi `syntax failure` (message rỗng). Toàn bộ phần backend v5.9 này bắt đầu từ việc điều tra các fail đó theo handoff.

## CHANGED

### 1. Root cause release-gate FAIL: thiếu `lua54.dll` (packaging bug)

- **Điều tra:** 6 suites (`test-v580.js`, `test-v479-payload.js`, `test-v479-register-isa.js`, `test-v479-macros-lph.js`, `test-v479-tail-return.js`, `test-v479-policy.js`) fail với `syntax failure: ` (rỗng). Exit status thật của `lua54.exe` là `3221225781` = `0xC0000135` = `STATUS_DLL_NOT_FOUND`. Chạy trực tiếp xác nhận: `error while loading shared libraries: lua54.dll`. `luau.exe` (static) không bị.
- **Nguyên nhân gốc:** `tools/install-native.ps1` tải `lua-5.4.8_Win64_bin.zip` (joedf/LuaBuilds — nguồn do chính project chọn) nhưng hàm `Install-ZipBinary` chỉ copy executable (`lua54.exe`), bỏ qua `lua54.dll` mà exe liên kết động. Archive chứa cả `lua.exe`, `lua54.dll`, `luac.exe`.
- **Fix:**
  - `tools/install-native.ps1`: thêm tham số `-ExtraFiles` cho `Install-ZipBinary`; lời gọi cài Lua truyền `-ExtraFiles @('lua54.dll')`; thiếu dependency giờ `throw` thay vì cài runtime chết. Luau không đổi (static, `ExtraFiles` mặc định rỗng).
  - `tools/native/windows-x64/lua54.dll`: thêm binary (679,052 bytes, Lua 5.4.8, trích từ đúng zip mà install script tải — kiểm chứng `lua54.exe` hiện hữu cùng build: 119,808 bytes, trùng `lua.exe` trong zip).
- **Không phải timeout:** handoff/plan nghi ngờ `npm test` timeout; thực tế gate chạy ~6–61s và fail nhanh vì DLL. Sau fix, gate chạy đến kết thúc tự nhiên, exit code 0.

### 2. Chẩn đoán runtime hỏng trong test harness (`tools/native-runtime.js`)

- Thêm `describeLaunchFailure()`: khi native runtime exit khác 0 với NTSTATUS (≥ `0xC0000000`) hoặc không có stdout/stderr, `runSyntaxCheck`/`runProgram` trả `error` mô tả rõ (ví dụ `STATUS_DLL_NOT_FOUND ... run tools/install-native.ps1`) thay vì message rỗng — chính là thứ đã khiến 6 suite fail trông như "lỗi cú pháp Lua" và làm lệch hướng chẩn đoán.
- Hành vi đường thành công và đường lỗi-Lua-thật không đổi: `describeLaunchFailure` trả `null` khi status=0 hoặc khi có stderr thật (lỗi Lua vẫn báo qua `stderr` như trước). Không đổi chữ ký hàm, không đổi API export.

### 3. Benchmark trung thực hơn: đo thật thay số khai báo (`tools/benchmark-v580-wrap.js`)

Theo handoff mục 1 ("đo output thực tế, không chỉ dùng số liệu benchmark hardcode") và mục 6 ("không tuyên bố chống RE chỉ dựa trên entropy/kích thước/slot ratio; phân biệt metrics cấu trúc với bằng chứng thực thi"):

- **Phát hiện:** khối `comparisonAcrossRevisions.fix3` khai báo cứng `liveCarriersOutsideBodyPct: 66.7`, `vmSubsystemsOutsideBodyPct: 66.7`, `maxSingleSlotSubsystemExposurePct: 33.3` và `staticConstantAndDiagnosticLeakagePct: 0.0`. Đo thật từ output sinh ra: `liveCarriersOutsideBodyPct` trung bình **65.44%** (khoảng 64.0–66.7 tùy seed) và `vmSubsystemsOutsideBodyPct` chỉ **54.17%** — tức số khai báo cũ **thổi phồng** phân bố subsystem ngoài body slot.
- **Fix:** thêm `measureStructural()` tính các chỉ số trên từ chính `analyses` của lần chạy (carriers theo slot, 6 primitives theo slot); thay toàn bộ số hardcode của fix3 bằng giá trị đo, kèm range. Static-scraper check (secret const + diagnostic strings) giờ được đếm (`checks`/`leaks`/`leakagePct` đo thật) thay vì hằng số 0.0.
- **Tái cấu trúc summary:** `comparisonAcrossRevisions` → `revisionComparison` với nhãn rõ `_structural` (fix1/fix2 giữ làm tham chiếu lịch sử, fix3 gắn `measured: true`); `reResistanceEvaluation` → `executionEvidence`; thêm `metricClassification` tuyên bố rõ nhóm structural (slot share/entropy/phân bố carrier — chỉ mô tả hình dạng output, **không** phải bằng chứng chống RE) so với nhóm execution evidence (chạy thật trên Lua 5.4 + Luau).
- Benchmark không nằm trong `SUITES` của release gate và không có code nào khác parse JSON output của nó → đổi cấu trúc summary không phá tương thích.
- *(Cập nhật sau mục 6/9: con số `liveCarriersOutsideBodyPct` đo lại trên carrier dạng container là **64.82%** (58.3–68); giá trị 65.44% ghi ở trên là phép đo cũ với carrier dạng quote, giữ nguyên để làm mốc lịch sử. Sau mục 10 — carrier rác cũng là carrier dạng container nên được tính vào tập "live" — lần chạy mới nhất đo **70.16%** (range 64.3–73.5), avg **30.25** carrier sống/output.)*

### 4. Engine mã hóa ký tự mới: VeilBlob-v1 (`src/obfuscation/veil_blob.js`)

Theo yêu cầu "nâng cấp mã hóa … định dạng `[==[byteveil ... ]`" và bảng ký tự đã cho (symbols `~!@#$%^&*()_+{}:"|<>?`-=[];'\,./` + alphabet `QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm`):

- **Charset 84 ký tự in được** (32 symbol + 52 chữ hoa/thường), không có chữ số — đúng tập người dùng chỉ định; `test-v590-blob.js` block 1 assert từng ký tự và độ dài 84.
- **Định dạng container**: `[=*[byteveil&<base84>=*]`, cấp `=` tự tăng (`pickBracketLevel`) để payload chứa `]=]` vẫn an toàn. Đây là đúng hình dạng của blob `LPH` trong mẫu Luraph 15.1 (`1.txt`): marker `LPH` dính ngay payload, không có dấu cách.
- **Codec base84**: pack 3 byte → 4 ký tự (đuôi 1→2, 2→3; `len % 4 === 1` là đầu vào lỗi), kèm frame độ dài 4 byte big-endian.
- **Khóa dòng (keystream)**: Lehmer PRNG (`a=48271, m=2147483647`) + autokey + ciphertext feedback + mặt nạ vị trí `(i*1103515245) % 2^31`, tất cả mod 256. **Không dùng bitwise operator** trong phần Lua sinh ra → chạy được trên Lua 5.1/5.4 và Luau (chỉ `%`, `math.floor`, `string.byte/sub/char`).
- Kiểm chứng: roundtrip JS trên mọi lớp đuôi `len%4`; decode **byte-exact trên Lua 5.4 và Luau thật**; đổi 1 ký tự ciphertext → fail-closed (không âm thầm trả chuỗi sai).
- **Codec đã đổi ở mục 12 (SUPERSEDED):** charset 84 ký tự *không chữ số* ở ba mục trên **không còn** — từ P1, blob và carrier dùng chung bảng **93** ký tự in được (ASCII 33..126 trừ `\`), nên codec là **base93** (pack 3 byte → 4 ký tự vẫn đúng vì `93⁴ = 74,805,201 > 2²⁴ = 16,777,216`; quy ước đuôi 1→2 / 2→3 và `len % 4 === 1` lỗi giữ nguyên). Lý do đổi: hai bảng khác nhau chính là fingerprint đọc tĩnh (xem mục 12), và mẫu Luraph 15.1 dùng tập in được đầy đủ **có chữ số** — tức tập 93 gần mẫu hơn, nhưng **lệch theo nghĩa đen** khỏi danh sách symbol+alphabet người dùng liệt kê (danh sách đó không có chữ số). Khai báo rõ để Arena/user quyết định có chấp nhận hay không.

### 5. Chuỗi chẩn đoán rời khỏi `\ddd` (`src/utils/diagnostic_string_encoder.js`)

- Toàn bộ string chẩn đoán của VM được gom vào **một manifest VeilBlob** (đánh chỉ mục, hoán vị thứ tự theo seed, mã lỗi số) và đọc qua runtime blob ở cổng emit cuối pipeline (`pipeline.js`, `blobSeed = (seed ^ 0xB10B5EED) >>> 0`).
- Kết quả đo trên output thật: số literal `\ddd` còn lại = **0** (assert trong `test-v580.js` và benchmark); ví dụ build `l1`: 49 chuỗi rõ → 1 manifest blob ~480 B + decoy.
- **Fix quan trọng (`applyEvents`)**: bộ thay thế từng literal bằng biểu thức truy cập bị **dính token** — body minify hợp lệ viết `x or"..."` không có dấu cách (dấu ngoặc là delimiter tự thân), nên thay bằng `or<accessor>` cho ra `orlv0b` và Lua báo `')' expected near 'orlv0b'` (rò ra ở preset `nest`, `test-v580.js:402`). `applyEvents` giờ chèn dấu cách có điều kiện theo `WORD_CHAR` ở cả hai biên. Regression test: block 9 `test-v590-blob.js` (cấu trúc + chạy thật ra đúng thông điệp trên 2 runtime).

### 6. Payload carrier đi trong container VeilBlob (`src/compiler/stack/vm_generator.js:14` import + `:1573` render `string.sub(renderCarrierLiteral(carrier.text), CARRIER_MARKER_SUB)`)

- Carrier trước đây nhét literal trong `decode("...")`; nay mỗi lane/descriptor mang `decode(string.sub([==[byteveil&...]==],10), ...)`: `string.sub` cắt marker nên decoder nhận đúng văn bản mã hóa như cũ, nhưng người đọc tĩnh mất dấu nháy phân định lane và phải giải cấp ngoặc trước.
- Import một chỗ duy nhất (`veil_blob`), không đổi planner/serializer; `test-v479-payload.js` và `test-v580.js` đã cập nhật mẫu nhận biết container (ablation giờ cắt byte **bên trong** ciphertext, không cắt ký tự escapes).
- Đo: `l1` 12 → 14 blob, số carrier dạng quote = **0**; chạy đúng trên Lua 5.4 + Luau ở mọi preset (`l1/l2/df/nest`).

### 7. "Source tạo mã ký tự nhưng không dùng" — đúng yêu cầu và đúng hình mẫu

Hai vị trí, cả hai là **container VeilBlob thật** (giống hệt về cấu trúc, giải mã được bằng codec, không phải chuỗi rỗng):

- **Cuối file, sau `end`** (`src/wrappers/bootstrap_renderer.js`): field cuối của metatable bootstrap là `[<key>]=[==[byteveil&...]==]` đặt sau `__call=function(...) ... end`, key số `1000 + seed % 89000` mà VM không bao giờ index. Kiểm chứng (block 11): key xuất hiện **đúng 1 lần** trong toàn bộ output; xóa field → 2 runtime vẫn in `30`; seed cố định tái lập, seed khác đổi khóa và ciphertext.
- **Rải trong carrier bed** (`src/compiler/stack/vm_generator.js:1582-1597`, `decoyRng = v38Rng(seed ^ 0x0E517)` + `distributed.splice`): 2–4 container `bank[<slot>]=[==[...]==]` được splice **ngay sau** các assignment `bank[slot]=function()...end` của carrier sống, theo `v38Rng(seed ^ 0x0E517)`. Đây đúng là mẫu Luraph 15.1: blob gán cho local xen giữa các field `function()...end`, không dồn đầu file. Slot decoy tránh mọi slot carrier (`usedSlots`), và `readPayloadLane`/`readPayloadDescriptor` chỉ chạm slot có trong lane/descriptor map nên decoy không nằm trên đường thực thi.
- Hệ quả đo được: **số blob ≠ số carrier** (benchmark lần chạy hiện tại sau mục 16–18: **356.75** container mỗi output, **trừ 319.25** container padding ⇒ **37.5** container trong payload, trong đó **30.63** carrier sống — đã gồm 3–6 carrier rác của mục 10 — **3.25** container gán raw không ai đọc nằm chen trong 3 slot bootstrap; phần chênh còn lại (~3.6/output) là container **ngoài** carrier bed, ví dụ manifest chuỗi chẩn đoán — benchmark chỉ phân loại sống/không-dùng cho container trong 3 slot bootstrap, và ở đó `containersInStagesNotAttributedToEither = 0`. Container không dùng chiếm **9.68%** carrier bed, range 5.6–12.9; số của lần chạy trước VeilStr: 37.13 / 30.25 / 3.25 / 9.85%).
- **Bằng chứng thực thi của "không dùng"** (thay cho suy luận cấu trúc): benchmark block 6 giờ phân loại từng container theo vị trí tuyệt đối — container sống (có `string.sub(` phía trước) bắt buộc fail-closed khi lật 1 byte; container gán raw bắt buộc **vẫn chạy và cho đúng cùng digest**. Kết quả ở mục VERIFIED.
- **Phạm vi của mục này (đọc kèm mục 10):** container ở đây là loại **gán raw** (`bank[slot]=[==[…]==]`, không có `function()return…end`) nên vẫn inert đúng như tuyên bố. Loại **carrier dạng function** do mục 10 sinh ra *không* nằm trong tập inert đó và đã được kiểm chứng là fail-closed; benchmark phân loại bằng vết `string.sub(` nên hai tập không lẫn vào nhau.

### 8. Release gate: chỉnh schedule theo số đo thật (`tools/run-release-tests.js`)

- Lần chạy trước fail `(test-v580.js; total=180199ms)` không phải vì lỗi thuật toán: `test-v580.js` chạy **một mình hết 52,743ms** nhưng vượt ngân sách 180s khi 8 suite chạy đồng thời (mỗi suite còn spawn `lua54`/`luau` → 8 node + 8 runtime oversubscribe CPU 8 nhân).
- Fix: `CONCURRENCY = cores/2` (min 2) và `PER_SUITE_TIMEOUT_MS = 300_000`, lấy từ wall-clock quan sát khi có tranh chấp chứ không đoán; kèm comment ghi rõ số đo. Suite `test-v590-blob.js` được đăng ký vào `SUITES` (11 → 12); hai suite của mục 10/11 (`test-v590-junk.js`, `test-v590-envguard.js`) nâng lên **14** và được đặt ngay sau `test-v590-blob.js` vì chúng là bằng chứng của chính patch này.

### 9. Sửa lỗi đo lường trong benchmark (`tools/benchmark-v580-wrap.js`) — 2 "pass giả"

- **(a) Carrier detector cũ lỗi thời**: `carrierRegex` vẫn dò dạng quote `=function()return dec("`, không còn tồn tại sau mục 6 → `liveCarriersOutsideBodyPct` bị báo **0**. Đã đổi sang dạng container và đo lại: **64.82%** (range 58.3–68).
- **(b) Ablation/tamper chạy bỏ qua harness**: block 5 và 6 gọi `runProgram(rt, mutated)` trong khi `sampleProgram` chạm global mà `harness()` cấp (`bv_side_log`, `bv_exec_count`). Không có harness thì **mọi** chương trình đều chết từ trước khi lật byte, nên assert "must fail closed" đúng một cách vacuous — và đó là lý do con số cũ `ablatedCarrierChecksPassed: 462/462` (mẫu self-referential `${n}/${n}`) vô nghĩa. Sau fix: mỗi lần lật chạy trong harness, số báo là `số container lật / số runtime check`, và decoy được tách ra để chứng minh **trái ngược** (phải sống). Block 3 cũng được thêm assert "lỗi phải là runtime, không phải `syntax error`" để phát hiện extraction cắt nhầm vào trong container.

### 10. Carrier rác "sống" — `[==[byteveil&…]==]` không còn là trang trí (`src/compiler/stack/vm_generator.js:1442` `junkRng`, `:1496` template, `:1523` assignment, `:1554` `junkCarrierDigest`)

Mục 7 trước đó rải container **gán raw** (`bank[slot]=[==[...]==]`) — có thật trong output nhưng VM không đọc, nên xóa/sửa tùy ý. Theo lựa chọn "Rác sống", engine giờ sinh thêm **carrier rác cùng hình dạng với carrier thật** và bắt buộc VM phải đọc chúng:

- Số lượng 3–6 carrier/output, slot `1000 + rng % 89000` (`v38Rng(seed ^ 0x0E5C0DE)`), payload 48–287 ký tự lấy từ đúng alphabet của carrier bed (**85** khi đo ở thời điểm mục 10; từ mục 12 là **93** ký tự thống nhất).
- Dạng gán **giống hệt** carrier sống: `bank[<slot>]=function()return <junkDecoder>(string.sub([==[byteveil&…]==],10),mult,offset,reversed[,streamSeed,streamSalt,decodeVariant]) end` — không còn dấu hiệu cấu trúc nào phân biệt rác với thật khi nhìn text.
- Đầu runtime định nghĩa `junk-carrier-digest`: gọi từng carrier rác, kiểm `type(F)=="function"`, kiểm độ dài chuỗi giải mã, **fold toàn bộ byte đã giải mã** (mod 1.000.003, trọng số `i*37+11` cho độ dài và `i*53+19` cho fold byte), so với digest tính sẵn lúc build, rồi `bank[slot]=nil`.
- Builder JS phải mô phỏng đúng decoder Lua (xor/mul 32-bit, `mix` kiểu murmur, `%` âm kiểu Lua, mặc định `K or 1` / `Z or 0` / `Q or 0`); sai một bit là runtime lệch digest ngay.
- **Vì sao phải có decoder riêng (`junk-carrier-decode`)**: bản `decodePayloadCarrier` chung bị chính các bootstrap stage *sửa bằng `.replace`* — dòng `PV` nhận thêm số hạng `bx(ctx[K.key] or 0, expectedKey)` chỉ bằng 0 sau khi stage đã nạp key. Kết quả là giải mã phụ thuộc thứ tự thực thi: đo thật **158/160** combo fail `junk carrier digest` khi dự đoán bằng bản chung. Sau khi tách bản sao không bao giờ bị sửa: **160/160** pass.
- Digest chỉ fold *byte đã giải mã* nên có ý nghĩa chống sửa đổi; bản trước chỉ fold độ dài nên **92/400** lần lật byte vẫn sống — đã sửa.

### 11. Chống env logger (`src/compiler/stack/vm_generator.js:1044` `integrityGuard471`; accessor môi trường ở `:1015`/`:1020`)

Attack được báo cáo: bot Discord cài metatable lên `_G` (`__index`/`__newindex` ghi tên lại) hoặc bọc stdlib rồi dump. Hai lớp phòng thủ mới:

- **Provenance của môi trường**: sau khi kiểm tra hình dạng env, guard đọc `getmetatable(E)` và `rawget` lấy `__index`/`__newindex`. Nếu là **function** → bắt buộc `debug.getinfo(F,"S").what=="C"`; nếu `__index` là **table** (kiểu chuyển tiếp hợp lệ của Luau) → dò `rawget(IX,"string").sub`. Callback bằng Lua closure ⇒ `environment index logger detected` / `environment index supply hook detected` / `environment write hook detected`. Check nằm sau `__bv_nativeChecks` (`_VERSION` bắt đầu "Lua 5" và có `debug.getinfo`) để Roblox Luau — nơi mọi hàm đều là Luau — không báo nhầm.
- **Đường abort của guard không còn phụ thuộc `error` toàn cục**: root-cause đo được — bộ định danh gộp lời gọi global builtin về một local alias đã hoisting, nhưng bản sao guard trong bootstrap stage nằm **ngoài scope** của alias đó ⇒ mọi lần guard fail chỉ ra `attempt to call a nil value (global 'NzD')` (mất thông điệp), và nếu host stub `error` thì guard **return rồi chạy tiếp** (fail-open). Sửa: guard tự bắt `local __bv_errorRef=error;` ngay đầu, gọi qua `__bv_error(M)` — sau lời gọi là một bẫy nội tại không stub được (`local Z=({})[1]return Z.x` ⇒ `attempt to index a nil value`), đồng thời `__bv_errorRef` được thêm vào danh sách provenance (thay `error` bằng closure là tự lộ). Carrier rác cũng dùng bail cùng kiểu (`__bvjBail`).
- Path đọc global của VM đã dùng `rawget(E,K)` trước nên một `__index` logger chỉ thấy các tên *không tồn tại*; đây là lý do `globalLogger` chứng kiến 0 tên của script, không phải 0 lần gọi metamethod.

### 12. Hợp nhất alphabet: mọi container dùng chung 93 ký tự in được (`src/obfuscation/blob_alphabet.js` mới; `src/obfuscation/payload_container_v29.js:10-15`, `src/obfuscation/veil_blob.js:22-26`, `src/compiler/stack/vm_generator.js:15-16`, `:1011`, `:1961`, `src/backend/bytecode_serializer.js:6`)

- **Fingerprint cũ (đã bị loại)**: đường carrier dùng bảng **85** ký tự *có* chữ số, đường blob (diagnostic/decoy) dùng bảng **84** ký tự *không* chữ số. Kẻ đọc tĩnh vì thế phân loại được container — cái nào mang payload, cái nào chỉ là trang trí — chỉ bằng cách đếm sự hiện diện của chữ số, **không cần giải mã**.
- **Bây giờ**: một nguồn duy nhất `UNIFIED_ALPHABET` = ASCII in được 33..126 trừ `\` ⇒ **93 ký tự**; `UNIFIED_BASE = 93` là radix của cả payload unpack (base93, không dùng bitwise Lua) lẫn blob codec. `BLOB_CHARSET === PAYLOAD_ALPHABET === UNIFIED_ALPHABET` (là đúng một object, không chỉ bằng nội dung).
- **Vì sao `\` bị loại**: text container đi qua JSON-escaped Lua string literal nên `\` thành `\\`, và ba chữ số payload ngay sau nó đọc thành escape `\ddd` — vừa phạm invariant của generator (cấm biểu diễn đó trong output), vừa đúng hình dạng output này sinh ra để tránh.
- **Thứ tự bảng ký tự** là fixed Fisher-Yates (seed một lần, không phải bảng ASCII), nên chữ/hoa/số/dấu không cluster — tỉ lệ class trong ciphertext xấp xỉ đồng đều, không phải hệ quả của một bảng sorted.
- `test-v590-blob.js` block 1 assert trực tiếp: charset dùng chung, `BLOB_BASE === 93`, không trùng ký tự, và "0123456789" nằm trong blob alphabet.

### 13. JunkForge-v1 — engine chèn junkcode kiểu Luraph, buf file >200 KB, trần 2.5 MB / 3 MB (`src/obfuscation/junk_forge.js` mới; `src/core/pipeline.js`, `src/core/output_budget.js:7-68`, `src/obfuscation/veil_blob.js` (`findBlobLiterals`, `renderDecoyBlob`), `test-v590-forge.js` mới, `tools/run-release-tests.js`, `package.json`, `test-v580.js`, `tools/benchmark-v580-wrap.js`)

- **Cơ chế**: hàng trăm → hàng nghìn container `[==[byteveil&…]==]` **thật** (đúng codec, đúng alphabet) trên byte PRNG, gom thành bank, phát ra dưới dạng một statement prefix `local <holder>=(function()local <banks>={} local <fns>={function()…end,…} … end)();`. Mỗi container là một giá trị base93 hợp lệ, không phải text ngẫu nhiên — không có cách nào phân biệt "junk" với "carrier" bằng hình dạng container.
- **Digest tải-time** (build-time seal, load-time re-compute): với mỗi container — `#text` + **4** điểm `string.byte` (chọn 4 trong 8 biểu thức offset, tính theo `L` độ dài container và `I`/`J` chỉ số bank/element); với mỗi bank — `table.concat` + **4** số đếm class bằng `string.gsub` (`%a/%d/%u/%p`, chạy trong C nên không tốn một Lua step mỗi byte). Sai digest ⇒ đường bail `local x=({})[1] return x.k` ⇒ `attempt to index a nil value`, **không stub được**; container ngắn dưới `MIN_CONTAINER_TEXT=60` cũng bail.
- **Hằng số đo được từ mã**: `FORGE_DOMAIN=0x0E5C0DE5`, `OUTPUT_CAP_BYTES={lua:2,500,000, luau:3,000,000}`, `MIN_FLOOR_BYTES=204,800`, `HEADROOM_BYTES=32,768`, `MIN_CONTAINER_TEXT=60`, `PRESET_FLOORS`: `l1/default 204,800 · l2 400,000 · nest 700,000 · df 1,200,000 · lz 2,000,000 · maximum 2,400,000`; profile không tên (custom) = `204,800 + (strength−1000)×24`.
- **Opt-out**: `junkForge:false` hoặc `junkForge:{enabled:false}` → `vmMeta.junkForge = {reason:"disabled", paddingBytes:0, applied:false}`.
- **Thứ tự trong pipeline**: build route → nest wrap → `finalizeGeneratedOutput` (mangle → minify → **JunkForge**) → `encodeDiagnosticStrings(...,{mode:"blob"})` (prelude chẩn đoán được chèn **trước** khối forge) → stats/vmMeta → ngân sách → `analyzeOutputBudget({floorBytes,capBytes,paddingBytes})`. `sizeBudget` trong vmMeta báo `targetMinBytes/targetMaxBytes/paddingBytes/status`, không còn hardcode số nào.
- **Trần cũ 475 KB** (`protectionBytes`) được thay bằng envelope 2.5 MB (Lua) / 3 MB (Luau); `maxOutputBytes` do caller truyền luôn thắng. Floor lớn hơn cap ⇒ clamp vào cap và `partial:true` (vẫn chạy đúng, vẫn fail-closed).
- **Topping-up có feedback**: seal → đo độ dài → bổ sung container → seal lại, vì bản thân code digest dài ra làm tăng số byte cần pad; overshoot đo được ≤ `floor×2% + 8192` byte.
- **Ví dụ đo thật** (`examples/input.lua`, 85 B nguồn): `l1` → 208,067 B / 340 container / 141,327 B padding, build 1,170 ms, chạy đúng digest; `lz` → 2,010,110 B / 4,717 container, build 3,240 ms, chạy đúng. Nguồn 97 KB đã hợp lệ về VM: `l1` → 1,088,431 B với `applied:false, reason:"already-above-floor"` (payload tự nó đã vượt floor ⇒ **không** chèn), `lz` → 2,005,926 B (924,222 B padding).

### 14. JunkForge key bed — khóa payload fold từ 5 container, đóng lỗ hổng "gỡ cả khối vẫn chạy" (`src/obfuscation/junk_forge.js` (`planForgeLatch`, `bedFold`), `src/backend/bytecode_serializer.js:782-787`, `src/compiler/stack/vm_generator.js` (`buildV452GeneratedSource`, `buildV45GeneratedSource`, `buildPackedBytecodeSourceV40`), `src/customVM.js`, `src/core/pipeline.js`, `test-v590-forge.js` mục 5)

Mục "Giới hạn đo được" bên dưới đã ghi nhận: digest cũ **chỉ** tự kiểm tra padding, nên xoá nguyên khối forge (kèm lời gọi) vẫn để payload chạy bình thường trên cả 3 preset × 2 runtime. Bản này sửa đúng chỗ đó, bằng cách biến khối thành **nguồn khóa giải mã** chứ không còn là oracle so sánh.

- **Bed**: 5 container `[==[byteveil&…]==]` drawn từ stream riêng (`LATCH_DOMAIN=0x1F0A6E5`, `LATCH_STREAM_SALT=0x1AD5`), **không** phụ thuộc body ⇒ tồn tại y hệt nhau dù build pad 200 KB hay không pad chút nào. Fold: `k=(k×83 + #text) % 2,147,483,587` rồi **đi qua từng byte** của cả 5 container `k=(k×97 + string.byte(text,i)) % M`, bắt đầu từ `LATCH_START_HASH=0x51F0ED1`. Block `return k`.
- **Binding vào payload**: `materialSeed = (rootSeed + key) % 2^32` chỉ được dùng cho `v45DeriveRegionSeed` (khóa vật liệu từng region). Trong generated source, `rs(R,D)`/`rseed(ID,T,D)` mix đầu tiên đọc `(RROOT + <holder>) % 4294967296` — `<holder>` chính là local do khối forge trả về, xuất hiện **đúng một lần** trong output. Personality, morph plan, layout, region tokens, shares và graphToken vẫn dùng `rootSeed` gốc ⇒ không đổi thứ gì ngoài vật liệu region.
- **Digest padding bị khóa theo bed**: `h = (key × seedMul + seedSalt) % mod` trước khi walk bank ⇒ sửa một container bed làm hỏng **cả** khóa và **cả** digest.
- **Chi phí thật của fold byte-complete**: bed text 1,817–2,108 B ⇒ **~2.3 ms/lần start trên Lua 5.4** và **~1.0 ms trên Luau** (micro-benchmark cùng vòng lặp emit ra, `os.clock`, 100 lần lặp). Padding digest vẫn chỉ đọc `#text` + 4 điểm sample + 4 class count — mở rộng byte-complete cho padding đã đo được là quá đắt (`gsub` 140 KB × 4 bucket ≈ 79 ms, 2.3 MB × 12 bucket ≈ 4.1 s Lua / 6.1 s Luau), nên giới hạn đó giữ nguyên và được khai báo thẳng trong LIMITATIONS.
- **_holder survive mangle/minify_**: tên holder 8 chữ thường, không chứa `_`, không thuộc `vmInternalNames` và nằm ngoài pool candidate 2–4 ký tự của `mangleGeneratedInternals`; `collectUsedNames` + `usedNames.add(holderName)` tránh pool sinh trùng tên. Pipeline **throw** nếu block emit ra không đúng holder đã bind (`JunkForge binding failed: block holder X != Y`) hoặc body không tham chiếu holder ⇒ không có đường "bind nửa vời".
- **Ngoại lệ có chủ đích**: preset `nest` nạp body VM từ string (chunk khác), holder cấp chunk không nhìn thấy ⇒ bind bị bỏ, `keyBedBound:false`, padding vẫn chèn đầy đủ. Route `junkForge:false` không có bed và payload chạy bình thường (đã kiểm chứng).
- **Telemetry mới** (`vmMeta.junkForge`, bản đầy đủ trong `stats.junkForge`): `keyBedBytes` (2,209–2,508 B), `keyBedContainers:5`, `keyBedTextBytes` (số byte fold thực đọc), `keyBedBound`, `baseBytes`; `reason` mới `key-bed-only` (body đã vượt floor ⇒ chỉ emit bed).

### 15. Wrapper: hai đuôi `return setmetatable` chọn theo seed, thêm pre-flight stage + native-ref pool kiểu Luraph 15.1 (`src/wrappers/bootstrap_renderer.js` (`chooseShape`, `colonField`, `chooseSlots`), `src/wrappers/WrapInFunction.js`, `src/core/pipeline.js`, `src/core/env.js`, `test-v580.js` mục "v5.9 wrapper tails", `tools/benchmark-v580-wrap.js`)

- **Đuôi mới `colon-dispatch`** (mục tiêu P2 "làm lại phân wrapper return setmetatable của luraph v15.1"): output đọc là
  `return setmetatable({<3 slot số>, <rootBindings>, <pool>={…}, <METHOD>=function(self) … return function(...) return self[(0x…-0x…)](self,...) end end}, {__call=function(self,...) … end, __metatable=false, [<decoy>]=[==[byteveil&…]==]}):<METHOD()>(...)`
  — method tên **định danh** (không phải slot số), gọi bằng **colon**, phát hành một closure rồi mới áp vararg tuple của chunk, đúng hình thái `…:{}():XX()(...)` của Luraph 15.1.
- **`<METHOD>` là một stage thật, không phải trang trí**: method **sở hữu một bước LCG** của máy trạng thái (`state = step(state, colonSalt)`), và `stage1Token` / `expectedBootstrapKey` (khóa bootstrap mà staged subsystems kiểm tra) được tính **sau** bước đó. Vì vậy ở build colon, gọi object trực tiếp qua `__call` (đuôi bị gỡ) ⇒ trạng thái chưa tiến ⇒ mọi phép so sánh phía sau chết ⇒ **fail closed**, không chạy nửa vời. Method cũng chặn `self[state]` đã bị tiếm (phải còn đúng `initSeed`) và xác minh pool trước khi cho decoder chạy.
- **Native-ref pool**: field định danh `<pool>={type,error,select,string.sub,string.byte,math.floor,table.concat,pairs}` (8 tham chiếu native, kiểu `[n]={…}` của Luraph). Pre-flight kiểm `type(pool)=="table"`, `#pool==8` và **tính danh từng phần tử** với các slot số đang bind (`pool[1]==self[<std.type>]`, `pool[3]==self[<std.select>]`, `pool[6]==self[<std.floor>]`) ⇒ pool bị sửa/cắt ngắn, hoặc host tráo global giữa hai lần đọc, đều abort. Pool + method bị `nil` cùng đợt wipe với stdlib bindings trong dispatch.
- **Chọn đuôi theo seed**: `chooseShape(seed, backend, invoke, requested)` — đo trên 200 seed liên tiếp (backend `register`): **100 colon / 100 callable-object**; `invoke:false` **bắt buộc** ở đuôi cũ (caller nhận object để tự gọi, không có vị trí tail cho stage). Override: `obfuscate(src,{wrapper:{shape:"colon-dispatch"|"callable-object"|"auto"}})` hoặc env `ENGINE_WRAPPER_SHAPE` (mặc định `auto`), plumbed qua 4 điểm `wrap()` trong `src/core/pipeline.js`.
- **Giữ nguyên các bất biến mà suite/benchmark đang đo**: vẫn **đúng 3** field `[ddd]=function(` (test-v580.js:36 và benchmark census), vẫn có `__call=function(` (test-v580.js:37), vẫn là decoy `[<key>]=[==[byteveil&…]==]` ngay sau `__metatable=false,` (test-v590-blob.js block 11), vẫn bắt đầu `return setmetatable({[<slot>]=function(`. Field mới dùng **key định danh** nên không làm thay đổi census slot số. Assertion đuôi trong `test-v580.js` (dòng từng hardcode `})(...)`) được viết lại **has-hình-dạng** (shape-aware) thay vì nới lỏng.
- **Telemetry đo từ output, không khai báo từ request**: `vmMeta.wrapper = { shape, requested }`; `shape` phân tích từ **đuôi thật sự emit** (`colon-dispatch` / `callable-object` / `no-callable-bootstrap-tail`) ⇒ preset `nest` (đường wrapper legacy) tự báo `no-callable-bootstrap-tail` thay vì nhận vờ là bootstrap. Benchmark thêm `wrapperTail` mỗi build và `wrapperTails` đếm cả lô. **Đã sửa ở mục 18:** nhãn đó trên đường `nest` là **cáo buộc sai** (bootstrap có thật, chỉ nằm trong inner source đã mã hóa) — `nest` + wrapper bật nay báo `bootstrap-in-nested-source`.
- **Bằng chứng thực thi** (`test-v580.js`, cả `lua54.exe` và `luau.exe`): hai đuôi đều reachable trong 64 seed đầu; build colon chạy đúng (`30`); **6 đột biến × 2 runtime đều abort** — gỡ field pre-flight, gỡ lời gọi `:<METHOD>()`, gọi qua `__call` thay thế, tráo `pool[6]` (`math.floor`→`math.ceil`), cắt pool còn 7 phần tử, lệch state seed 1 đơn vị. Kiểm trên build **có coupling + đã mangle** (preset `l1`): tên method là tên do engine sinh, vẫn xác định được từ đuôi; gỡ lời gọi ⇒ abort, gỡ cả field ⇒ abort. Phủ preset: 6 preset × 2 target × 4 seed = **48 build**, 20 colon / 28 callable-object, **0** build sai digest.
- **Chi phí thật, đo từ output** (`scratch/probe_colon_cost.js`, 200 seed, backend `register`, cùng body `local a=10 local b=20 print(a+b)` đã minify): field pre-flight một mình **538–616 B** (trung vị **581 B**); cả wrapper đuôi colon **2,116–2,421 B** so với đuôi callable-object **1,464–1,702 B** trên cùng seed ⇒ **tăng thêm +638…+720 B/build**, tức ~0.3–0.5% của ngân sách 2.5 MB chứ không phải con số tự nhiên đáng kể. Chi phí runtime: method chỉ chạy **một lần mỗi chunk** (một bước LCG + 3 phép so sánh tham chiếu + `#pool`), không có vòng lặp theo payload.

### 16. VeilStr-v1 — mã hóa chuỗi hằng số *riêng* cho payload, khóa là material root của build (`src/obfuscation/veil_str.js` mới; `src/backend/bytecode_serializer.js:787-798` + `:862`, `src/compiler/stack/vm_generator.js:870` + `:1287-1295` + `:1937`, `src/customVM.js`, `src/core/pipeline.js:85`/`:675`/`:848`, `test-v590-veilstr.js` mới)

Mục 4-5 (VeilBlob) chỉ đổi **dạng biểu diễn** chuỗi chẩn đoán/carrier. Phần chuỗi hằng của *chương trình người dùng* trước đây nằm plaintext trong region đã mã hóa: giải được region một lần là đọc được toàn bộ vocabulary của chương trình bằng một phép quét tuyến tính. VeilStr giữ nguyên vị trí đó nhưng cho **mỗi constant một keystream lane riêng**, khóa lấy từ material root của build — tức xóa key bed hoặc để bị hook không còn là "mất một check", mà làm hỏng **từng chuỗi trong chương trình**.

- **Định dạng on-wire**: constant string là tag `85` (`T==85`) = `len` (varint) + `check` (1 byte) + `len` byte cipher, thay cho tag `83` (plain) chỉ khi route bật cipher. Tag không đổi với number/bool/nil/nested chunk.
- **Khóa**: `K = mix32(materialRoot, (mul32(chunkSeq+1, 0x27D4EB2F) ^ mul32(index+1, 0x9E3779B1) ^ 0xD3C0DEC0) >>> 0)`; `materialRoot = (rootSeed + forgeLatchValue + guardLatchValue) % 2^32` — đúng ba addend mà `buildV452GeneratedSource` tái tạo được từ `(RROOT + <holder> + <guardKey>) % 4294967296`. Hai phía serializer/runtime đi cùng traversal order (pre-order chunk tree), nên `chunkSeq`/`index` khớp nhau mà không cần ghi mã vào payload.
- **Per-byte mask 3 lane**: `mask(K,P,L) = mix32(K, (0x51ED2708 + mul32(L+1,0x45D9F3B) + mul32(P+1,0x27D4EB2F)) % 2^32) % 256`; encrypt = `((p+lane0)^lane1)-lane2`, decrypt là nghịch đảo đúng thứ tự. Chỉ dùng `mix`/`mul`/`bx` — ba primitive đã được chứng minh JS↔Lua cho cùng kết quả, nên không đưa thêm rủi ro precision 53-bit.
- **Fold check + crash ladder (mỗi constant)**: `H=17; H=(H*65599+b+1)%2147483647` trên plaintext, lấy `%251` ghi trong payload. Nếu `fold(plain) ~= check`: `G.materialRoot=0` → wipe cả bảng constant của chunk (`K0[Z]=nil`) → `error(...,"ByteVeil v4.6.3: constant state",0)`. Xóa lời gọi check ⇒ build **vẫn chạy** nhưng in ra **chuỗi sai**, không phải chuỗi đúng — check chỉ là một điều kiện, không phải oracle toàn vẹn.
- **Không phải crypto chuẩn**: vẫn là keystream đối xứng theo khóa build (chiếu về bullet đầu của LIMITATIONS về VeilBlob); giá trị là **liên kết khóa**: key bed + guard verdict mất ⇒ mọi string thành rác.
- **Một fold, hai consumer**: biểu thức latch `(RROOT + <forge holder> + <guard holder>) % 2^32` được tính **một lần** vào local trong graph runtime; `rs()` (region seed) và `G.materialRoot=` (khóa chuỗi) cùng đọc local đó. Bản đầu của tôi nội suy biểu thức hai lần, và gate **bắt được**: `test-v590-forge.js` ("holder phải được đọc đúng tại chỗ sinh khóa region") và `test-v590-antibundle.js` ("verdict đọc đúng một lần trong region root") đều fail `2 !== 1`. Ngoài ra fold duplicated còn nghĩa là phép `%` bị tính lại mỗi lần resolve region.
- **Tắt được**: `obfuscate(src,{stringCipher:false})` → route không phát tag 85, không publish `G.materialRoot=`, payload chạy như trước (đã kiểm chứng trong suite).

### 17. Engine precheck — cổng tự kiểm trên artifact đã hoàn tất, sai là **crash build** (`src/core/precheck.js` mới; `src/core/pipeline.js:1604-1628`; `test-v590-precheck.js` mới)

Generator chứng minh bất biến trên code nó *viết ra*, nhưng body ship ra là sản phẩm của mangle → minify → JunkForge padding → callable bootstrap → diagnostic-blob pass. Precheck đọc lại **văn bản cuối cùng**: reparse bằng chính front end của engine, tự dẫn lại từng latch binding mà build tuyên bố, và **throw** khi artifact và metadata không khớp.

- **9 phép kiểm** (đánh số theo comment trong `src/core/precheck.js`): (1) artifact phải parse **sạch** bằng `parseDetailed()` — đếm `errors`, không tin `parse()` vì nó không bao giờ throw; (2) build tuyên bố `keyBedBound`/`guardKeyBound` thì region root phải đọc holder **được khai báo trước** trong cùng chunk (`KEY_SUM_PATTERN` + `declaredBefore`), và bind kép ⇒ root phải fold **đúng 3** addend; (3) verdict bind phải **bằng** `antiHookVerdict.expectedDigest` và có ≥1 lần đọc; (4) không còn template hole JS (`undefined`/`NaN`/`[object Object]`) trong code emit; (5) watermark engine phải khớp `ENGINE_VERSION`; (6) route virtualize không được để chuỗi hằng của user plaintext sót ngoài region (hiện là **notice**, xem bullet dưới); (7) trần size theo target; (8) census long-bracket literal đo được ≥ số forge container build tuyên bố; (9) route bật cipher phải publish một material root **tính ra được**, không phải hằng số.
- **Scan trên văn bản đã mask**: `maskNonCode()` blank comment/literal **giữ nguyên offset**, đồng thời đếm long-bracket literal nó đã ăn — cách đáng tin duy nhất, vì alphabet blob chứa `[` và `=` nên regex trên text thô sẽ đếm cả nội dung. Vì vậy blob 2 MB chứa từ nào cũng không kích hoạt check (4).
- **Phát hiện pass giả ngay trong lúc viết suite**: check (1) từng **vacuous** (`parse()` chưa bao giờ throw); check (5) từng **vô hiệu** vì quét trên text đã mask (watermark nằm trong string literal → bị blank, nên nó giờ quét text thô); check (9) từng chỉ cần sự **hiện diện** của xâu `G.materialRoot=` — crash ladder cũng viết đúng xâu đó, nên pin `G.materialRoot=0` lọt qua. Cả ba đã sửa và mỗi cái có fault-class riêng trong suite.
- **Notices, không phải fatal**: chuỗi plaintext còn sót ngoài region (keystream `#"中文"`, `select("#", …)` của engine glue) được ghi là notice — đo thật: 36/60 build `l1` từng bị **từ chối oan** vì để check (6) là fatal.
- **Đường `nest`**: body VM nằm trong encoded source loader, nên root và key bed không tồn tại ở cấp chunk này ⇒ check (9) báo `skipped:"nested-source-loader"` thay vì fatal (chiếu giới hạn `keyBedBound:false` của mục 14).
- **Cổng thật sự abort**: pipeline gọi qua `precheckModule.precheckArtifact(...)` (resolve lúc call, không destructure lúc require) — suite cài một verdict fail có chủ đích và xác nhận `obfuscate()` throw `ByteVeil v5.9 engine precheck failed (…): …`; opt-out `precheck:{enabled:false}` hoặc `precheck:false` thì `vmMeta.precheck` **không tồn tại** (không báo cáo rỗng).
- **Telemetry**: `vmMeta.precheck = {ok, fatal[], notices[], report}` với `report.bytes/reparsed/parseErrors/keySumReads/provenKeySumReads/templateHoles/versionStamps/plaintextLeaks/longBracketLiterals/forgeContainers/stringCipher{constants,cipheredBytes,rootAssignments,computedRoots}` — mọi con số precheck công bố đều **đo từ text**, không sao chép từ request.

### 18. Năm lỗi engine tìm ra được nhờ suite mới và nhờ chạy lại ma trận (không phải refactor trang trí)

- **Parser lẫn "dữ liệu" với "ngữ pháp"** (`src/frontend/parser.js`): `table.concat({"}", …})` — chính junk alphabet của engine sinh ra chuỗi có nội dung `}`, `)`, `end` — bị báo `Expected ), got }`. Nguyên nhân: các cổng ngữ pháp đọc `p(offset).value`, mà `value` của một string literal **là** nội dung chuỗi, nên `"}"` khớp `eat("}")`. Sửa tại một chỗ duy nhất: `Parser#value()` trả sentinel `"\0literal"` cho token `string`/`interpolated`; AST vẫn đọc literal qua `p()` nên **không đổi hợp đồng** nào. Kiểm chứng: 12 dạng câu có literal-granma (table key, call arg, concat, long-bracket, `for` control, `select("#")`) → `errors=[]`; sweep 17 ký tự × 3 ngữ cảnh → `bad=0`; regression vĩnh viễn trong `test-v590-frontend.js`.
- **Tùy chọn bị whitelist nuốt** (`src/core/pipeline.js:85`, `normalizeOptions`): `engineConfig()` là whitelist, nên `stringCipher` và `precheck` caller truyền vào **biến mất** trước khi tới backend — hai knob phải re-attach tường minh, và `stringCipher` phải plumbed qua `src/customVM.js` + `buildCustomVM` (2 điểm ở `pipeline.js:675`, `:848`).
- **Precheck vacuous / vô hiệu / quá chặt**: xem mục 17 bullet "Phát hiện pass giả" — ba lỗi này tự chúng là lý do suite tồn tại.
- **`wrapper:false` bị nuốt, opt-out thành no-op** (`src/core/pipeline.js:30-46`, `merge`): dòng cũ `wrapper: { ...(a.wrapper||{}), ...(b.wrapper||{}) }` — spread một boolean **không sinh key nào** (`{...(false||{})}` === `{}`), nên `{wrapper:false}` do caller truyền bị preset `enabled:true` đè lên. `wrap()` (module wrapper) vốn hiểu boolean, nên API **không nhất quán với chính nó** và người dùng tắt wrapper theo cách tự nhiên nhất thì vẫn nhận wrapper. Phát hiện khi chạy lại ma trận cross-route: bản v1 của probe truyền `wrapper` dạng boolean ⇒ **cả hai nhánh "wrap" đều thật sự được wrap**, 420 combo chỉ là 210 combo nhân đôi. Đã sửa bằng `wrapperSpec()` (boolean → `{enabled:…}`, object giữ nguyên, `true` không mất `argumentCount` của preset — `scratch/probe_wrapper_merge.js` in ra `old_bool=true / new_bool=false / new_true_keeps_preset_args=8`), kèm regression vĩnh viễn trong `test-v510.js`: hai cách viết opt-out phải cho output **giống nhau từng byte**, `vmMeta.wrapper.shape = "no-callable-bootstrap-tail"`, và cả ba build (on/off/object-off) vẫn chạy ra `42`. Bài học đo lường: một nhánh tham số không được engine xác nhận hình dạng thật thì **không phải** một chiều của ma trận.
- **`vmMeta.wrapper.shape` cáo buộc một sự vắng mặt mà nó không nhìn thấy** (`src/core/pipeline.js:1574-1589`, khối "Report the wrapper tail"): chính ma trận nói trên báo **30/30** combo `nest` + `wrap=on` (cả 2 target × 3 mode × 5 source) là `no-callable-bootstrap-tail`, tức "build này không có bootstrap". Probe đối chiếu (`scratch/probe_nest_wrapper.js`, seed `0x59A1`) cho thấy lời đó **sai**: `nest` wrap ON = **149,289 B** vs wrap OFF = **144,910 B**, `identical outputs: false`, `layers=5` — wrapper thật sự được áp, chỉ là nó bị **nhúng trong inner source đã mã hóa** của đường legacy, nên cả hai nhánh đều có `tailCalls=0 / callMetamethods=0 / colonDispatch=0` trong text ngoài. Heuristic chỉ quét **đuôi của chunk ngoài cùng** ⇒ hết `endsWith(")(...)")` là suy ra "không có bootstrap", trong khi cái nó thực sự biết là "không thấy ở đây". Đã sửa: khi `vmMeta.nestedObfuscation === true` **và** wrapper không bị tắt, shape báo `bootstrap-in-nested-source` (khác chuỗi `skipped:"nested-source-loader"` mà precheck dùng cho check (9) ở mục 17 — cùng hiện tượng, hai trường telemetry khác nhau); `no-callable-bootstrap-tail` chỉ còn cấp cho build **không** nest mà opt-out thật. Quét lại toàn bộ preset với seed `5151` (input `local v = 7 print(v * 6)`): `l1/l2/df/lz/default/maximum` = `colon-dispatch` với `nestedObfuscation=false`, **chỉ** `nest` = `bootstrap-in-nested-source` với `nestedRequiresDynamicLoader=true, layers=5` ⇒ nhãn mới không thể xuất hiện trên đường không-nest. Regression trong `test-v510.js`: `nest`+wrap → `bootstrap-in-nested-source`, `nest`+`wrapper:false` → `no-callable-bootstrap-tail`, hai output khác nhau; suite PASS exit=0, **8,283 ms** standalone (5,390 ms trước khi thêm hai build `nest`). Bài học: **telemetry chỉ được phép báo điều nó đo được** — "không thấy" và "không có" là hai claim khác nhau, và claim sai dễ tin vì nó trông như một con số trung thực.

### 19. JunkForge có thêm trần thứ ba: **ngân sách padding theo cỡ input** (`src/obfuscation/junk_forge.js`, `src/core/pipeline.js:1465`, `test-v590-forge.js` viết lại)

Mandate: input <100 KB ⇒ junk tối đa 400 KB (cả hai target); input ≥100 KB ⇒ 2 MB (lua) / 3 MB (luau).

- **Con số mandate được cài thành *ngân sách padding*, không phải trần file — và lý do là đo thật, không phải né yêu cầu.** Payload trần của chính engine đã lớn hơn mandate: input 64 KB preset `df` sinh **504,129 B** payload khi `junkForge:false` (đo: `node scratch/probe_junk_caps.js` × input 16/64/100 KB, seed `0x59C0DE`). Một trần **400 KB trên file** sẽ abort mọi build từ ~50 KB source trở lên, tức là làm hỏng build chứ không giới hạn junk. Vì vậy 400 KB / 2 MB / 3 MB áp lên **riêng khối padding** (`paddingCapBytes`), còn `OUTPUT_CAP_BYTES` (2.5 MB lua / 3 MB luau) vẫn là trần **tổng** không đổi — không build nào đang pass bỗng throw vì thay đổi này.
- **Hằng số mới** (`src/obfuscation/junk_forge.js`, export để suite đọc chứ không hardcode): `SMALL_INPUT_BYTES = 100_000`, `SMALL_INPUT_PADDING_CAP_BYTES = 400_000`, `LARGE_INPUT_PADDING_CAP_BYTES = {lua: 2_000_000, luau: 3_000_000}`, `PADDING_CODE_MARGIN_BYTES = 16_384`; hàm chọn trần `paddingCapFor(target, inputBytes)`.
- **`PADDING_CODE_MARGIN_BYTES` là chỗ phải đo mới thấy.** Vòng top-up của `emit()` tự canh bằng overhead của **seal trước**, nên round cuối luôn vượt: bản đầu đo được **400,781 B** padding cho một build trần 400 KB — vượt chính ngân sách nó nhân. Sau khi chừa 16 KB inside budget, padding thật rơi vào **384,392 – 384,547 B** trên mọi cell bị cắt (xem bảng VERIFIED).
- **Trần tính theo *input*, không theo body lúc forge.** `pipeline.js` ghi `opts.junkForgeSourceBytes = Buffer.byteLength(source,"utf8")` ngay khi resolve target, vì tới lúc `applyJunkForge` chạy thì body nó nhận đã là payload VM **gấp 5–40 lần** source. Nếu đọc độ dài lúc forge thì mọi build đều bị xếp vào nhánh "input lớn".
- **Lỗi thật tìm ra khi viết lại suite: `Number(null) === 0.**` `planJunkForge({inputBytes = null})` gọi `Number(inputBytes)` ra `0`, `0 < 100_000` thành true ⇒ **mọi** build vẽ ngân sách 400 KB kể cả input lớn. `test-v590-forge.js` bắt được ngay (`actual: 400000, expected: 2000000`, dòng 299). Sửa: kiểm `inputBytes === null || undefined` **trước** khi fallback sang `options.junkForgeSourceBytes`. Kiểm lại cả năm đường vào: `explicit` / `options` / `no-info` / `luau` / `override` → `2,000,000` / `2,000,000` / `2,000,000` / `3,000,000` / `123,456`.
- **Telemetry mới, hai chiều đều đo được:** `vmMeta.junkForge.paddingCapBytes` và `capBinding` — `"junk-budget"` khi ngân sách padding là thứ cắt, `"output-envelope"` khi trần file mới là thứ cắt, `null` khi build đạt floor mà chưa bị cắt. `emit()` và `noop()` đều báo `paddingCapBytes`; `applyJunkForge` tính `roomBytes = min(envelopeRoom, budget − margin)` và tự suy ra `capBinding` thay vì để caller đoán.
- **Suite viết lại để không tự lừa mình (`test-v590-forge.js`):** mọi ngưỡng đọc từ hằng số module; mỗi cell phân nhánh theo **`reachable = min(base + budget − margin, envelope − headroom)`** — nhánh không bị cắt yêu cầu `partial:false` / `capBinding:null` / `status:"in-target"` / byte nằm trong dải floor, nhánh bị cắt yêu cầu `partial:true` / `capBinding:"junk-budget"` / `bytes < floor` / `paddingBytes ≥ budget − 4×margin`. Section 2 tách cell thành `completed`/`clipped` (chỉ sắp xếp thứ tự kích thước trên cell đã hoàn tất, cell bị cắt chỉ bị ràng buộc bởi dải spread ≤ `8×band`) và có change-detector trên **sáu** hằng số mandate. Section 3 sinh source **thật** dưới/ngưỡng bằng `filler()`, không truyền override, và asserts từng build tự báo đúng ngân sách + `paddingBytes ≤ paddingCapBytes` + `bytes ≤ OUTPUT_CAP_BYTES.lua` + `vmMeta.precheck.ok === true`.

### 20. VeilBlob sinh container **đóng sớm** trên artifact lớn — một blob hợp lệ nhưng file ship ra sai cú pháp (`src/obfuscation/veil_blob.js`, `test-v590-blob.js` §2b)

- **Triệu chứng đo được trước khi hiểu nguyên nhân:** source 99 KB preset `df` cho artifact mà `lua54.exe` báo `unexpected symbol near ']'` và front end của chính engine báo **4 diagnostic tại line 2, cột 648264**, ngữ cảnh `…ugFL]==]==]`. Engine precheck (mục 17, check số 1) **abort build** — đây là cổng precheck làm đúng việc của nó, nhưng lỗi nằm ở generator chứ không phải ở input.
- **Nguyên nhân:** `pickBracketLevel()` chỉ tìm close-delimiter **bên trong** text. Một blob kết thúc bằng `]==` ghép với closer `]==]` tạo thành `]==]==]`, và Lua tìm thấy closer **sớm hơn 3 byte** so với delimiter thật ⇒ literal đóng ngay giữa ciphertext, phần còn lại (`==]`) là cú pháp rác nằm ngoài literal. Kiểm tra "closer không xuất hiện trong text" là **điều kiện sai** cho bài toán này vì chỗ ghép chỉ tồn tại ở **biên**.
- **Sửa:** `if (`${text}${closer}`.indexOf(closer) === text.length) return level;` — tức closer phải xuất hiện **duy nhất tại đúng vị trí cuối**, kèm comment ghi rõ overlap `]==` + `]==]`.
- **Bằng chứng sửa:** `scratch/probe_bracket_level.js` round-trip container trên native → **14/14 ok**, exit 0; build lại đúng artifact 99 KB `df` → **0 diagnostic**. Regression vĩnh viễn trong `test-v590-blob.js` §2b: **7** đuôi đối kháng (`x]==`, `a]==]`, `ok]==`, `==]==]`×3, 200×`q`+`]==`, marker+`payload]==`) — mỗi cái assert closer chỉ khớp tại biên, `pickBracketLevel` khớp level đã emit, và **load thật trên cả Lua 5.4 lẫn Luau** (`print(#value)` phải trả đúng số byte); cộng fuzz đường ship **4 seed × 48 độ dài × 3 byte rác (`]`, `=`, `[`) = 576 container**, không cái nào được đóng sớm và mọi cái decode đúng từng byte. Suite PASS, exit 0, **2m04.541s** standalone.

### 21. BAND/BOR dẫn xuất từ đúng một primitive xor đã avouch — sửa lỗi **kết quả khác nhau giữa hai host**, không phải lỗi tốc độ (`src/compiler/stack/vm_generator.js:2367-2368`, `src/compiler/register/reg_vm_generator.js:121-122`, `test-v590-bitops.js` mới)

- **Điểm yếu:** handler BAND/BOR cả hai route viết `bit32 and bit32.band and bit32.band(A,B) or (function() …32 vòng… end)(A,B)`. Hai hậu quả: (a) trên host **có** `bit32` (Luau/Roblox/FiveM) nó bị gọi **raw**, mà raw thì truncate-hướng-zero; (b) trên host **không có** (Lua 5.4 thuần) mỗi lần thực thi là một **closure mới + 32 vòng div/mod**.
- **Đó là lỗi đúng/sai, đo trên binary thật:** `bit32.band(-0.5, 1)` trên `luau.exe` trả **0**, còn đường 32-round floor trả **1**; `bit32.bor(-0.5, 1)` trả **1** so với **4294967295**. Và `(-0.5) & 1` trên `lua54.exe` **exit 1** (Lua 5.4 từ chối bit op với số fraction) — nên "cứ dùng toán tử host" không phải phương án. Cùng một artifact trả lời ba cách khác nhau tùy host.
- **Sửa:** dẫn xuất trên domain floor-first 32-bit — `a&b = floor((a+b-(a^b))/2)`, `a|b = a+b-(a&b)` — dùng đúng `${N.xor}` đã được 16-vector avouchment battery kiểm tra trên chính host. `math.floor` bao phép chia là **bắt buộc**: `/` của Lua 5.4 luôn ra float, nên bản chưa floor in `2.0` thay vì `2` (chính `scratch/probe_bitops_e2e.js` bắt được).
- **Identity được chứng minh, không đoán:** `scratch/probe_bit_derive.js` — boundary/fractional/negative + lưới exhaustive 1000×1000 + 2 triệu cặp ngẫu nhiên = **3,000,120 cặp, 0 mismatch**.
- **Vì sao không viết chooser riêng cho band/bor:** splitter payload-carrier v4.7.9 cắt chunk này thành các bootstrap stage theo **line index cố định** và chỉ re-export một tập primitive có tên qua context table. Thêm local mới ở prologue hoặc là lệch index (stage sau tham chiếu sang dòng sai), hoặc vô hình với stage sau. Cả hai đều **fail tại run time**: bản thử nghiệm thật chết bằng `attempt to get length of a nil value (global 'p8rL')` trong `decodePayloadCarrier`, tái hiện có kiểm soát bằng `scratch/band_toggle.js` (PRE = chạy OK). Dẫn xuất giữ layout stage **byte-stable** — đó là lý do kỹ thuật, không phải lựa chọn thẩm mỹ.
- **Đo A/B — kết luận thành thật: KHÔNG phân giải được bằng wall-time.** `scratch/ab_build.js` + `scratch/bit_toggle.js` (build hai bộ artifact, chỉ khác đúng 4 handler) + `scratch/probe_ab_interleaved.js` (xen kẽ new/base trong cùng tiến trình, đổi thứ tự mỗi round, min): `bitheavy` lua **−9%** (5 rounds) rồi **+28%** (9 rounds), luau **+14%** rồi **−6%** — dấu đảo giữa hai lần chạy. Control **không có bit op nào** cùng bàn chạy đó dao động **−8%…+31%** (5 rounds) và ±5–7% (9 rounds). Vậy số đo nằm trọn trong noise; **không claim speedup**. Con số giải thích tại sao: 32 vòng modulo/division chỉ cỡ 256 phép toán Lua thuần ≈ **8 µs**, trong khi chi phí per-op của interpreter đã đo ở LIMITATIONS là **≈320 µs** — band/bor nằm dưới noise một cách có thể tính trước. Chi phí thật nằm trên đường **xor chia sẻ** (mọi lệnh đi qua mix/guard), và chính đường đó đã cho **−51% lua / −23% luau** ở phép đo A/B trước.
- **Cái được thật, đo deterministic (không phụ thuộc noise):** (1) artifact trả lời **giống nhau trên cả hai host** cho mọi operand trong corpus — 4 cell (stack/register × lua54/luau) in cùng một đáp án; (2) chunk ship ra **không còn** vòng 32-round cho band/bor: đếm trên artifact `for _=1,32` đi từ **2 → 0**, số tham chiếu `bit32` từ **20 → 8** (còn lại là rung `bit32.bxor` của chooser và SHL/SHR chưa đụng tới).
- **Suite vĩnh viễn:** `test-v590-bitops.js` — structural (không còn loop/raw `bit32.band(`/`bit32.bor(`,chooser vẫn có `bit32.bxor` và thân dẫn xuất `/2)`) + semantics (23 biểu thức + 1 vòng lặp 200 lần, đối chiếu floor-first oracle, 4 cell phải trùng nhau) + **counterfactual** (raw `bit32.band/bor` trên `luau.exe` phải **khác** oracle, `(-0.5) & 1` trên `lua54.exe` phải **lỗi**) — chứng minh điều đang sửa là có thật. exit 0, **14.9 s** standalone, là suite thứ **20** của gate.
- **Chưa đụng tới (khai báo ở LIMITATIONS):** SHL/SHR vẫn `bit32.lshift/rshift` raw + fallback số học, vì semantics truncate của `bit32` khác floor của đường fallback và **chưa chứng minh được** là tập input của chương trình đã biên dịch luôn rơi vào phần hai đường trùng nhau; `src/vm/vm_island.js:207` và hai route legacy `buildGeneratedSource` (stack/reg) vẫn còn 32-round loop nhưng **không tới được** từ `obfuscate()` ở 5.8.0 (`customVM` → `buildGeneratedSourceV40` → `buildV452GeneratedSource`; island chỉ `src/backend/source_engine_luau_v270.js` require, và module đó chỉ `test-v270.js` dùng).

### 22. Tên định danh do engine sinh ra có thể **viết đúng chữ `NaN`** — precheck abort một build hợp lệ (`src/utils/lua_identifier_rewriter.js:170-195`, `src/wrappers/bootstrap_renderer.js:35-52`, `scratch/probe_name_hole.js`)

- **Triệu chứng:** `obfuscate()` trên source có vòng bitwise (`acc = ((acc + i) & 65535) | (i & 255)`), seed `0x59c0de`, stack: **`engine precheck failed (1): template hole(s) NaN leaked into the emitted code`**. Nhưng artifact build với `precheck:{enabled:false}` **chạy đúng trên cả hai host** và in `29423` khớp oracle ⇒ đây là **báo động sai của cổng**, không phải artifact hỏng.
- **Nguyên nhân:** `mangleGeneratedInternals` đổi tên internal `__bv_*` sang định danh **2–4 ký tự** `[A-Za-z][A-Za-z0-9]{1,3}` — nên `NaN` nằm trong không gian tên. Cổng precheck tìm hole bằng regex text thuần `\b(undefined|NaN|\[object Object\])\b`, không phân biệt "giá trị JS lọt xuống" với "cái tên tình cờ trùng". `makeIdentifierFactory` của wrapper cũng cùng hình dạng 2–4 ký tự ⇒ cùng rủi ro. `src/mangler.js` và `v38Id` thì vô sự (mở đầu bằng `_`, dài 7–16).
- **Sửa:** loại tên viết thành `NaN`/`undefined` tại **cả hai** chỗ sinh tên (vòng thử lại + nhánh fallback), **giữ nguyên** pattern của precheck — nới cổng để build thông là đúng hướng ngược lại.
- **Đo trước/sau trên chính generator** (`scratch/probe_name_hole.js`, strip đúng phần loại trừ khỏi bản sao module để lấy số "trước"): 5000 seed × 60 internal = **300,000 tên sinh ra**; **trước: 9 tên hole-shaped** (≈1/33,000 tên — một build đổi hàng trăm tên nên xác suất gặp là hữu hạn, đó là lý do nó vượt qua mọi corpus cũ); **sau: 0**. Dải độ dài tên vẫn **2–4** ⇒ không cắt giảm entropy/độ dài tên, chỉ loại 2 chuỗi cố định.
- **Hồi quy vĩnh viễn:** source gây lỗi ở trên giờ là một trong hai corpus của `test-v590-bitops.js`, nên mạch tên-này-đặt-tên-trong-vòng-lặp được build thật mỗi lần gate chạy.

### 23. Bump ENGINE_VERSION 5.8.0 → 5.9.0: `"5.8.0"` là **discriminator định tuyến**, không phải nhãn

- **Vì sao dễ hỏng:** khoảng **90 chỗ** trong `src/` so sánh tag version (`hardeningVersion`, `runtimeVersion`, `vm.structural?.version`, `packed.hardeningVersion`, các set/array tag hợp lệ) để chọn hình dạng payload. Caller cũ vẫn pin tag cũ (`test-v479.js` assert `vmMeta.version === "5.5.0"`), nên bump đúng là **THÊM** `"5.9.0"` vào mỗi phép thử thành viên, chứ không được **THAY** nhãn cũ.
- **Cách làm:** `scratch/version_bump_apply.js` (95 ops) + `scratch/version_bump_release_files.js` (33 ops), mỗi op line-scoped và **assert trước khi sửa** (đếm số lần khớp, sai là abort). Metadata gắn nhãn version được cho **nhánh riêng** (`isV590`/`v590` trước `isV580`/`v580`) để `PAYLOAD_LAYOUT`, `shadowArchitecture`, `generatorEngine`, `dispatchStyle`, `v471Label` in đúng 5.9 thay vì mượn nhãn 5.8.
- **Chuẩn bị trước khi sửa:** snapshot **42 artifact** (6 preset × 2 target × 3 source, register thêm cho `l1`, `junkForge:false`, seed cố định) chạy **hai lần** để chứng minh build deterministic (sha256 lặp lại) — `scratch/version_snapshot.js`, `scratch/vsnap/before1|before2`.
- **Chứng minh sau khi sửa:** `scratch/version_bump_diff.js` normalize đúng 6 nhãn hợp lệ (`v5.8-shared→v5.9-shared`, `-v58-shared→-v59-shared`, `shared-handler-core-v58→v59`, `mfg-5.8.0→mfg-5.9.0`, `MFG-5.8.0→MFG-5.9.0`, `5.8.0→5.9.0`) rồi so **byte**: **36/42 trùng tuyệt đối**; 6 cell `nest` khác trong vùng payload đã mã hoá, vì `nested_obfuscation.js:645/649` thay `v${version}` vào **source bên trong** trước khi encrypt ⇒ byte khác là tất yếu, không thể normalize từ ngoài.
- **Bằng chứng thật sự là thực thi:** `scratch/version_run_parity.js` chạy **84/84 cell × host** (`lua54.exe`, `luau.exe`) — stdout **0 khác biệt** trước/sau bump.
- **Cổng chống tự nói dối:** `src/core/precheck.js` so watermark in ra với `ENGINE_VERSION` (`record("version-stamp", …)`, fatal khi lệch) và 7 suite assert `ENGINE_VERSION === packageInfo.version`, nên không thể bump một nửa. Chu kỳ này chính cổng đó **bắt** ba expectation chưa đổi (`test-v580.js:335`, `test-v510.js:103`, `test-v479-bot.js:206` — gate FAIL 3 suite, exit 1), sửa xong gate xanh lại; đó là bằng chứng cổng chạy được, không phải bằng chứng tôi tự nhận.
- **Version string không đi vào seed/digest:** probe trên toàn `src/` trả **0 chỗ** chuỗi version tham gia material → bump không làm đổi khoá, đổi dispatch, đổi chi phí.

### 24. Cách ly 37 engine lôi thời ra khỏi `src/`, và gate **không cho quay lại** (`legacy/`, `test-v590-tree.js` mới)

- **Điểm weakness:** `src/` có **112** file nhưng chỉ **75** tới được từ `obfuscate()`. 37 file còn lại là **cả một thế hệ engine cũ** (`src/backend/source_engine_luau_v270.js` + `src/vm/vm_island.js`, `src/backend/lua_engine.js`, `src/compiler/stack/vm-gen.js`, `src/compiler/register/reg-vm-gen.js`, `src/runtime/vm-runner.js`, `src/analysis/*`, `src/vm/index.js` + cluster decoder/dispatcher, `src/core/options.js`, `src/core/diagnostics.js`, `src/wrappers/index.js`…). Chúng không làm chậm artifact nào cả, nhưng làm **người đọc không phân biệt được code nào authoritative** — và một lần refactor bất cẩn có thể nối lại đường chạy vào engine cũ.
- **Tính chắc chắn của phép đo:** scan require **tĩnh**, và một probe riêng (`scratch/engines_dynamic_requires.js`) chứng minh **toàn `src/` có 0 dynamic require / 0 template require** ⇒ không tồn tại đường nào kéo file "unreachable" vào lúc chạy. Con số 37 do đó là **đo được**, không phải ước lượng.
- **Sửa (không xoá):** `scratch/engines_quarantine.js` move đúng 37 file sang `legacy/src/<đường-dẫn-cũ>` và **rebase 32 specifier** (`./x`, `../customVM` → trỏ vào `src/` thật). Chọn cách ly thay vì xoá vì tree **không có git**, xoá là mất vĩnh viễn; legacy/ vẫn **parse được** (suite assert bằng `vm.Script`), vẫn chạy được từ 4 test lịch sử qua `npm run test:legacy:engines`.
- **Test cũ theo sau:** `test-v25/v25-instrument/v270/v280/v281` trỏ require sang `./legacy/src/...`. **Đo trạng thái trước và sau khi move: cùng một lý do fail** — `test-v281` PASS; `test-v25`/`v25-instrument` exit 1 `strict v4.6 path missing`; `test-v270` exit 1 strict-equal; `test-v280` exit 1 `df/lua should use the clean direct wrapper`. Ba test này đã **hỏng từ trước** (chúng assert hình dạng route v2.x/v4.6 mà engine hiện tại không đi), và **không** phải suite của gate.
- **Bất biến vĩnh viễn** (`test-v590-tree.js`, suite thứ **21** của gate): (1) mọi file dưới `src/` phải nằm trong closure require từ `src/index.js` — **0 orphan**, hiện **76/76**; (2) **không** file nào trong `src/` require vào `legacy/` — **0**; (3) mọi file `legacy/` vẫn parse — **37/37**; (4) mọi key trong preset phải thuộc registry và không được là key đã retired; (5) mỗi key đã đăng ký phải có **ít nhất một chỗ đọc** trong `src/` (ngoài chính registry/preset/env) — thêm một key trang trí là gate đỏ ngay.
- **Byte-neutrality có đo, không tuyên bố:** baseline **24 cell** (6 preset × 2 target × 2 modes, seed `0x59c0de`, `junkForge:false`) sha256 **24/24 trùng**, **0 khác** trước/sau cách ly + dọn preset (`scratch/knob_baseline.js`).

### 25. Knob "stub": 5 option **không đọc gì cả** — chứng minh bằng byte, rồi bắt buộc khai báo (`src/core/option_registry.js` mới)

- **Điều tra:** kiểm kê toàn bộ key mà `obfuscate()` nhận (normalizeOptions + preset + `engineConfig` whitelist) và tìm chỗ đọc thật sự. Kết quả **5 key chỉ được định nghĩa, không module nào đọc**: `transforms.gsubAnchor`, `transforms.payloadDecoys` (có mặt trong **cả 6 preset**), `nestedSourceEngine` (preset `nest`), `debug`/`ENGINE_DEBUG` (whitelist `engineConfig`), `explicitVmPolicy` (gán rồi bỏ đó).
- **Chứng minh bằng đo, không bằng đọc code:** `scratch/knob_noop_probe.js` — 8 build cell × từng probe, `gsubAnchor:true` vs `false`, `payloadDecoys:5` vs `0`, `debug:true` vs absent, và một key bịa `zzzUnknownKnob`: **6/6 probe cho ra artifact sha256 giống hệt nhau trên cả 8 cell ⇒ INERT**. Root cause cụ thể: `pipeline.js:1315-1317` hardcode `gsubAnchor:false, decoys:0` vào shell của compat route, và `src/backend/source_engine_v46_compat.js` **không cài đặt** hai tham số đó (grep: 0 khớp) — nên thậm chí không có gì để "wire".
- **Sửa theo hướng trung thực:** key nào không có đường cài đặt thì **bỏ khỏi preset** và **từ chối build** khi caller yêu cầu nó với giá trị bật (`ByteVeil v5.9.0 option transforms.payloadDecoys is not implemented (…)`). Giá trị falsy (`debug:false`, `payloadDecoys:0`) vẫn build bình thường ⇒ script cũ không chết vì một giá trị vô hại. `explicitVmPolicy` bị xoá luôn (dead assignment, 0 chỗ đọc), `debug` bị xoá khỏi whitelist `engineConfig` (đo `.env`: **không** có `ENGINE_DEBUG` đang đặt giá trị, nên không phá vỡ cấu hình thật nào).
- **Option lạ không còn im lặng:** `result.optionAudit.notApplied` liệt kê mọi key không thuộc registry (`antiDumpV9`, `transforms.mysteryRate`, …), và `strictOptions:true` biến danh sách đó thành **throw**. Mặc định không throw để không phá pipeline đang chạy của user — nhưng không còn chuyện "gõ sai tên knob thì build vẫn xong mà yếu hơn".
- **Còn mở tại thời điểm đó (đã đóng ở mục 26):** `backend` không được validate tập giá trị — `opts.backend` chỉ so với `vm35`/`vm33` tại `pipeline.js`, mọi giá trị khác **đi thẳng sang source fallback** (route yếu hơn) mà không có cảnh báo nào; `target` sai chính tả thì âm thầm rơi về `auto` (`target.js:18-21`). Registry lúc đó chỉ **báo cáo** key lạ chứ chưa **từ chối** giá trị lạ. Mục 26 đóng cả hai bằng tập giá trị đóng + đo 269 điểm gọi thật.

### 26. Khóa **im lặng xuống cấp** bằng tập giá trị đóng: 4 key giờ từ chối build trước khi có route yếu (`option_registry.ENUMS`, `src/core/luau_sanity.js`, `src/core/pipeline.js`)

- **Vấn đề còn lại sau mục 25:** registry chặn *key lạ*, nhưng không chặn *giá trị lạ*. `pipeline.js:1503` chỉ so `opts.backend` với `vm35`/`vm33`; `target` sai thì `target.js:18-21` rơi về auto; `mode` sai thì normalize map về register; `wrapper.returnMode` chỉ có hai nhánh thật (`setmetatable`, `gsub`) nên mọi chuỗi khác cho ra hình dạng **direct**. Tức là gõ sai một ký tự vẫn có artifact, chỉ là artifact đi route khác — đúng class lỗi user yêu cầu đóng.
- **Tập giá trị không đoán, mà đo:** `scratch/probe_option_enum_values.js` quét **tĩnh 201 file**, cắt ngoặc khớp để tìm **269 điểm gọi `obfuscate(`** thật và ghi lại từng giá trị literal: `mode` {`stack`×56, `register`×32, `hybrid`×1}, `target` {`lua`×144, `luau`×24, `auto`×4}, `backend` {`vm33`×8}, `wrapper.returnMode` {`setmetatable`×8}, `nestedProfile` **0** (không ai từng truyền). `ENUMS` đúng bằng tập đó cộng route mà engine thật sự có: `backend` {`vm35`,`vm33`,`source`}, `target` {`auto`,`lua`,`luau`}, `mode` {`stack`,`register`,`hybrid`}, `wrapper.returnMode` {`setmetatable`,`direct`,`gsub`}.
- **Message nói rõ route nào đã bị nuốt:** ví dụ `ByteVeil v5.9.0 option backend has unsupported value "vm36" (accepted: vm35, vm33, source); vm35 and vm33 run the shipped custom VM, source builds the source-container route; anything else silently downgraded the build and skipped the guard/JunkForge key binding`. `nestedProfile` dùng thông điệp "not implemented" như 5 knob ở mục 25.
- **`nestedProfile` bị retire (không phải bị validate):** probe `scratch/probe_nested_profile.js` build **6 route cell** (`l1`, `lz`, `compatibilityRoute`, `backend:"source"` × 2, preset `nest`) × {`full`, `balanced`, absent}: **distinct=false trên cả 6 cell ⇒ INERT**. Root cause thấy được bằng code đọc có kiểm chứng: `customVM.js:475-482` gán `chosenNestedProfile` theo **version VM**, không theo caller, và với các version đang ship (4.7.6…5.9.0) nó là hằng `"binary-region-no-source-loader"`; nhánh `nest` thì hardcode `full`. Bằng chứng mặt report: `vmMeta.nestedProfile` in ra **cùng một chuỗi dài** cho `l1`, `lz` và `nest`, còn `"legacy-wrapSource-v4.7.4"` chỉ xuất hiện ở `stats.nestedSourceEngine` của `nest` — tức nó là **nhãn output**, chưa bao giờ là **đầu vào chọn được**. Xóa key khỏi `TOP_LEVEL` + preset `nest`, thêm vào `RETIRED`.
- **`wrapper.returnMode`/`setmeta`: knob "sống" vẫn có thể là stub.** `returnMode` được đọc thật (`WrapInFunction.js:285-299`) nhưng `env.js:50` luôn đặt `setmeta` mặc định `true`, và `setmeta:true` **thắng** `returnMode:"direct"` ⇒ truyền vào đúng tên giá trị mà artifact trả về **giống hệt mặc định** (đo: 70,792 B, sha trùng). Sửa bằng quy tắc caller-thắng trong `normalizeOptions` (`pipeline.js:74-75`): `{setmeta:false}` không kèm `returnMode` ⇒ `direct`; `returnMode:"direct"` ⇒ ép `setmeta:false`. Bốn hình dạng đo được (seed `0x59c0de`, `l1`/lua, `junkForge:false`): mặc định `callable-object` **70,792 B**, `gsub` **67,858 B**, `direct` **67,852 B**, wrapper tắt **67,823 B**; `{setmeta:false}` và `{returnMode:"direct"}` cho ra **byte-identical** (sha `c739fdc689e78902…`) ⇒ hai tên, một shape — assert trong suite.
- **Nhãn shape mới để báo đúng:** `direct` kết thúc bằng `end)(...)` chứ không `})(...)`, nên phép thử cũ `endsWith("})(...)")` gọi nó là `callable-object` (báo sai: không có bootstrap table nào cả). `pipeline.js:1599-1606` thêm nhãn **`direct-callable-tail`**; vocabulary `vmMeta.wrapper.shape` giờ là {`colon-dispatch`, `callable-object`, `direct-callable-tail`, `bootstrap-in-nested-source`, `no-callable-bootstrap-tail`}.
- **Sửa một route thật sự hỏng — `src/core/luau_sanity.js`:** scanner cũ chỉ nhận long bracket **cấp 0** (`[[ … ]]`), trong khi mọi artifact hiện tại chứa `[==[` và `[#[` (VeilBlob + carrier). Bằng chứng tái hiện (`scratch/probe_luau_scanner_before.js`: dựng lại scanner cũ, giữ nguyên thuật toán delimiter của bản shipped): `vm l1/luau` 70,709 B → **FAIL `unbalanced delimiter near ']'`**; `vm nest/luau` 151,625 B → **FAIL `near ')'`**; `source container/luau` 29,456 B → **FAIL `near '}'`** — cả ba **pass** với scanner mới. Hệ quả thật: cổng Luau từng **từ chối chính artifact nó đang ship** và làm abort cả suite khi `backend:"source"` + `target:"luau"` được gọi. Scanner mới đọc `longBracketLevel()`/`skipLongBracket()`: opener `[` + N `=` + `[`, closer phải là `]` + **đúng** N `=` + `]` (bản đầu tiên của tôi chấp nhận cả `]==x` và vẫn nổ `near ']'` — đã sửa và đo lại).
- **Byte-neutrality:** baseline 24 cell sha256 **24/24 trùng, 0 khác** sau toàn bộ mục 26 (`scratch/knob_baseline.js` → `scratch/vsnap/knob_baseline_*.json`), và 5 hash route `backend:"source"` trước/sau thay đổi trùng từng ký tự (`scratch/vsnap/source_route_luau.log`).

### 27. Route nguồn không còn **xưng là VM**: nhãn runtime, engine kép và report wrapper (`src/core/pipeline.js`, `test-v590-tree.js` mục 4d)

- **Nhãn sai thật:** `buildSourceFallback()` trả `runtime: "Luau custom VM"` / `"Lua 5.1-5.5 custom VM"` trong khi chính kết quả đó có `bytecode:null` và `vmMeta.fallback:true` — tức báo một cái VM không tồn tại (route VM thật ở `pipeline.js:994` vẫn giữ nhãn đúng, đã phân biệt trước khi sửa). Nay route nguồn lấy nhãn từ **engine đã build nó**: `sourceEngine.runtime` ⇒ `"Lua 5.1-5.4 compatibility runtime"` / `"Luau compatibility runtime"`, và `validation.runtime` dùng cùng một biến để không thể lệch nhau. Không test nào từng assert hai chuỗi cũ (grep toàn suite: chỉ `test-v26.js` so nhãn của module resolve-target), nên sửa không phá expectation.
- **"Engine Luau riêng" là alias của một engine duy nhất:** `pipeline.js:12-13` require **cùng một** `source_engine_v46_compat` hai lần với hai tên (`buildLuaSourceEngine`, `buildLuauSourceEngine`), và bên trong engine đó `target` chỉ xuất hiện ở **một** dòng — `source_engine_v46_compat.js:170` chọn nhãn `runtime`. Đã gộp thành một `buildCompatSourceEngine` kèm comment, để tên biến không hứa một route không có. **Đo chứ không suy:** `backend:"source"`, cùng input, hai target ⇒ **byte-identical** (29,686 B, sha `8305d8b67909056e…`), nên `target` trên route này chỉ đổi nhãn + bước `minify` (bản thân bước đó là identity trên output của engine, cũng đo bằng byte). Nhánh `isLuau` giữ nguyên hành vi cũ.
- **`vmMeta.wrapper` phải phân biệt được "wrapper tắt" và "wrapper kiểu gsub":** cả hai kết thúc bằng đuôi không callable nên cùng nhận nhãn `no-callable-bootstrap-tail` — report không cho caller biết knob có được áp dụng không. Block report (`pipeline.js:1601-1612`) giờ kèm `enabled` và `returnMode` (selector đã cấu hình), `shape` vẫn là **đuôi thật đã phát ra**. Suite khóa cả hai mặt: gsub-on và off **cùng shape** (chứng minh va chạm là có thật) nhưng **khác `enabled`**.
- **Cổng mới (mục 4d của `test-v590-tree.js`):** với mỗi host, `backend:"source"` phải có `bytecode === null`, `vmMeta.fallback === true`, `runtime` khớp `/compatibility runtime$/`, **không** chứa `"custom VM"`, `validation.runtime === runtime`, và hai target cho ra output bằng nhau. Suite này fail nếu ai đó nối lại nhãn cũ.
- **Điều tra ra một giới hạn mới, chưa sửa (khai ở LIMITATIONS):** preset `l1` với `x: number`, `continue`, backtick interpolation thì cả hai route đều build; nhưng `local x = if a then … elseif b then … else …` thì **VM route từ chối** (`parser error: Expected else, got elseif`) trong khi **source container nhận** (29,729 B) — khoảng trống ngữ pháp Luau của frontend, không phải lỗi route.

### 28. VM xử lý **nhiều giá trị trả về ở vị trí giãn**: `{f()}`, `{...}`, `{table.unpack(x)}` (`src/compiler/bytecode.js:96-200`, `src/compiler/register/register_compiler.js:100-230`, `test-v590-multiret.js` mới)

- **Lỗi trước khi sửa, đo trên host thật:** mọi vị trí giãn đều bị cắt còn 1 result ⇒ artifact in `#{g3()} = 1` khi native in `3`; `print(fmt(idn(1,2,3)))` đưa `1|nil|nil` thay vì `1|2|3`; `return g3()` mất result của callee; `{holes()}` (return `1, nil, 3`) mất hole nên `#` và `t[3]` sai luôn. Đây là class lỗi user báo (mục 4 chương trình v6), không phải biên lệ tẻ: `{...}` trong function vararg là idiom hằng ngày của Roblox/FiveM.
- **Hai opcode carrying, và ISA khoá đúng ở 64/64:** `CALLP` dựng **toàn bộ** danh sách result thành pack `{n=<count>,[1..n]=…}` — giữ nil lỗ và cả trường hợp 0 result; `APPEND` ghi pack đó vào bảng tại ranh giới mảng tường minh của constructor. `OPS` trong `src/obfuscation/isa_engine.js:10` kết thúc bằng `…,"SUPER","CALLP","APPEND"` = **64/64**, và `test-v479-tail-return.js:10` assert `OPS.length <= 64` (6-bit physical opcode). Hệ quả thật, khai luôn ở mục 29: **không còn slot** cho một `SETLIST` đúng nghĩa, nên phần pre-size mảng của constructor phải đi nhờ `NEWTABLE`.
- **Vị trí giãn được nhận diện theo Lua, không theo sự tiện của compiler** (`expandableTail`, `bytecode.js:188` / `register_compiler.js:183`): chỉ **field cuối** ở list-position, **arg cuối** của call, **value list** của `return`, và vế phải của multi-assignment được giãn; `(f())` có ngoặc thì `singleResult === true` ⇒ cắt còn 1; `[k] = f()` thì không giãn. Suite pin **cả hai nửa** (giãn chỗ Lua giãn, cắt chỗ Lua cắt) vì một nửa đúng vẫn cho ra output sai ở nửa kia.
- **`RETURN` phải tự khai số result:** dạng instruction trong payload có bản pad operand bằng `0` tường minh (`vm_generator.js:1353` `packInstruction`, form `t=7`/`t=9`), nên `#instruction` **không** phải độ dài VM được phép tin. Register `RETURN` nhận thêm operand COUNT (`reg_vm_generator.js:143`), compiler phát ra count thật, và `permuteRegisterOperands` có nhánh riêng cho `CALLP`/`APPEND`/`RETURN`. Đây là bug do chính patch trước tạo ra (`print(f(1,2))` in thêm một `nil` ở register mode) và bắt bằng chứng chạy thật, không bằng đọc code.
- **Metadata đi kèm để không ai đoán sai arity:** `STACK_ARITY.CALLP: 4`, `APPEND: 1`, `REGISTER_ARITY.CALLP/APPEND` giữ nguyên hình dạng; `operandNames` khai tên từng operand cho cả hai mode; `src/ironbrew/validator.js` validate stack/register prefix theo đúng bảng đó.
- **Bằng chứng (`node test-v590-multiret.js`, exit 0):** **36 case pin** (31 Lua 5.4 + 5 Luau), **mỗi case chạy trên host trước** để chứng minh pin là hành vi thật của host chứ không là suy đoán của người viết test, rồi build `l1`+`l2` × `stack`+`register` ⇒ **156 cell artifact** in đúng chuỗi đã pin; thêm **5 seed × 2 mode** cho hình dạng spread (`{holes()}` + arg giãn + tail giãn) vì pack layout, register permutation và region layout đều đổi theo seed, và một result thừa/thiếu chỉ hiện ra dưới dạng một `nil` lạc trong stdout; thêm khối **empty-result return** (`return` trần, `return e()` với `e` 0 result) ⇒ `#t = 0` và `select('#', …) = 0`. Mọi cell đều assert `vmMeta.fallback === false` để chắc rằng nó đi qua VM custom chứ không rớt về source route.

### 29. Bảng của constructor phải **giữ được lỗ hổng mảng** như native: `NEWTABLE` mang SIZE (`src/compiler/table_array_hint.js` mới, `bytecode.js:130`, `register_compiler.js:159`, 6 handler body, `opcode-table.js`, `ironbrew/validator.js`)

- **Triệu chứng đo thật, và nó còn tệ hơn "sai số":** artifact in `#{none(), 1} = 0` khi cả hai host in `2`; và chính cách dựng naive (`t={}; t[1]=nil; t[2]=1`) cho `#` **khác nhau giữa hai host** — `lua54.exe` trả `0`, `luau.exe` trả `2`. Nghĩa là bug không chỉ sai mà **phụ thuộc host**: cùng một file build ra, chạy FiveM khác Roblox.
- **Nguyên nhân thật:** Lua size array part của table constructor từ **số list field**, trước khi biết giá trị của chúng, nên một `nil` chỉ xuất hiện lúc chạy vẫn để lại các index phía sau reachable qua `#`, `next`, `ipairs`. VM dựng bảng bằng từng assignment một thì không có pre-size đó.
- **Sửa:** `NEWTABLE` nhận thêm operand SIZE = số list field, handler materialise `{unpack({}, 1, SIZE)}` khi `SIZE > 0` (đường rẻ `{}` giữ nguyên khi không có rủi ro). `tableArraySizeHint()` là **một nguồn duy nhất cho cả hai compiler**, và nó **không** đếm cơ học: chỉ trả SIZE > 0 khi có một slot list **không phải literal** nằm **trước** slot list cuối — vì một `nil` chỉ che được các slot **phía sau** nó; `{1, 2, 3}` toàn literal thì không bao giờ hole ra, nên không phải trả giá unpack. Bảng tạm nội bộ (scratch của method call / for-loop) gọi `NEWTABLE 0` kèm comment giải thích vì sao nó không cần hint (`bytecode.js:212`, `register_compiler.js:239/348`).
- **Metadata phải sửa cùng, không được sửa một chỗ:** `STACK_ARITY.NEWTABLE: 0 → 1` + `operandNames.NEWTABLE = ["SIZE"]` (`src/opcode-table.js:57`, `:109`), `ironbrew/validator.js` stack ARITY `0 → 1`, register giữ arity 2 vì operand 2 **là literal** chứ không phải index pool (`NEWTABLE` không nằm trong `constantOperandIndexes`), và `singleReg1` (`register_compiler.js:710`) remap đúng `ins[1]` nên literal SIZE sống sót qua register permutation. Handler được sửa ở **cả sáu** chỗ đang sống và đang bị assert: stack `vm_generator.js:2378`, stack-alt `:2421`, register-alt `:2441`, register `reg_vm_generator.js:133`, cộng hai body legacy `vm_generator.js:194` / `reg_vm_generator.js:216` (bảng sau bị `test-v477-catalogue.js:42` assert chuỗi). Lane decoy (`src/protection/live_shadow_vm.js:530-551`) **copy thân handler thật** và chạy với instruction tổng hợp `I0={0,2,3,4,1,5,…}` ⇒ operand mới bắt buộc phải an toàn với instruction đó: SIZE=2 đi đường unpack, không vòng lặp không chặn.
- **Bằng chứng fidelity (harness `tools/verify-multiret-fidelity.js`):** **27** hình thái bảng-có-lỗ × 2 preset × 2 mode × 2 host = **216 cell**; **host divergence = 0** (luôn luôn ghi lại native-vs-native, vì pin do một host suy ra thì vô nghĩa); artifact lệch native còn **một lớp hình thái** — `{[7]=9, nil, 1}`, `{x=1, nil, 2}`, `{x=1, nil, h5()}`: `#` báo `0` thay vì `2`/`3` và `next()` bắt đầu ở hash part. **Giá trị tại mọi index vẫn đúng**; chỉ boundary của `#` và thứ tự `next` khác.
- **Vì sao không sửa nốt — đo chứ không đoán:** `scratch/hashorder.lua` — đảo thứ tự ghi (list trước, hash sau) chữa được Lua 5.4 (`#` = 2) nhưng **Luau vẫn 0**; `scratch/hashfill.lua` — array part **đặc giá trị** thì sống qua rehash trên **cả hai host** (`#`=2, `next`→2), nhưng "đặc" chỉ đúng khi **mọi** slot sẽ bị ghi lại; constructor có tail giãn (`{x=1, nil, f0()}`) có slot không ai ghi ⇒ giá trị độn lọt ra ngoài `#`. Native làm được vì `setnarr` resize array part **sau cùng**, là op nội bộ không có tương đương qua API công khai; và ISA đã 64/64 nên không có chỗ cho `SETLIST`/`CONSTRUCTORFINISH`. **Ghi thành LIMITATIONS**; đây là việc của ISA OPAL/ONYX (mục 26/27 v6), nơi ngân sách opcode được thiết kế từ đầu.
- **Change này lộ ra một bug của chính cổng đo, không phải của artifact:** `test-v580.js:645+` ablation chọn `findBlobLiterals(stageText)[0]` — blob **đầu tiên** của một stage hoàn toàn có thể là **decoy trơ** (`vyX7[54139]=[==[byteveil&…]==]`, class **cố ý** sống khi bị xoá/sửa theo mục 7). Khi thân handler đổi, byte layout dịch đi và stage 2 đặt decoy lên đầu ⇒ suite kết luận "ablating carrier must fail closed" như thể artifact vừa yếu đi. Đã sửa: chọn carrier theo **hình dạng** (`…=function()return D(string.sub(`) và ablation **mọi** callable carrier của cả ba stage, không phải một. Đo trước khi sửa bằng `tools/verify-carrier-classes.js` (tên lúc đó là `tools/scratch-stage2-ablation.js`, đã đổi vì nó là bằng chứng chứ không phải scratch): ba stage có **4 / 3 / 8** callable carrier, **15/15 chết trên cả hai host** khi lật 1 byte payload, còn decoy trơ thì sống đúng thiết kế. Suite standalone sau sửa: exit 0 (bây giờ gồm 30 lần chạy ablation thật).

- **Chi phí đo thật, không tuyên bố suông (`scratch/newtable_cost_bench.lua`, `tools/verify-newtable-frequency.js`):** phần **luôn trả** cho mỗi `NEWTABLE` là `+85.5 ns` (Lua 5.4) / `+62.3 ns` (Luau) — đọc operand rồi xét nhánh; phần **fill** `+1,087 ns` ở SIZE=3 (Lua 5.4) / `+402 ns` (Luau) chỉ xảy ra với constructor có rủi ro hole. Tần suất trên 4 nguồn thực tế (Roblox-ish, FiveM-ish, json-encoder, hình dạng multiret): **1/18** constructor trả phần fill (5.6%), tổng 3 slot materialise. Con số tuyệt đối của benchmark có kèm chi phí closure-call của harness, nên chỉ **delta** giữa hai dòng là số được trích.


### 30. Hằng số **phải giữ đúng subtype** của nó: `print(5.0)` không được in ra `5` (`src/compiler/number_operand.js` mới, `bytecode.js:43`, `register_compiler.js:40`, `src/backend/bytecode_serializer.js:148-160`, `src/ironbrew/validator.js:25-33`, `test-v590-numeric.js` mới)

- **Triệu chứng đo thật (trước khi sửa):** `scratch/probe_numeric_fidelity.js` chạy 31 ca × 2 mode, so stdout của host với stdout của artifact trên **cùng một nguồn**. Kết quả ghi trong `scratch/vsnap/numeric_fidelity_before.log`: **`SUMMARY cases=31 mismatches=10`**, và 10 dòng lệch không phải số làm tròn — `print(5.0)` in `5`, `print(1e3)` in `1000`, `print(0x1p4)` in `16`, `print((5.5)//1)` in `5`, `print(7.0 // 2.0)` in `3` — trên **cả hai** mode stack lẫn register. Đây là lỗi **sai kiểu**, không phải sai chữ số: Lua 5.4 phân biệt integer/float (`math.type(5.0) == "float"`), còn `5.0 // 2` là float trong khi `5 // 2` là integer; một giá trị sụp từ float xuống integer làm sai luôn `//`, `%`, khoá table và `math.type`.
- **Nguyên nhân thật:** JS chỉ có một kiểu `number`, không giữ được cách nguồn **viết** hằng số. Route cũ nhét mọi literal vào một operand dạng số nên `5.0` và `5` đi vào payload **giống hệt nhau**; mọi cách sửa dựa trên "giá trị có nguyên hay không" đều sai về bản chất, vì hai literal cùng giá trị nhưng khác chính tả phải cho hai kết quả khác nhau.
- **Sửa:** quyền quyết định subtype nằm ở **một chỗ duy nhất** — `numberOperand(node)` đọc `node.raw` (đúng chính tả trong nguồn: có `.`/`e`/`E`, hoặc hex có `.`/`p`/`P`), **không bao giờ đọc giá trị**. Một literal viết dạng float được bọc thành `FloatOperand` mang **chuỗi thập phân round-trip ngắn nhất buộc phải trông như float** (`floatText` thêm `.0`, vì JS render `5.0` thành `"5"` và host đọc `"5"` sẽ trả lại integer). Serializer `writeSVarint` cho nó đi **đúng đường ASCII** mà nhánh non-integer đã dùng (`bytecode_serializer.js:149`), nên host phục hồi bằng `tonumber()` và giữ subtype; integer vẫn đi form zigzag gọn như cũ.
- **Cổng validation phải biết ngoại lệ này:** `ironbrew/validator.js:25-33` — FloatOperand **chỉ** được phép ở đúng một slot (giá trị của `PUSHN`: index 2 cho register, 1 cho stack) và chuỗi của nó phải khớp `FLOAT_TEXT`; operand khác ở bất kỳ slot nào mà không phải số hữu hạn vẫn throw. Nghĩa là một payload bị sửa để nhét chuỗi.float vào slot khác bị từ chối trước khi chạy, không phải âm thầm nhận.
- **IDIV để nguyên `//` của host** (`vm_generator.js:169` và bản variant `:2353`, `reg_vm_generator.js:104-106` + `:182`): bất kỳ bản "floor tự tính" nào cũng sụp subtype đúng như 10 dòng mismatch ở trên. Hai variant của handler chọn theo **đúng** `v("IDIV", 2) === 0`, cả hai đều gọi `//`.
- **Pin ngược chiều chứng minh đây không phải chuyện "luôn in `.0`":** 5 ca Luau trong `test-v590-numeric.js` pin `print(5.0) → "5"` và `typeof(5.0) → "number"` (Luau không có integer subtype). Cùng một bản vá phải đúng trên host **có** phân biệt và host **không** phân biệt — nếu chỉ đo Lua 5.4 thì dễ "sửa" thành bắt Luau in `5.0`, tức là tạo ra một sai mới.
- **Bằng chứng:** `node test-v590-numeric.js` → exit 0, **39 pinned cases (32 Lua 5.4 + 7 Luau)**, **160 artifact cell** = mỗi pin chạy host trước rồi build `l1`+`l2` × `stack`+`register` (đếm lại sau khi thêm pin của mục 31). Wall **standalone 66 s**, trong gate **145,590 ms** ở lần gate trước (`scratch/gate-multiret-final-1793501949.log`, khi suite còn 31 pin). Pin **ghi cố định trong file**, không lấy lúc chạy từ host — host upgrade không được âm thầm dịch goalposts, nhưng nguồn thường vẫn được chạy và đối chiếu với pin nên pin lệch thực tế sẽ **nổ to**.
- **Sau khi sửa, đo lại bằng chính probe đó:** `node scratch/probe_numeric_fidelity.js` → `SUMMARY cases=31 mismatches=0`, exit 0, log `scratch/vsnap/numeric_fidelity_after.log` (0 dòng `DIFF`). Cặp trước/sau là bằng chứng, không phải suy luận: `before=10` → `after=0` trên đúng 31 ca, đúng 2 mode.

### 31. Ngữ pháp số của lexer phải nhận **đúng tập mà hai host nhận**: hex float không exponent, `5.`, `0x_FF` (`src/frontend/lexer.js:2-23` (`NUMERIC_LITERAL` + `parseNumericLiteral` viết lại) và điểm gọi `:370`), `test-v590-numeric.js` thêm 8 pin)

Mục 30 sửa cách **in** hằng số; đào thêm bằng một battery chuyên tìm chỗ engine **từ chối input hợp lệ** (`scratch/probe_hexfloat.js`, `scratch/probe_numeric_edges.js`) thì ra một lớp lỗi khác: nguồn đúng của Lua 5.4/Luau bị strict VM chặn, nghĩa là nạn nhân mất luôn đường VM và rơi về route yếu.

- **Bốn hình thái từ chối, đo từng cái trên host trước khi kết luận (host nói gì mới là sự thật):**
  `0x1.8` → host Lua 5.4 in `1.5` / `math.type = float`, engine báo `non-finite numeric literal requires source route: 0x1.8`, vì `parseNumericLiteral` chỉ đổi hex float **khi có `p`**; không có `p` thì rơi vào `Number("0x1.8")` = `NaN`.
  `0x.8` và `0x.8p1` → host in `0.5` / `1.0`, engine báo `lexer error: Malformed numeric literal near "0x"`, vì regex bắt buộc **có một hex digit trước dấu chấm**.
  `0x1.` → host in `1.0` (`float`), cùng lỗi trên.
  `5.` → **cả hai host đều nhận** (`lua54` in `5.0`, `luau` in `5`), engine báo `parser capability: Expected ), got .`, vì nhánh decimal bắt buộc có chữ số **sau** dấu chấm nên `5` bị cắt rời khỏi `.`.
  `0x_FF` (Luau in `255`) và `1._5` (Luau in `1.5`) → engine báo `Malformed numeric literal`, vì regex chỉ cho `_` **giữa** các chữ số, không cho ngay sau prefix `0x`/ngay sau dấu chấm.
- **Sửa:** `NUMERIC_LITERAL` là một constant có tên (trước đó là regex ẩn trong vòng scan) nhận hợp nhất ngữ pháp của hai host: hex có thể **không có** exponent, dấu chấm có thể đứng ở **hai đầu không** (`0x.8`, `0x1.`), `_` được phép ngay sau `0x`/`0b` và ngay sau `.`; decimal nhận đuôi `.` trần. `parseNumericLiteral` tự tính giá trị hex float thay vì đùn cho `Number()`: `whole + Σ digit·16^-i` rồi `× 2^exp`, nên `0x1.1111p4` ra đúng `17.066650390625` như host. Subtype vẫn do **chính tả** quyết định ở `number_operand.js` (`0x1.8` → float vì có `.`, `0xFF` → integer), không đổi luật ở mục 30.
- **Không sửa thành "nhận bừa để khỏi bị từ chối":** union hai ngữ pháp có nghĩa là với `target:"luau"`, nguồn `0x1.8` (mà `luau.exe` **từ chối**) vẫn build được và artifact của nó lại **chạy được** trên Luau, vì payload mang số thập phân `1.5` chứ không mang chính tả hex. Đây là độ rộng **đầu vào**, không phải khác biệt **semantics**; đã ghi thẳng vào LIMITATIONS để Arena không đọc nhầm thành "tương thích Luau đầy đủ".
- **Một khác biệt chẩn đoán còn lại, đo thật:** `1.5..2` — **cả hai host** báo `malformed number near '1.5..'`, engine vẫn chấp nhận và in `1.52`. Trước bản vá, `1.."a"` lại được engine nhận (host từ chối); sau bản vá nó bị từ chối **đúng như host**. Tức là bản vá làm hành vi sát host ở một ca và để hở một ca có cùng gốc (Lua ăn `..` vào numeral theo maximal munch), và nó chỉ theo hướng "engine rộng hơn host" chứ không bao giờ theo hướng "engine từ chối input hợp lệ".
- **Bằng chứng:** 8 pin mới trong `test-v590-numeric.js` (`hex float without exponent`, `hex float with empty fraction`, `hex float with empty whole part`, `hex float with exponent and fraction`, `hex float equals decimal float`, `trailing dot is a float literal`, `luau underscore after hex prefix`, `luau trailing dot and dot fraction`) → suite **exit 0, 39 pin / 160 cell, standalone wall 66 s**. `node scratch/probe_numeric_edges.js` → `SUMMARY edge cases=15 mismatches=0` (15 ca adversarial: `-0.0`, `2.0` vs `2` làm key, `math.huge`, `0/0`, `math.maxinteger // 3`, hex float, float qua `MAKEFUNC` nested chunk) trên **cả hai mode**; `node scratch/probe_hexfloat.js` in bảng 17 cách viết × 2 host với cột pipeline = `VM ok` cho **mọi** dòng mà host nhận.
- **Bản vá này có trung tính với corpus đã ship không — đo, không đoán (`scratch/probe_numeric_neutrality.js`, `scratch/neutrality-final.log`):** con số chốt là `files=258 numerals=781,901 files_with_value_change=0 files_with_spelling_change=0` trên **toàn bộ file `.lua`/`.luau`** của `examples/ src/ bot/ tools/ scratch/` (nguồn vào, ví dụ ship kèm, và artifact do các bản build cũ hơn sinh ra). Probe so chính tả cũ/mới **cùng chạy trên một văn bản**: pattern cũ dán nguyên văn vào probe, pattern mới đọc thẳng ra từ `src/frontend/lexer.js` nên không thể pass nhờ một bản copy cũ. Giá trị so theo **multiset**, không theo vị trí: một token rộng hơn sẽ dịch mọi index phía sau và sinh vài trăm diff ảo.
  Hai lần sửa probe là sửa **bệnh của test**, không phải của engine: bản đầu quét mọi chữ số trong văn bản thô nên đọc `6.` từ tên `FmS6..` và từ body `[==[byteveil&…]==]`, và `32.` ở cuối comment — báo nhầm 41 file "đổi giá trị"; bản sau đi theo **ranh giới token thật** (ăn trọn dãy identifier, bỏ comment/chuỗi/long-bracket) nên hai con số ảo kia về 0.
  Negative control bắt buộc, vì `0 diff` không phân biệt được "trung tính" với "probe không bao giờ chạm numeral": `CONTROL spellings=6 files_with_value_change=4 files_with_spelling_change=5` — `0x1.8` old=`NaN` new=`1.5`, `0x.8` old tách `0,.8`, `0x1.`/`5.` old=cụt dấu chấm, `0x_FF` old chỉ đọc `0`, `1._5 + 5.e1` old đọc `1,5`. Probe nhìn thấy đúng các chỗ bản vá cố đổi.
  Spot-check thêm cho lo lắng thật sự mà numeral rộng chạm tới (số đứng sát `..`): `scratch/probe_concat_lex.js` đối VM với naked host — `print(6 .. "a")` ra `6a` trên cả lua lẫn luau, `print(6 .. [[a]])` ra `6a`, `print(5. .. "z")` ra `5.0z` **giống hệt host**, `print(0x1.8 .. "z")` ra `1.5z`; `print(6.."a")` bị từ chối và thông báo chính là `malformed number near '6..'` của host (fail-closed, không phải engine tự nghĩ ra lỗi).

## VERIFIED (bằng chứng thực thi, không phải số khai báo)
Môi trường: Windows x64, Node v24.20.0, `lua54.exe` = Lua 5.4 (Lua 5.4.8 build, sau khi thêm `lua54.dll`), `luau.exe` = Luau 0.739 standalone (cài qua `install-native.ps1` gốc; không phải Luau trong Roblox).

### Multiple-return + array-part hint + subtype của hằng số (mục 28/29/30) — gate **23/23 PASS**, exit code 0, total **338,456 ms**, concurrency=4

Chu kỳ này không có suite nào bị bỏ; log: `scratch/gate-multiret-final-1793501949.log` (giữ nguyên trong `scratch/`, không đi kèm archive vì `scratch/` nằm trong `EXCLUDE_DIR_NAMES` — mọi con số dưới đây in ra từ chính log đó, không nhớ lại từ trí nhớ).

- `node test-v590-multiret.js` → exit 0, **36 pinned cases (31 Lua 5.4 + 5 Luau)**, **156 artifact cell** = mỗi pin chạy host trước (chứng minh pin là hành vi của host, không phải của người viết test) rồi build `l1`+`l2` × `stack`+`register`; thêm `5 seed × 2 mode` cho hình dạng spread và khối empty-result return. Wall **standalone 120 s** (exit 0, `scratch/standalone-walls.txt`); wall **trong gate: 197,681 ms** ở `gate-newtable-refined-1793501203.log` và **278,553 ms** ở lần gate chốt — suite này spawn tới hàng trăm process lua54/luau nên bị tranh CPU rõ rệt, hai con số là của **cùng nội dung**, khác mỗi tải máy.
- `node tools/verify-multiret-fidelity.js` → `cases=27 cells=216`, **host divergence: none**, **24 dòng mismatch** = đúng 3 hình thái (`hash then list`, `named then nil then hole tail`, `hash then hole then value`) × 2 preset × 2 mode × 2 host. **Đọc đúng bản chất tool:** nó là harness *differential* in `RESULT: FAIL` khi còn mismatch và chỉ đặt `exitCode` khi ném exception (`tools/verify-multiret-fidelity.js:93-96`), nên cặp `exit=0` + `RESULT: FAIL` + 24 dòng **chính là** trạng thái giới hạn đã ghi ở LIMITATIONS — số được trích là **24 dòng**, không phải exit code. Cái khoá hành vi là `test-v590-multiret.js` (36 pin, không pin hình thái sai).
- `node test-v580.js` → exit 0 standalone (wall **49 s**; một lần chạy khác trên cùng cây: **37 s**) với ablation **mọi** callable carrier: 3 stage có **4 / 3 / 8** carrier, **15/15 chết trên cả hai host** khi lật 1 byte payload (`tools/verify-carrier-classes.js` in bảng phân loại callable-vs-trơ trước khi kết luận). Trong gate: 54,637 ms / 64,276 ms / 146,392 ms cho cùng nội dung.
- `node tools/verify-newtable-frequency.js` → exit 0; assert chunk stack và chunk register phát đúng số hinted/cheap cho mọi constructor của top chunk, tổng **1/18** constructor thực tế rơi vào đường fill.
- `node test-v590-numeric.js` → exit 0, **31 pinned case (26 Lua 5.4 + 5 Luau)**, **128 artifact cell**; standalone wall **63 s**, trong gate **145,590 ms**. Cặp trước/sau của chính lỗi subtype: `node scratch/probe_numeric_fidelity.js` cho `cases=31 mismatches=10` trước bản vá (`scratch/vsnap/numeric_fidelity_before.log`) và `cases=31 mismatches=0` sau bản vá (`scratch/vsnap/numeric_fidelity_after.log`, exit 0, 0 dòng `DIFF`).
- `scratch/newtable_cost_bench.lua` chạy trên **cả hai** host (2M lặp × 7 vòng interleaved, best-of): delta được trích ở mục 29, không trích con số tuyệt đối.

### Carrier rác load-bearing (`node test-v590-junk.js`) — exit code 0, 19,974ms (trước P3) → **64,933ms** standalone sau khi có padding

Suite mới, **không cần nội bộ generator**: dò container trong output cuối bằng `findBlobLiterals` + vết `string.sub(` phía trước (đúng dạng VM đọc), đột biến rồi chạy thật trên cả `lua54.exe` và `luau.exe`.

- 4 build (preset `lz`, stack/register × seed `4242/90210`) → **144 container dạng carrier** được nhìn thấy (36/build), control in đúng digest gốc (đo từ mẫu chưa bảo vệ, không hardcode).
- Lật 1 ký tự payload (chọn ký tự **có trong alphabet** để lỗi phải đến từ giá trị, không từ cú pháp): **64/64 rejected** trên cả hai runtime.
- Cắt ngắn payload: **64/64 rejected**.
- `assert.deepEqual(survivors, [])` — không có container carrier nào "sửa tùy ý".

Bằng chứng mở rộng (harness tạm, đã xóa cùng patch này; chạy trên 12 build `lz/l1/l2` × stack/register × seed `1001/2002`): **68 carrier rác + 206 carrier payload = 274 container dạng carrier**, **544 lần lật ký tự payload → 0 liveCarriers** **136 lần trung hòa carrier rác (`[slot]=nil and function()…`) → 0 sống**, 0 slot rác không tìm thấy trong output. Ma trận hồi quy digest 80 build × 2 runtime = **160/160** chạy đúng.

### Env logger (`node test-v590-envguard.js`) — exit code 0, 16,064ms standalone (9,145ms trước khi có padding)

3 attack cài **trước** khi compile chunk bảo vệ, chạy trong host thật:

| Attack | Cơ chế | Lua 5.4 | Lý do guard báo |
|---|---|---|---|
| `globalLogger` | metatable trên `_G` với `__index`/`__newindex` ghi tên | fail-closed **4/4** build | `environment index logger detected` / `environment write hook detected` — 4/4 |
| `stdlibLogger` | bọc `string.sub`/`table.concat`/`string.byte` bằng Lua closure | fail-closed **4/4** | `runtime API provenance mismatch` — 4/4 |
| `guardBypass` | logging `_G` metatable **và** `error` bị stub thành no-op | fail-closed **4/4** | `attempt to index a nil value` (bẫy nội tại) — 4/4, `STUBBED>0` chứng minh lời gọi `error` thật bị vô hiệu hóa |

Luau standalone: cả 3 attack **bị nền tảng từ chối 4/4** (`setmetatable(_G,…)` và ghi vào `string`/`table` đều lỗi `attempt to modify a readonly table`), tức host chết trước khi chunk chạy — **không** được tính là phòng thủ; bằng chứng phát hiện chỉ có trên Lua 5.4 (xem LIMITATIONS).

### Sửa lỗi đo lường của chính suite proof (trước khi kết luận)

Bản `_junk_proof` đầu tiên báo **548/548 flip sống** — trông như "carrier không load-bearing". Nguyên nhân là harness: `findBlobLiterals().start` trỏ vào `[` của ngoặc dài, nên phép lật ở `start + 9` rơi vào **trong xâu marker `byteveil&`** — phần mà `string.sub(…,10)` cắt bỏ, nên đột biến vô hại. Sau khi tính đúng offset (`[=*[` + marker), toàn bộ lật đều fail-closed. Tương tự, host `globalLogger` ban đầu đặt handler vào *metatable của metatable* ⇒ metamethod không bao giờ được gọi, attack không tồn tại.

### JunkForge density envelope (`node test-v590-forge.js`) — exit code 0, standalone 33,609ms (trong gate: 67,004ms khi 4 suite tranh CPU)

Suite mới (một trong 19 suite của gate), đo **envelope thật của output đã pad** trên fixture `tri(9)`, 14 cell = 7 preset × {Lua 5.4, Luau}, seed `0x59F0ED1`. Mọi ngưỡng đều lấy từ hằng số module, không hardcode số byte:

- `vmMeta.junkForge`: `engine:"JunkForge-v1"`, `applied:true`, `partial:false`, `floorBytes === PRESET_FLOORS[preset]`, `maxBytes === OUTPUT_CAP_BYTES[target]`; `sizeBudget.targetMinBytes/targetMaxBytes/status` khớp cùng cặp số.
- `bytes >= floor && bytes <= cap`, và **overshoot có trần đo được**: `bytes − floor ≤ floor×2% + 8192`.
- Đúng **một** khối forge trong output, không có newline bên trong nó; số container đếm được bằng `findBlobLiterals` **nằm trong** khối đó `=== vmMeta.junkForge.containers`.
- **Gán padding chính xác từng byte**: build cùng seed với `junkForge:false` → `reason:"disabled"`, `paddingBytes:0`, và `bytes(naked) === bytes(padded) − paddingBytes` (không phải xấp xỉ).
- Determinism: cùng seed → cùng output (2 cell chọn làm mốc `l1/lua`, `maximum/luau`); khác seed → khác output. Marker `byteveil&` không bao giờ xuất hiện dưới dạng xâu quoted và biến mất hoàn toàn sau `stripBlobLiterals`.
- Order monotonic theo preset trên cả 2 target; caps đúng `2,500,000` (lua) / `3,000,000` (luau); custom không tên đạt floor scaled `MIN_FLOOR_BYTES + 500×24`; floor > cap ⇒ clamp vào cap với `partial:true` **và vẫn chạy đúng**; `junkForge:{floorBytes:2,900,000}` trên luau chạm floor đó.
- **Fail-closed census trên padding** (6 container trải đều trong khối forge × {drop container, cắt ngắn, đổi class letter↔digit} × Lua 5.4 + Luau): `dropped 12/12, shortened 12/12, reclassified 12/12` — `survivors = []` **và** `aborted === runs` (36/36 run chết **trước khi** payload chạy, không phải "chạy ra số khác"). Control: cùng build không sửa vẫn in đúng digest trên Luau.

Ma trận envelope đo thật từ chính suite (`tri(9)`, seed `0x59F0ED1`; Lua và Luau cho cùng số byte vì floor theo preset, không theo target). Bảng là số **sau VeilStr-v1** (lấy từ stdout của `test-v590-forge.js` trong lần chạy gate 19 suite): payload mang thêm reader tag-85 và hằng số đã cipher nên **tổng bytes tăng**, còn **padding giảm theo đúng lượng đó** — `floor` giữ nguyên, `bytes − padding = payload`:

| Preset | Output | Padding | Container | Bank | Floor | Cap |
|---|---|---|---|---|---|---|
| l1 | 210,534 B | +137,541 B | 335 | 16 | 204,800 | 2,500,000 |
| default | 210,052 B | +136,311 B | 331 | 17 | 204,800 | 2,500,000 |
| l2 | 406,378 B | +331,520 B | 812 | 41 | 400,000 | 2,500,000 |
| nest | 707,152 B | +550,465 B | 1,359 | 71 | 700,000 | 2,500,000 |
| df | 1,208,888 B | +1,130,352 B | 2,769 | 138 | 1,200,000 | 2,500,000 |
| lz | 2,011,780 B | +1,927,943 B | 4,739 | 236 | 2,000,000 | 2,500,000 |
| maximum | 2,414,057 B | +2,331,578 B | 5,731 | 299 | 2,400,000 | 2,500,000 |

Giá trị Luau của cùng 7 preset: giống hệt từng byte (`210,534 / 210,052 / 406,378 / 707,152 / 1,208,888 / 2,011,780 / 2,414,057`), trần khai báo là 3,000,000 B. Cột `bed` trong stdout suite là `keyBedBytes / keyBedTextBytes`: khối JunkForge key bed chiếm `2,209–2,508 B` tổng, trong đó **`1,817–2,108 B` là text container mà fold thật tiêu thụ** — suite assert con số thứ hai **bằng đúng** tổng nội dung bên trong `[=[…]=] của từng blob cộng lại, nên phần chênh chỉ là cú pháp ngoặc dài, không có byte text nào của bed nằm ngoài khóa region.

Lần đo envelope **trước** VeilStr (cùng fixture, cùng seed) cho `207,912 / 207,990 / 403,722 / 704,887 / 1,206,590 / 2,009,742 / 2,411,510` và bank `17/18/41/71/138/237/299` — giữ làm mốc: độ chênh +2,6 B (`l1`) tới +2,5 KB là chi phí thật của lớp cipher chuỗi, và padding tự co lại nên **kích thước file cuối cùng gần như không đổi**.

### Chi phí thật của JunkForge (median: build 3 lần, run 5 lần, **một build warm-up bỏ đi trước khi đo**)

`runMs` là wall của cả spawn + load + execute một file tạm, trên `lua54.exe` / `luau.exe`. Bảng này là lần đo **đã loại build lạnh**; lần đo đầu tiên (không warm-up) cho `l1`/Lua 383ms > `l2`/Lua 306ms — một inversion giả: đo riêng 7 build liên tiếp trong một process cho `l1` padded `[586, 297, 270, 250, 242, 222, 241]`, tức **build đầu tiên của process = 586ms, steady-state median = 250ms**; sau khi bỏ build lạnh, mọi cặp đơn điệu theo padding (`scratch/measure_build_jitter.js`, `scratch/measure_forge_cost_v2.js`):

| Preset | Target | Padded vs naked bytes | Build ms (pad/naked) | Run ms (pad/naked) | Δ build | Δ run |
|---|---|---|---|---|---|---|
| l1 | Lua 5.4 | 207,912 vs 66,987 | 367 / 167 | 287 / 257 | +200ms | **+30ms** |
| l1 | Luau | 207,912 vs 66,987 | 314 / 181 | 241 / 196 | +133ms | **+45ms** |
| l2 | Lua 5.4 | 403,722 vs 68,357 | 377 / 163 | 291 / 223 | +214ms | **+68ms** |
| l2 | Luau | 403,722 vs 68,357 | 364 / 195 | 255 / 191 | +169ms | **+64ms** |
| lz | Lua 5.4 | 2,009,742 vs 77,067 | 1,279 / 194 | 742 / 431 | +1,085ms | **+311ms** |
| lz | Luau | 2,009,742 vs 77,067 | 1,370 / 209 | 758 / 439 | +1,161ms | **+319ms** |
| maximum | Lua 5.4 | 2,411,510 vs 76,458 | 1,524 / 171 | 885 / 464 | +1,353ms | **+421ms** |
| maximum | Luau | 2,411,510 vs 76,458 | 1,497 / 166 | 838 / 318 | +1,331ms | **+520ms** |

- Bytes từng cell **khớp tuyệt đối** với bảng envelope **tại thời điểm đo** (`207,912 / 403,722 / 2,009,742 / 2,411,510` padded; `66,987 / 68,357 / 77,067 / 76,458` naked) vì build theo seed là deterministic — hai lần đo độc lập, cùng số. **Bảng này đo trước VeilStr-v1** (mục 16); sau khi thêm reader tag-85, payload to hơn và padding co lại đúng lượng đó nên **tổng file gần như không đổi** (`l1` 207,912 → 210,534 B, +1.3%) — các Δ dưới đây vì thế vẫn là khoảng chi phí hợp lệ cho bản hiện tại, và được kiểm chứng lại bằng `scratch/probe_v59_cost.js` (xem mục 16).
- Cột `naked` dao động theo process (lz naked 381ms lần đầu → 431ms lần này): chi phí spawn + load file nhỏ, nhiễu ±10-15%. **Δ run** vì thế là khoảng, không phải điểm: chi phí padding thật sự nằm trong **~+30ms (208 KB) → ~+420…520ms (2.4 MB)**.
- Padding bytes / containers mỗi build đúng bằng số telemetry: `l1` 140,925 B / 344, `l2` 335,365 B / 822, `lz` 1,932,675 B / 4,750, `maximum` 2,335,052 B / 5,740.

### [LỊCH SỬ — đã đóng bởi mục 14] Giới hạn đo được ngay trong lần kiểm chứng mục 13: bỏ **cả** khối forge thì payload vẫn chạy

Phép đo thật (`l1`/`l2`/`maximum`, xoá nguyên khối `local <holder>=(function()…end)();` — 140,925 / 335,365 / 2,335,052 B, đúng 344 / 822 / 5,740 container):

| Preset | Số container xoá | Lua 5.4 | Luau |
|---|---|---|---|
| l1 | 344 | chạy, in `45` | chạy, in `45` |
| l2 | 822 | chạy, in `45` | chạy, in `45` |
| maximum | 5,740 | chạy, in `45` | chạy, in `45` |

Nghĩa là (tại lần đo đó): **digest của JunkForge chỉ bảo vệ tính toàn vẹn của chính padding**, không có giá trị nào của payload phụ thuộc vào nó (holder local không được tiêu thụ ở downstream). Cùng hình thái giới hạn đã khai báo cho carrier rác: sửa/xoá *một phần* ⇒ chết; gỡ *toàn bộ* khối + lời gọi ⇒ sống.

**Tình trạng hiện tại — chính sách dẫn ở trên đã được thi hành**: mục §14 đưa 5 container key bed vào `materialSeed`/khóa region, nên holder giờ bị tiêu thụ thật. Đo lại bằng chứng thực thi trong `test-v590-forge.js` (`node` in stdout, lần gate 19 suite): **12/12 đột biến khối bed (xóa cả khối / stub về 0 / stub về khóa sai / lật 1 ký tự cùng class) abort trước khi payload chạy, `survivors=[]`**, và `vmMeta.junkForge.keyBedBound:true` trên 6 preset × 2 runtime. Giới hạn còn lại, đã khai trong LIMITATIONS: phần padding **ngoài** bed vẫn chỉ self-check (`#text` + 4 điểm sample + class count) ⇒ edit cùng class ngoài vị trí sample vẫn sống (60/60), và `nest` không bind được bed (loader chunk khác, `keyBedBound:false`).

### Tỷ lệ phát hiện đột biến một ký tự trong padding (đo thật, không suy luận)

Harness tạm (`scratch/measure_forge_flips_v2.js`, chạy trên `lua54.exe`, preset `l2`/lua, seed `0x59F0ED3`, output 403,722 B / 822 container / 41 bank; **không** nằm trong ZIP bàn giao vì là scratch). Vị trí sample được **parse ngược từ chính khối đã emit** (`string.byte(<t>,<expr>)`) rồi tính trong JS theo `L`, nên mỗi trial biết chắc mình có đang sửa một vị trí được digest đọc hay không — baseline unpadded chạy đúng digest trước khi đột biến.

| Loại edit trong container padding | n | bị bắt | sống |
|---|---|---|---|
| Đúng vị trí sample, **cùng** class ký tự | 30 | 30 | **0** |
| Ngoài vị trí sample, **khác** class (letter↔digit↔upper↔punct) | 30 | 30 | **0** |
| Ngoài vị trí sample, **cùng** class, độ dài giữ nguyên | 60 | 0 | **60 (100%)** |

- Độ dài container trung bình **396.4** ký tự, mỗi container chỉ có **4** điểm sample ⇒ vùng phủ theo vị trí ≈ **1.01%**; phần còn lại chỉ bị bắt khi edit làm đổi **class** (số đếm `%a/%d/%u/%p` của bank).
- Xoá/cắt container luôn bị bắt vì digest có `#text` của từng container và số class của cả bank.
- Run đầu tiên (80 trial trộn bừa, `scratch/measure_forge_flips.js`) cho `crossClass 63/63 bắt, sameClass 17/17 sống` — cùng kết luận, và hoá ra 7 "survivor cross-class" của lần đo đầu là do pool replacement chưa lọc class (khoảng 27% ký tự cùng class với ký tự gốc); bảng trên là lần đo đã lọc chặt.
- **Ý nghĩa**: class edit sống được là class edit **không mang thông tin** — padding do PRNG sinh, chứa byte ngẫu nhiên, đổi chữ này thành chữ khác cùng class trong nó không bộc lộ gì về payload. Đã khai báo trong LIMITATIONS, không được tính là "phát hiện mọi chỉnh sửa".

### Alphabet hợp nhất: đo dấu vết còn lại (preset `l2` × seed `1001/2002/3003`)

Phép đo trực tiếp trên output thật, phân lớp container bằng đúng vết `string.sub(` (lớp carrier) và phần còn lại (lớp blob/decoy/diagnostic):

- **52 container lớp carrier** và **2,464 container lớp kia**: **100%** cả hai phía có ít nhất một chữ số (`52/52` và `2464/2464`).
- **Số ký tự phân biệt xuất hiện trong body: 93/93 cho cả hai lớp** — không còn tập nào "không có chữ số" để dựa vào.
- `\` không xuất hiện trong bảng ký tự và không xuất hiện trong body container; `UNIFIED_BASE === 93 === PRINTABLE_ASCII.length − 1`, module `blob_alphabet.js` **throw ngay khi load** nếu bảng bị thiếu ký tự in được, trùng, hoặc quay lại có `\`.
- Đối chiếu fingerprint động: cả 4 detector v5.8 đếm **0** trên 8 seed của benchmark (`*85+`, `[0x…]=function(`, `.irep|.crep`, hằng FNV) — tức sự hợp nhất không chỉ là khai báo trong tài liệu.

### VeilStr-v1 parity + attack (`node test-v590-veilstr.js`) — exit code 0, standalone wall 50,328ms

Suite mới, đo bằng **cách chạy thật** (`lua54.exe` + `luau.exe`), không phải inspect text:

- **JS**: 15 vòng round-trip trên 1,011 byte plaintext — encrypt/decrypt là involution với mọi `(chunkSeq, index)` đã sample, fold check **không đổi** khi cipher đổi (check bind trên plaintext), và khóa **phụ thuộc lane/index** (không phải cùng keystream cho mọi constant).
- **Parity differential**: `["l1","maximum"] × ["stack","register"] × {flat, nested}` trên cả hai runtime = **8 build ciphered / 16 lần chạy native**, tất cả in **đúng** output của bản không bảo vệ; **96 constant được cipher / 822 byte cipher**, **8 material root phân biệt** trên 8 seed — không hardcode số nào, đọc từ `vmMeta.stringCipher` của chính build.
- **Attack 1 — pin published root về 0** (đột biến `G.materialRoot=<local>;` → `G.materialRoot=0;`, chỉ đói khóa chuỗi mà **không** đụng region seed): **4/4 abort** khi fold check còn sống, và **4/4 in ra chuỗi SAI** khi xóa fold check — đúng tinh thần fail-closed: không có đường "vừa chạy vừa lộ plaintext".
- **Attack 2 — đông băng bộ đếm traversal** (`chunkSeq=chunkSeq+1;` → `chunkSeq=chunkSeq+0;`): **4/4 abort**, và **4/4 in sai** sau khi bỏ check (khóa mọi constant lệch index).
- **Control**: xóa riêng fold check mà không đột biến khóa ⇒ build vẫn chạy **đúng** (chứng minh hai attack ở trên chết vì khóa, không phải vì syntax bị hỏng).
- **Opt-out**: `stringCipher:false` ⇒ `vmMeta.stringCipher.applied:false`, không có `T==85`, không có `G.materialRoot=`, payload chạy đúng.
- **Chi phí build/run thật của cipher (đo **paired + interleaved**, `scratch/probe_v59_cost2.js`, exit=0, wall 139,076 ms)**: 7 cặp A/B trên cùng seed (`0x59A1`), thống kê là **median của hiệu từng cặp**. Δ build: `lua/l1 −8.4 ms`, `lua/lz −13.3 ms`, `luau/l1 −11.4 ms`, `luau/lz −250.2 ms` ⇒ **không vượt được nhiễu** (hai lần chạy một-shot trước đó báo +336.9/+490.0 ms cho cùng phép đo — xem caveat bên dưới). Δ run (giá trị nhất quán hơn): **+10.9 → +79.8 ms/lần thực thi** (`luau/l1 10.9`, `luau/lz 69.5`, `lua/l1 42.7`, `lua/lz 79.8`) — đó là chi phí giải mã per-constant khi script chạy. Size: fixture nhỏ `l1` +**116 B** (210,250 → 210,366); ở `lz` output **−12 B** vì JunkForge pad tới floor, payload cipher được bù bằng padding (tính không đơn-điệu đã ghi ở LIMITATIONS).
- **Caveat phương pháp (lần đo đầu tiên của chính tôi là lần đo sai):** `scratch/probe_v59_cost.js` (median 3 build + 5 run, các arm chạy **liên tiếp nhau**) cho ra `build Δ = −358 … +624 ms` giữa ba lần lặp — hoàn toàn không kết luận được gì. Bản v2 sửa bằng cách **xen kẽ A/B trong cùng vòng lặp** và lấy median của **hiệu** nên các cặp chia sẻ chung trạng thái ấm của process; vì vậy chỉ Δ **run** và Δ **precheck** được trích ở trên, còn Δ build của cipher được báo là "dưới ngưỡng phân giải", không phải "≈ 0 ms" (đó là một claim mạnh hơn dữ liệu).

### Engine precheck (`node test-v590-precheck.js`) — exit code 0, standalone wall 37,295ms

- **16 fault class tổng hợp** (mỗi class một artifact sai **đúng một** way) đều bị từ chối, kèm **6 positive control** (artifact đúng phải được tha) — danh sách trong file test: unparseable, undeclared/late-declared key addend, missing verdict addend, verdict≠digest, verdict với 0 read, template hole `undefined`/`NaN`, `[object Object]` thành syntax error, stale stamp, census shortfall, over cap, root không publish, root bị pin hằng số, census rỗng, stamp_inside_literal.
- **12 route thật** (`lua`/`luau` × `l1`/`default`/`maximum` × `stack`/`register`): **0 fatal**, 108 check được ghi, output 209,985–2,413,859 byte, 120 constant ciphered — chứng minh cổng **không** từ chối build lành.
- **Bắt được metadata nói dối trên artifact thật**: forge `containers:999999` ⇒ refused; thay mọi `G.materialRoot=<expr>;` thành `G.materialRoot=nil;` ⇒ refused (đây chính là lỗ hổng "chỉ kiểm tra sự hiện diện" đã sửa ở mục 17).
- **Cổng abort thật**: cài verdict fail có chủ đích ⇒ `obfuscate()` throw `ByteVeil v5.9 engine precheck failed (1): injected…`; build lành với cổng thật ⇒ không throw; `precheck:{enabled:false}` và `precheck:false` ⇒ `vmMeta.precheck === undefined`.
- **Chi phí**: reparse artifact đã ship `l1/stack = 126.0 ms` (210 KB) và `maximum/register = 169.4 ms` (2.4 MB) bằng chính front end của engine — ngưỡng assert < 5,000 ms. **Δ build toàn trình khi bật cổng** (cùng phép paired/interleaved ở mục 16, `scratch/probe_v59_cost2.js`): `luau/l1 +53.1 ms`, `lua/l1 +82.5 ms`, `luau/lz +121.7 ms`, `lua/lz +258.6 ms` — dương ở cả 4 ô và nằm trong khoảng 28–320 ms, tức precheck là chi phí build **thật, đo được** (không phải run cost; script đã ship không biết gì về cổng).

### Trần padding mới đo trên 14 cell preset × target (`node test-v590-forge.js`) — exit code 0, wall 144,773 ms trong gate (bản chạy sạch)

Census thật sau khi áp ngân sách (`format: output(+padding/containers/bracket-levels; bed)`), seed `0x59C0DE`, input nhỏ:

```
l1/lua       = 210534B (+137541B / 335c / 16b; bed 2508B/2108B read)
default/lua  = 210052B (+136311B / 331c / 17b; bed 2209B/1817B read)
l2/lua       = 406378B (+331520B / 812c / 41b; bed 2508B/2108B read)
nest/lua     = 541130B (+384443B / 944c / 48b; bed 2432B/2037B read)
df/lua       = 462928B (+384392B / 947c / 48b; bed 2508B/2108B read)
lz/lua       = 468229B (+384392B / 947c / 48b; bed 2508B/2108B read)
maximum/lua  = 467026B (+384547B / 935c / 47b; bed 2209B/1817B read)
```

Bảy cell `*/luau` lặp lại **đúng từng byte** các số trên (trần luau 3 MB không binding ở input nhỏ; nó chỉ mở đường khi `OUTPUT_CAP_BYTES.luau` mới là thứ cắt). Bốn cell chạm trần nhỏ đều nằm trong **384,392 – 384,547 B** — dưới 400,000 và trên `400,000 − 4×margin`, tức `PADDING_CODE_MARGIN_BYTES` đang làm đúng việc. `tamper: 36/36`, `key bed: 12/12 abort, survivors=[]`.

Tỷ lệ input → payload → output, preset `df`, `seed 0x59C0DE` (`scratch/probe_junk_caps.js`):

| input | payload (`junkForge:false`) | output đã pad | padding | `paddingCapBytes` | `capBinding` |
|---|---|---|---|---|---|
| 16,034 B (<100 KB) | 183,510 B | 569,356 B | 384,394 B | 400,000 | `junk-budget` |
| 64,034 B (<100 KB) | 504,129 B | 890,473 B | 384,394 B | 400,000 | `junk-budget` |
| 100,034 B (≥100 KB) | 754,705 B | 1,205,724 B | 449,174 B | 2,000,000 | `null` (đạt floor, ngân sách không cắt) |

Dòng giữa là bằng chứng cho bullet "ngân sách padding, không phải trần file": payload trần của input 64 KB **đã gấp rưỡi** con số 400 KB.

### Chi phí tải thật đo theo **số statement**, không theo kích thước file (`scratch/probe_scale_curve.js`, `lua54.exe`, `junkForge:false`, trần 45 s)

| source | output | thời tải |
|---|---|---|
| 1 statement, 83 B | 69,684 B | **1,200 ms** ok |
| 2 statements, 152 B | 70,728 B | **5,169 ms** ok |
| 4 statements, 290 B | 71,102 B | **7,855 ms** ok |
| 8 statements, 566 B | 73,063 B | **19,906 ms** ok |
| 14 statements, 992 B | 77,292 B | **>45,000 ms** — bị giết |
| 22 statements, 1,568 B | 80,562 B | **>45,000 ms** — bị giết |

Ba phép loại trừ đã chạy để chắc đây **không** phải chi phí padding hay của một subsystem: (a) padding bật (`l1`, 14 statement, output **209,421 B**) vẫn trong cùng dải 23–35 s như bản trần; (b) ma trận **13** biến thể toggle (`controlFlow/strings/numbers/functionTransform/rename/metamethodAlias/watermark/stringCipher/guardLatch/forgeLatch` + `bare`) cho 22,690–44,602 ms **không có cái nào nổi bật**, kể cả build tắt mọi transform — nên cost nằm trong vòng interpreter, không trong một lớp obfuscation; (c) các artifact "treo" trước đây (`df` input 10–99 KB) đều là artifact **nhiều statement**, và mọi build "nhanh" đều là source vài dòng — giải thích thống nhất cho toàn bộ dữ liệu cũ.

Comparator đo bằng **cùng runtime, cùng trần**, trên corpus Luraph 15.x: `217668728763.lua` **273,582 B** → **775 ms**, `4554455454.lua` 217,123 B → 1,252 ms, `02103919238.lua` 1,299,680 B → **14,680 ms** trên `luau.exe` (cả ba dừng ở line 3 vì thiếu Roblox global — `attempt to index nil with 'new'`, tức đã parse + bootstrap + decode xong phần chạy tới đó). Trên `lua54.exe` chính các file mẫu đó **sai cú pháp ngay line 3** (`syntax error near '-'`, `unexpected symbol near 'if'`) — corpus này là hàng **Luau-target**, không phải Lua 5.4.

### Release gate đầy đủ — lần chạy sau mục 19–20 (`node tools/run-release-tests.js`) — exit code 0, `total=220,723 ms`

Chạy **một mình**, 19 suite, `concurrency=4` (4 suite trong gate vẫn chia CPU nên wall mỗi suite lớn hơn wall standalone). Lần này là lần **đầu tiên** có **trần padding mới** (mục 19) và **`pickBracketLevel` đã sửa** (mục 20) đi qua gate cùng lúc.

**Tính tái lập được chứng minh bằng chính hai lần chạy:** `test-v590-forge.js` in census `builds:` **giống hệt từng byte** giữa bản standalone (`scratch/forge_v6caps.txt`) và bản gate này — `cmp` trên hai dòng 815 byte ⇒ **identical**, seed `0x59C0DE` tái lập được cả khi CPU bị tranh lẫn khi chạy sạch.

**Ghi chú phương pháp (đúng kiểu lỗi đã bị bắt ở mục 18):** lần gate chạy **trước** đó (`scratch/gate_v59_caps.log`) có một phép đo build-only của tôi chồng lên ~2 phút đầu, nên wall của nó phồng **366,161 ms** so với **220,723 ms** của bản chạy sạch — tức **+59% chỉ vì tranh CPU**, trong khi vẫn PASS 19/19. Mọi wall lấy từ file log đó **không** dùng để so chi phí; bảng dưới là bản chạy sạch.

| Suite | Kết quả | Thời gian |
|---|---|---|
| test-v580.js | PASS (output=209,504 B; assert `gained === padding + keyBed + measured base delta` vẫn đúng dưới trần mới) | 193,919ms |
| test-v590-blob.js | PASS (§2b mới: 7 đuôi đối kháng × 2 runtime + 576 container fuzz) | 60,519ms |
| test-v590-frontend.js | PASS | 522ms |
| test-v590-veilstr.js | PASS | 67,479ms |
| test-v590-precheck.js | PASS (16 fault class + 6 control + **12 route, 0 fatal, 108 check**, 209,985–467,007 B, 120 hằng số đã mã hóa) | 37,074ms |
| test-v590-junk.js | PASS (4 build / **146** carrier VM-read; 64/64 flip + 64/64 cut rejected, 2 runtime) | 92,302ms |
| test-v590-forge.js | PASS (14 cell envelope + tamper 36/36 + key bed 12/12 abort, `survivors=[]`) | 144,773ms |
| test-v590-envguard.js | PASS (4×3 attack; Lua 5.4 fail-closed 4/4/4; Luau từ chối cả 12 attack ở nền tảng) | 36,529ms |
| test-v590-antibundle.js | PASS (10 build, 6 verdict-key binding, **135** program native, 56 digest match, 62 attack abort) | 71,545ms |
| test-v510.js | PASS | 17,033ms |
| test-v479-payload.js | PASS | 8,870ms |
| test-v479-lps.js | PASS | 511ms |
| test-v479-register-isa.js | PASS | 22,041ms |
| test-v479-audit-fixes.js | PASS | 615ms |
| test-v479-bot.js | PASS | 2,930ms |
| test-v479-macros-lph.js | PASS | 32,579ms |
| test-v433.js | PASS | 2,524ms |
| test-v479-tail-return.js | PASS | 38,978ms |
| test-v479-policy.js | PASS | 24,511ms |

Ba suite forge-aware **đo lại standalone** ngoài gate để chắc trần mới không làm chúng pass nhờ coincidence: `test-v580.js` exit=0 **304 s**, `test-v510.js` exit=0 **28 s**, `test-v590-precheck.js` exit=0 **46 s**.

### Release gate đầy đủ (`node tools/run-release-tests.js`) — exit code 0

**[LỊCH SỬ — đã được thay bởi mục gate ở trên] Lần chạy sau toàn bộ mục 4–18 (19 suite, concurrency=4, budget 600,000 ms) — chạy **một mình**, không có tiến trình nào khác tranh CPU** — `total` là wall-clock của cả gate; thời gian mỗi suite là wall khi 4 suite tranh CPU nên lớn hơn wall standalone. Lần này là lần **duy nhất** có đủ cả bản sửa `vmMeta.wrapper.shape` (mục 18) lẫn regression `nest` trong `test-v510.js`: bằng chứng là `test-v510.js` hết **12,455 ms** thay vì 5,095 ms như lần trước, tức 4 assert nest mới thực sự được chạy.

| Suite | Kết quả | Thời gian |
|---|---|---|
| test-v580.js | PASS (output=209,504 bytes; wrapper + 6 đột biến đuôi colon trên 2 runtime) | 180,679ms |
| test-v590-blob.js | PASS (12 block VeilBlob) | 44,547ms |
| test-v590-frontend.js | PASS (+ grammar-valued literals) | 281ms |
| test-v590-veilstr.js | PASS (8 build / 16 run native / 96 hằng số / 822 byte / 8 material root khác nhau / 4+4 attack) | 74,806ms |
| test-v590-precheck.js | PASS (16 fault class + 6 control + 12 route, 0 fatal, 108 check; reparse 123.2 ms l1/stack → 204.6 ms maximum/register) | 43,507ms |
| test-v590-junk.js | PASS (146 carrier VM-read; 64/64 flip + 64/64 cut rejected) | 199,410ms |
| test-v590-forge.js | PASS (14 cell envelope + 36/36 abort + key bed 12/12 abort) | 143,256ms |
| test-v590-envguard.js | PASS (4 builds × 3 attacks; fail-closed 4/4/4; Luau refused 4/4 cả ba class) | 72,785ms |
| test-v590-antibundle.js | PASS (10 build, 135 program, 56 digest match, 62 attack abort, 6 binding) | 84,893ms |
| test-v510.js | PASS (version, name mangling, lane diversity, **wrapper opt-out spellings + nested-route shape honesty**, Stack/Register routing) | 12,455ms |
| test-v479-payload.js | PASS (6 runtime checks) | 6,604ms |
| test-v479-lps.js | PASS | 898ms |
| test-v479-register-isa.js | PASS (12 runtime cases) | 19,007ms |
| test-v479-audit-fixes.js | PASS | 347ms |
| test-v479-bot.js | PASS | 3,518ms |
| test-v479-macros-lph.js | PASS | 26,500ms |
| test-v433.js | PASS | 2,411ms |
| test-v479-tail-return.js | PASS (18 runtime checks, ISA=62/64) | 31,230ms |
| test-v479-policy.js | PASS | 18,306ms |
| **Gate tổng** | **PASS 19/19, exit=0** | **total=246,686ms** (concurrency=4; wall cả lệnh `time` = 4m6.929s) |

Lần chạy 19 suite **trước** bản sửa `wrapper.shape` (`total=177,975ms`, `test-v510.js` 5,095ms — tức **chưa** có regression nest): giữ làm mốc lịch sử, **không** dùng làm bằng chứng cho mục 18.

**Bài học đo lường từ hai lần fail trước (phải đọc trước khi khen gate):**
- Lần 1 (fail `test-v590-forge.js` + `test-v590-antibundle.js`, `total=286,674ms`): **không phải timeout** — hai suite đó bắt đúng lỗi engine mới (`2 !== 1`), tức fold latch bị nhân bản hai lần trong body. Đã sửa bằng một fold/một local (mục 16) và cả hai suite xanh trở lại.
- Lần 2 (fail 4 suite, `total=981,753ms`): **hỏng ở chính harness**, không phải engine. `test-v590-junk.js` chạy standalone **81.5 s** nhưng trong gate bị tính >300 s → runner `SIGTERM` nó, và **trên Windows child không nhận con cháu `lua54.exe`/`luau.exe`**, nên `close` chỉ fire sau 954 s ⇒ slot concurrency bị chiếm dây chuyền, 4 suite cùng "timeout". Đã sửa trong `tools/run-release-tests.js`: budget **600,000 ms** (gấp ~2.5 lần worst-case contended đo được 154,799 ms) + `KILL_GRACE_MS=15,000` để settle dù pipe còn mở. Lần 3 chạy một mình: PASS 19/19.

Lần chạy sau mục 4–15 (15 suite, trước VeilStr + precheck): **PASS 15/15, exit=0, total=145,375ms** (concurrency=4).

| Suite (lịch sử, 15 suite) | Kết quả | Thời gian |
|---|---|---|
| test-v580.js | PASS (output=210,037 bytes) | 130,506ms |
| test-v590-blob.js | PASS (12 block VeilBlob) | 38,567ms |
| test-v590-junk.js | PASS (carrier VM-read; flip + cut rejected) | 145,300ms |
| test-v590-forge.js | PASS (14 cell envelope + census fail-closed) | 107,087ms |
| test-v590-envguard.js | PASS (4 builds × 3 attacks; fail-closed 4/4/4) | 56,183ms |
| test-v510.js | PASS | 3,735ms |
| test-v479-payload.js | PASS (6 runtime checks) | 3,984ms |
| test-v479-lps.js | PASS | 457ms |
| test-v479-register-isa.js | PASS (12 runtime cases) | 12,387ms |
| test-v479-audit-fixes.js | PASS | 267ms |
| test-v479-bot.js | PASS | 2,087ms |
| test-v479-macros-lph.js | PASS | 16,069ms |
| test-v433.js | PASS | 1,423ms |
| test-v479-tail-return.js | PASS (18 runtime checks, ISA=62/64) | 19,954ms |
| test-v479-policy.js | PASS | 10,436ms |
| **Gate tổng** | **PASS 15/15, exit=0** | **total=145,375ms** (concurrency=4) |

Lần chạy sau mục 4–13 (trước key bed + wrapper): 15 suite, **PASS 15/15, exit=0, total=111,260ms** (concurrency=4).

Chi phí thật của padding lên chính test suite (cùng lệnh, chạy standalone, không tranh CPU): `test-v590-junk.js` **19,974ms → 64,933ms** và `test-v580.js` **82,378ms → 92,714ms**, vì mỗi build của chúng giờ mang thêm 140 KB → 2.3 MB container. Đây là chi phí đo được, không phải timeout.

Bảng lịch sử (14 suite, chạy sau mục 4–11, trước P1/P3):

| Suite | Kết quả | Thời gian |
|---|---|---|
| test-v580.js | PASS (output=65,555 bytes) | 82,378ms |
| test-v590-blob.js | PASS (12 block VeilBlob) | 27,349ms |
| **test-v590-junk.js (mới)** | PASS (144 carrier VM-read; 64/64 flip + 64/64 cut rejected) | 48,489ms |
| **test-v590-envguard.js (mới)** | PASS (4 builds × 3 attacks; fail-closed 4/4/4; guard reason 4/4 mỗi attack) | 22,970ms |
| test-v510.js | PASS | 4,382ms |
| test-v479-payload.js | PASS (6 runtime checks) | 5,406ms |
| test-v479-lps.js | PASS | 480ms |
| test-v479-register-isa.js | PASS (12 runtime cases) | 16,265ms |
| test-v479-audit-fixes.js | PASS | 382ms |
| test-v479-bot.js | PASS | 2,638ms |
| test-v479-macros-lph.js | PASS | 12,947ms |
| test-v433.js | PASS | 2,070ms |
| test-v479-tail-return.js | PASS (18 runtime checks, ISA=62/64) | 19,403ms |
| test-v479-policy.js | PASS | 11,171ms |
| **Gate tổng** | **PASS 14/14, exit=0** | **82,382ms** (concurrency=4) |

Trước fix DLL: gate FAIL 6/11 (cùng lệnh, exit=1, total=5,676ms). Các lần chạy trước đó: 12 suite total=68,248ms; 11 suite total=61,054ms (concurrency=8) — giữ làm mốc lịch sử. `test-v580.js` tăng 68.2s → 82.4s đi kèm output sample lớn hơn (61,937 → 65,555 bytes, số in ra từ chính suite), tức do workload thật chứ không phải timeout.

### Kiểm chứng "decoy không nằm trên đường thực thi" (48 combo)

`l1/l2/df/nest` × 6 seed × {Lua 5.4, Luau} = **48/48** chạy đúng digest (`30`) trên build có rải decoy; inspect cấu trúc: `l1` 18 blob / 11 carrier sống / 4 container gán raw, `df` 25 blob / 19 sống / 3 raw, `nest` không có carrier bed (3 blob, 0 decoy rải). *(Số "carrier sống" ở đây đo **trước** mục 10 bằng đúng vết `string.sub(`; sau mục 10, cùng phép đếm cộng thêm 3–6 carrier rác/build — benchmark mới nhất: avg 30.25 carrier sống/output.)*

### Frontend v5.9 (giữ nguyên patch ChatGPT, không revert)

- `node test-v590-frontend.js` — PASS, exit=0 (diagnostics, escapes, numeric literals, CRLF, long comments, Unicode, interpolation).
- API giữ nguyên: `parse()` trả AST như cũ; `parseDetailed()` là API bổ sung. Backend không đổi hợp đồng nào của frontend.

### Benchmark bằng chứng thực thi, lần chạy hiện tại sau mục 16–18 (`node tools/benchmark-v580-wrap.js`) — exit code 0, wall 230,796ms

Chạy lại toàn bộ sau VeilStr-v1 (mục 16), precheck (mục 17) và năm lỗi sửa ở mục 18 — **mọi con số dưới đây đo từ output của lần chạy này**, không kế thừa bảng cũ. Cùng fixture, cùng 8 seed (`1001–1004`, `2001–2004`), cùng 4 arm stack/register × 2 runtime. Wall tăng 172,710 → **230,796 ms** vì mỗi build giờ còn bị precheck reparse và từng constant đi qua cipher.

Benchmark đã **sửa để tách padding** (`forgePaddingRange()` excise khối JunkForge trước khi đo share/entropy/primitive): mọi tỷ lệ cấu trúc dưới đây tính trên **payload bytes**, không phải file đã pad — nếu không, ~133 KB padding sẽ làm slot share và entropy vô nghĩa.

Execution evidence (8 seeds × stack/register, chạy output thật **trong harness** trên Lua 5.4 **và** Luau):

- Unmodified baseline chạy đúng digest **trước** mọi test tamper/ablation: **16/16**.
- Carrier ablation fail-closed: **245 container sống** lật 1 byte ciphertext → **490/490** runtime check chết đúng (tăng từ 242/484 vì payload có thêm container sau khi cipher làm đổi cách phân lớp).
- Unused container ablation: **26 container gán raw** lật cùng vị trí → **52/52** vẫn chạy và trả **đúng cùng digest** (bằng chứng thực thi rằng chúng không mang payload).
- `containersInStagesNotAttributedToEither = 0`; mọi container trong 3 slot bootstrap đều được xếp loại sống/không dùng, và padding được định vị lại trong text để **không** bị đếm nhầm: cross-check `containers trong khối forge === analysis.padding.containers === vmMeta.junkForge.containers` pass trên cả 8 build, đồng thời **cả 3 slot bootstrap đều bắt đầu sau** khối padding.
- Isolated single-slot attack: **48/48** fail vì runtime error (không phải `syntax error`); mỗi slot chứa **4/6** VM primitive hiện hành.
- Metatable lock + root stdlib/pow2 tamper: **32/32** fail-closed. Static scraper: **16 checks, 0 leaks**. Single-execution differential semantics: **32/32**.
- Cross-seed: mean hex-dispatch Jaccard **0.00048**, bootstrap-slot Jaccard **0**, register-permutation collisions **0**.
- `wrapperTails` đếm từ chính nhãn telemetry: `callable-object` **6**, `colon-dispatch` **2** — không build nào trong lô này là `nest`, nên nhãn mới `bootstrap-in-nested-source` (mục 18) **không** xuất hiện ở đây; đường nest được phủ bởi `test-v590-forge.js`, `test-v590-veilstr.js` và `test-v510.js`.

Structural metrics (đo thật, **chỉ mô tả hình dạng output**, không phải bằng chứng chống RE): payload trung bình **77,215.25 B** (76,217–78,303), padding trung bình **132,659.88 B** (131,192–133,744), output trung bình **209,967.13 B** (209,497–210,389), **319.25** container padding/build, **356.75** container tổng mỗi output, avg **30.63** carrier sống + **3.25** container thừa. Slot shares (payload-only) **31.4 / 34.02 / 30.31%**, max slot **36.74%**, normalized entropy **0.99**, live carriers ngoài body **70.16%** (64.3–73.5), container không dùng **9.68%** carrier bed (5.6–12.9), VM subsystems ngoài body **100%**, max single-slot exposure **66.67% (4/6)**.

**Đọc chênh lệch với lần trước cho đúng:** payload +**3,253.75 B** (73,961.5 → 77,215.25, +4.4%) là chi phí ciphertext của VeilStr trên các constant; output chỉ +**2,210.63 B** vì JunkForge pad tới **floor**, nên payload to hơn thì padding **co lại** (133,703 → 132,659.88). Đây đúng là tính không đơn-điệu theo preset đã ghi ở LIMITATIONS, lần này lộ ra giữa hai lần chạy benchmark trên cùng fixture.

Per-build (`build ms` gồm cả cipher + precheck reparse + JunkForge seal; dòng 1001 là build **đầu tiên của process** nên cao bất thường — xem caveat cold-build trong LIMITATIONS, các steady-state build từ 230 đến ~700 ms):

| seed | backend | tail | topology | payload B | padding B | output B | pad containers | containers total | live | unused | build ms | max slot % | entropy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1001 | stack | callable-object | trampoline-first | 77,120 | 132,285 | 209,497 | 312 | 346 | 27 | 4 | 1,450.75 | 36.9 | 0.9902 |
| 1002 | register | callable-object | trampoline-first | 76,254 | 133,684 | 210,030 | 329 | 368 | 33 | 3 | 697.31 | 35.8 | 0.9922 |
| 1003 | stack | callable-object | entry-first | 78,271 | 131,708 | 210,071 | 310 | 346 | 28 | 3 | 559.34 | 38.8 | 0.9842 |
| 1004 | register | callable-object | entry-first | 77,199 | 133,060 | 210,351 | 312 | 353 | 34 | 4 | 602.04 | 37.7 | 0.9883 |
| 2001 | stack | colon-dispatch | trampoline-first | 78,303 | 131,192 | 209,587 | 313 | 349 | 29 | 3 | 347.15 | 37.0 | 0.9896 |
| 2002 | register | colon-dispatch | trampoline-first | 76,217 | 133,744 | 210,053 | 329 | 368 | 32 | 3 | 230.05 | 36.2 | 0.9910 |
| 2003 | stack | callable-object | trampoline-first | 77,285 | 133,012 | 210,389 | 324 | 359 | 28 | 4 | 297.97 | 36.2 | 0.9915 |
| 2004 | register | callable-object | trampoline-first | 77,073 | 132,594 | 209,759 | 325 | 365 | 34 | 2 | 254.20 | 35.3 | 0.9928 |

Bốn fingerprint v5.8 vẫn **0 trên cả 8 seed** (`signatureRetirement.measuredRetiredCountsPerBuild`): `\*85\+` = 0, `\[0x…\]=function\(` = 0, `\.irep|\.crep` = 0, hằng FNV = 0 — VeilStr và precheck không hồi sinh bất kỳ dạng nào từng bị retirement.

**Đổi bộ nhận dạng primitive (phải đọc trước khi so với số cũ):** bốn fingerprint v5.8 không còn tồn tại trong output v5.9 — detector vì thế được **đổi đích** sang 6 ký hiệu hiện hành: `opcodeDispatchTable` (`[\d+]=0x[0-9a-f]{3,4}`, ≥24), `semanticHandlerBodies` (`[\d+]=function\(`, ≥8), `carrierStreamCipher` (`function(S,A,O,R,K,Z,Q)`, ≥1), `radix24BitUnpack` (`*93+` **và** `16777216`, ≥1), `modularLaneArithmetic` (`%256|%65536`, ≥8), `guardedExecutionSurface` (`setmetatable(|pcall(`, ≥2). Hệ quả **phải khai báo với Arena**: số "exposure 66.67% (4/6)" và "subsystems ngoài body 100%" của lần này **không so sánh được** với 33.33% (2/6) / 54.17% của v5.8 — mẫu số và định nghĩa primitive đã đổi, không phải output xấu đi hay tốt đi.

### [LỊCH SỬ] Benchmark bằng chứng thực thi, lần chạy sau P1+P3 (trước VeilStr + precheck) — exit code 0, wall 172,710ms

Benchmark đã **sửa để tách padding** (`forgePaddingRange()` excise khối JunkForge trước khi đo share/entropy/primitive): mọi tỷ lệ cấu trúc dưới đây tính trên **payload bytes**, không phải file đã pad — nếu không, 133 KB padding sẽ làm slot share và entropy vô nghĩa.

Execution evidence (8 seeds × stack/register, chạy output thật **trong harness** trên Lua 5.4 **và** Luau):

- Unmodified baseline chạy đúng digest **trước** mọi test tamper/ablation: **16/16**.
- Carrier ablation fail-closed: **242 container sống** lật 1 byte ciphertext → **484/484** runtime check chết đúng.
- Unused container ablation: **26 container gán raw** lật cùng vị trí → **52/52** vẫn chạy và trả **đúng cùng digest** (bằng chứng thực thi rằng chúng không mang payload).
- `containersInStagesNotAttributedToEither = 0`; mọi container trong 3 slot bootstrap đều được xếp loại sống/không dùng, và padding được định vị lại trong text để **không** bị đếm nhầm: phép cross-check `containers trong khối forge === analysis.padding.containers === vmMeta.junkForge.containers` pass trên cả 8 build, đồng thời **cả 3 slot bootstrap đều bắt đầu sau** khối padding.
- Isolated single-slot attack: **48/48** fail vì runtime error (không phải `syntax error`); mỗi slot chứa **4/6** VM primitive hiện hành.
- Metatable lock + root stdlib/pow2 tamper: **32/32** fail-closed. Static scraper: **16 checks, 0 leaks**. Single-execution differential semantics: **32/32**.
- Cross-seed: mean hex-dispatch Jaccard **0.00048**, bootstrap-slot Jaccard **0**, register-permutation collisions **0**.

Structural metrics (đo thật, **chỉ mô tả hình dạng output**, không phải bằng chứng chống RE): payload trung bình **73,961.5 B** (72,968–75,080), padding trung bình **133,703 B** (132,831–134,630), output trung bình **207,756.5 B** (207,459–208,122), **324.13** container padding/build, **361.25** container tổng mỗi output, avg **30.25** carrier sống + **3.25** container thừa. Slot shares (payload-only) 30.64 / 34.57 / 30.39%, max slot **37.94%**, normalized entropy **0.9864**, live carriers ngoài body **70.16%** (64.3–73.5), container không dùng **9.85%** carrier bed (5.6–14.3), VM subsystems ngoài body **100%**, max single-slot exposure **66.67% (4/6)**.

Per-build (build time gồm cả JunkForge seal + topping-up):

| seed | backend | topology | payload B | padding B | output B | pad containers | build ms | max slot % | entropy |
|---|---|---|---|---|---|---|---|---|---|
| 1001 | stack | trampoline-first | 73,681 | 133,698 | 207,471 | 321 | 593.26 | 38.1 | 0.9861 |
| 1002 | register | trampoline-first | 72,968 | 134,630 | 207,690 | 326 | 342.57 | 37.1 | 0.9891 |
| 1003 | stack | entry-first | 75,080 | 132,831 | 208,003 | 332 | 311.23 | 40.1 | 0.9786 |
| 1004 | register | entry-first | 73,830 | 133,842 | 207,764 | 317 | 297.51 | 38.9 | 0.9845 |
| 2001 | stack | trampoline-first | 74,309 | 133,492 | 207,893 | 320 | 292.46 | 37.3 | 0.9882 |
| 2002 | register | trampoline-first | 73,151 | 134,407 | 207,650 | 328 | 269.46 | 37.3 | 0.9883 |
| 2003 | stack | trampoline-first | 74,349 | 133,018 | 207,459 | 320 | 267.53 | 37.6 | 0.9878 |
| 2004 | register | trampoline-first | 74,324 | 133,706 | 208,122 | 329 | 253.47 | 37.1 | 0.9888 |

**Đổi bộ nhận dạng primitive (phải đọc trước khi so với số cũ):** bốn fingerprint v5.8 không còn tồn tại trong output v5.9 — đo trực tiếp trên cả 8 seed × các preset: `\*85\+` = 0, `\[0x[0-9a-f]\{3,4}\]=function\(` = 0, `\.irep|\.crep` = 0, hằng FNV `16777619|2166136261` = 0 (`signatureRetirement.measuredRetiredCountsPerBuild`). Detector vì thế được **đổi đích** sang 6 ký hiệu hiện hành: `opcodeDispatchTable` (`[\d+]=0x[0-9a-f]{3,4}`, ≥24), `semanticHandlerBodies` (`[\d+]=function\(`, ≥8), `carrierStreamCipher` (`function(S,A,O,R,K,Z,Q)`, ≥1), `radix24BitUnpack` (`*93+` **và** `16777216`, ≥1), `modularLaneArithmetic` (`%256|%65536`, ≥8), `guardedExecutionSurface` (`setmetatable(|pcall(`, ≥2). Hệ quả **phải khai báo với Arena**: số "exposure 66.67% (4/6)" và "subsystems ngoài body 100%" của lần này **không so sánh được** với 33.33% (2/6) / 54.17% của v5.8 — mẫu số và định nghĩa primitive đã đổi, không phải output xấu đi hay tốt đi.

### Benchmark bằng chứng thực thi (`node tools/benchmark-v580-wrap.js`) — exit code 0, lần chạy trước P3

Execution evidence (đo bằng cách chạy output thật **trong harness** trên Lua 5.4 **và** Luau, 8 seeds × stack/register; output sinh ra trung bình **73,853 bytes**, range 72,858–74,973 — tăng so với 70,496 trước mục 10 vì mỗi build mang thêm 3–6 carrier rác):

- Unmodified baseline chạy đúng digest **trước** mọi test tamper/ablation: **16/16**.
- Carrier ablation fail-closed: **242 container sống** (gồm carrier rác dạng `function`) được lật 1 byte ciphertext → **484/484** runtime check chết đúng (trước fix là `462/462` vacuous, xem mục 9; trước mục 10 là 205/410).
- **Unused container ablation**: **26 container gán raw** lật cùng vị trí byte → **52/52** check vẫn chạy và trả **đúng cùng digest** — bằng chứng thực thi rằng chúng không mang payload, không chỉ là suy luận từ regex.
- Phân loại phủ kín: `containersInStagesNotAttributedToEither = 0` (mọi container trong 3 slot bootstrap đều được xếp loại sống/không dùng, không có blob âm thầm bị bỏ qua).
- Isolated single-slot attack: gọi riêng từng slot standalone phải fail **và fail vì runtime error chứ không phải `syntax error`**: **48/48**; mỗi slot chỉ chứa **2/6** VM primitives.
- Metatable lock + root stdlib/pow2 binding tamper (bọc harness + assert tìm đúng target): **32/32** fail-closed.
- Static scraper (secret const `BV_SECRET_CONST_ALPHA` + diagnostic strings, sau khi strip blob): **16 checks, 0 leaks (0%)**; đồng thời assert không còn `\ddd` nào trong body sau strip.
- Single-execution differential semantics: **32/32** trên cả 2 runtime × wrap() × obfuscate() stack/register.
- Topology differentiation: `entry-first` / `trampoline-first` đảo 2 subsystem + chain `__call→…`; semantics giống hệt giữa các seed.
- Cross-seed: mean hex-dispatch Jaccard **0.00048**, bootstrap-slot Jaccard **0**, register-permutation collisions **0**.

Structural metrics (đo thật, **chỉ mô tả hình dạng output**): avg slot shares 30.65/34.61/30.44% (entry/dispatch/body), max slot share 37.99%, normalized entropy 0.9865, live carriers ngoài body **70.16%** (64.3–73.5), **container không dùng chiếm 9.85% carrier bed** (5.6–14.3), avg **30.25** carrier sống + **3.25** container thừa/output (**37.13** container tất cả), VM subsystems ngoài body 54.17%, max single-slot exposure 33.33% (2/6).

## RUN — lệnh đã dùng + exit code (chu kỳ mục 19–20: trần padding + sửa bracket)

Mọi lệnh dưới đây chạy **một mình** theo từng loạt; hai wall của `run-release-tests.js` cho thấy lý do phải nghiêm túc chuyện đó (+59% chỉ vì tranh CPU, xem ghi chú phương pháp ở mục gate).

```
node tools/run-release-tests.js              # exit=0  PASS 19/19, total=220,723ms (bản chạy sạch)
node tools/run-release-tests.js              # exit=0  PASS 19/19, total=366,161ms (bản có 1 phép đo build-only chồng 2 phút đầu — giữ lại làm bằng chứng nhiễu)
node test-v590-blob.js                       # exit=0  PASS, standalone 124,541ms (gồm §2b mới)
node test-v580.js                            # exit=0  PASS, standalone 304s
node test-v510.js                            # exit=0  PASS, standalone 28s
node test-v590-precheck.js                   # exit=0  PASS, standalone 46s
node scratch/probe_bracket_level.js          # exit=0  14/14 container escalated load đúng byte trên lua54+luau
node scratch/probe_99kb_df.js                # trước fix: lua54 "unexpected symbol near ']'" + 4 diagnostic line 2 col 648264; sau fix: 0 diagnostic
node scratch/probe_junk_caps.js              # exit=0  bảng input → payload → padding → cap → capBinding
node scratch/probe_scale_curve.js            # exit=0  curve 1/2/4/8/14/22 statement + 12 sample Luraph (kết quả: scratch/scale_results.json)
node scratch/probe_load_toggle.js            # exit=0  13 toggle, 22,690–44,602ms, không outlier
node scratch/probe_stall.js                  # exit=0  phân biệt "treo" vs "chậm" (5,343 / 39,139 / >90,000 / 10,191 ms)
```

## RUN — lệnh đã dùng + exit code (lần chạy hiện tại, cho bàn giao v5)

Mỗi lệnh dưới đây chạy **một mình**, không có tiến trình Node/lua nào khác tranh CPU. Đây là điểm khác
biệt với các RUN block trước: những wall ghi trong block cũ (`33,609ms` forge, `64,933ms` junk,
`8,283ms` v510…) đo trong phiên có **10 suite chạy song song**, tức là wall của tiến trình bị tranh —
giữ nguyên ở đó làm lịch sử nhưng **không** dùng để so sánh chi phí nữa.

```
node tools/run-release-tests.js                 # exit=0  PASS 19/19, total=246,686ms, concurrency=4, wall 4m6.929s
node test-v510.js                               # exit=0  PASS, standalone wall 6,593ms (có 4 assert nest của mục 18)
node scratch/probe_nest_shape_fix.js            # exit=0  60 build / 60 native run / problems=0, wall ~5m
node scratch/probe_veil_matrix_v2.js            # exit=0  420 build / 420 ciphered / 420 native run / 0 semantic failure / 0 shape mismatch, wall 9m50.707s
```

## RUN — lệnh đã dùng + exit code (chu kỳ mục 21–22: đường bit + tên định danh)

Mỗi lệnh chạy **một mình**; gate chạy riêng, không chồng với probe nào. Wall đo bằng `date +%s%3N` bọc quanh lệnh, Git Bash trên máy 8 nhân.

```
node test-v590-bitops.js                        # exit=0  PASS, standalone wall 14,944ms (suite thứ 20 của gate)
node tools/run-release-tests.js                 # exit=0  PASS all 20 suites, concurrency=4, total=274,910ms
node tools/native-test.js                       # exit=0  6/6 PASS (luau register+stack parse check đã chạy trở lại, xem ghi chú harness)
node scratch/probe_bitops_e2e.js                # exit=0  all 4 cells match the 32-bit floor oracle, wall 7,058ms
node scratch/probe_bit_derive.js                # exit=0  derivation checked=3000120 mismatches=0, wall 824ms
node scratch/ab_outcmp.js                       # exit=0  all 10 cells print identical program output on both hosts, wall 36,460ms
node scratch/probe_name_hole.js                 # exit=0  before=9/300000 hole-shaped, after=0, wall 15,784ms
BV_ROUNDS=5 node scratch/probe_ab_interleaved.js   # exit=0  10 cell (5 source x 2 host), scratch/ab_bitops_full5.json
BV_NAMES="bitheavy strheavy tiny" BV_ROUNDS=9 BV_OUT=ab_bitheavy_focus.json node scratch/probe_ab_interleaved.js   # exit=0  scratch/ab_bitheavy_focus.json
node scratch/bit_toggle.js restore              # exit=0  "restored current generators (byte-identical to backups)"
```

Các lệnh A/B **không** đưa ra kết luận tốc độ cho band/bor (dấu delta đảo giữa hai lần chạy, control lệch tới +31%); chúng được giữ làm bằng chứng phương pháp — xem LIMITATIONS "Đường bit sau chu kỳ này".

Ghi chú harness: `tools/native-test.js` trước đây abort hai cell `luau/register` + `luau/stack` bằng `unexpected engine path` vì nó đòi `vmMeta.fallback === true`, trong khi route Luau đang ship là custom VM (`fallback:false`, `backend:"custom-vm"`) — hai phép kiểm tra cú pháp trên Luau vì thế **không chạy** mà không ai thấy. Giờ chấp nhận cả hai đường hợp lệ và luôn chạy parse check; đó là lý do block này báo 6/6 chứ không phải 4/6.

**Bằng chứng cross-route của bản sửa `wrapper.shape` (mục 18)** — `scratch/probe_veil_matrix_v2.js` phủ
2 target × 3 mode × 7 preset × 2 nhánh wrapper × 5 nguồn (`strings / nested / utf8 / numbers / vararg`),
mỗi build vừa assert hình dạng đuôi vừa **chạy native** và so với output không bảo vệ:

- `builds=420 ciphered=420 native runs=420 semantic failures=0 wrapper-shape mismatches=0 not-ciphered=0`
- `ciphered constants=3668 ciphered bytes=28280`, phủ đều 7 preset: `{l1:60, l2:60, nest:60, df:60, lz:60, default:60, maximum:60}`
- Nhánh `nest` riêng rẻ: `probe_nest_shape_fix.js` = 60 build / 60 native run / `problems=0`, trong đó
  mọi build có wrapper báo `bootstrap-in-nested-source` và mọi build tắt wrapper báo
  `no-callable-bootstrap-tail` — đúng như hợp đồng regression trong `test-v510.js`.

**Caveat phương pháp (đọc kèm):** trong cùng một khung thời gian tôi từng có **ba** lần sweep chồng lên nhau
và một lần in ra `MATRIX_EXIT=127` (lệnh không tồn tại), cộng một file `veil_matrix_full.txt` báo 60 build
`nest` fail precheck. 60 fail đó **không phản ánh mã hiện tại**: chúng sinh ra từ một lần chạy trước khi
nhánh `nested-source-loader` của precheck tồn tại (`src/core/precheck.js`, check số 9). Kết quả của lần
chồng nhau ấy tôi **không trích dẫn**, và con số ở trên lấy từ một lần chạy duy nhất, cây source đóng băng,
exit code ghi thẳng vào file.

Tất cả chạy trên Windows x64, Node v24.20.0, `lua54.exe` (Lua 5.4.8) + `luau.exe` (0.739) trong `tools/native/windows-x64/`.

## RUN — lệnh đã dùng + exit code (chu kỳ mục 23–27: bump, cách ly legacy, knob stub, giá trị đóng, báo đúng route)

Mỗi lệnh chạy **một mình**; gate chạy riêng, không chồng probe nào (đó là lý do wall của gate ~250 s trong khi các suite của nó chạy một mình nhanh hơn nhiều).

```
node tools/run-release-tests.js                 # exit=0  PASS all 21 suites, concurrency=4, total=253,199ms  [sau mục 26] -> scratch/vsnap/gate_v590_final3.log
node tools/run-release-tests.js                 # exit=0  PASS all 21 suites, concurrency=4, total=249,052ms  [sau mục 27] -> scratch/vsnap/gate_v590_final4.log
node tools/run-release-tests.js                 # exit=0  PASS all 21 suites, concurrency=4, total=243,336ms  [lần 5 — CẠNH TRANH với một lệnh khác tình cờ chạy cùng, không dùng làm số chốt] -> scratch/vsnap/gate_v590_final5.log
node tools/run-release-tests.js                 # exit=0  PASS all 21 suites, concurrency=4, total=223,239ms  [lần 6 — CHẠY MỘT MÌNH trên đúng cây ship, đây là số chốt] -> scratch/vsnap/gate_v590_final6.log
node test-v590-tree.js                          # exit=0  PASS, standalone wall 9,964ms
node test-v510.js                               # exit=0  PASS, standalone wall 5,907ms
node test-v580.js                               # exit=0  PASS, standalone wall 64,530ms (trong gate contention: 190,037ms — cùng nội dung)
node tools/native-test.js                        # exit=0  6/6 check PASS (luau/register, luau/stack, lua/register, lua/stack, 2 runtime)
node scratch/probe_option_enum_values.js        # exit=0  201 files / 269 obfuscate() call sites — nguồn cho ENUMS
node scratch/probe_enum_refusal.js              # exit=0  8/8 typo bị từ chối + 9/10 giá trị hợp lệ build được; dòng thứ 10 là `nestedProfile:"full"` — trước bản vá nó ACCEPTED, sau khi retire nó REFUSED (log: scratch/vsnap/enum_refusal_after.log)
node scratch/probe_nested_profile.js            # exit=0  6 route cell, distinct=false mọi cell => nestedProfile INERT
node scratch/knob_baseline.js <after.json>      # exit=0  24/24 sha256 trùng baseline, 0 khác (so với knob_baseline_enum2.json)
node scratch/probe_source_route_luau.js         # exit=0  5 fixture x 2 route; if/elif chỉ source container nhận
node scratch/probe_luau_scanner_before.js       # exit=0  3 artifact: scanner cũ FAIL (']' / ')' / '}'), scanner mới pass
node scratch/probe_v590_item26.js               # exit=0  bảng size/shape 6 cấu hình wrapper + 3 backend route + 9 refusal
```

Bằng chứng byte-neutrality của cả chu kỳ 23–27: **24 cell** (6 preset × 2 target × 2 mode, seed `0x59c0de`,
`junkForge:false`) sha256 **trùng 24/24**, và 5 hash route `backend:"source"` (input Lua thường + 4 fixture
Luau-only) **trùng từng ký tự** trước/sau các sửa đổi report — `scratch/vsnap/knob_baseline_report.json`,
`scratch/vsnap/source_route_luau.log`. Những gì đổi sau mục 27 chỉ là **metadata** (`runtime`, `validation.runtime`,
`vmMeta.wrapper.enabled/returnMode`) — không phải byte artifact.

## RUN — lệnh đã dùng + exit code (chu kỳ mục 28–31: multiple-return trong constructor + hint array-part + subtype và ngữ pháp số)

Ba lần gate **FAIL** đầu tiên không phải do artifact: cả ba stop ở `test-v580.js` vì chính suite chọn sai carrier để đột biến (`stageBlobs[0]` sau khi body `NEWTABLE` đổi số byte đã trở thành một decoy trơ — lớp được thiết kế để SỐNG). Ghi lại đủ ba log vì "gate đỏ vì bug của test" là thông tin, không phải chi tiết làm xấu báo cáo.

```
node tools/run-release-tests.js                 # exit=1  FAIL (test-v580.js; total=175,483ms) — bug chọn carrier  -> scratch/gate-1793497836.log
node tools/run-release-tests.js                 # exit=1  FAIL (test-v580.js in 64,276ms; total=244,911ms) — sau mục 29, bug vẫn còn  -> scratch/gate-newtable-20261101-091314.log
node tools/run-release-tests.js                 # exit=1  FAIL (test-v580.js in 54,637ms; total=237,996ms) — hint đã tinh chỉnh, bug vẫn còn  -> scratch/gate-newtable-refined-1793501203.log
node tools/run-release-tests.js                 # exit=0  PASS all 23 suites, concurrency=4, total=338,456ms  [chốt mục 28–30]  -> scratch/gate-multiret-final-1793501949.log
node tools/run-release-tests.js                 # exit=0  PASS all 23 suites, concurrency=4, total=312,359ms  [CHỐT CẢ CHU KỲ, sau bản vá ngữ pháp số mục 31]  -> scratch/gate-hexfloat-1793504487.log
node test-v590-multiret.js                      # exit=0  36 pin (31 lua54 + 5 luau) / 156 artifact cell, standalone wall 120s  -> scratch/multiret-standalone.log
node test-v580.js                               # exit=0  PASS với ablation mọi callable carrier, standalone wall 49s (lần khác cùng cây: 37s)  -> scratch/v580-standalone3.log
node tools/verify-multiret-fidelity.js          # exit=0  cases=27 cells=216, "host divergence (native vs native): none", 24 dòng mismatch còn lại  -> scratch/verify-multiret-fidelity.log
node tools/verify-newtable-frequency.js         # exit=0  TOTAL: 1/18 constructor trả phần fill, 3 slot materialise  -> scratch/verify-newtable-frequency.log
node tools/verify-carrier-classes.js            # exit=0  stage 1/2/3 = 4/3/8 callable carrier, 15/15 chết, decoy sống  -> scratch/verify-carrier-classes.log
node test-v590-numeric.js                       # exit=1  `Malformed numeric literal near "1._"` — pin mới thêm vào đã tự bắt bản vá lexer còn thiếu `_` ngay sau dấu chấm; sửa regex rồi chạy lại dòng dưới
node test-v590-numeric.js                       # exit=0  39 pin (32 lua54 + 7 luau) / 160 artifact cell, standalone wall 66s  -> scratch/numeric-standalone2.log
node scratch/probe_numeric_fidelity.js          # exit=0  cases=31 mismatches=0 (TRƯỚC bản vá subtype: mismatches=10)  -> scratch/vsnap/numeric_fidelity_{before,after}.log
node scratch/probe_hexfloat.js                  # exit=0  bảng 17 cách viết × 2 host; sau bản vá: cột pipeline = "VM ok" trên MỌI dòng mà host nhận  -> scratch/vsnap/hexfloat_after.log
node scratch/probe_numeric_edges.js             # exit=0  SUMMARY edge cases=15 mismatches=0 (1 ca host tự reject `1e1_0` trên lua54, được ghi là HOST-REJECTS chứ không tính là diff)  -> scratch/vsnap/numeric_edges_after.log
node test-v590-frontend.js                      # exit=0  PASS, grammar-valued literals + 5 nguồn phải báo "Malformed numeric literal" vẫn đúng sau khi viết lại NUMERIC_LITERAL
node scratch/probe_numeric_neutrality.js        # exit=0  files=258 numerals=781,901 files_with_value_change=0 files_with_spelling_change=0 + CONTROL spellings=6 value_change=4 spelling_change=5  -> scratch/neutrality-final.log
node scratch/probe_concat_lex.js                # exit=0  7 ca số-cạnh-`..`: VM stdout == naked stdout (lua+luau); `6.."a"` bị reject bằng chính message của host
tools/native/windows-x64/lua54.exe scratch/_c.lua + luau.exe scratch/_c.luau  # đo từng ca `print(6 .. "a")` / `print(6.."a")` / `print(1.."a")` / `print(1.5.."a")` trên CẢ HAI host trước khi kết luận (cả ba ca không có space đều `malformed number`)
tools/native/windows-x64/lua54.exe scratch/newtable_cost_bench.lua   # 2M lặp × 7 vòng interleaved, best-of — bảng delta trong mục 29
tools/native/windows-x64/luau.exe  scratch/newtable_cost_bench.lua   # cùng script, cùng cách lấy best-of
tools/native/windows-x64/lua54.exe scratch/hashorder.lua             # đảo thứ tự ghi: chữa 5.4, Luau vẫn #=0  -> lý do không sửa được bằng API công khai
tools/native/windows-x64/luau.exe  scratch/hashorder.lua
tools/native/windows-x64/lua54.exe scratch/hashfill.lua              # độn array part: giữ pre-size nhưng lọt giá trị độn ra `#` khi có tail giãn
tools/native/windows-x64/luau.exe  scratch/hashfill.lua
node tools/package-release-v590.js ../<archive>.zip  # exit=0 — entry count xem mục ĐÓNG GÓI bên dưới; legacy/ fail-closed, credential loại 2 file
```

Cửa `run-release-tests` được chốt **bằng log**, không bằng exit code của lệnh shell cuối: nhiều lần `echo $?` sau `;` báo 0 của chính lệnh `echo`/`ls` chứ không phải của node. Bài học này đã khiến một lần gate FAIL bị đọc nhầm thành PASS ở chu kỳ trước, nên từ mục 28 trở đi exit code của gate ghi thẳng vào file (`scratch/gate-last-exit.txt`: `gate_exit=0`) và đối chiếu lại với dòng chốt của log.

Con đường ban đầu để chứng minh lexer mới không đổi artifact — so 24 cell sha256 với baseline đóng băng — **đã thử và bỏ**: `scratch/vsnap/knob_baseline_before.json` (chụp 31/10, **trước** mục 28–30) đối với `scratch/vsnap/knob_baseline_after_lexer.json` cho `cells=24 identical=0 differing=24` (ví dụ `l1/lua/stack`: `7464a573…`/73,477 B → `a5e59cf1…`/76,406 B), tức là mọi cell lệch vì multiple-return và padding chứ không riêng vì ngữ pháp số; phép so đó không chứng minh được gì, nên thay bằng `scratch/probe_numeric_neutrality.js`: so hai bộ ngữ pháp trên **cùng một văn bản**, cô lập đúng một biến số là bản vá mục 31.

## ĐÓNG GÓI — ZIP bàn giao v7 (hiện tại, bản 5.9.0 chính thức)

- File: `C:\Users\WINDOWS\Documents\ByteVeil-v5.9-FULL-qoder-v7.zip` — **367 entry**, `unzip -t`: `No errors detected in compressed data`. SHA-256 **chỉ** ở sidecar `ByteVeil-v5.9-FULL-qoder-v7.zip.sha256.txt`, tính bằng **hai công cụ độc lập** và khớp từng ký tự với sidecar: `crypto` của Node và `Get-FileHash` của PowerShell. Theo đúng bài học v4/v5: **không ghi** tổng byte chưa nén hay kích thước zip nén vào tài liệu, vì hai số đó đổi mỗi lần sửa chính tài liệu này — một con số không thể đúng trong archive chứa nó.
- **37 engine lôi thời đã biến mất hẳn, không còn `legacy/`:** `unzip -l | grep -c legacy` = **0**, `test-v590-tree.js:88` assert `!fs.existsSync(legacy/)`, và `tools/package-release-v590.js:67` **từ chối ghi zip** nếu thư mục `legacy` còn tồn tại trên đĩa hoặc nếu còn entry dạng `legacy/`, hoặc nếu code sống `require('...legacy/...')`. Đây là điểm khác biệt mà yêu cầu "đâu phải nhét engine lỗi thời vào legacy/" yêu cầu: v6 vẫn ship 38 file `legacy/` (181,528 B raw); v7 ship **0**.
- **Diff v6 → v7, đo bằng cách mở cả hai archive** (không suy từ tên file): `added=7`, `removed=43`, `orphan=0`. 43 file removed = **38** file `legacy/` (xoá thật) + **5** suite chỉ test engine chết (`test-v25.js`, `test-v25-instrument.js`, `test-v270.js`, `test-v280.js`, `test-v281.js`). 7 file added = `src/compiler/table_array_hint.js`, `src/compiler/number_operand.js`, `test-v590-multiret.js`, `test-v590-numeric.js`, `tools/verify-multiret-fidelity.js`, `tools/verify-newtable-frequency.js`, `tools/verify-carrier-classes.js`. Net **−36** file.
- **Vì sao archive to hơn dù ít file hơn (đo thật, không đoán):** `examples/` có đúng **45** file ở cả hai bản nhưng raw tăng **832,425 → 2,980,139 B**. Lý do là số literal blob `[==[byteveil&…]==]` trong ba fixture lớn nhất tăng từ **0 → 361 / 851 / 1,002** (`examples/v280-runtime-l1/l2/lz.lua`), tức các fixture này được `test-v280-runtime.js` (suite trong gate) ghi lại **sau khi đường blob hoạt động ở preset này**; `legacy/` −181,528 B, test −3 file (+4,377 B), phần còn lại +45,966 B. Không phải do mục 28/29: CALLP/APPEND/SIZE thêm operand, không thêm carrier.
- **Kiểm chứng loại trừ bằng cách liệt kê entry, không tin lệnh copy:** `unzip -l` chốt **367 files**; `\.env$` khớp **0** (chỉ hai file `.env.example` + `bot/.env.example`, placeholder); `scratch/` = **0**; `node_modules/` = **0**; `*.log` = **0**; entry `.zip`/`.sha256.txt` = **0** (nên archive không tự tham chiếu). Hai file `.env` THẬT trên đĩa vẫn bị packer loại và in ra: `excluded credential files: bot/.env, .env`.
- **Chạy lại từ bản giải nén:** engine trong archive tự đủ runtime (`tools/native/windows-x64/lua54.exe` + `lua54.dll` + `luau.exe`) — đã build và chạy artifact từ đúng thư mục giải nén của bản bàn giao, hai mode cho cùng stdout (`3 3 2 1 3 nil`, `vmMeta.fallback=false`).
- **Lệnh tái kiểm cho đúng file bạn nhận:**
  `sha256sum -c ByteVeil-v5.9-FULL-qoder-v7.zip.sha256.txt` → `OK`;
  `unzip -l ByteVeil-v5.9-FULL-qoder-v7.zip | grep -cE "(^|/)legacy/"` → **0**;
  `unzip -l ByteVeil-v5.9-FULL-qoder-v7.zip | grep -E "(^|/)\.env$"` → **0 dòng**;
  `unzip -q ByteVeil-v5.9-FULL-qoder-v7.zip -d check && cd check && node tools/native-test.js && node test-v590-tree.js && node test-v590-multiret.js`.
- Máy nhận: `npm install` (discord.js + dotenv), `npm test` chạy gate **23 suite** — lần chốt chu kỳ này `PASS (all 23 suites; concurrency=4; total=338,456ms)`, exit=0.

## ĐÓNG GÓI — ZIP bàn giao v6 (lịch sử — vẫn ship 38 file `legacy/`, đã bị v7 thay)

- File: `C:\Users\WINDOWS\Documents\ByteVeil-v5.9-FULL-qoder-v6.zip` — **403 entry** (con số duy nhất ổn định theo tập file; tổng byte chưa nén ~10 MB và kích thước nén ~3.7 MB đổi theo chính nội dung tài liệu này nên **không** ghi thành số đo). SHA-256 **chỉ** nằm ở sidecar cạnh zip: `ByteVeil-v5.9-FULL-qoder-v6.zip.sha256.txt` (không có digest tự tham chiếu trong archive — xem ghi chú ở mục v5 phía dưới). Hash tính bằng **hai công cụ độc lập** và khớp từng ký tự: `crypto` của Node và `Get-FileHash` của PowerShell.
- **Trình đóng gói nằm trong archive:** `tools/package-release-v590.js` — đi bộ cây theo `src/ bot/ tools/ examples/ legacy/` + file gốc, tên entry dùng `/`, deflate level 9 (store khi không ích), DOS date cố định nên tập entry mới cho ra zip **stable**. Nó **từ chối ghi** nếu còn sót file tên `.env`/`.env.local`/`.env.production` sau bước loại trừ, và in đúng những gì nó loại. Chạy lại: `node tools/package-release-v590.js ../ByteVeil-v5.9-FULL-qoder-v6.zip`.
- **Hai file `.env` THẬT trên đĩa đã bị loại, không phải không có:** `excluded credential files: bot/.env, .env`. Đây là lý do fail-closed nằm trong script chứ không tin lệnh copy — thư mục làm việc vẫn còn `.env` cho bot chạy.
- **Diff so với v5 (398 entry), đo bằng cách mở cả hai archive trong PowerShell (không suy từ tên file):** `added=42 removed=37 orphan=0`. 37 file `removed` **có mặt lại nguyên vẹn** dưới `legacy/src/...` (`movedToLegacy=37`, `orphan=0` — không mất nội dung nào, chỉ đổi đường dẫn). 42 file thêm = **38** file `legacy/` (37 file chuyển đường dẫn + `legacy/README.md`) + `src/core/option_registry.js` + `test-v590-bitops.js` (suite mục 21) + `test-v590-tree.js` (suite mục 24/26/27) + `tools/package-release-v590.js`. Net **+5** file.
- **Kiểm chứng loại trừ bằng cách liệt kê entry, không tin lệnh copy:** `unzip -l` chốt **403 files**; PowerShell mở lại archive đếm `entries=403`, `envExact=0`, `envAny=2` **bằng** `envExample=2` (chỉ `.env.example` + `bot/.env.example`, placeholder), `nodeModules=0`, `backslash=0`, `logFiles=0`, `zipEntries=0`, `shaSidecar=0` (archive không chứa `.zip`/`.sha256.txt` nào nên không có vòng tự tham). **Số byte chưa nén cố tình không ghi:** nó đổi mỗi lần sửa chính tài liệu này, tức là một con số không thể đúng trong archive chứa nó (xem bài học v4 ở mục dưới). `unzip -t`: `No errors detected in compressed data`. `find` trên thư mục giải nén: **403 file** — đúng bằng số entry.
- **Chạy lại từ bản giải nén** (archive tự đủ runtime, có `lua54.exe` + `lua54.dll` + `luau.exe` trong `tools/native/windows-x64/`): `node test-v590-tree.js` **exit=0**; `node test-v590-blob.js` **exit=0** (decode trên `lua54.exe` + `luau.exe` nên chết ngay nếu thiếu runtime); `node tools/native-test.js` **exit=0, 6/6 check PASS** (luau/register, luau/stack, lua/register, lua/stack, luau/runtime, lua/runtime). Ba suite này đã chạy trên đúng bản giải nén của archive bàn giao. **Không ghi wall time:** nó đổi theo tải máy từng lần chạy, còn điều cần chứng minh (exit code + số check) thì không đổi.
- **Lệnh tái kiểm cho đúng file bạn nhận** (không cần tin số của tôi):
  `sha256sum -c ByteVeil-v5.9-FULL-qoder-v6.zip.sha256.txt` → `OK`;
  `unzip -l ByteVeil-v5.9-FULL-qoder-v6.zip | grep -E "(^|/)\.env$"` → **0 dòng**;
  `unzip -q ByteVeil-v5.9-FULL-qoder-v6.zip -d check && cd check && node tools/native-test.js && node test-v590-tree.js`.
- Máy nhận: `npm install` (discord.js + dotenv), `npm test` chạy gate **21 suite** — lần chốt chu kỳ này: `PASS (all 21 suites; concurrency=4; total=249,052ms)`, exit=0.

## ĐÓNG GÓI — ZIP bàn giao v5 (lịch sử)

- File: `C:\Users\WINDOWS\Documents\ByteVeil-v5.9-FULL-qoder-v5.zip` — **398 entry** (con số duy nhất ổn định theo tập file). Kích thước nén ~3.65 MB và tổng byte chưa nén **không** ghi ở đây vì chúng đổi theo chính nội dung tài liệu này; SHA-256 của archive **chỉ** nằm trong sidecar ghi **cạnh** file zip: `ByteVeil-v5.9-FULL-qoder-v5.zip.sha256.txt`.
- **Không có digest tự tham chiếu trong archive này.** Một file không thể chứa hash của cái zip chứa nó: ghi vào thì phải đóng lại, đóng lại thì hash đổi. Bản **v4 làm sai điều đó** — `CHANGES-V5.9.0.md` bên trong v4 ghi `F2E88CEB…` tức hash của chính v4, nên bản `.md` trong archive v4 và bản trên đĩa **không thể** cùng đúng. Bản v5 cắt dứt điểm: tài liệu trong archive mang số **ổn định theo tập file** (số entry, số byte chưa nén, danh sách loại trừ), còn thứ phụ thuộc nội dung (hash, kích thước zip nén) chỉ có ở sidecar. Muốn verify: so `sha256sum` của zip với sidecar, rồi so số entry với `unzip -l`.
- So với v4 (392 entry): thêm **6** file — `src/core/precheck.js`, `src/obfuscation/veil_str.js`, `test-v590-veilstr.js`, `test-v590-precheck.js`, `test-v590-antibundle.js`, `HANDOFF-V6-WRAPPER-SPEC.md`. Không file nào bị loại thêm. `scratch/` vẫn là nơi làm việc nên không vào archive.
- **Kiểm chứng loại trừ bằng cách liệt kê entry archive** (không tin lệnh copy): `env_exact=0`, `node_modules=0`, `.git=0`, `*.log=0`, `_* scratch=0`, `backslash=0` (mọi entry dùng `/`). `env_any=2` và `env_example=2` **bằng nhau**, tức hai file duy nhất khớp mẫu `.env*` là `.env.example` + `bot/.env.example`, nội dung chỉ là placeholder (`replace-with-your-discord-token`, `replace-with-a-long-random-secret`). Kiểm chứng bằng **hai công cụ độc lập**: PowerShell mở lại archive và đếm entry, và `unzip -l` của Git-Bash liệt kê cùng tập; `find` trên thư mục giải nén cũng cho đúng hai `.env.example` và số file trên đĩa **bằng đúng** số entry của archive vừa giải nén.
- **Chạy lại từ bản giải nén** (5 suite, cả 5 exit=0): `test-v479-audit-fixes.js` 401ms, `test-v479-lps.js` 657ms, `test-v590-frontend.js` 381ms, `test-v510.js` 15,059ms (bản có regression `nest` của mục 18), `test-v590-blob.js` 53,636ms — suite cuối chứng minh archive tự đủ runtime vì nó decode trên `lua54.exe` + `luau.exe` (`lua54.dll` nằm trong archive). Các lần chạy giải nén đó là của bản 397-entry; bản 398 chỉ thêm một file `.md` nên không đổi hành vi, nhưng phép thử "archive tự đủ" vẫn do chính lần chạy đó chứng minh. Lệnh tái kiểm cho **đúng** archive bạn nhận (tự chạy, không cần tin số của tôi): `unzip -q ByteVeil-v5.9-FULL-qoder-v5.zip -d check && cd check && node test-v590-blob.js && node test-v510.js` — suite blob là phép thử mạnh nhất vì nó decode trên `lua54.exe`/`luau.exe` nên chết ngay nếu thiếu `lua54.dll`. Thư mục giải nén tạm đã dọn.
- Máy nhận: `npm install` (discord.js + dotenv), `npm run native:install` nếu cần cài lại runtime, `npm test` chạy gate **19 suite** (gate vẫn tự dán nhãn "v5.8.0 release gate" và `package.json` vẫn `5.8.0` — chưa bump cho tới khi Arena review đạt).

### ⚠️ Rò rỉ credential — trạng thái đo thật (không suy đoán)

Liệt kê entry **từng archive cũ** cho kết quả cụ thể:

| Archive | Chứa `.env` thật? |
|---|---|
| `Byteveil-v4.3.3.zip` | **Có** — `.env` + `bot/.env` |
| `Byteveil_obfuscator-v5.8-hardened.zip` | **Có** — `.env` + `bot/.env` |
| `ByteVeil-v5.9-backend-qoder.zip` | **Có** — `.env` |
| `ByteVeil-v5.9-FULL-qoder.zip` / `-v3` / `-v4` / **-v5** | Không — chỉ `.env.example` placeholder |

Ba archive đầu chứa `DISCORD_TOKEN` dạng thật (bắt đầu bằng `MTU0…`), `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID` và `API_SECRET` dạng thật (`45b2…`). **Việc của user, không làm hộ được:** rotate `DISCORD_TOKEN` (Discord Developer Portal → Bot → Reset Token) và `API_SECRET`. Bản v5 này sạch, nhưng secret cũ vẫn còn hiệu lực cho tới khi xoay, và vẫn nằm trong ba file ZIP trên đĩa. Tôi **không** xoá/sửa ba archive đó khi chưa được bạn đồng ý.

## ĐÓNG GÓI — ZIP bàn giao v4 (lịch sử)

> **Đọc kèm mục v5 phía trên:** dòng hash dưới đây là lỗi tự tham chiếu (hash của v4 được ghi trong
> `CHANGES-V5.9.0.md` nằm *bên trong* v4), nên bản `.md` trong archive v4 và bản trên đĩa không khớp nhau.
> Giữ nguyên để làm mốc, không dùng dòng đó để xác minh tính toàn vẹn — muốn verify v4 hãy tin
> `ByteVeil-v5.9-FULL-qoder-v4.sha256.txt` nằm cạnh file zip.

- File: `C:\Users\WINDOWS\Documents\ByteVeil-v5.9-FULL-qoder-v4.zip` — **392 entry**, **3,577,433 bytes**, SHA-256 `F2E88CEB54AEC16181FBCD84D48B0FED7851BE64116E4E0B6DB7CA98A741272F`, ghi ở sidecar `ByteVeil-v5.9-FULL-qoder-v4.sha256.txt` nằm **cạnh** file zip. Hash tính độc lập bằng hai đường (`Get-FileHash` của PowerShell và `crypto` của Node) — cùng ra một giá trị.
- So với v3 (389 entry): thêm đúng 3 file mới của P1/P3 — `src/obfuscation/blob_alphabet.js`, `src/obfuscation/junk_forge.js`, `test-v590-forge.js`. Không có file nào bị loại thêm.
- Trọn bộ: `src/`, `bot/`, `tools/` (kể cả `tools/native/windows-x64/lua54.exe` + `lua54.dll` + `luau.exe`), `examples/`, toàn bộ `test-*.js`, `package.json` (vẫn `5.8.0`), `CHANGES-V5.9.0.md`, `LIMITATIONS-V5.9.0.md`, `BACKEND-HANDOFF-V5.9.md` + lịch sử release log.
- **Kiểm chứng loại trừ bằng cách liệt kê entry archive** (không tin lệnh copy): `env_exact=0`, `env_any=0` (chỉ có `.env.example` / `bot/.env.example`, nội dung là placeholder `replace…`), `node_modules=0`, `.git=0`, `*.log=0`, `_* scratch=0`. Lần đóng gói này **chính thư mục làm việc cũng không còn file `.env` nào** (find toàn cây: chỉ hai `.env.example`), và grep tìm token dạng thật trong `src/`+`bot/` chỉ ra các hằng test `unit-test-token-not-valid`.
- Đường phân tách entry trong v4 là dấu `/` theo spec ZIP (v3 lưu dấu `\` — vẫn mở được trên Windows nhưng không chuẩn trên Linux/macOS).
- **Chạy lại từ bản giải nén** (cả 4 exit=0): `node test-v479-audit-fixes.js` 200ms, `node test-v479-lps.js` 298ms, `node test-v590-forge.js` 33,163ms (14 cell envelope + census fail-closed), `node test-v590-envguard.js` 18,601ms — chứng minh archive tự đủ (có `lua54.dll`), không thiếu runtime. Thư mục giải nén tạm đã dọn.
- Máy nhận: `npm install` (discord.js + dotenv), `npm run native:install` nếu cần cài lại runtime, `npm test` chạy gate **15 suite**.
- ⚠️ **Việc của user (bắt buộc, không làm hộ được):** rotate `DISCORD_TOKEN` và `API_SECRET` vì bản ZIP cũ từng rò rỉ `.env`. Bản v4 này không chứa secret — nhưng secret cũ vẫn còn hiệu lực cho tới khi xoay.
- Bản v3 (`ByteVeil-v5.9-FULL-qoder-v3.zip`, 389 entry, 3,550,318 B, SHA-256 ở `…-v3.sha256.txt`) giữ làm mốc lịch sử, **không** dùng để review P1/P3 vì chưa có `blob_alphabet.js`, `junk_forge.js` và `test-v590-forge.js`.

## COMPATIBILITY

- Không đổi public API nào của `src/` (frontend `parse`/`parseDetailed`, `obfuscate`, `wrap` giữ nguyên) — chỉ **thêm** tùy chọn. Module mới: `src/obfuscation/blob_alphabet.js`, `src/obfuscation/junk_forge.js`; sửa thuật toán trong `src/obfuscation/veil_blob.js`, `src/obfuscation/payload_container_v29.js`, `src/utils/diagnostic_string_encoder.js`, `src/compiler/stack/vm_generator.js`, `src/backend/bytecode_serializer.js`, `src/wrappers/bootstrap_renderer.js`, `src/core/pipeline.js`, `src/core/output_budget.js`. File test mới: `test-v590-junk.js`, `test-v590-envguard.js`, `test-v590-forge.js` (cả ba trong `SUITES` của gate).
- **Thay đổi mặc định người dùng phải biết (mục 13 + mục 19 — hai mục cộng lại thành chính sách mới):** từ bản này mọi build vẫn được pad theo floor của preset, **nhưng** khối padding bị cắt bởi ngân sách theo cỡ input: input **<100 KB** ⇒ padding ≤ **400 KB**; input **≥100 KB** ⇒ ≤ **2 MB** (lua) / **3 MB** (luau); và `OUTPUT_CAP_BYTES` (2.5 MB / 3 MB) vẫn là trần tổng. **Hệ quả đo được, không phải suy luận:** với input nhỏ, các preset nặng **không còn đạt floor** — `maximum`/lua giờ ra **467,026 B** thay vì ~2.4 MB, `lz` 468,229 B, `df` 462,928 B, `nest` 541,130 B, `l2` 406,378 B; chỉ `l1` (210,534 B) và `default` (210,052 B) còn nằm trong floor vì floor của chúng ≤ 204,800 B. Những build này báo `partial:true` + `capBinding:"junk-budget"` + `vmMeta.junkForge.paddingCapBytes`, **không** abort. Trước mục 19, cùng preset/cùng seed pad tới gần trần envelope. Muốn phục hồi hành vi cũ: `obfuscate(src,{junkForge:{paddingCapBytes:64_000_000}})` (clamp tối đa 64 MB); opt-out `junkForge:false`; `maxOutputBytes` của caller luôn thắng. Telemetry `vmMeta.junkForge` giờ thêm `paddingCapBytes` và `capBinding` (`"junk-budget"` / `"output-envelope"` / `null`).
- **Thay đổi hành vi cần biết (mục 20):** `pickBracketLevel` trước đó chỉ kiểm close-delimiter **bên trong** blob text, nên một container kết thúc bằng `]==` bị chính `]==]==]` ở biên đóng sớm — artifact **không load được** (`unexpected symbol near ']'`) và bị engine precheck abort. Nay level được chọn theo điều kiện closer xuất hiện **duy nhất tại đúng vị trí cuối**. Mọi chỗ emit long-bracket trong engine đều đi qua hàm này (`renderLongBracket`, `renderBlob` trong `veil_blob.js`; `junk_forge.js` và `diagnostic_string_encoder.js` require codec từ đó), nên không còn emitter nào tự viết lại luật level.
- **Thay đổi hành vi cần biết (mục 11):** output ByteVeil giờ **abort** khi host thay `error` toàn cục bằng stub — lỗi báo là `attempt to index a nil value` (bẫy nội tại), không phải thông điệp gốc. Đây là thiết kế fail-closed; host nào ghi đè `error` vì lý do hợp lệ sẽ thấy khác trước.
- **Thay đổi hành vi cần biết (mục 18):** `obfuscate(src,{wrapper:false})` từ bản này **thực sự tắt** callable bootstrap (đúng như `wrap()` vẫn hiểu boolean). Trước đó boolean bị merge nuốt nên build vẫn mang wrapper — script nào từng truyền `{wrapper:false}` để lấy body thô giờ sẽ nhận output **khác** (ngắn hơn, không có `return setmetatable(...):X()(...)`). Cách viết `{wrapper:{enabled:false}}` cho kết quả y hệt, và `{wrapper:true}` không làm mất `argumentCount` của preset.
- Output vẫn là Lua/Luau hợp lệ trên cả 7 preset (`l1/default/l2/nest/df/lz/maximum`) × 2 target — kiểm chứng bằng cách **chạy thật** trên `lua54.exe` và `luau.exe`, không chỉ `luac -p`. Kích thước: payload trung bình **77,215.25 B** (76,217–78,303) và output sau pad trung bình **209,967.13 B** (209,497–210,389) trên 8 seed benchmark lần chạy hiện tại (mục VERIFIED "Benchmark … sau mục 16–18"); số trước VeilStr là 73,961.5 B / 207,756.5 B, và `test-v580.js` từng đo 61,937 → 65,555 B ở payload trước P3.
- **Thay đổi telemetry cần biết (mục 18):** `vmMeta.wrapper.shape` trên preset `nest` với wrapper bật trả **nhãn mới** `bootstrap-in-nested-source` thay vì `no-callable-bootstrap-tail`. Caller nào so sánh `shape === "no-callable-bootstrap-tail"` để phát hiện "build không có wrapper" sẽ **không còn** nhận diện được `nest` theo cách đó — muốn hỏi "wrapper có được áp không" thì dùng `vmMeta.nestedObfuscation` / `vmMeta.wrapper.requested`, không suy từ shape. `test-v580.js` (assert `colon-dispatch` trên `l1`) và benchmark (`wrapperTails` đếm nhãn) không đổi hành vi.
- `package.json` **vẫn 5.8.0** — chưa bump theo đúng PLAN-V5.9 mục 1.4; gate string trong `run-release-tests.js` vẫn tự nhận "v5.8.0 release gate" (sẽ đổi ở bước release chính thức). Script npm họ `test:v590:*`: `frontend`, `blob`, `junk`, `envguard`, `forge`, `veilstr`, `precheck`, `antibundle`.
- Máy khác khi clone: chạy `npm run native:install` (script đã sửa) sẽ tự cài đủ `lua54.exe` + `lua54.dll` + `luau.exe`.
- **Tương thích format**: người dùng đã copy output cũ (dạng `\ddd`, carrier quote) vẫn chạy được — engine không đọc lại output của chính nó; VeilBlob chỉ là dạng biểu diễn mới khi sinh code.

## Bàn giao cho Arena AI

- Chạy lại các lệnh ở mục RUN; kỳ vọng exit=0 tất cả (gate **20 suite**, trong đó chín suite thuộc v5.9: `test-v590-junk.js`, `test-v590-envguard.js`, `test-v590-forge.js`, `test-v590-blob.js`, `test-v590-frontend.js`, **`test-v590-veilstr.js`**, **`test-v590-precheck.js`**, **`test-v590-antibundle.js`**, **`test-v590-bitops.js`**).
- **Kiểm chứng mục 18 (nhãn `wrapper.shape`)** — đây là lỗi "telemetry nói nhiều hơn điều nó đo", dễ tái phạm nhất: (a) build `preset:"nest"` với wrapper bật phải trả `bootstrap-in-nested-source`, wrapper tắt trả `no-callable-bootstrap-tail`, và hai output **phải khác nhau**; (b) sweep cross-route `node scratch/probe_veil_matrix_v2.js` (không bàn giao, nhưng chạy lại được từ source tree) phải in `wrapper-shape mismatches=0` **và** `semantic failures=0` trên 420 build — một mình `problems=0` của probe `nest` là chưa đủ vì nó không phủ 6 preset còn lại; (c) đọc `src/core/precheck.js` check số 9 và xác nhận nhánh `nested-source-loader` **skip** chứ không **pass im lặng**, tức báo cáo vẫn ghi `constants`/`cipheredBytes` cho nest.
- **Kiểm chứng đóng gói bằng archive, không bằng lời tôi:** `unzip -l ByteVeil-v5.9-FULL-qoder-v5.zip | grep -E "\.env|node_modules|scratch"` phải trả về **đúng** hai dòng `.env.example`; `unzip -l` total = **398**; và `sha256sum` của zip phải khớp sidecar `.zip.sha256.txt`. Lý do mục ĐÓNG GÓI v5 không ghi hash: xem bullet "Không có digest tự tham chiếu" — và đó cũng là bug có thật của v4, hãy kiểm v4 để xác nhận (`CHANGES` trong v4 chứa hash của chính v4).
- **Tài liệu mới `HANDOFF-V6-WRAPPER-SPEC.md`** (đi kèm archive): khoảng cách wrapper hiện tại vs file 1 của Luraph 15.1, đo từ sample, kèm **danh sách code sẽ vỡ** khi đổi đuôi (`test-v580.js:52`, `test-v590-blob.js:302`, `benchmark-v580-wrap.js:161`, heuristic pipeline) và **bẫy pow2**: nối dài mảng `a={[0]=1,…}` mà không mở rộng guard của `stepKey` thì đột biến cuối mảng thành trơ. Review trước khi ai đó bắt đầu code, vì đây là chỗ dễ tạo pass giả nhất.
- **Kiểm chứng JunkForge (mới, điểm dễ tự lừa nhất):** (a) mở `test-v590-forge.js` xác nhận mọi ngưỡng floor/cap **đọc từ hằng số module** (`PRESET_FLOORS`, `OUTPUT_CAP_BYTES`) chứ không hardcode số byte; (b) tự kiểm tra phép gán padding: build cùng seed với `junkForge:false` phải cho `bytes(naked) === bytes(padded) − vmMeta.junkForge.paddingBytes` **chính xác từng byte**; (c) census tamper phải đi kèm điều kiện `aborted === runs` — chỉ `survivors === []` là chưa đủ, vì "chết sau khi đã in digest" không phải fail-closed; (d) **không** được trích padding làm bằng chứng chống RE — đây đúng là chỗ tài liệu cũ từng sai.
- **Kiểm chứng mục 19 (trần padding theo input) — ba chỗ dễ tự lừa nhất:** (a) đọc `paddingCapFor()` và xác nhận nhánh nhỏ là `min(SMALL_INPUT_PADDING_CAP_BYTES, large)` chứ không phải `large` bị ghi đè, và `luau` input lớn thật sự ra **3,000,000** (đo: `paddingCapFor("luau", 200_000) === 3_000_000`); (b) `paddingCapBytes` trong `vmMeta.junkForge` phải **bằng** số mà `paddingCapFor(target, Buffer.byteLength(source,"utf8"))` trả về cho **input của user**, không phải cho body payload — cách kiểm nhanh: build cùng seed với source 64 KB và 128 KB, cell nhỏ phải báo `400000` và `capBinding:"junk-budget"`, cell lớn báo `2000000` và `capBinding:null` (đo thật: 384,394 B / 449,174 B padding); (c) `PADDING_CODE_MARGIN_BYTES` là **budget reserve**, không phải floor — đừng "sửa" cho padding chạm đúng 400,000: vòng top-up tự canh bằng seal trước, bỏ margin là quay lại overshoot **400,781 B** đã đo.
- **Kiểm chứng mục 20 (`pickBracketLevel`) — phải kiểm bằng boundary, không bằng interior:** điều kiện đúng là `` `${text}${closer}`.indexOf(closer) === text.length ``; bản cũ `!text.includes(closer)` **không phát hiện** được `…]==` + `]==]`. Tự tái lập: `renderLongBracket("x==")` phải ra level **≥3**, và `lua54.exe -e 'local v=[==[x==]==] print(#v)'`-style round-trip phải trả đúng số byte — suite làm việc đó cho **7** đuôi đối kháng × 2 runtime và **576** container fuzz (4 seed × 48 độ dài × 3 byte `] = [`). Kiểm thêm rằng **mọi** emitter long-bracket trong `src/` đi qua hàm này (`junk_forge.js` và `diagnostic_string_encoder.js` require codec từ `veil_blob.js`; không có hàm chọn level thứ hai).
- **Kiểm chứng mục 21 (BAND/BOR dẫn xuất) — bắt đầu bằng việc phủ nhận con số tốc độ:** delta wall của `bitheavy` **đổi dấu** giữa hai lần chạy (−9% ở 5 rounds, +28% ở 9 rounds) và control không bit op lệch tới **+31%** trên cùng bàn, nên **không có cơ sở** để báo "nhanh hơn"; nếu Arena thấy ai đó trích một trong hai con số đó làm speedup thì đó là pass giả. Ba thứ kiểm được và deterministic: (a) `grep -c 'for _=1,32' <artifact>` phải **0** với build mới và **2** với build tạo bởi `node scratch/bit_toggle.js baseline` (cái sau là cách tái lập đường cũ, luôn chạy `restore` sau đó — `restore` verify byte-identical nên không có trạng thái lửng); (b) `node test-v590-bitops.js` phải cho **4 cell trùng nhau** — đây là hồi quy thật của patch: `bit32.band(-0.5,1)` trên `luau.exe` thật trả **0**, artifact trả **1**; (c) `/2` **phải** nằm trong `math.floor(...)`, vì Lua 5.4 in `2.0` khi float — đây là bug do chính tôi tạo ra trong quá trình sửa và `scratch/probe_bitops_e2e.js` bắt được. Kiểm thêm quyết định **không** sửa SHL/SHR: `bit32.lshift/rshift` raw và nhánh số học không tương đương trên mọi input, nên chưa đụng — nếu Arena chứng minh được tương đương trên tập input mà compiler sinh ra thì đó là fix tiếp theo, còn không thì giữ nguyên là đúng.
- **Kiểm chứng mục 22 (tên định danh trùng hole-pattern) — đây là bug của cổng, không phải bug artifact:** tái lập bằng cách build `local acc=0 for i=1,200 do acc=((acc+i)&65535)|(i&255) end print(acc)` seed `0x59c0de` với `precheck:{enabled:false}` → artifact **chạy đúng** (in `29423` trên cả hai host), trong khi build qua cổng thì abort trước khi sửa. Arena nên kiểm ba điều: (a) sửa ở **generator**, không ở pattern (`TEMPLATE_HOLE_PATTERN` trong `src/core/precheck.js` giữ nguyên — nới cổng để build thông là hướng sai); (b) còn chỗ sinh tên ngắn nào khác không — hiện `mangler.js` (`_` + 7–16 ký tự) và `v38Id` (`_` prefix) vô sự, hai chỗ 2–4 ký tự đã bịt; nếu thêm emitter tên mới thì **phải** đi qua một reserve chung, và đó là chỗ thiết kế còn thiếu tôi khai nhận ở LIMITATIONS; (c) `node scratch/probe_name_hole.js` tạo bản sao module đã strip phần loại trừ để đo "trước" — chạy nó và xác nhận `before=9` không phải số bịa, và `after=0`.- **Kiểm chứng phát hiện đột biến padding (phải đọc trước khi khen):** đo thật là edit **cùng class** ký tự ở vị trí **không** được sample, giữ nguyên độ dài ⇒ **60/60 sống**. Nếu ai đó báo "digest phát hiện mọi chỉnh sửa" thì đó là pass giả. Bảng đo + cách tái lập ở mục VERIFIED.
- **Kiểm chứng phân loại padding trong benchmark:** `tools/benchmark-v580-wrap.js` có ba phép cross-check (`containers trong khối forge` = `analysis.padding.containers` = `vmMeta.junkForge.containers`, `analysis.padding.bytes === vmMeta.junkForge.paddingBytes`, và mọi slot bootstrap bắt đầu **sau** khối padding). Hủy một trong ba phép đó phải làm benchmark fail, không im lặng.
- **Không so số cũ/mới của bộ nhận dạng primitive:** exposure 66.67% (4/6) và "subsystems ngoài body 100%" lần này dùng **6 ký hiệu v5.9 hoàn toàn khác** 4 fingerprint v5.8 (đã đếm = 0 trên cả 8 seed, xem `signatureRetirement`). So 66.67% với 33.33% của release trước là lỗi phương pháp, không phải phát hiện.
- **Phản chứng mục 7 (decoy)**: với mỗi seed `1001/1002/1003/1004/2001/2002/2003/2004`, mở `tools/benchmark-v580-wrap.js` block 6 — nếu bỏ harness ở `runProgram(lua, harness(mutated))` thì toàn bộ ablation "pass" giả (chương trình chết vì thiếu `bv_side_log`); đây đúng là bug đã tồn tại trước patch này.
- **Kiểm chứng decoy — phải tách hai loại** (trước đây tài liệu này gộp chung một dòng, dễ hiểu nhầm):
  - *Inert (đúng thiết kế mục 7):* tail field `[<key>]=[==[byteveil&...]==]` và các container **gán raw** `bank[<slot>]=[==[...]==]` (không có `function()return`) → xóa hoặc đổi 1 byte bên trong vẫn phải chạy và trả **đúng cùng digest**.
  - *Load-bearing (mục 10):* mọi assignment dạng `bank[<slot>]=function()return <dec>(string.sub([==[byteveil&...]==],10),...)` — gồm cả carrier rác — phải **chết** khi lật 1 ký tự payload, cắt ngắn payload, hoặc trung hòa carrier (`[<slot>]=nil and function()...end`). Lật sai chỗ (rơi vào 9 ký tự `byteveil&` mà `string.sub(...,10)` cắt bỏ) cho "survivor" giả — dùng offset `[=*[` + marker, xem mục VERIFIED "Sửa lỗi đo lường".
- **Kiểm chứng env logger**: chạy `node test-v590-envguard.js` rồi tự thử lại ngoài suite — cài `setmetatable(_G,{__index=function(...) ... end})` **trước** khi `load` chunk bảo vệ (đặt handler là field raw của metatable, không phải metatable lồng nhau) ⇒ phải thấy `environment index logger detected`; stub luôn `error` ⇒ phải chết ở `attempt to index a nil value`, **không** được in digest. Kỳ vọng fail-closed chỉ trên Lua 5.4; trên `luau.exe` attack bị nền tảng từ chối (readonly table) — xem LIMITATIONS, không tính là phòng thủ.
- **Kiểm chứng token-safe**: build `local function f(g) return g or "payload lane missing" end print(f(false))` (preset `nest`) → không được sinh ra `or<accessor>` dính token; chạy ra `payload lane missing`.
- Kiểm chứng `describeLaunchFailure` không nuốt lỗi Lua thật: tạo output sai cú pháp, `runSyntaxCheck` phải trả stderr Lua (không phải message launch).
- Nếu xóa thử `lua54.dll`: gate phải fail với message chẩn đoán mới (không còn "syntax failure: " rỗng).
- **Giới hạn đã biết, không cần báo lại thành bug** (chi tiết trong LIMITATIONS-V5.9.0.md): preset `nest` không sinh runtime guard; bỏ **toàn bộ** khối carrier rác + lời gọi digest thì build sống (chỉ sửa/xóa từng phần mới chết); **tương tự, bỏ cả khối JunkForge thì payload vẫn chạy đúng** (đo: 3 preset × 2 runtime) và **edit cùng class ngoài vị trí sample trong padding không bị bắt** (60/60 sống); hook mức C không phát hiện được; host stub `error` hợp lệ sẽ thấy abort `attempt to index a nil value`; trần 2.5/3 MB chưa kiểm chứng trên loader thật (Roblox/FiveM).

# ByteVeil v4.7.8 — Comparative study of obfuscated-output corpora

**Purpose:** use concrete output structures from the user's two repositories to inform ByteVeil architecture; record evidence and uncertainty rather than treating opaque source as a description of another engine's internals.

## Scope and method

The public repository manifests and representative samples from multiple Luraph versions were inspected statically. I also inspected a sophisticated unlabelled VM-shaped output in `Sample-obfuscator` and a MoonVeil output from that repository. The `Sample` archive is very large (GitHub reports a repository size of about 4.1 million KB); this was a representative source-level study, **not a full byte-by-byte review of every file in the archive**. No protected sample was executed, and this report does not claim to have obtained or reconstructed Luraph's proprietary generator source.

## Repository inventory

### `Dev-Meoz/Sample-obfuscator`

The root has eight Lua files: `luaobfuscator.com.lua`, `obfuscated.lua`, and `obfuscated (1).lua` through `obfuscated (6).lua`. The files are not all the same obfuscator. `obfuscated.lua` and `(1)` identify themselves as MoonVeil 2.0.26; `(2)` through `(6)` contain dense VM-style code with no reliable vendor attribution from the inspected excerpts. That distinction matters: the sophisticated `(2)` VM should not be mislabeled as Luraph.

- [`luaobfuscator.com.lua`](https://github.com/Dev-Meoz/Sample-obfuscator/blob/main/luaobfuscator.com.lua), blob `5e4bf51f57b18fea53fd205a7ff1e20bfe5c0ed5`, 10,597 bytes. The header says LuaObfuscator.com Alpha 0.10.9. It has identifier-heavy code, many functions/loops and string helper use. This is useful as a distinct baseline, not an instruction to copy its names.
- [`obfuscated.lua`](https://github.com/Dev-Meoz/Sample-obfuscator/blob/main/obfuscated.lua), blob `145321134a0d906ca4b3fd46d48e3f364e1cba7b`, 5,184 bytes; first line identifies MoonVeil 2.0.26. The inspected excerpt shows bit-operation-heavy transformation code. It differs substantially from the large Luraph outputs.
- [`obfuscated (2).lua`](https://github.com/Dev-Meoz/Sample-obfuscator/blob/main/obfuscated%20(2).lua), blob `adc3b6d9ff553f281c42780bf2977105e6266802`, 11,564 bytes. This unlabeled output is especially informative structurally: a byte hash/seeding stage; a custom alphabet decoder; a flag/LZ-style decompressor; a decoded header and a table of offset/length pairs; lazy per-function materialization; a per-function opcode permutation/inverse lookup; instruction decoding with extra operand forms; a PC-dependent execution mask; and an interpreter dispatch loop. Closure cells have open/closed representations, and scope cleanup checks `__close` metamethods. This description is based on visible code; it is not evidence that Luraph uses the same implementation.
- [`obfuscated (3).lua`](https://github.com/Dev-Meoz/Sample-obfuscator/blob/main/obfuscated%20(3).lua) and [`obfuscated (6).lua`](https://github.com/Dev-Meoz/Sample-obfuscator/blob/main/obfuscated%20(6).lua) show related dense VM-style output. The latter is 12,813 bytes and also includes payload decoding, an offset/length table, per-function opcode inverse mapping and an interpreter. As with `(2)`, no vendor is established by the inspected header.

### `Dev-Meoz/Sample`

The root manifest includes families such as `77fuscator`, `Boronide`, `Hercules`, `Ironbrew1`, `IronBrew2`, `Ironbrew3`, `LPS`, `LuaObfuscator`, `Luraph`, `MoonSec`, `MoonVeil`, `PSU`, `Prometheus`, `SynapseXen` and `wYnFuscate`, plus large real-world Luau script samples. This diversity makes the repository valuable for cross-family regression and analysis; the folder names alone do not prove that any individual algorithm has been understood.

Representative Luraph outputs inspected:

| File | Observed structure | Important limitation |
|---|---|---|
| [v14.8 `0942aaa445539073.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v14.8/0942aaa445539073.lua) — blob `d428c5a656f85922ba1433c831e7ac190271d6c7`, 147,244 bytes | Header identifies Luraph v14.8. The returned object contains many short-named functions plus numeric-key dispatch entries and aliases for `bit32` operations; `coroutine`, `getfenv`/`setfenv`, and string packing helpers are also visible. | The opening table alone does not reveal the full payload encoding or all VM semantics.
| [v14.9 `e462eaaccbac09b0.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v14.9/e462eaaccbac09b0.lua) — blob `79df2d5c09ceef60b977a490c5cdb9995c726849`, 212,717 bytes | Header identifies v14.9. This sample visibly references `string.pack`/`unpack`, `buffer.fromstring`, `loadstring` and `load`, includes a `setmetatable` path, and constructs/decompresses data before handing it to a loader. | This is a variation; do not generalize the source-loader pattern to every Luraph version/output.
| [v15.0 `392628e9da400b8a.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.0/392628e9da400b8a.lua) — blob `3e66fead6e384458c446f96e5066e3206b62c6b5`, 253,339 bytes | Header identifies v15.0. The file starts with a `setmetatable`-wrapped numeric/function table, with many function-valued entries and binary reader use including `buffer.readstring`, `buffer.readu16` and `buffer.readi32`. | Numeric keys/functions indicate indirection/dispatch structure but are not, by themselves, a security measure.
| [v15.1 `390ea6acb88b8f9f.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.1/390ea6acb88b8f9f.lua) — blob `62a6ce6587e5456b912c47d64e7613441852d82c`, 286,257 bytes | Header identifies v15.1. The initial table aliases many host APIs by numeric keys: `buffer.readstring/readu16`, `buffer.write*`, `buffer.copy/len/create/fromstring`, numerous `bit32` operations, and coroutine primitives. Function bodies include a dispatch loop and instruction/operand decode logic; decoder state derives from PC and runtime state. | This is a structural observation of one output, not recovery of Luraph's private source code or proof of how every build differs.
| [v15.1 `2153b779fa7a87f2.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.1/2153b779fa7a87f2.lua) — blob `b252ab033c8be62e2f539f326c312ab6ec274899`, 280,360 bytes | Also header-identifies v15.1, but differs in visible function/table shape and has a different combination of `buffer.*` and loader-related references. It includes a power-of-two table and more compact visible function count. | One version label does not imply all samples in that version use identical structure.

## Architectural takeaways grounded in the inspected output

1. **Payload organization matters more than visible code length or number of wrappers.** Multiple outputs separate data into encoded binary strings/regions and recover portions at runtime. In the unlabelled VM-shaped sample, the offset/length table plus per-function lazy materialization is explicitly visible. The Luraph v15.1 samples show substantial native-buffer API usage and binary instruction decoding.
2. **Decoder, opcode map and runtime state are coupled.** The unlabelled sample computes an inverse opcode permutation per function and combines instruction decode with PC-derived masks. In Luraph samples, table indirection, bit operations, and buffer reads appear around dispatch/decoder code. This is stronger design evidence than merely renaming opcode functions.
3. **Native buffer APIs are an implementation substrate, not a magic protection layer.** Their use can make typed binary payloads practical and avoid text-heavy payload encoding, but the format and decode path remain observable to an analyst with runtime access.
4. **Lazy materialization has a purpose when it preserves boundaries.** Offsets/lengths and per-function caches let payload pieces be decoded when used rather than all materialized as one plaintext program at startup. Merely splitting a string into chunks without changing when/where it is decoded would add bulk without the same structural benefit.
5. **Different outputs in the same family/version can differ.** The two v15.1 files differ in visible table shape, API aliases, function distribution and loader references. A robust design should test multiple artifacts and not fit a reverse-engineering story to a single sample.
6. **A decoy should not be treated as protection merely because it looks busy.** If an auxiliary lane consumes a static source trace, uses an unrelated toy ISA, or only performs hash-shaped work unconnected to runtime dispatch, an analyst can often separate it from the VM that controls program effects. The prior v4.7.7 shadow path made precisely that mistake: it guessed opcode categories by regular expressions and derived decoy fields from a static compile trace.

## What changed in ByteVeil v4.7.8

- Each active build now assigns every active opcode a unique randomized shadow ID and dispatches the current runtime opcode through that exact map.
- The source-derived static opcode trace is not embedded in the new shadow payload; randomized binary rows are built from the same active ISA instead.
- Rows use field-wise masks and seed-dependent physical ordering; operation-correlated per-op handlers update the shadow projection state, which contributes to the runtime guard/fabric.
- Metadata calls this `semantic-projection-isa-v478`, not a fully independent semantic VM. The main VM still handles actual source semantics.
- The eight binary-region transforms, no-source-loader route, function-policy decisions and previous public APIs remain in place.

## Limitations / next research pass

- This was a representative study, not a clone or a complete corpus-wide disassembly.
- `Sample-obfuscator`'s VM-like files are not attributed to Luraph absent a reliable banner/source link.
- ByteVeil's v4.7.8 shadow lane is still an abstract projection; this release does **not** establish that it is as difficult to reverse engineer as the main VM or Luraph.
- Stronger next steps need tests against known source/expected behavior and an external crack workflow: correlate live dispatch with each selected binary region; test whether decoy and real handler families are separable by state influence; inspect whether any single resolver exposes full plaintext; and measure output/runtime cost without silently weakening protection. The results should be recorded as observations, not scores inferred from line count.

## v4.7.8 source-level VM audit and first semantic repair (2026-10-15)

### What the source currently does (not a claim about Luraph internals)

- The active `src/compiler/stack/vm_generator.js` builds an actual bytecode dispatch loop and has separate stack/register handlers for arithmetic, indexing, calls, closure creation, locals, returns and iterators. It is inaccurate to say every part of v4.7.8 is a stub.
- The `buildSemanticShadowVM` helper in `src/protection/live_shadow_vm.js` is **not** a second full interpreter for the user's program. It maps active opcode names to a randomized shadow alphabet and executes opcode-category-specific synthetic state updates (for example, call-shaped entries update a shadow call accumulator). It checks runtime transitions, but it does not independently implement the language's true CALL/GETGLOBAL/SETGLOBAL/upvalue/return semantics. Calling this shadow lane a complete semantic VM would overstate its role.
- Main-VM lexical capture is comparatively simple: `MAKEFUNC` retains the parent VM state; `GETL`/`SETL` walk parent states and resolve locals through name-keyed local tables. That is a concrete architectural gap against output structures with explicit prototype/upvalue metadata and open/closed cells. A future rewrite should target prototype descriptors/upvalue cells and test closing/capturing semantics, not just add another layer of string transforms.
- Visible identifier mangling in Luraph samples is more than short local names: host APIs are also aliased through numeric table entries, and table/function indirection is integrated with decoder and runtime dispatch. Names alone are only the surface layer.

### Semantic defect fixed in this work chunk: expandable call in final return position

The former compile/validate path rejected or mishandled a final call in forms such as `return f()` and `return prefix, f()`. Correct Lua/Luau behavior must preserve the full result tuple, including explicit nils and nil holes; treating the call as a single result changes program behavior.

The current v4.7.8 patch adds a single logical `TAILCALL` opcode (kept within the serializer's 6-bit physical opcode budget), lowers expandable final calls through it in both stack and register compilers, validates operand layout, preserves global/local/method callee forms, forwards a trailing vararg pack, and collects exact return arity with `select('#', ...)`. The handler invokes the final call and returns the call's complete result tuple plus any preceding return values. **This is a tail-position return opcode for correct multi-result semantics; it does not claim to implement a full trampoline or constant-stack proper-tail-call optimization.**

A regression test, `test-v478-tail-return.js`, runs nine input forms through both backends (18 runtime checks): local/global calls, a method call, a preceding return value, vararg forwarding and nil holes. It asserts the output has no explicit source-loader call and verifies generated Lua syntax plus runtime output. Current result on the available Lua-compatible runtime: PASS, `ISA=62/64`.

### Validation recorded for this work chunk

- PASS: `node test-v478-tail-return.js` — 18 runtime checks across stack/register.
- PASS: `node test-v478-bot.js`.
- PASS: `node test-v478-macros-lph.js`.
- PASS: `node test-v433.js`.
- PASS: `node test-v478-policy.js`.
- Release-suite limitation: the full `npm test` remains blocked because `test-v478.js` requires an actual Lua 5.4 runtime; the environment resolves LuaTeX's embedded Lua 5.3 instead. A temporary compatibility-only run that bypassed just the version assertion did not pass the shadow-transition crack probe, so it is not counted as a release pass. No Lua 5.4 release-suite pass is claimed.

### Still not claimed / next architectural gaps

This patch fixes one concrete language-semantics defect; it does **not** make v4.7.8 equivalent to Luraph. No complete Luraph devirtualization was performed, no protected sample was executed, and the corpus does not reveal proprietary generator source. The next evidence-led main-VM steps are: (1) explicit prototype records and constant/instruction region boundaries; (2) stable upvalue-cell objects with close semantics; (3) separate source call lowering for local/global/method/vararg/multiple-result forms with differential tests; (4) per-prototype opcode/operand decode tested against all branch/call edges; and (5) reproducible runtime crack probes that are validated under the intended Lua 5.4/Luau runtime. Each item must have a test demonstrating what changed and what remains uncovered.

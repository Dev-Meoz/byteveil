# ByteVeil v4.7.5 — Crack-test return log

## 1. Input finding / root cause

The supplied v4.7.4 report described nine `load` source strings, including extracted layer 8 (51,941 bytes) and layer 9 (47,400 bytes). The first basic hook was rejected by the outer provenance guard. In an analysis-only copy, bypassing that guard allowed the nested wrappers to reveal the later source stages. The problem was therefore not simply a weak check: the active architecture reconstructed Lua source between layers and handed it to a standard source loader.

## 2. Fix applied

- The v4.7.5 active generation route no longer calls the nested source wrapper.
- The graph VM is serialized into binary regions and each region uses eight sequential reversible byte-transform operations.
- When available, the generated runtime can keep validated bytes in Luau's native buffer API; stock Lua uses a byte-array fallback.
- Release metadata explicitly reports 0 nested source layers, 0 source-loader stages/calls, 8 payload transforms, and optional native-buffer support.
- Loader provenance checks are not described as making client-side code uncrackable. The important change is that the affected source-loader boundary is absent from the normal path.

## 3. Tests run

`npm test` passed from the working tree and again after extracting the release ZIP:

- Slash-command deployment mocks: PASS
- Macro/LPH regression: PASS
- Legacy frontend/stack-safety regression: PASS
- v4.7.5 graph VM regression: PASS
- Eight-transform inverse/round-trip property checks: 64 cases PASS
- Stack/register semantic checks for closure/upvalue, coroutine and multiple-return behavior: PASS
- Preset matrix (`l1`, `l2`, `df`, `lz`): PASS
- Fixture `examples/input.lua`, preset `lz`, seed `0x475B0001`: 50,288 output bytes; Lua 5.4 output `5`; PASS
- Benchmark fixture, 85-byte source, preset `lz`, stack mode, seed `1196099585`: 52,280 output bytes; Lua 5.4 output `5`; PASS
- Lua-side buffer API shim: PASS; this validates the buffer branch's indexing integration, not actual Roblox Luau execution
- JavaScript syntax audit over `src`, `bot/src`, and `tools`: PASS

## 4. Crack probe

The generated outputs were executed with hooks on both `load` and `loadstring`, without bypassing or changing generated checks. The hook logged **zero calls**. Static assertions also verified no loader call expressions or loader identifiers in the protected output. A separate behavior fixture reproduces the exact print string in the v4.7.4 report; its output does not contain that whole phrase as a plaintext source literal, and it prints the exact expected result under the loader hooks.

Important scope distinction: this is a behavior-only reproduction of the observed print statement, not the exact original v4.7.4 binary or its unrecovered source. The output-size comparison with the original 460,508-byte artifact is not a valid same-input strength benchmark.

## 5. Remaining weaknesses / next crack targets

- Native Roblox Luau was unavailable in this environment. The native `buffer` branch must still be run in a real Luau host before making compatibility claims.
- The source-loader peel route is removed, but decoded binary-region contents or VM state can still be inspected through deeper runtime instrumentation. Zero loader calls do not prove the VM is impossible to reverse-engineer.
- No claim of equivalent resistance to Luraph v15.x or MoonSec is made. The next loop should target actual region-state/material extraction and compare recovered semantic instructions against known fixtures, then add that attack as a regression test.

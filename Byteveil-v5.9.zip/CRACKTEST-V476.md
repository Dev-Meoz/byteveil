# ByteVeil v4.7.6 — Crack-test return log

## 1. Finding

The weakness reported against v4.7.5 was that an auxiliary decoy VM could be identified and separated from the live VM if its instruction stream and state had little relationship to the actual instructions being executed. Extra opaque handlers alone would only add bulk, not robust coupling.

## 2. Fix

- Each primary VM instruction now triggers a secondary handler selected from the current logical opcode.
- That handler receives register/operand seeds derived from the actual instruction operand fields and current runtime state.
- The encoded side stream also remains active: 3/4 of its build-specific rows are derived from the compiled opcode/operand trace; 1/4 are build-seeded transitions. Masked row fields and physical row order differ by build seed.
- Secondary state is folded into the main VM guard/fabric state after every actual instruction, so it evolves during the program rather than running as an isolated wheel before/after execution.
- The standard output path remains binary-region based, with 0 nested source-loader stages. No generated `load(...)`/`loadstring(...)` stage is needed to enter the next protection layer.

## 3. Test results

`npm test` passed after the runtime-coupled change:

- Bot slash-command/deploy mock: PASS.
- Macro/LPH regression: PASS.
- Legacy frontend/stack-safety regression: PASS.
- v4.7.6 VM suite: PASS (8 semantic mode runs, all presets, reversible 8-lane codec checks, output budget, and loader probes).
- Semantic regression set: **20 mode runs PASS** (10 programs × stack/register). Includes arithmetic, branching, tables, varargs, recursion, closure/upvalue mutation, coroutine yield/resume, concatenation, parenthesized single-result calls, and ordinary multi-return assignment.
- JS syntax audit (`src`, `bot/src`, `tools`): PASS.

## 4. Loader crack probe

Generated outputs were executed with wrappers around both native `load` and `loadstring`. Both hooks observed **0 calls**, and the tests confirmed the generated program retained the expected output. The release suite also replays the observable print string from the earlier v4.7.4 report as a behavior fixture; the phrase is not emitted as a complete plaintext source literal, and output matches exactly.

This is a targeted attack-path result, not a universal crack-resistance score. It does not reproduce the exact binary that red team tested in v4.7.4 and does not show the full recovery of all VM regions is impossible.

## 5. Benchmark snapshot

Fixed 85-byte `examples/input.lua`, preset `lz`, strength `10000`, seed `0x476B0001`:

| Mode | Output bytes | Runtime status | Stdout | Shadow instructions | Shadow handlers | Dispatch steps/real instruction |
|---|---:|---|---|---:|---:|---:|
| Stack | 50,341 | PASS (Lua 5.4) | `5` | 96 | 34 | 3 |
| Register | 50,003 | PASS (Lua 5.4) | `5` | 96 | 34 | 3 |

Machine-specific timings and metadata are recorded in `BENCHMARK-V476-STACK.json` and `BENCHMARK-V476-REGISTER.json`.

## 6. Remaining crack targets

- The secondary VM is runtime-coupled and stateful, but its handler effects are not equivalent to executing the original source semantics a second time. A skilled analyst may still identify the auxiliary ISA by comparing its handler behavior to the real opcode trace.
- Decode-region instrumentation, dynamic state capture, and correlation of real opcode execution against secondary handler dispatch remain untested as bypass paths.
- No native Roblox Luau runtime was available. Buffer behavior was validated with a Lua-side shim only.
- No result here proves parity with Luraph v15.x, MoonSec, or another commercial obfuscator. The next loop should take any recovered VM-state or region data, identify a reproducible weakness, add the specific crack as a test, and then fix it.

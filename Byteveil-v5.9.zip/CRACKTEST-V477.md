# ByteVeil v4.7.7 — Crack / Regression Test Report

## Scope

This is a reproducible test report for ByteVeil's own harmless fixtures. It does not run arbitrary third-party protected scripts from the sample corpus. The corpus repositories contain protected output samples; their presence or structural similarity is not proof of an obfuscator's internal algorithm or protection strength.

## Environment

- Runtime executed: bundled Lua 5.4 runner (`tools/lua54-runner`).
- JavaScript: Node.js in the current Linux build environment.
- Native Roblox Luau / Roblox Studio: **not run**.
- Lua 5.1 / Lua 5.3: **not run**.

## Reproduction

```sh
npm install
npm test
npm run benchmark:v477
```

## Test results

- `test-v477-bot.js`: PASS — mocked Discord deploy/command flow.
- `test-v477-macros-lph.js`: PASS — Macro/LPH integration regressions.
- `test-v433.js`: PASS — legacy frontend / stack-safety regression.
- `test-v477-policy.js`: PASS — VM-A and VM-B policies, both mixed-backend directions, function-level compiler-transformed mode, unsupported target rejection, explicit fallback recording, output-size rejection, and hybrid wrapper syntax/runtime.
- `test-v477.js`: PASS — eight-lane byte-transform round trips, seed-dependent output, closure/upvalue behavior, coroutine, varargs/multiple returns, parenthesized single-result calls, arithmetic, branch, table, all public presets, output budget and loader-hook probes.
- Semantic regression matrix: 20 runs across stack/register mode for 10 programs. All passed in Lua 5.4.
- Full `npm test`: all five suites passed after the stack `CALLG/CALLGM` and hybrid-wrapper separator fixes.

## Attack probes

### Source-loader instrumentation

The harmless protected fixtures are executed with wrappers on `load` and `loadstring` that write a unique marker when invoked. The tested fixtures execute correctly and the markers are absent. Static inspection also checks that these outputs do not contain literal `load(...)` / `loadstring(...)` call sites and that metadata reports zero source-loader stages.

**What this proves:** the tested standard VM output path did not use these source-loader functions for these fixtures.

**What this does not prove:** resistance to bytecode extraction, runtime memory inspection, constant recovery, VM devirtualization, debug API instrumentation, patching other runtime primitives or attacks against different source programs/targets.

### Hybrid backend validation

The benchmark fixture defines `add` and `mul` and requires the same `HYBRID\t15\t12` runtime output under 20 profiles: VM-A, VM-B, A-root/B-function, B-root/A-function and compiler-transformed under each of the four public presets. Build metadata is checked so a policy result cannot be called routed solely because its requested policy was accepted. Unsupported local-function routing is tested to fail by default; explicit fallback is recorded with the actual containing backend and reason.

## Known limitations / next red-team targets

- The cross-backend bridge only supports simple top-level global function declarations. Cross-backend upvalue/capture transport and independently routed local/nested functions are not implemented.
- The secondary/interleaved VM state is coupled to the live instruction path, but is not a second independent engine that reevaluates full Lua semantics. Do not equate its handler count or state updates with reverse-engineering resistance.
- Eight byte transforms are reversible encoding/serialization, not cryptographic secrecy.
- Native Luau `buffer` behavior and Roblox environment differences are not verified here; the existing Lua-side shim is only an integration test.
- Next useful crack probes are bytecode/region recovery, constant materialization, runtime state tracing and comparison of structure across differently seeded builds. A zero-loader-call result alone must not be used as a strength score.

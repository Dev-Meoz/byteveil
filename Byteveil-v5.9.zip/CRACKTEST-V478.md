# ByteVeil v4.7.8 — Test and crack-probe report

Date: 2026-10-14

## LOG

- Corpus notes: `CORPUS-RESEARCH-V478.md` references the inspected sample paths and blob hashes and separates visible facts from inference.
- Fixed issue: v4.7.7's regex-mapped static-trace shadow lane was not coupled to the exact active opcode route. v4.7.8 builds unique randomized secondary IDs for the current build ISA and removes the static source opcode trace.

## FIX

- `src/protection/live_shadow_vm.js`: added `buildSemanticShadowVM()`.
- `src/compiler/stack/vm_generator.js`: routes v4.7.8 builds to the new builder and labels the architecture explicitly.
- `src/customVM.js`, `src/core/pipeline.js`, `src/backend/bytecode_serializer.js`, protection/IR modules, package metadata, bot labels and benchmark entry point: updated active version wiring and labels.
- `test-v478*.js`: tests updated/added for shadow metadata and release-specific behavior.

## TEST

Commands run successfully:

```text
BYTECODE_LUA_PATH=/path/to/lua5.4 npm test
BYTECODE_LUA_PATH=/path/to/lua5.4 node tools/benchmark-v478.js --runs=3
```

Runtime selection: verified by executing `io.write(_VERSION)`; result was exactly `Lua 5.4`. A LuaTeX fallback previously caused an incorrect Lua 5.4 claim, so the release tests now reject other `_VERSION` values.

Regression output:

```text
ByteVeil v4.7.8 slash-command/deploy tests: PASS
ByteVeil Macro/LPH v4.7.8 hotfix tests: PASS
ByteVeil legacy frontend/stack-safety regression: PASS
ByteVeil v4.7.8 function-policy / hybrid VM tests: PASS
ByteVeil v4.7.8 shadow/semantic regression: PASS (20 semantic mode runs; 8-lane codec; three shadow mutation probes rejected; 0 source-loader stages; fixture=91703 bytes; loader crack probes=0 calls)
```

Benchmark result (`BENCHMARK-V478.json`): 20 profile/preset combinations, 3 independent seeded generations per profile, actual runtime version verified as Lua 5.4; all final outputs under 475,000 bytes, syntax pass, runtime pass; zero source-loader stages in metadata and no direct `load(`/`loadstring(` call site found by the static source scan. Largest median output: 153,603 bytes; largest last-run output: 153,793 bytes. Each profile has one measured runtime smoke run on its final build, not three. Compiler-transformed profiles intentionally are not VM-backed.

The regression suite also exercised the buffer-shim fixture and instrumented `load`/`loadstring`; those probes observed zero calls for the tested output. They do not test every possible loader alias or dynamic instrumentation method.

## CRACK

Performed here:

- static scan of each generated benchmark output for direct `load(`/`loadstring(` call sites;
- runtime execution with `load` and `loadstring` hooks installed for the focused fixture;
- three automated shadow-lane mutation tests: replacing the shadow-step call with `local ST=0`, doing that while forging only the tick increment, and forging tick + accumulator + the visible return/commit value without reproducing the per-handler authenticator; all three fail closed;
- a manual adversarial check of the prior design found that assigning the precomputed expected authenticator into a visible state field bypassed the prior implementation. The expected value is no longer returned as a call-site local; the current proof re-decodes the selected rows and returns only a boolean. The three prior probes were rerun against this design and fail closed. This remains an in-source consistency check, not a cryptographic guarantee: a determined analyst can still patch the verifier or rewrite control flow.
- runtime/syntax tests through a Lua 5.4 runner selected via `BYTECODE_LUA_PATH` (the runner used here is not included in the Windows-focused release ZIP);
- static reading of the representative GitHub sample outputs listed in the corpus report.

Not performed / not verified:

- no external analyst red-team or full devirtualization of a v4.7.8 output was performed during this release pass;
- no extraction test with debugger, hook engine, memory scanner or a Roblox executor was run;
- no native Roblox Studio/Luau execution or Lua 5.1/5.3 runtime test was run;
- no claim is made that the shadow projection is as hard to separate as the real VM or Luraph.

## RETURN

**CHANGED:** static source-trace-based shadow decoys are no longer used by the v4.7.8 route; the active ISA is mapped into a randomized shadow dispatch table and masked/shuffled decoy rows. A per-instruction authenticator binds handler opcode/operand inputs to runtime PC; an independent proof pass re-decodes the masked/shuffled rows and checks the authentication transition alongside tick/state/commit invariants.

**VERIFIED:** active release test suite passes on a runtime whose `_VERSION` is exactly Lua 5.4; the 20-profile benchmark passes with 3 seeded generations per profile; maximum median output is below the 475,000-byte budget; loader probes observed zero calls in tested fixtures; the three focused shadow-step/state mutations are rejected by the independent proof.

**SECURITY LIMITATION:** the three targeted mutation probes described above are now rejected. This is not evidence that an analyst cannot crack the output: an attacker who edits the verifier or rewrites the main VM control flow can still bypass client-side checks. The shadow is still a semantic projection, not a second VM independently proven to execute full source semantics; meaningful resistance to a skilled analyst remains unverified. Do not describe this as crack-proof or Luraph-equivalent.

**NOT VERIFIED:** commercial-obfuscator parity, real-world cracking cost, native Luau/Roblox compatibility, or any protection rating. `npm run test:historical` still stops at `test-v26.js` because that legacy snapshot expects the obsolete `Lua 5.1-5.4 (auto-compatible)` metadata label. Historical tests are not part of `npm test`. This old assertion was not changed blindly because it refers to a historical engine path, and other legacy snapshots also contain old version-specific assumptions.

# Wrapper v2 spec — measured from `A-luraph_sample/1.txt` (Luraph v15.1, 280,360 B)

Tài liệu bàn giao cho chu kỳ **v6** (mandate "sửa lại wrapper giống file 1"). Mọi số liệu dưới đây đo từ
`sample-luraph_15.x.zip` giải nén ra `A-luraph_sample/` — **không phải** hàng mẫu của ByteVeil, và **không**
đi kèm archive này. Script trích xuất (`scratch/extract_f1.js`, `scratch/extract_f1b.js`,
`scratch/analyze_luraph_wrapper.js`) nằm ở `scratch/` nên **không** bàn giao — vì vậy mọi trích dẫn trong
bảng dưới là **nguyên văn byte** lấy từ file sample, đủ để kiểm lại bằng mắt hoặc bằng một phép grep tự
viết trên `1.txt`, không cần tin con số tôi ghi.

All numbers below were read out of the sample by `scratch/extract_f1.js` /
`scratch/extract_f1b.js`, not from memory. Corpus tally over all 53 samples from
`sample-luraph_15.x.zip` (`scratch/analyze_luraph_wrapper.js`):
`{"empty-meta-colon":47,"no-call-tail":1,"other-call-tail":5}` — the empty-metatable colon tail is
the shape Luraph actually emits, so "giống file 1" means targeting that shape.

## Reference tail (verbatim, last 400 chars of file 1)

`…,T=function(P,F,s,...)local N=P[8](...);P[71](N,1,N.n,s+1,F);end},{}):u()(...);`

Prefix: `-- This file was protected using Luraph Obfuscator v15.1 [https://lura.ph/]\n\nreturn setmetatable(`
(the `setmetatable(` begins at byte 84, i.e. nothing but the banner precedes it).

## Structure of the first table (the wrapper region)

| Item | Measured in file 1 | ByteVeil today (seed 0x59A1, l1, luau/register) |
|---|---|---|
| metatable (2nd arg) | `{}` — literally empty | `{__call=…, __metatable=false, [<n>]=[==[byteveil&…]==]}` |
| trailing `;` | present | absent |
| method name | `u` (1 char; corpus: 1–2 chars, 39 distinct over 47 samples) | 2–3 chars (`xks`) |
| numeric fields | 25 keys | 3 slots + 8 stdlib slots + state + decoy key |
| letter fields | 132 | ~7 |
| pow2 array | `a={[0]=1,2,4,…,4294967296}` = 33 entries (2^0..2^32) | `[0]=1..65536` = 17 entries |
| native refs | scattered as **direct** numeric fields: `[8]=table.pack,[99]=bit32.band,[85]=buffer.writeu8,…` | one nested array `pool={type,error,select,…}` under a letter key |
| `buffer.*` refs | 8 distinct (`buffer.create/fromstring/copy/readu8/writeu8/readu32/writeu32/tostring`) | 0 |
| `bit32.*` refs | 5 distinct (`band/bnot/lshift/rshift/bxor`) | 0 |
| symbol map | `d={["'"]="o?+G^",["#"]="[Wyc^",["$"]="myhah",["\""]="5G+Y+",["%"]="9n=10",["&"]="Mt{,4",["!"]="rd6p.",["~"]=";rB1e",["("]="9)9pK",[" "]="uH[OY"}` (10 punctuator→5-char entries) | none |
| short raw junk string field | `H="[ -(~]"` | none (long-bracket blobs only) |
| real letter-keyed function | `T=function(P,F,s,...)local N=P[8](...);P[71](N,1,N.n,s+1,F);end` | yes (step/method/body slots) |

## What wrapper v2 must change

1. `renderCallableBootstrap` emits `{}` as the metatable for the default shape; `__call` disappears.
   The `:method()` call already returns the trampoline that consumes the vararg tuple, so the
   stage-chain semantics are unchanged — but the decoy blob must move into the **first** table as a
   field, and `callable-object` (`invoke:false`, the caller keeps the object) has to stay available
   with its `__call` because an empty metatable makes the object uncalled.
2. Trailing `;`. This breaks `vmMeta.wrapper.shape`'s `endsWith(")(...)")` test and every tail
   assertion (`test-v580.js:137`, `test-v510.js`, `tools/benchmark-v580-wrap.js:407/:631`) — all four
   must move to a regex that accepts the `;`.
3. Method name length 1–2 (corpus-faithful, and it keeps the tail short).
4. pow2 array extended to 33 entries with the `[0]=` offset.
5. Native-ref pool scattered as direct numeric fields of the wrapper table instead of one nested
   array. The pre-flight cross-check then compares `self[<numericSlot>]` pairs rather than
   `pool[i]`.
6. Symbol-map field with punctuator keys → 5-char values, and short raw junk string fields.
7. **Target-aware pool**: `buffer.*` and `bit32.*` are Luau-only in this project's threat model —
   emitting them into a Lua 5.4 artifact would make that output fail to load on real Lua 5.4.
   The Lua pool must draw only from `table.* / string.* / math.* / utf8.* / io-less` globals.

## Load-bearing rule carried over

Nothing in the tail may be decoration: the method owns one LCG step of the state chain, so deleting
`:method()(...)` fails closed, and the pool cross-check wipes on an edited pool. Any new field
(symbol map, junk strings, decoy blob) is either fail-closed under mutation or reported as a decoy
in the benchmark — never silently claimed as resistance.

## Code that hard-codes today's tail (blast radius, read 2026-10-30)

- `src/core/pipeline.js:1574-1589` — shape heuristic (`endsWith(")(...)")` + `/(...):M\(\)\(\.\.\.\)$/`); the
  trailing `;` breaks both. Needs a regex that tolerates `;` and an extra label for the empty-metatable form.
- `test-v580.js` (in the gate): :37 requires `__call=function(` in the seed-123 build; :52 `endsWith('):M()(...)')`;
  :53 requires `__metatable=false,`; :109 `includes("})(...)")`; :112 and :148 anchor `,{__call=function(`;
  :671-672 asserts `getmetatable(obj) == false` for `invoke:false` (metatable lock).
- `test-v590-blob.js` (in the gate): :302-308 locates the wrapper decoy blob **immediately after**
  `__metatable=false,` — moving the decoy into the first table requires a new anchor.
- `tools/benchmark-v580-wrap.js`:161 — `lastIndexOf("__call=function")` is the **end boundary** of the last
  bootstrap-slot slice; with an empty metatable it becomes -1 and slot sizing collapses.
- `tools/benchmark-v580-wrap.js`:332 — pow2 tamper mutates `,32768,65536}`. If the array grows to 2^32, the
  literal changes **and** `stepKey`'s guard (`P[8]~=256 or P[16]~=65536`) would no longer cover the new tail
  entries, so a late-array edit would become an inert mutation. Fix: extend the guard to check the added
  positions (e.g. P[24], P[32]) so every sampled tamper point stays fail-closed.
- Not in the gate (legacy, still worth checking after the change): `test-v570.js`:29, `test-v560.js`:28-30.

## Non-negotiable before claiming "giống file 1"

Native runs on both Lua 5.4 and Luau for every shape × target × preset, plus the mutation set (delete
`:method()`, delete `;`, edit the pool, edit the symbol map, edit the decoy blob) each proven fail-closed or
explicitly reported as inert decoy.

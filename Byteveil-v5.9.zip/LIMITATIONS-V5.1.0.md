# ByteVeil v5.1.0 verification boundaries

This release contains real targeted changes on top of the existing v5.0.0 code. It is not a clean-sheet rewrite and should not be represented as one.

## Implemented and tested in this package

- Version/metadata synchronization in the core and bot package.
- Seeded handler-parameter variation for active generated handlers and semantic-shadow/VM-island handlers; active output no longer emits `function(S,I)` for the sample covered by `test-v510.js`.
- Lexical remapping of generated `__bv_*` and `_bvanti_*` identifiers in active generated output, preserving strings/comments and regular Lua/Luau API spellings.
- Seed-dependent payload lane count/distribution using the existing packed descriptor format.
- Fail-closed-by-default behavior in the anti-hook source builder when no usable environment can be resolved; an explicit `false` opts out. This does not prove that native APIs were not hooked before the script started.
- Crypto-random default seed for Micro's name factory, deterministic explicit seeds, and LPH quoted-argument parsing.
- Explicit Stack/Register method option for `/obf`, bot-side method validation, and tests for deploy synchronization preserving unrelated commands.

## Not claimed as fully completed

- Payload descriptor/decoder architecture has not been replaced from scratch; the current format is an extension of the prior packed-descriptor lane format.
- No universal source-level lexical-scope renaming pass is applied to arbitrary user source. Identifier remapping targets generated internal aliases and VM-generated handler arguments; it is not a substitute for a full scope-resolved compiler name-mangling pass.
- The complete Lua/Luau lexer/parser/IR/compiler has not been formally audited for every language-version feature. Existing and expanded regression tests do not prove compatibility with every Lua/Luau/executor runtime.
- Anti-hook checks cannot prove absence of pre-startup hooks, and dump cleanup cannot guarantee secure erasure from all copies or runtime memory.
- Micro/Macro/LPS/LPH retain their independent existing responsibilities; this release makes focused changes to Micro and LPH parsing and regression metadata. It does not claim to have fully re-engineered all four engines.
- Stack and Register VM architecture is retained and incrementally improved; this is not a rewrite of either VM from zero.
- Discord commands are synchronized by the deploy script/tested mock interactions, but this package has not been deployed to a live Discord application in this session.
- The full release suite `test-v479.js` requires a Lua 5.4 runtime. Any failure caused by an unavailable runtime must be distinguished from a code failure.

# ByteVeil v5.2.0 — limitations and verification boundaries

## Supported input, with boundaries

- Plain source, file uploads and raw HTTP/HTTPS source URLs enter the existing input pipeline.
- Source already obfuscated by another program can be attempted if it parses as supported Lua/Luau and its runtime APIs and semantics are compatible. There is no general-purpose foreign-protector devirtualizer/unwrapper.
- v5.2 adds tested lowering for Luau `continue` and common backtick interpolation, but the interpolation implementation is a bounded parser/lowering feature, not a complete Luau language implementation. Other Luau syntax and Roblox/executor APIs are not validated against a native Roblox Luau runtime in this run. Parser acceptance alone does not prove runtime compatibility.

## Diagnostic literal encoding

- The generated-source pass converts selected diagnostic string literals into decimal byte escapes and routes bare generated `error(...)` calls through a local error alias when the emitted prelude provides one. It preserves the actual runtime message and reduces obvious call-pattern/text exposure in a dump.
- This is not encryption; a reader can decode the escapes statically or at runtime. It does not make the VM's structure or payload inherently uncrackable.
- This pass intentionally does not remove error branches, because silently removing runtime guards or errors would risk changing behavior and concealing genuine failures.
- The current diagnostic matcher is selected-pattern based, not a guarantee that every user-facing or internal message is hidden.

## Payload and reverse-engineering limits

- This is not a clean-sheet VM or payload reorganization. The position-keyed striped lanes and packed region descriptor are inherited from v5.1; the main new changes concern parser precedence, validation, diagnostic rendering and input delivery.
- The runtime decoder and payload-related derivation data remain in output because the client must execute the program. No claim of 100% anti-crack protection is made.
- Existing integrity checks are not cryptographic message authentication. Anti-hook logic cannot prove that API references were native before program startup.
- Stack and Register retain their existing independent backends; broader changes to closure/upvalue semantics, coroutine behavior, every Luau feature and every executor environment remain outside this targeted release.

## Runtime and deployment verification

- `npm test` passed the configured active regression suite in the available environment.
- JavaScript syntax checks passed for project files.
- `npm run test:all` stopped at an explicit runtime-version precondition: the extended release probe requires Lua 5.4 but only Lua 5.3 was available. The extended Lua 5.4 release/crack suite therefore remains unverified.
- No native Roblox Luau runtime test and no live Discord application deployment were performed in this run. Discord command synchronization and URL request behavior were mock-tested.

## Output budget

- The active v5.2 VM output profile enforces a 475,000-byte maximum. Explicit legacy/compatibility routes retain their own selected route policy. Sample observations vary by input, preset, backend and options.
- Outputs smaller than 375,000 bytes are not padded; the historic range is not a requirement to inflate small inputs.

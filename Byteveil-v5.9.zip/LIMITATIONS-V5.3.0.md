# ByteVeil v5.3.0 limitations

- Runtime guard byte tables can be recovered by static or dynamic analysis; this change reduces obvious source signatures, not the theoretical recoverability of the strings.
- Anti-hook checks detect selected API replacement after initialization, not hooks installed before the script captures its baseline.
- Lua 5.4 and native Roblox Luau validation must be performed on matching runtimes before claiming full compatibility.
- This is a targeted anti-hook presentation/structure fix, not a full payload/VM architecture rewrite.

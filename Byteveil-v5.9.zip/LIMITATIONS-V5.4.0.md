# ByteVeil v5.4.0 limitations

- Build-derived local names, state keys and decoy strings are recoverable through static/dynamic analysis. They remove selected stable fingerprints; they are not cryptographic encryption.
- A local-name tokenizer/mangler is deliberately scoped to generated shadow source. It is not a general-purpose Lua/Luau parser or whole-program symbol-renaming proof.
- Cross-backend closure captures are not implemented. By default, a function-policy request that captures locals from another VM is rejected; `allowPolicyFallback: true` explicitly permits fallback to the containing chunk and records that decision in build metadata.
- The shadow VM uses a build-derived semantic-handler sandbox and integrity/trace checks; it is not a second VM that executes the user's program with full language semantics.
- API guards can only check assumptions represented by their baseline and checks. They cannot prove the environment was not instrumented before startup.
- The configured regression suite uses the Lua-compatible runtime available on this host. A test requiring a native Lua 5.4 runtime cannot be claimed as passed when only Lua 5.3 is available.
- A native Roblox Luau runtime was not available in this environment, and this run does not deploy the Discord bot to a live application.
- No anti-reversing guarantee is made. A client-side VM necessarily ships enough information to execute its payload.

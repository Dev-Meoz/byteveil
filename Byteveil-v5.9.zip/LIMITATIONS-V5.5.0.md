# ByteVeil v5.5.0 — limitations and unverified scope

- **No unbreakable protection claim:** payload codecs and runtime decoders are shipped together. An analyst can inspect or instrument the generated runtime.
- **VeilSync scope:** this is an integrated coordinator for existing reversible encoding stages with build-time round-trip verification. It is not cryptographic encryption and does not hide the decoder from an analyst.
- **State/handler randomization target:** the requested 98% target is not implemented as a measurable coverage requirement. Do not infer that target from randomized local names, opcode IDs, or state slots.
- **VM architecture:** Stack and Register are selectable and have regression coverage, but still share substantial generated runtime infrastructure. This release is not a complete dual-VM redesign.
- **Superoperators:** the production planning field still reports no actual fused instructions. Superoperator fusion is not delivered in v5.5.0.
- **Tamper checks:** `setmetatable` replacement after baseline capture is detected and fails closed. Replacement before baseline capture, direct runtime patching, or complete analysis can bypass/defeat this type of client-side guard.
- **Nest preset:** uses the existing v4.7.4 nested-source engine and has five layers at strength 6000. It requires `load`/`loadstring` support. Native Roblox Luau behavior was not verified here; use only where the target runtime permits dynamic compilation.
- **Macro/LPS/LPH:** current regression suites pass and the active version metadata is updated, but the broader requested API/semantic redesign has not been completed.
- **Full test matrix:** `npm test` passes. `npm run test:all` includes `test-v479.js`, whose precondition requires Lua 5.4. This environment's available Lua-compatible executable is not guaranteed to satisfy that exact precondition.

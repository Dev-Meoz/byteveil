# ByteVeil v5.6.0 — limitations and unverified scope

- **No unbreakable-protection claim:** payload codecs and runtime decoders are shipped together. Analysts can inspect or instrument generated runtime code.
- **VeilSync scope:** the v2 coordinator verifies existing reversible codec stages at build time. It is not cryptographic encryption and does not hide the decoder.
- **State/handler randomization target:** the requested 98% target is not implemented as a measurable coverage requirement. Do not infer that target from randomized local names, opcode IDs, or state slots.
- **VM architecture:** Stack and Register are selectable and have regression coverage, but still share substantial generated-runtime infrastructure. This release is not a complete dual-VM redesign.
- **Superoperators:** the production planning field still reports no actual fused instructions. Superoperator fusion is not delivered in v5.6.0.
- **Tamper checks:** replacement of `setmetatable` after baseline capture is detected and fails closed. Replacement before baseline capture, direct runtime patching, or complete analysis can bypass or defeat this class of client-side guard.
- **Nest preset:** uses the existing v4.7.4 nested-source engine and requires `load`/`loadstring` at runtime. Native Roblox Luau behavior was not verified; use only where the target runtime permits dynamic compilation.
- **Macro/LPS/LPH:** current regression suites cover existing behavior, but the broader requested API/semantic redesign has not been completed.
- **Diagnostic encoding:** selected generated-runtime diagnostic literals are encoded for readability resistance only. Other structural cues remain, and numeric escapes are reversible.
- **Runtime scope:** tests use the Lua-compatible executable available in this environment. They are not proof of compatibility with every Lua interpreter, Roblox Luau, or exploit-specific runtime.
- **Test runner:** `npm test` runs 11 isolated suites in batches of three and is verified on this environment; lower-resource hosts may need to run the component tests individually if they impose strict process/time limits.

## Targeted follow-up scope

- **Compiler/front end scope:** v5.6.0 does not constitute a full rewrite of the lexer, parser, IR builder, compiler or bit utilities. The existing operator-precedence and selected parser/runtime regressions are tested, but unsupported grammar and IR-quality issues remain possible. Do not read these targeted patches as proof that all front-end weaknesses are resolved.
- **Minifier boundary:** output is token-aware and single-line for generated VM cases covered by tests, but no formatter can safely erase every separator. Wrapper parameters and table/metamethod syntax necessarily remain visible, and token names alone are not a security barrier.
- **Decoy fidelity:** decoy operands/fingerprints now vary with the seed and encode instruction content, but the decoy program is still not a second semantically complete VM and can be distinguished by deeper analysis.
- **Sample regeneration:** the two `.lua` files supplied for the audit were not overwritten. They are pre-patch v5.6.0 artifacts; to observe the new name cleanup/minifier, regenerate from the original unobfuscated source using this source tree.
- **Native Luau verification:** the available runtime in this environment is Lua via LuaTeX; no native Roblox Luau executable was available. All 11 release suites pass, but that is not a claim of live Roblox execution.

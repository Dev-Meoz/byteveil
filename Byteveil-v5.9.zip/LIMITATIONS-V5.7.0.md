# ByteVeil v5.7.0 — limitations and remaining work

## Current limitations

- **VM architecture:** Stack and Register still share significant generated-runtime infrastructure. The v5.7 wrapper change does not by itself make them two fully independent VM architectures.
- **IR/compiler:** no comprehensive semantic-IR rewrite was performed. Lexer/parser support for complex Luau syntax, closure/upvalue semantics, and transformation correctness still requires a separate audited effort.
- **Payload layout:** the existing position-keyed striped region container and runtime decoding path are retained. v5.7 has not implemented a new prototype directory with independently materialized code/constant regions.
- **Obfuscation versus encryption:** seeded numeric slots, variable renaming, dispatch indirection and VeilSync transforms increase analysis work but are not cryptographic guarantees. Decoder behavior can be studied or instrumented at runtime.
- **Wrapper topology:** the renderer has two output topologies, but they both remain a callable-table wrapper around the existing generated body; they are not a new VM.
- **Macro/LPH/LPS:** active regressions pass, but this release does not turn every directive into an independently verified compiler transformation.
- **Runtime validation:** test coverage uses the available Lua-compatible runtime. Native Roblox Luau is not installed/available here, so Roblox runtime compatibility is not verified by this release.
- **Nest preset:** the historical nested-source engine remains opt-in and requires `load`/`loadstring` at runtime.
- **Reverse-engineering percentage:** no universal 80–90% recovery limit is claimed. A credible measurement needs known original inputs, an explicitly defined recovery rubric, repeatable analysis attempts, and comparisons across identical source/preset/runtime combinations.

## Recommended next milestone

The next major step should not be more wrapper noise. Audit and improve semantic IR/CFG representation first, then define a versioned prototype/region format and independently specified Stack/Register ABIs. Add a differential corpus for closures, upvalues, multiple returns, varargs, methods, metatables, coroutines, errors and Unicode before expanding decoder/dispatch transformations.

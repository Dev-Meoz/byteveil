# ByteVeil v5.8.0 limitations

- **Incremental, not architectural replacement:** the lexer, parser, semantic IR, compiler, core Stack/Register VM, and striped payload/container format are largely inherited from previous releases. This is not the major compiler/VM redesign previously discussed for the 6.x line.
- **The size drop is not a strength score:** the shared shadow-dispatch core removes repeated handler source. Smaller output alone does not establish that a devirtualizer will recover less code or take longer.
- **Seed variation is limited in this change:** action IDs vary per build, but the core shape and action categories remain visible. This should not be described as a novel VM ISA or a fundamentally new payload architecture.
- **Diagnostic string encoding is not encryption:** decimal escapes can be reversed and do not stop runtime instrumentation.
- **No resistance percentage guarantee:** ByteVeil cannot guarantee that 80–90% of source is unrecoverable. Any claim like that requires a documented benchmark corpus, threat model, baseline, and independent analysis.
- **No direct Luraph parity evidence:** no controlled, repeatable benchmark against Luraph v14.7 or v15.x was run here. Version numbers cannot demonstrate parity.
- **Native Roblox Luau unverified:** the current available runtime is Lua-compatible, not a native Roblox Luau runtime. Compatibility with Roblox-specific semantics and sandbox behavior remains unproven.
- **Focused size fixture only:** l1/lz measurements were made on one short concatenation script, one seed, and one test environment. Do not generalize those percentages to large projects.
- **Unconfirmed output anomaly:** the earlier user-provided l1 output included a suspicious `wzqm[3]` reference in a handler. This specific expression was not reproduced or isolated by the focused fixture; it is not claimed fixed. It needs a reproducible source, preset, options, and seed to diagnose.
- **Nest loader constraint:** the historical nested-source route still depends on `load`/`loadstring`, which may be unavailable or restricted in some Luau hosts.

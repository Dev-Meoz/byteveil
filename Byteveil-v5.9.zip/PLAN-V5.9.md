# ByteVeil v5.9 — Kế hoạch phát triển

**Trạng thái:** Đang chuẩn bị; chưa phải bản release hoàn chỉnh  
**Baseline:** Source ZIP ByteVeil v5.8 Hardened do người dùng cung cấp  
**Phân công:** Frontend do ChatGPT xử lý; backend do Qoder AI triển khai, Arena AI review/fix/debug, sau đó trả lại để kiểm tra tích hợp cuối.

## 1. Mục tiêu v5.9

1. Nâng độ tin cậy của frontend parser/lexer, đặc biệt là lỗi cú pháp, vị trí chẩn đoán và phục hồi sau input không hợp lệ.
2. Giữ tương thích với API hiện tại; bổ sung API chẩn đoán chi tiết thay vì âm thầm thay đổi hợp đồng cũ.
3. Tiếp tục các mục backend còn mở từ log review v5.8 Fix 3, nhưng không tự ý chỉnh backend trong nhánh frontend này.
4. Không đánh dấu release hoặc nâng `package.json` lên 5.9.0 cho đến khi backend được trả về, tích hợp, và release gate được chạy hoàn tất.

## 2. Phạm vi frontend đã xử lý

- `src/frontend/lexer.js`
  - Chuẩn hóa theo dõi dòng/cột cho CRLF và CR đơn.
  - Giữ đúng vị trí token sau long comment bắt đầu bằng `--`.
  - Báo lỗi với newline không escape trong chuỗi trích dẫn.
  - Hỗ trợ line continuation `\\` + LF/CRLF/CR thành một newline logic.
  - Báo lỗi escape hex/Unicode sai định dạng, Unicode surrogate hoặc code point vượt miền hợp lệ.
  - Báo lỗi khi số có hậu tố identifier không hợp lệ thay vì im lặng tách token.
  - Giữ nguyên hỗ trợ Unicode identifier, long string/comment và Luau interpolation hiện có.
- `src/frontend/parser.js`
  - Thêm `parseDetailed()` để trả AST, token, lỗi lexer, lỗi parser và feature flags.
  - Giữ `parse()` trả AST như trước để không phá API hiện tại.
  - Báo lỗi khi danh sách biểu thức bị thiếu giá trị.
  - Chặn vòng lặp vô hạn ở danh sách tham số function khi source kết thúc tại EOF.
  - Báo lỗi khi thiếu toán hạng ở biểu thức unary/binary và biểu thức trong ngoặc.
- `src/frontend/index.js`
  - Export API mới `parseDetailed`.
- `test-v590-frontend.js`
  - Thêm regression tests cho diagnostics, escapes, số sai định dạng, CRLF/CR, long comments, Unicode và interpolation.
- `package.json`
  - Thêm script `test:v590:frontend`; chưa thay đổi version package.

## 3. Phạm vi backend chờ Qoder AI

Qoder AI chịu trách nhiệm sửa/triển khai backend theo yêu cầu của dự án. Không giới hạn vào các mục sau:

1. **Payload/subsystem partitioning:** xác minh mỗi carrier/giai đoạn có logic thực thi thực sự; output nguyên bản phải chạy trước khi benchmark kiểm tra tamper; không dựa riêng vào số liệu khai báo sẵn.
2. **Dispatch/topology:** xác minh hai topology khác nhau về trách nhiệm thực thi thật, không chỉ thứ tự field hoặc phép toán che số; đối chiếu semantics giữa seed.
3. **Vararg và semantics Lua/Luau:** mỗi fixture phải chạy đúng số lần dự kiến; kiểm thử số lượng return, trailing `nil`, closure/upvalue, thứ tự side effect, global và lỗi runtime.
4. **Release gate:** điều tra timeout của `npm test`, ghi exit code và output của mọi suite; không coi các suite chạy lẻ là tương đương với release gate đầy đủ.
5. **Tích hợp:** giữ hợp đồng của frontend và các API hiện có; mọi thay đổi ngoài phạm vi cần ghi lý do, file, regression test và ảnh hưởng tương thích.

## 4. Vai trò của Arena AI

Sau khi Qoder AI hoàn tất, Arena AI cần review và fix/debug độc lập:

- Chạy các bài test do Qoder bổ sung, kiểm tra test có thể tái lập và không pass giả.
- Tìm lỗi cú pháp, regression semantics, sai khác giữa backend Stack/Register, và trường hợp lỗi runtime.
- Xác minh output gốc chạy thành công trước tamper test.
- Trả lại source đầy đủ cùng log `CHANGED / VERIFIED / LIMITATIONS / RUN`, danh sách test PASS/FAIL và lỗi còn lại.
- Không chỉ trả về nhận xét hoặc diff không có source tích hợp.

## 5. Kiểm tra cuối sau khi backend quay lại

1. So sánh source trả về với baseline và frontend patch này.
2. Chạy `npm run test:v590:frontend`.
3. Chạy regression suites v5.8 và suite riêng cho Register/Stack.
4. Chạy toàn bộ `npm test` đến khi có exit code hoàn chỉnh, không bị timeout.
5. Chạy native Lua/Luau tests nếu runtime tương ứng hiện diện.
6. Chỉ sau khi có bằng chứng đầy đủ mới nâng package/engine version lên `5.9.0` và ghi release log.

## 6. Tiêu chí hoàn thành

- Frontend không mất vị trí dòng/cột sau comment hoặc newline thông dụng.
- Input sai được báo chẩn đoán thay vì lặp vô hạn hoặc bị parse im lặng.
- API cũ vẫn tương thích; API mới có test độc lập.
- Backend đã qua Qoder implementation và Arena review/debug.
- Toàn bộ release gate chạy hết thành công; các giới hạn runtime được ghi rõ.

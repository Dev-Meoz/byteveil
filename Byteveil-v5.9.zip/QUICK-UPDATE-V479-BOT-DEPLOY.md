# ByteVeil v4.7.9 Quick Update — Discord Command Synchronization

## Problem addressed

The bot’s command help/footer and ready log still displayed v4.7.8 while the package/engine was v4.7.9. The prior deploy flow also sent a separate removal write and later deployment write to the active command scope, creating a transient empty/stale command window. Only the configured guild was known, so old guild-specific registrations could remain after changing `DISCORD_GUILD_ID`.

## Changes

- `bot/src/deploy-commands.js`: discovers all configured scopes before mutation; bulk-overwrites the active scope in one write with unrelated commands preserved plus the canonical `/help`, `/rule`, `/obf` schema from `commands.js`; removes ByteVeil command names from other known scopes; supports `--reset-only`; fails closed if REST sync fails so startup cannot continue.
- `bot/src/config.js`: adds optional comma-separated `DISCORD_LEGACY_GUILD_IDS` for guilds previously used by the application.
- `bot/src/commands.js`, `bot/src/discord_rules.js`, `bot/src/index.js`, `bot/README.md`: synchronize bot display/version labels to v4.7.9.
- `bot/.env.example`: documents the legacy guild list.
- `test-v479-bot.js`: covers repeated startup with same-name stale schemas, global cleanup, cleanup of a previous guild, preservation of unrelated commands, reset-only mode, and fail-fast startup script order.
- Keeps the striped payload and register-command ABI changes included in this v4.7.9 candidate.

## How it behaves

1. `npm start` runs `bot/src/deploy-commands.js` before `bot/src/index.js`.
2. The active global or guild scope receives the complete canonical ByteVeil command schema by one bulk-overwrite request. Same-name commands with outdated options are replaced, not left alongside the current definition.
3. ByteVeil commands are removed from the other known scopes, while unrelated commands are retained.
4. Any deployment failure returns a non-zero exit status; because startup uses `&&`, the new process does not log into Discord.

When `DISCORD_GUILD_ID` changes, place prior guild IDs in `DISCORD_LEGACY_GUILD_IDS`, for example `111111111111111111,222222222222222222`. The Discord application command API does not provide one route to enumerate every guild-specific registration from all historical guilds; stale guild IDs must be supplied explicitly.

## Verification

- `node test-v479-bot.js`: PASS.
- `npm test` with `BYTECODE_LUA_PATH` pointed at a Lua 5.4 runner: PASS for all listed release suites, including LPS, striped payload/descriptor tamper, register ISA, audit fixes, bot deployment, Macro/LPH, legacy, tail-return, function policy and 26 shadow/semantic runs.
- Live Discord REST deployment/login was not run because no live bot credentials were used; deployment correctness is verified with deterministic REST mocks.

# ByteVeil v4.7.7 — Hybrid VM / Function-Level Policy

ByteVeil v4.7.7 builds on the v4.7.6 binary-region VM and adds a function-level policy selector. It uses an independent register-oriented VM-A backend and stack-oriented VM-B backend, with a lexical bridge for supported top-level global functions. The goal is to make backend selection measurable and fail closed when a requested route cannot be supported.

## Function policy API

```js
const { obfuscate } = require("./src");

const result = obfuscate(`
function add(a, b) return a + b end
function priceWithTax(price, rate) return price * (1 + rate) end
print(add(4, 5), priceWithTax(100, 0.08))
`, {
  target: "lua",
  preset: "lz",
  seed: 0x47770001,
  vmPolicy: "balanced",
  functionPolicies: {
    priceWithTax: "hardened"
  },
  allowPolicyFallback: false,
  maxOutputBytes: 475000
});

console.log(result.vmMeta.functionPolicyReport);
console.log(result.output);
```

Supported policies:

- `balanced` / `vm-a`: register-oriented VM-A for the containing chunk or selected function.
- `hardened` / `vm-b`: stack-oriented VM-B for the containing chunk or selected function. “Hardened” is a policy name, not a claim that it is proven harder to reverse engineer.
- `compiler-transformed`: source-to-source transformation without VM virtualization. The output intentionally reconstructs transformed source; this mode does not provide the same virtualization boundary as either VM backend.

The `l1`, `l2`, `df`, and `lz` presets remain available. Legacy `mode: "register"` / `mode: "stack"`, Discord slash commands, Macro and LPH entry points remain supported.

### Function routing scope

Function-level cross-backend routing currently supports **simple, named, top-level global function declarations**. It does not yet transport captured chunk locals/upvalues across VM runtimes, nor does it route local functions, method declarations, or nested anonymous functions as independent VMs.

Unsupported mixed-policy requests fail by default. `allowPolicyFallback: true` is an explicit opt-in to keep the function in the containing chunk; the result metadata records the requested policy, effective backend and reason. Inspect `result.vmMeta.explicitFallbacks` and `result.vmMeta.functionPolicyReport` rather than assuming every request was independently routed.

A global named function that is selected for a different policy is replaced with a lexical bridge call. This avoids adding a normal global bridge variable but does not preserve cross-VM closure captures; those requests are rejected unless explicit fallback is enabled.

## Development and verification

Install dependencies and run:

```sh
npm install
npm test
node tools/benchmark-v477.js --runs=3
```

`npm test` includes the bot deploy mock, Macro/LPH tests, the legacy frontend/stack-safety regression, policy/hybrid-VM tests and v4.7.7 VM/runtime tests. The benchmark command emits JSON for 20 profiles: the five backend/policy paths under each of `l1`, `l2`, `df`, and `lz`. The recorded output is `BENCHMARK-V477.json`; a full summary is in `BENCHMARK-V477.md`. See `CORPUS-RESEARCH-V477.md` for source-by-source corpus observations and limitations.

## Runtime compatibility status

- **Verified here:** Lua 5.4 via the bundled runner, including syntax/runtime and the v4.7.7 regression suites.
- **Not verified here:** Lua 5.1, Lua 5.3, and native Roblox Luau in Roblox Studio.
- The optional `buffer` branch was exercised under a Lua-side shim. That validates the generated code's integration contract in that fixture, not native Roblox Luau behavior, API availability across Roblox versions or performance.

## Security scope

The binary-region payload has eight reversible byte transforms, a build-specific representation and the v4.7.6 live-opcode-coupled secondary state path. These transformations are not encryption and do not prevent an analyst from inspecting runtime state. The loader-hook tests prove only that these tested fixtures do not invoke `load`/`loadstring`; they do not prove resistance to VM devirtualization, constant recovery, memory inspection or sophisticated dynamic instrumentation. No parity claim is made with Luraph, MoonSec or any other commercial obfuscator.

## Corpus research

The implementation was informed by static observations of protected outputs such as [Luraph v15.1 sample `390ea6acb88b8f9f.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.1/390ea6acb88b8f9f.lua), [Luraph v15.1 sample `2153b779fa7a87f2.lua`](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.1/2153b779fa7a87f2.lua), and the [Sample-obfuscator output corpus](https://github.com/Dev-Meoz/Sample-obfuscator). Those repositories contain protected outputs, not full original engine source. Observed `buffer.*`, bit-operation and dispatch patterns are used as research references only; no claim is made about the proprietary internals behind them.

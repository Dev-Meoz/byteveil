# ByteVeil v4.7.8 — ISA-Coupled Semantic-Projection Shadow VM

ByteVeil v4.7.8 keeps the v4.7.7 hybrid function-policy and binary-region VM architecture, and fixes a weakness in its secondary/shadow execution lane. The old path approximated opcode mappings with name-matching rules and derived decoy operands from a static source trace. v4.7.8 instead creates a per-build randomized ID for every opcode in the active ISA, routes each live VM opcode through the corresponding shadow handler, and uses a masked/shuffled secondary instruction stream drawn from that same build-specific ISA.

**Important distinction:** this shadow lane is an operation-correlated *semantic projection*, not a second VM proven to execute the complete source semantics independently. Its state contributes to runtime guard/fabric evolution, while the main VM remains responsible for program semantics. The verifier independently re-decodes the selected masked/shuffled rows and validates an authentication transition for each live+decoy step. Focused mutation probes reject a no-op, a forged tick, and a forged tick+accumulator+commit when the valid auth transition is absent. These probes are not proof against an analyst who patches the verifier or rewrites control flow; this is not a claim of Luraph parity.

## Function policy API

```js
const { obfuscate } = require("./src");

const result = obfuscate(`
function add(a, b) return a + b end
function priceWithTax(price, rate) return price * (1 + rate) end
print(add(4, 5), priceWithTax(100, 0.08))
`, {
  target: "lua",
  preset: "lz",
  seed: 0x47800001,
  vmPolicy: "balanced",
  functionPolicies: { priceWithTax: "hardened" },
  allowPolicyFallback: false,
  maxOutputBytes: 475000
});

console.log(result.vmMeta.functionPolicyReport);
console.log(result.output);
```

Supported policies:

- `balanced` / `vm-a`: register-oriented VM-A.
- `hardened` / `vm-b`: stack-oriented VM-B. “Hardened” is a policy label, not a measured security ranking.
- `compiler-transformed`: source-to-source transformation without VM virtualization; it does not provide the same virtualization boundary as either VM backend.

The `l1`, `l2`, `df`, and `lz` presets, legacy `mode: "register"` / `mode: "stack"`, Discord slash commands, Macro and LPH entry points remain available.

## Shadow-lane changes in v4.7.8

- A unique randomized secondary opcode ID is assigned to every active-build opcode; the live `logical` opcode selects the matching handler through the build-specific map.
- Shadow handlers are generated per opcode instead of mapping unrelated opcode names into a small fixed set of toy operations.
- Decoy rows are serialized from the active build ISA, masked field-by-field, and stored in a seed-shuffled physical order.
- A static source opcode/operand trace is no longer embedded (`shadowTraceOpcodeCount = 0`, `shadowOperandTraceDerived = false`).
- An independent per-instruction proof pass re-decodes masked/shuffled rows and recomputes an authenticator over opcode, operands, PC and transition input. `test-v478.js` includes no-op, forged-tick, and forged-state/commit mutation probes; all three are rejected by the current verifier. See `CRACKTEST-V478.md` for limits and the methods not tested.
- Metadata explicitly labels the architecture `semantic-projection-isa-v478` to avoid overstating it as a second semantics-complete VM.
- The existing eight binary-region transforms, zero source-loader stages and function-policy fail-closed behavior are retained.

## Function routing limits

Function-level cross-backend routing supports simple, named, top-level global function declarations. It does not yet transport captured chunk locals/upvalues across VM runtimes, nor independently route local functions, method declarations or nested anonymous functions. Unsupported mixed-policy requests fail by default. `allowPolicyFallback: true` is an explicit opt-in; results record the requested policy, effective backend and reason. Inspect `result.vmMeta.explicitFallbacks` and `result.vmMeta.functionPolicyReport` instead of assuming every requested route was independently applied.

## Verify and benchmark

Install a real Lua 5.4 interpreter first and set `BYTECODE_LUA_PATH` to its executable. Do not point it at LuaTeX/LuaMetaTeX; the release tests now verify the executable-reported `_VERSION`.

```sh
npm install
# Linux/macOS example
BYTECODE_LUA_PATH=/path/to/lua5.4 npm test
BYTECODE_LUA_PATH=/path/to/lua5.4 npm run benchmark:v478 -- --runs=3
```

PowerShell example:

```powershell
$env:BYTECODE_LUA_PATH = "C:\Lua54\lua54.exe"
npm test
npm run benchmark:v478 -- --runs=3
```

`npm test` covers the mocked bot deploy path, Macro/LPH, the legacy front-end/stack-safety regression, function-policy/hybrid VM and v4.7.8 shadow/semantic tests, including three focused shadow-state mutation probes that are rejected. These checks do not protect against a determined analyst who patches the verifier or rewrites control flow; see `CRACKTEST-V478.md`. The benchmark exercises 20 combinations (4 presets × 5 policy profiles), records generation/runtime metrics, checks Lua syntax/runtime and enforces the 475,000-byte output budget. The current checked run recorded 3 independent seeded generations per profile in `BENCHMARK-V478.json`; summary: `BENCHMARK-V478.md`. Runtime syntax/behavior were checked once per profile on the final generated build.

## Verification status

- **Verified here:** Node syntax checks, v4.7.8 test suite, 20 benchmark profile/preset combinations through a Lua 5.4 runtime selected via `BYTECODE_LUA_PATH`, buffer-shim fixture, and `load`/`loadstring` instrumentation on tested fixtures.
- **Security status:** the previously known tick+accumulator+commit mutation is now rejected when the attacker does not reproduce the independent authenticator. The shadow still is not a full independent semantic VM, and resistance to a skilled analyst who rewrites the verifier/control flow is not verified.
- **Not verified here:** execution in Roblox Studio/native Roblox Luau, Lua 5.1/5.3 compatibility, performance at scale, third-party red-team devirtualization/cracking of v4.7.8, and commercial-obfuscator parity.
- The loader-hook result means the tested outputs did not call the two instrumented source loaders. It does not establish resistance to instruction tracing, memory inspection, VM extraction or other dynamic/static attacks.

## Corpus research

Research notes identify the exact files, observed structures, hashes and interpretation limits: [`CORPUS-RESEARCH-V478.md`](CORPUS-RESEARCH-V478.md). The two provided GitHub repositories contain protected output samples, not the original private source of Luraph. Their structures are evidence for comparative analysis, not ground truth about the proprietary implementation.

- [Sample-obfuscator corpus](https://github.com/Dev-Meoz/Sample-obfuscator)
- [Sample corpus archive](https://github.com/Dev-Meoz/Sample)
- [Luraph v15.1 representative sample](https://github.com/Dev-Meoz/Sample/blob/main/Luraph/v15.1/390ea6acb88b8f9f.lua)

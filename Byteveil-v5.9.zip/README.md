# ByteVeil v5.9.0 — closed option surface, obsolete engines deleted, v5.9 runtime tag

ByteVeil v5.9.0 keeps the v5.8 shared shadow-dispatch core and the VeilSync-v2 position-keyed
payload pipeline, and adds the layers built during this cycle: **VeilBlob-v1** (seed-keyed
long-bracket string containers), **VeilStr-v1** (per-build keystream for constant strings),
**JunkForge-v1** (density floor with a self-checking key bed), an **engine precheck gate**, the
anti-hook **verdict-as-key** binding, and a **closed option registry** that refuses knobs and
values that do not select a real route.

This is an incremental hardening cycle, **not** a full compiler / IR / VM / payload-format
redesign. Entropy, byte share, container counts and file size are *structural* metrics: they
describe the shape of the output, they do **not** prove that devirtualization is harder.
Obfuscation is not cryptographic encryption and cannot guarantee that source semantics are
impossible to recover.

## Install and run

- Requires Node.js 18 or later.
- Install dependencies with `npm install`.
- Configure the bot from `bot/.env.example`. **Never distribute `.env` files or real bot tokens** —
  the release archive is checked with `unzip -l` and contains no `.env`.
- Install the native test hosts with `npm run native:install` (PowerShell, Windows). The gate needs
  `lua54.exe` (Lua 5.4.8) and `luau.exe` (0.739 standalone — not Roblox Luau).
- Run `npm test` (or `npm run test:v5:release`) for the release gate: **21 suites**, concurrency
  `cores/2`, per-suite timeout 600,000 ms. Last recorded run: `PASS (all 21 suites; concurrency=4;
  total=249,052ms)`, exit 0, on an 8-core Windows machine.
- `npm run native:test` runs host syntax/runtime validation (6 checks).
- `npm run test:legacy:engines` runs the four historical suites that read the quarantined `legacy/`
  tree. Three of them assert shapes of pre-5.x routes and fail for documented reasons (see
  `legacy/README.md`); they are **not** part of the release gate.

## Presets

- `l1` — entry preset; emits the callable bootstrap. With the default `shape: "auto"` the tail is
  seed-derived between `colon-dispatch` and `callable-object` (`src/wrappers/bootstrap_renderer.js`,
  `chooseShape`); request `wrapper: { shape: "callable-object" }` to pin it. The emitted tail is
  reported as `vmMeta.wrapper.shape`.
- `l2` — stronger VM profile.
- `nest` — opt-in reuse of the historical v4.7.4 nested-source loader around the VM output. Requires
  `load`/`loadstring` and may not suit every Luau host. It emits **no** runtime guard and does not
  bind the key bed (`keyBedBound:false`).
- `df` and `lz` — higher-strength profiles; `default` and `maximum` are `l1`/`lz` plus
  `compatibilityRoute:true`, which does **not** force the source engine — it only permits the
  source-container fallback when the parser or strict VM refuses the input (measured: a clean parse
  on `l1` + `compatibilityRoute:true` still builds the custom VM, 70,792 B, `fallback=false`). Use
  `backend:"source"` to ask for the container directly.

The Discord `/obf` command requires a preset and an explicit Stack/Register method.

## Option surface (v5.9)

`src/core/option_registry.js` is the single list of what `obfuscate()` accepts.

- **Registered and read:** 19 top-level keys + 11 `transforms.*` keys. The gate refuses any
  registered key that has no read site, so decorative options cannot come back.
- **Retired (build refused when requested with an active value):** `debug`, `nestedSourceEngine`,
  `nestedProfile`, `transforms.gsubAnchor`, `transforms.payloadDecoys`. Each was proven byte-inert on
  real builds, so asking for one now throws `ByteVeil v5.9.0 option … is not implemented (…)` instead
  of silently building without it. Falsy values (`debug:false`, `payloadDecoys:0`) still build, so
  older scripts do not die.
- **Closed value sets:** `backend` ∈ {`vm35`, `vm33`, `source`}, `target` ∈ {`auto`, `lua`, `luau`},
  `mode` ∈ {`stack`, `register`, `hybrid`}, `wrapper.returnMode` ∈ {`setmetatable`, `direct`, `gsub`}.
  A typo such as `backend:"vm36"` or `target:"lua54"` refuses the build rather than falling through
  to a weaker route. `backend:"source"` is the explicit source-container route.
- **Unknown keys:** reported in `result.optionAudit.notApplied` (non-fatal by default); pass
  `strictOptions:true` to make them fatal.
- `wrapper:{setmeta:false}` and `wrapper:{returnMode:"direct"}` are one shape (measured
  byte-identical); the caller's wrapper spec now wins over the preset default.

## Engine tree

- `src/` contains **only** engine files reachable from `src/index.js` (76 files, 0 orphans), and no
  file in `src/` requires `legacy/`. Both invariants are asserted by `test-v590-tree.js`.
- 37 obsolete engine files from an earlier generation live under `legacy/src/<old-path>`. They still
  parse and remain readable from the historical suites — quarantine, not deletion.
- Two slow paths remain inside live files (`buildGeneratedSource` in `src/compiler/stack/vm_generator.js`
  and `src/compiler/register/reg_vm_generator.js`). Neither is reachable from `obfuscate()`, and
  shipped artifacts contain no `for _=1,32` loop (asserted structurally by `test-v590-bitops.js`).

## Verification

The 21-suite gate covers VeilBlob codec/parity/tamper, VeilStr parity plus fail-closed attacks,
JunkForge envelope + census + key bed, carrier load-bearing (payload flips and truncations rejected
on Lua 5.4 and Luau), environment-logger detection, engine-precheck fault classes, option/tree
invariants, bitwise-operator semantics on both hosts, anti-bundle verdict-key binding, the shared
shadow core, LPS, Register ISA, function-policy/hybrid routes, Macro/LPH, tail-return, bot
deploy/reset, the frontend grammar suite and the v4.3.3 legacy regressions.

Release evidence, exact commands, exit codes and wall times: `CHANGES-V5.9.0.md`.
What is **not** proven, with every measured caveat: `LIMITATIONS-V5.9.0.md`.
Remaining distance between the v5.9 wrapper and the reference shape analyzed from a Luraph 15.1
sample: `HANDOFF-V6-WRAPPER-SPEC.md`.

## Limitations

- **Load cost is the open blocker.** Measured per-op cost of the shipped VM interpreter is
  ~320–350 µs on Lua 5.4 — orders of magnitude above native, and the gap versus the Luraph samples
  is documented with numbers in `LIMITATIONS-V5.9.0.md`. No new anti/obfuscation layer should be
  added before this is fixed and re-measured.
- **VeilBlob / VeilStr are keystream obfuscation, not standard cryptography.** Every key derives
  from the build seed, which is present in the output. They must not be marketed as AES-strength.
- **JunkForge is density, not strength.** The build itself reports size as a density property.
- **Preset `nest` has no runtime guard** and no text-level key binding.
- **"Luau" here means standalone Luau 0.739,** not Roblox's runtime; the Luraph sample corpus is also
  Luau-target and does not parse on Lua 5.4.
- **Frontend grammar gap:** Luau `if/elseif/else` expressions are accepted by the source container but
  refused by the VM route's parser (`Expected else, got elseif`).
- **No recovery percentage guarantee:** “80–90% cracked” is not a measurable claim without a defined
  reverse-engineering benchmark, corpus, threat model and independent analysis — none of which exists.

See `CHANGES-V5.9.0.md` and `LIMITATIONS-V5.9.0.md` for this release, and `CHANGES-V5.8.0.md` /
`LIMITATIONS-V5.8.0.md` for the previous cycle.

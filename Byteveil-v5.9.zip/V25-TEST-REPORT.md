# ByteCode v2.5.1 validation report

Validated before packaging:

- `node --check` on every project JavaScript file outside `node_modules`: PASS
- `package.json` JSON parsing: PASS (no root `package-lock.json` is shipped)
- ByteCode v2.5.1 8-way preset/mode matrix: PASS
- Register + Stack generation: PASS
- opcode remapping and nested chunk mapping: PASS through engine validator
- payload transform round-trip: PASS
- JS-side Register VM smoke runtime: PASS (`print(2+3)` -> `5`)
- generated Luau lexical/string/delimiter sanity: PASS
- macro scan in `src`: PASS (no MacroExpand/macros implementation)
- secret scan: PASS after removing real `.env` files from the package
- archive extraction + repeat test: PASS

## Native runtime limitation

The environment used for this build does not contain a `luau`, `lua`, or `luajit` executable. Therefore the package does **not** claim that generated files were executed by a real Luau/Roblox runtime. The included JS smoke runtime and generated-source sanity checker are preflight checks; final native compatibility still needs a Luau/Roblox execution test.

- top-level generated `...` invocation regression: PASS
- generated `endend` regression scan: PASS
- native runtime installer/runner integration: PASS (installer included; native binaries must be installed on the target machine)

# ByteVeil v4.6.1 — Implementation Notes

## Real modules added/updated

- `src/obfuscation/vm_architecture_v46.js` — six real VM-B routing families.
- `src/obfuscation/vm_personality.js` — build-specific architecture/personality planner.
- `src/obfuscation/representation_morph.js` — reversible runtime representation transforms.
- `src/backend/bytecode_serializer.js` — v4.6 represented region transport.
- `src/compiler/stack/vm_generator.js` — v4.6 architecture-diverse strict runtime.
- `src/protection/nested_obfuscation.js` — v4.6 fast nested codec path while preserving the existing layer-count policy.
- `src/backend/source_engine_v46_compat.js` — standalone v4.6 compatibility source engine; it no longer imports pre-v4 source protection code.

## Legacy handling

Historical pre-v4 engines remain in the tree so archived imports and historical fixtures are not silently deleted. They are not the active source fallback architecture anymore. The current compatibility path is independently implemented under `source_engine_v46_compat.js`.

## Verified properties

- Six nested codecs: runtime PASS.
- Strength 10000: 9 nested layers.
- Real representation encode/decode roundtrip: PASS.
- Stack/register semantic smoke tests: PASS.
- 20 independent V46 build artifacts: unique and high structural diversity.
- No emitted `coreDispatch` in the V46 strict branch.
- No universal `G.resolve/G.fetch/G.peek/byteAt` resolver artifacts in the V46 test fixture.
- Nested tamper probe: execution rejected.
- Hook probe: execution rejected.
- High-strength Lua 5.4 runtime: PASS.

## Known boundary

The semantic operation bodies remain static Lua closures in the payload. v4.6 materially changes the **routing/topology/materialization architecture** around those bodies, but this is not equivalent to a cryptographic guarantee that no semantic body can ever be recovered from a client-controlled runtime.

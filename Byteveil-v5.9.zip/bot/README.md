# ByteVeil Discord Bot — v5.8.0 Slash Commands

The bot registers `/help`, `/rule`, and `/obf`. `/obf` routes Lua/Luau source through the ByteVeil v5.8.0 pipeline and requires an explicit Stack/Register method.

## Run

Configure `bot/.env` using `bot/.env.example`, then run from the repository root:

```sh
npm start
```

The command deployment step runs before bot login and synchronizes the current ByteVeil command definitions. Use `npm run bot:reset-commands` to remove registered ByteVeil slash commands while preserving unrelated commands.

Only submit code and files you have permission to process. Do not upload real credentials, access tokens, or unrelated secrets.

The bot exposes the `l1`, `l2`, `nest`, `df`, and `lz` presets. The Nest preset continues to depend on dynamic loading and may not work in all Luau hosts. See the root `LIMITATIONS-V5.8.0.md` for engine limitations.

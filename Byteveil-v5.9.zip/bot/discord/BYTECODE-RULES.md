# ByteVeil Community Rules

1. Be respectful. No harassment, spam, raids, or unnecessary drama.
2. Only share code and files you are allowed to use.
3. Never post passwords, bot tokens, cookies, API keys, or other secrets.
4. Use `/help`, `/rule`, and `/obf` in the appropriate bot channel.
5. Bug reports should include the preset, source language, runtime/compiler, and exact error text.
6. Do not use the bot to steal credentials, distribute malware, deploy destructive payloads, or compromise systems without authorization.

## Nội quy

1. Tôn trọng mọi người; không quấy rối, spam, raid hoặc gây drama không cần thiết.
2. Chỉ chia sẻ mã và tệp mà bạn có quyền sử dụng.
3. Không đăng mật khẩu, token bot, cookie, API key hoặc dữ liệu bí mật.
4. Dùng `/help`, `/rule` và `/obf` trong kênh bot phù hợp.
5. Khi báo lỗi, hãy ghi rõ preset, ngôn ngữ source, runtime/compiler và nội dung lỗi chính xác.
6. Không dùng bot để đánh cắp thông tin, phát tán malware, phá hoại hoặc xâm nhập trái phép.

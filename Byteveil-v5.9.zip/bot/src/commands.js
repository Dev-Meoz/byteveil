"use strict";

const { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { validateFileName, runEngine } = require("./obfuscate");
const { config } = require("./runtime");
const { detect } = require("../../src/detect");
const { byteCodeRulesEmbed } = require("./discord_rules");
const path = require("path");
const dns = require("node:dns/promises");
const net = require("node:net");
const http = require("node:http");
const https = require("node:https");

const VERSION = "5.9.0";
const BRAND = "BYTEVEIL  /  LUA + LUAU";
const FOOTER = `ByteVeil v${VERSION} • Slash Commands`;
const COLORS = Object.freeze({ blue: 0x63A8FF, violet: 0x9A7BFF, green: 0x35C98A, amber: 0xF3B955, red: 0xF16D7A, slate: 0x8A96A8 });
const PRESETS = ["l1", "l2", "nest", "df", "lz"];
const PRESET_CHOICES = PRESETS.map((name) => ({ name, value: name }));
const METHOD_CHOICES = [{ name: "Stack VM", value: "stack" }, { name: "Register VM", value: "register" }];
const INPUT_CHOICES = [{ name: "code", value: "code" }, { name: "file", value: "file" }, { name: "url", value: "url" }];
const BYTEVEIL_COMMAND_NAMES = new Set(["help", "rule", "obf"]);

const commands = [
  new SlashCommandBuilder().setName("help").setDescription("Show ByteVeil command help"),
  new SlashCommandBuilder().setName("rule").setDescription("Show ByteVeil rules in English and Vietnamese"),
  new SlashCommandBuilder()
    .setName("obf")
    .setDescription("Obfuscate Lua/Luau source with the ByteVeil engine")
    .addStringOption((o) => o.setName("presets").setDescription("Obfuscation preset").setRequired(true).addChoices(...PRESET_CHOICES))
    .addStringOption((o) => o.setName("method").setDescription("VM execution method; choose explicitly for this build").setRequired(true).addChoices(...METHOD_CHOICES))
    .addStringOption((o) => o.setName("attach").setDescription("How to provide the source").setRequired(true).addChoices(...INPUT_CHOICES))
    .addStringOption((o) => o.setName("input").setDescription("Source code or an HTTP/HTTPS URL").setRequired(false))
    .addAttachmentOption((o) => o.setName("upload").setDescription("Lua/Luau/TXT source file; used with attach:file").setRequired(false)),
].map((command) => command.toJSON());

function baseEmbed(color = COLORS.blue) {
  return new EmbedBuilder().setColor(color).setAuthor({ name: BRAND }).setFooter({ text: FOOTER }).setTimestamp();
}
function clip(value, max = 900) {
  const text = String(value ?? "");
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function helpEmbed() {
  return baseEmbed(COLORS.violet).setTitle("COMMAND CENTER")
    .setDescription("ByteVeil Lua/Luau protection engine. Choose a slash command below; generated source is returned as a downloadable file.")
    .addFields(
      { name: "GENERAL", value: "`/help` — Open this panel\n`/rule` — Read usage and community rules", inline: false },
      { name: "OBFUSCATION", value: "`/obf presets:l1 method:register attach:code`\n`/obf presets:l2 method:stack attach:file upload:<file>`\n`/obf presets:nest method:stack attach:code`\n`/obf presets:df method:register attach:url input:<url>`\n`/obf presets:lz method:stack attach:code`", inline: true },
      { name: "INPUT MODES", value: "**Stack/Register** · Select the VM method in this same `/obf` command\n**code** · Paste source into `input`\n**file** · Attach one `.lua`, `.luau`, or `.txt` file\n**url** · Fetch source from an HTTP/HTTPS URL", inline: true },
      { name: "EXAMPLE", value: "`/obf presets:l1 method:register attach:code input:print('Hello')`", inline: false },
      { name: "LIMITS", value: `Up to ${(config.maxInputBytes / 1024 / 1024).toFixed(0)} MB per input · one source per request`, inline: false },
    );
}
function usageEmbed(message = "") {
  return baseEmbed(COLORS.amber).setTitle("OBFUSCATION · USAGE")
    .setDescription(`${message ? `${message}\n\n` : ""}Choose one preset, one VM method, and exactly one input mode.`)
    .addFields(
      { name: "INLINE SOURCE", value: "`/obf presets:l1 method:register attach:code input:print('Hello')`", inline: false },
      { name: "FILE ATTACHMENT", value: "Choose `attach:file` and provide `upload` with one `.lua`, `.luau`, or `.txt` file.", inline: false },
      { name: "URL INPUT", value: "Choose `attach:url` and paste an HTTP/HTTPS source URL into `input`.", inline: false },
    );
}
function errorEmbed(title, message, hint = "") {
  const embed = baseEmbed(COLORS.red).setTitle(`REQUEST FAILED  /  ${clip(title, 160)}`).setDescription(clip(message || "An unexpected error occurred.", 2500));
  if (hint) embed.addFields({ name: "NEXT STEP", value: clip(hint, 900), inline: false });
  return embed;
}
function processingEmbed(preset, mode, method) {
  return baseEmbed(COLORS.blue).setTitle("ENGINE RUNNING")
    .setDescription("Input accepted. ByteVeil is validating source and running the selected obfuscation pipeline.")
    .addFields({ name: "PRESET", value: `\`${preset}\``, inline: true }, { name: "VM METHOD", value: `\`${method}\``, inline: true }, { name: "INPUT MODE", value: `\`${mode}\``, inline: true }, { name: "STATUS", value: "`PROCESSING`", inline: true });
}
function successEmbed({ preset, method, inputName, mode, detection, result, outputBytes }) {
  const target = String(result.target || detection.target || "lua").toUpperCase();
  const syntaxOk = result.validation?.generated?.ok;
  return baseEmbed(COLORS.green).setTitle("BUILD COMPLETE")
    .setDescription("The source passed through the ByteVeil pipeline. Your generated file is attached to this response.")
    .addFields(
      { name: "PRESET", value: `\`${preset}\``, inline: true },
      { name: "VM METHOD", value: `\`${method}\``, inline: true },
      { name: "TARGET", value: `\`${target}\``, inline: true },
      { name: "DETECTION", value: `${Math.round((detection.confidence || 0) * 100)}% confidence`, inline: true },
      { name: "ENGINE", value: clip(result.stats?.engine || "ByteVeil", 180), inline: true },
      { name: "RUNTIME", value: clip(result.runtime || "Not reported", 180), inline: true },
      { name: "OUTPUT SIZE", value: `${Number(outputBytes).toLocaleString()} bytes`, inline: true },
      { name: "SYNTAX CHECK", value: syntaxOk === true ? "✅ PASS" : syntaxOk === false ? "⚠️ CHECK" : "ℹ️ Not reported", inline: true },
      { name: "INPUT", value: `\`${clip(inputName, 160)}\` · ${mode}`, inline: false },
    );
}

function stripCodeFence(source) {
  const text = String(source || "").trim();
  const match = /^```(?:lua|luau|txt|text)?\s*\r?\n([\s\S]*?)\r?\n```$/i.exec(text);
  return match ? match[1] : text;
}
function safeOutputBase(name) {
  const raw = path.basename(String(name || "input")).replace(/\.(lua|luau|txt)$/i, "");
  return raw.replace(/[^\p{L}\p{N}._-]+/gu, "_").slice(0, 64) || "output";
}
function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
}

function isNonPublicAddress(address) {
  const normalized = String(address || "").toLowerCase().split("%")[0];
  const family = net.isIP(normalized);
  if (family === 4) {
    const octets = normalized.split(".").map(Number);
    const [a, b, c] = octets;
    return a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && (b === 168 || (b === 0 && c === 0) || (b === 0 && c === 2) || (b === 88 && c === 99))) ||
      (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) ||
      (a === 203 && b === 0 && c === 113) || (a === 255 && b === 255 && c === 255);
  }
  if (family === 6) {
    if (normalized === "::" || normalized === "::1" || normalized.startsWith("fc") || normalized.startsWith("fd") ||
      /^fe[89ab]/.test(normalized) || normalized.startsWith("ff") || normalized.startsWith("2001:db8:") ||
      normalized.startsWith("2001:0:") || normalized.startsWith("2001:2:") || normalized.startsWith("2001:10:") ||
      normalized.startsWith("2001:20:") || normalized.startsWith("2002:")) return true;
    if (normalized.startsWith("::ffff:")) {
      const mapped = normalized.slice(7);
      if (net.isIP(mapped) === 4) return isNonPublicAddress(mapped);
      const mappedHex = /^([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i.exec(mapped);
      if (mappedHex) {
        const high = Number.parseInt(mappedHex[1], 16);
        const low = Number.parseInt(mappedHex[2], 16);
        const ipv4 = `${high >>> 8}.${high & 255}.${low >>> 8}.${low & 255}`;
        return isNonPublicAddress(ipv4);
      }
      return true;
    }
    return false;
  }
  return true;
}

async function resolvePublicHttpUrl(parsed, lookup = dns.lookup) {
  const hostname = normalizeHost(parsed.hostname);
  if (!hostname || hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local") || hostname.endsWith(".internal") || hostname.endsWith(".test")) {
    throw new Error("URL phải trỏ tới host công khai; localhost/tên miền nội bộ không được phép.");
  }
  let addresses;
  if (net.isIP(hostname)) {
    if (isNonPublicAddress(hostname)) throw new Error("URL tới IP nội bộ hoặc IP dành riêng bị từ chối.");
    addresses = [{ address: hostname, family: net.isIP(hostname) }];
  } else {
    try { addresses = await lookup(hostname, { all: true, verbatim: true }); }
    catch { throw new Error("Không phân giải được host URL."); }
  }
  if (!addresses?.length || addresses.some((item) => isNonPublicAddress(item.address))) {
    throw new Error("URL phân giải tới IP nội bộ hoặc IP dành riêng; đã từ chối tải source.");
  }
  // Return the exact addresses used by the request's lookup callback. Pinning
  // this DNS result closes the validation/fetch second-resolution gap.
  return addresses;
}

async function validatePublicHttpUrl(parsed) {
  await resolvePublicHttpUrl(parsed);
  return true;
}

function requestRawSource(parsed, addresses, requestImpl) {
  return new Promise((resolve, reject) => {
    const maxBytes = config.maxInputBytes;
    let settled = false;
    let total = 0;
    const chunks = [];
    const fail = (error) => {
      if (settled) return;
      settled = true;
      reject(error instanceof Error ? error : new Error(String(error)));
    };
    const hostname = normalizeHost(parsed.hostname);
    const lookup = (_requestedHost, options, callback) => {
      const requestedFamily = Number(options?.family || 0);
      const compatible = addresses.filter((item) => !requestedFamily || (item.family || net.isIP(item.address)) === requestedFamily);
      if (!compatible.length) return callback(new Error("No validated public IP address matches the requested address family."));
      if (options && options.all) {
        return callback(null, compatible.map((item) => ({ address: item.address, family: item.family || net.isIP(item.address) })));
      }
      const chosen = compatible[0];
      return callback(null, chosen.address, chosen.family || net.isIP(chosen.address));
    };
    let request;
    try {
      const transport = parsed.protocol === "https:" ? https : http;
      request = requestImpl || transport.request.bind(transport);
      const req = request({
        protocol: parsed.protocol,
        hostname,
        port: parsed.port || undefined,
        method: "GET",
        path: `${parsed.pathname || "/"}${parsed.search || ""}`,
        headers: { accept: "text/plain, application/octet-stream, */*", "user-agent": "ByteVeil-Source-Resolver/5.2" },
        lookup,
        servername: net.isIP(hostname) ? undefined : hostname,
        timeout: 15000
      }, (response) => {
        const status = Number(response.statusCode || 0);
        if (status < 200 || status >= 300) {
          response.resume?.();
          fail(new Error(`Không tải được URL (HTTP ${status || "unknown"}); redirect hoặc response lỗi bị từ chối.`));
          return;
        }
        const declaredLength = Number(response.headers?.["content-length"]);
        if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
          response.destroy?.();
          fail(new Error("Source tải từ URL vượt giới hạn đầu vào."));
          return;
        }
        response.on("data", (chunk) => {
          if (settled) return;
          const data = Buffer.from(chunk);
          total += data.length;
          if (total > maxBytes) {
            response.destroy?.();
            req.destroy?.();
            fail(new Error("Source tải từ URL vượt giới hạn đầu vào."));
            return;
          }
          chunks.push(data);
        });
        response.on("end", () => {
          if (settled) return;
          settled = true;
          resolve(Buffer.concat(chunks, total));
        });
        response.on("error", fail);
      });
      req.setTimeout?.(15000, () => req.destroy(new Error("URL request timed out.")));
      req.on("error", fail);
      req.end();
    } catch (error) {
      fail(error);
    }
  });
}

async function readResponseLimited(response, label) {
  const limit = config.maxInputBytes;
  const length = Number(response.headers?.get?.("content-length"));
  if (Number.isFinite(length) && length > limit) throw new Error(`${label} vượt giới hạn đầu vào.`);
  if (!response.body || typeof response.body.getReader !== "function") {
    const data = Buffer.from(await response.arrayBuffer());
    if (data.length > limit) throw new Error(`${label} vượt giới hạn đầu vào.`);
    return data;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = Buffer.from(value);
      total += chunk.length;
      if (total > limit) {
        await reader.cancel().catch(() => {});
        throw new Error(`${label} vượt giới hạn đầu vào.`);
      }
      chunks.push(chunk);
    }
  } finally {
    reader.releaseLock?.();
  }
  return Buffer.concat(chunks, total);
}

async function downloadAttachment(file) {
  validateFileName(file.name);
  if (Number(file.size || 0) > config.maxInputBytes) throw new Error(`File vượt giới hạn ${(config.maxInputBytes / 1024 / 1024).toFixed(0)} MB.`);
  const response = await fetch(file.url, { signal: AbortSignal.timeout(15000), redirect: "error" });
  if (!response.ok) throw new Error(`Không tải được file đính kèm (HTTP ${response.status}).`);
  const data = await readResponseLimited(response, "File đính kèm");
  return { source: data.toString("utf8"), name: file.name, mode: "file" };
}
async function downloadUrl(rawUrl) {
  let parsed;
  try { parsed = new URL(String(rawUrl || "").trim()); } catch { throw new Error("URL không hợp lệ."); }
  if (!/^https?:$/.test(parsed.protocol)) throw new Error("Chỉ hỗ trợ URL HTTP/HTTPS.");
  if (parsed.username || parsed.password) throw new Error("URL không được chứa thông tin đăng nhập.");
  const addresses = await resolvePublicHttpUrl(parsed);
  // Native http/https requests are pinned to the already-validated DNS set,
  // redirects are never followed, and response bytes are capped while streamed.
  const data = await requestRawSource(parsed, addresses);
  let source;
  try {
    source = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(data);
  } catch {
    throw new Error("Source URL không phải UTF-8 hợp lệ.");
  }
  return { source, name: path.basename(parsed.pathname || "") || "input.lua", mode: "url" };
}
function validateInputMode(mode, input, upload) {
  const hasInput = typeof input === "string" && input.length > 0;
  if (!INPUT_CHOICES.some((choice) => choice.value === mode)) throw new Error("Input mode không hợp lệ. Chọn code, file hoặc url.");
  if (mode === "code" && (!hasInput || upload)) throw new Error("attach:code yêu cầu input có source và không dùng upload.");
  if (mode === "url" && (!hasInput || upload)) throw new Error("attach:url yêu cầu input có URL và không dùng upload.");
  if (mode === "file" && (!upload || hasInput)) throw new Error("attach:file yêu cầu upload và không dùng input.");
}
async function resolveInput(mode, input, upload) {
  validateInputMode(mode, input, upload);
  if (mode === "file") return downloadAttachment(upload);
  if (mode === "url") return downloadUrl(input);
  const source = stripCodeFence(input);
  if (/^https?:\/\//i.test(source.trim())) {
    throw new Error("Input trông giống URL, không phải source code. Chọn attach:url rồi đặt URL vào input để tải raw source.");
  }
  if (!source.trim()) throw new Error("Source rỗng.");
  if (Buffer.byteLength(source, "utf8") > config.maxInputBytes) throw new Error("Source vượt giới hạn đầu vào.");
  return { source, name: "input.txt", mode: "code" };
}
async function executeObf(interaction) {
  const preset = interaction.options.getString("presets", true)?.toLowerCase();
  const method = interaction.options.getString("method", true)?.toLowerCase();
  const mode = interaction.options.getString("attach", true)?.toLowerCase();
  const input = interaction.options.getString("input");
  const upload = interaction.options.getAttachment("upload");
  if (!PRESETS.includes(preset)) throw new Error("Preset không hợp lệ. Chọn l1, l2, nest, df hoặc lz.");
  if (!METHOD_CHOICES.some((choice) => choice.value === method)) throw new Error("VM method không hợp lệ. Chọn stack hoặc register.");
  const sourceInput = await resolveInput(mode, input, upload);
  if (!sourceInput.source.trim()) throw new Error("Source rỗng.");

  const detection = detect(sourceInput.source, sourceInput.name, { sourceFirst: true });
  const result = runEngine(sourceInput.source, preset, "auto", sourceInput.name, { fastPath: false, mode: method });
  if (!result || typeof result.output !== "string" || !result.output.length) throw new Error("Engine không tạo được output.");
  if (result.vmMeta?.mode && result.vmMeta.mode !== method) throw new Error(`Engine đã trả method ${result.vmMeta.mode} nhưng yêu cầu là ${method}; từ chối gửi output không đúng method.`);

  const ext = String(result.target || detection.target || "lua").toLowerCase() === "luau" ? ".luau" : ".lua";
  const outputName = `${safeOutputBase(sourceInput.name)}_${preset}_${method}_obfuscated${ext}`;
  const buffer = Buffer.from(result.output, "utf8");
  await interaction.editReply({ embeds: [successEmbed({ preset, method, inputName: sourceInput.name, mode: sourceInput.mode, detection, result, outputBytes: buffer.length })], files: [new AttachmentBuilder(buffer, { name: outputName })], content: null });
}
async function execute(interaction) {
  if (!interaction || typeof interaction.isChatInputCommand !== "function" || !interaction.isChatInputCommand()) return;
  const name = interaction.commandName;
  try {
    if (name === "help") {
      await interaction.reply({ embeds: [helpEmbed()], ephemeral: true });
      return;
    }
    if (name === "rule") {
      await interaction.reply({ embeds: [byteCodeRulesEmbed()], ephemeral: true });
      return;
    }
    if (name !== "obf") return;
    const preset = interaction.options.getString("presets", true);
    const mode = interaction.options.getString("attach", true);
    const method = interaction.options.getString("method", true);
    await interaction.deferReply();
    await interaction.editReply({ embeds: [processingEmbed(preset, mode, method)], content: null });
    await executeObf(interaction);
  } catch (error) {
    const message = clip(error?.message || String(error), 2000);
    const hint = name === "obf" ? "Use /help for supported presets and input modes. The bot only reports success when the engine returns output." : "Try again or contact a bot administrator.";
    const embed = errorEmbed(name.toUpperCase(), message, hint);
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ embeds: [embed], content: null, files: [] }).catch(() => {});
    } else {
      await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
    }
  }
}

module.exports = { commands, execute, executeObf, helpEmbed, usageEmbed, errorEmbed, successEmbed, processingEmbed, PRESETS, METHOD_CHOICES, INPUT_CHOICES, BYTEVEIL_COMMAND_NAMES, validateInputMode, resolveInput, stripCodeFence, isNonPublicAddress, validatePublicHttpUrl, resolvePublicHttpUrl, requestRawSource, readResponseLimited };

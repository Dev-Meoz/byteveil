"use strict";

const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
const botEnv = path.join(__dirname, "..", ".env");
const rootEnv = path.resolve(__dirname, "..", "..", ".env");
// Prefer explicit bot/.env values; root .env is a convenient fallback for local development.
if (fs.existsSync(botEnv)) dotenv.config({ path: botEnv });
if (fs.existsSync(rootEnv)) dotenv.config({ path: rootEnv });

function required(name) {
  const value = process.env[name];
  if (!value || /^replace-with-/i.test(value)) throw new Error(`Missing or placeholder ${name}. Set it in ${botEnv}.`);
  return value;
}
const maxInputBytes = Number(process.env.MAX_INPUT_BYTES || 2097152);
if (!Number.isSafeInteger(maxInputBytes) || maxInputBytes < 1024) throw new Error("MAX_INPUT_BYTES must be an integer of at least 1024.");

module.exports = {
  token: required("DISCORD_TOKEN"),
  clientId: required("DISCORD_CLIENT_ID"),
  guildId: process.env.DISCORD_GUILD_ID || "",
  // Optional comma-separated guild IDs where older ByteVeil slash commands may still exist.
  legacyGuildIds: [...new Set(String(process.env.DISCORD_LEGACY_GUILD_IDS || "").split(",").map((id) => id.trim()).filter(Boolean))],
  apiSecret: process.env.API_SECRET || "",
  enginePreset: process.env.ENGINE_PRESET || "l1",
  maxInputBytes,
};

"use strict";

const { REST, Routes } = require("discord.js");
const { config } = require("./runtime");
const { commands, BYTEVEIL_COMMAND_NAMES } = require("./commands");

const COMMAND_PAYLOAD_FIELDS = [
  "type", "name", "name_localizations", "description", "description_localizations",
  "options", "default_member_permissions", "dm_permission", "default_permission",
  "nsfw", "contexts", "integration_types",
];

function cleanCommand(command) {
  const clean = {};
  for (const field of COMMAND_PAYLOAD_FIELDS) {
    if (command && command[field] !== undefined) clean[field] = command[field];
  }
  return clean;
}

function getScopes() {
  const globalIsTarget = !config.guildId;
  const scopes = [{
    name: "global",
    route: Routes.applicationCommands(config.clientId),
    target: globalIsTarget,
  }];

  if (config.guildId) {
    scopes.push({
      name: `guild ${config.guildId}`,
      route: Routes.applicationGuildCommands(config.clientId, config.guildId),
      target: true,
    });
  }

  const seenGuildIds = new Set(config.guildId ? [config.guildId] : []);
  for (const guildId of config.legacyGuildIds || []) {
    if (seenGuildIds.has(guildId)) continue;
    seenGuildIds.add(guildId);
    scopes.push({
      name: `legacy guild ${guildId}`,
      route: Routes.applicationGuildCommands(config.clientId, guildId),
      target: false,
    });
  }
  return scopes;
}

function unrelatedCommands(existing) {
  return existing
    .filter((command) => !BYTEVEIL_COMMAND_NAMES.has(command.name))
    .map(cleanCommand);
}

function countByteVeilCommands(existing) {
  return existing.filter((command) => BYTEVEIL_COMMAND_NAMES.has(command.name)).length;
}

async function deployCommands({ resetOnly = false } = {}) {
  if (!config.clientId) throw new Error("Missing DISCORD_CLIENT_ID in bot/.env (required to deploy slash commands).");
  const rest = new REST({ version: "10" }).setToken(config.token);
  const scopes = getScopes();

  // Snapshot all known scopes first. If any read fails, do not mutate a partial set of scopes.
  const snapshots = [];
  for (const scope of scopes) {
    const response = await rest.get(scope.route);
    snapshots.push({ scope, existing: Array.isArray(response) ? response : [] });
  }

  if (resetOnly) {
    let removed = 0;
    for (const { scope, existing } of snapshots) {
      const oldCount = countByteVeilCommands(existing);
      if (oldCount) {
        await rest.put(scope.route, { body: unrelatedCommands(existing) });
      }
      removed += oldCount;
      console.log(`Reset ${scope.name}: removed ${oldCount} ByteVeil command(s); preserved ${existing.length - oldCount} unrelated command(s).`);
    }
    console.log(`ByteVeil reset-only complete: removed ${removed} command registration(s).`);
    return { resetOnly: true, removed };
  }

  // Bulk-overwrite the active scope once with the canonical definitions from commands.js.
  // This replaces stale option schemas atomically instead of deleting and recreating the
  // same command set in two writes, which can expose an empty/stale window to Discord clients.
  const targetSnapshot = snapshots.find(({ scope }) => scope.target);
  if (!targetSnapshot) throw new Error("No active Discord command deployment scope was configured.");

  const currentPayload = commands.map(cleanCommand);
  const targetKeep = unrelatedCommands(targetSnapshot.existing);
  await rest.put(targetSnapshot.scope.route, { body: [...targetKeep, ...currentPayload] });
  console.log(
    `Synchronized ${targetSnapshot.scope.name}: deployed ${commands.map((command) => `/${command.name}`).join(", ")}; ` +
    `replaced ${countByteVeilCommands(targetSnapshot.existing)} stale ByteVeil definition(s); preserved ${targetKeep.length} unrelated command(s).`
  );

  // Remove ByteVeil registrations from every other known scope to prevent global/guild
  // definitions from competing. The current target is deliberately not reset first.
  let removedElsewhere = 0;
  for (const { scope, existing } of snapshots) {
    if (scope.target) continue;
    const oldCount = countByteVeilCommands(existing);
    if (oldCount) {
      await rest.put(scope.route, { body: unrelatedCommands(existing) });
      removedElsewhere += oldCount;
    }
    console.log(`Cleanup ${scope.name}: removed ${oldCount} stale ByteVeil command(s); preserved ${existing.length - oldCount} unrelated command(s).`);
  }

  console.log(`Command sync complete. Removed ${removedElsewhere} stale registration(s) outside the active scope.`);
  return { resetOnly: false, target: targetSnapshot.scope.name, removedElsewhere };
}

if (require.main === module) {
  deployCommands({ resetOnly: process.argv.includes("--reset-only") }).catch((error) => {
    console.error("Slash command synchronization failed; bot startup must not continue:", error.stack || error);
    process.exitCode = 1;
  });
}

module.exports = { deployCommands, getScopes, cleanCommand, unrelatedCommands, countByteVeilCommands };

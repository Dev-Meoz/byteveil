"use strict";

const { EmbedBuilder } = require("discord.js");

function byteCodeRulesEmbed() {
  return new EmbedBuilder().setColor(0xF3B955)
    .setAuthor({ name: "BYTEVEIL  /  COMMUNITY RULES" })
    .setTitle("USAGE RULES  /  NỘI QUY")
    .setDescription("Keep ByteVeil channels focused on Lua/Luau protection, testing, bug reports, and project development.\nVui lòng giữ các kênh tập trung vào bảo vệ mã Lua/Luau, kiểm thử, báo lỗi và phát triển dự án.")
    .addFields(
      { name: "01  RESPECT · TÔN TRỌNG", value: "**EN** · No harassment, spam, raids, or unnecessary drama.\n**VI** · Không quấy rối, spam, raid hoặc gây drama.", inline: false },
      { name: "02  FILES · TỆP TIN", value: "**EN** · Only share code and files you are allowed to use. Never post passwords, tokens, cookies, API keys, or secrets.\n**VI** · Chỉ chia sẻ code/tệp bạn có quyền sử dụng. Không đăng mật khẩu, token, cookie, API key hoặc thông tin bí mật.", inline: false },
      { name: "03  COMMANDS · LỆNH", value: "`/help` · `/rule` · `/obf presets:l1 method:register` · `/obf presets:l2 method:stack` · `/obf presets:nest method:stack` · `/obf presets:df method:register` · `/obf presets:lz method:stack`\nUse commands in an appropriate bot channel. / Dùng lệnh tại kênh bot phù hợp.", inline: false },
      { name: "04  BUG REPORTS · BÁO LỖI", value: "**EN** · Include preset, input language, runtime/compiler, and the exact error.\n**VI** · Ghi rõ preset, ngôn ngữ đầu vào, runtime/compiler và lỗi chính xác.", inline: false },
      { name: "05  SAFETY · AN TOÀN", value: "**EN** · Do not use the bot for credential theft, malware, destructive payloads, or unauthorized compromise.\n**VI** · Không dùng bot để đánh cắp thông tin, phát tán malware, phá hoại hoặc xâm nhập trái phép.", inline: false },
    )
    .setFooter({ text: "ByteVeil v5.9.0 • Lua + Luau • Slash Commands" })
    .setTimestamp();
}
module.exports = { byteCodeRulesEmbed };

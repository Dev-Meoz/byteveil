"use strict";

const { Client, GatewayIntentBits, Events } = require("discord.js");
const { config } = require("./runtime");
const { execute } = require("./commands");

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, (readyClient) => {
  console.log(`ByteVeil v5.9.0 online: ${readyClient.user.tag}`);
  console.log("Slash commands: /help | /rule | /obf");
});
client.on(Events.InteractionCreate, async (interaction) => {
  try { await execute(interaction); }
  catch (error) { console.error("Interaction error:", error.stack || error); }
});
client.on(Events.Error, (error) => console.error("Discord client error:", error.stack || error));
client.login(config.token).catch((error) => {
  console.error("Discord login failed:", error.message);
  process.exit(1);
});

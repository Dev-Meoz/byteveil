"use strict";

const { obfuscate } = require("../../src");
const { detect } = require("../../src/detect");

const ALLOWED = new Set([".luau", ".lua", ".txt"]);

function extension(name = "") {
  const i = String(name).lastIndexOf(".");
  return i >= 0 ? String(name).slice(i).toLowerCase() : "";
}

function detectSource(source, filename = "") {
  return detect(source, filename);
}

function runEngine(source, preset, target = "auto", filename = "", extra = {}) {
  if (!source.trim()) throw new Error("Code rỗng.");
  // Slash commands preserve the selected preset and explicitly disable fast-path
  // shortcuts when the caller requests the full engine pipeline.
  const options = { preset, target, filename };
  if (extra.mode !== undefined) {
    if (extra.mode !== "stack" && extra.mode !== "register") throw new Error("VM method must be stack or register.");
    options.mode = extra.mode;
  }
  if (extra.seed !== undefined) options.seed = extra.seed;
  if (extra.fastPath !== undefined) options.fastPath = extra.fastPath;
  return obfuscate(source, options);
}

function validateFileName(name) {
  const ext = extension(name);
  if (!ALLOWED.has(ext)) throw new Error("Chỉ nhận file .lua, .luau hoặc .txt.");
}

module.exports = { ALLOWED, extension, validateFileName, runEngine, detectSource, detectRobloxSource: detectSource };

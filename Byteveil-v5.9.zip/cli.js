"use strict";

const { obfuscateFile } = require("./src");

const [, , input, outputArg, modeArg = "register", targetArg = "auto"] = process.argv;

if (!input) {
  console.error("Usage: node cli.js input.lua|input.luau [output.lua|output.luau] [stack|register] [auto|lua|luau]");
  process.exit(1);
}

const mode = modeArg === "stack" ? "stack" : "register";

try {
  const result = obfuscateFile(input, outputArg, {
    mode,
    target: targetArg,
    preset: "default"
  });
  console.log(`OK ${result.target}/${result.runtime}: ${result.stats.bytes} bytes -> ${result.outputFile}`);
  if (result.sizeBudget) {
    const sizeKB = (result.sizeBudget.outputBytes / 1000).toFixed(1);
    const sourceKB = (result.sizeBudget.sourceBytes / 1000).toFixed(1);
    console.log(`Size budget: ${sizeKB} KB output / ${sourceKB} KB source; target 375–475 KB (${result.sizeBudget.status})`);
    const compression = result.vmMeta?.nestedCompression;
    if (compression?.enabled) {
      console.log(`Nested payload compression: ${compression.compressedLayers}/${compression.attemptedLayers} layers compressed; ${compression.bytesSaved} bytes saved before layer encoding; ${compression.longOffsetReferences || 0} long-distance references`);
    }
    if (result.sizeBudget.overMaximum) {
      console.warn(`WARNING: ${result.sizeBudget.recommendation}`);
      console.warn(`Likely contributors to inspect: ${result.sizeBudget.likelyContributors.join(", ") || "not isolated"}`);
    }
  }
} catch (error) {
  console.error(error.stack || error);
  process.exit(1);
}

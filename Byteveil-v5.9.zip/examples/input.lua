local x = 2
local y = 3
local function add(a, b)
  return a + b
end
print(add(x, y))

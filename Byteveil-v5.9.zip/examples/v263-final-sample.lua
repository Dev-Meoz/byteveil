local function calculate(a, b)
    local total = a + b
    if total > 10 then
        return total * 2
    end
    return total
end

local result = calculate(7, 6)
print("ByteCode v2.6.3:", result)

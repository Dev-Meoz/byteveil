local function greet(name)
    return "hello " .. name
end

print(greet("ByteCode v2.6.3"))

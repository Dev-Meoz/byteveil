local function add(a,b)return a+b end
local function score(n)local s=0 for i=1,n do s=s+i end return s end
local t={name="ByteCode",value=add(7,8)}
print(t.name,t.value,score(5))
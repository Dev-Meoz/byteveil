local __bc_payload_check=function(D)local H=17;for I=1,#D do H=(H*65599+string.byte(D,I)+1)%2147483647 end;return H end
local __bc_band=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 and b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_bor=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 or b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_bxor=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_shl=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return(A*2^B)%4294967296 end
local __bc_shr=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return math.floor(A/2^B) end
local __bc_unpack=table.unpack or unpack
local _3sv95k={}
local _1v8dodk=function(B,K,Q,L)local O={};local S=Q%4294967296;local function X(A,B)local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end;local function I(A,B)A=A%4294967296;B=B%4294967296;local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;for J=1,L do S=X(S,math.floor(S/32768));S=I(S,2246822519);S=X(S,(S*8192)%4294967296);S=I(S,3266489917);local M=(__bc_bxor(string.byte(K,((J-1)%#K)+1),__bc_bxor(S%256,(J*29+71)%256)))%256;local V=(string.byte(B,J)-((J*17)%256)+256)%256;O[J]=string.char(__bc_bxor(V,M)%256)end;return table.concat(O)end
local _y11lyg=function(E,V)return{pc=1,reg={},locals={},env=E,consts=V,code=nil,halt=false,ret={},varargs={},guard=0}end
local _4vum88=function(V)return type(V)=="table" end
local _10foqrj=function(V)return V~=nil end
local _1vzivau=function(V)return type(V)=="string" end
local _fd3iyd=function(V)return #V>0 end
local _1awxnho=function(V)return V and V.k~=nil end
local _7fnq1v=function(V)return V and V.c~=nil end
local _12zhul6=function(V)return V and V.p~=nil end
local _1le6k7t=function(V)return V and V.v~=nil end
local _hwwms0=function(V)return V and #V<=16777216 end
local _1dgqrbb=function(V)return V and V<=4294967296 end
local _9zgtvi=function(V)return V and V>=0 end
local _se5ji5=function(V)return V and #V>0 end
local _1nxzo1g=function(A,B)return A and B end
local _kgpqln=function(A,B)return A or B end
local _1g0jv4y=function(V)return type(V)~="function" or true end
local _1fyq6f5=function(V)return type(V)~="thread" or true end
local _chg8zc=function(V)return V~=false end
local _181adin=function(V)return V==nil or V==true or V==false or type(V)=="number" or type(V)=="string" or type(V)=="table" end
local function _15mn8pk(D)local P=1;local function U()local V=0;local M=1;while true do local B=string.byte(D,P);P=P+1;V=V+__bc_band(B,127)*M;if B<128 then return V end;M=M*128 end end;local function R(N)local V=D:sub(P,P+N-1);P=P+N;return V end;local function S()return R(U())end;local function N()local T=string.byte(D,P);P=P+1;if T==0 then local V=U();return(V%2==0)and(V/2)or-((V+1)/2)else return tonumber(S()) end end;local function C()local K={};local KC=U();for I=1,KC do local T=string.byte(D,P);P=P+1;if T==83 then K[I]=S()elseif T==78 then K[I]=N()elseif T==84 then K[I]=true elseif T==70 then K[I]=false elseif T==90 then K[I]=nil elseif T==67 then K[I]=C()end end;local X={k=K};local PC=U();X.p={};for I=1,PC do X.p[I]=S()end;X.v=string.byte(D,P)==1;P=P+1;local IC=U();X.c={};for I=1,IC do local AC=U();local Q={};for J=1,AC do Q[J]=N()end;X.c[I]=Q end;return X end;return C()end
local function _1o5zh5n(S,I,...)S.halt=true;return true;end
local function _13ko84e(S,I,...)S.reg[I[2]]=S.consts[I[3]+1];end
local function _1uvidaj(S,I,...)S.reg[I[2]]=I[3];end
local function _fk4fof(S,I,...)S.reg[I[2]]=I[3]~=0;end
local function _gl4ytc(S,I,...)S.reg[I[2]]=nil;end
local function _1t2s9zb(S,I,...)S.reg[I[2]]=S.env[S.consts[I[3]+1]];end
local function _1sgout8(S,I,...)S.env[S.consts[I[2]+1]]=S.reg[I[3]];end
local function _1528hjc(S,I,...)local T=S;local N=S.consts[I[3]+1];while T do if T.localSet[N] then S.reg[I[2]]=T.locals[N];break end;T=T.parent end;if not T then S.reg[I[2]]=nil end;end
local function _hg4la3(S,I,...)local T=S;local N=S.consts[I[2]+1];while T and not T.localSet[N] do T=T.parent end;if not T then T=S;T.localSet[N]=true end;T.locals[N]=S.reg[I[3]];end
local function _1wd2mph(S,I,...)S.reg[I[2]]=S.reg[I[3]][S.reg[I[4]]];end
local function _1p6ei32(S,I,...)S.reg[I[2]][S.reg[I[3]]]=S.reg[I[4]];end
local function _1lnhotj(S,I,...)S.reg[I[2]]=S.reg[I[3]]+S.reg[I[4]];end
local function _67qo01(S,I,...)S.reg[I[2]]=S.reg[I[3]]-S.reg[I[4]];end
local function _17r2576(S,I,...)S.reg[I[2]]=S.reg[I[3]]*S.reg[I[4]];end
local function _dnnbi9(S,I,...)S.reg[I[2]]=S.reg[I[3]]/S.reg[I[4]];end
local function _7ctbty(S,I,...)S.reg[I[2]]=math.floor(S.reg[I[3]]/S.reg[I[4]]);end
local function _1e5o6k4(S,I,...)S.reg[I[2]]=S.reg[I[3]]%S.reg[I[4]];end
local function _ht69il(S,I,...)S.reg[I[2]]=S.reg[I[3]]^S.reg[I[4]];end
local function _2apqpr(S,I,...)S.reg[I[2]]=S.reg[I[3]]==S.reg[I[4]];end
local function _a9j7es(S,I,...)S.reg[I[2]]=S.reg[I[3]]~=S.reg[I[4]];end
local function _1m1ydmz(S,I,...)S.reg[I[2]]=S.reg[I[3]]<S.reg[I[4]];end
local function _1m3s2cs(S,I,...)S.reg[I[2]]=S.reg[I[3]]>S.reg[I[4]];end
local function _1eguctu(S,I,...)S.reg[I[2]]=S.reg[I[3]]<=S.reg[I[4]];end
local function _1b8doth(S,I,...)S.reg[I[2]]=S.reg[I[3]]>=S.reg[I[4]];end
local function _12tt1jv(S,I,...)S.reg[I[2]]=not S.reg[I[3]];end
local function _vj744a(S,I,...)S.reg[I[2]]=-S.reg[I[3]];end
local function _449kl9(S,I,...)S.reg[I[2]]=#S.reg[I[3]];end
local function _z4rzq6(S,I,...)S.reg[I[2]]=S.reg[I[3]]..S.reg[I[4]];end
local function _107714h(S,I,...)S.reg[I[2]]=S.reg[I[3]] and S.reg[I[4]];end
local function _1d7mmta(S,I,...)S.reg[I[2]]=S.reg[I[3]] or S.reg[I[4]];end
local function _1egz9o4(S,I,...)S.reg[I[2]]=__bc_band(S.reg[I[3]],S.reg[I[4]]);end
local function _tzywo5(S,I,...)S.reg[I[2]]=__bc_bor(S.reg[I[3]],S.reg[I[4]]);end
local function _wrntzz(S,I,...)S.reg[I[2]]=__bc_bxor(S.reg[I[3]],S.reg[I[4]]);end
local function _1gulhna(S,I,...)S.reg[I[2]]=__bc_shl(S.reg[I[3]],S.reg[I[4]]);end
local function _1k4vudg(S,I,...)S.reg[I[2]]=__bc_shr(S.reg[I[3]],S.reg[I[4]]);end
local function _dlicx9(S,I,...)S.pc=I[2]+1;end
local function _1130j9f(S,I,...)if not S.reg[I[2]] then S.pc=I[3]+1 end;end
local function _1lt56z0(S,I,...)local f=S.reg[I[3]];local a={};for q=1,I[4] do a[q]=S.reg[I[4+q]] end;local r={f(__bc_unpack(a,1,I[4]))};S.reg[I[2]]=r[1];end
local function _10yxbim(S,I,...)local r={};for q=2,#I do r[#r+1]=S.reg[I[q]] end;S.halt=true;S.ret=r;return true;end
local function _1stqj1q(S,I,...)S.reg[I[2]]=nil;end
local function _1fcj0w7(S,I,...)S.reg[I[2]]=S.reg[I[3]];end
local function _m6xi8z(S,I,...)S.reg[I[2]]={};end
local function _1rj00gp(S,I,...)local X=S.consts[I[3]+1];local P=S;S.reg[I[2]]=function(...)return _1nms1mg(X,P,...)end;end
local function _10ixpuq(S,I,...)S.reg[I[2]]=S.varargs or {};end
local function _e2jzj7(S,I,...)S.halt=true;return true;end
local function _1hj92pr(S,I,...)S.reg[I[2]]=S.reg[I[3]];end
local function _16s5ken(S,I,...)local i=S.reg[I[2]];local l=S.reg[I[3]];local st=S.reg[I[4]];S.reg[I[2]]=(st>=0 and i<=l)or(st<0 and i>=l);end
local function _1f4kai8(S,I,...)S.iter=S.reg[I[2]];end
local function _1nyz7rl(S,I,...)S.halt=true;return true;end
local function _ge3e7r(S,I,...)S.reg[I[2]][I[3]]=S.reg[I[4]];end
local function _wru26g(S,I,...)S.reg[I[2]]=S.reg[I[3]][I[4]];end
local _izkwpt=function(OP)return((OP*11+0)%51)+1 end
local _3sv95k={}
_3sv95k[35]=_1o5zh5n
_3sv95k[28]=_13ko84e
_3sv95k[27]=_1uvidaj
_3sv95k[38]=_fk4fof
_3sv95k[13]=_gl4ytc
_3sv95k[33]=_1t2s9zb
_3sv95k[49]=_1sgout8
_3sv95k[12]=_1528hjc
_3sv95k[20]=_hg4la3
_3sv95k[18]=_1wd2mph
_3sv95k[23]=_1p6ei32
_3sv95k[47]=_1lnhotj
_3sv95k[25]=_67qo01
_3sv95k[26]=_17r2576
_3sv95k[41]=_dnnbi9
_3sv95k[51]=_7ctbty
_3sv95k[36]=_1e5o6k4
_3sv95k[19]=_ht69il
_3sv95k[48]=_2apqpr
_3sv95k[15]=_a9j7es
_3sv95k[21]=_1m1ydmz
_3sv95k[37]=_1m3s2cs
_3sv95k[34]=_1eguctu
_3sv95k[9]=_1b8doth
_3sv95k[2]=_12tt1jv
_3sv95k[29]=_vj744a
_3sv95k[8]=_449kl9
_3sv95k[5]=_z4rzq6
_3sv95k[43]=_dlicx9
_3sv95k[6]=_1130j9f
_3sv95k[11]=_1lt56z0
_3sv95k[4]=_10yxbim
_3sv95k[44]=_1stqj1q
_3sv95k[40]=_1fcj0w7
_3sv95k[39]=_m6xi8z
_3sv95k[42]=_ge3e7r
_3sv95k[14]=_wru26g
_3sv95k[3]=_1rj00gp
_3sv95k[31]=_10ixpuq
_3sv95k[50]=_107714h
_3sv95k[7]=_1d7mmta
_3sv95k[10]=_1egz9o4
_3sv95k[16]=_tzywo5
_3sv95k[46]=_wrntzz
_3sv95k[30]=_1gulhna
_3sv95k[1]=_1k4vudg
_3sv95k[32]=_e2jzj7
_3sv95k[45]=_1hj92pr
_3sv95k[22]=_16s5ken
_3sv95k[17]=_1f4kai8
_3sv95k[24]=_1nyz7rl
local _1g16evc=function(S)local G=S.guard or 0;while not S.halt do local I=S.code[S.pc];if not I then S.halt=true;break end;local O=I[1];S.pc=S.pc+1;G=(G*1664525+O*101+S.pc+1013904223)%4294967296;S.guard=G;local H=_3sv95k[_izkwpt(O)];if not H then error("ByteCode VM error",0)end;local X=H(S,I);if X then break end end;return S end
local _1nms1mg=function(X,P,...)local E=setmetatable({},{__index=_G});local S=_y11lyg(E,X.k);S.parent=P;S.code=X.c;S.varargs={...};S.guard=2528090685;for Q=1,#(X.p or {}) do local N=X.p[Q];S.locals[N]=select(Q,...);S.localSet[N]=true end;_1g16evc(S);return __bc_unpack(S.ret or {},1,#(S.ret or {}))end
local _qtdc6p=(function(C,O)local R={};local U=table.unpack or unpack;for I=1,#O do local N=C[O[I]];R[#R+1]=string.char(U(N))end;return table.concat(R)end)({{42,47,252,39,134,171,105,124,156,51,123,180,159,42,247,199,104,131,205,12,233,148,91,66,133,231,190,73,31,35,67,239,41,82,2,137,243,101,201,73,138,120,98},{83,139,194,145,207,46,23},{196,82,204,7,242,46,58,125,192,30,61,212,25,169,63,17,105,123,121,89,207,210},{98,65,79,27,147,94,246,180,95,143,142,43,67,201,197,230,140,148,246,166,100,228,196,184,32,143,4,34,251,57,229,33,106,134,246,142,83,185,56,207,16,87,196,31,136},{192,252,32,112,81,217,7,186,156,30,34,235,157,71,244,163,138,23,253,157,124,20,28,64,36,219,240,134,103,241,162,31,180,81,170,184,138,86,250,94,155,71,119},{167,98,161,43,75,88,225,80,65,227,6,78,88,23,86,158,20,223,249,16,36},{93,206,239,197,251,19,86,52,106,151,140,83,186,80,125,143,153,192,48,243,25,210,133,235,119,33,192,84,112,105},{240,166,40,135,178,133,120,174,249,43,73,76,7,123,122,139,32,147,77,2,254,21,11,149},{209,228,171,248,214,87,68,114,209,170,42,160,27,95,173,57,140,0,27,181,139,61,56,73,64,9,133,96,91,177,219,150,31,227,153,119}},{2})
local _11p9bnz="\078\086\165\022\004\103\067\199\006\040\001\061\145\223\167\181\148\005\094\044"
local _19dma05=_1v8dodk(_qtdc6p,_11p9bnz,3235823763,7)
if __bc_payload_check(_19dma05)~=577803753 then error("ByteCode payload integrity failed",0) end
local _e8dn7a=_15mn8pk(_19dma05)
if not (_4vum88(_e8dn7a) and _1awxnho(_e8dn7a) and _7fnq1v(_e8dn7a) and _12zhul6(_e8dn7a)) then error("ByteCode VM validation failed",0) end
local _19uj2ed={_1nms1mg(_e8dn7a,nil) }
return __bc_unpack(_19uj2ed,1,#_19uj2ed)
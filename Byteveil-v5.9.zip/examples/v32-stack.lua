local __bc_payload_check=function(D)local H=17;for I=1,#D do H=(H*65599+string.byte(D,I)+1)%2147483647 end;return H end
local __bc_band=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 and b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_bor=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 or b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_bxor=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end
local __bc_shl=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return(A*2^B)%4294967296 end
local __bc_shr=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return math.floor(A/2^B) end
local __bc_unpack=table.unpack or unpack
local _2hylha={}
local _5rzg3a=function(B,K,Q,L)local O={};local S=Q%4294967296;local function X(A,B)local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end;local function I(A,B)A=A%4294967296;B=B%4294967296;local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;for J=1,L do S=X(S,math.floor(S/32768));S=I(S,2246822519);S=X(S,(S*8192)%4294967296);S=I(S,3266489917);local M=(__bc_bxor(string.byte(K,((J-1)%#K)+1),__bc_bxor(S%256,(J*29+71)%256)))%256;local V=(string.byte(B,J)-((J*17)%256)+256)%256;O[J]=string.char(__bc_bxor(V,M)%256)end;return table.concat(O)end
local _1ypdzzl=function(E,V)return{pc=1,sp=0,stack={},locals={},localSet={},parent=nil,env=E,consts=V,code=nil,halt=false,ret={},varargs={},guard=0}end
local _12r9gup=function(V)return type(V)=="table" end
local _2k9w52=function(V)return V~=nil end
local _uttny7=function(V)return type(V)=="string" end
local _1gisqb0=function(V)return #V>0 end
local _9r8g51=function(V)return V and V.k~=nil end
local _18lcxei=function(V)return V and V.c~=nil end
local _1tsn8j=function(V)return V and V.p~=nil end
local _nirplc=function(V)return V and V.v~=nil end
local _1fsbheh=function(V)return V and #V<=16777216 end
local _flbwou=function(V)return V and V<=4294967296 end
local _17uvohz=function(V)return V and V>=0 end
local _1tjuqus=function(V)return V and #V>0 end
local _msagot=function(A,B)return A and B end
local _1lmexya=function(A,B)return A or B end
local _euunsb=function(V)return type(V)~="function" or true end
local _i3bbso=function(V)return type(V)~="thread" or true end
local _1acv3lt=function(V)return V~=false end
local _a5viw6=function(V)return V==nil or V==true or V==false or type(V)=="number" or type(V)=="string" or type(V)=="table" end
local function _2i6pb3(D)local P=1;local function U()local V=0;local M=1;while true do local B=string.byte(D,P);P=P+1;V=V+__bc_band(B,127)*M;if B<128 then return V end;M=M*128 end end;local function R(N)local V=D:sub(P,P+N-1);P=P+N;return V end;local function S()return R(U())end;local function N()local T=string.byte(D,P);P=P+1;if T==0 then local V=U();return(V%2==0)and(V/2)or-((V+1)/2)else return tonumber(S())end end;local function C()local K={};local KC=U();for I=1,KC do local T=string.byte(D,P);P=P+1;if T==83 then K[I]=S()elseif T==78 then K[I]=N()elseif T==84 then K[I]=true elseif T==70 then K[I]=false elseif T==67 then K[I]=C()elseif T==90 then K[I]=nil end end;local X={k=K,p={},c={}};local PC=U();for I=1,PC do X.p[I]=S()end;X.v=string.byte(D,P)==1;P=P+1;local IC=U();for I=1,IC do local AC=U();local Q={};for J=1,AC do Q[J]=N()end;X.c[I]=Q end;return X end;return C()end
local function _c5lfb5(S,I,...)S.halt=true;return true;end
local function _j786fx(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=S.consts[I[2]+1];end
local function _1qxi38w(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=I[2];end
local function _1xi2sp8(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=I[2]~=0;end
local function _13t2qi4(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=nil;end
local function _120w1l3(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=S.env[S.consts[I[2]+1]];end
local function _h33a5a(S,I,...)S.env[S.consts[I[2]+1]]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _e0c954(S,I,...)local T=S;local N=S.consts[I[2]+1];while T do if T.localSet[N] then S.stack[S.sp+1]=T.locals[N];S.sp=S.sp+1;break end;T=T.parent end;if not T then S.sp=S.sp+1;S.stack[S.sp]=nil end;end
local function _1otd6y9(S,I,...)local T=S;local N=S.consts[I[2]+1];while T and not T.localSet[N] do T=T.parent end;if not T then T=S;T.localSet[N]=true end;T.locals[N]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _15b6eb9(S,I,...)local k=S.stack[S.sp];local a=S.stack[S.sp-1];S.stack[S.sp-1]=a[k];S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _kddmvg(S,I,...)local v=S.stack[S.sp];local k=S.stack[S.sp-1];local a=S.stack[S.sp-2];a[k]=v;S.stack[S.sp]=nil;S.stack[S.sp-1]=nil;S.stack[S.sp-2]=nil;S.sp=S.sp-3;end
local function _1h1rhgf(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]+b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1sxfhi1(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]-b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1x183ka(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]*b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1ab83wp(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]/b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1is8l7p(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=math.floor(S.stack[S.sp-1]/b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _hi3e5o(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]%b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _vs1uut(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]^b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _12ok1dc(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]==b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1bpqi4z(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]~=b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _idtq98(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]<b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _tjq763(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]>b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _7ifcpx(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]<=b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _lym6cy(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]>=b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _dnqhjn(S,I,...)S.stack[S.sp]=not S.stack[S.sp];end
local function _6915r6(S,I,...)S.stack[S.sp]=-S.stack[S.sp];end
local function _nt3n3p(S,I,...)S.stack[S.sp]=#S.stack[S.sp];end
local function _1dtqe2c(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]..b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _5b5zy1(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1] and b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _14davzl(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1] or b;S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _c3miwk(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=__bc_band(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _fwzwz1(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=__bc_bor(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _gp9dhy(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=__bc_bxor(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _1huqd3i(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=__bc_shl(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _uupw0c(S,I,...)local b=S.stack[S.sp];S.stack[S.sp-1]=__bc_shr(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _psu71h(S,I,...)S.pc=I[2]+1;end
local function _13crkms(S,I,...)local z=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1;if not z then S.pc=I[2]+1 end;end
local function _7ri2eu(S,I,...)S.stack[S.sp]=nil;S.sp=S.sp-1;end
local function _91fj(S,I,...)S.sp=S.sp+1;S.stack[S.sp]=S.stack[S.sp-1];end
local function _mmrwpv(S,I,...)S.sp=S.sp+1;S.stack[S.sp]={};end
local function _13nee4a(S,I,...)local count=I[2];local args={};for q=count,1,-1 do args[q]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1 end;local f=S.stack[S.sp];local r={f(__bc_unpack(args,1,count))};S.stack[S.sp]=r[1];end
local function _6ha1ph(S,I,...)local count=I[2];local r={};for q=count,1,-1 do r[q]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1 end;S.halt=true;S.ret=r;return true;end
local function _1uoe9r5(S,I,...)local X=S.consts[I[2]+1];local P=S;S.sp=S.sp+1;S.stack[S.sp]=function(...)return _1lm70ut(X,P,...)end;end
local function _yq33ex(S,I,...)S.sp=S.sp+1;local a=S.varargs or {};S.stack[S.sp]=a;end
local function _opbjfg(S,I,...)S.halt=true;return true;end
local function _7skh7x(S,I,...)local a=S.stack[S.sp-1];S.sp=S.sp+1;S.stack[S.sp]=a;end
local function _slpjcp(S,I,...)local step=S.stack[S.sp];local limit=S.stack[S.sp-1];local idx=S.stack[S.sp-2];local ok=(step>=0 and idx<=limit)or(step<0 and idx>=limit);S.stack[S.sp-2]=ok;S.stack[S.sp]=nil;S.stack[S.sp-1]=nil;S.sp=S.sp-2;end
local function _7u9j88(S,I,...)local f=S.stack[S.sp-I[2]];S.stack[S.sp-I[2]]=f;end
local function _7czwce(S,I,...)S.halt=true;return true;end
local _uridaf=function(OP)return((OP*11+0)%51)+1 end
local _2hylha={}
_2hylha[35]=_c5lfb5
_2hylha[28]=_j786fx
_2hylha[27]=_1qxi38w
_2hylha[38]=_1xi2sp8
_2hylha[13]=_13t2qi4
_2hylha[33]=_120w1l3
_2hylha[49]=_h33a5a
_2hylha[12]=_e0c954
_2hylha[20]=_1otd6y9
_2hylha[18]=_15b6eb9
_2hylha[23]=_kddmvg
_2hylha[47]=_1h1rhgf
_2hylha[25]=_1sxfhi1
_2hylha[26]=_1x183ka
_2hylha[41]=_1ab83wp
_2hylha[51]=_1is8l7p
_2hylha[36]=_hi3e5o
_2hylha[19]=_vs1uut
_2hylha[48]=_12ok1dc
_2hylha[15]=_1bpqi4z
_2hylha[21]=_idtq98
_2hylha[37]=_tjq763
_2hylha[34]=_7ifcpx
_2hylha[9]=_lym6cy
_2hylha[2]=_dnqhjn
_2hylha[29]=_6915r6
_2hylha[8]=_nt3n3p
_2hylha[5]=_1dtqe2c
_2hylha[43]=_psu71h
_2hylha[6]=_13crkms
_2hylha[11]=_13nee4a
_2hylha[4]=_6ha1ph
_2hylha[44]=_7ri2eu
_2hylha[40]=_91fj
_2hylha[39]=_mmrwpv
_2hylha[42]=_jgeola
_2hylha[14]=_6vn45l
_2hylha[3]=_1uoe9r5
_2hylha[31]=_yq33ex
_2hylha[50]=_5b5zy1
_2hylha[7]=_14davzl
_2hylha[10]=_c3miwk
_2hylha[16]=_fwzwz1
_2hylha[46]=_gp9dhy
_2hylha[30]=_1huqd3i
_2hylha[1]=_uupw0c
_2hylha[32]=_opbjfg
_2hylha[45]=_7skh7x
_2hylha[22]=_slpjcp
_2hylha[17]=_7u9j88
_2hylha[24]=_7czwce
local _1ovzrn0=function(S)local G=S.guard or 0;while not S.halt do local I=S.code[S.pc];if not I then S.halt=true;break end;local O=I[1];S.pc=S.pc+1;G=(G*1664525+O*101+S.pc+1013904223)%4294967296;S.guard=G;local H=_2hylha[_uridaf(O)];if not H then error("ByteCode VM error",0)end;local X=H(S,I);if X then break end end;return S end
local _1lm70ut=function(X,P,...)local E=setmetatable({},{__index=_G});local S=_1ypdzzl(E,X.k);S.parent=P;S.code=X.c;S.varargs={...};S.guard=2528090685;for Q=1,#(X.p or {}) do local N=X.p[Q];S.locals[N]=select(Q,...);S.localSet[N]=true end;_1ovzrn0(S);return __bc_unpack(S.ret or {},1,#(S.ret or {}))end
local _1rpwixm=(function(C,O)local R={};local U=table.unpack or unpack;for I=1,#O do local N=C[O[I]];R[#R+1]=string.char(U(N))end;return table.concat(R)end)({{42,47,252,39,134,171,105,124,156,51,123,180,159,42,247,199,104,131,205,12,233,148,91,66,133,231,190,73,31,35,67,239,41,82,2,137,243,101,201,73,138,120,98},{83,139,194,145,207,46,23},{196,82,204,7,242,46,58,125,192,30,61,212,25,169,63,17,105,123,121,89,207,210},{98,65,79,27,147,94,246,180,95,143,142,43,67,201,197,230,140,148,246,166,100,228,196,184,32,143,4,34,251,57,229,33,106,134,246,142,83,185,56,207,16,87,196,31,136},{192,252,32,112,81,217,7,186,156,30,34,235,157,71,244,163,138,23,253,157,124,20,28,64,36,219,240,134,103,241,162,31,180,81,170,184,138,86,250,94,155,71,119},{167,98,161,43,75,88,225,80,65,227,6,78,88,23,86,158,20,223,249,16,36},{93,206,239,197,251,19,86,52,106,151,140,83,186,80,125,143,153,192,48,243,25,210,133,235,119,33,192,84,112,105},{240,166,40,135,178,133,120,174,249,43,73,76,7,123,122,139,32,147,77,2,254,21,11,149},{209,228,171,248,214,87,68,114,209,170,42,160,27,95,173,57,140,0,27,181,139,61,56,73,64,9,133,96,91,177,219,150,31,227,153,119}},{2})
local _1og3s5f="\078\086\165\022\004\103\067\199\006\040\001\061\145\223\167\181\148\005\094\044"
local _1lhqrm1=_5rzg3a(_1rpwixm,_1og3s5f,3235823763,7)
if __bc_payload_check(_1lhqrm1)~=577803753 then error("ByteCode payload integrity failed",0) end
local _1bsssi8=_2i6pb3(_1lhqrm1)
if not (_12r9gup(_1bsssi8) and _9r8g51(_1bsssi8) and _18lcxei(_1bsssi8) and _1tsn8j(_1bsssi8)) then error("ByteCode VM validation failed",0) end
local _1ldnd95={_1lm70ut(_1bsssi8,nil) }
return __bc_unpack(_1ldnd95,1,#_1ldnd95)
"use strict";

const {
    OPS: SEMANTIC_OPS,
    SEMANTIC_CLASS
} = require("./obfuscation/isa_engine");

const {
    REGISTER_ISA_VERSION,
    REGISTER_COMMAND_BY_SEMANTIC,
    REGISTER_COMMAND_NAMES
} = require("./compiler/register/register_isa_v479");

const Opcode = Object.freeze({
    LOADNIL: 2, LOADB: 3, LOADN: 4, LOADK: 5, MOVE: 6,
    GETGLOBAL: 7, SETGLOBAL: 8, GETUPVAL: 9, SETUPVAL: 10,
    CLOSEUPVALS: 11, GETTABLE: 13, SETTABLE: 14,
    GETTABLEKS: 15, SETTABLEKS: 16, GETTABLEN: 17,
    SETTABLEN: 18, NEWCLOSURE: 19, NAMECALL: 20,
    CALL: 21, RETURN: 22, JUMP: 23, JUMPBACK: 24,
    JUMPIF: 25, JUMPIFNOT: 26, JUMPIFEQ: 27,
    JUMPIFLE: 28, JUMPIFLT: 29, JUMPIFNOTEQ: 30,
    JUMPIFNOTLE: 31, JUMPIFNOTLT: 32, ADD: 33,
    SUB: 34, MUL: 35, DIV: 36, MOD: 37, POW: 38,
    CONCAT: 49, NOT: 50, MINUS: 51, LENGTH: 52,
    NEWTABLE: 53, SETLIST: 55, FORNPREP: 56,
    FORNLOOP: 57, FORGLOOP: 58, GETVARARGS: 63,
    IDIV: 81, ADDMOVE: 82, MOVE_ADD: 83,
    GETTKS_MOVE: 84, LOADK_MOVE: 85,

    HALT: 0xE0, PUSHK: 0xE1, PUSHN: 0xE2,
    PUSHB: 0xE3, PUSHNIL: 0xE4, GETG: 0xE5,
    SETG: 0xE6, GETL: 0xE7, SETL: 0xE8,
    GETI: 0xE9, SETI: 0xEA, NEG: 0xEB,
    LEN: 0xEC, JMP: 0xED, JZ: 0xEE,
    POP: 0xEF, DUP: 0xF0, MAKEFUNC: 0xF1,
    VARARG: 0xF2, AND: 0xF3, OR: 0xF4,
    BAND: 0xF5, BOR: 0xF6, BXOR: 0xF7,
    SHL: 0xF8, SHR: 0xF9, BREAK: 0xFA,
    MOVE_SELF: 0xFB, FORCMP: 0xFC,
    ITERPREP: 0xFD, ITERLOOP: 0xFE,
    BNOT: 0xFF, SWAP: 0x100,
    CALLM: 0x101, SUPER: 0x102
});

const Name = Object.freeze(
    Object.fromEntries(
        Object.entries(Opcode).map(([name, value]) => [value, name])
    )
);

const SemanticNameSet = new Set(SEMANTIC_OPS);

const SemanticOrdinal = Object.freeze(
    Object.fromEntries(
        SEMANTIC_OPS.map((name, index) => [name, index])
    )
);

const SemanticNameByOrdinal = Object.freeze(SEMANTIC_OPS.slice());
const RegisterCommandNameSet = new Set(REGISTER_COMMAND_NAMES);

function isKnown(value) {
    return Object.prototype.hasOwnProperty.call(Name, Number(value));
}

function isSemanticName(value) {
    return typeof value === "string" && SemanticNameSet.has(value);
}

function semanticOrdinal(name) {
    return isSemanticName(name) ? SemanticOrdinal[name] : null;
}

function semanticNameFromOrdinal(value) {
    const index = Number(value);

    return Number.isInteger(index) &&
        index >= 0 &&
        index < SemanticNameByOrdinal.length
        ? SemanticNameByOrdinal[index]
        : null;
}

function legacyName(value) {
    return Name[Number(value)] || null;
}

function legacyOpcode(name) {
    return typeof name === "string" &&
        Object.prototype.hasOwnProperty.call(Opcode, name)
        ? Opcode[name]
        : null;
}

function isRegisterCommand(value) {
    return typeof value === "string" &&
        RegisterCommandNameSet.has(value);
}

function describeIdentity(value, mode = "semantic") {
    if (mode === "legacy") {
        const name = legacyName(value);

        return name
            ? { kind: "legacy", name, id: Number(value) }
            : null;
    }

    if (mode === "register-command") {
        return isRegisterCommand(value)
            ? {
                kind: "register-command",
                name: value,
                version: REGISTER_ISA_VERSION
            }
            : null;
    }

    if (typeof value === "string" && isSemanticName(value)) {
        return {
            kind: "semantic",
            name: value,
            ordinal: SemanticOrdinal[value],
            category: SEMANTIC_CLASS[value] || "other"
        };
    }

    if (typeof value === "number") {
        const name = legacyName(value);

        return name
            ? { kind: "legacy", name, id: value }
            : null;
    }

    return null;
}

module.exports = {
    Opcode,
    Name,
    isKnown,

    SEMANTIC_OPS,
    SEMANTIC_CLASS,
    SemanticOrdinal,

    isSemanticName,
    semanticOrdinal,
    semanticNameFromOrdinal,

    legacyName,
    legacyOpcode,
    isRegisterCommand,
    describeIdentity,

    REGISTER_ISA_VERSION,
    REGISTER_COMMAND_BY_SEMANTIC
};
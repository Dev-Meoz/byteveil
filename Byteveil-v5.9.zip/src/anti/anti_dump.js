"use strict";

const WIPE_MAX_DEPTH = 3;

function cleanPrefix(value, fallback = "_bv_ad") {
    const text = String(value == null ? fallback : value)
        .replace(/[^A-Za-z0-9_]/g, "_");

    const prefixed = /^[A-Za-z_]/.test(text) ? text : `_${text}`;
    return prefixed || fallback;
}

function validateLuaExpression(expression, label = "Lua expression") {
    if (
        typeof expression !== "string" ||
        expression.trim() === ""
    ) {
        throw new TypeError(`${label} must be a non-empty string`);
    }

    return expression.trim();
}

/**
 * Sinh helper xóa dữ liệu khỏi bảng mutable và Luau buffer khi có hỗ trợ.
 *
 * Không thể xóa chuỗi bất biến hoặc xóa các bản sao đã bị công cụ
 * phân tích chụp lại trước đó.
 */
function buildAntiDumpSource(options = {}) {
    const prefix = cleanPrefix(options.prefix);
    const enabled = options.enabled !== false;

    const n = {
        type: `${prefix}_type`,
        pcall: `${prefix}_pcall`,
        pairs: `${prefix}_pairs`,
        wipe: `${prefix}_wipe`,
        filler: `${prefix}_filler`,
        depth: `${prefix}_depth`,
        bufferLib: `${prefix}_buffer`
    };

    if (!enabled) {
        return {
            declaration: "",
            clearCall: () => "",
            clearStatements: () => "",
            names: n,
            enabled: false,

            metadata: {
                antiDumpLayers: 0,
                antiDumpMutableCleanup: false
            }
        };
    }

    const declaration = [
        `local ${n.type} = type`,
        `local ${n.pcall} = pcall`,
        `local ${n.pairs} = pairs`,
        `local ${n.bufferLib} = buffer`,

        // Two passes: fill each slot with a same-type value before unlinking the key, so
        // decoded bytes are not still readable through the table between the passes.
        // Immutable strings cannot be erased in place; this releases the table's reference.
        `local function ${n.filler}(__value)`,
        `    local __kind = ${n.type}(__value)`,
        `    if __kind == "number" then return 0 end`,
        `    if __kind == "string" then return "" end`,
        `    if __kind == "boolean" then return false end`,
        `    return false`,
        `end`,

        `local function ${n.wipe}(__value, ${n.depth})`,
        `    if ${n.type}(__value) ~= "table" then`,
        `        if ${n.bufferLib} ~= nil and ${n.type}(__value) == "buffer" then`,
        `            local __lenFn = ${n.bufferLib}.len`,
        `            local __fillFn = ${n.bufferLib}.fill`,
        `            if ${n.type}(__lenFn) == "function" and ${n.type}(__fillFn) == "function" then`,
        `                return ${n.pcall}(__fillFn, __value, 0, __lenFn(__value), 0)`,
        `            end`,
        `        end`,
        `        return false`,
        `    end`,

        `    local __depth = ${n.depth}`,
        `    if __depth == nil then __depth = ${WIPE_MAX_DEPTH} end`,
        `    local __keys = {}`,
        `    local __count = 0`,
        `    for __key in ${n.pairs}(__value) do`,
        `        __count = __count + 1`,
        `        __keys[__count] = __key`,
        `    end`,
        `    for __i = 1, __count do`,
        `        local __key = __keys[__i]`,
        `        local __child = __value[__key]`,
        `        if ${n.type}(__child) == "table" and __depth > 1 then`,
        `            ${n.wipe}(__child, __depth - 1)`,
        `        end`,
        `        __value[__key] = ${n.filler}(__child)`,
        `    end`,
        `    for __i = 1, __count do`,
        `        __value[__keys[__i]] = nil`,
        `        __keys[__i] = nil`,
        `    end`,
        `    if setmetatable then ${n.pcall}(setmetatable, __value, nil) end`,
        `    return true`,
        `end`
    ].join("\n");

    function clearCall(expression) {
        const value = validateLuaExpression(expression);
        return `${n.wipe}(${value})`;
    }

    function clearStatements(expressions) {
        if (!Array.isArray(expressions)) {
            throw new TypeError("cleanup targets must be an array");
        }

        const unique = [
            ...new Set(
                expressions.map((entry) =>
                    validateLuaExpression(entry, "cleanup target")
                )
            )
        ];

        return unique.map((entry) => clearCall(entry)).join("\n");
    }

    const templateHole = /\b(undefined|NaN|\[object Object\])\b/.exec(declaration);
    if (templateHole) {
        throw new TypeError(`anti-dump template emitted ${templateHole[0]}; refusing to build`);
    }

    return {
        declaration,
        clearCall,
        clearStatements,
        names: n,
        enabled: true,

        metadata: {
            antiDumpLayers: 0,
            antiDumpMutableCleanup: true,
            antiDumpClearsMutableTables: true,
            antiDumpOverwritesSlotsBeforeUnlink: true,
            antiDumpRecursionDepth: WIPE_MAX_DEPTH,
            antiDumpClearsLuauBuffersWhenAvailable: true,
            antiDumpCannotEraseImmutableStrings: true
        }
    };
}

module.exports = {
    buildAntiDumpSource,
    WIPE_MAX_DEPTH
};
"use strict";

const DEFAULT_CORE_APIS = Object.freeze([
    "type",
    "pcall",
    "pairs",
    "tostring",
    "select",
    "error",
    "setmetatable"
]);

const STRICT_EXTRA_APIS = Object.freeze([
    "next",
    "assert",
    "xpcall",
    "rawget",
    "rawset"
]);

const MODULUS = 2147483647;
const LIBRARY_NAMES = Object.freeze(["string", "table", "math"]);

/**
 * Members of the library tables that the guard itself captured lexically. Checking
 * `libRefs[i][name] == memRefs[i]` catches the common exploit shape where a tool
 * rewrites `string.sub` in place instead of replacing the global name.
 */
const LIBRARY_MEMBERS = Object.freeze([
    { lib: 1, name: "sub", ref: "sub" },
    { lib: 1, name: "byte", ref: "byte" },
    { lib: 2, name: "concat", ref: "concat" },
    { lib: 3, name: "floor", ref: "floor" }
]);
const CANARY_MIN_LENGTH = 7;
const CANARY_MAX_LENGTH = 9;

function cleanPrefix(value, fallback = "_bv_ah") {
    const text = String(value == null ? fallback : value)
        .replace(/[^A-Za-z0-9_]/g, "_");

    const prefixed = /^[A-Za-z_]/.test(text) ? text : `_${text}`;
    return prefixed || fallback;
}

function normalizeApiList(profile, customApis) {
    const base = profile === "strict"
        ? [...DEFAULT_CORE_APIS, ...STRICT_EXTRA_APIS]
        : [...DEFAULT_CORE_APIS];

    const additions = Array.isArray(customApis) ? customApis : [];

    for (const api of additions) {
        if (
            typeof api !== "string" ||
            !/^[A-Za-z_][A-Za-z0-9_]*$/.test(api)
        ) {
            throw new TypeError(`Invalid Lua API name: ${String(api)}`);
        }

        if (!base.includes(api)) {
            base.push(api);
        }
    }

    return base;
}

function mix32(state, salt) {
    let value = ((Number(state) >>> 0) ^ 0x9E3779B9) >>> 0;
    value = (Math.imul(value ^ (value >>> 15), 0x85EBCA6B) + (Number(salt) >>> 0)) >>> 0;
    value = (value ^ (value >>> 13)) >>> 0;
    return value >>> 0;
}

function floorMod(value, modulus) {
    return ((value % modulus) + modulus) % modulus;
}

/**
 * The guard folds its own verdict into a number instead of only raising a flag, so a
 * caller can bind decode key material to the checks: hooked API => different digest =>
 * payload does not decode. Every entry below is pure and returns the same value on Lua
 * 5.4 and Luau, which is what makes the digest reproducible on the JavaScript side.
 * `lua`/`js` are two views of one spec, and the suite proves they agree at runtime.
 */
function buildCanarySpec(seed) {
    const word = buildCanaryWord(seed, 0x11);
    const second = buildCanaryWord(seed, 0x29);
    const negFloor = 2 + (mix32(seed, 0x31) % 6);
    const posFloor = 5 + (mix32(seed, 0x47) % 9);
    const pair = [
        buildCanaryWord(seed, 0x5D).slice(0, 2),
        buildCanaryWord(seed, 0x67).slice(0, 2)
    ];

    return {
        word,
        second,
        pair,
        negFloor,
        posFloor,
        canaries: [
            {
                id: "byte-head",
                numeric: true,
                lua: (a) => `${a.BYTE}(${a.WORD}, 1)`,
                js: () => word.charCodeAt(0)
            },
            {
                id: "sub-window-byte",
                numeric: true,
                lua: (a) => `${a.BYTE}(${a.SUB}(${a.WORD}, 2, 5), 1)`,
                js: () => word.charCodeAt(1)
            },
            {
                id: "sub-window-length",
                numeric: true,
                lua: (a) => `#${a.SUB}(${a.WORD}, 2, 5)`,
                js: () => 4
            },
            {
                id: "floor-negative",
                numeric: true,
                lua: (a) => `${a.FLOOR}(-${negFloor}.5)`,
                js: () => -(negFloor + 1)
            },
            {
                id: "floor-positive",
                numeric: true,
                lua: (a) => `${a.FLOOR}(${posFloor}.25)`,
                js: () => posFloor
            },
            {
                id: "select-count",
                numeric: true,
                lua: (a) => `${a.SELECT}("#", 1, 2, 3)`,
                js: () => 3
            },
            {
                id: "type-nil",
                lua: (a) => `${a.TYPE}(nil) == "nil"`,
                js: () => 1
            },
            {
                id: "type-number",
                lua: (a) => `${a.TYPE}(2) == "number"`,
                js: () => 1
            },
            {
                id: "concat-pair",
                lua: (a, names) => `${a.CONCAT}(${names.tablePair}, "") == ${JSON.stringify(pair.join(""))}`,
                js: () => 1
            },
            {
                id: "next-present",
                lua: (a, names) => `${a.NEXT}(${names.tablePair}) ~= nil`,
                js: () => 1
            },
            {
                id: "pcall-catches-error",
                lua: (a, names) => `${a.PCALL}(function() ${a.ERROR}(${names.secondLiteral}, 0) end)`,
                js: () => 0
            },
            {
                id: "error-level-zero",
                lua: (a, names) => `${a.RAWEQUAL}(${names.caughtValue}, ${names.secondLiteral})`,
                js: () => 1
            },
            {
                id: "purity-sub",
                lua: (a, names) => `${a.RAWEQUAL}(${names.subWindow}, ${names.subWindowAgain})`,
                js: () => 1
            },
            {
                id: "purity-floor",
                lua: (a, names) => `${a.RAWEQUAL}(${names.floorWindow}, ${a.FLOOR}(-${negFloor}.5))`,
                js: () => 1
            },
            {
                id: "word-sum-scan",
                scan: true,
                lua: (a, names) => `${a.BYTE}(${names.second}, ${a.I2})`,
                js: () => Array.from(second, (character) => character.charCodeAt(0))
            }
        ]
    };
}

function buildCanaryWord(seed, salt) {
    const alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const length = CANARY_MIN_LENGTH + (mix32(seed, salt) % (CANARY_MAX_LENGTH - CANARY_MIN_LENGTH + 1));
    let state = mix32(seed, salt);
    let word = "";
    for (let index = 0; index < length; index++) {
        state = mix32(state, index + salt);
        word += alphabet[state % alphabet.length];
    }
    return word;
}

function guardDigest(spec, apiCount, libraryCount, memberCount) {
    const init = 17 + (mix32(spec.seed, 0x51) % 65519);
    const mult = 65599 + ((mix32(spec.seed, 0x73) % 2048) * 2);
    let hash = init;
    const mix = (value) => { hash = floorMod(hash * mult + value, MODULUS); };

    for (let index = 0; index < apiCount; index++) mix(1);
    for (let index = 0; index < libraryCount; index++) mix(1);
    for (let index = 0; index < memberCount; index++) mix(1);

    for (const canary of orderedCanaries(spec)) {
        if (canary.scan) {
            for (const byte of canary.js()) mix(byte);
            continue;
        }
        const value = canary.js();
        mix(canary.numeric ? value : (value ? 1 : 0));
    }

    return { init, mult, hash };
}

function orderedCanaries(spec) {
    const order = spec.order;
    return order.map((index) => spec.canaries[index]);
}

function buildAntiHookSource(options = {}) {
    const prefix = cleanPrefix(options.prefix);
    const profile = options.profile === "strict" ? "strict" : "balanced";
    const enabled = options.enabled !== false;
    const apiNames = normalizeApiList(profile, options.apis);
    const seed = Number.isFinite(Number(options.seed)) ? (Number(options.seed) >>> 0) : 0;
    const key = (((seed ^ 0x6D2B79F5) >>> 0) % GUARD_ALPHABET.length);

    const n = {
        type: `${prefix}_type`,
        pcall: `${prefix}_pcall`,
        pairs: `${prefix}_pairs`,
        error: `${prefix}_error`,
        getfenv: `${prefix}_getfenv`,
        getgenv: `${prefix}_getgenv`,
        env: `${prefix}_env`,
        refs: `${prefix}_refs`,
        guard: `${prefix}_check`,
        decode: `${prefix}_decode`,
        sub: `${prefix}_sub`,
        alphabet: `${prefix}_alphabet`,
        concat: `${prefix}_concat`,
        keys: `${prefix}_keys`,
        key: `${prefix}_key`,
        i: `${prefix}_i`,
        api: `${prefix}_api`,
        message: `${prefix}_message`,
        byte: `${prefix}_byte`,
        floor: `${prefix}_floor`,
        select: `${prefix}_select`,
        next: `${prefix}_next`,
        rawequal: `${prefix}_rawequal`,
        word: `${prefix}_word`,
        second: `${prefix}_word2`,
        pairTable: `${prefix}_pair`,
        probe: `${prefix}_probe`,
        hash: `${prefix}_acc`,
        mix: `${prefix}_mix`,
        mixArg: `${prefix}_v`,
        libKeys: `${prefix}_libkeys`,
        libRefs: `${prefix}_librefs`,
        memKeys: `${prefix}_memkeys`,
        memLibs: `${prefix}_memlibs`,
        memRefs: `${prefix}_memrefs`,
        subWindow: `${prefix}_win`,
        subWindowAgain: `${prefix}_win2`,
        floorWindow: `${prefix}_flr`,
        caughtFlag: `${prefix}_caught`,
        caughtValue: `${prefix}_err`,
        i2: `${prefix}_j`
    };

    if (!enabled) {
        return {
            declaration: "", checkCall: "", names: n, enabled: false, apiNames: [],
            metadata: { antiHookLayers: 0, antiHookMode: "disabled" }
        };
    }

    // Keep API names and diagnostics out of plaintext string-keyed lookup chains.
    // The additive per-build codec is intentionally a presentation/obfuscation
    // layer, not cryptography; runtime behavior remains a normal API snapshot check.
    const runtimeAlphabet = shuffleAlphabet(GUARD_ALPHABET, seed);
    const alphabetFragments = splitAlphabetLiteral(runtimeAlphabet, seed);
    const encodedKeys = apiNames.map((api) =>
        `{${encodeBytes(api, key, runtimeAlphabet).join(",")}}`
    ).join(",");
    const tamperMessage = "Obfuscated source crash - runtime tamper detect";
    const encodedMessage = `{${encodeBytes(tamperMessage, key, runtimeAlphabet).join(",")}}`;
    const encodedUnavailable = `{${encodeBytes("runtime guard unavailable", key, runtimeAlphabet).join(",")}}`;
    const encodedLibraries = LIBRARY_NAMES.map((library) =>
        `{${encodeBytes(library, key, runtimeAlphabet).join(",")}}`
    ).join(",");
    const encodedMembers = LIBRARY_MEMBERS.map((member) =>
        `{${encodeBytes(member.name, key, runtimeAlphabet).join(",")}}`
    ).join(",");
    const references = apiNames.map((api) => api).join(", ");
    const referenceInitialization = options.baselineFromEnvironment === true
        ? [
            `local ${n.keys} = {${encodedKeys}}`,
            `local ${n.message} = ${encodedMessage}`,
            `local ${n.refs} = {}`,
            `if ${n.env} ~= nil then for ${n.i} = 1, #${n.keys} do local __name = ${n.decode}(${n.keys}[${n.i}]); ${n.refs}[${n.i}] = ${n.env}[__name] end end`
        ]
        : [
            `local ${n.refs} = {${references}}`,
            `local ${n.keys} = {${encodedKeys}}`,
            `local ${n.message} = ${encodedMessage}`
        ];

    const spec = buildCanarySpec(seed);
    spec.seed = seed;
    spec.order = shuffleCanaryOrder(spec, seed);
    const digest = guardDigest(spec, apiNames.length, LIBRARY_NAMES.length, LIBRARY_MEMBERS.length);
    const alias = {
        TYPE: n.type,
        PCALL: n.pcall,
        ERROR: n.error,
        SUB: n.sub,
        CONCAT: n.concat,
        BYTE: n.byte,
        FLOOR: n.floor,
        SELECT: n.select,
        NEXT: n.next,
        RAWEQUAL: n.rawequal,
        WORD: n.word,
        I2: n.i2
    };
    const canaryNames = {
        tablePair: n.pairTable,
        second: n.second,
        secondLiteral: JSON.stringify(spec.second),
        subWindow: n.subWindow,
        subWindowAgain: n.subWindowAgain,
        floorWindow: n.floorWindow,
        caughtFlag: n.caughtFlag,
        caughtValue: n.caughtValue
    };

    const canaryLines = [];
    for (const index of spec.order) {
        const canary = spec.canaries[index];
        if (canary.scan) {
            canaryLines.push(
                `for ${n.i2} = 1, #${n.second} do ${n.mix}(${canary.lua(alias, canaryNames)}) end`
            );
            continue;
        }
        const expression = canary.lua(alias, canaryNames);
        canaryLines.push(
            canary.numeric
                ? `${n.mix}(${expression})`
                : `${n.mix}(${expression} and 1 or 0)`
        );
    }

    const declaration = [
        `local ${n.type} = type`,
        `local ${n.pcall} = pcall`,
        `local ${n.pairs} = pairs`,
        `local ${n.error} = error`,
        `local ${n.getfenv} = getfenv`,
        `local ${n.getgenv} = getgenv`,
        `local ${n.sub} = string.sub`,
        `local ${n.concat} = table.concat`,
        `local ${n.byte} = string.byte`,
        `local ${n.floor} = math.floor`,
        `local ${n.select} = select`,
        `local ${n.next} = next`,
        `local ${n.rawequal} = rawequal`,
        `local ${n.alphabet} = ${n.concat}({${alphabetFragments}})`,
        `local ${n.key} = ${key}`,
        `local function ${n.decode}(${n.api})`,
        `    local ${n.message} = {}`,
        `    for ${n.i} = 1, #${n.api} do local __p = ((${n.api}[${n.i}] - ${n.key} - (${n.i} * 5)) % #${n.alphabet}) + 1; ${n.message}[${n.i}] = ${n.sub}(${n.alphabet}, __p, __p) end`,
        `    return ${n.concat}(${n.message})`,
        `end`,
        `local ${n.env} = nil`,
        `do`,
        `    local __ok, __value = ${n.pcall}(function()`,
        `        if ${n.getgenv} ~= nil then`,
        `            local __g = ${n.getgenv}()`,
        `            if ${n.type}(__g) == "table" then return __g end`,
        `        end`,
        `        if ${n.getfenv} ~= nil then`,
        `            local __f = ${n.getfenv}(0)`,
        `            if ${n.type}(__f) == "table" then return __f end`,
        `        end`,
        `        if ${n.type}(_G) == "table" then return _G end`,
        `        return nil`,
        `    end)`,
        `    if __ok and ${n.type}(__value) == "table" then ${n.env} = __value end`,
        `end`,
        ...referenceInitialization,
        `local ${n.word} = ${JSON.stringify(spec.word)}`,
        `local ${n.second} = ${JSON.stringify(spec.second)}`,
        `local ${n.pairTable} = {${spec.pair.map((entry) => JSON.stringify(entry)).join(", ")}}`,
        `local ${n.libKeys} = {${encodedLibraries}}`,
        `local ${n.libRefs} = {string, table, math}`,
        `local ${n.memKeys} = {${encodedMembers}}`,
        `local ${n.memLibs} = {${LIBRARY_MEMBERS.map((member) => member.lib).join(", ")}}`,
        `local ${n.memRefs} = {${LIBRARY_MEMBERS.map((member) => n[member.ref]).join(", ")}}`,
        `local function ${n.probe}()`,
        `    local ${n.hash} = ${digest.init}`,
        `    local function ${n.mix}(${n.mixArg})`,
        `        ${n.hash} = (${n.hash} * ${digest.mult} + ${n.mixArg}) % ${MODULUS}`,
        `    end`,
        `    for ${n.i} = 1, #${n.keys} do`,
        `        local __name = ${n.decode}(${n.keys}[${n.i}])`,
        `        ${n.mix}(${n.rawequal}(${n.env}[__name], ${n.refs}[${n.i}]) and 1 or 0)`,
        `    end`,
        `    for ${n.i} = 1, #${n.libKeys} do`,
        `        local __lib = ${n.decode}(${n.libKeys}[${n.i}])`,
        `        ${n.mix}(${n.rawequal}(${n.env}[__lib], ${n.libRefs}[${n.i}]) and 1 or 0)`,
        `    end`,
        `    for ${n.i} = 1, #${n.memKeys} do`,
        `        local __member = ${n.decode}(${n.memKeys}[${n.i}])`,
        `        ${n.mix}(${n.rawequal}(${n.libRefs}[${n.memLibs}[${n.i}]][__member], ${n.memRefs}[${n.i}]) and 1 or 0)`,
        `    end`,
        `    local ${n.subWindow} = ${n.sub}(${n.word}, 2, 5)`,
        `    local ${n.subWindowAgain} = ${n.sub}(${n.word}, 2, 5)`,
        `    local ${n.floorWindow} = ${n.floor}(-${spec.negFloor}.5)`,
        `    local ${n.caughtFlag}, ${n.caughtValue} = ${n.pcall}(function() ${n.error}(${JSON.stringify(spec.second)}, 0) end)`,
        ...canaryLines,
        `    return ${n.hash}`,
        `end`,
        `local ${n.guard} = function()`,
        `    if ${n.type}(${n.type}) ~= "function" or ${n.type}(${n.pcall}) ~= "function" or ${n.type}(${n.pairs}) ~= "function" then ${n.error}(${n.decode}(${n.message}), 0) end`,
        (options.failClosedOnMissingEnvironment !== false
            ? `    if ${n.env} == nil then ${n.error}(${n.decode}(${encodedUnavailable}), 0) end`
            : `    if ${n.env} == nil then return true end`),
        `    for ${n.i} = 1, #${n.keys} do`,
        `        local __name = ${n.decode}(${n.keys}[${n.i}])`,
        `        if ${n.env}[__name] ~= ${n.refs}[${n.i}] then ${n.error}(${n.decode}(${n.message}), 0) end`,
        `    end`,
        `    for ${n.i} = 1, #${n.memKeys} do`,
        `        local __member = ${n.decode}(${n.memKeys}[${n.i}])`,
        `        if ${n.libRefs}[${n.memLibs}[${n.i}]][__member] ~= ${n.memRefs}[${n.i}] then ${n.error}(${n.decode}(${n.message}), 0) end`,
        `    end`,
        `    local __probeOk, __digest = ${n.pcall}(${n.probe})`,
        `    if not __probeOk then ${n.error}(${n.decode}(${n.message}), 0) end`,
        `    if __digest ~= ${digest.hash} or ${n.type}(__digest) ~= "number" then ${n.error}(${n.decode}(${n.message}), 0) end`,
        `    return __digest`,
        `end`
    ].join("\n");

    // A template hole serialises as `undefined`/`NaN` and reaches the target as a bare
    // global, which reads as working code and fails at runtime. Fail the build instead.
    const templateHole = /\b(undefined|NaN|\[object Object\])\b/.exec(declaration);
    if (templateHole) {
        throw new TypeError(`anti-hook template emitted ${templateHole[0]}; refusing to build`);
    }
    return {
        declaration,
        checkCall: `${n.guard}()`,
        names: n,
        enabled: true,
        apiNames,
        digest: {
            expression: `${n.guard}()`,
            expected: digest.hash,
            init: digest.init,
            multiplier: digest.mult,
            modulus: MODULUS,
            canaryOrder: spec.order.map((index) => spec.canaries[index].id),
            spec
        },
        metadata: {
            antiHookLayers: 1,
            antiHookMode: profile,
            antiHookCheckedApis: apiNames.length,
            antiHookChecksReplacementAfterStartup: true,
            antiHookGuaranteesNoNativeHook: false,
            antiHookDiagnosticCodec: "seeded-additive-byte-table-v2",
            antiHookDetectsSetmetatableReplacement: true,
            antiHookFailureMessage: tamperMessage,
            antiHookReferenceBaseline: options.baselineFromEnvironment === true ? "decoded-environment-vector-v1" : "lexical-reference-vector-v1",
            antiHookVerdictDigest: "pure-canary-fold-v59",
            antiHookVerdictDigestBindings: apiNames.length + LIBRARY_NAMES.length + LIBRARY_MEMBERS.length,
            antiHookVerdictDigestCanaries: spec.canaries.length,
            antiHookDetectsLibraryMemberReplacement: true,
            antiHookBehavioralCanariesTargetIndependent: true,
            antiHookDigestIsCryptographicHash: false
        }
    };
}

function shuffleCanaryOrder(spec, seed) {
    const indices = spec.canaries.map((_, index) => index);
    let state = mix32(seed, 0x0F1E2D3C);
    for (let index = indices.length - 1; index > 0; index--) {
        state = mix32(state, index);
        const swap = state % (index + 1);
        [indices[index], indices[swap]] = [indices[swap], indices[index]];
    }
    return indices;
}

/**
 * Sinh Lua/Luau guard để phát hiện việc thay thế các API
 * đã được ghi nhận sau thời điểm script khởi tạo.
 *
 * Không thể chứng minh API chưa bị hook trước khi guard chạy.
 */
const GUARD_ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 -!";

function shuffleAlphabet(alphabet, seed) {
    const chars = Array.from(alphabet);
    let state = ((Number(seed) >>> 0) ^ 0xA53C9E17) >>> 0;
    if (state === 0) state = 0x6D2B79F5;
    for (let i = chars.length - 1; i > 0; i--) {
        state = (Math.imul(state ^ (state >>> 13), 0x5BD1E995) + 0x9E3779B9 + i) >>> 0;
        const j = state % (i + 1);
        [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join("");
}

function splitAlphabetLiteral(alphabet, seed) {
    const parts = [];
    let cursor = 0;
    let state = ((Number(seed) >>> 0) ^ 0x3C6EF372) >>> 0;
    while (cursor < alphabet.length) {
        state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
        const step = 6 + (state % 7);
        parts.push(JSON.stringify(alphabet.slice(cursor, cursor + step)));
        cursor += step;
    }
    return parts.join(",");
}

function encodeBytes(value, key, alphabet = GUARD_ALPHABET) {
    return Array.from(String(value), (character, index) => {
        const plain = alphabet.indexOf(character);
        if (plain < 0) throw new TypeError(`Unsupported guard codec character: ${character}`);
        return (plain + key + ((index + 1) * 5)) % alphabet.length;
    });
}

module.exports = {
    buildAntiHookSource,
    guardDigest,
    buildCanarySpec,
    DEFAULT_CORE_APIS,
    STRICT_EXTRA_APIS,
    GUARD_ALPHABET,
    GUARD_MODULUS: MODULUS
};

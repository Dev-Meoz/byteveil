"use strict";

const CHECKSUM_MODULUS = 2147483647;

function cleanPrefix(value, fallback = "_bv_at") {
    const text = String(value == null ? fallback : value)
        .replace(/[^A-Za-z0-9_]/g, "_");

    const prefixed = /^[A-Za-z_]/.test(text) ? text : `_${text}`;
    return prefixed || fallback;
}

function toBytes(value) {
    if (value == null) {
        throw new TypeError("Expected payload bytes");
    }

    let values;

    if (Buffer.isBuffer(value)) {
        values = Array.from(value, (entry) => Number(entry) & 0xff);
    } else if (value instanceof DataView) {
        values = Array.from(
            new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
        );
    } else if (ArrayBuffer.isView(value)) {
        values = Array.from(value, (entry) => Number(entry) & 0xff);
    } else if (value instanceof ArrayBuffer) {
        values = Array.from(new Uint8Array(value));
    } else if (Array.isArray(value)) {
        values = value.map((entry) => {
            const number = Number(entry);

            if (!Number.isFinite(number)) {
                throw new TypeError("Payload contains a non-numeric byte");
            }

            return number & 0xff;
        });
    } else {
        throw new TypeError(
            "Expected an Array, Buffer, TypedArray, or ArrayBuffer"
        );
    }

    return values;
}

function deriveTamperParams(seed) {
    if (seed === undefined || seed === null || seed === false) {
        return {
            initHash: 17, mult: 65599, posMix: 0, strideBias: 1, seeded: false,
            mirrorInit: 23, mirrorMult: 65599, mirrorPosMix: 0, mirrorStrideBias: 1
        };
    }
    const s = (Number(seed) >>> 0) || 0x5800A11;
    return {
        initHash: 17 + (s % 65519),
        mult: 65599 + (((s >>> 8) % 4093) * 2),
        posMix: 1 + ((s >>> 16) % 251),
        strideBias: 1 + ((s >>> 24) % 13),
        seeded: true,
        // Second chain walks the same table from the far end, so a patch that keeps the
        // forward loop intact still produces a digest the build never predicted.
        mirrorInit: 19 + (((s ^ 0x5BF03635) >>> 0) % 65519),
        mirrorMult: 65599 + ((((s >>> 4) ^ 0x9E37) % 4093) * 2),
        mirrorPosMix: 1 + (((s >>> 12) ^ 0x2B99) % 251),
        mirrorStrideBias: 1 + (((s >>> 20) ^ 0x7F5) % 13)
    };
}

function lumod(value, modulus) {
    return ((value % modulus) + modulus) % modulus;
}

/**
 * Dual-chain integrity digest. `hash` is the forward walk, `mirror` is the same pass
 * reading the table from the other end. Both are emitted into the payload, so a byte
 * edit, a truncation, or a rewritten loop order changes at least one of the two.
 */
function checksumBytesV2(value, seed) {
    const bytes = toBytes(value);
    const params = deriveTamperParams(seed);
    let forward = params.initHash;
    let mirror = params.mirrorInit;

    for (let i = 1; i <= bytes.length; i++) {
        const mixed = params.seeded
            ? (bytes[i - 1] + ((i * params.posMix) % 256)) % 256
            : bytes[i - 1] % 256;
        forward = lumod(forward * params.mult + mixed + (params.seeded ? (i % params.strideBias) + 1 : 1), CHECKSUM_MODULUS);

        const j = bytes.length - i + 1;
        const mirrored = params.seeded
            ? (bytes[j - 1] + ((i * params.mirrorPosMix) % 256)) % 256
            : bytes[j - 1] % 256;
        mirror = lumod(mirror * params.mirrorMult + mirrored + (params.seeded ? (i % params.mirrorStrideBias) + 1 : 1), CHECKSUM_MODULUS);
    }

    return {
        hash: forward,
        mirror,
        length: bytes.length,
        params
    };
}

/**
 * Giữ phép tính dưới 2^53 để JavaScript và Lua dùng double-number
 * có thể thực hiện phép tính nhất quán cho các byte đầu vào.
 */
function checksumBytes(value, seed) {
    const bytes = toBytes(value);
    const params = deriveTamperParams(seed);
    let hash = params.initHash;

    for (let i = 0; i < bytes.length; i++) {
        const idx = i + 1;
        const mixedByte = params.seeded
            ? (bytes[i] + ((idx * params.posMix) % 256)) % 256
            : bytes[i];
        const bias = params.seeded ? (idx % params.strideBias) + 1 : 1;
        hash = (
            hash * params.mult +
            mixedByte +
            bias
        ) % CHECKSUM_MODULUS;
    }

    return hash;
}

function createIntegrityRecord(value, seed) {
    const digest = checksumBytesV2(value, seed);

    return Object.freeze({
        length: digest.length,
        checksum: digest.hash,
        mirrorChecksum: digest.mirror
    });
}

/**
 * Sinh validator cho một Lua byte table liên tục, đánh chỉ số từ 1.
 *
 * Truyền expectedBytes và dataExpression để tạo sẵn lời gọi kiểm tra.
 */
function buildAntiTamperSource(options = {}) {
    const prefix = cleanPrefix(options.prefix);
    const enabled = options.enabled !== false;
    const params = deriveTamperParams(options.seed);

    const n = {
        type: `${prefix}_type`,
        error: `${prefix}_error`,
        hash: `${prefix}_hash`,
        check: `${prefix}_check`
    };

    const byteMixExpr = params.seeded
        ? `((__byte + ((__i * ${params.posMix}) % 256)) % 256)`
        : `(__byte % 256)`;
    const biasExpr = params.seeded
        ? `((__i % ${params.strideBias}) + 1)`
        : `1`;
    const mirrorByteMixExpr = params.seeded
        ? `((__mirrorByte + ((__i * ${params.mirrorPosMix}) % 256)) % 256)`
        : `(__mirrorByte % 256)`;
    const mirrorBiasExpr = params.seeded
        ? `((__i % ${params.mirrorStrideBias}) + 1)`
        : `1`;

    const declaration = enabled
        ? [
            `local ${n.type} = type`,
            `local ${n.error} = nil`,

            `local function ${n.hash}(__bytes)`,
            `    if ${n.type}(__bytes) ~= "table" then return nil, nil, -1 end`,

            `    local __count = #__bytes`,
            `    local __hash = ${params.initHash}`,
            `    local __mirror = ${params.mirrorInit}`,

            `    for __i = 1, __count do`,
            `        local __byte = __bytes[__i]`,
            `        local __mirrorByte = __bytes[__count - __i + 1]`,

            `        if ${n.type}(__byte) ~= "number" or ${n.type}(__mirrorByte) ~= "number" then`,
            `            return nil, nil, __count`,
            `        end`,

            `        local __mixed = ${byteMixExpr}`,
            `        __hash = (__hash * ${params.mult} + __mixed + ${biasExpr}) % 2147483647`,
            `        local __mirrorMixed = ${mirrorByteMixExpr}`,
            `        __mirror = (__mirror * ${params.mirrorMult} + __mirrorMixed + ${mirrorBiasExpr}) % 2147483647`,
            `    end`,

            `    return __hash, __mirror, __count`,
            `end`,

            `local function ${n.check}(__bytes, __expectedHash, __expectedLength, __expectedMirror)`,
            `    local __hash, __mirror, __length = ${n.hash}(__bytes)`,

            `    if __hash == nil or __hash ~= __expectedHash or __length ~= __expectedLength then`,
            `        return ${n.error}()`,
            `    end`,

            // `__expectedMirror` is optional: three-argument call sites (lane and
            // descriptor tables, whose records predate the mirror chain) keep working,
            // while builders that have the bytes pass the second expectation too.
            `    if ${n.type}(__expectedMirror) == "number" and __mirror ~= __expectedMirror then`,
            `        return ${n.error}()`,
            `    end`,

            `    return __hash`,
            `end`
        ].join("\n")
        : "";

    let record = null;

    if (options.expectedBytes !== undefined && options.expectedBytes !== null) {
        record = createIntegrityRecord(options.expectedBytes, options.seed);
    } else if (
        options.expectedRecord &&
        Number.isInteger(options.expectedRecord.length) &&
        Number.isInteger(options.expectedRecord.checksum)
    ) {
        record = Object.freeze({
            length: options.expectedRecord.length,
            checksum: options.expectedRecord.checksum,
            mirrorChecksum: Number.isInteger(options.expectedRecord.mirrorChecksum)
                ? options.expectedRecord.mirrorChecksum
                : null
        });
    }

    let checkCall = "";

    if (
        enabled &&
        record &&
        typeof options.dataExpression === "string" &&
        options.dataExpression.trim()
    ) {
        checkCall =
            `${n.check}(` +
            `${options.dataExpression.trim()}, ` +
            `${record.checksum}, ${record.length}` +
            (record.mirrorChecksum === null ? "" : `, ${record.mirrorChecksum}`) +
            `)`;
    }

    return {
        declaration,
        checkCall,
        names: n,
        enabled,
        record,

        metadata: {
            antiTamperLayers: checkCall ? 1 : 0,
            antiTamperValidatorGenerated: enabled,
            antiTamperPayloadCheckConfigured: Boolean(checkCall),
            antiTamperChecksumAlgorithm: "ByteVeil-mod65599-dual-chain-v2",
            antiTamperMirrorChain: true,
            antiTamperChecksumLengthBound: true,
            antiTamperIsCryptographicAuthentication: false
        }
    };
}

module.exports = {
    buildAntiTamperSource,
    checksumBytes,
    checksumBytesV2,
    createIntegrityRecord,
    deriveTamperParams,
    toBytes,
    CHECKSUM_MODULUS
};
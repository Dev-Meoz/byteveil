"use strict";

const { buildAntiHookSource } = require("./anti_hook");
const { buildAntiDumpSource } = require("./anti_dump");
const { buildAntiTamperSource } = require("./anti_tamper");

function cleanPrefix(value, fallback = "_bv_anti") {
    const text = String(value == null ? fallback : value)
        .replace(/[^A-Za-z0-9_]/g, "_");

    const prefixed = /^[A-Za-z_]/.test(text) ? text : `_${text}`;
    return prefixed || fallback;
}

/**
 * Ghép các anti module thành những đoạn code mà VM generator có thể chèn.
 *
 * options:
 *   seed              Số nguyên dùng để tạo tên local ổn định theo build.
 *   mode              "balanced" hoặc "strict".
 *   payloadBytes      Dãy byte chính xác cần được kiểm tra.
 *   payloadExpression Biểu thức Lua trỏ đến bảng byte cần kiểm tra.
 *   cleanupTargets    Mảng các biểu thức Lua trỏ đến dữ liệu mutable cần dọn.
 *
 * Caller tự quyết định vị trí gọi checkpoint.
 * Hàm này không tự động sửa nội dung VM generator.
 */
function buildAntiBundle(options = {}) {
    const enabled = options.enabled !== false;
    const base = cleanPrefix(options.prefix);

    const seed = Number.isFinite(Number(options.seed))
        ? (Number(options.seed) >>> 0)
        : 0;

    const suffix = seed.toString(36);
    const prefix = `${base}_${suffix}`;

    const hook = buildAntiHookSource({
        prefix: `${prefix}_hook`,
        seed,
        profile: options.mode === "strict" ? "strict" : "balanced",
        apis: options.hookApis,
        enabled: enabled && options.antiHook !== false,
        failClosedOnMissingEnvironment: options.failClosedOnMissingEnvironment !== false,
        baselineFromEnvironment: options.baselineFromEnvironment === true
    });

    const dump = buildAntiDumpSource({
        prefix: `${prefix}_dump`,
        enabled: enabled && options.antiDump !== false
    });

    const tamper = buildAntiTamperSource({
        prefix: `${prefix}_tamper`,
        seed,
        enabled: enabled && options.antiTamper !== false,
        expectedBytes: options.payloadBytes,
        expectedRecord: options.integrityRecord,
        dataExpression: options.payloadExpression
    });

    const declarations = [
        hook.declaration,
        dump.declaration,
        tamper.declaration
    ]
        .filter(Boolean)
        .join("\n\n");

    const cleanupTargets = Array.isArray(options.cleanupTargets)
        ? [
            ...new Set(
                options.cleanupTargets.map((target) => {
                    if (typeof target !== "string" || !target.trim()) {
                        throw new TypeError(
                            "Each cleanup target must be a non-empty Lua expression"
                        );
                    }

                    return target.trim();
                })
            )
        ]
        : [];

    const beforeDecode = hook.checkCall;

    const beforeExecute = [
        hook.checkCall,
        tamper.checkCall
    ]
        .filter(Boolean)
        .join("\n");

    const afterExecute = dump.enabled
        ? dump.clearStatements(cleanupTargets)
        : "";

    const usedDumpCleanup = Boolean(afterExecute);

    const metadata = {
        ...hook.metadata,
        ...dump.metadata,
        ...tamper.metadata,

        antiHookLayers: hook.enabled ? 1 : 0,
        antiDumpLayers: usedDumpCleanup ? 1 : 0,
        antiTamperLayers: tamper.checkCall ? 1 : 0,

        antiHookEnabled: hook.enabled,
        antiDumpEnabled: usedDumpCleanup,
        antiTamperEnabled: Boolean(tamper.checkCall),

        antiCleanupTargetCount: cleanupTargets.length,
        antiIntegration: "explicit-generator-checkpoints",
        antiBundleDeclarationsIncluded: Boolean(declarations)
    };

    return {
        declarations,

        checkpoints: {
            beforeDecode,
            beforeExecute,
            afterExecute
        },

        helpers: {
            hook,
            dump,
            tamper
        },

        metadata
    };
}

// The single configuration the stack VM bundles use. The pipeline has to predict the
// guard's verdict before the serializer runs, so both sides build from this object and
// the generator re-checks the number it actually emitted.
const VM_ANTI_BUNDLE_CONFIG = Object.freeze({
    prefix: "_bvanti",
    mode: "balanced"
});

function predictGuardVerdict(options = {}) {
    const bundle = buildAntiBundle({
        ...VM_ANTI_BUNDLE_CONFIG,
        seed: Number.isFinite(Number(options.seed)) ? (Number(options.seed) >>> 0) : 0,
        antiHook: true,
        antiDump: false,
        antiTamper: false,
        failClosedOnMissingEnvironment: options.failClosedOnMissingEnvironment !== false,
        baselineFromEnvironment: options.baselineFromEnvironment === true,
        cleanupTargets: []
    });
    const digest = bundle.helpers.hook.digest;
    if (!digest || !Number.isInteger(digest.expected)) {
        throw new Error("ByteVeil v5.9 anti-hook invariant failed: guard verdict is not predictable");
    }
    return {
        value: digest.expected,
        guardName: bundle.helpers.hook.names.guard,
        canaryCount: Number(bundle.metadata.antiHookVerdictDigestCanaries || 0)
    };
}

module.exports = {
    buildAntiBundle,
    buildAntiHookSource,
    buildAntiDumpSource,
    buildAntiTamperSource,
    predictGuardVerdict,
    VM_ANTI_BUNDLE_CONFIG
};
"use strict";

const { makePayloadContainer } = require("../obfuscation/payload_container");
const { makeNumericContainer, ALPHABET: PAYLOAD_ALPHABET } = require("../obfuscation/payload_container_v29");
const PAYLOAD_ALPHABET_SET = new Set(PAYLOAD_ALPHABET);
const PAYLOAD_RADIX = PAYLOAD_ALPHABET.length;
const { encodeBytes, decodeBytes, deriveCodecKey } = require("../obfuscation/encoder");
const { OPS, buildISAPlan } = require("../obfuscation/isa_engine");
const { deriveProtectionMaterials, deriveMaterial, mix32 } = require("../protection/byte_blinder");
const { buildV455Personality, buildV46Personality } = require("../obfuscation/vm_personality");
const { morphEncode } = require("../obfuscation/representation_morph");
const { buildMorphPlan, buildInstructionLayoutPlan } = require("../obfuscation/representation_morph");
const { createCallRegistry, executeLPS, validatePayloadDirectory } = require("../lps");
const { encodeSynchronizedPayload } = require("../vm/veil_sync");
const { VEIL_STR_TAG, VEIL_STR_ALGORITHM, encryptConstant } = require("../obfuscation/veil_str");
const { isFloatOperand } = require("../compiler/number_operand");

function luaDataString(value) {
    const bytes = Buffer.from(String(value), "utf8");
    let out = '"';
    for (const b of bytes) {
        out += `\\${String(b).padStart(3, "0")}`;
    }
    return out + '"';
}

function luaValue(value) {
    if (value && value.__chunk) return chunkValue(value.__chunk);
    if (typeof value === "string") return luaDataString(value);
    if (value === null || value === undefined) return "nil";
    if (value === true) return "true";
    if (value === false) return "false";
    if (typeof value === "number" && Number.isFinite(value)) return String(value);
    return "nil";
}

function chunkValue(chunk) {
    const code = (chunk.code || []).map(i => `{${i.join(",")}}`).join(",");
    const consts = (chunk.consts || []).map(luaValue).join(",");
    const params = (chunk.params || []).map(luaDataString).join(",");
    return `{p={${params}},c={${code}},k={${consts}},v=${chunk.vararg ? "true" : "false"}}`;
}

/*
 * VM-first transport format.
 *
 * The plaintext bytecode/constant pool never appears in the generated
 * Luau output. It is packed into a compact binary stream, then XOR/rot
 * mixed with a per-build key.
 *
 * Format:
 *   chunk:
 *     const-count (varuint)
 *     constants:
 *       S + length + UTF-8 bytes
 *       N + length + ASCII number
 *       T
 *       F
 *       Z
 *       C + recursive chunk
 *     param-count (varuint)
 *     params: length + UTF-8 bytes
 *     vararg: 0/1
 *     instruction-count (varuint)
 *     instructions:
 *       operand-count (varuint)
 *       operands: signed-varints
 */

function writeUVarint(out, value) {
    let n = Number(value);
    if (!Number.isSafeInteger(n) || n < 0) {
        throw new Error("writeUVarint expects a non-negative safe integer");
    }

    while (n >= 0x80) {
        out.push((n % 0x80) + 0x80);
        n = Math.floor(n / 0x80);
    }

    out.push(n);
}

function encodePayloadShardText(bytes) {
    const input = Array.from(bytes || [], (value) => Number(value) & 0xFF);
    let output = "";
    for (let offset = 0; offset < input.length; offset += 4) {
        const a = input[offset] || 0;
        const b = input[offset + 1] || 0;
        const c = input[offset + 2] || 0;
        const d = input[offset + 3] || 0;
        let value = a * 0x1000000 + b * 0x10000 + c * 0x100 + d;
        const digits = new Array(5);
        for (let index = 4; index >= 0; index--) {
            digits[index] = PAYLOAD_ALPHABET[value % PAYLOAD_RADIX];
            value = Math.floor(value / PAYLOAD_RADIX);
        }
        output += digits.join("");
    }
    return output;
}

function writeU32Varint(out, value) {
    writeUVarint(out, Number(value) >>> 0);
}

function writeU32Array(out, values) {
    const array = Array.isArray(values) ? values : [];
    writeUVarint(out, array.length);
    for (const value of array) writeU32Varint(out, value);
}

/*
 * v4.7.9 packed region descriptor. Region fields are carried in a compact
 * binary stream instead of emitting a readable Lua object tree and a 62-entry
 * route array for every region. This is an independent format, not a copy of
 * any third-party obfuscator format.
 */
function encodeV479Descriptor(regionEntries, payloadDirectory) {
    const bytes = [0x42, 0x56, 0x52, 0x44, 1]; // BVRD / format 1
    writeUVarint(bytes, regionEntries.length);
    for (const region of regionEntries) {
        const scalarValues = [
            region.id, region.start, region.length, region.token, region.checksum,
            region.state, region.variant, region.resolverFamily, region.variantSeed,
            region.personality, region.representation, region.constantRepresentation,
            region.instructionRepresentation, region.controlRepresentation,
            region.representationSeed, region.instructionLayout,
            region.architectureFamily, region.secondaryArchitecture,
            region.materializationFamily, region.shardMaskSeed
        ];
        for (const value of scalarValues) writeU32Varint(bytes, value);
        writeU32Array(bytes, region.deps);
        writeU32Array(bytes, region.route);
        writeU32Array(bytes, region.vocabulary);
        writeU32Array(bytes, region.globalShardOrder);
        writeU32Array(bytes, region.container?.lengths);
    }
    writeUVarint(bytes, payloadDirectory.length);
    for (const entry of payloadDirectory) {
        writeU32Varint(bytes, entry.lane);
        writeU32Varint(bytes, entry.offset);
        writeU32Varint(bytes, entry.length);
    }
    return encodePayloadShardText(bytes);
}

function writeSVarint(out, value) {
    if (isFloatOperand(value)) {
        /*
         * Float literal (5.0, 1e3, 0x1p4). Same ASCII path the non-integer branch below uses, so
         * the host reads it with tonumber() and keeps the float subtype instead of collapsing it
         * into an integer. The text is engine-generated and shape-checked, never caller input.
         */
        const bytes = Buffer.from(value.text, "ascii");

        out.push(1);
        writeUVarint(out, bytes.length);

        for (const b of bytes) {
            out.push(b);
        }
        return;
    }

    const n = Number(value);

    if (Number.isInteger(n) && Number.isSafeInteger(n)) {
        const zig = n < 0
            ? (-n * 2) - 1
            : n * 2;

        out.push(0);
        writeUVarint(out, zig);
        return;
    }

    /*
     * Non-integer number marker.
     * Decimal ASCII stays inside the encrypted blob.
     */
    const text = String(n);
    const bytes = Buffer.from(text, "ascii");

    out.push(1);
    writeUVarint(out, bytes.length);

    for (const b of bytes) {
        out.push(b);
    }
}

function writeBytes(out, value) {
    const bytes = Buffer.from(String(value), "utf8");

    writeUVarint(out, bytes.length);

    for (const b of bytes) {
        out.push(b);
    }
}

function writeChunk(out, chunk, opcodeMask = 0, cipher = null, traversal = null) {
    const walk = traversal || { seq: 1, constants: 0, cipheredBytes: 0 };
    const chunkSeq = walk.seq++;
    const consts = Array.isArray(chunk?.consts)
        ? chunk.consts
        : [];

    writeUVarint(out, consts.length);

    for (let constantIndex = 0; constantIndex < consts.length; constantIndex++) {
        const value = consts[constantIndex];
        if (value && value.__chunk) {
            out.push(67); // C
            writeChunk(out, value.__chunk, opcodeMask, cipher, walk);
            continue;
        }

        if (typeof value === "string") {
            if (cipher) {
                // VeilStr-v1: per-constant keystream keyed by the build's material root,
                // plus a fold of the plaintext bytes so a wrong key dies on the read
                // instead of returning garbage the program then prints.
                const sealed = encryptConstant(value, {
                    materialRoot: cipher.materialRoot,
                    chunkSeq,
                    index: constantIndex
                });
                out.push(VEIL_STR_TAG); // U
                writeUVarint(out, sealed.cipher.length);
                out.push(sealed.check);
                for (const b of sealed.cipher) out.push(b);
                walk.constants++;
                walk.cipheredBytes += sealed.plainLength;
                continue;
            }
            out.push(83); // S
            writeBytes(out, value);
            continue;
        }

        if (typeof value === "number" && Number.isFinite(value)) {
            out.push(78); // N
            writeSVarint(out, value);
            continue;
        }

        if (value === true) {
            out.push(84); // T
            continue;
        }

        if (value === false) {
            out.push(70); // F
            continue;
        }

        out.push(90); // Z = nil
    }

    const params = Array.isArray(chunk?.params)
        ? chunk.params
        : [];

    writeUVarint(out, params.length);

    for (const param of params) {
        writeBytes(out, param);
    }

    out.push(chunk?.vararg ? 1 : 0);

    const code = Array.isArray(chunk?.code)
        ? chunk.code
        : [];

    writeUVarint(out, code.length);

    for (const instruction of code) {
        const item = Array.isArray(instruction)
            ? instruction
            : [];

        writeUVarint(out, item.length);

        for (let operandIndex = 0; operandIndex < item.length; operandIndex++) {
            let operand = item[operandIndex];
            // v3.4 opcode whitening: only the opcode field is transformed.
            // Operands stay byte-for-byte compatible with the existing VM.
            if (operandIndex === 0 && Number.isInteger(operand) && opcodeMask) {
                operand = (operand >>> 0) ^ opcodeMask;
            }
            writeSVarint(out, operand);
        }
    }

    return walk;
}

function normalizeMaterials(input) {
    if (Array.isArray(input)) return input.map((v) => Number(v) >>> 0);
    if (input && typeof input === "object") {
        return [input.payloadA, input.payloadB, input.payloadC, input.payloadD]
            .map((v) => Number(v) >>> 0);
    }
    const seed = Number(input) >>> 0;
    return [seed, mix32(seed, 0xB3), mix32(seed, 0xC7), mix32(seed, 0xD9)];
}

function deriveOpcodeMask(material) {
    let s = (Number(material) >>> 0) ^ 0xD3C4A7B1;
    s = Math.imul(s ^ (s >>> 16), 2246822519) >>> 0;
    s = Math.imul(s ^ (s >>> 13), 3266489917) >>> 0;
    let mask = (s ^ (s >>> 8) ^ (s >>> 24)) & 0xFF;
    if (mask === 0) mask = 0x5A;
    return mask;
}

function deriveByteMask(material, index, lane) {
    const domain = (0x51ED2708 + Math.imul(lane + 1, 0x45D9F3B) + Math.imul(index + 1, 0x27D4EB2F)) >>> 0;
    return mix32(Number(material) >>> 0, domain) & 0xFF;
}

function transformBytes(bytes, materialsInput) {
    const materials = normalizeMaterials(materialsInput);
    if (materials.length < 4) throw new Error("ByteVeil v4.4.0 serializer: four payload materials required");
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] ^ deriveByteMask(materials[0], i, 0)) & 0xFF;
        out[i] = (out[i] + deriveByteMask(materials[1], i, 1)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[2], i, 2)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[3], i, 3) + 256) & 0xFF;
    }
    return { bytes: out };
}

function inverseTransformBytes(bytes, materialsInput) {
    const materials = normalizeMaterials(materialsInput);
    if (materials.length < 4) throw new Error("ByteVeil v4.4.0 serializer: four payload materials required");
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] + deriveByteMask(materials[3], i, 3)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[2], i, 2)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[1], i, 1) + 256) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[0], i, 0)) & 0xFF;
    }
    return out;
}

// v4.7.5 moves the protection depth into the binary regions instead of nesting
// executable Lua source. Eight reversible byte transforms run before the
// region permutation and protected-shard transport.
function transformBytesV475(bytes, materialsInput) {
    const materials = Array.isArray(materialsInput) ? materialsInput.map((v) => Number(v) >>> 0) : normalizeMaterials(materialsInput);
    if (materials.length < 8) throw new Error("ByteVeil v4.7.5 serializer: eight payload materials required");
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] ^ deriveByteMask(materials[0], i, 0)) & 0xFF;
        out[i] = (out[i] + deriveByteMask(materials[1], i, 1)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[2], i, 2)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[3], i, 3) + 256) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[4], i, 4)) & 0xFF;
        out[i] = (out[i] + deriveByteMask(materials[5], i, 5)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[6], i, 6)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[7], i, 7) + 256) & 0xFF;
    }
    return { bytes: out };
}

function inverseTransformBytesV475(bytes, materialsInput) {
    const materials = Array.isArray(materialsInput) ? materialsInput.map((v) => Number(v) >>> 0) : normalizeMaterials(materialsInput);
    if (materials.length < 8) throw new Error("ByteVeil v4.7.5 serializer: eight payload materials required");
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] + deriveByteMask(materials[7], i, 7)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[6], i, 6)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[5], i, 5) + 256) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[4], i, 4)) & 0xFF;
        out[i] = (out[i] + deriveByteMask(materials[3], i, 3)) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[2], i, 2)) & 0xFF;
        out[i] = (out[i] - deriveByteMask(materials[1], i, 1) + 256) & 0xFF;
        out[i] = (out[i] ^ deriveByteMask(materials[0], i, 0)) & 0xFF;
    }
    return out;
}

function roundTripTransform(bytes, materials) {
    const encoded = transformBytes(bytes, materials).bytes;
    const decoded = inverseTransformBytes(encoded, materials);
    return Buffer.from(decoded).equals(Buffer.from(bytes));
}

function luaByteString(bytes) {
    let out = '"';

    for (let i = 0; i < bytes.length; i++) {
        out +=
            "\\" +
            String(bytes[i]).padStart(3, "0");
    }

    return out + '"';
}

function checksumBytes(bytes) {
    let h = 17;
    for (const b of bytes) {
        h = (h * 65599 + b + 1) % 2147483647;
    }
    return h;
}

function shapeTokenOfBytecode(root) {
    let h = 2166136261 >>> 0;
    const visit = (chunk) => {
        const consts = Array.isArray(chunk?.consts) ? chunk.consts : [];
        const params = Array.isArray(chunk?.params) ? chunk.params : [];
        const code = Array.isArray(chunk?.code) ? chunk.code : [];
        h = Math.imul((h ^ consts.length) >>> 0, 16777619) >>> 0;
        h = Math.imul((h ^ params.length) >>> 0, 16777619) >>> 0;
        h = Math.imul((h ^ code.length) >>> 0, 16777619) >>> 0;
        h = Math.imul((h ^ (chunk?.vararg ? 1 : 0)) >>> 0, 16777619) >>> 0;
        for (const value of consts) {
            const kind = value && value.__chunk ? 67 : typeof value === "string" ? 83 : typeof value === "number" ? 78 : value === true ? 84 : value === false ? 70 : 90;
            h = Math.imul((h ^ kind) >>> 0, 16777619) >>> 0;
            if (value?.__chunk) visit(value.__chunk);
        }
        for (const instruction of code) {
            h = Math.imul((h ^ ((Array.isArray(instruction) ? instruction.length : 0) + 257)) >>> 0, 16777619) >>> 0;
        }
    };
    visit(root || {});
    return h >>> 0;
}


function shapeTokenOfBytecodeV45(root) {
    let h = 2166136261 >>> 0;
    const visit = (chunk) => {
        const consts = Array.isArray(chunk?.consts) ? chunk.consts : [];
        const params = Array.isArray(chunk?.params) ? chunk.params : [];
        const code = Array.isArray(chunk?.code) ? chunk.code : [];
        h = Math.imul((h ^ consts.length) >>> 0, 16777619) >>> 0;
        for (const value of consts) {
            const kind = value && value.__chunk ? 67 : typeof value === "string" ? 83 : typeof value === "number" ? 78 : value === true ? 84 : value === false ? 70 : 90;
            h = Math.imul((h ^ kind) >>> 0, 16777619) >>> 0;
            if (value?.__chunk) visit(value.__chunk);
        }
        h = Math.imul((h ^ params.length) >>> 0, 16777619) >>> 0;
        h = Math.imul((h ^ (chunk?.vararg ? 1 : 0)) >>> 0, 16777619) >>> 0;
        h = Math.imul((h ^ code.length) >>> 0, 16777619) >>> 0;
        for (const instruction of code) {
            h = Math.imul((h ^ ((Array.isArray(instruction) ? instruction.length : 0) + 257)) >>> 0, 16777619) >>> 0;
        }
    };
    visit(root || {});
    return h >>> 0;
}


function u32le(out, value) {
    const v = Number(value) >>> 0;
    out.push(v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF);
}

function deriveTransportSeed(baseSeed, materials) {
    return mix32(
        mix32(baseSeed, (materials.payloadB ^ materials.guard ^ 0x6D2B79F5) >>> 0),
        (materials.codec ^ materials.payloadD ^ 0x51ED2708) >>> 0
    ) >>> 0;
}

function transportByteMask(material, index, lane) {
    const domain = (0x6A09E667 + Math.imul(lane + 1, 0x45D9F3B) + Math.imul(index + 1, 0x27D4EB2F)) >>> 0;
    return mix32(Number(material) >>> 0, domain) & 0xFF;
}

function transportBytes(bytes, seed, materials) {
    const transportSeed = deriveTransportSeed(seed, materials);
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] ^ transportByteMask(transportSeed, i, 0)) & 0xFF;
        out[i] = (out[i] + transportByteMask(materials.payloadA, i, 1)) & 0xFF;
        out[i] = (out[i] ^ transportByteMask(materials.integrity, i, 2)) & 0xFF;
        out[i] = (out[i] - transportByteMask(materials.codec, i, 3) + 256) & 0xFF;
    }
    return out;
}

function inverseTransportBytes(bytes, seed, materials) {
    const transportSeed = deriveTransportSeed(seed, materials);
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        out[i] = (out[i] + transportByteMask(materials.codec, i, 3)) & 0xFF;
        out[i] = (out[i] ^ transportByteMask(materials.integrity, i, 2)) & 0xFF;
        out[i] = (out[i] - transportByteMask(materials.payloadA, i, 1) + 256) & 0xFF;
        out[i] = (out[i] ^ transportByteMask(transportSeed, i, 0)) & 0xFF;
    }
    return out;
}


function permutationParams(length, seed) {
    const n = Number(length) >>> 0;
    if (n <= 1) return { step: 1, offset: 0 };
    let step = (mix32(seed, 0xD1B54A32) % n) | 1;
    step %= n;
    if (step === 0) step = 1;
    const gcd = (a0, b0) => {
        let a = a0;
        let b = b0;
        while (b) {
            const c = a % b;
            a = b;
            b = c;
        }
        return a;
    };
    let guard = 0;
    while (gcd(step, n) !== 1 && guard++ < n + 2) {
        step = (step + 2) % n;
        if (step === 0) step = 1;
    }
    if (gcd(step, n) !== 1) throw new Error("ByteVeil v4.4.0 payload permutation could not find a coprime step");
    const offset = mix32(seed, 0x94D049BB) % n;
    return { step, offset };
}

function permutePayloadBytes(bytes, seed) {
    const input = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    const { step, offset } = permutationParams(input.length, seed);
    const out = new Array(input.length);
    for (let i = 0; i < input.length; i++) {
        const p = (offset + (i * step)) % input.length;
        out[p] = input[i];
    }
    return out;
}

function inversePermutePayloadBytes(bytes, seed) {
    const input = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    const { step, offset } = permutationParams(input.length, seed);
    const out = new Array(input.length);
    for (let i = 0; i < input.length; i++) {
        const p = (offset + (i * step)) % input.length;
        out[i] = input[p];
    }
    return out;
}

function buildPayloadEnvelope(rawBytes, {
    materials,
    seed,
    mode,
    strength,
    shapeToken,
    descriptorSalt,
    opcodeMask
}) {
    const body = Array.from(rawBytes || [], (v) => Number(v) & 0xFF);
    const checksum = checksumBytes(body) >>> 0;
    let binding = mix32(
        materials.integrity,
        (checksum ^ (shapeToken >>> 0) ^ (descriptorSalt >>> 0) ^ (opcodeMask >>> 0) ^ body.length) >>> 0
    ) >>> 0;
    binding = mix32(
        binding,
        (materials.activation ^ materials.guard ^ (seed >>> 0) ^ Math.imul(strength >>> 0, 0x9E3779B1)) >>> 0
    ) >>> 0;
    const transportTag = mix32(
        materials.codec,
        (binding ^ materials.payloadA ^ materials.payloadD ^ (mode === "register" ? 0x13579BDF : 0x2468ACE0)) >>> 0
    ) >>> 0;
    const flags = ((mode === "register" ? 1 : 0) | (strength >= 8000 ? 2 : 0) | (strength >= 10000 ? 4 : 0)) & 0xFF;
    const out = [0x42, 0x56, 0x45, 0x44, 1, flags, 0xA4, 0x7C];
    u32le(out, body.length);
    u32le(out, checksum);
    u32le(out, shapeToken >>> 0);
    u32le(out, binding);
    u32le(out, opcodeMask >>> 0);
    u32le(out, descriptorSalt >>> 0);
    u32le(out, transportTag);
    for (const b of body) out.push(b);
    return {
        bytes: out,
        bodyLength: body.length,
        checksum,
        shapeToken: shapeToken >>> 0,
        binding,
        transportTag,
        headerLength: 36,
        flags
    };
}


function v45ReadUVarint(bytes, offset) {
    let p = offset;
    let value = 0;
    let mul = 1;
    while (true) {
        const b = bytes[p++];
        if (b === undefined) throw new Error("ByteVeil v4.5.0 serializer: truncated varint");
        value += (b & 0x7F) * mul;
        if (b < 0x80) return { value, next: p };
        mul *= 128;
        if (mul > Number.MAX_SAFE_INTEGER) throw new Error("ByteVeil v4.5.0 serializer: varint overflow");
    }
}

function v45ReadSVarint(bytes, offset) {
    const marker = bytes[offset];
    if (marker === undefined) throw new Error("ByteVeil v4.5.0 serializer: truncated signed varint");
    if (marker === 0) {
        const x = v45ReadUVarint(bytes, offset + 1);
        const zig = x.value;
        return { value: (zig % 2 === 0) ? Math.floor(zig / 2) : -Math.floor((zig + 1) / 2), next: x.next };
    }
    const len = v45ReadUVarint(bytes, offset + 1);
    return { value: Number(Buffer.from(bytes.slice(len.next, len.next + len.value)).toString("ascii")), next: len.next + len.value };
}

function v45LocateOpcodeFields(bytes) {
    const positions = [];
    let p = 0;
    function readBytesLen() {
        const r = v45ReadUVarint(bytes, p);
        p = r.next + r.value;
    }
    function scanChunk() {
        const cc = v45ReadUVarint(bytes, p); p = cc.next;
        for (let i = 0; i < cc.value; i++) {
            const tag = bytes[p++];
            if (tag === 67) scanChunk();
            else if (tag === 83) readBytesLen();
            else if (tag === VEIL_STR_TAG) {
                const r = v45ReadUVarint(bytes, p);
                p = r.next + 1 + r.value;
            } else if (tag === 78) {
                const marker = bytes[p++];
                const r = v45ReadUVarint(bytes, p);
                p = r.next + (marker === 0 ? 0 : r.value);
            } else if (tag === 84 || tag === 70 || tag === 90) {
                // no payload
            } else throw new Error("ByteVeil v4.5.0 serializer: invalid constant tag while locating opcodes");
        }
        const pc = v45ReadUVarint(bytes, p); p = pc.next;
        for (let i = 0; i < pc.value; i++) readBytesLen();
        p += 1;
        const ic = v45ReadUVarint(bytes, p); p = ic.next;
        for (let i = 0; i < ic.value; i++) {
            const argc = v45ReadUVarint(bytes, p); p = argc.next;
            for (let j = 0; j < argc.value; j++) {
                const field = p;
                const r = v45ReadSVarint(bytes, p);
                p = r.next;
                if (j === 0 && Number.isInteger(r.value)) positions.push({ offset: field, value: r.value });
            }
        }
    }
    scanChunk();
    if (p !== bytes.length) throw new Error(`ByteVeil v4.5.0 serializer: bytecode locator stopped at ${p}/${bytes.length}`);
    return positions;
}

function v45WriteSVarintInPlace(bytes, offset, value) {
    if (!Number.isInteger(value) || !Number.isSafeInteger(value) || value < 0) {
        throw new Error("ByteVeil v4.5.0 serializer: opcode remap requires non-negative safe integer");
    }
    const zig = value * 2;
    if (zig >= 128) throw new Error("ByteVeil v4.5.0 serializer: physical opcode exceeded single-byte varint budget");
    if (bytes[offset] !== 0) throw new Error("ByteVeil v4.5.0 serializer: opcode field is not integer-encoded");
    bytes[offset + 1] = zig;
}

function v45Permutation(count, seed) {
    const u32 = (n) => Number(n) >>> 0;
    const out = Array.from({ length: count }, (_, i) => i);
    let s = u32(seed) || 0x6D2B79F5;
    for (let i = out.length - 1; i > 0; i--) {
        s = mix32(s, i + 1);
        const j = s % (i + 1);
        [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
}

function v45BuildMicroPlan(opNames, seed, regionCount) {
    const names = Array.isArray(opNames) ? opNames.slice() : [];
    const physicalCount = names.length;
    if (!physicalCount) throw new Error("ByteVeil v4.5.0 serializer: empty opcode set");
    const logicalOrder = v45Permutation(physicalCount, seed ^ 0xA7F041);
    const logicalToSlot = new Array(physicalCount);
    for (let i = 0; i < logicalOrder.length; i++) logicalToSlot[logicalOrder[i]] = i + 1;
    const recipeIds = v45Permutation(physicalCount, seed ^ 0xB8E152).map((v) => v + 1);
    const recipeByLogical = recipeIds.slice();
    const regionRoutes = [];
    for (let region = 0; region < regionCount; region++) {
        const p = v45Permutation(physicalCount, mix32(seed ^ 0xC9F263, region + 1));
        const decode = p.slice();
        regionRoutes.push(decode);
    }
    return {
        logicalOrder,
        logicalToSlot,
        recipeByLogical,
        regionRoutes,
        recipeCount: physicalCount
    };
}

function v45RegionCount(length, strength) {
    const target = Number(strength) >= 10000 ? 9 : Number(strength) >= 8000 ? 8 : Number(strength) >= 3500 ? 6 : 5;
    const maxRegions = Math.max(2, Math.min(32, Number(length || 2)));
    return Math.max(2, Math.min(target, maxRegions));
}

function v45DeriveRegionSeed(rootSeed, regionId, token, depState) {
    let s = mix32(rootSeed, token ^ Math.imul(regionId + 1, 0x45D9F3B));
    s = mix32(s, depState ^ 0x9E3779B9);
    return mix32(s, 0xB17E4A31 ^ Math.imul(regionId + 7, 0x27D4EB2F));
}


function v452PermuteRegionBytes(bytes, seed, variant) {
    const input = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    const L = input.length;
    if (L <= 1) return input.slice();
    if (variant === 1) return input.slice().reverse();
    if (variant === 2) {
        const shift = (Number(seed) >>> 0) % L;
        const out = new Array(L);
        for (let i = 0; i < L; i++) out[i] = input[(i + shift) % L];
        return out;
    }
    if (variant === 3) {
        let step = ((Number(seed) >>> 0) % L) | 1;
        if (step === 0) step = 1;
        const gcd = (a, b) => { while (b) { const t = a % b; a = b; b = t; } return a; };
        let guard = 0;
        while (gcd(step, L) !== 1 && guard++ < L + 2) { step = (step + 2) % L || 1; }
        if (gcd(step, L) !== 1) return input.slice().reverse();
        const offset = ((((Number(seed) >>> 0) ^ 0x94D049BB) >>> 0) % L);
        const out = new Array(L);
        for (let i = 0; i < L; i++) out[i] = input[(offset + i * step) % L];
        return out;
    }
    return input.slice();
}

function v452InverseRegionBytes(bytes, seed, variant) {
    const input = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    const L = input.length;
    if (L <= 1) return input.slice();
    if (variant === 1) return input.slice().reverse();
    if (variant === 2) {
        const shift = (Number(seed) >>> 0) % L;
        const out = new Array(L);
        for (let i = 0; i < L; i++) out[(i + shift) % L] = input[i];
        return out;
    }
    if (variant === 3) {
        let step = ((Number(seed) >>> 0) % L) | 1;
        if (step === 0) step = 1;
        const gcd = (a, b) => { while (b) { const t = a % b; a = b; b = t; } return a; };
        let guard = 0;
        while (gcd(step, L) !== 1 && guard++ < L + 2) { step = (step + 2) % L || 1; }
        if (gcd(step, L) !== 1) return input.slice().reverse();
        const offset = ((((Number(seed) >>> 0) ^ 0x94D049BB) >>> 0) % L);
        const out = new Array(L);
        for (let i = 0; i < L; i++) out[(offset + i * step) % L] = input[i];
        return out;
    }
    return input.slice();
}

function encodeBytecodeBlobV45(bytecode, seed, options = {}) {
    const raw = [];
    const strength = Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000));
    const mode = options.mode || bytecode?.mode || "stack";
    const buildSeed = Number(seed) >>> 0;
    const opNames = Array.isArray(bytecode?.opcode) && bytecode.opcode.length ? bytecode.opcode.slice() : OPS.slice();
    const shapeToken = shapeTokenOfBytecodeV45(bytecode);
    const descriptorSalt = Number(bytecode?.descriptorSalt || 0) >>> 0;

    const profile = strength >= 10000 ? { depth: 96, budget: 9 } : strength >= 8000 ? { depth: 64, budget: 7 } : strength >= 3500 ? { depth: 40, budget: 5 } : { depth: 24, budget: 4 };
    let decoyMix = Math.imul((buildSeed ^ shapeToken ^ descriptorSalt) >>> 0, 1664525) >>> 0;
    for (let i = 1; i <= profile.budget; i++) {
        decoyMix = (Math.imul(decoyMix, 1664525) + Math.imul(i, 1013904223) + profile.depth + strength) >>> 0;
        decoyMix = (decoyMix ^ Math.floor(decoyMix / 8192)) >>> 0;
        decoyMix = Math.imul(decoyMix, 2246822519) >>> 0;
        decoyMix = (decoyMix ^ Math.floor(decoyMix / 65536)) >>> 0;
    }
    const rootSeed = (buildSeed ^ decoyMix) >>> 0;
    // The root seed is recoverable from the descriptor shares, so on its own it
    // only obscures where the key comes from. The forge latch adds a number the
    // runtime can only reproduce by re-folding the JunkForge key-bed containers,
    // which removes the region material from anything a share-only dump can build.
    const forgeLatchValue = Number(options.forgeLatch?.value ?? 0) >>> 0;
    // The guard latch is the anti-hook verdict: the runtime reproduces it by re-running
    // the API/library identity fold and the behavioural canaries, so a build whose guard
    // is stubbed out or whose environment was hooked loses the region key as well.
    const guardLatchValue = Number(options.guardLatch?.value ?? 0) >>> 0;
    const materialSeed = (rootSeed + forgeLatchValue + guardLatchValue) % 4294967296;
    // VeilStr-v1 runs on the routes whose constant reader knows tag 85 (the v4.6.5+
    // generator family, which is also every 5.x build). The key is the material root, so a
    // build that loses the key bed or the guard verdict loses every string in the program,
    // not only the region decode.
    const isV452Route = new Set(["4.6.5", "4.6.6", "4.6.7", "4.6.8", "4.7.1", "4.7.2", "4.7.3", "4.7.4", "4.7.5", "4.7.6", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"]).has(options.hardeningVersion);
    const stringCipherPlan = isV452Route && options.stringCipher !== false
        ? { materialRoot: materialSeed }
        : null;
    const chunkWalk = writeChunk(raw, bytecode || {}, 0, stringCipherPlan, null);
    const stringCipher = stringCipherPlan
        ? { algorithm: VEIL_STR_ALGORITHM, applied: true, constants: chunkWalk.constants, cipheredBytes: chunkWalk.cipheredBytes, materialRoot: materialSeed }
        : { algorithm: VEIL_STR_ALGORITHM, applied: false, constants: 0, cipheredBytes: 0, materialRoot: 0 };
    const regionCount = v45RegionCount(raw.length, strength);
    const microPlan = v45BuildMicroPlan(opNames, rootSeed ^ descriptorSalt, regionCount);
    const isV51BuildDiverse = options.hardeningVersion === "5.3.0" || options.hardeningVersion === "5.4.0" || options.hardeningVersion === "5.5.0" || options.hardeningVersion === "5.6.0" || options.hardeningVersion === "5.7.0" || options.hardeningVersion === "5.8.0" || options.hardeningVersion === "5.9.0";
    const isV500 = options.hardeningVersion === "5.0.0" || isV51BuildDiverse;
    const isV479 = options.hardeningVersion === "4.7.9" || isV500;
    const isV475 = options.hardeningVersion === "4.7.5" || options.hardeningVersion === "4.7.6" || options.hardeningVersion === "4.7.7" || options.hardeningVersion === "4.7.8" || isV479;
    const isV46 = new Set(["4.6.1", "4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7", "4.6.8", "4.7.1", "4.7.2", "4.7.3", "4.7.4", "4.7.5", "4.7.6", "4.7.7", "4.7.8", "4.7.9"]).has(options.hardeningVersion) || isV500;
    const buildPersonalityPlan = isV46
        ? buildV46Personality(rootSeed ^ descriptorSalt, mode, options.hardeningVersion)
        : buildV455Personality(rootSeed ^ descriptorSalt, mode);
    const morphPlan = buildMorphPlan(rootSeed ^ buildPersonalityPlan.representationSalt, regionCount, mode, isV46 ? "4.6.3" : "4.5.5");
    const instructionLayoutPlan = isV46 ? buildInstructionLayoutPlan(rootSeed ^ buildPersonalityPlan.topologySalt, regionCount, mode) : [];
    const opPositions = v45LocateOpcodeFields(raw);
    const bounds = [];
    for (let i = 0; i < regionCount; i++) bounds.push(Math.floor((raw.length * i) / regionCount));
    bounds.push(raw.length);
    const regionOf = (offset) => {
        for (let i = 0; i < regionCount; i++) if (offset >= bounds[i] && offset < bounds[i + 1]) return i;
        return regionCount - 1;
    };
    const physicalToLogical = new Array(opNames.length);
    for (let physical = 0; physical < opNames.length; physical++) {
        const name = bytecode?.map?.decode?.[physical] || opNames[physical];
        const logical = opNames.indexOf(name);
        physicalToLogical[physical] = logical >= 0 ? logical : physical;
    }
    const working = raw.slice();
    for (const field of opPositions) {
        const region = regionOf(field.offset);
        const decodeRoute = microPlan.regionRoutes[region];
        const physical = field.value;
        if (!Number.isInteger(physical) || physical < 0 || physical >= physicalToLogical.length) continue;
        const logical = physicalToLogical[physical];
        if (!Number.isInteger(logical) || logical < 0 || logical >= opNames.length) continue;
        let encoded = 0;
        for (let x = 0; x < decodeRoute.length; x++) if (decodeRoute[x] === logical) { encoded = x; break; }
        v45WriteSVarintInPlace(working, field.offset, encoded);
    }

    const regionTokens = Array.from({ length: regionCount }, (_, i) => mix32(rootSeed ^ 0xDA7A5EED, Math.imul(i + 1, 0x9E3779B9)) >>> 0);
    const regionStates = new Array(regionCount);
    const regionEntries = [];
    const verifyEveryRegion = options.hardeningVersion === "5.6.0" || options.hardeningVersion === "5.7.0" || options.hardeningVersion === "5.8.0" || options.hardeningVersion === "5.9.0";
    let encodingRegionsVerified = 0;
    let encodingRoundTripsVerified = 0;
    let encodingPipelineRoundTripsVerified = 0;
    for (let region = 0; region < regionCount; region++) {
        const deps = [];
        if (region > 0) deps.push(region - 1);
        if (region > 2 && (region % 2 === 0)) deps.push(region - 3);
        if (region > 3 && (region % 3 === 0)) deps.push(region - 2);
        const regionVariant = (options.hardeningVersion === "4.5.2" || options.hardeningVersion === "4.5.4" || options.hardeningVersion === "4.5.5" || (options.hardeningVersion === "4.6.1" || options.hardeningVersion === "4.6.2" || options.hardeningVersion === "4.6.3" || options.hardeningVersion === "4.6.4" || (options.hardeningVersion === "4.6.5" || options.hardeningVersion === "4.6.6" || options.hardeningVersion === "4.6.7" || (options.hardeningVersion === "4.6.8" || (options.hardeningVersion === "4.7.1" || (options.hardeningVersion === "4.7.2" || options.hardeningVersion === "4.7.3" || (options.hardeningVersion === "4.7.4" || options.hardeningVersion === "4.7.5" || options.hardeningVersion === "4.7.6" || options.hardeningVersion === "4.7.7" || options.hardeningVersion === "4.7.8" || (options.hardeningVersion === "4.7.9" || isV500))))))))
            ? (mix32(rootSeed ^ descriptorSalt ^ buildPersonalityPlan.topologySalt, regionTokens[region] ^ Math.imul(region + 3, 0x9E3779B1)) % 4)
            : 0;
        const regionResolverFamily = (Number(buildPersonalityPlan.resolverFamily) + regionVariant + region) % (isV46 ? 6 : 4);
        const resolverVariant = (regionVariant + regionResolverFamily) % 4;
        const depOrder = deps.slice();
        let depSeed = 0x13579BDF;
        if (resolverVariant === 1 || resolverVariant === 3) depOrder.reverse();
        if (resolverVariant === 2) depOrder.sort((a, b) => (regionTokens[b] >>> 0) - (regionTokens[a] >>> 0));
        if (resolverVariant === 3) depSeed = 0x2468ACE0;
        const depState = depOrder.reduce((acc, d) => mix32(acc, regionStates[d] ^ regionTokens[d]), depSeed) >>> 0;
        let regionSeed = v45DeriveRegionSeed(materialSeed, region, regionTokens[region], depState);
        regionSeed = mix32(regionSeed, regionResolverFamily ^ 0x4555A11C);
        const materialDomains = isV475
            ? [0xB3, 0xC7, 0xD9, 0xEB, 0xF1, 0xA3, 0x6D, 0x91]
            : [0xB3, 0xC7, 0xD9, 0xEB];
        const mats = materialDomains.map((domain) => deriveMaterial(regionSeed, domain, strength, mode));
        const start = bounds[region];
        const end = bounds[region + 1];
        const plain = working.slice(start, end);
        const represented = isV46
            ? morphEncode(plain, morphPlan.forms[region], regionSeed ^ buildPersonalityPlan.representationSalt ^ Math.imul(region + 1, 0x9E3779B9))
            : Buffer.from(plain);
        const variantSeed = mix32(regionSeed, 0xD1B54A32 ^ Math.imul(region + 11, 0x27D4EB2F)) >>> 0;
        const useRegionPermutation = options.hardeningVersion === "4.5.2" || options.hardeningVersion === "4.5.4" || options.hardeningVersion === "4.5.5" || isV46 || isV500;
        const codecKey = deriveCodecKey(regionSeed, regionTokens[region], variantSeed);
        const verifyRegion = verifyEveryRegion || region === 0;
        const synchronizedRegion = encodeSynchronizedPayload(represented, [
            { id: "region-byte-transform", encode: (bytes) => (isV475 ? transformBytesV475(Array.from(bytes), mats) : transformBytes(Array.from(bytes), mats)).bytes, decode: (bytes) => (isV475 ? inverseTransformBytesV475(bytes, mats) : inverseTransformBytes(bytes, mats)) },
            { id: "region-layout-permutation", encode: (bytes) => useRegionPermutation ? v452PermuteRegionBytes(bytes, variantSeed, regionVariant) : bytes, decode: (bytes) => useRegionPermutation ? v452InverseRegionBytes(bytes, variantSeed, regionVariant) : bytes },
            { id: "region-bytecode-carrier", encode: (bytes) => isV479 ? encodeBytes(bytes, codecKey) : bytes, decode: (bytes) => isV479 ? decodeBytes(bytes, codecKey) : bytes }
        ], { verify: verifyRegion });
        if (verifyRegion) {
            if (synchronizedRegion.roundTripsVerified !== 3 || !synchronizedRegion.pipelineRoundTripVerified) {
                throw new Error(`VeilSync region stage contract failed at region ${region + 1}`);
            }
            encodingRegionsVerified += 1;
            encodingRoundTripsVerified += synchronizedRegion.roundTripsVerified;
            encodingPipelineRoundTripsVerified += synchronizedRegion.pipelineRoundTripVerified ? 1 : 0;
        }
        const stored = Array.from(synchronizedRegion.bytes);
        const containerSeed = mix32(regionSeed, 0x51ED2708 ^ regionTokens[region] ^ regionVariant) >>> 0;
        const shardMaskSeed = mix32(containerSeed, 0xA5C3E7D1 ^ Math.imul(region + 1, 0x45D9F3B) ^ regionVariant) >>> 0;
        const container = makeNumericContainer(stored, containerSeed, {
            shardMaskSeed,
            strength,
            minShard: strength >= 8000 ? 32 : 24,
            maxShard: strength >= 8000 ? 96 : 72,
            decoys: strength >= 10000 ? 2 : strength >= 8000 ? 1 : 0
        });
        const checksum = checksumBytes(plain) >>> 0;
        const stateOut = mix32(regionSeed, checksum ^ (plain.length >>> 0) ^ regionTokens[region]) >>> 0;
        regionStates[region] = stateOut;
        const regionOps = [];
        for (const field of opPositions) {
            const rr = regionOf(field.offset);
            if (rr !== region) continue;
            const physical = field.value;
            const logical = physicalToLogical[physical];
            if (Number.isInteger(logical) && !regionOps.includes(logical)) regionOps.push(logical);
        }
        regionOps.sort((a, b) => a - b);
        const personality = mix32(rootSeed, regionTokens[region] ^ Math.imul(region + 1, 0x85EBCA6B)) >>> 0;
        regionEntries.push({ id: region, start, length: plain.length, token: regionTokens[region], deps, checksum, state: stateOut, resolverFamily: regionResolverFamily, route: microPlan.regionRoutes[region].slice(), container, regionSeed, shardMaskSeed, variant: regionVariant, variantSeed, vocabulary: regionOps, personality, representation: morphPlan.forms[region], constantRepresentation: morphPlan.constantForms[region], instructionRepresentation: morphPlan.instructionForms[region], controlRepresentation: morphPlan.controlForms[region], representationSeed: isV46 ? (regionSeed ^ buildPersonalityPlan.representationSalt ^ Math.imul(region + 1, 0x9E3779B9)) >>> 0 : regionSeed, instructionLayout: isV46 ? instructionLayoutPlan[region] : 0, architectureFamily: isV46 ? buildPersonalityPlan.architectureFamily : 0, secondaryArchitecture: isV46 ? buildPersonalityPlan.secondaryArchitecture : 0, materializationFamily: isV46 ? buildPersonalityPlan.materializationFamily : 0 });
    }

    let graphToken = mix32(rootSeed, shapeToken ^ descriptorSalt ^ working.length);
    for (const r of regionEntries) {
        graphToken = mix32(graphToken, r.id ^ r.start ^ r.length ^ r.token ^ r.checksum);
        for (const d of r.deps) graphToken = mix32(graphToken, d ^ (r.id * 257));
    }
    // No single global root-key literal is emitted. Four independent shares are
    // consumed together at runtime to reconstruct the graph root state.
    const rootShareA = mix32(rootSeed, 0xA17F21C3) >>> 0;
    const rootShareB = mix32(rootSeed, 0x27D4EB2F) >>> 0;
    const rootShareC = mix32(rootSeed, 0x6C8E9CF5) >>> 0;
    const rootShareD = (rootSeed ^ rootShareA ^ rootShareB ^ rootShareC) >>> 0;
    const personality = mix32(rootSeed, shapeToken ^ descriptorSalt ^ 0x6A09E667) >>> 0;
    const physical = v45Permutation(regionEntries.length, mix32(rootSeed, 0xE1F2A3B4 ^ personality)).map((i) => regionEntries[i]);
    let payloadLanes = [];
    let payloadDirectory = [];
    let descriptorBlob = "";
    if (isV479) {
        // Use the LPS planner to permute shard identity, then spread the
        // encoded shards across independent printable lanes. The descriptor
        // stores lane/range references in binary instead of a visible pd table.
        const allSegments = [];
        for (const region of regionEntries) {
            const container = region.container;
            if (!Array.isArray(container.segments) || !Array.isArray(container.order) || !Array.isArray(container.lengths)) {
                throw new Error("shared payload metadata unavailable");
            }
            if (container.order.length !== container.shardCount || container.lengths.length !== container.shardCount) {
                throw new Error("shared payload logical shard metadata is inconsistent");
            }
            const seenPhysical = new Set();
            for (const physicalIndex of container.order) {
                if (!Number.isInteger(physicalIndex) || physicalIndex < 1 || physicalIndex > container.segments.length || seenPhysical.has(physicalIndex)) {
                    throw new Error("shared payload region order is not a valid shard permutation");
                }
                seenPhysical.add(physicalIndex);
            }
            if (container.lengths.some((length) => !Number.isInteger(length) || length < 1)) {
                throw new Error("shared payload logical shard lengths are invalid");
            }
            for (let localIndex = 0; localIndex < container.segments.length; localIndex++) {
                const text = container.segments[localIndex];
                if (typeof text !== "string" || text.length === 0 || [...text].some((character) => !PAYLOAD_ALPHABET_SET.has(character))) {
                    throw new Error("shared payload segment is empty or outside the encoded payload alphabet");
                }
                allSegments.push({ regionId: region.id, localIndex, text });
            }
        }
        const lpsRegistry = createCallRegistry({ "payload.permutation": v45Permutation });
        const layoutProgram = [
            ["CONST", 0, allSegments.length],
            ["CONST", 1, mix32(rootSeed, 0x9D8C3A71 ^ personality)],
            ["CALL", 2, "payload.permutation", [0, 1]],
            ["RET", 2]
        ];
        const layout = executeLPS(layoutProgram, { registry: lpsRegistry, stepLimit: 16 }).value;
        if (!Array.isArray(layout) || layout.length !== allSegments.length) throw new Error("LPS payload planner returned an invalid shard permutation");
        const seenLayout = new Set();
        for (const sourceIndex of layout) {
            if (!Number.isInteger(sourceIndex) || sourceIndex < 0 || sourceIndex >= allSegments.length || seenLayout.has(sourceIndex)) {
                throw new Error("LPS payload planner did not return a bijective shard permutation");
            }
            seenLayout.add(sourceIndex);
        }
        if (seenLayout.size !== allSegments.length) throw new Error("LPS payload planner omitted payload shards");

        const globalIdByRegion = new Map(regionEntries.map((region) => [region.id, new Array(region.container.segments.length)]));
        const laneCount = isV51BuildDiverse
            ? Math.min(12, Math.max(4 + (personality % 5), Math.ceil(Math.sqrt(Math.max(1, allSegments.length))) + ((personality >>> 5) % 5)))
            : Math.min(8, Math.max(4, Math.ceil(Math.sqrt(Math.max(1, allSegments.length)))));
        payloadLanes = Array.from({ length: laneCount }, () => "");
        const nextOffsetByLane = Array.from({ length: laneCount }, () => 1);
        const laneDirectories = Array.from({ length: laneCount }, () => []);
        for (const sourceIndex of layout) {
            const segment = allSegments[sourceIndex];
            const id = payloadDirectory.length + 1;
            const distributionSeed = (Math.imul(id, 0x9E3779B1)
                ^ Math.imul(segment.regionId + 1, 0x45D9F3B)
                ^ Math.imul(segment.localIndex + 1, 0x27D4EB2F)
                ^ personality) >>> 0;
            let laneIndex;
            if (isV51BuildDiverse) {
                // Build v5.1 uses seeded two-choice placement: still deterministic for an
                // explicit seed, but the physical lane assignment differs from the old
                // single-hash bucket rule and tends to avoid severely imbalanced lanes.
                const first = mix32(rootSeed, distributionSeed) % laneCount;
                const second = mix32(rootSeed ^ 0x51A7C0DE, distributionSeed ^ 0xA3B19535) % laneCount;
                const alternative = second === first ? (second + 1 + (distributionSeed % Math.max(1, laneCount - 1))) % laneCount : second;
                laneIndex = nextOffsetByLane[first] <= nextOffsetByLane[alternative] ? first : alternative;
            } else {
                laneIndex = mix32(rootSeed, distributionSeed) % laneCount;
            }
            const offset = nextOffsetByLane[laneIndex];
            const directoryEntry = { lane: laneIndex + 1, offset, length: segment.text.length };
            payloadDirectory.push(directoryEntry);
            laneDirectories[laneIndex].push({ offset, length: segment.text.length });
            payloadLanes[laneIndex] += segment.text;
            nextOffsetByLane[laneIndex] += segment.text.length;
            globalIdByRegion.get(segment.regionId)[segment.localIndex] = id;
        }
        for (let laneIndex = 0; laneIndex < payloadLanes.length; laneIndex++) {
            validatePayloadDirectory(payloadLanes[laneIndex], laneDirectories[laneIndex]);
        }
        for (const region of regionEntries) {
            const physicalOrder = region.container.order;
            if (new Set(physicalOrder).size !== physicalOrder.length) throw new Error("shared payload region order contains duplicate shard references");
            region.globalShardOrder = physicalOrder.map((localPhysicalIndex) => {
                const globalId = globalIdByRegion.get(region.id)[localPhysicalIndex - 1];
                if (!Number.isInteger(globalId) || globalId < 1 || globalId > payloadDirectory.length) throw new Error("shared payload shard reference invalid");
                return globalId;
            });
            if (region.globalShardOrder.length !== region.container.shardCount || new Set(region.globalShardOrder).size !== region.globalShardOrder.length) {
                throw new Error("shared payload region references do not cover each logical shard exactly once");
            }
        }
        descriptorBlob = encodeV479Descriptor(regionEntries, payloadDirectory);
    }
    const regionCode = isV479 ? "" : physical.map((r) =>
        `{id=${r.id},start=${r.start},len=${r.length},tok=${r.token},chk=${r.checksum},st=${r.state},dep={${r.deps.join(",")}},route={${r.route.join(",")}},rv=${r.variant},rf=${r.resolverFamily},rs=${r.variantSeed},ps=${r.personality},voc={${r.vocabulary.join(",")}},rep=${r.representation},cr=${r.constantRepresentation},ir=${r.instructionRepresentation},cf=${r.controlRepresentation},rps=${r.representationSeed},il=${r.instructionLayout},af=${r.architectureFamily},sa=${r.secondaryArchitecture},mf=${r.materializationFamily},data=${r.container.expression},ord=${r.container.orderExpression},sl=${r.container.lengthsExpression},sm=${r.shardMaskSeed}}`
    ).join(",");
    const graphTail = (options.hardeningVersion === "4.5.2" || options.hardeningVersion === "4.5.4" || options.hardeningVersion === "4.5.5" || isV46) ? `,morph={${morphPlan.forms.join(",")}},crep={${morphPlan.constantForms.join(",")}},irep={${morphPlan.instructionForms.join(",")}},cfp={${morphPlan.controlForms.join(",")}},ilp={${instructionLayoutPlan.join(",")}},pbf=${Number(buildPersonalityPlan.pbfFamily||0)},cff=${Number(buildPersonalityPlan.cffFamily||0)},envf=${Number(buildPersonalityPlan.envFamily||0)},personalityVersion=${JSON.stringify(buildPersonalityPlan.version)}` : `,slots={${microPlan.logicalToSlot.join(",")}},recipeIds={${microPlan.recipeByLogical.join(",")}}`;
    const graphVersion = (options.hardeningVersion === "4.5.2" || options.hardeningVersion === "4.5.4") ? 2 : (options.hardeningVersion === "4.5.5" ? 3 : (isV46 ? 4 : 1));
    // v4.7.9 payload transport is deliberately not embedded in the graph as
    // one pl={...},rd="..." block. Split every lane and the descriptor into
    // independently addressable source carriers; the VM generator distributes
    // those carriers among generated runtime definitions and reassembles them
    // lazily only when a region is needed.
    const payloadCarriers = [];
    const payloadLaneCarrierSlots = Array.from({ length: payloadLanes.length }, () => []);
    const payloadDescriptorCarrierSlots = [];
    if (isV479) {
        const isV580 = options.hardeningVersion === "5.8.0" || options.hardeningVersion === "5.9.0";
        const alphabetSize = PAYLOAD_ALPHABET.length;
        const gcd = (a, b) => { while (b) { const t = a % b; a = b; b = t; } return a; };
        const shuffleIndices = (count, seed0) => {
            const arr = Array.from({ length: count }, (_, i) => i);
            let s = seed0 >>> 0;
            for (let i = arr.length - 1; i > 0; i--) {
                s = mix32(s, i + 97);
                const j = s % (i + 1);
                [arr[i], arr[j]] = [arr[j], arr[i]];
            }
            return arr;
        };
        const variantPerm = shuffleIndices(4, (rootSeed ^ descriptorSalt ^ 0x58C0DE) >>> 0);
        const encodeCarrierFragment = (plain, slot, kind, lane, logicalOffset, fragIdx) => {
            const salt = (kind === "descriptor" ? 0xD35C91A7 : Math.imul((lane + 1) >>> 0, 0x45D9F3B)) >>> 0;
            let multiplier = 2 + (mix32(rootSeed, (Math.imul(slot + 1, 0x9E3779B1) ^ salt ^ descriptorSalt) >>> 0) % (alphabetSize - 2));
            while (gcd(multiplier, alphabetSize) !== 1) multiplier = multiplier >= alphabetSize - 1 ? 2 : multiplier + 1;
            let inverseMultiplier = 1;
            while ((multiplier * inverseMultiplier) % alphabetSize !== 1) inverseMultiplier++;
            const decodeOffset = mix32(rootSeed ^ descriptorSalt, (Math.imul(slot + 7, 0x27D4EB2F) ^ salt ^ 0xA17F21C3) >>> 0) % alphabetSize;
            const reversed = (mix32(rootSeed, (Math.imul(slot + 13, 0x85EBCA6B) ^ salt ^ shapeToken) >>> 0) & 1) === 1;

            // v5 uses a build/slot/lane-bound stream that changes at each
            // character; v5.8 couples non-linear autokey + ciphertext feedback.
            const streamSalt = (Math.imul(slot + 1, 0x85EBCA6B) ^ salt ^ Math.imul(logicalOffset + 1, 0x27D4EB2F) ^ shapeToken) >>> 0;
            const streamSeed = mix32(rootSeed ^ descriptorSalt, (Math.imul(slot + 1, 0x9E3779B1) ^ salt ^ Math.imul(logicalOffset + 1, 0x45D9F3B) ^ shapeToken) >>> 0);
            const decodeVariant = isV500
                ? (isV580 && fragIdx < 4 ? variantPerm[fragIdx] : (mix32(streamSeed, streamSalt ^ descriptorSalt) % 4))
                : null;
            let state = streamSeed;
            let prev = isV580 ? (((streamSalt ^ descriptorSalt) >>> 0) % alphabetSize) : 0;
            const mapped = Array.from(plain, (character, index) => {
                const charIndex = PAYLOAD_ALPHABET.indexOf(character);
                if (charIndex < 0) throw new Error("ByteVeil payload carrier invariant failed: alphabet mismatch");
                if (!isV500) return PAYLOAD_ALPHABET[(Math.imul(multiplier, charIndex) + decodeOffset) % alphabetSize];

                const stepBase = (Math.imul(index + 1, 0x9E3779B1) ^ streamSalt) >>> 0;
                const step = isV580 ? ((stepBase ^ Math.imul(prev + 1, 0x45D9F3B)) >>> 0) : stepBase;
                if (decodeVariant === 0) state = mix32(state, step);
                else if (decodeVariant === 1) state = mix32((state ^ step) >>> 0, 0xA5D3C7E9);
                else if (decodeVariant === 2) state = mix32(state, mix32(step, 0x9E3779B9));
                else state = (mix32((state ^ 0xC0FFEE11) >>> 0, step) ^ step) >>> 0;
                const mask = state % alphabetSize;
                const encodedIndex = (Math.imul(multiplier, charIndex) + decodeOffset + mask) % alphabetSize;
                if (isV580) prev = (charIndex * 13 + encodedIndex * 7 + index) % alphabetSize;
                return PAYLOAD_ALPHABET[encodedIndex];
            });
            if (reversed) mapped.reverse();
            return {
                slot, kind, lane, offset: logicalOffset, text: mapped.join(""),
                decodeMultiplier: inverseMultiplier, decodeOffset, reversed,
                codecVersion: isV51BuildDiverse ? "position-keyed-four-family-v5.1-build-diverse" : isV500 ? "position-keyed-four-family-v5" : "affine-carrier-v479",
                ...(isV500 ? { streamSeed, streamSalt, decodeVariant } : {})
            };
        };
        const rawFragments = [];
        let fragSeq = 0;
        const nextFragmentStep = (seq, kindSalt) => {
            if (!isV580) return 192;
            return 96 + (mix32(rootSeed ^ descriptorSalt, (Math.imul(seq + 1, 0x9E3779B1) ^ kindSalt) >>> 0) % 97);
        };
        for (let laneIndex = 0; laneIndex < payloadLanes.length; laneIndex++) {
            const lane = payloadLanes[laneIndex];
            let offset = 0;
            while (offset < lane.length) {
                const stepLen = nextFragmentStep(fragSeq++, Math.imul(laneIndex + 1, 0x45D9F3B));
                rawFragments.push({
                    slice: lane.slice(offset, offset + stepLen),
                    kind: "lane",
                    laneIndex,
                    lane: laneIndex + 1,
                    offset
                });
                offset += stepLen;
            }
        }
        {
            let offset = 0;
            while (offset < descriptorBlob.length) {
                const stepLen = nextFragmentStep(fragSeq++, 0xD35C91A7);
                rawFragments.push({
                    slice: descriptorBlob.slice(offset, offset + stepLen),
                    kind: "descriptor",
                    laneIndex: -1,
                    lane: 0,
                    offset
                });
                offset += stepLen;
            }
        }
        const slotPool = isV580
            ? shuffleIndices(rawFragments.length, (rootSeed ^ descriptorSalt ^ 0x585107) >>> 0).map((idx) => idx + 1)
            : Array.from({ length: rawFragments.length }, (_, i) => i + 1);
        for (let i = 0; i < rawFragments.length; i++) {
            const frag = rawFragments[i];
            const slot = slotPool[i];
            const carrier = encodeCarrierFragment(frag.slice, slot, frag.kind, frag.lane, frag.offset, i);
            payloadCarriers.push(carrier);
            if (frag.kind === "lane") {
                payloadLaneCarrierSlots[frag.laneIndex].push(slot);
            } else {
                payloadDescriptorCarrierSlots.push(slot);
            }
        }
    }
    const sharedPayloadTail = "";
    const regionsTail = isV479 ? "" : `,regions={${regionCode}}`;
    const graphExpression = `{v=${graphVersion},n=${regionEntries.length},len=${working.length},shape=${shapeToken},ds=${descriptorSalt},token=${graphToken},personality=${personality},shares={${rootShareA},${rootShareB},${rootShareC},${rootShareD}}${regionsTail}${sharedPayloadTail}${graphTail}}`;
    return {
        graph: graphExpression,
        regionCount,
        regionShards: regionEntries.reduce((n, r) => n + r.container.shardCount, 0),
        regionEntries: regionEntries.reduce((n, r) => n + r.container.entryCount, 0),
        regionDecoys: regionEntries.reduce((n, r) => n + r.container.decoyCount, 0),
        payloadByteLength: working.length,
        stringCipher,
        encodingEngine: ["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? "VeilSync-v2" : null,
        encodingStages: ["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? ["region-byte-transform", "region-layout-permutation", "region-bytecode-carrier"] : [],
        encodingRoundTripsVerified: ["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? encodingRoundTripsVerified : 0,
        encodingRegionsVerified: ["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? encodingRegionsVerified : 0,
        encodingPipelineRoundTripsVerified: ["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? encodingPipelineRoundTripsVerified : 0,
        payloadLayout: isV51BuildDiverse ? (["5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(options.hardeningVersion) ? (options.hardeningVersion === "5.9.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : options.hardeningVersion === "5.8.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.8-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : options.hardeningVersion === "5.7.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.7-callable-bootstrap-region-verified" : "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-veilsync-v2-region-verified") : "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse") : isV500 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5" : (isV479 ? "striped-payload-lanes-packed-descriptor-lazy-region-v479" : "per-region-sharded-v478"),
        payloadCarrierCodec: isV51BuildDiverse ? "position-keyed-four-family-alphabet-stream-v5.1-build-diverse" : isV500 ? "position-keyed-four-family-alphabet-stream-v5" : (isV479 ? "affine-carrier-v479" : null),
        payloadCarriers: isV479 ? payloadCarriers : [],
        payloadCarrierCount: isV479 ? payloadCarriers.length : 0,
        payloadLaneCarrierSlots: isV479 ? payloadLaneCarrierSlots : [],
        payloadDescriptorCarrierSlots: isV479 ? payloadDescriptorCarrierSlots : [],
        lpsPayloadPlanner: isV51BuildDiverse ? "LPS-bytecode-registry-build-diverse-payload-layout-v5.1" : isV500 ? "LPS-bytecode-registry-payload-layout-v5" : isV479 ? "LPS-bytecode-registry-payload-layout-v479" : null,
        payloadDirectoryValidatedByLPS: isV479,
        payloadBlobChars: isV479 ? payloadLanes.reduce((total, lane) => total + lane.length, 0) : 0,
        payloadLaneCount: isV479 ? payloadLanes.length : 0,
        payloadDescriptorChars: isV479 ? descriptorBlob.length : 0,
        payloadDirectoryEntries: isV479 ? payloadDirectory.length : 0,
        // Runtime integrity expectations for the exact reassembled ASCII lanes. Both
        // chains of the dual digest travel with the record so a rewritten walk order in
        // the validator cannot keep the forward number intact.
        payloadLaneIntegrity: isV479 ? payloadLanes.map((lane, index) => {
            const digest = require("../anti/anti_tamper").checksumBytesV2(Buffer.from(lane, "ascii"), Number(seed) >>> 0);
            return {
                lane: index + 1,
                checksum: digest.hash,
                mirrorChecksum: digest.mirror,
                length: Buffer.byteLength(lane, "ascii")
            };
        }) : [],
        payloadDescriptorIntegrity: isV479 ? (() => {
            const digest = require("../anti/anti_tamper").checksumBytesV2(Buffer.from(descriptorBlob, "ascii"), Number(seed) >>> 0);
            return {
                checksum: digest.hash,
                mirrorChecksum: digest.mirror,
                length: Buffer.byteLength(descriptorBlob, "ascii")
            };
        })() : null,
        rootSeed,
        shapeToken,
        graphToken,
        descriptorSalt,
        opcodeMask: 0,
        microPlan,
        transformedOpcodeCount: opPositions.length,
        graphVersion: (options.hardeningVersion === "4.5.2" || options.hardeningVersion === "4.5.4") ? 2 : (options.hardeningVersion === "4.5.5" ? 3 : ((options.hardeningVersion === "4.6.1" || options.hardeningVersion === "4.6.2" || options.hardeningVersion === "4.6.3" || options.hardeningVersion === "4.6.4" || (options.hardeningVersion === "4.6.5" || options.hardeningVersion === "4.6.6" || options.hardeningVersion === "4.6.7" || (options.hardeningVersion === "4.6.8" || (options.hardeningVersion === "4.7.1" || (options.hardeningVersion === "4.7.2" || options.hardeningVersion === "4.7.3" || (options.hardeningVersion === "4.7.4" || options.hardeningVersion === "4.7.5" || options.hardeningVersion === "4.7.6" || options.hardeningVersion === "4.7.7" || options.hardeningVersion === "4.7.8" || (options.hardeningVersion === "4.7.9" || isV500))))))) ? 4 : 1)),
        hardeningVersion: options.hardeningVersion || "4.5.4",
        payloadTransformLayers: isV475 ? 8 : 4,
        nativeBufferRuntime: isV475,
        buildPersonality: personality,
        vmPersonalityPlan: buildPersonalityPlan,
        regionVariants: regionEntries.map((r) => r.variant),
        regionVocabulary: regionEntries.map((r) => r.vocabulary.slice()),
        regionRepresentations: morphPlan.forms.slice(),
        regionConstantRepresentations: morphPlan.constantForms.slice(),
        regionInstructionRepresentations: morphPlan.instructionForms.slice(),
        regionControlRepresentations: morphPlan.controlForms.slice(),
        regionInstructionLayouts: instructionLayoutPlan.slice(),
        regionResolverFamilies: regionEntries.map((r) => r.resolverFamily),
        vmResolverFamily: buildPersonalityPlan.resolverFamily,
        vmRepresentationStyle: buildPersonalityPlan.representationStyle,
        vmStateModel: buildPersonalityPlan.stateModel,
        vmCommitStyle: buildPersonalityPlan.commitStyle,
        representationMorphing: options.hardeningVersion === "4.5.5" || (options.hardeningVersion === "4.6.1" || options.hardeningVersion === "4.6.2" || options.hardeningVersion === "4.6.3" || options.hardeningVersion === "4.6.4" || (options.hardeningVersion === "4.6.5" || options.hardeningVersion === "4.6.6" || options.hardeningVersion === "4.6.7" || (options.hardeningVersion === "4.6.8" || (options.hardeningVersion === "4.7.1" || (options.hardeningVersion === "4.7.2" || options.hardeningVersion === "4.7.3" || (options.hardeningVersion === "4.7.4" || options.hardeningVersion === "4.7.5" || options.hardeningVersion === "4.7.6" || options.hardeningVersion === "4.7.7" || options.hardeningVersion === "4.7.8" || ((options.hardeningVersion === "4.7.9" || isV500)))))))),
        actualRepresentationMorphing: isV46,
        vmArchitectureFamily: isV46 ? buildPersonalityPlan.architectureFamily : 0,
        vmSecondaryArchitecture: isV46 ? buildPersonalityPlan.secondaryArchitecture : 0,
        vmMaterializationFamily: isV46 ? buildPersonalityPlan.materializationFamily : 0,
        vmPbfFamily: isV46 ? buildPersonalityPlan.pbfFamily : 0,
        vmCffFamily: isV46 ? buildPersonalityPlan.cffFamily : 0,
        vmEnvFamily: isV46 ? buildPersonalityPlan.envFamily : 0,
        __debugRegionData: isV46 ? regionEntries.map((r) => ({id:r.id,regionSeed:r.regionSeed,representationSeed:r.representationSeed,variantSeed:r.variantSeed,variant:r.variant,resolverFamily:r.resolverFamily,checksum:r.checksum,state:r.state,plain:Buffer.from(working.slice(r.start,r.start+r.length)).toString("hex")})) : undefined
    };
}

function encodeBytecodeBlob(bytecode, seed, options = {}) {
    const raw = [];
    const buildSeed = Number(seed) >>> 0;
    const opNames = Array.isArray(bytecode?.opcode) && bytecode.opcode.length ? bytecode.opcode : OPS.slice();
    const poly = bytecode?.polyPlan || buildISAPlan(opNames, buildSeed ^ 0x38C0DE, { lanes: 4 });
    const polySalt = poly.route.reduce((a, v, i) => (a + ((v + 1) * (i + 3) * 17)) >>> 0, 0) >>> 0;
    const superSalt = Number(bytecode?.superPlan?.dispatchNoise || 0) >>> 0;
    const descriptorSalt = Number(bytecode?.descriptorSalt || 0) >>> 0;
    const strength = Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000));
    const strengthSalt = Math.imul(strength >>> 0, 0x45D9F3B) >>> 0;
    const basePayloadSeed = (buildSeed ^ polySalt ^ superSalt ^ descriptorSalt ^ strengthSalt) >>> 0;
    const shapeToken = shapeTokenOfBytecode(bytecode);
    const mode = options.mode || bytecode?.mode || "stack";
    const profile = strength >= 10000 ? { depth: 96, budget: 9, stages: 4 } : strength >= 8000 ? { depth: 64, budget: 7, stages: 4 } : strength >= 3500 ? { depth: 40, budget: 5, stages: 3 } : { depth: 24, budget: 4, stages: 3 };

    // The decoy accumulator now participates in the real runtime root seed.
    // This keeps the material path coupled to the bounded decoy VM without
    // exposing activation/material constants as direct comparison oracles.
    let decoyMix = Math.imul(
        (basePayloadSeed ^ shapeToken ^ descriptorSalt) >>> 0,
        1664525
    ) >>> 0;
    for (let i = 1; i <= profile.budget; i++) {
        decoyMix = (
            Math.imul(decoyMix, 1664525) +
            Math.imul(i, 1013904223) +
            profile.depth +
            strength
        ) >>> 0;
        decoyMix = (decoyMix ^ Math.floor(decoyMix / 8192)) >>> 0;
        decoyMix = Math.imul(decoyMix, 2246822519) >>> 0;
        decoyMix = (decoyMix ^ Math.floor(decoyMix / 65536)) >>> 0;
    }
    const runtimeRootSeed = (basePayloadSeed ^ decoyMix) >>> 0;
    const materials = deriveProtectionMaterials(runtimeRootSeed, strength, mode);
    const baseMaterials = { ...materials };
    const payloadMaterials = [materials.payloadA, materials.payloadB, materials.payloadC, materials.payloadD];
    const opcodeMask = options.opcodeWhitening === false ? 0 : deriveOpcodeMask(materials.opcode);

    writeChunk(raw, bytecode || {}, opcodeMask);

    const envelope = buildPayloadEnvelope(raw, {
        materials,
        seed: runtimeRootSeed,
        mode,
        strength,
        shapeToken,
        descriptorSalt,
        opcodeMask
    });

    const byteKey = deriveCodecKey(materials.codec, materials.payloadB, runtimeRootSeed);
    const synchronized = encodeSynchronizedPayload(envelope.bytes, [
        { id: "payload-byte-transform", encode: (bytes) => transformBytes(bytes, payloadMaterials).bytes, decode: (bytes) => inverseTransformBytes(bytes, payloadMaterials) },
        { id: "payload-alphabet-codec", encode: (bytes) => encodeBytes(bytes, byteKey), decode: (bytes) => decodeBytes(bytes, byteKey) },
        { id: "payload-secondary-transport", encode: (bytes) => transportBytes(bytes, runtimeRootSeed, materials), decode: (bytes) => inverseTransportBytes(bytes, runtimeRootSeed, materials) },
        { id: "payload-position-permutation", encode: (bytes) => permutePayloadBytes(bytes, runtimeRootSeed), decode: (bytes) => inversePermutePayloadBytes(bytes, runtimeRootSeed) }
    ]);
    const [transformedBytes, encodedBytes, transportedBytes, stagedBytes] = synchronized.stageOutputs;
    const transformed = { bytes: transformedBytes };
    if (synchronized.roundTripsVerified !== 4 || !Buffer.from(synchronized.bytes).equals(Buffer.from(stagedBytes))) {
        throw new Error("VeilSync internal stage contract failed");
    }

    const containerSeed = (materials.payloadC ^ materials.codec ^ runtimeRootSeed) >>> 0;
    const shardMaskSeed = (containerSeed ^ materials.payloadA ^ materials.payloadD ^ materials.guard) >>> 0;
    const container = makePayloadContainer(
        stagedBytes,
        containerSeed,
        {
            format: "opaque85",
            strength,
            shardMaskSeed,
            minShard: Number(options.minShard || (Number(options.strength || 0) >= 8000 ? 16 : Number(options.strength || 0) >= 3500 ? 12 : 8)),
            maxShard: Number(options.maxShard || (Number(options.strength || 0) >= 8000 ? 40 : Number(options.strength || 0) >= 3500 ? 32 : 20)),
            decoys: Number(options.decoys ?? (Number(options.strength || 0) >= 10000 ? Math.max(8, Math.ceil(stagedBytes.length / 48)) : Number(options.strength || 0) >= 8000 ? Math.max(6, Math.ceil(stagedBytes.length / 64)) : Number(options.strength || 0) >= 3500 ? Math.max(4, Math.ceil(stagedBytes.length / 80)) : 3))
        }
    );

    return {
        blob: container.expression,
        order: container.orderExpression,
        alphabet: container.alphabet,
        baseMaterialDomains: { ...baseMaterials },
        materialDomains: {
            activation: materials.activation,
            payloadA: materials.payloadA,
            payloadB: materials.payloadB,
            payloadC: materials.payloadC,
            payloadD: materials.payloadD,
            opcode: materials.opcode,
            codec: materials.codec,
            integrity: materials.integrity,
            guard: materials.guard
        },
        byteLength: envelope.bytes.length,
        bodyByteLength: envelope.bodyLength,
        encodedByteLength: encodedBytes.length,
        transportedByteLength: transportedBytes.length,
        stagedByteLength: stagedBytes.length,
        containerEntries: container.entryCount,
        containerShards: container.shardCount,
        containerDecoys: container.decoyCount,
        checksum: envelope.checksum,
        opcodeMask,
        polyRoute: Array.isArray(poly.route) ? poly.route.slice() : [],
        superCount: Number(bytecode?.superPlan?.planned || 0),
        descriptorSalt,
        basePayloadSeed,
        runtimeRootSeed,
        shapeToken: envelope.shapeToken,
        envelopeVersion: 1,
        payloadLayout: "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-veilsync",
        payloadCarrierCodec: "position-keyed-four-family-alphabet-stream-v5.1-build-diverse",
        envelopeHeaderLength: envelope.headerLength,
        envelopeFlags: envelope.flags,
        crossLayerToken: envelope.binding,
        stageCount: strength >= 8000 ? 4 : 3,
        hardeningVersion: options.hardeningVersion || "5.9.0",
        encodingEngine: synchronized.engine,
        encodingStages: synchronized.trace,
        encodingRoundTripsVerified: synchronized.roundTripsVerified,
        strength
    };
}

module.exports = {
    luaDataString,
    luaValue,
    chunkValue,
    writeUVarint,
    writeSVarint,
    encodeBytecodeBlob,
    encodeBytecodeBlobV45,
    v45BuildMicroPlan,
    normalizeMaterials,
    v452PermuteRegionBytes,
    v452InverseRegionBytes,
    transformBytes,
    inverseTransformBytes,
    transformBytesV475,
    inverseTransformBytesV475,
    roundTripTransform,
    checksumBytes,
    shapeTokenOfBytecode,
    shapeTokenOfBytecodeV45,
    deriveOpcodeMask,
    transportBytes,
    inverseTransportBytes,
    buildPayloadEnvelope,
    deriveTransportSeed,
    permutationParams,
    permutePayloadBytes,
    inversePermutePayloadBytes
};
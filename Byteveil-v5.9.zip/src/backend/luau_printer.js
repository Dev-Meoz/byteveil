"use strict";

const { minify } = require("../wrappers/WrapInFunction");

function quote(value) {
    const s = String(value);
    // Values marked by string_obfuscator already contain Lua decimal escapes.
    if (/^(?:\\\d{3})+$/.test(s)) return `"${s}"`;
    return JSON.stringify(s);
}

function print(node) {
    if (!node) return "nil";
    switch (node.type) {
        case "Chunk":
            return node.body.map(printStatement).join(";");
        case "Id": return node.name;
        case "Number": {
            // Preserve the lexer spelling on source-route output. This is
            // essential for integers above JS safe-range and hexadecimal
            // floating literals whose exact source value cannot be represented
            // faithfully by a JavaScript Number.
            if (typeof node.raw === "string" && node.raw.length > 0) return node.raw;
            return Number.isFinite(node.value) ? String(node.value) : "0";
        }
        case "String": return quote(node.value);
        case "Boolean": return node.value ? "true" : "false";
        case "Nil": return "nil";
        case "Vararg": return "...";
        case "Binary": return `(${print(node.left)}${node.op}${print(node.right)})`;
        case "Unary": return `(${node.op} ${print(node.arg)})`;
        case "Index": return `${print(node.obj)}[${print(node.key)}]`;
        case "Call": {
            const args = (node.args || []).map(print).join(",");
            if (node.method && node.callee && node.callee.type === "Index" && node.callee.key && node.callee.key.type === "String") {
                return `${print(node.callee.obj)}:${node.callee.key.value}(${args})`;
            }
            const callee = print(node.callee);
            return `${callee}(${args})`;
        }
        case "FunctionExpr": {
            const params = (node.params || []).join(",");
            const dots = node.vararg ? (params ? ",..." : "...") : "";
            const body = (node.body || []).map(printStatement).join(";");
            return `function(${params}${dots})${body ? body + ";" : ""}end`;
        }
        case "Table": {
            const fields = (node.fields || []).map((f, i) => {
                if (f.key) return `[${print(f.key)}]=${print(f.value)}`;
                return print(f.value);
            });
            return `{${fields.join(",")}}`;
        }
        default:
            throw new Error(`Luau printer: unsupported expression node ${String(node.type)}`);
    }
}

function printStatement(node) {
    if (!node) return "";
    switch (node.type) {
        case "Local": {
            const vars = (node.vars || []).map(v => typeof v === "string" ? v : (v && v.type === "Id" ? v.name : print(v))).join(",");
            const values = (node.values || []).map(print).join(",");
            return values ? `local ${vars}=${values}` : `local ${vars}`;
        }
        case "LocalFunction":
            const body = (node.fn.body || []).map(printStatement).join(";");
            return `local function ${node.name}(${(node.fn.params || []).join(",")}${node.fn.vararg ? ((node.fn.params || []).length ? ",..." : "...") : ""})${body ? body + ";" : ""}end`;
        case "Function": {
            const path = Array.isArray(node.namePath) && node.namePath.length
                ? node.namePath
                : null;
            const fn = node.fn || {};
            const params = (fn.params || []).slice(node.method ? 1 : 0).join(",");
            const dots = fn.vararg ? (params ? ",..." : "...") : "";
            const body = (fn.body || []).map(printStatement).join(";");
            if (path) {
                const methodPart = path.find((part) => part.type === "method");
                if (methodPart) {
                    const owner = path.slice(0, -1).map((part) => part.value).join(".");
                    return `function ${owner}:${methodPart.value}(${params}${dots})${body ? body + ";" : ""}end`;
                }
                const fullName = path.map((part) => part.value).join(".");
                return `${fullName}=function(${params}${dots})${body ? body + ";" : ""}end`;
            }
            return `${node.name}=function(${params}${dots})${body ? body + ";" : ""}end`;
        }
        case "Assign":
            return `${(node.vars || []).map(print).join(",")}=${(node.values || []).map(print).join(",")}`;
        case "Compound":
            return `${print(node.left)}${node.op}${print(node.value)}`;
        case "CallStmt": return print(node.call);
        case "Return":
            return node.values && node.values.length ? `return ${(node.values || []).map(print).join(",")}` : "return";
        case "Break": return "break";
        case "If": {
            let out = "";
            for (let i = 0; i < node.branches.length; i++) {
                const b = node.branches[i];
                const body = (b.body || []).map(printStatement).join(";");
                out += `${i === 0 ? "if" : "elseif"} ${print(b.cond)} then;${body ? body + ";" : ""}`;
            }
            if (node.elseBody && node.elseBody.length) {
                const body = node.elseBody.map(printStatement).join(";");
                out += `else;${body ? body + ";" : ""}`;
            }
            return `${out}end`;
        }
        case "While": { const body = (node.body || []).map(printStatement).join(";"); return `while ${print(node.cond)} do;${body ? body + ";" : ""}end`; }
        case "Repeat": { const body = (node.body || []).map(printStatement).join(";"); return `repeat;${body ? body + ";" : ""}until ${print(node.cond)}`; }
        case "ForNum": {
            const step = node.step ? `,${print(node.step)}` : "";
            const body = (node.body || []).map(printStatement).join(";");
            return `for ${node.name}=${print(node.start)},${print(node.end)}${step} do;${body ? body + ";" : ""}end`;
        }
        case "ForIn": {
            const body = (node.body || []).map(printStatement).join(";");
            return `for ${(node.names || []).join(",")} in ${(node.it || []).map(print).join(",")} do;${body ? body + ";" : ""}end`;
        }
        case "Do": { const body = (node.body || []).map(printStatement).join(";"); return `do;${body ? body + ";" : ""}end`; }
        default:
            throw new Error(`Luau printer: unsupported statement node ${String(node.type)}`);
    }
}

function printChunk(ast, options = {}) {
    const raw = print(ast);
    return options.minify === false ? raw : minify(raw);
}

function printFunctionBody(ast, options = {}) {
    if (!ast || !Array.isArray(ast.body)) throw new TypeError("Luau printer: expected Chunk AST");
    const raw = ast.body.map(printStatement).join(";");
    return options.minify === false ? raw : minify(raw);
}

module.exports = {
    print,
    printStatement,
    printChunk,
    printFunctionBody
};

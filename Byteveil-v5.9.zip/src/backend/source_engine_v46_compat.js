"use strict";

/*
 * ByteVeil v4.6 compatibility source route.
 *
 * This route is intentionally independent of the pre-v4 source engines. It is
 * used only when the strict VM explicitly rejects a valid source feature and
 * compatibilityRoute is enabled.
 *
 * Runtime shape:
 *   source -> v4.6 nested protection -> linked graph reconstruction -> load
 *
 * The graph contains only protected v4.6 nested payload shards. It does not
 * embed the original source in plaintext, does not use string.char, and keeps
 * the same reference/hook/integrity checks as the v4.6 protection path.
 */

const { wrapSource } = require("../protection/nested_obfuscation");
const { minify } = require("../wrappers/WrapInFunction");

const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

function u32(n) { return Number(n) >>> 0; }

function mix(seed, value) {
    let s = u32(seed ^ value ^ 0x4600A731);
    s ^= s >>> 16;
    s = Math.imul(s, 2246822519) >>> 0;
    s ^= s >>> 13;
    s = Math.imul(s, 3266489917) >>> 0;
    s ^= s >>> 16;
    return s >>> 0;
}

function rng(seed) {
    let state = u32(seed) || 0xA5110A46;
    return () => {
        state = (state + 0x6D2B79F5) >>> 0;
        let t = state;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return (t ^ (t >>> 14)) >>> 0;
    };
}

function identFactory(seed) {
    const next = rng(seed ^ 0x4600C0DE);
    const used = new Set();
    let fallbackSerial = 0;
    return () => {
        for (let attempts = 0; ; attempts++) {
            const a = next();
            let out = "_" + ALPHABET[a % ALPHABET.length];
            for (let i = 0; i < 9; i++) out += ALPHABET[next() % ALPHABET.length];
            if (!used.has(out)) {
                used.add(out);
                return out;
            }
            if (attempts >= 64) {
                do { out = `_BVCompat${(fallbackSerial++).toString(36)}`; }
                while (used.has(out));
                used.add(out);
                return out;
            }
        }
    };
}

function textShards(text, seed, strength) {
    const input = String(text);
    const min = strength >= 7500 ? 40 : strength >= 3500 ? 56 : 72;
    const max = strength >= 7500 ? 104 : strength >= 3500 ? 132 : 168;
    const next = rng(seed ^ 0x4600D00D);
    const shards = [];
    let p = 0;
    while (p < input.length) {
        const span = min + (next() % (max - min + 1));
        let end = Math.min(input.length, p + span);
        // Never split a UTF-16 surrogate pair in the source-container text.
        while (end > p && end < input.length &&
               input.charCodeAt(end) >= 0xDC00 && input.charCodeAt(end) <= 0xDFFF) {
            end--;
        }
        if (end === p) end = Math.min(input.length, p + 1);
        shards.push(input.slice(p, end));
        p = end;
    }
    return shards.length ? shards : [""];
}

function shuffle(values, seed) {
    const out = values.slice();
    const next = rng(seed);
    for (let i = out.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
}

function token(seed, i) {
    const next = rng((seed ^ Math.imul(i + 1, 0x9E3779B9)) >>> 0);
    let out = "";
    for (let k = 0; k < 8; k++) out += ALPHABET[next() % ALPHABET.length];
    return out;
}

function shardHash(text) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < text.length; i++) {
        h = Math.imul((h ^ text.charCodeAt(i)) >>> 0, 16777619) >>> 0;
    }
    return h >>> 0;
}

function buildSourceEngine(source, options = {}) {
    const seed = Number(options.seed ?? 0xA5110A46) >>> 0;
    const target = String(options.target || "lua").toLowerCase() === "luau" ? "luau" : "lua";
    const strength = Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000));

    // The compatibility route still gets the actual v4.6 nested protection.
    const nested = wrapSource(String(source), {
        seed: seed ^ 0x4600A11A,
        strength,
        version: "4.7.4", nestedProfile: options.nestedProfile || "balanced"
    });
    const shards = textShards(nested.output, seed, strength);
    const order = shuffle(shards.map((_, i) => i), seed ^ 0x4600B22B);
    const names = identFactory(seed);
    const graph = names();
    const state = names();
    const part = names();
    const trace = names();
    const count = names();
    const loader = names();
    const type = names();
    const concat = names();
    const byte = names();
    const unpack = names();
    const expectedHash = shards.reduce((h, shard) => {
        let out = h >>> 0;
        for (let i = 0; i < shard.length; i++) out = (out + shard.charCodeAt(i) * 16777619) >>> 0;
        return out;
    }, 2166136261) >>> 0;

    const ids = shards.map((_, i) => token(seed ^ 0x4600CCDD, i + 1));
    const graphDefs = [];
    for (const i of order) {
        const next = i + 1 < shards.length ? JSON.stringify(ids[i + 1]) : "nil";
        graphDefs.push(`${graph}[${JSON.stringify(ids[i])}]=function()return ${JSON.stringify(shards[i])},${next} end`);
    }

    const body = [
        `local __E=((getgenv and getgenv())or(getfenv and getfenv(1))or _G);local ${type}=__E.type or type;local ${concat}=__E.table and __E.table.concat or table.concat;local ${byte}=__E.string and __E.string.byte or string.byte;local ${unpack}=__E.table and (__E.table.unpack or __E.unpack) or table.unpack or unpack`,
        `local ${graph}={};local ${state}=${JSON.stringify(ids[0] || "")};local ${part}={};local ${trace}=2166136261;local ${count}=0`,
        ...graphDefs,
        `while ${state}~=nil do local F=${graph}[${state}];if ${type}(F)~="function" then error("ByteVeil v4.6 compatibility graph failed",0)end;local A,B=F();if ${type}(A)~="string" then error("ByteVeil v4.6 compatibility shard failed",0)end;${count}=${count}+1;${part}[${count}]=A;for I=1,#A do ${trace}=(${trace}+${byte}(A,I)*16777619)%4294967296 end;${state}=B;if ${count}>${shards.length} then error("ByteVeil v4.6 compatibility cycle",0)end end`,
        `if ${count}~=${shards.length} or ${trace}%4294967296~=${expectedHash} then error("ByteVeil v4.6 compatibility integrity failed",0)end`,
        `if type~=${type} or table.concat~=${concat} or string.byte~=${byte} then error("ByteVeil v4.6 compatibility hook detected",0)end`,
        `local ${loader}=(__E and __E["lo".."ad"])or(type(load)=="function"and load);if type(${loader})~="function" then error("ByteVeil v4.6 compatibility loader missing",0)end`,
        `local C,E=${loader}(${concat}(${part}));if not C then error(E,0)end;return ${unpack}({C()})`
    ].join(";");

    let output = minify(`do ${body} end`).replace(/\r\n/g, "\n");

    return {
        output,
        engine: "ByteVeil Compatibility Source Engine v4.6.3",
        target,
        runtime: target === "luau" ? "Luau compatibility runtime" : "Lua 5.1-5.4 compatibility runtime",
        seed,
        strength,
        encodedBytes: Buffer.byteLength(source, "utf8"),
        innerBytes: Buffer.byteLength(nested.output, "utf8"),
        containerEntries: shards.length,
        containerShards: shards.length,
        containerDecoys: 0,
        containerFormat: "nested-linked-graph-source-v461",
        vmIsland: false,
        vmVersion: "4.6.3-compatibility",
        runtimeBaseVersion: "4.6.3-nested",
        checksum: shardHash(String(source)),
        transformRounds: nested.layers,
        nestedObfuscationLayers: nested.layers,
        nestedCodecs: nested.codecs,
        compatibility: true,
        architecture: "outer-linked-graph-over-v46-nested"
    };
}

module.exports = { buildSourceEngine };

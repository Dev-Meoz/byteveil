"use strict";

const { shuffle: makeOpcodeMap } = require("../obfuscation/opcode_shuffle");
const { ConstantPool } = require("../obfuscation/constant_pool");
const { numberOperand } = require("./number_operand");
const { tableArraySizeHint } = require("./table_array_hint");

function compileAST(ast, mode = "stack", seed = 1, context = {}) {
    if (!ast || ast.type !== "Chunk") throw new TypeError("compileAST: expected Chunk AST");

    const map = makeOpcodeMap(seed >>> 0);
    const code = [];
    const pool = new ConstantPool();
    const consts = pool.items;

    const constant = (value) => pool.add(value);

    const emit = (name, ...args) => {
        const ins = [map.encode[name], ...args];
        code.push(ins);
        return code.length - 1;
    };

    const patch = (at, argIndex, value) => { code[at][argIndex] = value; };
    let localNames = new Set([...(context.visibleNames || []), ...(ast.params || []), ...(ast.locals || [])]);
    const loopBreaks = [];
    const loopContinues = [];
    const pushLoop = () => { const ctx = []; loopBreaks.push(ctx); loopContinues.push([]); return ctx; };
    const popLoop = (ctx, exit, continueTarget = exit) => {
        for (const at of ctx) patch(at, 1, exit);
        const continues = loopContinues.pop() || [];
        for (const at of continues) patch(at, 1, continueTarget);
        loopBreaks.pop();
    };

    function compileChunk(chunk, subSeed) {
        return compileAST(chunk, mode, subSeed >>> 0, { visibleNames: new Set(localNames) });
    }

    function expr(x) {
        if (!x) { emit("PUSHNIL"); return; }
        switch (x.type) {
            case "Number": emit("PUSHN", numberOperand(x)); return;
            case "String": emit("PUSHK", constant(String(x.value))); return;
            case "Boolean": emit("PUSHB", x.value ? 1 : 0); return;
            case "Nil": emit("PUSHNIL"); return;
            case "Id": { const name = String(x.name); emit(localNames.has(name) ? "GETL" : "GETG", constant(name)); return; }
            case "Vararg": emit("VARARG"); return;
            case "Unary":
                expr(x.arg);
                emit({ not: "NOT", "-": "NEG", "#": "LEN", "~": "BNOT" }[x.op] || "NOT");
                return;
            case "IfElseExpression": {
                expr(x.cond);
                const falseJump = emit("JZ", 0);
                expr(x.consequent);
                const endJump = emit("JMP", 0);
                patch(falseJump, 1, code.length);
                expr(x.alternate);
                patch(endJump, 1, code.length);
                return;
            }
            case "Binary": {
                if (x.op === "and" || x.op === "or") {
                    expr(x.left);
                    emit("DUP");
                    const falseJump = emit("JZ", 0);
                    if (x.op === "and") {
                        emit("POP");
                        expr(x.right);
                        patch(falseJump, 1, code.length);
                    } else {
                        const endJump = emit("JMP", 0);
                        patch(falseJump, 1, code.length);
                        emit("POP");
                        expr(x.right);
                        patch(endJump, 1, code.length);
                    }
                    return;
                }
                expr(x.left); expr(x.right);
                const op = {
                    "+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV", "//": "IDIV", "%": "MOD", "^": "POW",
                    "==": "EQ", "~=": "NE", "<": "LT", ">": "GT", "<=": "LE", ">=": "GE",
                    "..": "CONCAT",
                    "&": "BAND", "|": "BOR", "~": "BXOR", "<<": "SHL", ">>": "SHR"
                }[x.op];
                emit(op || "ADD");
                return;
            }
            case "Index":
                expr(x.obj); expr(x.key); emit("GETI"); return;
            case "Call": {
                const args = x.args || [];
                const tail = args.length ? args[args.length - 1] : null;
                const spreadsTail = !!tail && (tail.type === "Vararg" || (tail.type === "Call" && tail.singleResult !== true));
                const fixedArgs = spreadsTail ? args.slice(0, -1) : args;
                const pushTailPack = () => { if (tail.type === "Vararg") emit("VARARGS"); else callPack(tail); };
                if (!x.method && x.callee?.type === "Id" && !localNames.has(String(x.callee.name))) {
                    fixedArgs.forEach(expr);
                    if (spreadsTail) pushTailPack();
                    emit(spreadsTail ? "CALLGV" : "CALLG", constant(String(x.callee.name)), fixedArgs.length);
                } else if (x.method) {
                    // obj:method(args) -> function, self, fixed args, optional trailing pack.
                    expr(x.callee.obj);
                    emit("DUP");
                    expr(x.callee.key);
                    emit("GETI");
                    emit("SWAP");
                    fixedArgs.forEach(expr);
                    if (spreadsTail) pushTailPack();
                    emit(spreadsTail ? "CALLV" : "CALL", fixedArgs.length + 1);
                } else {
                    expr(x.callee);
                    fixedArgs.forEach(expr);
                    if (spreadsTail) pushTailPack();
                    emit(spreadsTail ? "CALLV" : "CALL", fixedArgs.length);
                }
                return;
            }
            case "FunctionExpr": {
                const sub = compileAST({ type: "Chunk", body: x.body || [], params: x.params || [], vararg: !!x.vararg }, mode, seed + code.length + 31, { visibleNames: new Set(localNames) });
                sub.params = x.params || [];
                sub.vararg = !!x.vararg;
                sub.mode = mode;
                emit("MAKEFUNC", constant({ __chunk: sub }));
                return;
            }
            case "Table": {
                emit("NEWTABLE", tableArraySizeHint(x.fields || []));
                const fields = x.fields || [];
                let implicitCount = 0;
                for (let i = 0; i < fields.length; i++) {
                    const field = fields[i];
                    // Only the final list-position field expands: `[k] = f()` and a
                    // non-terminal `f()` keep Lua's single-result truncation.
                    const isExpandTail = i === fields.length - 1 && !field.explicit && expandableTail(field.value);
                    if (isExpandTail) {
                        if (field.value.type === "Vararg") emit("VARARGS"); else callPack(field.value);
                        emit("APPEND", implicitCount + 1);
                        continue;
                    }
                    if (field.key) expr(field.key);
                    else emit("PUSHN", implicitCount + 1);
                    if (!field.explicit) implicitCount++;
                    expr(field.value);
                    emit("SETI");
                }
                return;
            }
            default:
                emit("PUSHNIL");
        }
    }

    // Lowers a call so that every result it produces survives as an explicit
    // {n=..., [1..n]=...} pack on the operand stack. CALLP keeps nil holes and
    // zero-result calls intact, which is what table tails and expanded call
    // arguments need; ordinary expression position still uses CALL/CALLG and
    // truncates to one value, matching native Lua/Luau.
    function callPack(x) {
        const args = x.args || [];
        const tail = args.length ? args[args.length - 1] : null;
        const spreadsTail = !!tail && (tail.type === "Vararg" || (tail.type === "Call" && tail.singleResult !== true));
        const fixedArgs = spreadsTail ? args.slice(0, -1) : args;
        const pushTailPack = () => { if (tail.type === "Vararg") emit("VARARGS"); else callPack(tail); };
        if (!x.method && x.callee?.type === "Id" && !localNames.has(String(x.callee.name))) {
            fixedArgs.forEach(expr);
            if (spreadsTail) pushTailPack();
            emit("CALLP", 1, constant(String(x.callee.name)), fixedArgs.length, spreadsTail ? 1 : 0);
        } else if (x.method) {
            expr(x.callee.obj);
            emit("DUP");
            expr(x.callee.key);
            emit("GETI");
            emit("SWAP");
            fixedArgs.forEach(expr);
            if (spreadsTail) pushTailPack();
            emit("CALLP", 0, 0, fixedArgs.length + 1, spreadsTail ? 1 : 0);
        } else {
            expr(x.callee);
            fixedArgs.forEach(expr);
            if (spreadsTail) pushTailPack();
            emit("CALLP", 0, 0, fixedArgs.length, spreadsTail ? 1 : 0);
        }
    }

    function expandableTail(value) {
        return !!value && (value.type === "Vararg" || (value.type === "Call" && value.singleResult !== true));
    }

    function hasExpandableArgTail(call) {
        const args = call?.args || [];
        return args.length > 0 && expandableTail(args[args.length - 1]);
    }

    function statement(s) {
        switch (s.type) {
            case "Local":
            case "Assign": {
                const values = s.values || [];
                const vars = s.vars || [];
                const targets = vars.map((v) => typeof v === "string" ? { type: "Id", name: v } : v);

                // Multi-target assignments expand a final `...` exactly to the
                // fixed target count while preserving the vararg pack's explicit n.
                const hasVarargTail = values.length > 0 && values[values.length - 1]?.type === "Vararg";
                const varargPrefixCount = Math.max(0, values.length - 1);
                if (hasVarargTail && targets.length > varargPrefixCount && targets.every((v) => v && v.type === "Id")) {
                    // Scratch table: every slot is written and read by explicit index,
                    // so it never needs the constructor array-part hint.
                    emit("NEWTABLE", 0);
                    for (let i = 0; i < targets.length; i++) {
                        emit("DUP");
                        emit("PUSHN", i + 1);
                        if (i < varargPrefixCount) {
                            expr(values[i]);
                        } else {
                            emit("VARARGS");
                            emit("PUSHN", i - varargPrefixCount + 1);
                            emit("GETI");
                        }
                        emit("SETI");
                    }
                    if (s.type === "Local") for (const target of targets) localNames.add(String(target.name));
                    for (let i = 0; i < targets.length; i++) {
                        emit("DUP");
                        emit("PUSHN", i + 1);
                        emit("GETI");
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", constant(name));
                    }
                    emit("POP");
                    return;
                }

                // Lua evaluates the complete RHS before storing any LHS value.
                // A temporary VM table keeps parallel assignment deterministic without
                // changing the existing opcode set or directory layout.
                if (targets.length > 1 && values.length === 1 && values[0]?.type === "Call" && values[0].singleResult !== true
                    && hasExpandableArgTail(values[0]) && targets.every((v) => v && v.type === "Id")) {
                    // `local a, b = g(f())` needs both the expanded argument list and
                    // the expanded result list, so the results are materialised in a
                    // temporary table and read back one target at a time.
                    emit("NEWTABLE", 0);
                    callPack(values[0]);
                    emit("APPEND", 1);
                    if (s.type === "Local") for (const target of targets) localNames.add(String(target.name));
                    for (let i = 0; i < targets.length; i++) {
                        emit("DUP");
                        emit("PUSHN", i + 1);
                        emit("GETI");
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", constant(name));
                    }
                    emit("POP");
                    return;
                }

                if (targets.length > 1 && targets.every((v) => v && v.type === "Id") && values.length > 0 && values[values.length - 1]?.type === "Call" && values[values.length - 1]?.singleResult !== true) {
                    const prefixCount = Math.max(0, values.length - 1);
                    for (let i = 0; i < prefixCount; i++) expr(values[i]);
                    const call = values[values.length - 1];
                    const want = Math.max(1, targets.length - prefixCount);
                    if (!call.method && call.callee?.type === "Id" && !localNames.has(String(call.callee.name))) {
                        (call.args || []).forEach(expr);
                        emit("CALLGM", constant(String(call.callee.name)), (call.args || []).length, want);
                    } else if (call.method) {
                        expr(call.callee.obj);
                        emit("DUP");
                        expr(call.callee.key);
                        emit("GETI");
                        emit("SWAP");
                        (call.args || []).forEach(expr);
                        emit("CALLM", (call.args || []).length + 1, want);
                    } else {
                        expr(call.callee);
                        (call.args || []).forEach(expr);
                        emit("CALLM", (call.args || []).length, want);
                    }
                    const produced = prefixCount + want;
                    if (produced > targets.length) for (let i = produced - targets.length; i > 0; i--) emit("POP");
                    if (s.type === "Local") for (const target of targets) localNames.add(String(target.name));
                    for (let i = targets.length - 1; i >= 0; i--) emit(localNames.has(String(targets[i].name)) ? "SETL" : "SETG", constant(String(targets[i].name)));
                    return;
                }

                if (targets.length > 1 && targets.every((v) => v && v.type === "Id")) {
                    emit("NEWTABLE", 0);
                    for (let i = 0; i < Math.max(values.length, targets.length); i++) {
                        emit("DUP");
                        emit("PUSHN", i + 1);
                        if (i < values.length) expr(values[i]); else emit("PUSHNIL");
                        emit("SETI");
                    }
                    if (s.type === "Local") for (const target of targets) localNames.add(String(target.name));
                    for (let i = 0; i < targets.length; i++) {
                        const target = targets[i];
                        emit("DUP");
                        emit("PUSHN", i + 1);
                        emit("GETI");
                        const name = String(target.name);
                        emit(localNames.has(name) ? "SETL" : "SETG", constant(name));
                    }
                    emit("POP");
                    return;
                }

                for (let i = 0; i < Math.max(values.length, vars.length); i++) {
                    const target = targets[i];
                    if (!target) {
                        if (i < values.length) expr(values[i]); else emit("PUSHNIL");
                        emit("POP");
                        continue;
                    }
                    if (target.type === "Id") {
                        if (i < values.length) expr(values[i]); else emit("PUSHNIL");
                        const name = String(target.name);
                        if (s.type === "Local") localNames.add(name);
                        emit(localNames.has(name) ? "SETL" : "SETG", constant(name));
                    } else {
                        // Single indexed assignments retain the existing fast path.
                        expr(target.obj);
                        expr(target.key);
                        if (i < values.length) expr(values[i]); else emit("PUSHNIL");
                        emit("SETI");
                    }
                }
                return;
            }
            case "Compound":
                if (s.left && s.left.type === "Id") {
                    const name = String(s.left.name);
                    emit(localNames.has(name) ? "GETL" : "GETG", constant(name));
                    expr(s.value);
                    emit({ "+=": "ADD", "-=": "SUB", "*=": "MUL", "/=": "DIV", "//=": "IDIV", "%=": "MOD", "^=": "POW", "..=": "CONCAT" }[s.op] || "ADD");
                    emit(localNames.has(name) ? "SETL" : "SETG", constant(name));
                }
                return;
            case "CallStmt": expr(s.call); emit("POP"); return;
            case "Return": {
                const values = s.values || [];
                const tail = values.length ? values[values.length - 1] : null;
                if (tail?.type === "Call" && tail.singleResult !== true) {
                    const prefix = values.slice(0, -1);
                    prefix.forEach(expr);
                    const args = tail.args || [];
                    const argTail = args.length ? args[args.length - 1] : null;
                    const spreadsTail = !!argTail && (argTail.type === "Vararg" || (argTail.type === "Call" && argTail.singleResult !== true));
                    const fixedArgs = spreadsTail ? args.slice(0, -1) : args;
                    const pushTailPack = () => { if (argTail.type === "Vararg") emit("VARARGS"); else callPack(argTail); };
                    if (!tail.method && tail.callee?.type === "Id" && !localNames.has(String(tail.callee.name))) {
                        fixedArgs.forEach(expr);
                        if (spreadsTail) pushTailPack();
                        emit("TAILCALL", 1, constant(String(tail.callee.name)), fixedArgs.length, prefix.length, spreadsTail ? 1 : 0);
                    } else if (tail.method) {
                        expr(tail.callee.obj);
                        emit("DUP");
                        expr(tail.callee.key);
                        emit("GETI");
                        emit("SWAP");
                        fixedArgs.forEach(expr);
                        if (spreadsTail) pushTailPack();
                        emit("TAILCALL", 0, 0, fixedArgs.length + 1, prefix.length, spreadsTail ? 1 : 0);
                    } else {
                        expr(tail.callee);
                        fixedArgs.forEach(expr);
                        if (spreadsTail) pushTailPack();
                        emit("TAILCALL", 0, 0, fixedArgs.length, prefix.length, spreadsTail ? 1 : 0);
                    }
                } else if (tail?.type === "Vararg") {
                    values.slice(0, -1).forEach(expr);
                    emit("VARARGS");
                    emit("RETURNV", values.length - 1);
                } else {
                    values.forEach(expr);
                    emit("RETURN", values.length);
                }
                return;
            }
            case "If": {
                const endJumps = [];
                for (const branch of s.branches || []) {
                    expr(branch.cond);
                    const falseJump = emit("JZ", 0);
                    const saved = localNames;
                    localNames = new Set(localNames);
                    (branch.body || []).forEach(statement);
                    localNames = saved;
                    endJumps.push(emit("JMP", 0));
                    patch(falseJump, 1, code.length);
                }
                if (s.elseBody?.length) {
                    const saved = localNames;
                    localNames = new Set(localNames);
                    s.elseBody.forEach(statement);
                    localNames = saved;
                }
                const end = code.length;
                for (const j of endJumps) patch(j, 1, end);
                return;
            }
            case "While": {
                const start = code.length;
                expr(s.cond);
                const exit = emit("JZ", 0);
                const loop = pushLoop();
                const saved = localNames;
                localNames = new Set(localNames);
                (s.body || []).forEach(statement);
                localNames = saved;
                emit("JMP", start);
                const end = code.length;
                patch(exit, 1, end);
                popLoop(loop, end, start);
                return;
            }
            case "Repeat": {
                const start = code.length;
                const loop = pushLoop();
                (s.body || []).forEach(statement);
                const continueTarget = code.length;
                expr(s.cond);
                emit("JZ", start);
                const end = code.length;
                popLoop(loop, end, continueTarget);
                return;
            }
            case "Do": {
                const saved = localNames;
                localNames = new Set(localNames);
                (s.body || []).forEach(statement);
                localNames = saved;
                return;
            }
            case "Break": if (!loopBreaks.length) throw new Error("ByteVeil v5.9.0 strict VM rejected input: break outside loop"); loopBreaks[loopBreaks.length - 1].push(emit("JMP", 0)); return;
            case "Continue": if (!loopContinues.length) throw new Error("ByteVeil v5.9.0 strict VM rejected input: continue outside loop"); loopContinues[loopContinues.length - 1].push(emit("JMP", 0)); return;
            case "ForNum": {
                // Lower numeric for to explicit loop state using hidden globals.
                const idx = String(s.name);
                const endName = `__bc_for_end_${idx}_${code.length}`;
                const stepName = `__bc_for_step_${idx}_${code.length}`;
                localNames.add(idx); localNames.add(endName); localNames.add(stepName);
                expr(s.start); emit("SETL", constant(idx));
                expr(s.end); emit("SETL", constant(endName));
                if (s.step) expr(s.step); else emit("PUSHN", 1);
                emit("SETL", constant(stepName));
                const loop = code.length;
                const breaks = pushLoop();
                emit("GETL", constant(idx));
                emit("GETL", constant(endName));
                emit("GETL", constant(stepName));
                emit("FORCMP");
                const exit = emit("JZ", 0);
                (s.body || []).forEach(statement);
                const continueTarget = code.length;
                emit("GETL", constant(idx));
                emit("GETL", constant(stepName));
                emit("ADD");
                emit("SETL", constant(idx));
                emit("JMP", loop);
                const end = code.length;
                patch(exit, 1, end);
                popLoop(breaks, end, continueTarget);
                return;
            }
            case "ForIn": {
                const names = (s.names || []).map(String);
                const exprs = s.it || [];
                if (!names.length || !exprs.length || exprs.length > 3) {
                    throw new Error("ByteVeil strict VM: unsupported generic-for expression shape");
                }

                // Lua's generic-for setup expects (iterator, state, control).
                // The last iterator expression may be multi-valued, so give Call
                // a real multi-return opcode instead of collapsing it to one value.
                let produced = 0;
                for (let i = 0; i < exprs.length; i++) {
                    const x = exprs[i];
                    const isLast = i === exprs.length - 1;
                    if (isLast && x?.type === "Call" && x?.singleResult !== true) {
                        const before = code.length;
                        const argCount = (x.args || []).length;
                        expr(x.callee);
                        (x.args || []).forEach(expr);
                        const want = Math.max(1, 3 - produced);
                        emit("CALLM", argCount, want);
                        produced += want;
                        if (code.length === before) throw new Error("ByteVeil strict VM: iterator call lowering failed");
                    } else {
                        expr(x);
                        produced++;
                    }
                }
                while (produced < 3) { emit("PUSHNIL"); produced++; }
                if (produced > 3) throw new Error("ByteVeil strict VM: generic-for setup overflow");

                const nameConst = names.map(name => constant(name));
                emit("ITERPREP", produced);
                const loop = emit("ITERLOOP", 0, nameConst.length, ...nameConst);
                const breaks = pushLoop();
                const saved = localNames;
                localNames = new Set(localNames);
                names.forEach(name => localNames.add(name));
                (s.body || []).forEach(statement);
                localNames = saved;
                const continueTarget = code.length;
                emit("JMP", loop);
                const end = code.length;
                patch(loop, 1, end);
                popLoop(breaks, end, continueTarget);
                return;
            }
            case "LocalFunction":
            case "Function": {
                const fn = s.fn || { body: [], params: [], vararg: false };
                const fnName = String(s.name);
                if (s.type === "LocalFunction") localNames.add(fnName);
                const sub = compileAST({ type: "Chunk", body: fn.body || [], params: fn.params || [], vararg: !!fn.vararg }, mode, seed + code.length + 101, { visibleNames: new Set(localNames) });
                sub.params = fn.params || [];
                sub.vararg = !!fn.vararg;
                sub.mode = mode;
                emit("MAKEFUNC", constant({ __chunk: sub }));
                if (s.type === "LocalFunction") { localNames.add(fnName); emit("SETL", constant(fnName)); }
                else emit("SETG", constant(fnName));
                return;
            }
            default:
                return;
        }
    }

    for (const s of ast.body || []) statement(s);
    emit("HALT");

    return {
        mode,
        code,
        consts,
        params: ast.params || [],
        vararg: !!ast.vararg,
        opcode: map.names,
        map
    };
}

module.exports = { compileAST };

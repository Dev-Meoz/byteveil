"use strict";

const POLICIES = new Set(["balanced", "hardened", "compiler-transformed"]);

function normalizePolicy(value, fallback = "balanced") {
    const input = String(value ?? fallback).trim().toLowerCase().replace(/[_\s]+/g, "-");
    const aliases = new Map([
        ["balanced", "balanced"], ["vm-a", "balanced"], ["vma", "balanced"],
        ["hardened", "hardened"], ["vm-b", "hardened"], ["vmb", "hardened"],
        ["compiler-transformed", "compiler-transformed"], ["transformed", "compiler-transformed"], ["no-vm", "compiler-transformed"]
    ]);
    const policy = aliases.get(input);
    if (!policy || !POLICIES.has(policy)) {
        throw new Error(`ByteVeil v5.9.0: unknown function VM policy ${JSON.stringify(value)}; expected balanced, hardened, or compiler-transformed`);
    }
    return policy;
}

function rememberPolicyNames(ast) {
    const seen = new Set();
    const visit = (value) => {
        if (!value || typeof value !== "object" || seen.has(value)) return;
        seen.add(value);
        if (value.type === "Function" || value.type === "LocalFunction") {
            const sourceName = simpleGlobalFunctionName(value) || String(value.name || "");
            if (sourceName && !Object.prototype.hasOwnProperty.call(value, "__byteVeilPolicyName")) {
                Object.defineProperty(value, "__byteVeilPolicyName", { value: sourceName, enumerable: false, configurable: true });
            }
        }
        for (const child of Object.values(value)) {
            if (Array.isArray(child)) child.forEach(visit);
            else visit(child);
        }
    };
    visit(ast);
    return ast;
}

function functionExpression(fn) {
    return {
        type: "FunctionExpr",
        params: Array.isArray(fn?.params) ? fn.params.map(String) : [],
        vararg: !!fn?.vararg,
        body: Array.isArray(fn?.body) ? fn.body : [],
        returnType: null
    };
}

function simpleGlobalFunctionName(node) {
    if (!node || node.type !== "Function" || node.method) return null;
    const path = Array.isArray(node.namePath) ? node.namePath : [];
    if (path.length !== 1 || path[0]?.type !== "name") return null;
    const name = String(path[0].value ?? node.name ?? "");
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name) ? name : null;
}

function collectReferencedNames(body, out = new Set()) {
    function expr(node) {
        if (!node || typeof node !== "object") return;
        switch (node.type) {
            case "Id": out.add(String(node.name)); return;
            case "Binary": expr(node.left); expr(node.right); return;
            case "Unary": expr(node.arg); return;
            case "Index": expr(node.obj); expr(node.key); return;
            case "Call": expr(node.callee); (node.args || []).forEach(expr); return;
            case "FunctionExpr": (node.body || []).forEach(stmt); return;
            case "Table": for (const f of node.fields || []) { expr(f.key); expr(f.value); } return;
            case "IfElseExpression": expr(node.cond); expr(node.consequent); expr(node.alternate); return;
            default: return;
        }
    }
    function stmt(node) {
        if (!node || typeof node !== "object") return;
        switch (node.type) {
            case "Local": (node.values || []).forEach(expr); return;
            case "LocalFunction": (node.fn?.body || []).forEach(stmt); return;
            case "Function": (node.fn?.body || []).forEach(stmt); return;
            case "Assign":
                (node.vars || []).forEach((v) => {
                    if (typeof v === "string") out.add(v);
                    else if (v?.type === "Id") out.add(String(v.name));
                    else expr(v);
                });
                (node.values || []).forEach(expr);
                return;
            case "Compound": expr(node.left); expr(node.value); return;
            case "CallStmt": expr(node.call); return;
            case "Return": (node.values || []).forEach(expr); return;
            case "If":
                for (const b of node.branches || []) { expr(b.cond); (b.body || []).forEach(stmt); }
                (node.elseBody || []).forEach(stmt); return;
            case "While": case "Repeat": expr(node.cond); (node.body || []).forEach(stmt); return;
            case "ForNum": expr(node.start); expr(node.end); expr(node.step); (node.body || []).forEach(stmt); return;
            case "ForIn": (node.it || []).forEach(expr); (node.body || []).forEach(stmt); return;
            case "Do": (node.body || []).forEach(stmt); return;
            default: return;
        }
    }
    (body || []).forEach(stmt);
    return out;
}

function collectAllFunctionNames(ast) {
    const names = new Set();
    const seen = new Set();
    function expr(node, path) {
        if (!node || typeof node !== "object") return;
        if (node.type === "FunctionExpr") {
            (node.body || []).forEach((s, i) => stmt(s, `${path}.<function:${i + 1}>`));
            return;
        }
        switch (node.type) {
            case "Binary": expr(node.left, path); expr(node.right, path); break;
            case "Unary": expr(node.arg, path); break;
            case "Index": expr(node.obj, path); expr(node.key, path); break;
            case "Call": expr(node.callee, path); (node.args || []).forEach((x) => expr(x, path)); break;
            case "Table": (node.fields || []).forEach((f) => { expr(f.key, path); expr(f.value, path); }); break;
            case "IfElseExpression": expr(node.cond, path); expr(node.consequent, path); expr(node.alternate, path); break;
        }
    }
    function stmt(node, path) {
        if (!node || typeof node !== "object" || seen.has(node)) return;
        seen.add(node);
        if (node.type === "Function" || node.type === "LocalFunction") {
            if (node.name) names.add(String(node.name));
            if (node.__byteVeilPolicyName) names.add(String(node.__byteVeilPolicyName));
            (node.fn?.body || []).forEach((s, i) => stmt(s, `${path}.${node.name || `fn${i}`}`));
            return;
        }
        switch (node.type) {
            case "Local": case "Assign": (node.values || []).forEach((x) => expr(x, path)); (node.vars || []).forEach((x) => typeof x === "object" && expr(x, path)); break;
            case "Compound": expr(node.left, path); expr(node.value, path); break;
            case "CallStmt": expr(node.call, path); break;
            case "Return": (node.values || []).forEach((x) => expr(x, path)); break;
            case "If": (node.branches || []).forEach((b) => { expr(b.cond, path); (b.body || []).forEach((s) => stmt(s, path)); }); (node.elseBody || []).forEach((s) => stmt(s, path)); break;
            case "While": case "Repeat": expr(node.cond, path); (node.body || []).forEach((s) => stmt(s, path)); break;
            case "ForNum": expr(node.start, path); expr(node.end, path); expr(node.step, path); (node.body || []).forEach((s) => stmt(s, path)); break;
            case "ForIn": (node.it || []).forEach((x) => expr(x, path)); (node.body || []).forEach((s) => stmt(s, path)); break;
            case "Do": (node.body || []).forEach((s) => stmt(s, path)); break;
        }
    }
    (ast?.body || []).forEach((s, i) => stmt(s, `chunk.${i + 1}`));
    return names;
}

/**
 * Apply a strict, top-level function policy plan without silently changing scope.
 * Cross-backend extraction is limited to simple global function declarations which do
 * not capture currently-visible chunk locals. Unsupported mixed-policy requests throw.
 */
function prepareFunctionPolicy(ast, options = {}) {
    rememberPolicyNames(ast);
    const defaultPolicy = normalizePolicy(options.vmPolicy || "balanced");
    const rawMap = options.functionPolicies && typeof options.functionPolicies === "object" ? options.functionPolicies : {};
    const explicit = new Map(Object.entries(rawMap).map(([name, policy]) => [String(name), normalizePolicy(policy)]));
    const allNames = collectAllFunctionNames(ast);
    for (const name of explicit.keys()) {
        if (!allNames.has(name)) throw new Error(`ByteVeil v5.9.0: function policy target ${JSON.stringify(name)} was not found in the AST`);
    }

    const visibleLocals = new Set();
    const routed = [];
    const report = [];
    const explicitFallbacks = [];
    let hasMismatch = false;
    const occupied = collectAllFunctionNames(ast);
    let bridgeName = `__bv_entry_arg_${(Number(options.seed) >>> 0).toString(36)}`;
    let bridgeSuffix = 0;
    while (occupied.has(bridgeName)) bridgeName = `__bv_entry_arg_${(Number(options.seed) >>> 0).toString(36)}_${++bridgeSuffix}`;
    const fallbackAllowed = options.allowPolicyFallback === true;
    const containingBackend = defaultPolicy === "balanced" ? "VM-A/register" : defaultPolicy === "hardened" ? "VM-B/stack" : "compiler-transformed";
    const reportFallback = (sourceName, runtimeName, policy, reason) => {
        const item = { name: sourceName, runtimeName: runtimeName || sourceName, policy, requestedBackend: policy === "balanced" ? "VM-A/register" : policy === "hardened" ? "VM-B/stack" : "compiler-transformed", backend: containingBackend, routing: "explicit-fallback-containing-chunk", fallback: true, fallbackReason: reason, captures: [] };
        report.push(item);
        explicitFallbacks.push({ name: sourceName, requestedPolicy: policy, effectivePolicy: defaultPolicy, backend: containingBackend, reason });
    };

    const body = [];
    for (const node of ast.body || []) {
        if (node?.type === "Function") {
            const name = simpleGlobalFunctionName(node);
            const runtimeDeclaredName = String(node.name || "");
            const declaredName = String(node.__byteVeilPolicyName || runtimeDeclaredName);
            const policy = explicit.get(declaredName) || explicit.get(runtimeDeclaredName) || defaultPolicy;
            if (name && policy !== defaultPolicy) {
                let unsupportedReason = null;
                if (visibleLocals.has(name)) unsupportedReason = "declaration assigns a visible local variable";
                const refs = collectReferencedNames(node.fn?.body || []);
                const captures = [...refs].filter((ref) => visibleLocals.has(ref)).sort();
                if (captures.length) unsupportedReason = `cross-backend closure capture is not implemented for ${captures.map((v) => JSON.stringify(v)).join(", ")}`;
                if (!name) unsupportedReason = "mixed-backend routing requires a simple top-level global function";
                if (unsupportedReason) {
                    if (!fallbackAllowed) {
                        throw new Error(`ByteVeil v5.9.0: cannot route function ${JSON.stringify(declaredName)} to ${policy}; ${unsupportedReason}; set allowPolicyFallback:true to explicitly permit containing-chunk fallback`);
                    }
                    body.push(node);
                    reportFallback(declaredName, runtimeDeclaredName, policy, unsupportedReason);
                    continue;
                }
                const fn = functionExpression(node.fn);
                routed.push({ name: declaredName, runtimeName: name, policy, fn, sourceNode: node });
                report.push({ name: declaredName, runtimeName: name, policy, backend: policy === "balanced" ? "VM-A/register" : policy === "hardened" ? "VM-B/stack" : "compiler-transformed", routing: "isolated-global-function", captures: [] });
                body.push({
                    type: "Assign",
                    vars: [{ type: "Id", name }],
                    values: [{ type: "Index", obj: { type: "Id", name: bridgeName }, key: { type: "String", value: name } }]
                });
                hasMismatch = true;
            } else {
                body.push(node);
                if (name) report.push({ name: declaredName, runtimeName: name, policy, backend: containingBackend, routing: "containing-chunk", captures: [] });
            }
        } else {
            body.push(node);
        }

        // Lua's top-level locals only become visible to following statements. Tracking
        // them in source order conservatively rejects cross-VM closures rather than
        // pretending their upvalues can be shared across independent runtimes.
        if (node?.type === "Local") {
            for (const entry of node.vars || []) visibleLocals.add(String(typeof entry === "string" ? entry : entry?.name));
        } else if (node?.type === "LocalFunction") {
            visibleLocals.add(String(node.name));
        }
    }

    if (hasMismatch) {
        ast.body = body;
        ast.params = [...(Array.isArray(ast.params) ? ast.params.map(String) : []), bridgeName];
    }
    for (const [name, policy] of explicit) {
        if (!report.some((row) => row.name === name)) {
            // The name exists but is nested/local/method-based. Same-policy requests
            // inherit safely; mixed-policy requests cannot be silently downgraded.
            if (policy !== defaultPolicy) {
                const reason = "mixed-backend routing requires a supported top-level named global function with no captured chunk locals";
                if (!fallbackAllowed) throw new Error(`ByteVeil v5.9.0: function policy for ${JSON.stringify(name)} cannot be routed; ${reason}; set allowPolicyFallback:true to explicitly permit containing-chunk fallback`);
                reportFallback(name, name, policy, reason);
                continue;
            }
            report.push({ name, runtimeName: name, policy, backend: containingBackend, routing: "inherited-same-policy", captures: [] });
        }
    }
    return { defaultPolicy, bridgeName: hasMismatch ? bridgeName : null, routed, report, explicitFallbacks };
}

module.exports = { POLICIES, normalizePolicy, rememberPolicyNames, prepareFunctionPolicy };

"use strict";

const packageVersion = require("../../package.json").version;

class IR {
    constructor(mode = "stack", ast = null, version = packageVersion) {
        this.mode = mode === "register" ? "register" : "stack";
        this.ast = ast;
        this.blocks = [];
        this.edges = [];
        this.features = new Set();
        this.meta = { version: String(version || packageVersion), mode: this.mode };
    }

    add(block) {
        this.blocks.push(block);
        return block;
    }

    connect(from, to, kind = "next") {
        this.edges.push({ from, to, kind });
    }

    hasFeature(name) {
        return this.features.has(name);
    }
}

module.exports = { IR };

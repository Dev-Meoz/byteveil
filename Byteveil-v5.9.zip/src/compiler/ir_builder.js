"use strict";

const { IR } = require("./ir");
const packageVersion = require("../../package.json").version;

function fnv1a(text) {
    let h = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
}

function build(ast, mode = "stack", version = packageVersion) {
    if (!ast || ast.type !== "Chunk") throw new TypeError("IR builder expected Chunk AST");
    const ir = new IR(mode, ast, version);
    let nextBlock = 0;
    let instructionCount = 0;
    let functionCount = 0;
    const shape = [];

    const newBlock = (kind = "basic") => {
        const block = { id: nextBlock++, kind, ops: [] };
        ir.add(block);
        return block;
    };

    let current = newBlock("entry");

    const mark = (name) => {
        if (name) { ir.features.add(name); shape.push(name); }
    };
    const op = (name) => {
        current.ops.push({ op: name });
        instructionCount++;
        shape.push(name);
    };

    function expression(node) {
        if (!node) return;
        switch (node.type) {
            case "Number": mark("number"); op("CONST"); break;
            case "String": mark("string"); op("CONST"); break;
            case "Boolean": mark("boolean"); op("CONST"); break;
            case "Nil": mark("nil"); op("CONST"); break;
            case "Id": mark("identifier"); op("LOAD"); break;
            case "Vararg": mark("vararg"); op("VARARG"); break;
            case "Unary": mark("unary:" + node.op); expression(node.arg); op("UNARY"); break;
            case "Binary": mark("binary:" + node.op); expression(node.left); expression(node.right); op("BINARY"); break;
            case "Index": mark("index"); expression(node.obj); expression(node.key); op("GETINDEX"); break;
            case "Call": mark(node.method ? "method-call" : "call"); expression(node.callee); (node.args || []).forEach(expression); op(node.method ? "CALL_SELF" : "CALL"); break;
            case "FunctionExpr":
                mark("closure");
                functionCount++;
                op("CLOSURE");
                buildFunctionBody(node);
                break;
            case "Table":
                mark("table");
                op("NEWTABLE");
                (node.fields || []).forEach((field) => { if (field.key) expression(field.key); expression(field.value); op("SETINDEX"); });
                break;
            case "IfElseExpression":
                mark("if-expression");
                expression(node.cond); expression(node.consequent); expression(node.alternate); op("SELECT");
                break;
            default:
                mark("expr:" + node.type);
                op("EXPR");
        }
    }

    function buildFunctionBody(fn) {
        const saved = current;
        current = newBlock("function");
        (fn.body || []).forEach(statement);
        current = saved;
    }

    function branchFrom(cond, body, elseBody) {
        expression(cond);
        const thenBlock = newBlock("branch");
        ir.connect(current.id, thenBlock.id, "true");
        const saved = current;
        current = thenBlock;
        body.forEach(statement);
        const join = newBlock("join");
        ir.connect(current.id, join.id, "join");
        current = saved;
        const elseBlock = newBlock("branch");
        ir.connect(current.id, elseBlock.id, "false");
        current = elseBlock;
        (elseBody || []).forEach(statement);
        ir.connect(current.id, join.id, "join");
        current = join;
    }

    function statement(node) {
        if (!node) return;
        switch (node.type) {
            case "Local":
                mark("local");
                (node.values || []).forEach(expression);
                (node.vars || []).forEach(() => op("BIND_LOCAL"));
                break;
            case "Assign":
                mark("assign");
                (node.values || []).forEach(expression);
                (node.vars || []).forEach((v) => { if (v?.type === "Id") op("STORE"); else { expression(v?.obj); expression(v?.key); op("SETINDEX"); } });
                break;
            case "Compound":
                mark("compound:" + node.op);
                expression(node.left); expression(node.value); op("BINARY_STORE");
                break;
            case "CallStmt": mark("call-stmt"); expression(node.call); op("POP"); break;
            case "Return": mark("return"); (node.values || []).forEach(expression); op("RETURN"); break;
            case "If":
                mark("if");
                for (let i = 0; i < (node.branches || []).length; i++) {
                    const b = node.branches[i];
                    expression(b.cond);
                    const thenBlock = newBlock("if-branch");
                    ir.connect(current.id, thenBlock.id, "true");
                    const prior = current;
                    current = thenBlock;
                    (b.body || []).forEach(statement);
                    const after = newBlock("if-join");
                    ir.connect(current.id, after.id, "join");
                    current = prior;
                    const falseBlock = newBlock("if-false");
                    ir.connect(current.id, falseBlock.id, "false");
                    current = falseBlock;
                    if (i === (node.branches || []).length - 1) (node.elseBody || []).forEach(statement);
                    current = after;
                }
                break;
            case "While":
                mark("while");
                expression(node.cond);
                {
                    const body = newBlock("while-body");
                    const join = newBlock("while-join");
                    ir.connect(current.id, body.id, "true");
                    ir.connect(current.id, join.id, "false");
                    current = body;
                    (node.body || []).forEach(statement);
                    ir.connect(current.id, body.id, "back");
                    current = join;
                }
                break;
            case "Repeat":
                mark("repeat");
                {
                    const body = newBlock("repeat-body");
                    const exit = newBlock("repeat-exit");
                    ir.connect(current.id, body.id, "body");
                    current = body;
                    (node.body || []).forEach(statement);
                    expression(node.cond);
                    ir.connect(current.id, body.id, "false");
                    ir.connect(current.id, exit.id, "true");
                    current = exit;
                }
                break;
            case "Do":
                mark("do");
                (node.body || []).forEach(statement);
                break;
            case "ForNum":
                mark("numeric-for");
                expression(node.start); expression(node.end); expression(node.step); op("FOR_PREP");
                (node.body || []).forEach(statement); op("FOR_NEXT");
                break;
            case "ForIn":
                mark("generic-for");
                (node.it || []).forEach(expression);
                op("ITER_PREP");
                (node.body || []).forEach(statement);
                op("ITER_NEXT");
                break;
            case "Break": mark("break"); op("BREAK"); break;
            case "LocalFunction":
                mark("local-function");
                functionCount++;
                op("CLOSURE");
                buildFunctionBody(node.fn || {});
                op("STORE");
                break;
            case "Function":
                mark(node.method ? "method-function" : "function");
                functionCount++;
                op("CLOSURE");
                buildFunctionBody(node.fn || {});
                op("STORE");
                break;
            case "Continue": mark("continue"); op("CONTINUE"); break;
            default: mark("stmt:" + node.type); op("STMT");
        }
    }

    (ast.body || []).forEach(statement);
    current.kind = current.kind === "entry" ? "exit" : current.kind;
    const normalizedShape = shape.join("|");
    ir.features.forEach((f) => shape.push("feature:" + f));
    const fingerprint = fnv1a(shape.join("|") + `|b${ir.blocks.length}|e${ir.edges.length}|i${instructionCount}|f${functionCount}`);
    ir.meta = {
        version: String(version || "4.7.6"),
        mode: ir.mode,
        blockCount: ir.blocks.length,
        edgeCount: ir.edges.length,
        instructionCount,
        functionCount,
        featureSet: Array.from(ir.features).sort(),
        fingerprint: fingerprint.toString(16).padStart(8, "0"),
        normalizedShape: fnv1a(normalizedShape) >>> 0
    };
    ir.fingerprint = ir.meta.fingerprint;
    return ir;
}

module.exports = { build };

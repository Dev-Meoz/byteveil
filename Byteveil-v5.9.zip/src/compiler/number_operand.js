"use strict";

// Lua 5.4 keeps integer and float subtypes apart: `print(5)` gives "5" and `print(5.0)` gives
// "5.0", `5.0 // 2` is a float while `5 // 2` is an integer. A JS number cannot hold that
// distinction, so a literal the source *wrote* as a float travels to the payload as the decimal
// text the host reads back with tonumber(), and an integer literal keeps the compact zigzag form.
// This is the only place allowed to decide a literal's subtype, and it decides it from the source
// text — never from the value.

class FloatOperand {
  constructor(text) {
    this.text = text;
  }
}

// Shapes tonumber() accepts as a float: decimal with '.' or exponent, hex with '.' or 'p'.
const FLOAT_TEXT = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$|^[+-]?0[xX](?:[0-9a-fA-F]+\.[0-9a-fA-F]*|\.[0-9a-fA-F]+)(?:[pP][+-]?\d+)?$/;

function isFloatText(value) {
  return typeof value === "string" && FLOAT_TEXT.test(value) && Number.isFinite(Number(value));
}

function writtenAsFloat(raw) {
  const text = String(raw || "").replace(/_/g, "");
  if (!text) return false;
  if (/^0[xX]/.test(text)) return /[.pP]/.test(text);
  return /[.eE]/.test(text);
}

// Shortest round-trip decimal for the double, forced to look like a float so tonumber() cannot
// hand the host an integer: JS renders 5.0 as "5", Lua reads "5" back as the integer 5.
function floatText(value) {
  const text = String(value);
  return /[.eE]/.test(text) ? text : `${text}.0`;
}

function numberOperand(node) {
  const value = Number(node && node.value);
  if (!Number.isFinite(value)) return value;
  if (!Number.isInteger(value)) return value;
  return writtenAsFloat(node && node.raw) ? new FloatOperand(floatText(value)) : value;
}

function isFloatOperand(value) {
  return value instanceof FloatOperand;
}

module.exports = { FloatOperand, numberOperand, isFloatOperand, isFloatText, FLOAT_TEXT };

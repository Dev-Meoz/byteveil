"use strict";

const { encodeBytecodeBlob } = require("../../backend/bytecode_serializer");
const { deriveTamperParams } = require("../../anti/anti_tamper");

function randomId(seed = Date.now()) {
    let s = Number(seed) >>> 0;
    s = (Math.imul(s ^ (s >>> 15), 2246822519) + 3266489917) >>> 0;
    return s.toString(36);
}

function opVariant(seed, opName, count = 3) {
    let h = ((Number(seed) >>> 0) ^ 0x52454756) >>> 0;
    for (let i = 0; i < opName.length; i++) {
        h = Math.imul((h ^ opName.charCodeAt(i)) >>> 0, 16777619) >>> 0;
    }
    h ^= h >>> 15;
    h = Math.imul(h, 0x85EBCA6B) >>> 0;
    return (h >>> 0) % Math.max(1, count);
}

function permuteSlots(seed, fields) {
    let s = (Number(seed) >>> 0) || 0x9E3779B9;
    const values = fields.map((_, i) => i + 1);
    for (let i = values.length - 1; i > 0; i--) {
        s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0;
        s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0;
        s ^= s >>> 16; s >>>= 0;
        const j = s % (i + 1);
        [values[i], values[j]] = [values[j], values[i]];
    }
    return Object.fromEntries(fields.map((field, i) => [field, values[i]]));
}

function rewriteStateLayout(output, seed, fields, initPattern) {
    const slots = permuteSlots(seed, fields);
    let out = output;
    for (const field of fields) {
        out = out.replace(new RegExp(`\\bS\\.${field}\\b`, "g"), `S[${slots[field]}]`);
        out = out.replace(new RegExp(`\\bT\\.${field}\\b`, "g"), `T[${slots[field]}]`);
    }
    const init = initPattern(slots);
    out = out.replace(init.from, init.to);
    return { output: out, slots };
}

/**
 * ByteVeil v5.9.0 polymorphic Register VM (VM-A/register) semantic handler builder.
 * Generates per-build varied register handler bodies and portable 32-bit bitwise logic
 * for both Lua 5.4 and Luau.
 */
function buildV580RegisterHandlerDefs(S, N, seed = 1) {
    const v = (name, count = 3) => opVariant(seed, name, count);
    const R = `S[${S.reg}]`;

    const binaryArith = (opName, sym, commutative = false) => {
        const k = v(opName, 3);
        if (k === 0) return `${R}[I[2]]=${R}[I[3]]${sym}${R}[I[4]]`;
        if (k === 1) {
            return commutative
                ? `local RF=${R};local B0=RF[I[4]];local A0=RF[I[3]];RF[I[2]]=B0${sym}A0`
                : `local RF=${R};local A0=RF[I[3]];local B0=RF[I[4]];RF[I[2]]=A0${sym}B0`;
        }
        return `local A0=${R}[I[3]];local B0=${R}[I[4]];local Z0=A0${sym}B0;${R}[I[2]]=Z0`;
    };

    const binaryCmp = (opName, sym, swappedSym = null) => {
        const k = v(opName, 3);
        if (k === 0) return `${R}[I[2]]=${R}[I[3]]${sym}${R}[I[4]]`;
        if (k === 1 && swappedSym) return `local RF=${R};local B0=RF[I[4]];local A0=RF[I[3]];RF[I[2]]=(B0${swappedSym}A0)`;
        return `local A0=${R}[I[3]];local B0=${R}[I[4]];${R}[I[2]]=(A0${sym}B0)`;
    };

    return {
        HALT: `S[${S.halt}]=true;return true`,
        PUSHK: v("PUSHK", 2) === 0
            ? `${R}[I[2]]=${N.const}(S,I[3])`
            : `local K0=${N.const}(S,I[3]);${R}[I[2]]=K0`,
        PUSHN: v("PUSHN", 2) === 0
            ? `${R}[I[2]]=I[3]`
            : `local V0=I[3];${R}[I[2]]=V0`,
        PUSHB: v("PUSHB", 2) === 0
            ? `${R}[I[2]]=I[3]~=0`
            : `local B0=(I[3]~=0);${R}[I[2]]=B0`,
        PUSHNIL: `${R}[I[2]]=nil`,
        GETG: v("GETG", 2) === 0
            ? `${R}[I[2]]=${N.resolveGlobal}(S,I[3])`
            : `local V0=${N.resolveGlobal}(S,I[3]);${R}[I[2]]=V0`,
        SETG: v("SETG", 2) === 0
            ? `${N.writeGlobal}(S,I[2],${R}[I[3]])`
            : `local V0=${R}[I[3]];${N.writeGlobal}(S,I[2],V0)`,
        GETL: `local T=S;local Q=${N.const}(S,I[3]);while T do if T[${S.localSet}][Q] then ${R}[I[2]]=T[${S.locals}][Q];return end;T=T[${S.parent}] end;${R}[I[2]]=nil`,
        SETL: `local T=S;local Q=${N.const}(S,I[2]);while T and not T[${S.localSet}][Q] do T=T[${S.parent}] end;if not T then T=S;T[${S.localSet}][Q]=true end;T[${S.locals}][Q]=${R}[I[3]]`,
        GETI: v("GETI", 2) === 0
            ? `${R}[I[2]]=${R}[I[3]][${R}[I[4]]]`
            : `local RF=${R};local T0=RF[I[3]];local K0=RF[I[4]];RF[I[2]]=T0[K0]`,
        SETI: v("SETI", 2) === 0
            ? `${R}[I[2]][${R}[I[3]]]=${R}[I[4]]`
            : `local RF=${R};local T0=RF[I[2]];local K0=RF[I[3]];T0[K0]=RF[I[4]]`,
        ADD: binaryArith("ADD", "+", true),
        SUB: binaryArith("SUB", "-", false),
        MUL: binaryArith("MUL", "*", true),
        DIV: binaryArith("DIV", "/", false),
        IDIV: v("IDIV", 2) === 0
            ? `${R}[I[2]]=${R}[I[3]]//${R}[I[4]]`
            : `local RF=${R};RF[I[2]]=RF[I[3]]//RF[I[4]]`,
        MOD: binaryArith("MOD", "%", false),
        POW: binaryArith("POW", "^", false),
        EQ: binaryCmp("EQ", "==", "=="),
        NE: binaryCmp("NE", "~=", "~="),
        LT: binaryCmp("LT", "<", ">"),
        GT: binaryCmp("GT", ">", "<"),
        LE: binaryCmp("LE", "<=", ">="),
        GE: binaryCmp("GE", ">=", "<="),
        NOT: v("NOT", 2) === 0 ? `${R}[I[2]]=not ${R}[I[3]]` : `local V0=${R}[I[3]];${R}[I[2]]=(not V0)`,
        NEG: v("NEG", 2) === 0 ? `${R}[I[2]]=-${R}[I[3]]` : `local V0=${R}[I[3]];${R}[I[2]]=-V0`,
        LEN: v("LEN", 2) === 0 ? `${R}[I[2]]=#${R}[I[3]]` : `local V0=${R}[I[3]];${R}[I[2]]=#V0`,
        CONCAT: binaryArith("CONCAT", "..", false),
        AND: `${R}[I[2]]=${R}[I[3]] and ${R}[I[4]]`,
        OR: `${R}[I[2]]=${R}[I[3]] or ${R}[I[4]]`,
        BAND: `local A0=math.floor(${R}[I[3]]or 0)%4294967296;local B0=math.floor(${R}[I[4]]or 0)%4294967296;${R}[I[2]]=math.floor((A0+B0-${N.xor}(A0,B0))/2)`,
        BOR: `local A0=math.floor(${R}[I[3]]or 0)%4294967296;local B0=math.floor(${R}[I[4]]or 0)%4294967296;local H=math.floor((A0+B0-${N.xor}(A0,B0))/2);${R}[I[2]]=A0+B0-H`,
        BXOR: `${R}[I[2]]=${N.xor}(${R}[I[3]],${R}[I[4]])`,
        SHL: `local A0=math.floor(${R}[I[3]]or 0)%4294967296;local B0=math.floor(${R}[I[4]]or 0);if bit32 and bit32.lshift then ${R}[I[2]]=bit32.lshift(A0,B0)elseif B0<0 or B0>31 then ${R}[I[2]]=0 else ${R}[I[2]]=math.floor((A0*(2^B0))%4294967296)end`,
        SHR: `local A0=math.floor(${R}[I[3]]or 0)%4294967296;local B0=math.floor(${R}[I[4]]or 0);if bit32 and bit32.rshift then ${R}[I[2]]=bit32.rshift(A0,B0)elseif B0<0 or B0>31 then ${R}[I[2]]=0 else ${R}[I[2]]=math.floor(A0/(2^B0))end`,
        BNOT: `${R}[I[2]]=-1-${N.xor}(${R}[I[3]],4294967295)`,
        JMP: v("JMP", 2) === 0 ? `S[${S.pc}]=I[2]+1` : `local T0=I[2];S[${S.pc}]=T0+1`,
        JZ: v("JZ", 2) === 0
            ? `if not ${R}[I[2]] then S[${S.pc}]=I[3]+1 end`
            : `local V0=${R}[I[2]];if not V0 then S[${S.pc}]=I[3]+1 end`,
        POP: `${R}[I[2]]=nil`,
        DUP: v("DUP", 2) === 0 ? `${R}[I[2]]=${R}[I[3]]` : `local RF=${R};RF[I[2]]=RF[I[3]]`,
        NEWTABLE: `local N0=I[3]or 0;${R}[I[2]]=N0>0 and {${N.unpackBuiltin}({},1,N0)} or {}`,
        CALL: `local RF=${R};local F0=RF[I[3]];local C0=I[4]or 0;local A0={};for Q=1,C0 do A0[Q]=RF[I[4+Q]] end;local R0={F0(${N.unpackBuiltin}(A0,1,C0))};RF[I[2]]=R0[1]`,
        CALLG: `local RF=${R};local C0=I[4]or 0;local A0={};for Q=1,C0 do A0[Q]=RF[I[4+Q]] end;local F0=${N.resolveGlobal}(S,I[3]);local R0={F0(${N.unpackBuiltin}(A0,1,C0))};RF[I[2]]=R0[1]`,
        CALLM: `local RF=${R};local F0=RF[I[3]];local C0=I[4]or 0;local A0={};for Q=1,C0 do A0[Q]=RF[I[5+Q]] end;local R0={F0(${N.unpackBuiltin}(A0,1,C0))};local W0=I[5]or 1;for Q=1,W0 do RF[I[2]+Q-1]=R0[Q] end`,
        CALLGM: `local RF=${R};local C0=I[4]or 0;local A0={n=C0};for Q=1,C0 do A0[Q]=RF[I[5+Q]] end;local F0=${N.resolveGlobal}(S,I[3]);local R0={F0(${N.unpackBuiltin}(A0,1,C0))};local W0=I[5]or 1;for Q=1,W0 do RF[I[2]+Q-1]=R0[Q] end`,
        CALLV: `local RF=${R};local C0=I[4]or 0;local A0={n=0};for Q=1,C0 do A0[Q]=RF[I[4+Q]];A0.n=Q end;local P0=RF[I[5+C0]]or{n=0};local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q] end;A0.n=C0+VN;local F0=RF[I[3]];local R0={F0(${N.unpackBuiltin}(A0,1,A0.n))};RF[I[2]]=R0[1]`,
        CALLGV: `local RF=${R};local C0=I[4]or 0;local A0={n=0};for Q=1,C0 do A0[Q]=RF[I[4+Q]];A0.n=Q end;local P0=RF[I[5+C0]]or{n=0};local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q] end;A0.n=C0+VN;local F0=${N.resolveGlobal}(S,I[3]);local R0={F0(${N.unpackBuiltin}(A0,1,A0.n))};RF[I[2]]=R0[1]`,
        CALLP: `local RF=${R};local C0=I[5]or 0;local A0={n=C0};for Q=1,C0 do A0[Q]=RF[I[6+Q]]end;local P0={n=0};if I[6]==1 then P0=RF[I[7+C0]]or{n=0}end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q]end;A0.n=C0+VN;local F0;if I[3]==1 then F0=${N.resolveGlobal}(S,I[4])else F0=RF[I[4]]end;local function KP0(...)return {n=select("#",...),...}end;RF[I[2]]=KP0(F0(${N.unpackBuiltin}(A0,1,A0.n)))`,
        APPEND: `local RF=${R};local T0=RF[I[2]];local P0=RF[I[3]]or{n=0};local B0=I[4];local VN=P0.n or #P0;local H0=false;for Q=1,VN do if P0[Q]==nil then H0=true;break end end;if H0 and VN>0 then local Z0={};for Q=1,B0-1 do Z0[Q]=T0[Q]end;for Q=1,VN do Z0[B0-1+Q]=P0[Q]end;local M0={${N.unpackBuiltin}(Z0,1,B0-1+VN)};local K0,W0=next(T0);while K0 do if not (type(K0)=="number" and K0>=1 and K0<=B0-1) then M0[K0]=W0 end K0,W0=next(T0,K0)end;RF[I[2]]=M0 else for Q=1,VN do T0[B0+Q-1]=P0[Q]end end`,
        TAILCALL: `local RF=${R};local K0=I[2]or 0;local V0=I[3];local C0=I[4]or 0;local C1=I[5]or 0;local SP0=I[6]==1;local A0={n=C0};for Q=1,C0 do A0[Q]=RF[I[6+Q]]end;local P0={n=0};if SP0 then P0=RF[I[7+C0]]or{n=0}end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q]end;A0.n=C0+VN;local F0;if K0==1 then F0=${N.resolveGlobal}(S,V0)else F0=RF[V0]end;local function PK0(...)return{n=select("#",...),...}end;local T0=PK0(F0(${N.unpackBuiltin}(A0,1,A0.n)));local R0={n=C1+(T0.n or 0)};local BASE=6+C0+(SP0 and 1 or 0);for Q=1,C1 do R0[Q]=RF[I[BASE+Q]]end;for Q=1,(T0.n or 0)do R0[C1+Q]=T0[Q]end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        RETURN: `local RF=${R};local C0=I[2]or 0;local R0={n=C0};for Q=1,C0 do R0[Q]=RF[I[2+Q]] end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        RETURNV: `local RF=${R};local C0=I[2]or 0;local P0=RF[I[3+C0]]or{n=0};local VN=P0.n or #P0;local R0={n=C0+VN};for Q=1,C0 do R0[Q]=RF[I[2+Q]] end;for Q=1,VN do R0[C0+Q]=P0[Q] end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        MAKEFUNC: `local X0=${N.const}(S,I[3]);local P0=S;${R}[I[2]]=function(...)return ${N.run}(X0,P0,...)end`,
        VARARG: `local A0=S[${S.varargs}]or{};${R}[I[2]]=A0[1]`,
        VARARGS: `${R}[I[2]]=S[${S.varargs}]or{n=0}`,
        BREAK: `S[${S.halt}]=true;return true`,
        SWAP: `local RF=${R};local A0=RF[I[2]];RF[I[2]]=RF[I[3]];RF[I[3]]=A0`,
        MOVE_SELF: `${R}[I[2]]=${R}[I[3]]`,
        FORCMP: `local RF=${R};local ST=RF[I[4]];local LM=RF[I[3]];local IX=RF[I[2]];RF[I[2]]=(ST>=0 and IX<=LM)or(ST<0 and IX>=LM)`,
        SETFIELD: `${R}[I[2]][I[3]]=${R}[I[4]]`,
        GETFIELD: `${R}[I[2]]=${R}[I[3]][I[4]]`,
        SUPER: `local F=${N.superFns}[I[2]];if not F then error("ByteVeil SUPER dispatch failed",0)end;return F(S,I)`,
        ITERPREP: `local RF=${R};local B=I[2];local T={RF[B],RF[B+1],RF[B+2]};if type(T[1])=="table" then T={next,T[1],nil} end;S[${S.iter}][#S[${S.iter}]+1]=T`,
        ITERLOOP: `local T=S[${S.iter}][#S[${S.iter}]];if not T or type(T[1])~="function" then S[${S.iter}][#S[${S.iter}]]=nil;S[${S.pc}]=I[2]+1;return end;local R0={T[1](T[2],T[3])};if R0[1]==nil then S[${S.iter}][#S[${S.iter}]]=nil;S[${S.pc}]=I[2]+1;return end;T[3]=R0[1];for Q=1,(I[3]or 0) do local N0=${N.const}(S,I[3+Q]);S[${S.locals}][N0]=R0[Q];S[${S.localSet}][N0]=true end`
    };
}

function buildRegisterHandlers(n) {
    const h = [];
    const add = (name, body) => {
        if (!n.h[name]) return;
        h.push(`local function ${n.h[name]}(S,I,...)${body};end`);
    };

    add("HALT", `S.halt=true;return true`);
    add("PUSHK", `S.reg[I[2]]=S.consts[I[3]+1]`);
    add("PUSHN", `S.reg[I[2]]=I[3]`);
    add("PUSHB", `S.reg[I[2]]=I[3]~=0`);
    add("PUSHNIL", `S.reg[I[2]]=nil`);
    add("GETG", `S.reg[I[2]]=S.env[S.consts[I[3]+1]]`);
    add("SETG", `S.env[S.consts[I[2]+1]]=S.reg[I[3]]`);
    add("GETL", `local T=S;local N=S.consts[I[3]+1];while T do if T.localSet[N] then S.reg[I[2]]=T.locals[N];break end;T=T.parent end;if not T then S.reg[I[2]]=nil end`);
    add("SETL", `local T=S;local N=S.consts[I[2]+1];while T and not T.localSet[N] do T=T.parent end;if not T then T=S;T.localSet[N]=true end;T.locals[N]=S.reg[I[3]]`);
    add("GETI", `S.reg[I[2]]=S.reg[I[3]][S.reg[I[4]]]`);
    add("SETI", `S.reg[I[2]][S.reg[I[3]]]=S.reg[I[4]]`);
    add("ADD", `S.reg[I[2]]=S.reg[I[3]]+S.reg[I[4]]`);
    add("SUB", `S.reg[I[2]]=S.reg[I[3]]-S.reg[I[4]]`);
    add("MUL", `S.reg[I[2]]=S.reg[I[3]]*S.reg[I[4]]`);
    add("DIV", `S.reg[I[2]]=S.reg[I[3]]/S.reg[I[4]]`);
    add("IDIV", `S.reg[I[2]]=S.reg[I[3]]//S.reg[I[4]]`);
    add("MOD", `S.reg[I[2]]=S.reg[I[3]]%S.reg[I[4]]`);
    add("POW", `S.reg[I[2]]=S.reg[I[3]]^S.reg[I[4]]`);
    add("EQ", `S.reg[I[2]]=S.reg[I[3]]==S.reg[I[4]]`);
    add("NE", `S.reg[I[2]]=S.reg[I[3]]~=S.reg[I[4]]`);
    add("LT", `S.reg[I[2]]=S.reg[I[3]]<S.reg[I[4]]`);
    add("GT", `S.reg[I[2]]=S.reg[I[3]]>S.reg[I[4]]`);
    add("LE", `S.reg[I[2]]=S.reg[I[3]]<=S.reg[I[4]]`);
    add("GE", `S.reg[I[2]]=S.reg[I[3]]>=S.reg[I[4]]`);
    add("NOT", `S.reg[I[2]]=not S.reg[I[3]]`);
    add("NEG", `S.reg[I[2]]=-S.reg[I[3]]`);
    add("LEN", `S.reg[I[2]]=#S.reg[I[3]]`);
    add("CONCAT", `S.reg[I[2]]=S.reg[I[3]]..S.reg[I[4]]`);
    add("AND", `S.reg[I[2]]=S.reg[I[3]] and S.reg[I[4]]`);
    add("OR", `S.reg[I[2]]=S.reg[I[3]] or S.reg[I[4]]`);
    add("BAND", `S.reg[I[2]]=${n.band}(S.reg[I[3]],S.reg[I[4]])`);
    add("BOR", `S.reg[I[2]]=${n.bor}(S.reg[I[3]],S.reg[I[4]])`);
    add("BXOR", `S.reg[I[2]]=${n.bxor}(S.reg[I[3]],S.reg[I[4]])`);
    add("SHL", `S.reg[I[2]]=${n.shl}(S.reg[I[3]],S.reg[I[4]])`);
    add("SHR", `S.reg[I[2]]=${n.shr}(S.reg[I[3]],S.reg[I[4]])`);
    add("BNOT", `local V=${n.bxor}(S.reg[I[3]],4294967295);if V>=2147483648 then V=V-4294967296 end;S.reg[I[2]]=V`);
    add("JMP", `S.pc=I[2]+1`);
    add("JZ", `if not S.reg[I[2]] then S.pc=I[3]+1 end`);
    add("CALL", `local f=S.reg[I[3]];local c=I[4]or 0;local a={};for q=1,c do a[q]=S.reg[I[4+q]] end;local r={f(${n.unpackBuiltin}(a,1,c))};S.reg[I[2]]=r[1]`);
    add("CALLG", `local c=I[4]or 0;local a={};for q=1,c do a[q]=S.reg[I[4+q]] end;local f=S.env[S.consts[I[3]+1]];local r={f(${n.unpackBuiltin}(a,1,c))};S.reg[I[2]]=r[1]`);
    add("CALLM", `local f=S.reg[I[3]];local c=I[4]or 0;local a={};for q=1,c do a[q]=S.reg[I[5+q]] end;local r={f(${n.unpackBuiltin}(a,1,c))};local w=I[5]or 1;for q=1,w do S.reg[I[2]+q-1]=r[q] end`);
    add("CALLGM", `local c=I[4]or 0;local a={n=c};for q=1,c do a[q]=S.reg[I[5+q]] end;local f=S.env[S.consts[I[3]+1]];local r={f(${n.unpackBuiltin}(a,1,c))};local w=I[5]or 1;for q=1,w do S.reg[I[2]+q-1]=r[q] end`);
    add("CALLV", `local c=I[4]or 0;local a={n=0};for q=1,c do a[q]=S.reg[I[4+q]];a.n=q end;local p=S.reg[I[5+c]]or{n=0};local vn=p.n or #p;for q=1,vn do a[c+q]=p[q] end;a.n=c+vn;local f=S.reg[I[3]];local r={f(${n.unpackBuiltin}(a,1,a.n))};S.reg[I[2]]=r[1]`);
    add("CALLGV", `local c=I[4]or 0;local a={n=0};for q=1,c do a[q]=S.reg[I[4+q]];a.n=q end;local p=S.reg[I[5+c]]or{n=0};local vn=p.n or #p;for q=1,vn do a[c+q]=p[q] end;a.n=c+vn;local f=S.env[S.consts[I[3]+1]];local r={f(${n.unpackBuiltin}(a,1,a.n))};S.reg[I[2]]=r[1]`);
    add("TAILCALL", `local k0=I[2]or 0;local v0=I[3];local c0=I[4]or 0;local c1=I[5]or 0;local sp0=I[6]==1;local a0={n=c0};for q=1,c0 do a0[q]=S.reg[I[6+q]]end;local p0={n=0};if sp0 then p0=S.reg[I[7+c0]]or{n=0}end;local vn=p0.n or #p0;for q=1,vn do a0[c0+q]=p0[q]end;a0.n=c0+vn;local f0;if k0==1 then f0=S.env[S.consts[v0+1]]else f0=S.reg[v0]end;local function pk0(...)return{n=select("#",...),...}end;local t0=pk0(f0(${n.unpackBuiltin}(a0,1,a0.n)));local r0={n=c1+(t0.n or 0)};local base=6+c0+(sp0 and 1 or 0);for q=1,c1 do r0[q]=S.reg[I[base+q]]end;for q=1,(t0.n or 0)do r0[c1+q]=t0[q]end;S.halt=true;S.ret=r0;return true`);
    add("RETURN", `local C0=I[2]or 0;local r={n=C0};for q=1,C0 do r[q]=S.reg[I[2+q]] end;S.halt=true;S.ret=r;return true`);
    add("RETURNV", `local c0=I[2]or 0;local p0=S.reg[I[3+c0]]or{n=0};local vn=p0.n or #p0;local r0={n=c0+vn};for q=1,c0 do r0[q]=S.reg[I[2+q]] end;for q=1,vn do r0[c0+q]=p0[q] end;S.halt=true;S.ret=r0;return true`);
    add("POP", `S.reg[I[2]]=nil`);
    add("DUP", `S.reg[I[2]]=S.reg[I[3]]`);
    add("NEWTABLE", `local c0=I[3]or 0;S.reg[I[2]]=c0>0 and {${n.unpackBuiltin}({},1,c0)} or {}`);
    add("MAKEFUNC", `local X=S.consts[I[3]+1];local P=S;S.reg[I[2]]=function(...)return ${n.run}(X,P,...)end`);
    add("VARARG", `local a0=S.varargs or {};S.reg[I[2]]=a0[1]`);
    add("VARARGS", `S.reg[I[2]]=S.varargs or {n=0}`);
    add("BREAK", `S.halt=true;return true`);
    add("SWAP", `local V=S.reg[I[2]];S.reg[I[2]]=S.reg[I[3]];S.reg[I[3]]=V`);
    add("MOVE_SELF", `S.reg[I[2]]=S.reg[I[3]]`);
    add("FORCMP", `local i=S.reg[I[2]];local l=S.reg[I[3]];local st=S.reg[I[4]];S.reg[I[2]]=(st>=0 and i<=l)or(st<0 and i>=l)`);
    add("ITERPREP", `local b=I[2];local t={S.reg[b],S.reg[b+1],S.reg[b+2]};if type(t[1])=="table"then t={next,t[1],nil}end;S.iter[#S.iter+1]=t`);
    add("ITERLOOP", `local t=S.iter[#S.iter];if not t or type(t[1])~="function"then S.iter[#S.iter]=nil;S.pc=I[2]+1;return end;local r0={t[1](t[2],t[3])};if r0[1]==nil then S.iter[#S.iter]=nil;S.pc=I[2]+1;return end;t[3]=r0[1];for q=1,(I[3]or 0)do local n0=S.consts[I[3+q]+1];S.locals[n0]=r0[q];S.localSet[n0]=true end`);
    add("SETFIELD", `S.reg[I[2]][I[3]]=S.reg[I[4]]`);
    add("GETFIELD", `S.reg[I[2]]=S.reg[I[3]][I[4]]`);

    return h;
}

function buildGeneratedSource(bytecode, seed, options = {}) {
    const n = {
        state: `_${randomId(seed ^ 0x10A0)}`,
        decode: `_${randomId(seed ^ 0x20B0)}`,
        dispatch: `_${randomId(seed ^ 0x30C0)}`,
        run: `_${randomId(seed ^ 0x40D0)}`,
        unpack: `_${randomId(seed ^ 0x50E0)}`,
        handlers: `_${randomId(seed ^ 0x60F0)}`,
        slot: `_${randomId(seed ^ 0x70F1)}`,
        blob: `_${randomId(seed ^ 0x70A1)}`,
        key: `_${randomId(seed ^ 0x80B2)}`,
        root: `_${randomId(seed ^ 0x90C3)}`,
        raw: `_${randomId(seed ^ 0x9A14)}`,
        result: `_${randomId(seed ^ 0xA0D4)}`,
        pack: `_${randomId(seed ^ 0xA1E5)}`,
        env: `_${randomId(seed ^ 0xA2F6)}`,
        g1: `_${randomId(seed ^ 0xB101)}`,
        g5: `_${randomId(seed ^ 0xB505)}`,
        g6: `_${randomId(seed ^ 0xB606)}`,
        g7: `_${randomId(seed ^ 0xB707)}`,
        payloadCheck: `_${randomId(seed ^ 0xC313)}`,
        band: `_${randomId(seed ^ 0xC414)}`,
        bor: `_${randomId(seed ^ 0xC515)}`,
        bxor: `_${randomId(seed ^ 0xC616)}`,
        shl: `_${randomId(seed ^ 0xC717)}`,
        shr: `_${randomId(seed ^ 0xC818)}`,
        unpackBuiltin: `_${randomId(seed ^ 0xC919)}`,
        h: {}
    };

    for (const name of bytecode.opcode || []) {
        n.h[name] = `_${randomId(
            seed ^ name.split("").reduce((a, c) => ((a * 33) ^ c.charCodeAt(0)) >>> 0, 5381)
        )}`;
    }

    const packed = encodeBytecodeBlob(
        bytecode,
        seed,
        { opcodeWhitening: options.opcodeWhitening !== false }
    );

    const ops = Array.isArray(bytecode.opcode) ? bytecode.opcode : [];
    const tamperParams = deriveTamperParams(seed);

    const lines = [];
    lines.push(`local ${n.env}=((getgenv and getgenv())or(getfenv and getfenv(0))or(getfenv and getfenv(1))or _G)`);
    lines.push(`local ${n.payloadCheck}=function(D)local H=${tamperParams.initHash};for I=1,#D do H=(H*${tamperParams.mult}+string.byte(D,I)*${tamperParams.posFactor}+(I%${tamperParams.posMod})+${tamperParams.bias})%2147483647 end;return H end`);
    lines.push(`local ${n.band}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;if bit32 and bit32.band then return bit32.band(A,B)end;local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a==1 and b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.bor}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;if bit32 and bit32.bor then return bit32.bor(A,B)end;local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a==1 or b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.bxor}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;if bit32 and bit32.bxor then return bit32.bxor(A,B)end;local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.shl}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if bit32 and bit32.lshift then return bit32.lshift(A,B)end;if B<0 or B>31 then return 0 end;return math.floor((A*2^B)%4294967296)end`);
    lines.push(`local ${n.shr}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if bit32 and bit32.rshift then return bit32.rshift(A,B)end;if B<0 or B>31 then return 0 end;return math.floor(A/2^B)end`);
    lines.push(`local ${n.unpackBuiltin}=table.unpack or unpack`);
    lines.push(`local ${n.run}`);
    lines.push(`local ${n.handlers}={}`);
    lines.push(
        `local ${n.unpack}=function(B,Q,L)local O={};local S=Q%4294967296;local function X(A,B0)return ${n.bxor}(A,B0)end;local function I(A,B0)A=A%4294967296;B0=B0%4294967296;local a=A%65536;local ah=math.floor(A/65536);local b=B0%65536;local bh=math.floor(B0/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;local K={};local KS=${n.bxor}(Q,3235823838);if KS==0 then KS=2738958700 end;for KI=1,20 do KS=${n.bxor}(KS,math.floor(KS/65536));KS=I(KS,2246822519);KS=${n.bxor}(KS,math.floor(KS/8192));KS=I(KS,3266489917);KS=${n.bxor}(KS,math.floor(KS/65536));K[KI]=(${n.bxor}(KS,((KI*73244475)%4294967296)))%256 end;for J=1,L do S=X(S,math.floor(S/32768));S=I(S,2246822519);S=X(S,(S*8192)%4294967296);S=I(S,3266489917);local M=${n.bxor}(K[((J-1)%#K)+1],${n.bxor}(S%256,(((J-1)*29+71)%256)))%256;local V=(string.byte(B,J)-(((J-1)*17)%256)+256)%256;O[J]=string.char(${n.bxor}(V,M)%256)end;return table.concat(O)end`
    );
    lines.push(
        `local ${n.state}=function(E,V)return{pc=1,reg={},locals={},localSet={},parent=nil,env=E,consts=V,code=nil,halt=false,ret={},varargs={},guard=0,iter={}}end`
    );
    lines.push(`local ${n.g1}=function(V)return type(V)=="table" end`);
    lines.push(`local ${n.g5}=function(V)return V and V.k~=nil end`);
    lines.push(`local ${n.g6}=function(V)return V and V.c~=nil end`);
    lines.push(`local ${n.g7}=function(V)return V and V.p~=nil end`);
    lines.push(
        `local function ${n.decode}(D)local P=1;local function U()local V=0;local M=1;while true do local B=string.byte(D,P);P=P+1;V=V+${n.band}(B,127)*M;if B<128 then return V end;M=M*128 end end;local function R(N)local V=D:sub(P,P+N-1);P=P+N;return V end;local function S()return R(U())end;local function N()local T=string.byte(D,P);P=P+1;if T==0 then local V=U();return(V%2==0)and(V/2)or-((V+1)/2)else return tonumber(S()) end end;local function C()local K={};local KC=U();for I=1,KC do local T=string.byte(D,P);P=P+1;if T==83 then K[I]=S()elseif T==78 then K[I]=N()elseif T==84 then K[I]=true elseif T==70 then K[I]=false elseif T==90 then K[I]=nil elseif T==67 then K[I]=C()end end;local X={k=K};local PC=U();X.p={};for I=1,PC do X.p[I]=S()end;X.v=string.byte(D,P)==1;P=P+1;local IC=U();X.c={};for I=1,IC do local AC=U();local Q={};for J=1,AC do Q[J]=N()end;X.c[I]=Q end;return X end;return C()end`
    );

    lines.push(...buildRegisterHandlers(n));

    const handlerCount = Math.max(1, ops.length);
    let handlerMul = 3 + (seed % 23);
    const gcd = (a, b) => { while (b) { const t = a % b; a = b; b = t; } return a; };
    while (gcd(handlerMul, handlerCount) !== 1) handlerMul++;
    const handlerAdd = handlerCount ? ((seed >>> 7) % handlerCount) : 0;
    lines.push(`local ${n.slot}=function(OP)return((OP*${handlerMul}+${handlerAdd})%${handlerCount})+1 end`);
    lines.push(`local ${n.handlers}={}`);
    for (const name of ops) {
        const op = bytecode.map.encode[name];
        const slot = ((op * handlerMul + handlerAdd) % handlerCount) + 1;
        lines.push(`${n.handlers}[${slot}]=${n.h[name]}`);
    }

    lines.push(
        `local ${n.dispatch}=function(S)local G=S.guard or 0;while not S.halt do local I=S.code[S.pc];if not I then S.halt=true;break end;local O=I[1];${packed.opcodeMask ? `O=${n.bxor}(O,${packed.opcodeMask})` : ""};S.pc=S.pc+1;G=(G*1664525+O*101+S.pc+1013904223)%4294967296;S.guard=G;local H=${n.handlers}[${n.slot}(O)];if not H then error("ByteVeil VM error",0)end;local X=H(S,I);if X then break end end;return S end`
    );

    lines.push(
        `${n.run}=function(X,P,...)local E=P and P.env or ${n.env};local S=${n.state}(E,X.k);S.parent=P;S.code=X.c;local PC0=#(X.p or {});S.varargs={select(PC0+1,...)};S.varargs.n=math.max(0,select("#",...)-PC0);S.guard=${(seed * 2654435761) % 4294967296};for Q=1,PC0 do local N=X.p[Q];S.locals[N]=select(Q,...);S.localSet[N]=true end;${n.dispatch}(S);return ${n.unpackBuiltin}(S.ret or {},1,(S.ret and S.ret.n)or #(S.ret or {}))end`
    );

    lines.push(`local ${n.blob}=${packed.blob}`);
    lines.push(`local ${n.raw}=${n.unpack}(${n.blob},${packed.state},${packed.byteLength})`);
    lines.push(`if ${n.payloadCheck}(${n.raw})~=${packed.checksum} then error("ByteVeil payload integrity failed",0) end`);
    lines.push(`local ${n.root}=${n.decode}(${n.raw})`);
    lines.push(`if not (${n.g1}(${n.root}) and ${n.g5}(${n.root}) and ${n.g6}(${n.root}) and ${n.g7}(${n.root})) then error("ByteVeil VM validation failed",0) end`);
    lines.push(`local function ${n.pack}(...)return{n=select("#",...),...}end`);
    lines.push(`local ${n.result}=${n.pack}(${n.run}(${n.root},nil,...))`);
    lines.push(`return ${n.unpackBuiltin}(${n.result},1,${n.result}.n)`);

    let output = lines.join("\n");
    const state = rewriteStateLayout(output, seed, ["pc", "reg", "locals", "localSet", "parent", "env", "consts", "code", "halt", "ret", "varargs", "guard", "iter"], (slots) => ({
        from: /return\{pc=1,reg=\{\},locals=\{\},localSet=\{\},parent=nil,env=E,consts=V,code=nil,halt=false,ret=\{\},varargs=\{\},guard=0,iter=\{\}\}end/,
        to: `return{[${slots.pc}]=1,[${slots.reg}]={},[${slots.locals}]={},[${slots.localSet}]={},[${slots.parent}]=nil,[${slots.env}]=E,[${slots.consts}]=V,[${slots.code}]=nil,[${slots.halt}]=false,[${slots.ret}]={},[${slots.varargs}]={},[${slots.guard}]=0,[${slots.iter}]={}}end`
    }));
    output = state.output;
    output = output.replace(/\bByteCode\b/g, "ByteVeil");
    return output;
}

function buildGeneratedSourceV40(bytecode, options = {}) {
    if (!bytecode || !bytecode.map) {
        throw new TypeError("Register VM generator v5.9.0: invalid bytecode");
    }
    const { buildGeneratedSourceV40: buildPackedV40 } = require("../stack/vm_generator");
    return buildPackedV40(bytecode, {
        ...options,
        mode: "register"
    });
}

function generate(bytecode, options = {}) {
    if (!bytecode || !bytecode.map) {
        throw new TypeError("Register VM generator: invalid bytecode");
    }
    const seed = Number(options.seed ?? Date.now()) >>> 0;
    const generated = buildGeneratedSourceV40(bytecode, {
        ...options,
        seed,
        mode: "register",
        version: options.version || "5.9.0"
    });
    return typeof generated === "object" && generated !== null && typeof generated.output === "string"
        ? generated.output
        : String(generated);
}

module.exports = {
    generate,
    buildGeneratedSource,
    buildGeneratedSourceV40,
    buildGeneratedSourceV39: buildGeneratedSourceV40,
    buildGeneratedSourceV38: buildGeneratedSourceV40,
    buildGeneratedSourceV35: buildGeneratedSourceV40,
    buildRegisterHandlers,
    buildV580RegisterHandlerDefs
};

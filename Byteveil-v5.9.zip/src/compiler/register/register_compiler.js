"use strict";
const { buildRegisterISAPlan, REGISTER_SEMANTIC_OPS } = require("./register_isa_v479");
const { ConstantPool } = require("../../obfuscation/constant_pool");
const { numberOperand } = require("../number_operand");
const { tableArraySizeHint } = require("../table_array_hint");

function compile(ast, seed = 1, context = {}) {
    const map = context.map || buildRegisterISAPlan((seed + 911) >>> 0, { lanes: 4 });
    const code = [], pool = new ConstantPool();
    const consts = pool.items;
    let nextReg = 0;
    let localNames = new Set([...(context.visibleNames || []), ...(ast.params || []), ...(ast.locals || [])]);
    const loopBreaks = [];
    const loopContinues = [];
    const pushLoop = () => { const ctx = []; loopBreaks.push(ctx); loopContinues.push([]); return ctx; };
    const popLoop = (ctx, exit, continueTarget = exit) => {
        for (const at of ctx) patch(at, 1, exit);
        const continues = loopContinues.pop() || [];
        for (const at of continues) patch(at, 1, continueTarget);
        loopBreaks.pop();
    };
    const k = (v) => pool.add(v);
    const emit = (name, ...a) => { code.push([map.encode[name], ...a]); return code.length - 1; };
    const regBlocks = [];
    const reg = () => nextReg++;
    const regBlock = (count) => {
        const span = Math.max(1, Number(count) | 0);
        const base = nextReg;
        nextReg += span;
        if (span > 1) regBlocks.push({ base, count: span });
        return base;
    };
    const patch = (at, idx, value) => { code[at][idx] = value; };

    function ex(x) {
        const r = reg();
        if (!x) { emit("PUSHNIL", r); return r; }

        switch (x.type) {
            case "Number": emit("PUSHN", r, numberOperand(x)); break;
            case "String": emit("PUSHK", r, k(String(x.value))); break;
            case "Boolean": emit("PUSHB", r, x.value ? 1 : 0); break;
            case "Nil": emit("PUSHNIL", r); break;
            case "Id": {
                const name = String(x.name);
                emit(localNames.has(name) ? "GETL" : "GETG", r, k(name));
                break;
            }
            case "Vararg": emit("VARARG", r); break;
            case "Unary": {
                const a = ex(x.arg);
                emit({ not: "NOT", "-": "NEG", "#": "LEN", "~": "BNOT" }[x.op] || "NOT", r, a);
                break;
            }
            case "IfElseExpression": {
                const c = ex(x.cond);
                const falseJump = emit("JZ", c, 0);
                const a = ex(x.consequent);
                emit("DUP", r, a);
                const endJump = emit("JMP", 0);
                patch(falseJump, 2, code.length);
                const b = ex(x.alternate);
                emit("DUP", r, b);
                patch(endJump, 1, code.length);
                break;
            }
            case "Binary": {
                if (x.op === "and" || x.op === "or") {
                    const a = ex(x.left);
                    emit("DUP", r, a);
                    const falseJump = emit("JZ", r, 0);

                    if (x.op === "and") {
                        const b = ex(x.right);
                        emit("DUP", r, b);
                        patch(falseJump, 2, code.length);
                    } else {
                        const endJump = emit("JMP", 0);
                        patch(falseJump, 2, code.length);
                        const b = ex(x.right);
                        emit("DUP", r, b);
                        patch(endJump, 1, code.length);
                    }
                    break;
                }

                const a = ex(x.left), b = ex(x.right);
                const op = {
                    "+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV",
                    "//": "IDIV", "%": "MOD", "^": "POW", "==": "EQ",
                    "~=": "NE", "<": "LT", ">": "GT", "<=": "LE",
                    ">=": "GE", "..": "CONCAT", "&": "BAND", "|": "BOR",
                    "~": "BXOR", "<<": "SHL", ">>": "SHR"
                }[x.op] || "ADD";

                emit(op, r, a, b);
                break;
            }
            case "Index": {
                const a = ex(x.obj), b = ex(x.key);
                emit("GETI", r, a, b);
                break;
            }
            case "Call": {
                const nodes = x.args || [];
                const tail = nodes.length ? nodes[nodes.length - 1] : null;
                const spreadsTail = !!tail && expandableTail(tail);
                const fixedNodes = spreadsTail ? nodes.slice(0, -1) : nodes;
                const tailReg = spreadsTail ? packOf(tail) : null;

                if (!x.method && x.callee?.type === "Id" && !localNames.has(String(x.callee.name))) {
                    const args = fixedNodes.map(ex);
                    emit(
                        spreadsTail ? "CALLGV" : "CALLG",
                        r,
                        k(String(x.callee.name)),
                        args.length,
                        ...args,
                        ...(tailReg === null ? [] : [tailReg])
                    );
                } else if (x.method) {
                    const self = ex(x.callee.obj);
                    const key = ex(x.callee.key);
                    const f = reg();
                    emit("GETI", f, self, key);
                    const args = fixedNodes.map(ex);
                    const callArgs = [self, ...args];
                    emit(
                        spreadsTail ? "CALLV" : "CALL",
                        r, f, callArgs.length,
                        ...callArgs,
                        ...(tailReg === null ? [] : [tailReg])
                    );
                } else {
                    const f = ex(x.callee);
                    const args = fixedNodes.map(ex);
                    emit(
                        spreadsTail ? "CALLV" : "CALL",
                        r, f, args.length,
                        ...args,
                        ...(tailReg === null ? [] : [tailReg])
                    );
                }
                break;
            }
            case "FunctionExpr": {
                const sub = compile(
                    { type: "Chunk", body: x.body || [], params: x.params || [], vararg: !!x.vararg },
                    seed + nextReg + 77,
                    { visibleNames: new Set(localNames), map }
                );
                sub.params = x.params || [];
                sub.vararg = !!x.vararg;
                emit("MAKEFUNC", r, k({ __chunk: sub }));
                break;
            }
            case "Table": {
                const fields = x.fields || [];
                emit("NEWTABLE", r, tableArraySizeHint(fields));
                let implicitCount = 0;
                for (let i = 0; i < fields.length; i++) {
                    const field = fields[i];
                    const isExpandTail = i === fields.length - 1 && !field.explicit && expandableTail(field.value);
                    if (isExpandTail) {
                        emit("APPEND", r, packOf(field.value), implicitCount + 1);
                        continue;
                    }
                    const keyReg = field.key
                        ? ex(field.key)
                        : (() => { const q = reg(); emit("PUSHN", q, implicitCount + 1); return q; })();
                    if (!field.explicit) implicitCount++;
                    const valueReg = ex(field.value);
                    emit("SETI", r, keyReg, valueReg);
                }
                break;
            }
            default: emit("PUSHNIL", r);
        }

        return r;
    }

    function expandableTail(value) {
        return !!value && (value.type === "Vararg" || (value.type === "Call" && value.singleResult !== true));
    }

    function hasExpandableArgTail(call) {
        const args = call?.args || [];
        return args.length > 0 && expandableTail(args[args.length - 1]);
    }

    // CALLP writes every result of a call - including nil holes and the
    // zero-result case - into an explicit {n=..., [1..n]=...} pack register.
    // Pack registers are what APPEND, CALLV/CALLGV and TAILCALL consume, so one
    // opcode covers table tails, expanded call arguments and expanded returns.
    function callPackReg(x) {
        const nodes = x.args || [];
        const tail = nodes.length ? nodes[nodes.length - 1] : null;
        const spreadsTail = !!tail && expandableTail(tail);
        const fixedNodes = spreadsTail ? nodes.slice(0, -1) : nodes;
        const args = fixedNodes.map(ex);
        const tailReg = spreadsTail ? packOf(tail) : null;
        const trailing = tailReg === null ? [] : [tailReg];
        const r = reg();

        if (!x.method && x.callee?.type === "Id" && !localNames.has(String(x.callee.name))) {
            emit("CALLP", r, 1, k(String(x.callee.name)), args.length, tailReg === null ? 0 : 1, ...args, ...trailing);
        } else if (x.method) {
            const self = ex(x.callee.obj);
            const key = ex(x.callee.key);
            const f = reg();
            emit("GETI", f, self, key);
            const callArgs = [self, ...args];
            emit("CALLP", r, 0, f, callArgs.length, tailReg === null ? 0 : 1, ...callArgs, ...trailing);
        } else {
            const f = ex(x.callee);
            emit("CALLP", r, 0, f, args.length, tailReg === null ? 0 : 1, ...args, ...trailing);
        }
        return r;
    }

    function packOf(x) {
        if (x.type === "Vararg") { const q = reg(); emit("VARARGS", q); return q; }
        return callPackReg(x);
    }

    function stmt(s) {
        switch (s.type) {
            case "Local":
            case "Assign": {
                const values = s.values || [], vars = s.vars || [];
                const targets = vars.map((v) => typeof v === "string" ? { type: "Id", name: v } : v);
                const hasVarargTail = values.length > 0 && values[values.length - 1]?.type === "Vararg";
                const varargPrefixCount = Math.max(0, values.length - 1);

                if (hasVarargTail && targets.length > varargPrefixCount && targets.every((v) => v && v.type === "Id")) {
                    const temp = reg();
                    const pack = reg();
                    emit("NEWTABLE", temp, 0);
                    emit("VARARGS", pack);

                    for (let i = 0; i < targets.length; i++) {
                        const keyReg = reg();
                        emit("PUSHN", keyReg, i + 1);
                        let valueReg;

                        if (i < varargPrefixCount) {
                            valueReg = ex(values[i]);
                        } else {
                            const argKey = reg();
                            valueReg = reg();
                            emit("PUSHN", argKey, i - varargPrefixCount + 1);
                            emit("GETI", valueReg, pack, argKey);
                        }

                        emit("SETI", temp, keyReg, valueReg);
                    }

                    if (s.type === "Local") {
                        for (const target of targets) localNames.add(String(target.name));
                    }

                    for (let i = 0; i < targets.length; i++) {
                        const keyReg = reg();
                        const valueReg = reg();
                        emit("PUSHN", keyReg, i + 1);
                        emit("GETI", valueReg, temp, keyReg);
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", k(name), valueReg);
                    }
                    break;
                }

                // Preserve Lua's parallel-assignment rule: evaluate every RHS first,
                // then perform all stores. Complex indexed multi-assignment is routed
                // out of the strict VM by semantic validation.
                if (
                    targets.length > 1 && targets.every((v) => v && v.type === "Id") &&
                    values.length === 1 && values[0]?.type === "Call" &&
                    values[0].singleResult !== true && hasExpandableArgTail(values[0])
                ) {
                    // `local a, b = g(f())` expands on both sides, so the results are
                    // kept in the CALLP pack and read back per target.
                    const pack = callPackReg(values[0]);
                    if (s.type === "Local") for (const target of targets) localNames.add(String(target.name));
                    for (let i = 0; i < targets.length; i++) {
                        const keyReg = reg();
                        const valueReg = reg();
                        emit("PUSHN", keyReg, i + 1);
                        emit("GETI", valueReg, pack, keyReg);
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", k(name), valueReg);
                    }
                    break;
                }

                if (
                    targets.length > 1 &&
                    targets.every((v) => v && v.type === "Id") &&
                    values.length > 0 &&
                    values[values.length - 1]?.type === "Call" &&
                    values[values.length - 1]?.singleResult !== true
                ) {
                    const rhsRegs = [];
                    const prefixCount = Math.max(0, values.length - 1);

                    for (let i = 0; i < prefixCount; i++) rhsRegs.push(ex(values[i]));

                    const call = values[values.length - 1];
                    const want = Math.max(1, targets.length - prefixCount);
                    let base;

                    if (!call.method && call.callee?.type === "Id" && !localNames.has(String(call.callee.name))) {
                        const args = (call.args || []).map(ex);
                        base = regBlock(want);
                        emit("CALLGM", base, k(String(call.callee.name)), args.length, want, ...args);
                    } else if (call.method) {
                        const self = ex(call.callee.obj);
                        const key = ex(call.callee.key);
                        const f = reg();
                        emit("GETI", f, self, key);
                        const args = [self, ...(call.args || []).map(ex)];
                        base = regBlock(want);
                        emit("CALLM", base, f, args.length, want, ...args);
                    } else {
                        const f = ex(call.callee);
                        const args = (call.args || []).map(ex);
                        base = regBlock(want);
                        emit("CALLM", base, f, args.length, want, ...args);
                    }

                    for (let i = 0; i < want; i++) rhsRegs.push(base + i);
                    if (s.type === "Local") {
                        for (const target of targets) localNames.add(String(target.name));
                    }

                    for (let i = 0; i < targets.length; i++) {
                        const valueReg = rhsRegs[i] ?? (() => { const z = reg(); emit("PUSHNIL", z); return z; })();
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", k(name), valueReg);
                    }
                    break;
                }

                if (targets.length > 1 && targets.every((v) => v && v.type === "Id")) {
                    const temp = reg();
                    const total = Math.max(values.length, targets.length);
                    emit("NEWTABLE", temp, 0);

                    for (let i = 0; i < total; i++) {
                        const keyReg = reg();
                        emit("PUSHN", keyReg, i + 1);
                        const valueReg = i < values.length
                            ? ex(values[i])
                            : (() => { const z = reg(); emit("PUSHNIL", z); return z; })();
                        emit("SETI", temp, keyReg, valueReg);
                    }

                    if (s.type === "Local") {
                        for (const target of targets) localNames.add(String(target.name));
                    }

                    for (let i = 0; i < targets.length; i++) {
                        const keyReg = reg();
                        const valueReg = reg();
                        emit("PUSHN", keyReg, i + 1);
                        emit("GETI", valueReg, temp, keyReg);
                        const name = String(targets[i].name);
                        emit(localNames.has(name) ? "SETL" : "SETG", k(name), valueReg);
                    }
                    break;
                }

                for (let i = 0; i < Math.max(values.length, vars.length); i++) {
                    const r = i < values.length
                        ? ex(values[i])
                        : (() => { const z = reg(); emit("PUSHNIL", z); return z; })();
                    const v = targets[i];

                    if (!v) continue;

                    if (v.type === "Id") {
                        const name = String(v.name);
                        if (s.type === "Local") localNames.add(name);
                        emit(localNames.has(name) ? "SETL" : "SETG", k(name), r);
                    } else {
                        const a = ex(v.obj), b = ex(v.key);
                        emit("SETI", a, b, r);
                    }
                }
                break;
            }

            case "Compound": {
                if (s.left?.type === "Id") {
                    const name = String(s.left.name);
                    const a = ex(s.left), b = ex(s.value);
                    emit({
                        "+=": "ADD", "-=": "SUB", "*=": "MUL", "/=": "DIV",
                        "//=": "IDIV", "%=": "MOD", "^=": "POW", "..=": "CONCAT"
                    }[s.op] || "ADD", a, a, b);
                    emit(localNames.has(name) ? "SETL" : "SETG", k(name), a);
                }
                break;
            }

            case "CallStmt":
                ex(s.call);
                break;

            case "Return": {
                const values = s.values || [];
                const tail = values.length ? values[values.length - 1] : null;

                if (tail?.type === "Call" && tail.singleResult !== true) {
                    const prefix = values.slice(0, -1).map(ex);
                    const nodes = tail.args || [];
                    const argTail = nodes.length ? nodes[nodes.length - 1] : null;
                    const spreadsVarargs = !!argTail && expandableTail(argTail);
                    const fixedNodes = spreadsVarargs ? nodes.slice(0, -1) : nodes;

                    if (!tail.method && tail.callee?.type === "Id" && !localNames.has(String(tail.callee.name))) {
                        const args = fixedNodes.map(ex);
                        const pack = spreadsVarargs ? packOf(argTail) : null;
                        emit(
                            "TAILCALL", 1, k(String(tail.callee.name)), args.length,
                            prefix.length, spreadsVarargs ? 1 : 0,
                            ...args, ...(spreadsVarargs ? [pack] : []), ...prefix
                        );
                    } else if (tail.method) {
                        const self = ex(tail.callee.obj);
                        const key = ex(tail.callee.key);
                        const f = reg();
                        emit("GETI", f, self, key);
                        const args = [self, ...fixedNodes.map(ex)];
                        const pack = spreadsVarargs ? packOf(argTail) : null;
                        emit(
                            "TAILCALL", 0, f, args.length,
                            prefix.length, spreadsVarargs ? 1 : 0,
                            ...args, ...(spreadsVarargs ? [pack] : []), ...prefix
                        );
                    } else {
                        const f = ex(tail.callee);
                        const args = fixedNodes.map(ex);
                        const pack = spreadsVarargs ? packOf(argTail) : null;
                        emit(
                            "TAILCALL", 0, f, args.length,
                            prefix.length, spreadsVarargs ? 1 : 0,
                            ...args, ...(spreadsVarargs ? [pack] : []), ...prefix
                        );
                    }
                } else if (tail?.type === "Vararg") {
                    const prefix = values.slice(0, -1).map(ex);
                    const pack = reg();
                    emit("VARARGS", pack);
                    emit("RETURNV", prefix.length, ...prefix, pack);
                } else {
                    // The result count is an operand, never #I: a payload region may
                    // materialise a short instruction with padded slots, so the runtime
                    // cannot infer how many values a `return` produced from its length.
                    emit("RETURN", values.length, ...values.map(ex));
                }
                break;
            }

            case "Break":
                if (!loopBreaks.length) throw new Error("ByteVeil v5.9.0 strict VM rejected input: break outside loop");
                loopBreaks[loopBreaks.length - 1].push(emit("JMP", 0));
                break;

            case "Continue":
                if (!loopContinues.length) throw new Error("ByteVeil v5.9.0 strict VM rejected input: continue outside loop");
                loopContinues[loopContinues.length - 1].push(emit("JMP", 0));
                break;

            case "If": {
                const endJumps = [];

                for (const branch of s.branches || []) {
                    const cond = ex(branch.cond);
                    const falseJump = emit("JZ", cond, 0);
                    const saved = localNames;
                    localNames = new Set(localNames);
                    (branch.body || []).forEach(stmt);
                    localNames = saved;
                    endJumps.push(emit("JMP", 0));
                    patch(falseJump, 2, code.length);
                }

                if (s.elseBody?.length) {
                    const saved = localNames;
                    localNames = new Set(localNames);
                    s.elseBody.forEach(stmt);
                    localNames = saved;
                }

                const end = code.length;
                for (const j of endJumps) patch(j, 1, end);
                break;
            }

            case "While": {
                const start = code.length;
                const cond = ex(s.cond);
                const exit = emit("JZ", cond, 0);
                const breaks = pushLoop();
                const saved = localNames;
                localNames = new Set(localNames);
                (s.body || []).forEach(stmt);
                localNames = saved;
                emit("JMP", start);
                const end = code.length;
                patch(exit, 2, end);
                popLoop(breaks, end, start);
                break;
            }

            case "Repeat": {
                const start = code.length;
                const breaks = pushLoop();
                (s.body || []).forEach(stmt);
                const continueTarget = code.length;
                const cond = ex(s.cond);
                emit("JZ", cond, start);
                const end = code.length;
                popLoop(breaks, end, continueTarget);
                break;
            }

            case "Do": {
                const saved = localNames;
                localNames = new Set(localNames);
                (s.body || []).forEach(stmt);
                localNames = saved;
                break;
            }

            case "ForNum": {
                const name = String(s.name);
                localNames.add(name);
                const start = ex(s.start);
                emit("SETL", k(name), start);
                const limit = ex(s.end);
                const step = s.step
                    ? ex(s.step)
                    : (() => { const z = reg(); emit("PUSHN", z, 1); return z; })();
                const loop = code.length;
                const breaks = pushLoop();
                const current = ex({ type: "Id", name });
                const cond = reg();
                emit("DUP", cond, current);
                emit("FORCMP", cond, limit, step);
                const exit = emit("JZ", cond, 0);
                (s.body || []).forEach(stmt);
                const continueTarget = code.length;
                const next = ex({ type: "Id", name });
                emit("ADD", next, next, step);
                emit("SETL", k(name), next);
                emit("JMP", loop);
                const end = code.length;
                patch(exit, 2, end);
                popLoop(breaks, end, continueTarget);
                break;
            }

            case "ForIn": {
                const names = (s.names || []).map(String);
                const exprs = s.it || [];
                if (!names.length || !exprs.length || exprs.length > 3) throw new Error("ByteVeil strict VM: unsupported generic-for expression shape");

                const resultBase = regBlock(3);
                let produced = 0;

                for (let i = 0; i < exprs.length; i++) {
                    const x = exprs[i];
                    const isLast = i === exprs.length - 1;

                    if (isLast && x?.type === "Call" && x?.singleResult !== true) {
                        const f = ex(x.callee);
                        const args = (x.args || []).map(ex);
                        const want = Math.max(1, 3 - produced);
                        emit("CALLM", resultBase + produced, f, args.length, want, ...args);
                        produced += want;
                    } else {
                        const r = ex(x);
                        if (r !== resultBase + produced) emit("DUP", resultBase + produced, r);
                        produced++;
                    }
                }

                while (produced < 3) {
                    const z = reg();
                    emit("PUSHNIL", z);
                    emit("DUP", resultBase + produced, z);
                    produced++;
                }

                const nameConst = names.map(name => k(name));
                emit("ITERPREP", resultBase, nameConst.length, ...nameConst);
                const loop = emit("ITERLOOP", 0, nameConst.length, ...nameConst);
                const breaks = pushLoop();
                const saved = localNames;
                localNames = new Set(localNames);
                names.forEach(name => localNames.add(name));
                (s.body || []).forEach(stmt);
                localNames = saved;
                const continueTarget = code.length;
                emit("JMP", loop);
                const end = code.length;
                patch(loop, 1, end);
                popLoop(breaks, end, continueTarget);
                break;
            }

            case "LocalFunction":
            case "Function": {
                const fn = s.fn || { body: [], params: [], vararg: false };
                const fnName = String(s.name);
                if (s.type === "LocalFunction") localNames.add(fnName);
                const sub = compile(
                    { type: "Chunk", body: fn.body || [], params: fn.params || [], vararg: !!fn.vararg },
                    seed + nextReg + 133,
                    { visibleNames: new Set(localNames), map }
                );
                sub.params = fn.params || [];
                sub.vararg = !!fn.vararg;
                const r = reg();
                emit("MAKEFUNC", r, k({ __chunk: sub }));

                if (s.type === "LocalFunction") {
                    localNames.add(fnName);
                    emit("SETL", k(fnName), r);
                } else {
                    emit("SETG", k(fnName), r);
                }

                break;
            }
        }
    }

    (ast.body || []).forEach(stmt);
    emit("HALT");

    const regPermutation = permuteRegisterOperands(code, map.decode, nextReg, regBlocks, seed);

    return {
        mode: "register",
        code,
        consts,
        params: ast.params || [],
        vararg: !!ast.vararg,
        opcode: map.names,
        map,
        registers: regPermutation.maxPhysicalReg,
        registerPermutation: regPermutation,
        OPS: REGISTER_SEMANTIC_OPS
    };
}

function permuteRegisterOperands(code, decodeMap, virtualCount, regBlocks, seed) {
    if (!virtualCount || virtualCount <= 0) {
        return { virtualCount: 0, maxPhysicalReg: 0, map: [] };
    }
    const blockByStart = new Map();
    const covered = new Uint8Array(virtualCount);
    for (const blk of regBlocks || []) {
        if (blk && Number.isInteger(blk.base) && blk.base >= 0 && blk.base < virtualCount && blk.count > 1) {
            const count = Math.min(blk.count, virtualCount - blk.base);
            blockByStart.set(blk.base, count);
            for (let i = 0; i < count; i++) covered[blk.base + i] = 1;
        }
    }
    const units = [];
    for (let r = 0; r < virtualCount; r++) {
        if (blockByStart.has(r)) {
            const count = blockByStart.get(r);
            units.push({ start: r, count });
            r += count - 1;
        } else if (!covered[r]) {
            units.push({ start: r, count: 1 });
        }
    }

    let rngState = (((Number(seed) >>> 0) ^ 0x52454750 ^ Math.imul(virtualCount, 0x9E3779B1)) >>> 0) || 0xA5A55A5A;
    const nextRand = () => {
        rngState ^= rngState >>> 16;
        rngState = Math.imul(rngState, 2246822519) >>> 0;
        rngState ^= rngState >>> 13;
        rngState = Math.imul(rngState, 3266489917) >>> 0;
        rngState ^= rngState >>> 16;
        return rngState >>> 0;
    };

    for (let i = units.length - 1; i > 0; i--) {
        const j = nextRand() % (i + 1);
        [units[i], units[j]] = [units[j], units[i]];
    }

    const regMap = new Array(virtualCount);
    let phys = 1 + (nextRand() % 13);
    for (const unit of units) {
        for (let k = 0; k < unit.count; k++) {
            regMap[unit.start + k] = phys + k;
        }
        phys += unit.count + (nextRand() % 3);
    }

    const remap = (v) => (Number.isInteger(v) && v >= 0 && v < virtualCount) ? regMap[v] : v;
    const singleReg1 = new Set(["PUSHK", "PUSHN", "PUSHB", "PUSHNIL", "POP", "NEWTABLE", "GETG", "GETL", "MAKEFUNC", "VARARG", "VARARGS", "JZ", "ITERPREP"]);
    const singleReg2 = new Set(["SETG", "SETL"]);
    const pairReg12 = new Set(["NOT", "NEG", "LEN", "BNOT", "DUP", "SWAP", "MOVE_SELF", "GETFIELD"]);
    const tripleReg123 = new Set(["GETI", "SETI", "ADD", "SUB", "MUL", "DIV", "IDIV", "MOD", "POW", "EQ", "NE", "LT", "GT", "LE", "GE", "CONCAT", "AND", "OR", "BAND", "BOR", "BXOR", "SHL", "SHR", "FORCMP"]);

    for (const ins of code) {
        if (!Array.isArray(ins) || !ins.length) continue;
        const op = decodeMap?.[ins[0]];
        if (!op) continue;
        if (singleReg1.has(op)) {
            ins[1] = remap(ins[1]);
        } else if (singleReg2.has(op)) {
            ins[2] = remap(ins[2]);
        } else if (pairReg12.has(op)) {
            ins[1] = remap(ins[1]);
            ins[2] = remap(ins[2]);
        } else if (op === "SETFIELD") {
            ins[1] = remap(ins[1]);
            ins[3] = remap(ins[3]);
        } else if (tripleReg123.has(op)) {
            ins[1] = remap(ins[1]);
            ins[2] = remap(ins[2]);
            ins[3] = remap(ins[3]);
        } else if (op === "CALL" || op === "CALLV") {
            ins[1] = remap(ins[1]);
            ins[2] = remap(ins[2]);
            for (let j = 4; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "CALLG" || op === "CALLGV") {
            ins[1] = remap(ins[1]);
            for (let j = 4; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "CALLM") {
            ins[1] = remap(ins[1]);
            ins[2] = remap(ins[2]);
            for (let j = 5; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "CALLGM") {
            ins[1] = remap(ins[1]);
            for (let j = 5; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "CALLP") {
            // [opcode, DEST, GLOBAL_FLAG, FUNCTION_OR_K, ARGC, VARARG_FLAG, REGS..., PACK?]
            ins[1] = remap(ins[1]);
            if (ins[2] === 0) ins[3] = remap(ins[3]);
            for (let j = 6; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "APPEND") {
            ins[1] = remap(ins[1]);
            ins[2] = remap(ins[2]);
        } else if (op === "TAILCALL") {
            if (ins[1] === 0) ins[2] = remap(ins[2]);
            for (let j = 6; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "RETURN") {
            // operand 1 is the result count, so only the registers after it remap.
            for (let j = 2; j < ins.length; j++) ins[j] = remap(ins[j]);
        } else if (op === "RETURNV") {
            for (let j = 2; j < ins.length; j++) ins[j] = remap(ins[j]);
        }
    }

    return {
        virtualCount,
        maxPhysicalReg: phys,
        map: regMap
    };
}

module.exports = { compile, permuteRegisterOperands };
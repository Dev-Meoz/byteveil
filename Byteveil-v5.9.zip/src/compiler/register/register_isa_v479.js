"use strict";

/*
 * ByteVeil v4.7.9 register-command ABI.
 *
 * Register bytecode must not inherit the legacy v4.5.5 shared opcode table.
 * The compiler still expresses operations in semantic names (GETG, ADD, CALL,
 * etc.) because the VM handler layer understands those semantics. This module
 * maps that semantic vocabulary onto a separate register-specific command set
 * before assigning the physical opcode values serialized into the payload.
 */
const {
    buildISAPlan,
    SEMANTIC_CLASS
} = require("../../obfuscation/isa_engine");

const REGISTER_COMMAND_BY_SEMANTIC = Object.freeze({
    HALT: "R_STOP",
    PUSHK: "R_LOAD_CONST",
    PUSHN: "R_LOAD_NUMBER",
    PUSHB: "R_LOAD_BOOLEAN",
    PUSHNIL: "R_LOAD_NIL",
    GETG: "R_READ_GLOBAL",
    SETG: "R_WRITE_GLOBAL",
    GETL: "R_READ_LOCAL",
    SETL: "R_WRITE_LOCAL",
    GETI: "R_READ_INDEX",
    SETI: "R_WRITE_INDEX",
    CALLG: "R_CALL_GLOBAL",
    CALLGM: "R_CALL_GLOBAL_MULTI",
    TAILCALL: "R_TAIL_CALL",
    ADD: "R_ADD_REG",
    SUB: "R_SUB_REG",
    MUL: "R_MUL_REG",
    DIV: "R_DIV_REG",
    IDIV: "R_FLOOR_DIV_REG",
    MOD: "R_MOD_REG",
    POW: "R_POW_REG",
    EQ: "R_COMPARE_EQ",
    NE: "R_COMPARE_NE",
    LT: "R_COMPARE_LT",
    GT: "R_COMPARE_GT",
    LE: "R_COMPARE_LE",
    GE: "R_COMPARE_GE",
    NOT: "R_LOGICAL_NOT",
    NEG: "R_NUMERIC_NEGATE",
    LEN: "R_LENGTH",
    CONCAT: "R_CONCAT_REG",
    JMP: "R_BRANCH",
    JZ: "R_BRANCH_IF_FALSE",
    CALL: "R_CALL_REG",
    RETURN: "R_RETURN_REGS",
    POP: "R_CLEAR_REG",
    DUP: "R_MOVE_REG",
    NEWTABLE: "R_ALLOC_TABLE",
    SETFIELD: "R_WRITE_FIELD",
    GETFIELD: "R_READ_FIELD",
    MAKEFUNC: "R_CREATE_CLOSURE",
    VARARG: "R_READ_VARARG",
    VARARGS: "R_COLLECT_VARARGS",
    CALLV: "R_CALL_REG_VARARGS",
    CALLGV: "R_CALL_GLOBAL_VARARGS",
    RETURNV: "R_RETURN_VARARGS",
    CALLM: "R_CALL_MULTI_RESULT",
    AND: "R_LOGICAL_AND",
    OR: "R_LOGICAL_OR",
    BAND: "R_BIT_AND",
    BOR: "R_BIT_OR",
    BXOR: "R_BIT_XOR",
    SHL: "R_SHIFT_LEFT",
    SHR: "R_SHIFT_RIGHT",
    BNOT: "R_BIT_NOT",
    BREAK: "R_LOOP_BREAK",
    SWAP: "R_SWAP_REGS",
    MOVE_SELF: "R_SELF_REGISTER",
    FORCMP: "R_NUMERIC_FOR_COMPARE",
    ITERPREP: "R_ITERATOR_PREPARE",
    ITERLOOP: "R_ITERATOR_STEP",
    SUPER: "R_FUSED_SUPER",
    CALLP: "R_CALL_PACK_RESULTS",
    APPEND: "R_APPEND_RESULT_LIST"
});

const REGISTER_SEMANTIC_OPS = Object.freeze(Object.keys(REGISTER_COMMAND_BY_SEMANTIC));
const REGISTER_COMMAND_NAMES = Object.freeze(REGISTER_SEMANTIC_OPS.map((name) => REGISTER_COMMAND_BY_SEMANTIC[name]));
const SEMANTIC_BY_REGISTER_COMMAND = Object.freeze(
    Object.fromEntries(REGISTER_SEMANTIC_OPS.map((semantic) => [REGISTER_COMMAND_BY_SEMANTIC[semantic], semantic]))
);
const REGISTER_ISA_VERSION = "4.7.9-register-command-abi";
const REGISTER_ISA_SALT = 0x52454779; // "REGy", deliberately separate from the shared ISA seed domain.

if (new Set(REGISTER_COMMAND_NAMES).size !== REGISTER_COMMAND_NAMES.length) {
    throw new Error("ByteVeil v4.7.9 register ISA: duplicate command alias");
}

function buildRegisterISAPlan(seed, options = {}) {
    const semanticPlan = buildISAPlan(
        REGISTER_COMMAND_NAMES,
        ((Number(seed) >>> 0) ^ REGISTER_ISA_SALT) >>> 0,
        options
    );

    const encode = Object.create(null);
    const decode = Object.create(null);
    for (const semantic of REGISTER_SEMANTIC_OPS) {
        encode[semantic] = semanticPlan.encode[REGISTER_COMMAND_BY_SEMANTIC[semantic]];
    }
    for (const [physical, command] of Object.entries(semanticPlan.decode)) {
        const semantic = SEMANTIC_BY_REGISTER_COMMAND[command];
        if (!semantic) throw new Error(`ByteVeil v4.7.9 register ISA: unknown command ${command}`);
        decode[physical] = semantic;
    }

    const lanes = semanticPlan.lanes.map((lane) => Object.fromEntries(
        REGISTER_SEMANTIC_OPS.map((semantic) => [semantic, lane[REGISTER_COMMAND_BY_SEMANTIC[semantic]]])
    ));
    const order = semanticPlan.order.map((command) => SEMANTIC_BY_REGISTER_COMMAND[command]);
    const operandVariant = REGISTER_SEMANTIC_OPS.map((semantic, index) => ({
        name: semantic,
        variant: semanticPlan.operandVariant[index]
    }));

    return {
        ...semanticPlan,
        version: REGISTER_ISA_VERSION,
        names: REGISTER_SEMANTIC_OPS.slice(),
        commandNames: REGISTER_COMMAND_NAMES.slice(),
        encode,
        decode,
        lanes,
        order,
        route: REGISTER_SEMANTIC_OPS.map((semantic) => encode[semantic]),
        operandVariant,
        semanticClass: { ...SEMANTIC_CLASS }
    };
}

module.exports = {
    REGISTER_ISA_VERSION,
    REGISTER_ISA_SALT,
    REGISTER_COMMAND_BY_SEMANTIC,
    REGISTER_COMMAND_NAMES,
    REGISTER_SEMANTIC_OPS,
    buildRegisterISAPlan
};

"use strict";
const { compileAST } = require("../bytecode");
module.exports = { compile: (ast, seed = 1) => compileAST(ast, "stack", seed) };

"use strict";

const { encodeBytecodeBlob, encodeBytecodeBlobV45 } = require("../../backend/bytecode_serializer");
const { buildAntiBundle, predictGuardVerdict, VM_ANTI_BUNDLE_CONFIG } = require("../../anti");
const { buildDecoyProgram } = require("../../protection/decoy_compiler");
const { buildLiveShadowVM, buildSemanticShadowVM, buildShadowStrings } = require("../../protection/live_shadow_vm");
const { rewriteGeneratedAccessShape } = require("../../protection/access_shape");
const { wrapSource } = require("../../protection/nested_obfuscation");
const { SEMANTIC_CLASS } = require("../../obfuscation/isa_engine");
const { buildV455Personality, buildV46Personality } = require("../../obfuscation/vm_personality");
const { ARCHITECTURES, buildArchitecturePlan, emitSemanticArchitecture } = require("../../obfuscation/vm_architecture_v46");
const { buildLuaInverseSource } = require("../../obfuscation/representation_morph");
const { buildLuaHelpers: buildVeilStrHelpers } = require("../../obfuscation/veil_str");
const { renderCarrierLiteral, CARRIER_MARKER_SUB, renderDecoyBlob } = require("../../obfuscation/veil_blob");
const { UNIFIED_ALPHABET } = require("../../obfuscation/blob_alphabet");
const PAYLOAD_RADIX = UNIFIED_ALPHABET.length;

function randomId(seed = Date.now()) {
    let s = Number(seed) >>> 0;
    s = (Math.imul(s ^ (s >>> 16), 2246822519) + 3266489917) >>> 0;
    return s.toString(36);
}


function permuteSlots(seed, fields) {
    let s = (Number(seed) >>> 0) || 0x9E3779B9;
    const values = fields.map((_, i) => i + 1);
    for (let i = values.length - 1; i > 0; i--) {
        s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0;
        s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0;
        s ^= s >>> 16; s >>>= 0;
        const j = s % (i + 1);
        [values[i], values[j]] = [values[j], values[i]];
    }
    return Object.fromEntries(fields.map((field, i) => [field, values[i]]));
}

function rewriteStateLayout(output, seed, fields, initPattern) {
    const slots = permuteSlots(seed, fields);
    let out = output;
    for (const field of fields) {
        out = out.replace(new RegExp(`\\bS\\.${field}\\b`, "g"), `S[${slots[field]}]`);
        out = out.replace(new RegExp(`\\bT\\.${field}\\b`, "g"), `T[${slots[field]}]`);
    }
    const init = initPattern(slots);
    out = out.replace(init.from, init.to);
    return { output: out, slots };
}

function rewriteChunkLayout(output, seed, initFrom) {
    const fields = ["consts", "params", "vararg", "code"];
    const slots = permuteSlots(seed ^ 0xA5A5A5A5, fields);
    let out = output;
    out = out.replace(initFrom.constsFrom, initFrom.constsTo(slots));
    for (const [key, slot] of Object.entries(slots)) {
        const aliases = { consts: "k", params: "p", vararg: "v", code: "c" };
        out = out.replace(new RegExp(`\\bX\\.${aliases[key]}\\b`, "g"), `X[${slot}]`);
    }
    return { output: out, slots };
}

/*
 * One 32-bit xor for the whole runtime, chosen on the host that executes it.
 *
 * Measured per call (scratch/ab/xor_shapes.lua, 300,000 calls, os.clock CPU time;
 * scratch/probe_xor_arm.js times the chooser text this file actually emits):
 *   Luau    bit32+floor 65ns | bit32+floor+mod 90ns | native '~' n/a (syntax error) | byte table ~900ns
 *   Lua 5.4 no bit32 at all -> native '~' 213ns | byte table 1155ns | 32-round loop 3040ns
 * The byte table also materialises 65,536 sub-tables at load (~13ms on Lua 5.4), which every
 * rung above it skips. The pre-change runtime had no '~' rung, so a Lua 5.4 host paid the
 * byte table on every single xor, and N.mix alone performs four of them.
 *
 * Arm order is by measured cost, and each arm must pass the battery on the real host before it
 * is adopted - nothing is decided at build time:
 *   1. bit32.bxor(math.floor(A), math.floor(B)). bit32 already reduces its operands to 32 bits,
 *      so floor is the only normalisation needed; this is what makes the rung 65ns instead of
 *      90ns. Luau has no bitwise operators at all ('~' is a syntax error there) but does ship
 *      bit32, so this is the fast rung on Roblox/FiveM-style hosts.
 *   2. bit32.bxor behind floor+mod, for a bit32 that rejects or mishandles values over 2^32.
 *   3. native '~' compiled out-of-band - Lua 5.3+. It cannot be written literally in a chunk
 *      that must also parse on Lua 5.1/5.2, so the operator reaches the compiler as a string and
 *      the rung simply fails to load where it is unsupported. It needs floor+mod because 5.3+
 *      '~' is a 64-bit operator and raises on operands with a fractional part.
 *   4. byte table - universal floor.
 *
 * Every rung returns the floor-first 32-bit result, which is what all four agree on and what
 * the previous runtime produced on every host, so xor stays identical across hosts. That is why
 * calling bit32.bxor raw - 68ns, only 3ns cheaper - is not one of the rungs: measured on Luau,
 * raw truncates -0.5 toward zero and gives 1 where the floor rungs give 4294967294.
 *
 * BAND and BOR are derived from this one avouched xor rather than given their own chooser.
 * a&b = (a+b-(a^b))/2 and a|b = a+b-(a&b) are exact over the floor-first 32-bit domain
 * (scratch/probe_bit_derive.js: 2,000,000 random pairs plus an exhaustive 1000x1000 grid, zero
 * mismatches). A dedicated chooser cannot be added as a plain chunk-level local: the v4.7.9
 * payload-carrier splitter rewrites this chunk into bootstrap stages by fixed line index and
 * re-exports only a named primitive set through its context table, so any new chunk-level local
 * is invisible to the later stages and fails at run time as a nil global. Deriving keeps the
 * stage layout byte-stable.
 *
 * Both handlers previously wrote `bit32 and bit32.band and bit32.band(A,B) or (function() ...32
 * rounds... end)(A,B)`, which cost a fresh closure plus a 32-round loop per execution on a host
 * without bit32, and called bit32 raw where it exists - so the same artifact disagreed between
 * Luau and Lua 5.4 on any fractional or negative operand. Derivation from the avouched xor makes
 * the result host-independent and adds no per-execution allocation.
 *
 * The division by 2 is wrapped in math.floor. Lua 5.4 `/` always yields a float, so the unfloored
 * form printed `2.0` where the old loop and native `&` print `2`; scratch/probe_bitops_e2e.js
 * compiles every bitwise operator through both routes and compares the rendered artifact output
 * to the floor-first oracle on lua and luau, which is what caught it.
 */

// Operands chosen to cover the boundaries the rungs can disagree on: the 32-bit ceiling, a carry
// across the half-word, a fractional pair (floor vs truncate), negatives, and values outside 32
// bits. Expected values come from u32Floor plus the JS operator, which is a third implementation
// independent of both the Lua rungs and the 32-round loop; scratch/probe_xor_arm.js re-checks
// them on the real hosts.
const XOR_AVOUCHMENT_PAIRS = [
    [6, 3], [0, 0], [4294967295, 1], [2147483648, 2147483647], [3.7, 1.2], [-1, 0],
    [255, 15], [4294967295, 4294967295], [65536, 65537], [16777215, 1],
    [4294967295, 2147483648], [4294967296, 1], [8589934593, 1], [-4294967297, 255],
    [-0.5, 1], [12345, 54321]
];

// Lua's math.floor then %% 2^32, evaluated here so the battery can never encode a
// truncate-toward-zero answer.
function u32Floor(value) {
    const mod = 4294967296;
    const f = Math.floor(value);
    return ((f % mod) + mod) % mod;
}

const XOR_AVOUCHMENT_VECTORS = XOR_AVOUCHMENT_PAIRS
    .map(([a, b]) => [a, b, (u32Floor(a) ^ u32Floor(b)) >>> 0]);

const XOR_BYTE_TABLE = `local N={};for i=0,15 do local r={};for j=0,15 do local x,y,v,p=i,j,0,1;while x>0 or y>0 do local a,b=x%2,y%2;if a~=b then v=v+p end;x=(x-a)/2;y=(y-b)/2;p=p*2 end;r[j]=v end;N[i]=r end;local T={};for i=0,255 do local r={};local il=i%16;local ih=(i-il)/16;local nl,nh=N[il],N[ih];for j=0,255 do local jl=j%16;local jh=(j-jl)/16;r[j]=nl[jl]+nh[jh]*16 end;T[i]=r end;return function(A,B)A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;local a0=A%256;A=(A-a0)/256;local a1=A%256;A=(A-a1)/256;local a2=A%256;local a3=(A-a2)/256;local b0=B%256;B=(B-b0)/256;local b1=B%256;B=(B-b1)/256;local b2=B%256;local b3=(B-b2)/256;return T[a0][b0]+T[a1][b1]*256+T[a2][b2]*65536+T[a3][b3]*16777216 end`;

function buildXorChooser(name) {
    const checks = XOR_AVOUCHMENT_VECTORS
        .map(([a, b, want]) => `if F(${a},${b})~=${want} then return false end;`)
        .join("");
    return `local ${name}=(function()local MOD=4294967296;local function avouch(F)${checks}return true end;`
        + `local function try(F)local P,V=pcall(avouch,F);if P and V then return F end end;local F;`
        + `local BXL=bit32 and bit32.bxor;`
        + `if type(BXL)=="function"then F=try(function(A,B)return BXL(math.floor(A),math.floor(B)) end)`
        + ` or try(function(A,B)return BXL(math.floor(A)%MOD,math.floor(B)%MOD)%MOD end) end;`
        + `if not F then local LD=(load or loadstring);if LD then local OC,CH=pcall(LD,"return function(PX,PY)return PX~PY end");if OC and type(CH)=="function"then local OF,OP=pcall(CH);if OF and type(OP)=="function"then F=try(function(A,B)return OP(math.floor(A)%MOD,math.floor(B)%MOD)%MOD end) end end end end;`
        + `if F then return F end;`
        + ` ${XOR_BYTE_TABLE} end)()`;
}

function buildStackHandlers(op, n) {
    const h = [];
    const add = (name, body) => h.push(`local function ${n.h[name]}(S,I,...)${body};end`);
    add("HALT", `S.halt=true;return true`);
    add("PUSHK", `S.sp=S.sp+1;S.stack[S.sp]=S.consts[I[2]+1]`);
    add("PUSHN", `S.sp=S.sp+1;S.stack[S.sp]=I[2]`);
    add("PUSHB", `S.sp=S.sp+1;S.stack[S.sp]=I[2]~=0`);
    add("PUSHNIL", `S.sp=S.sp+1;S.stack[S.sp]=nil`);
    add("GETG", `S.sp=S.sp+1;S.stack[S.sp]=S.env[S.consts[I[2]+1]]`);
    add("SETG", `S.env[S.consts[I[2]+1]]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("GETL", `local T=S;local N=S.consts[I[2]+1];while T do if T.localSet[N] then S.stack[S.sp+1]=T.locals[N];S.sp=S.sp+1;break end;T=T.parent end;if not T then S.sp=S.sp+1;S.stack[S.sp]=nil end`);
    add("SETL", `local T=S;local N=S.consts[I[2]+1];while T and not T.localSet[N] do T=T.parent end;if not T then T=S;T.localSet[N]=true end;T.locals[N]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("GETI", `local k=S.stack[S.sp];local a=S.stack[S.sp-1];S.stack[S.sp-1]=a[k];S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("SETI", `local v=S.stack[S.sp];local k=S.stack[S.sp-1];local a=S.stack[S.sp-2];a[k]=v;S.stack[S.sp]=nil;S.stack[S.sp-1]=nil;S.sp=S.sp-2`);
    add("ADD", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]+b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("SUB", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]-b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("MUL", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]*b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("DIV", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]/b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("IDIV", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]//b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("MOD", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]%b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("POW", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]^b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("EQ", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]==b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("NE", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]~=b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("LT", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]<b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("GT", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]>b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("LE", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]<=b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("GE", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]>=b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("NOT", `S.stack[S.sp]=not S.stack[S.sp]`);
    add("NEG", `S.stack[S.sp]=-S.stack[S.sp]`);
    add("LEN", `S.stack[S.sp]=#S.stack[S.sp]`);
    add("CONCAT", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1]..b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("AND", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1] and b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("OR", `local b=S.stack[S.sp];S.stack[S.sp-1]=S.stack[S.sp-1] or b;S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("BAND", `local b=S.stack[S.sp];S.stack[S.sp-1]=${n.band}(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("BOR", `local b=S.stack[S.sp];S.stack[S.sp-1]=${n.bor}(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("BXOR", `local b=S.stack[S.sp];S.stack[S.sp-1]=${n.bxor}(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("SHL", `local b=S.stack[S.sp];S.stack[S.sp-1]=${n.shl}(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("SHR", `local b=S.stack[S.sp];S.stack[S.sp-1]=${n.shr}(S.stack[S.sp-1],b);S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("BNOT", `local v=${n.bxor}(S.stack[S.sp],4294967295);if v>=2147483648 then v=v-4294967296 end;S.stack[S.sp]=v`);
    add("JMP", `S.pc=I[2]+1`);
    add("JZ", `local z=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1;if not z then S.pc=I[2]+1 end`);
    add("POP", `S.stack[S.sp]=nil;S.sp=S.sp-1`);
    add("DUP", `S.sp=S.sp+1;S.stack[S.sp]=S.stack[S.sp-1]`);
    add("NEWTABLE", `local c0=I[2]or 0;S.sp=S.sp+1;S.stack[S.sp]=c0>0 and {${n.unpackBuiltin}({},1,c0)} or {}`);
    add("CALL", `local count=I[2];local args={};for q=count,1,-1 do args[q]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1 end;local f=S.stack[S.sp];local r={f(${n.unpackBuiltin}(args,1,count))};S.stack[S.sp]=r[1]`);
    add("RETURN", `local count=I[2];local r={};for q=count,1,-1 do r[q]=S.stack[S.sp];S.stack[S.sp]=nil;S.sp=S.sp-1 end;S.halt=true;S.ret=r;return true`);
    add("MAKEFUNC", `local X=S.consts[I[2]+1];local P=S;S.sp=S.sp+1;S.stack[S.sp]=function(...)return ${n.run}(X,P,...)end`);
    add("VARARG", `S.sp=S.sp+1;local a=S.varargs or {};S.stack[S.sp]=a`);
    add("BREAK", `S.halt=true;return true`);
    add("SWAP", `local a=S.stack[S.sp];S.stack[S.sp]=S.stack[S.sp-1];S.stack[S.sp-1]=a`);
    add("MOVE_SELF", `local a=S.stack[S.sp-1];S.sp=S.sp+1;S.stack[S.sp]=a`);
    add("FORCMP", `local step=S.stack[S.sp];local limit=S.stack[S.sp-1];local idx=S.stack[S.sp-2];local ok=(step>=0 and idx<=limit)or(step<0 and idx>=limit);S.stack[S.sp-2]=ok;S.stack[S.sp]=nil;S.stack[S.sp-1]=nil;S.sp=S.sp-2`);
    add("ITERPREP", `local f=S.stack[S.sp-I[2]];S.stack[S.sp-I[2]]=f`);
    add("ITERLOOP", `S.halt=true;return true`);
    return h;
}

function buildGeneratedSource(bytecode, seed, options = {}) {
    const tag = randomId(
        (Number(seed) ^ 0xA7F341) >>> 0
    );

    const n = {
        state: `_${randomId(seed ^ 0x1021)}`,
        unpack: `_${randomId(seed ^ 0x2042)}`,
        decode: `_${randomId(seed ^ 0x3063)}`,
        dispatch: `_${randomId(seed ^ 0x4084)}`,
        run: `_${randomId(seed ^ 0x50A5)}`,
        blob: `_${randomId(seed ^ 0x60C6)}`,
        key: `_${randomId(seed ^ 0x70E7)}`,
        root: `_${randomId(seed ^ 0x8108)}`,
        raw: `_${randomId(seed ^ 0x8A19)}`,
        result: `_${randomId(seed ^ 0x9209)}`,
        handlers: `_${randomId(seed ^ 0xA30A)}`,
        slot: `_${randomId(seed ^ 0xA40B)}`,
        g1:`_${randomId(seed ^ 0xB101)}`,
        g2:`_${randomId(seed ^ 0xB202)}`,
        g3:`_${randomId(seed ^ 0xB303)}`,
        g4:`_${randomId(seed ^ 0xB404)}`,
        g5:`_${randomId(seed ^ 0xB505)}`,
        g6:`_${randomId(seed ^ 0xB606)}`,
        g7:`_${randomId(seed ^ 0xB707)}`,
        g8:`_${randomId(seed ^ 0xB808)}`,
        g9:`_${randomId(seed ^ 0xB909)}`,
        g10:`_${randomId(seed ^ 0xBA0A)}`,
        g11:`_${randomId(seed ^ 0xBB0B)}`,
        g12:`_${randomId(seed ^ 0xBC0C)}`,
        g13:`_${randomId(seed ^ 0xBD0D)}`,
        g14:`_${randomId(seed ^ 0xBE0E)}`,
        g15:`_${randomId(seed ^ 0xBF0F)}`,
        g16:`_${randomId(seed ^ 0xC010)}`,
        g17:`_${randomId(seed ^ 0xC111)}`,
        g18:`_${randomId(seed ^ 0xC212)}`,
        payloadCheck:`_${randomId(seed ^ 0xC313)}`,
        band:`_${randomId(seed ^ 0xC414)}`,
        bor:`_${randomId(seed ^ 0xC515)}`,
        bxor:`_${randomId(seed ^ 0xC616)}`,
        shl:`_${randomId(seed ^ 0xC717)}`,
        shr:`_${randomId(seed ^ 0xC818)}`,
        unpackBuiltin:`_${randomId(seed ^ 0xC919)}`,
        h: {}
    };

    for (const name of bytecode.opcode || []) {
        n.h[name] =
            `_${randomId(
                (seed ^
                    name.split("").reduce(
                        (a, c) =>
                            ((a * 33) ^
                                c.charCodeAt(0)) >>> 0,
                        5381
                    )) >>> 0
            )}`;
    }

    const packed =
        encodeBytecodeBlob(
            bytecode,
            seed,
            { opcodeWhitening: options.opcodeWhitening !== false }
        );

    const lines = [];
    lines.push(`local ${n.payloadCheck}=function(D)local H=17;for I=1,#D do H=(H*65599+string.byte(D,I)+1)%2147483647 end;return H end`);
    // v2.5 portable bit helpers: generated source must parse on Lua 5.1+ and Luau.
    lines.push(`local ${n.band}=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 and b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.bor}=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a==1 or b==1 then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.bxor}=function(A,B)local R=0;local P=1;A=math.floor(A)%4294967296;B=math.floor(B)%4294967296;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${n.shl}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return(A*2^B)%4294967296 end`);
    lines.push(`local ${n.shr}=function(A,B)A=math.floor(A)%4294967296;B=math.floor(B);if B<0 then B=0 end;if B>31 then return 0 end;return math.floor(A/2^B) end`);
    lines.push(`local ${n.unpackBuiltin}=table.unpack or unpack`);


    lines.push(`local ${n.run}`);

    lines.push(
        `local ${n.handlers}={}`
    );

    /*
     * Same inverse transform as bytecode_serializer.js.
     * No plaintext constants or instruction tables are emitted.
     */
    lines.push(
        `local ${n.unpack}=function(B,Q,L)local O={};local S=Q%4294967296;local function X(A,B)local R=0;local P=1;for _=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end;local function I(A,B)A=A%4294967296;B=B%4294967296;local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;local K={};local KS=${n.bxor}(Q,3235823838);if KS==0 then KS=2738958700 end;for KI=1,20 do KS=${n.bxor}(KS,math.floor(KS/65536));KS=I(KS,2246822519);KS=${n.bxor}(KS,math.floor(KS/8192));KS=I(KS,3266489917);KS=${n.bxor}(KS,math.floor(KS/65536));K[KI]=(${n.bxor}(KS,((KI*73244475)%4294967296)))%256 end;for J=1,L do S=X(S,math.floor(S/32768));S=I(S,2246822519);S=X(S,(S*8192)%4294967296);S=I(S,3266489917);local M=${n.bxor}(K[((J-1)%#K)+1],${n.bxor}(S%256,(((J-1)*29+71)%256)))%256;local V=(string.byte(B,J)-(((J-1)*17)%256)+256)%256;O[J]=string.char(${n.bxor}(V,M)%256)end;return table.concat(O)end`
    );

    lines.push(
        `local ${n.state}=function(E,V)return{pc=1,sp=0,stack={},locals={},localSet={},parent=nil,env=E,consts=V,code=nil,halt=false,ret={},varargs={},guard=0}end`
    );

    /*
     * Packed-data decoder.
     */
    lines.push(`local ${n.g1}=function(V)return type(V)=="table" end`);
    lines.push(`local ${n.g2}=function(V)return V~=nil end`);
    lines.push(`local ${n.g3}=function(V)return type(V)=="string" end`);
    lines.push(`local ${n.g4}=function(V)return #V>0 end`);
    lines.push(`local ${n.g5}=function(V)return V and V.k~=nil end`);
    lines.push(`local ${n.g6}=function(V)return V and V.c~=nil end`);
    lines.push(`local ${n.g7}=function(V)return V and V.p~=nil end`);
    lines.push(`local ${n.g8}=function(V)return V and V.v~=nil end`);
    lines.push(`local ${n.g9}=function(V)return V and #V<=16777216 end`);
    lines.push(`local ${n.g10}=function(V)return V and V<=4294967296 end`);
    lines.push(`local ${n.g11}=function(V)return V and V>=0 end`);
    lines.push(`local ${n.g12}=function(V)return V and #V>0 end`);
    lines.push(`local ${n.g13}=function(A,B)return A and B end`);
    lines.push(`local ${n.g14}=function(A,B)return A or B end`);
    lines.push(`local ${n.g15}=function(V)return type(V)~="function" or true end`);
    lines.push(`local ${n.g16}=function(V)return type(V)~="thread" or true end`);
    lines.push(`local ${n.g17}=function(V)return V~=false end`);
    lines.push(`local ${n.g18}=function(V)return V==nil or V==true or V==false or type(V)=="number" or type(V)=="string" or type(V)=="table" end`);
    lines.push(
        `local function ${n.decode}(D)local P=1;local function U()local V=0;local M=1;while true do local B=string.byte(D,P);P=P+1;V=V+${n.band}(B,127)*M;if B<128 then return V end;M=M*128 end end;local function R(N)local V=D:sub(P,P+N-1);P=P+N;return V end;local function S()return R(U())end;local function N()local T=string.byte(D,P);P=P+1;if T==0 then local V=U();return(V%2==0)and(V/2)or-((V+1)/2)else return tonumber(S())end end;local function C()local K={};local KC=U();for I=1,KC do local T=string.byte(D,P);P=P+1;if T==83 then K[I]=S()elseif T==78 then K[I]=N()elseif T==84 then K[I]=true elseif T==70 then K[I]=false elseif T==67 then K[I]=C()elseif T==90 then K[I]=nil end end;local X={k=K,p={},c={}};local PC=U();for I=1,PC do X.p[I]=S()end;X.v=string.byte(D,P)==1;P=P+1;local IC=U();for I=1,IC do local AC=U();local Q={};for J=1,AC do Q[J]=N()end;X.c[I]=Q end;return X end;return C()end`
    );

    lines.push(
        ...buildStackHandlers(
            bytecode.map,
            n
        )
    );

    // v2.6.3: per-build affine handler-slot permutation + rolling VM guard.
    const handlerCount = (bytecode.opcode || []).length;
    let handlerMul = 3 + (seed % 23);
    const gcd = (a, b) => { while (b) { const t = a % b; a = b; b = t; } return a; };
    while (gcd(handlerMul, handlerCount) !== 1) handlerMul++;
    const handlerAdd = handlerCount ? ((seed >>> 7) % handlerCount) : 0;
    lines.push(`local ${n.slot}=function(OP)return((OP*${handlerMul}+${handlerAdd})%${handlerCount})+1 end`);
    lines.push(`local ${n.handlers}={}`);
    for (const name of bytecode.opcode || []) {
        const op = bytecode.map.encode[name];
        const slot = ((op * handlerMul + handlerAdd) % handlerCount) + 1;
        lines.push(`${n.handlers}[${slot}]=${n.h[name]}`);
    }

    lines.push(
        `local ${n.dispatch}=function(S)local G=S.guard or 0;while not S.halt do local I=S.code[S.pc];if not I then S.halt=true;break end;local O=I[1];${packed.opcodeMask ? `O=${n.bxor}(O,${packed.opcodeMask})` : ""};S.pc=S.pc+1;G=(G*1664525+O*101+S.pc+1013904223)%4294967296;S.guard=G;local H=${n.handlers}[${n.slot}(O)];if not H then error("ByteVeil VM error",0)end;local X=H(S,I);if X then break end end;return S end`
    );

    lines.push(
        `${n.run}=function(X,P,...)local E=setmetatable({},{__index=_G});local S=${n.state}(E,X.k);S.parent=P;S.code=X.c;S.varargs={...};S.guard=${(seed*2654435761)%4294967296};for Q=1,#(X.p or {}) do local N=X.p[Q];S.locals[N]=select(Q,...);S.localSet[N]=true end;${n.dispatch}(S);return ${n.unpackBuiltin}(S.ret or {},1,#(S.ret or {}))end`
    );

    /* Payload container is deliberately materialized late, after the VM body. */
    lines.push(
        `local ${n.blob}=${packed.blob}`
    );

    lines.push(
        `local ${n.raw}=${n.unpack}(${n.blob},${packed.state},${packed.byteLength})`
    );

    lines.push(
        `if ${n.payloadCheck}(${n.raw})~=${packed.checksum} then error("ByteVeil payload integrity failed",0) end`
    );

    lines.push(
        `local ${n.root}=${n.decode}(${n.raw})`
    );

    lines.push(
        `if not (${n.g1}(${n.root}) and ${n.g5}(${n.root}) and ${n.g6}(${n.root}) and ${n.g7}(${n.root})) then error("ByteVeil VM validation failed",0) end`
    );

    lines.push(
        `local ${n.result}={${n.run}(${n.root},nil) }`
    );

    lines.push(
        `return ${n.unpackBuiltin}(${n.result},1,#${n.result})`
    );

    let output = lines.join("\n");
    const state = rewriteStateLayout(output, seed, ["pc","sp","stack","locals","localSet","parent","env","consts","code","halt","ret","varargs","guard"], (slots) => ({
        from: /return\{pc=1,sp=0,stack=\{\},locals=\{\},localSet=\{\},parent=nil,env=E,consts=V,code=nil,halt=false,ret=\{\},varargs=\{\},guard=0\}end/,
        to: `return{[${slots.pc}]=1,[${slots.sp}]=0,[${slots.stack}]={},[${slots.locals}]={},[${slots.localSet}]={},[${slots.parent}]=nil,[${slots.env}]=E,[${slots.consts}]=V,[${slots.code}]=nil,[${slots.halt}]=false,[${slots.ret}]={},[${slots.varargs}]={},[${slots.guard}]=0}end`
    }));
    output = state.output;
    // Legacy chunk schema retained for compatibility; v3.7 uses the structural backend.

    output = output.replace(/\bByteCode\b/g, "ByteVeil");
    return output;
}

function generate(bytecode, options={}) {
    if (!bytecode || !bytecode.map) throw new TypeError("Stack VM generator: invalid bytecode");
    const seed = Number(options.seed ?? Date.now()) >>> 0;
    return buildGeneratedSource(bytecode, seed);
}

module.exports={generate,buildGeneratedSource,buildStackHandlers};

// ---------------------------------------------------------------------------
// ByteVeil v3.7 structural runtime generator.
// This layer intentionally avoids arithmetic-based opcode/payload protection
// and avoids string.char entirely in generated output. Runtime arithmetic is
// kept only where it is part of the original program semantics or VM mechanics.
// ---------------------------------------------------------------------------

function v35Rng(seed) {
    let s = (Number(seed) >>> 0) || 0xA341316C;
    return () => {
        s ^= s >>> 16;
        s = Math.imul(s, 2246822519) >>> 0;
        s ^= s >>> 13;
        s = Math.imul(s, 3266489917) >>> 0;
        s ^= s >>> 16;
        return s >>> 0;
    };
}

function v35Shuffle(values, next) {
    const out = values.slice();
    for (let i = out.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
}

function v35Ident(seed, prefix = "_") {
    const n = (v35Rng(seed)() >>> 0).toString(36);
    return `${prefix}${n}${(seed >>> 3).toString(36)}`;
}

function v35Token(seed, serial) {
    const next = v35Rng((seed ^ Math.imul(serial + 1, 0x9E3779B9)) >>> 0);
    const alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let out = "";
    while (out.length < 4) out += alphabet[next() % alphabet.length];
    return out;
}

function v35EscapedByte(byte) {
    return `\\${Number(byte).toString(10).padStart(3, "0")}`;
}

function v36EscapedLiteral(value) {
    const bytes = Buffer.from(String(value), "utf8");
    let out = '"';
    for (const byte of bytes) out += `\\${byte.toString(10).padStart(3, "0")}`;
    return out + '"';
}

function v35BuildByteCodec(seed) {
    // v3.7: no 256-entry token map and no string.char-based decoder.
    return {
        seed,
        encodeBytes: (value) => v36EscapedLiteral(value),
        mapLiteral: null,
        decodeName: null
    };
}

function v35Slots(seed, fields, salt = 0) {
    const next = v35Rng((seed ^ salt) >>> 0);
    const shuffled = v35Shuffle(fields.map((_, i) => i + 1), next);
    return Object.fromEntries(fields.map((field, i) => [field, shuffled[i]]));
}

function v35LuaStringExpr(codec, value) {
    return codec.encodeBytes(value);
}

function v35LuaNumberExpr(codec, value) {
    const text = Number.isFinite(value) ? String(value) : "0";
    return `tonumber(${v35LuaStringExpr(codec, text)})`;
}

function v35LuaBooleanExpr(codec, value) {
    return `(${v35LuaStringExpr(codec, value ? "1" : "0")}=="1")`;
}

function v35CollectChunks(root) {
    const chunks = [];
    const seen = new Map();
    function visit(chunk) {
        if (!chunk || typeof chunk !== "object") return;
        if (seen.has(chunk)) return;
        const id = chunks.length;
        seen.set(chunk, id);
        chunks.push(chunk);
        for (const value of chunk.consts || []) {
            if (value && typeof value === "object" && value.__chunk) visit(value.__chunk);
        }
    }
    visit(root);
    return { chunks, ids: seen };
}

function v35OpcodeName(chunk, raw) {
    const code = raw?.[0];
    if (chunk?.map?.decode && Object.prototype.hasOwnProperty.call(chunk.map.decode, code)) return chunk.map.decode[code];
    if (Array.isArray(chunk?.opcode)) return chunk.opcode[code];
    return null;
}

function v35BuildGraph(chunk) {
    const raw = Array.isArray(chunk?.code) ? chunk.code : [];
    const nodes = raw.map((ins, index) => ({
        index,
        op: v35OpcodeName(chunk, ins),
        args: Array.isArray(ins) ? ins.slice(1) : [],
        next: index + 1 < raw.length ? index + 1 : null,
        alt: null
    }));

    for (const node of nodes) {
        if (node.op === "JMP") {
            node.alt = Number(node.args[0]);
            node.next = null;
        } else if (node.op === "JZ") {
            node.alt = node.args[node.args.length - 1];
        } else if (["HALT", "RETURN", "BREAK", "ITERLOOP"].includes(node.op)) {
            node.next = null;
        }
    }

    for (const node of nodes) {
        if (!node.op) throw new Error(`ByteVeil v3.7 VM: unknown opcode at instruction ${node.index}`);
        if (node.alt != null && (node.alt < 0 || node.alt >= nodes.length)) {
            throw new Error(`ByteVeil v3.7 VM: invalid jump target at instruction ${node.index}`);
        }
    }
    return nodes;
}

function v35BuildHandlers(mode, n, slots, insSlots, opNames) {
    const handlers = [];
    const push = (op, body, terminal = false) => {
        if (!opNames.has(op)) return;
        // Do not regex-scan handler source for `return`: nested function
        // expressions can contain their own returns while the VM handler still
        // needs to follow its graph edge.
        const tail = terminal ? "" : `;return ${N}`;
        handlers.push(`local ${n.handlersByOp[op]}=function(S,I)${body}${tail};end`);
    };
    const A = `I[${insSlots.args}]`;
    const N = `I[${insSlots.next}]`;
    const ALT = `I[${insSlots.alt}]`;

    if (mode === "stack") {
        const SP = `S[${slots.sp}]`;
        const STACK = `S[${slots.stack}]`;
        const LOCALS = `S[${slots.locals}]`;
        const LOCALSET = `S[${slots.localSet}]`;
        const ENV = `S[${slots.env}]`;
        const PARENT = `S[${slots.parent}]`;
        const RET = `S[${slots.ret}]`;
        const VARARGS = `S[${slots.varargs}]`;
        const HALT = `S[${slots.halt}]`;

        push("HALT", `${HALT}=true;return nil`, true);
        push("PUSHK", `${SP}=${SP}+1;${STACK}[${SP}]=${A}[1]()`);
        push("PUSHN", `${SP}=${SP}+1;${STACK}[${SP}]=${A}[1]`);
        push("PUSHB", `${SP}=${SP}+1;${STACK}[${SP}]=${A}[1]~=0`);
        push("PUSHNIL", `${SP}=${SP}+1;${STACK}[${SP}]=nil`);
        push("GETG", `${SP}=${SP}+1;${STACK}[${SP}]=${ENV}[${A}[1]()]`);
        push("SETG", `${ENV}[${A}[1]()]=${STACK}[${SP}];${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("GETL", `local T=S;local C=${A}[1]();while T do if T[${slots.localSet}][C] then ${STACK}[${SP}+1]=T[${slots.locals}][C];${SP}=${SP}+1;return I[${insSlots.next}] end;T=T[${slots.parent}] end;${SP}=${SP}+1;${STACK}[${SP}]=nil`);
        push("SETL", `local T=S;local C=${A}[1]();while T and not T[${slots.localSet}][C] do T=T[${slots.parent}] end;if not T then T=S;T[${slots.localSet}][C]=true end;T[${slots.locals}][C]=${STACK}[${SP}];${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("GETI", `local K=${STACK}[${SP}];local O=${STACK}[${SP}-1];${STACK}[${SP}-1]=O[K];${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("SETI", `local V=${STACK}[${SP}];local K=${STACK}[${SP}-1];local O=${STACK}[${SP}-2];O[K]=V;${STACK}[${SP}]=nil;${STACK}[${SP}-1]=nil;${SP}=${SP}-2`);
        for (const [op, expr] of [["ADD","+"],["SUB","-"],["MUL","*"],["DIV","/"],["IDIV","//"],["MOD","%"],["POW","^"],["EQ","=="],["NE","~="],["LT","<"],["GT",">"],["LE","<="],["GE",">="]]) {
            push(op, `local B=${STACK}[${SP}];${STACK}[${SP}-1]=${STACK}[${SP}-1]${expr}B;${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        }
        push("NOT", `${STACK}[${SP}]=not ${STACK}[${SP}]`);
        push("NEG", `${STACK}[${SP}]=-${STACK}[${SP}]`);
        push("LEN", `${STACK}[${SP}]=#${STACK}[${SP}]`);
        push("CONCAT", `local B=${STACK}[${SP}];${STACK}[${SP}-1]=${STACK}[${SP}-1]..B;${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("AND", `local B=${STACK}[${SP}];${STACK}[${SP}-1]=${STACK}[${SP}-1] and B;${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("OR", `local B=${STACK}[${SP}];${STACK}[${SP}-1]=${STACK}[${SP}-1] or B;${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("JMP", `return ${ALT}`, true);
        push("JZ", `local Z=${STACK}[${SP}];${STACK}[${SP}]=nil;${SP}=${SP}-1;if not Z then return ${ALT} end;return ${N}`, true);
        push("POP", `${STACK}[${SP}]=nil;${SP}=${SP}-1`);
        push("DUP", `${SP}=${SP}+1;${STACK}[${SP}]=${STACK}[${SP}-1]`);
        push("NEWTABLE", `${SP}=${SP}+1;${STACK}[${SP}]={}`);
        push("CALL", `local C=${A}[1];local ARGS={};for Q=C,1,-1 do ARGS[Q]=${STACK}[${SP}];${STACK}[${SP}]=nil;${SP}=${SP}-1 end;local F=${STACK}[${SP}];local R={F(${n.unpack}(ARGS,1,C))};${STACK}[${SP}]=R[1]`);
        push("RETURN", `local C=${A}[1];local R={};for Q=C,1,-1 do R[Q]=${STACK}[${SP}];${STACK}[${SP}]=nil;${SP}=${SP}-1 end;${HALT}=true;${RET}=R;return nil`, true);
        push("MAKEFUNC", `local X=${A}[1]();local P=S;${SP}=${SP}+1;${STACK}[${SP}]=function(...)return ${n.run}(X,P,...)end`);
        push("VARARG", `${SP}=${SP}+1;${STACK}[${SP}]=${VARARGS} or {}`);
        push("BREAK", `${HALT}=true;return nil`, true);
        push("SWAP", `local A1=${STACK}[${SP}];${STACK}[${SP}]=${STACK}[${SP}-1];${STACK}[${SP}-1]=A1`);
        push("MOVE_SELF", `local A1=${STACK}[${SP}-1];${SP}=${SP}+1;${STACK}[${SP}]=A1`);
        push("FORCMP", `local ST=${STACK}[${SP}];local LIM=${STACK}[${SP}-1];local IDX=${STACK}[${SP}-2];${STACK}[${SP}-2]=(ST>=0 and IDX<=LIM)or(ST<0 and IDX>=LIM);${STACK}[${SP}]=nil;${STACK}[${SP}-1]=nil;${SP}=${SP}-2`);
    } else {
        const REG = `S[${slots.reg}]`;
        const LOCALS = `S[${slots.locals}]`;
        const LOCALSET = `S[${slots.localSet}]`;
        const ENV = `S[${slots.env}]`;
        const PARENT = `S[${slots.parent}]`;
        const RET = `S[${slots.ret}]`;
        const VARARGS = `S[${slots.varargs}]`;
        const HALT = `S[${slots.halt}]`;

        push("HALT", `${HALT}=true;return nil`, true);
        push("PUSHK", `${REG}[${A}[1]]=${A}[2]()`);
        push("PUSHN", `${REG}[${A}[1]]=${A}[2]`);
        push("PUSHB", `${REG}[${A}[1]]=${A}[2]~=0`);
        push("PUSHNIL", `${REG}[${A}[1]]=nil`);
        push("GETG", `${REG}[${A}[1]]=${ENV}[${A}[2]()]`);
        push("SETG", `${ENV}[${A}[1]()]=${REG}[${A}[2]]`);
        push("GETL", `local T=S;local C=${A}[2]();while T do if T[${slots.localSet}][C] then ${REG}[${A}[1]]=T[${slots.locals}][C];return ${N} end;T=T[${slots.parent}] end;${REG}[${A}[1]]=nil`);
        push("SETL", `local T=S;local C=${A}[1]();while T and not T[${slots.localSet}][C] do T=T[${slots.parent}] end;if not T then T=S;T[${slots.localSet}][C]=true end;T[${slots.locals}][C]=${REG}[${A}[2]]`);
        push("GETI", `${REG}[${A}[1]]=${REG}[${A}[2]][${REG}[${A}[3]]]`);
        push("SETI", `${REG}[${A}[1]][${REG}[${A}[2]]]=${REG}[${A}[3]]`);
        for (const [op, expr] of [["ADD","+"],["SUB","-"],["MUL","*"],["DIV","/"],["IDIV","//"],["MOD","%"],["POW","^"],["EQ","=="],["NE","~="],["LT","<"],["GT",">"],["LE","<="],["GE",">="]]) {
            push(op, `${REG}[${A}[1]]=${REG}[${A}[2]]${expr}${REG}[${A}[3]]`);
        }
        push("NOT", `${REG}[${A}[1]]=not ${REG}[${A}[2]]`);
        push("NEG", `${REG}[${A}[1]]=-${REG}[${A}[2]]`);
        push("LEN", `${REG}[${A}[1]]=#${REG}[${A}[2]]`);
        push("CONCAT", `${REG}[${A}[1]]=${REG}[${A}[2]]..${REG}[${A}[3]]`);
        push("AND", `${REG}[${A}[1]]=${REG}[${A}[2]] and ${REG}[${A}[3]]`);
        push("OR", `${REG}[${A}[1]]=${REG}[${A}[2]] or ${REG}[${A}[3]]`);
        push("JMP", `return ${ALT}`, true);
        push("JZ", `if not ${REG}[${A}[1]] then return ${ALT} end;return ${N}`, true);
        push("CALL", `local F=${REG}[${A}[2]];local ARGS={};for Q=1,${A}[3] do ARGS[Q]=${REG}[${A}[3+Q]] end;local R={F(${n.unpack}(ARGS,1,${A}[3]))};${REG}[${A}[1]]=R[1]`);
        push("RETURN", `local R={};for Q=1,#${A} do R[Q]=${REG}[${A}[Q]] end;${HALT}=true;${RET}=R;return nil`, true);
        push("POP", `${REG}[${A}[1]]=nil`);
        push("DUP", `${REG}[${A}[1]]=${REG}[${A}[2]]`);
        push("NEWTABLE", `${REG}[${A}[1]]={}`);
        push("MAKEFUNC", `local X=${A}[2]();local P=S;${REG}[${A}[1]]=function(...)return ${n.run}(X,P,...)end`);
        push("VARARG", `${REG}[${A}[1]]=${VARARGS} or {}`);
        push("BREAK", `${HALT}=true;return nil`, true);
        push("SWAP", `local V=${REG}[${A}[1]];${REG}[${A}[1]]=${REG}[${A}[2]];${REG}[${A}[2]]=V`);
        push("MOVE_SELF", `${REG}[${A}[1]]=${REG}[${A}[2]]`);
        push("FORCMP", `local IDX=${REG}[${A}[1]];local LIM=${REG}[${A}[2]];local ST=${REG}[${A}[3]];${REG}[${A}[1]]=(ST>=0 and IDX<=LIM)or(ST<0 and IDX>=LIM)`);
        push("SETFIELD", `${REG}[${A}[1]][${A}[2]]=${REG}[${A}[3]]`);
        push("GETFIELD", `${REG}[${A}[1]]=${REG}[${A}[2]][${A}[3]]`);
    }
    return handlers;
}

function v35ChunkFactory(chunk, id, chunksInfo, codec, n, mode, stateSlots, chunkSlots, insSlots, opTokens) {
    const fn = n.factories[id];
    const graph = v35BuildGraph(chunk);
    const nodes = graph;
    const nodeNames = nodes.map((node, index) => `_${v35Token(n.seed ^ id, index)}${index.toString(36)}`);
    const lines = [];
    lines.push(`${fn}=function()`);
    if (nodeNames.length) lines.push(`local ${nodeNames.join(",")}`);

    const constExpr = (value, constIndex) => {
        if (value && typeof value === "object" && value.__chunk) {
            const nestedId = chunksInfo.ids.get(value.__chunk);
            return `${n.factories[nestedId]}()`;
        }
        if (typeof value === "string") return v35LuaStringExpr(codec, value);
        if (typeof value === "number") return v35LuaNumberExpr(codec, value);
        if (value === true) return v35LuaBooleanExpr(codec, true);
        if (value === false) return v35LuaBooleanExpr(codec, false);
        return "nil";
    };

    const consts = Array.isArray(chunk.consts) ? chunk.consts : [];
    const constFns = consts.map((_, i) => v35Ident(n.seed ^ Math.imul(id + 1, 0x51ED2708) ^ Math.imul(i + 1, 0x9E3779B9), "_k"));
    const constOrder = v35Shuffle(consts.map((_, i) => i), v35Rng(n.seed ^ Math.imul(id + 1, 0xC011EC7)));
    for (const i of constOrder) lines.push(`local ${constFns[i]}=function()return ${constExpr(consts[i], i)} end`);
    const params = Array.isArray(chunk.params) ? chunk.params : [];
    lines.push(`local P={${params.map((p) => v35LuaStringExpr(codec, p)).join(",")}}`);
    lines.push(`local V=${chunk.vararg ? "true" : "false"}`);

    const definitionOrder = v35Shuffle(nodes.map((_, i) => i), v35Rng(n.seed ^ Math.imul(id + 1, 0xC0FFEE)));
    // Allocate every node object first. This allows randomized definition order
    // without accidentally capturing a future node variable while it is still nil.
    for (const i of definitionOrder) lines.push(`${nodeNames[i]}={}`);
    for (const i of definitionOrder) {
        const node = nodes[i];
        const op = opTokens[node.op];
        const constArgIndex = mode === "stack"
            ? ({PUSHK:0,GETG:0,SETG:0,GETL:0,SETL:0,MAKEFUNC:0}[node.op] ?? -1)
            : ({PUSHK:1,GETG:1,SETG:0,GETL:1,SETL:0,MAKEFUNC:1}[node.op] ?? -1);
        const args = node.args.map((v, argIndex) => {
            if (argIndex === constArgIndex) {
                const getter = constFns[Number(v)];
                if (!getter) throw new Error(`ByteVeil v3.7 VM: invalid constant reference at instruction ${node.index}`);
                return getter;
            }
            if (typeof v === "number" && Number.isFinite(v)) return v35LuaNumberExpr(codec, v);
            if (typeof v === "boolean") return v35LuaBooleanExpr(codec, v);
            return "nil";
        });
        const next = node.next == null ? "nil" : nodeNames[node.next];
        const alt = node.alt == null ? "nil" : nodeNames[node.alt];
        const inst = [];
        inst[insSlots.op - 1] = JSON.stringify(op);
        inst[insSlots.args - 1] = `{${args.join(",")}}`;
        inst[insSlots.next - 1] = next;
        inst[insSlots.alt - 1] = alt;
        while (inst.length < 4) inst.push("nil");
        for (let slot = 1; slot <= inst.length; slot++) {
            lines.push(`${nodeNames[i]}[${slot}]=${inst[slot - 1]}`);
        }
    }

    const schema = [];
    schema[chunkSlots.root - 1] = nodes.length ? nodeNames[0] : "nil";
    schema[chunkSlots.params - 1] = `P`;
    schema[chunkSlots.vararg - 1] = `V`;
    while (schema.length < 4) schema.push("nil");
    lines.push(`return{${schema.join(",")}}`);
    lines.push("end");
    return lines.join("\n");
}

function buildStructuralGeneratedSource(bytecode, options = {}) {
    if (!bytecode || !bytecode.map) throw new TypeError("ByteVeil v3.7 structural VM: invalid bytecode");
    const mode = options.mode === "stack" ? "stack" : "register";
    const seed = Number(options.seed ?? Date.now()) >>> 0;
    const codec = v35BuildByteCodec(seed);
    const chunksInfo = v35CollectChunks(bytecode);
    const opNames = new Set();
    for (const chunk of chunksInfo.chunks) for (const ins of chunk.code || []) {
        const op = v35OpcodeName(chunk, ins);
        if (op) opNames.add(op);
    }

    const required = mode === "stack"
        ? ["HALT","PUSHK","PUSHN","PUSHB","PUSHNIL","GETG","SETG","GETL","SETL","GETI","SETI","ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE","NOT","NEG","LEN","CONCAT","JMP","JZ","CALL","RETURN","POP","DUP","NEWTABLE","MAKEFUNC","VARARG","BREAK","SWAP","MOVE_SELF","FORCMP"]
        : ["HALT","PUSHK","PUSHN","PUSHB","PUSHNIL","GETG","SETG","GETL","SETL","GETI","SETI","ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE","NOT","NEG","LEN","CONCAT","JMP","JZ","CALL","RETURN","POP","DUP","NEWTABLE","MAKEFUNC","VARARG","BREAK","SWAP","MOVE_SELF","FORCMP","SETFIELD","GETFIELD"];
    for (const op of opNames) if (!required.includes(op)) throw new Error(`ByteVeil v3.7 structural VM: unsupported opcode ${op}`);

    const stateFields = mode === "stack"
        ? ["env","root","stack","sp","locals","localSet","parent","ret","varargs","halt","guard"]
        : ["env","root","reg","locals","localSet","parent","ret","varargs","halt","guard"];
    const stateSlots = v35Slots(seed, stateFields, 0xA5110A);
    const chunkSlots = v35Slots(seed, ["root","params","vararg"], 0xB5110B);
    const insSlots = v35Slots(seed, ["op","args","next","alt"], 0xC5110C);

    const n = {
        seed,
        state: v35Ident(seed ^ 0x1001),
        handlers: v35Ident(seed ^ 0x1002),
        run: v35Ident(seed ^ 0x1003),
        root: v35Ident(seed ^ 0x1004),
        result: v35Ident(seed ^ 0x1005),
        codec: v35Ident(seed ^ 0x1006),
        unpack: v35Ident(seed ^ 0x1007),
        meta: v35Ident(seed ^ 0x1008),
        hookGuard: v35Ident(seed ^ 0x100A),
        typeSnap: v35Ident(seed ^ 0x100B),
        pcallSnap: v35Ident(seed ^ 0x100C),
        concatSnap: v35Ident(seed ^ 0x100D),
        byteSnap: v35Ident(seed ^ 0x100E),
        subSnap: v35Ident(seed ^ 0x100F),
        loadstringSnap: v35Ident(seed ^ 0x1010),
        loadSnap: v35Ident(seed ^ 0x1011),
        concat: v35Ident(seed ^ 0x1012),
        factories: chunksInfo.chunks.map((_, i) => v35Ident(seed ^ Math.imul(i + 1, 0x41A7), "_f")),
        handlersByOp: {}
    };

    const tokenOps = v35Shuffle([...opNames], v35Rng(seed ^ 0xD00D));
    const opTokens = Object.fromEntries(tokenOps.map((op, i) => [op, v35Token(seed ^ 0x7A51, i)]));
    for (const op of opNames) {
        let hash = 2166136261 >>> 0;
        for (const ch of op) hash = Math.imul(hash ^ ch.charCodeAt(0), 16777619) >>> 0;
        n.handlersByOp[op] = v35Ident(seed ^ hash, "_h");
    }

    const lines = [];
    lines.push(`local ${n.typeSnap},${n.pcallSnap},${n.concatSnap},${n.byteSnap},${n.subSnap},${n.loadstringSnap},${n.loadSnap}=type,pcall,table.concat,string.byte,string.sub,loadstring,load`);
        lines.push(`local ${n.meta}=${JSON.stringify("ByteVeil Obfuscator")}`);
    lines.push(`local ${n.unpack}=table.unpack or unpack`);
    lines.push(`local ${n.hookGuard}=function()if type~=${n.typeSnap} or pcall~=${n.pcallSnap} or table.concat~=${n.concatSnap} or string.byte~=${n.byteSnap} or string.sub~=${n.subSnap} or loadstring~=${n.loadstringSnap} or load~=${n.loadSnap} then error("ByteVeil hook/tamper detected",0)end end`);
    lines.push(`local ${n.run}`);

    // Forward-declare factories so nested function chunks can refer to any
    // other chunk regardless of traversal order.
    lines.push(`local ${n.factories.join(",")}`);

    for (let i = 0; i < chunksInfo.chunks.length; i++) {
        lines.push(v35ChunkFactory(
            chunksInfo.chunks[i],
            i,
            chunksInfo,
            codec,
            n,
            mode,
            stateSlots,
            chunkSlots,
            insSlots,
            opTokens
        ));
    }

    const handlerLines = v35BuildHandlers(mode, n, stateSlots, insSlots, opNames).map((line) => line.replace(/\bnull\b/g, "nil"));
    lines.push(...handlerLines);
    lines.push(`${n.handlers}={}`);
    for (const op of tokenOps) {
        lines.push(`${n.handlers}[${JSON.stringify(opTokens[op])}]=${n.handlersByOp[op]}`);
    }
    lines.push(`${n.hookGuard}()`);

    const stateCtor = mode === "stack"
        ? `function(E,R,P)local S={};S[${stateSlots.env}]=E;S[${stateSlots.root}]=R;S[${stateSlots.stack}]={};S[${stateSlots.sp}]=0;S[${stateSlots.locals}]={};S[${stateSlots.localSet}]={};S[${stateSlots.parent}]=P;S[${stateSlots.ret}]={};S[${stateSlots.varargs}]={};S[${stateSlots.halt}]=false;S[${stateSlots.guard}]=0;return S end`
        : `function(E,R,P)local S={};S[${stateSlots.env}]=E;S[${stateSlots.root}]=R;S[${stateSlots.reg}]={};S[${stateSlots.locals}]={};S[${stateSlots.localSet}]={};S[${stateSlots.parent}]=P;S[${stateSlots.ret}]={};S[${stateSlots.varargs}]={};S[${stateSlots.halt}]=false;S[${stateSlots.guard}]=0;return S end`;
    lines.push(`local ${n.state}=${stateCtor}`);

    if (mode === "stack") {
        lines.push(`${n.run}=function(X,P,...)local E=P and P[${stateSlots.env}] or _G;local S=${n.state}(E,X[${chunkSlots.root}],P);S[${stateSlots.varargs}]={...};for Q=1,#(X[${chunkSlots.params}] or {}) do local K=X[${chunkSlots.params}][Q];S[${stateSlots.locals}][K]=select(Q,...);S[${stateSlots.localSet}][K]=true end;local I=S[${stateSlots.root}];${n.hookGuard}();while I do local H=${n.handlers}[I[${insSlots.op}]];if not H then error(\"ByteVeil VM error\",0)end;I=H(S,I)end;${n.hookGuard}();return ${n.unpack}(S[${stateSlots.ret}] or {},1,#(S[${stateSlots.ret}] or {}))end`);
    } else {
        lines.push(`${n.run}=function(X,P,...)local E=P and P[${stateSlots.env}] or _G;local S=${n.state}(E,X[${chunkSlots.root}],P);S[${stateSlots.varargs}]={...};for Q=1,#(X[${chunkSlots.params}] or {}) do local K=X[${chunkSlots.params}][Q];S[${stateSlots.locals}][K]=select(Q,...);S[${stateSlots.localSet}][K]=true end;local I=S[${stateSlots.root}];${n.hookGuard}();while I do local H=${n.handlers}[I[${insSlots.op}]];if not H then error(\"ByteVeil VM error\",0)end;I=H(S,I)end;${n.hookGuard}();return ${n.unpack}(S[${stateSlots.ret}] or {},1,#(S[${stateSlots.ret}] or {}))end`);
    }

    lines.push(`local ${n.root}=${n.factories[0]}()`);
    lines.push(`local ${n.result}={${n.run}(${n.root},nil)}`);
    lines.push(`return ${n.unpack}(${n.result},1,#${n.result})`);

    // The metadata table is intentionally live but semantically inert. Add a
    // second randomized marker on stronger builds for project identification.
    if (Number(options.strength || 0) >= 7500) {
        lines.splice(Math.max(1, Math.floor(lines.length / 3)), 0, `local ${n.meta}=${JSON.stringify(`ByteVeil Obfuscator ${v35Token(seed ^ 0xBEEF, 1)}`)}`);
    }

    let output = lines.join("\n");
    output = output.replace(/\bByteCode\b/g, "ByteVeil");
    if (/string\.char/.test(output)) throw new Error("ByteVeil v3.7 generator invariant failed: string.char emitted");
    return {
        output,
        layout: "random-graph-structural-vm",
        version: "3.7.0",
        mode,
        stateSlots,
        chunkSlots,
        instructionSlots: insSlots,
        opTokens,
        protectedStrings: true,
        arithmeticProtection: false,
        sourceReconstruction: false,
        stringChar: false
    };
}

module.exports.buildGeneratedSourceV35 = buildStructuralGeneratedSource;

// ---------------------------------------------------------------------------
// ByteVeil v4.1 legacy generator entry retained for compatibility.
// The executable output contains only printable packed payload shards. The
// compiler/CFG is serialized to opaque bytes and interpreted after decoding;
// no Lua-visible instruction graph or source fragments are emitted.
// ---------------------------------------------------------------------------
const { stackHandler, registerHandler } = require("../../vm/vm_handlers");

function v38Rng(seed) {
    let s = (Number(seed) >>> 0) || 0xA341316C;
    return () => {
        s ^= s >>> 16;
        s = Math.imul(s, 2246822519) >>> 0;
        s ^= s >>> 13;
        s = Math.imul(s, 3266489917) >>> 0;
        s ^= s >>> 16;
        return s >>> 0;
    };
}

function v38Shuffle(values, seed) {
    const out = values.slice();
    const next = v38Rng(seed);
    for (let i = out.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
}

function v38Id(seed, suffix = "") {
    // Do not serialize `(seed ^ constant).toString(36)` into identifiers.
    // That older naming scheme leaked the build seed and made related aliases
    // visibly share a prefix. Mix the seed and role label before encoding them.
    let state = ((Number(seed) >>> 0) ^ 0x9E3779B9) >>> 0;
    const label = String(suffix);
    for (let i = 0; i < label.length; i++) {
        state = Math.imul(state ^ label.charCodeAt(i), 0x85EBCA6B) >>> 0;
        state ^= state >>> 13;
    }
    state ^= state >>> 16;
    state = Math.imul(state, 0x7FEB352D) >>> 0;
    state ^= state >>> 15;
    state = Math.imul(state, 0x846CA68B) >>> 0;
    state ^= state >>> 16;

    const head = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const body = `${head}0123456789`;
    const out = [];
    const length = 5 + (state % 3);
    for (let i = 0; i < length; i++) {
        state = (state + 0x6D2B79F5) >>> 0;
        let value = state;
        value = Math.imul(value ^ (value >>> 15), value | 1) >>> 0;
        value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
        value = (value ^ (value >>> 14)) >>> 0;
        out.push(i === 0 ? head[value % head.length] : body[value % body.length]);
    }
    return `_${out.join("")}`;
}

function v38Slots(seed, names) {
    const order = v38Shuffle(names, seed);
    const slots = Object.create(null);
    order.forEach((name, index) => { slots[name] = index + 1; });
    return slots;
}

function v38SupportedStringByte(b) {
    // Packed strings are byte arrays. UTF-8 multi-byte sequences and arbitrary
    // Lua string bytes are valid, because v4.6.6 runtime reader materializes
    // each byte independently with string.char.
    return Number.isInteger(b) && b >= 0 && b <= 255;
}

function reserveLocalName(N, base) {
    const used = N.__usedLocalNames || (N.__usedLocalNames = new Set(Object.values(N).filter(v => typeof v === "string")));
    let salt = (String(base).split("").reduce((h, c) => ((h * 33) ^ c.charCodeAt(0)) >>> 0, 5381) ^ used.size ^ 0x51ED2708) >>> 0;
    const initialName = v38Id(salt, String(base));
    let name = initialName;
    let suffix = 0;
    while (used.has(name)) name = `${initialName}_v${(++suffix).toString(36)}`;
    used.add(name);
    return name;
}

// Generator output is not minified yet, so a local can be emitted as
// `local a=b`, `local a = b` or `local function a(...)`.
function findLocalDeclaration(source, name) {
    const escaped = String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = new RegExp(`local\\s+(?:function\\s+)?${escaped}\\s*[=(]`).exec(source);
    return match ? match.index : -1;
}


function buildV452GeneratedSource(bytecode, { seed, mode, strength, decoyProfile, decoderVariant, opNames, S, C, N, defs, packed, vmPersonality, runtimeBridgeParam = null, forgeLatch = null, guardLatch = null }) {
    const lines = [];
    // The serializer derives region material from `rootSeed + forgeLatch + guardLatch`,
    // so the runtime reads its region seed back through the same addends.
    // `forgeLatch.holder` is the JunkForge key-bed block's chunk-level local and
    // `guardKeyHolder` is the anti-hook verdict; without either one the arithmetic
    // fails before a single payload byte is decoded.
    let guardKeyHolder = null;
    const materialRootExpression = () => {
        const addends = [];
        if (forgeLatch && forgeLatch.holder) addends.push(String(forgeLatch.holder));
        if (guardKeyHolder) addends.push(guardKeyHolder);
        return addends.length ? `(RROOT+${addends.join("+")})%4294967296` : "RROOT";
    };
    let materialRoot = materialRootExpression();
    const vmVariant = Number(packed.vmVariant ?? ((Number(packed.buildPersonality || seed) >>> 0) % 4)) >>> 0;
    const vmPersonalitySeed = Number(packed.vmPersonality ?? packed.buildPersonality ?? seed) >>> 0;
    const personality = vmPersonality || buildV455Personality(vmPersonalitySeed, mode);
const v530 = packed.hardeningVersion === "5.3.0";
const v590 = packed.hardeningVersion === "5.9.0";
const v580 = packed.hardeningVersion === "5.8.0" || v590;
const v570 = packed.hardeningVersion === "5.7.0" || v580;
const v560 = packed.hardeningVersion === "5.6.0" || v570;
const v550 = packed.hardeningVersion === "5.5.0" || v560;
const v540 = packed.hardeningVersion === "5.4.0" || v550;
// Derive the shadow state's randomized field names before emitting the interpreter
// loop; this must use the same root seed and derivation as buildSemanticShadowVM.
const _shadowStateNameVector = v540 ? buildShadowStrings(packed.rootSeed >>> 0, 24) : ["pc", "r", "m", "f", "acc", "tick", "calls", "ret"];
const shadowStateKeys = {
    pc: _shadowStateNameVector[0], r: _shadowStateNameVector[1], m: _shadowStateNameVector[2],
    f: _shadowStateNameVector[3], acc: _shadowStateNameVector[4], tick: _shadowStateNameVector[5],
    calls: _shadowStateNameVector[6], ret: _shadowStateNameVector[7]
};
const v51BuildDiverse = v530 || v540;
const v500 = packed.hardeningVersion === "5.0.0" || v51BuildDiverse;
const v479 = packed.hardeningVersion === "4.7.9" || v500;
const v478 = packed.hardeningVersion === "4.7.8" || v479;
const v477 = packed.hardeningVersion === "4.7.7" || v478;
const v476 = packed.hardeningVersion === "4.7.6" || v477;
const v475 = packed.hardeningVersion === "4.7.5";
const v474 = packed.hardeningVersion === "4.7.4";
const v473 = packed.hardeningVersion === "4.7.3";
const v472 = packed.hardeningVersion === "4.7.2" || v473 || v474 || v475 || v476;
const v471 = packed.hardeningVersion === "4.7.1" || v472;
const v471Label = v590 ? "5.9.0" : v580 ? "5.8.0" : v570 ? "5.7.0" : v560 ? "5.6.0" : v550 ? "5.5.0" : v540 ? "5.4.0" : v530 ? "5.3.0" : v500 ? "5.0.0" : v479 ? "4.7.9" : v478 ? "4.7.8" : v477 ? "4.7.7" : v476 ? "4.7.6" : v475 ? "4.7.5" : v474 ? "4.7.4" : v473 ? "4.7.3" : v472 ? "4.7.2" : "4.7.1";
const v468 = packed.hardeningVersion === "4.6.8" || v471;
    const v46 = packed.hardeningVersion === "4.6.1" || packed.hardeningVersion === "4.6.2" || packed.hardeningVersion === "4.6.3" || packed.hardeningVersion === "4.6.4" || (packed.hardeningVersion === "4.6.5" || packed.hardeningVersion === "4.6.6" || packed.hardeningVersion === "4.6.7" || v468);
    const v455 = packed.hardeningVersion === "4.5.5";
    const used = N.__v452Used || new Set(Object.values(N).filter((v) => typeof v === "string"));
    const opaque = (key, salt = 0) => {
        let h = 2166136261 >>> 0;
        for (const ch of String(key)) h = Math.imul((h ^ ch.charCodeAt(0)) >>> 0, 16777619) >>> 0;
        let x = (Number(seed) ^ h ^ Math.imul((salt + 1) >>> 0, 0x9E3779B1) ^ 0xA5A5C3C3) >>> 0;
        let out = v38Id(x, "");
        while (used.has(out)) { x = (x + 0x27D4EB2F) >>> 0; out = v38Id(x, ""); }
        used.add(out);
        return out;
    };
    const V = {
        graph: opaque("g",1), state: opaque("s",2), fetch: opaque("f",3), readers: opaque("r",4),
        peek: opaque("p",5), regionFor: opaque("rf",6), vma: opaque("a",7), vmb: opaque("b",8),
        microExit: opaque("x",9), decoys: opaque("d",10), decoyRun: opaque("dr",11), personality: opaque("ps",12),
        shadowCode: opaque("shadow-code",23), shadowOrder: opaque("shadow-order",24), shadowHandlers: opaque("shadow-handlers",25), shadowCore: opaque("shadow-handler-core",56),
        shadowInit: opaque("shadow-init",26), shadowStep: opaque("shadow-step",27), shadowLiveMap: opaque("shadow-live-map",28), shadowProof: opaque("shadow-proof",29), shadowAuth: opaque("shadow-auth",30),
        shadowSemanticHandlers: opaque("shadow-semantic-handlers",31), shadowSemanticProbe: opaque("shadow-semantic-probe",32), shadowSemanticPlans: opaque("shadow-semantic-plans",33), shadowVMState: opaque("shadow-vm-state",34),
        shadowProofSemanticProbe: opaque("shadow-proof-semantic-probe",43), shadowProofVMState: opaque("shadow-proof-vm-state",44),
        shadowFrame: opaque("shadow-frame",55), shadowSandboxNoop: opaque("shadow-sandbox-noop",35), shadowSandboxConst: opaque("shadow-sandbox-const",36), shadowSandboxResolve: opaque("shadow-sandbox-resolve",37), shadowSandboxWrite: opaque("shadow-sandbox-write",38), shadowSandboxRun: opaque("shadow-sandbox-run",39), shadowSandboxSuper: opaque("shadow-sandbox-super",40), shadowSemanticTrace: opaque("shadow-semantic-trace",41), shadowSemanticDigest: opaque("shadow-semantic-digest",42),
        descriptorRead: opaque("packed-region-descriptor-reader",45),
        payloadCarrierBank: opaque("payload-carrier-bank",46),
        payloadLaneCache: opaque("payload-lane-cache",47),
        payloadLaneMap: opaque("payload-lane-map",48),
        payloadDescriptorMap: opaque("payload-descriptor-map",49),
        readPayloadLane: opaque("payload-lane-reader",50),
        readPayloadDescriptor: opaque("payload-descriptor-reader",51),
        decodePayloadCarrier: opaque("payload-carrier-decoder",52),
        payloadIntegrityRecords: opaque("payload-integrity-records",53),
        payloadToBytes: opaque("payload-to-byte-table",54),
        junkCarrierDigest: opaque("junk-carrier-digest",57),
        junkCarrierDecode: opaque("junk-carrier-decode",58),
        compose: opaque("compose",13), microExec: opaque("micro-exec",14), coreDispatch: opaque("core-dispatch",15),
        packInstruction: opaque("pack-instruction",16), unpackInstruction: opaque("unpack-instruction",17),
        constantMorph: opaque("constant-morph",18), regionFlavor: opaque("region-flavor",19),
        env: opaque("execution-env",20), envGuard: opaque("env-guard",21), advance: opaque("control-advance",22),
        banks: [], rec: []
    };
    const antiBundle = v479 ? buildAntiBundle({
        seed: Number(seed) >>> 0,
        ...VM_ANTI_BUNDLE_CONFIG,
        antiHook: true,
        antiDump: true,
        antiTamper: true,
        failClosedOnMissingEnvironment: v500,
        baselineFromEnvironment: v540,
        cleanupTargets: []
    }) : null;
    if (v479) {
        const records = Array.isArray(packed.payloadLaneIntegrity) ? packed.payloadLaneIntegrity : [];
        if (records.length !== Number(packed.payloadLaneCount || 0) || !packed.payloadDescriptorIntegrity ||
            !Number.isInteger(packed.payloadDescriptorIntegrity.mirrorChecksum)) {
            throw new Error("ByteVeil v4.7.9 anti-tamper invariant failed: serializer integrity records are missing");
        }
        if (records.some((record, index) => record.lane !== index + 1 || !Number.isInteger(record.checksum) || !Number.isInteger(record.length) || !Number.isInteger(record.mirrorChecksum))) {
            throw new Error("ByteVeil v4.7.9 anti-tamper invariant failed: malformed lane integrity record");
        }
        antiBundle.metadata.antiTamperLayers = 1;
        antiBundle.metadata.antiTamperEnabled = true;
        antiBundle.metadata.antiTamperPayloadCheckConfigured = true;
        // Temporary fragment tables are wiped inside the lazy readers. Do not
        // clear the lane cache after the first call: returned VM closures may
        // resolve additional regions after their creating function has returned.
        antiBundle.metadata.antiDumpLayers = 1;
        antiBundle.metadata.antiDumpEnabled = true;
        antiBundle.metadata.antiDumpMutableCleanup = true;
        antiBundle.metadata.antiDumpCleanupPoint = "after-lane-and-descriptor-assembly";
    }
    // Anti-hook verdict as key material. The guard folds API/library identity plus the
    // behavioural canaries into a number the serializer has already mixed into the
    // region root, so stubbing the guard or hooking the environment costs the payload
    // its key instead of only losing a check. The generator re-derives the number from
    // the bundle it actually emits, so a config drift between the two fails the build
    // rather than shipping a script that cannot decode itself.
    if (guardLatch && guardLatch.value != null) {
        const offered = Number(guardLatch.value);
        const emitted = Number(antiBundle?.helpers?.hook?.digest?.expected ?? -1);
        if (!Number.isInteger(offered) || emitted !== offered) {
            throw new Error(`ByteVeil v5.9 anti-hook key binding failed: guard verdict ${emitted} != serializer addend ${offered}`);
        }
        guardKeyHolder = opaque("guard-key-latch", 59);
        materialRoot = materialRootExpression();
    }
    const packedShardRead = v479
        ? `(function()local D=G.pd[R.ord[I]];if type(D)~="table" or type(D[1])~="number" or type(D[2])~="number" or type(D[3])~="number" or D[1]~=math.floor(D[1]) or D[2]~=math.floor(D[2]) or D[3]~=math.floor(D[3]) or D[1]<1 or D[1]>${Number(packed.payloadLaneCount || 0)} or D[2]<1 or D[3]<1 then error("payload address",0)end;local S=${V.readPayloadLane}(D[1]);if type(S)~="string" or D[2]+D[3]-1>#S then error("payload address bounds",0)end;return ${N.decode85}(string.sub(S,D[2],D[2]+D[3]-1))end)()`
        : `${N.decode85}(R.data[R.ord[I]])`;
    const modeFlag = mode === "register" ? 1 : 0;
    const rawAsciiStr = Array.from({ length: 95 }, (_, i) => String.fromCharCode(32 + i)).join("");
    const asciiStepCandidates = [2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17, 18, 21, 22, 23, 24, 26, 27, 28, 29];
    const asciiStep = v580 ? asciiStepCandidates[(Number(seed) >>> 0) % asciiStepCandidates.length] : 1;
    const asciiOff = v580 ? ((Number(seed) >>> 5) % 95) : 0;
    const permutedAsciiArr = new Array(95);
    for (let i = 0; i < 95; i++) {
        permutedAsciiArr[(i * asciiStep + asciiOff) % 95] = rawAsciiStr[i];
    }
    const permutedAsciiStr = permutedAsciiArr.join("");
    const splitIntoLuaConcat = (str, splitSeed) => {
        const chunks = [];
        let cur = 0;
        let st = (splitSeed >>> 0) || 0x58A1;
        while (cur < str.length) {
            st = (Math.imul(st, 1664525) + 1013904223) >>> 0;
            const sz = 3 + (st % 4);
            chunks.push(JSON.stringify(str.slice(cur, cur + sz)));
            cur += sz;
        }
        return `table.concat({${chunks.join(",")}})`;
    };
    const ascii = v580 ? splitIntoLuaConcat(permutedAsciiStr, Number(seed) ^ 0x58A5C11) : JSON.stringify(rawAsciiStr);
    const rawAlphabetStr = UNIFIED_ALPHABET;
    const alphabet = v580 ? splitIntoLuaConcat(rawAlphabetStr, Number(seed) ^ 0x58A1F85) : JSON.stringify(rawAlphabetStr);
    const envFamily = Number(personality.envFamily || 0) % 4;
    const envExpr = envFamily === 0
        ? "((getgenv and getgenv())or(getfenv and getfenv(1))or _G)"
        : envFamily === 1
            ? "((getfenv and getfenv(1))or(getgenv and getgenv())or _G)"
            : envFamily === 2
                ? "((getgenv and getgenv())or(getfenv and getfenv(0))or _G)"
                : "((getfenv and getfenv(0))or(getfenv and getfenv(1))or _G)";
    lines.push(`local ${V.env}=${v46 ? envExpr : "((getgenv and getgenv())or(getfenv and getfenv(1))or _G)"};local ${V.envGuard}=function()local E=${V.env};if not E then error("ByteVeil v4.6.3: environment unavailable",0)end;return E end;local ${N.unpackBuiltin}=${V.env}["table"] and (${V.env}["table"].unpack or ${V.env}["unpack"]) or table.unpack or unpack`);
    lines.push(buildXorChooser(N.bx));
    lines.push(`local ${N.xor}=${N.bx}`);
    lines.push(`local ${N.mul}=function(A,B)local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end`);
    lines.push(`local ${N.mix}=function(U,V)local R=${N.bx}(U,${N.bx}(V,0xB17E4A31));R=${N.bx}(R,math.floor(R/65536));R=${N.mul}(R,2246822519);R=${N.bx}(R,math.floor(R/8192));R=${N.mul}(R,3266489917);return ${N.bx}(R,math.floor(R/65536)) end`);
    lines.push(`local ${N.checksum}=function(D)local H=17;for I=1,#D do H=(H*65599+D[I]+1)%2147483647 end;return H end`);
    lines.push(`local ${N.run}`);
    lines.push(`local ${N.superFns}={}`);
    const constFunctionBody = (v455 || v46)
        ? `local T=S[${S.consts}];local V0=T[I+1];if type(V0)=="function"then V0=V0(S);local K0=(${N.bx}((S[${S.region}]or 0)+I+${Number(personality.id)},0x${(Number(personality.semanticSalt)>>>0).toString(16)})%6);local W;if K0==0 then W={[0]=0,[1]=V0,[2]=0x${(Number(personality.representationSalt)>>>0).toString(16)}}elseif K0==1 then W={a=V0,b=K0,m=0x${(Number(personality.stateSalt)>>>0).toString(16)}}elseif K0==2 then W={q={K0,V0},z=0x${(Number(personality.topologySalt)>>>0).toString(16)}}elseif K0==3 then W={r=K0,s=V0,t=0x${(Number(personality.semanticSalt^0x5A5A5A5A)>>>0).toString(16)}}elseif K0==4 then W={p=V0,k=K0,u=0x${(Number(personality.representationSalt^0xA5A5A5A5)>>>0).toString(16)}}else W={{K0,V0},d=0x${(Number(personality.stateSalt^0xC3C3C3C3)>>>0).toString(16)}}end;T[I+1]=W;V0=W end;if type(V0)=="table"then if V0[2]==0x${(Number(personality.representationSalt)>>>0).toString(16)} then return V0[1] elseif V0.m==0x${(Number(personality.stateSalt)>>>0).toString(16)} then return V0.a elseif V0.z==0x${(Number(personality.topologySalt)>>>0).toString(16)} then return V0.q[2] elseif V0.t==0x${(Number(personality.semanticSalt^0x5A5A5A5A)>>>0).toString(16)} then return V0.s elseif V0.u==0x${(Number(personality.representationSalt^0xA5A5A5A5)>>>0).toString(16)} then return V0.p elseif V0.d==0x${(Number(personality.stateSalt^0xC3C3C3C3)>>>0).toString(16)} then return V0[1][2] end end;return V0`
        : `local T=S[${S.consts}];local V0=T[I+1];if type(V0)=="function"then local R0=V0(S);T[I+1]=R0;return R0 end;return V0`;
    const renderStateInstructionFunction = (body, identity) => mode === "stack"
        ? stackHandler("", body, { seed, identity: `v51-${identity}` })
        : registerHandler("", body, { seed, identity: `v51-${identity}` });
    lines.push(`local ${N.const}=${renderStateInstructionFunction(constFunctionBody, "constant-access")}`);
    const resolveGlobalBody = `local E=${V.envGuard}();local K=${N.const}(S,I);if rawget then local V0=rawget(E,K);if V0~=nil then return V0 end end;return E[K]`;
    lines.push(`local ${N.resolveGlobal}=${renderStateInstructionFunction(resolveGlobalBody, "resolve-global")}`);
    lines.push(`local ${N.writeGlobal}=function(S,I,V0)local E=${V.envGuard}();local K=${N.const}(S,I);E[K]=V0 end`);
    lines.push(`local ${N.alphabet}=${alphabet}`);
    lines.push(`local ${N.decode85}=function(T)local O={};for I=1,#T,5 do local V0=0;for J=0,4 do local P=string.find(${N.alphabet},string.sub(T,I+J,I+J),1,true);if not P then error("ByteVeil v4.6.3: payload alphabet",0)end;V0=V0*${PAYLOAD_RADIX}+P-1 end;O[#O+1]=math.floor(V0/16777216)%256;O[#O+1]=math.floor(V0/65536)%256;O[#O+1]=math.floor(V0/256)%256;O[#O+1]=V0%256 end;return O end`);
    const v479DescriptorInit = v479 ? `local ${V.descriptorRead}=function(S)local B=${N.decode85}(S);if B[1]~=66 or B[2]~=86 or B[3]~=82 or B[4]~=68 or B[5]~=1 then error("ByteVeil v4.7.9: descriptor header",0)end;local P=6;local function U()local V0=0;local M0=1;for K0=1,5 do local B0=B[P];if B0==nil then error("ByteVeil v4.7.9: descriptor truncated",0)end;P=P+1;V0=V0+(B0%128)*M0;if B0<128 then return V0 end;M0=M0*128 end;error("ByteVeil v4.7.9: descriptor varint overflow",0)end;local function A()local N0=U();if N0>100000 then error("ByteVeil v4.7.9: descriptor array bound",0)end;local O={};for J=1,N0 do O[J]=U()end;return O end;local N0=U();if N0>8192 then error("ByteVeil v4.7.9: descriptor region bound",0)end;local R0={};for I=1,N0 do local R={id=U(),start=U(),len=U(),tok=U(),chk=U(),st=U(),rv=U(),rf=U(),rs=U(),ps=U(),rep=U(),cr=U(),ir=U(),cf=U(),rps=U(),il=U(),af=U(),sa=U(),mf=U(),sm=U()};R.dep=A();R.route=A();R.voc=A();R.ord=A();R.sl=A();R0[#R0+1]=R end;local Q=U();if Q>100000 then error("ByteVeil v4.7.9: descriptor directory bound",0)end;local D0={};for I=1,Q do D0[I]={U(),U(),U()}end;return R0,D0 end;G.regions,G.pd=${V.descriptorRead}(${V.readPayloadDescriptor}());for L0=1,${Number(packed.payloadLaneCount || 0)} do ${V.readPayloadLane}(L0)end;if #G.regions~=G.n then error("ByteVeil v4.7.9: descriptor cardinality",0)end;`
        : "";

    const integrityGuard471 = `local __bv_type=type;local __bv_byte=string.byte;local __bv_sub=string.sub;local __bv_find=string.find;local __bv_concat=table.concat;local __bv_floor=math.floor;local __bv_rawget=rawget;local __bv_rawequal=rawequal;local __bv_setmeta=setmetatable;local __bv_getmeta=getmetatable;local __bv_getgenv=getgenv;local __bv_getfenv=getfenv;local __bv_pcall=pcall;local __bv_xpcall=xpcall;local __bv_next=next;local __bv_select=select;local __bv_tostring=tostring;local __bv_rawset=rawset;local __bv_load=load;local __bv_loadstring=loadstring;local __bv_debug=debug;local __bv_getinfo=__bv_debug and __bv_debug.getinfo;local __bv_gethook=__bv_debug and __bv_debug.gethook;local __bv_sethook=__bv_debug and __bv_debug.sethook;local __bv_envload=${V.env}["load"];local __bv_envloadstring=${V.env}["loadstring"];local __bv_nativeChecks=(type(_VERSION)=="string" and __bv_sub(_VERSION,1,5)=="Lua 5" and __bv_getinfo~=nil);local __bv_nativeProofDone=false;local __bv_native=function(F)if __bv_nativeChecks and type(F)=="function"then local I=__bv_getinfo(F,"S");if not I or I.what~="C"then error("ByteVeil v4.7.1: runtime API provenance mismatch",0)end end end;local __bv_envNative=function(F,L)if __bv_nativeChecks and type(F)=="function"then local I=__bv_getinfo(F,"S");if not I or I.what~="C"then error("ByteVeil v4.7.1: "..L,0)end end end;local ${N.runtimeGuard}=function()local E=${V.envGuard}();if type~=__bv_type or string.byte~=__bv_byte or string.sub~=__bv_sub or string.find~=__bv_find or table.concat~=__bv_concat or math.floor~=__bv_floor or rawget~=__bv_rawget or rawset~=__bv_rawset or rawequal~=__bv_rawequal or setmetatable~=__bv_setmeta or getmetatable~=__bv_getmeta or pcall~=__bv_pcall or xpcall~=__bv_xpcall or next~=__bv_next or select~=__bv_select or tostring~=__bv_tostring or load~=__bv_load or loadstring~=__bv_loadstring then error("ByteVeil v4.7.1: runtime reference integrity failed",0)end;if E["load"]~=__bv_envload or E["loadstring"]~=__bv_envloadstring then error("ByteVeil v4.7.1: loader environment changed",0)end;if getgenv~=__bv_getgenv or getfenv~=__bv_getfenv then error("ByteVeil v4.7.1: environment hook detected",0)end;if not E or E["type"]~=__bv_type or E["table"]==nil then error("ByteVeil v4.7.1: environment shape changed",0)end;if __bv_nativeChecks and E then local EM=__bv_getmeta(E);if EM then local IX=__bv_rawget(EM,"__index");local NX=__bv_rawget(EM,"__newindex");if IX~=nil then if type(IX)=="function"then __bv_envNative(IX,"environment index logger detected")elseif type(IX)=="table"then local SG=__bv_rawget(IX,"string");__bv_envNative(type(SG)=="table" and __bv_rawget(SG,"sub") or nil,"environment index supply hook detected")end end;if NX~=nil then __bv_envNative(NX,"environment write hook detected")end end end;if debug and debug.gethook and debug.gethook()~=nil then error("ByteVeil v4.7.1: debug hook detected",0)end;if debug~=__bv_debug or (debug and debug.getinfo)~=__bv_getinfo or (debug and debug.gethook)~=__bv_gethook or (debug and debug.sethook)~=__bv_sethook then error("ByteVeil v4.7.1: debug inspection integrity failed",0)end;if __bv_nativeChecks and not __bv_nativeProofDone then __bv_native(__bv_getinfo);if type(__bv_load)=="function"then __bv_native(__bv_load)end;if type(__bv_loadstring)=="function"then __bv_native(__bv_loadstring)end;if type(__bv_envload)=="function"then __bv_native(__bv_envload)end;if type(__bv_envloadstring)=="function"then __bv_native(__bv_envloadstring)end;__bv_native(__bv_gethook);__bv_native(__bv_sethook);__bv_native(__bv_type);__bv_native(__bv_byte);__bv_native(__bv_sub);__bv_native(__bv_find);__bv_native(__bv_concat);__bv_native(__bv_floor);__bv_native(__bv_rawget);__bv_native(__bv_rawset);__bv_native(__bv_rawequal);__bv_native(__bv_setmeta);__bv_native(__bv_getmeta);__bv_native(__bv_pcall);__bv_native(__bv_xpcall);__bv_native(__bv_next);__bv_native(__bv_select);__bv_native(__bv_tostring);__bv_nativeProofDone=true end end;local ${N.hookGuard}=${N.runtimeGuard}`;
    const integrityGuardActive = (v475 || v476)
        ? integrityGuard471
            .replace('local __bv_rawset=rawset;local __bv_load=load;local __bv_loadstring=loadstring;local __bv_debug=debug;', 'local __bv_rawset=rawset;local __bv_buffer=buffer;local __bv_bcreate=type(buffer)=="table" and buffer.create;local __bv_breadu8=type(buffer)=="table" and buffer.readu8;local __bv_bwriteu8=type(buffer)=="table" and buffer.writeu8;local __bv_debug=debug;')
            .replace(/local __bv_envload=[^;]+;local __bv_envloadstring=[^;]+;/, '')
            .replace(' or load~=__bv_load or loadstring~=__bv_loadstring', '')
            .replace('or tostring~=__bv_tostring then error("ByteVeil v4.7.1: runtime reference integrity failed",0)', 'or tostring~=__bv_tostring or buffer~=__bv_buffer or (type(__bv_buffer)=="table" and (__bv_buffer.create~=__bv_bcreate or __bv_buffer.readu8~=__bv_breadu8 or __bv_buffer.writeu8~=__bv_bwriteu8)) then error("ByteVeil v4.7.1: runtime reference integrity failed",0)')
            .replace('if E["load"]~=__bv_envload or E["loadstring"]~=__bv_envloadstring then error("ByteVeil v4.7.1: loader environment changed",0)end;', '')
            .replace('if type(__bv_load)=="function"then __bv_native(__bv_load)end;if type(__bv_loadstring)=="function"then __bv_native(__bv_loadstring)end;if type(__bv_envload)=="function"then __bv_native(__bv_envload)end;if type(__bv_envloadstring)=="function"then __bv_native(__bv_envloadstring)end;', '')
        : integrityGuard471;
    // Guard failures must surface with their own message and must abort even when the host
    // replaced `error` with a stub. The name blender rewrites call-position `error` to an
    // alias that is not always in scope at the guard site, so the guard keeps its own
    // reference and a VM-intrinsic trap that cannot be intercepted.
    const withFailTrap = (text) => text
        .replace("local __bv_type=type;", 'local __bv_errorRef=error;local __bv_error=function(M)__bv_errorRef(M,0)local Z=({})[1]return Z.x end;local __bv_type=type;')
        .replace(/\berror\("ByteVeil v/g, '__bv_error("ByteVeil v')
        .replace("__bv_native(__bv_type);", "__bv_native(__bv_errorRef);__bv_native(__bv_type);");
    lines.push(withFailTrap(v471 ? integrityGuardActive.replace(/v4\.7\.1/g, `v${v471Label}`) : (v468
        ? `local __bv_type=type;local __bv_byte=string.byte;local __bv_sub=string.sub;local __bv_find=string.find;local __bv_concat=table.concat;local __bv_floor=math.floor;local __bv_rawget=rawget;local __bv_rawequal=rawequal;local __bv_setmeta=setmetatable;local __bv_getmeta=getmetatable;local __bv_getgenv=getgenv;local __bv_getfenv=getfenv;local __bv_pcall=pcall;local __bv_xpcall=xpcall;local __bv_next=next;local __bv_select=select;local __bv_tostring=tostring;local __bv_rawset=rawset;local __bv_debug=debug;local __bv_getinfo=__bv_debug and __bv_debug.getinfo;local __bv_gethook=__bv_debug and __bv_debug.gethook;local __bv_sethook=__bv_debug and __bv_debug.sethook;local __bv_nativeChecks=(type(_VERSION)=="string" and __bv_sub(_VERSION,1,5)=="Lua 5" and __bv_getinfo~=nil);local __bv_nativeProofDone=false;local __bv_native=function(F)if __bv_nativeChecks then local I=__bv_getinfo(F,"S");if not I or I.what~="C" then error("ByteVeil v4.6.8: runtime API provenance mismatch",0)end end end;local ${N.runtimeGuard}=function()local E=${V.envGuard}();if type~=__bv_type or string.byte~=__bv_byte or string.sub~=__bv_sub or string.find~=__bv_find or table.concat~=__bv_concat or math.floor~=__bv_floor or rawget~=__bv_rawget or rawset~=__bv_rawset or rawequal~=__bv_rawequal or setmetatable~=__bv_setmeta or getmetatable~=__bv_getmeta or pcall~=__bv_pcall or xpcall~=__bv_xpcall or next~=__bv_next or select~=__bv_select or tostring~=__bv_tostring then error("ByteVeil v4.6.8: runtime reference integrity failed",0)end;if getgenv~=__bv_getgenv or getfenv~=__bv_getfenv then error("ByteVeil v4.6.8: environment hook detected",0)end;if not E or E["type"]~=__bv_type or E["table"]==nil then error("ByteVeil v4.6.8: environment shape changed",0)end;if debug and debug.gethook and debug.gethook()~=nil then error("ByteVeil v4.6.8: debug hook detected",0)end;if debug~=__bv_debug or (debug and debug.getinfo)~=__bv_getinfo or (debug and debug.gethook)~=__bv_gethook or (debug and debug.sethook)~=__bv_sethook then error("ByteVeil v4.6.8: debug inspection integrity failed",0)end;if __bv_nativeChecks and not __bv_nativeProofDone then __bv_native(__bv_getinfo);__bv_native(__bv_gethook);__bv_native(__bv_sethook);__bv_native(__bv_type);__bv_native(__bv_byte);__bv_native(__bv_sub);__bv_native(__bv_find);__bv_native(__bv_concat);__bv_native(__bv_floor);__bv_native(__bv_rawget);__bv_native(__bv_rawset);__bv_native(__bv_rawequal);__bv_native(__bv_setmeta);__bv_native(__bv_getmeta);__bv_native(__bv_pcall);__bv_native(__bv_xpcall);__bv_native(__bv_next);__bv_native(__bv_select);__bv_native(__bv_tostring);__bv_nativeProofDone=true end end;local ${N.hookGuard}=${N.runtimeGuard}`
        : `local __bv_type=type;local __bv_byte=string.byte;local __bv_sub=string.sub;local __bv_find=string.find;local __bv_concat=table.concat;local __bv_floor=math.floor;local __bv_rawget=rawget;local __bv_rawequal=rawequal;local __bv_setmeta=setmetatable;local __bv_getmeta=getmetatable;local __bv_getgenv=getgenv;local __bv_getfenv=getfenv;local __bv_pcall=pcall;local __bv_xpcall=xpcall;local __bv_next=next;local __bv_select=select;local __bv_tostring=tostring;local __bv_rawset=rawset;local ${N.runtimeGuard}=function()local E=${V.envGuard}();if type~=__bv_type or string.byte~=__bv_byte or string.sub~=__bv_sub or string.find~=__bv_find or table.concat~=__bv_concat or math.floor~=__bv_floor or rawget~=__bv_rawget or rawset~=__bv_rawset or rawequal~=__bv_rawequal or setmetatable~=__bv_setmeta or getmetatable~=__bv_getmeta or pcall~=__bv_pcall or xpcall~=__bv_xpcall or next~=__bv_next or select~=__bv_select or tostring~=__bv_tostring then error("ByteVeil v4.6.3: runtime reference integrity failed",0)end;if getgenv~=__bv_getgenv or getfenv~=__bv_getfenv then error("ByteVeil v4.6.3: environment hook detected",0)end;if not E or E["type"]~=__bv_type or E["table"]==nil then error("ByteVeil v4.6.3: environment shape changed",0)end;if debug and debug.gethook and debug.gethook()~=nil then error("ByteVeil v4.6.3: debug hook detected",0)end end;local ${N.hookGuard}=${N.runtimeGuard}`)));
    lines.push(`local ${V.graph}=${packed.graph}`);

    const regionCount = Number(packed.regionCount || 1);
    const vocab = Array.isArray(packed.regionVocabulary) ? packed.regionVocabulary : Array.from({length: regionCount}, () => []);
    const variants = Array.isArray(packed.regionVariants) ? packed.regionVariants : Array.from({length: regionCount}, (_, i) => i % 4);
    const usedLogical = new Set();
    for (const arr of vocab) for (const x of arr || []) if (Number.isInteger(x)) usedLogical.add(x);
    if (!usedLogical.size) usedLogical.add(0);

    // v4.5.5: semantic execution is composed at runtime. There is no static
    // recipe table and no global semantic-handler table. Semantic cores remain
    // split from runtime micro-op orchestration and build/region state decides
    // the sequence used to reach them.
    const bankTable = opaque(`bank-table`, 7005);
    const recipeTable = opaque(`recipe-table`, 7006);
    if (!v455 && !v46) {
        // v4.5.4 compatibility path retained verbatim.
        for (let rid = 0; rid < regionCount; rid++) {
            const ops = (vocab[rid] || []).filter((x) => Number.isInteger(x) && opNames[x]).slice();
            if (!ops.length) ops.push(...Array.from(usedLogical).slice(0, 1));
            const localSeed = ((seed ^ ((variants[rid] + 1) * 0x45D9F3B) ^ ((rid + 1) * 0x27D4EB2F)) >>> 0);
            ops.sort((a, b) => {
                const ha = (Math.imul((a + 1) ^ localSeed, 2246822519) >>> 0);
                const hb = (Math.imul((b + 1) ^ localSeed, 2246822519) >>> 0);
                return (ha - hb) || (a - b);
            });
            const bankName = opaque(`bank:${rid}`, rid + 700);
            const recName = opaque(`rec:${rid}`, rid + 800);
            const flavor = ((Number(variants[rid] || 0) + Number(personality.recipeStyle) + (Number(packed.buildPersonality || 0) & 3)) % 3);
            const semanticSlots = {};
            const bankExpr = [];
            bankExpr.push(`function(S,I,R)S[${S.region}]=R.id;S[${S.micro}]=${N.mix}(S[${S.guard}]or 0,R.ps or 0);S[${S.guard}]=${N.bx}(S[${S.micro}],S[${S.fabric}]or 0)end`);
            bankExpr.push(`function(S,I,R)S[${S.frame}]=((S[${S.frame}]or 0)+1)%4294967296;S[${S.guard}]=${N.mix}(S[${S.guard}]or 0,S[${S.frame}])end`);
            bankExpr.push(`function(S,I,R)local Z=${N.mix}(S[${S.guard}]or 0,${rid+1}*0x9E3779B1);S[${S.guard}]=${N.xor}(Z,R.token or 0)end`);
            for (let i = 0; i < ops.length; i++) {
                const logical = ops[i];
                const name = opNames[logical];
                semanticSlots[logical] = 4 + i;
                const body = defs[name] || `S[${S.halt}]=true;return true`;
                const handlerOptions = { seed, identity: `micro-handler-${name}` };
                const fn = mode === "stack" ? stackHandler("", body, handlerOptions) : registerHandler("", body, handlerOptions);
                bankExpr.push(fn);
            }
            const endSlot = bankExpr.length + 1;
            const exitSlot = bankExpr.length + 2;
            bankExpr.push(`function(S,I,R)local F=S[${S.frame}]or 0;S[${S.frame}]=F>0 and F-1 or 0;S[${S.guard}]=${N.mix}(S[${S.guard}]or 0,(S[${S.frame}]or 0)+R.st+${rid})end`);
            bankExpr.push(`function(S,I,R)local Z=${N.mix}(S[${S.micro}]or 0,S[${S.pc}]or 0);S[${S.micro}]=Z;S[${S.guard}]=${N.xor}(S[${S.guard}]or 0,Z)end`);
            V.banks[rid] = bankName;
            V.rec[rid] = recName;
            lines.push(`local ${bankName}={${bankExpr.join(",")}}`);
            const recipeEntries = [];
            for (const logical of ops) {
                const slot = semanticSlots[logical];
                const seq = flavor === 0 ? [1, 2, slot, endSlot, exitSlot] : flavor === 1 ? [1, 3, 2, slot, endSlot, exitSlot] : [1, 2, 3, slot, 3, endSlot, exitSlot];
                recipeEntries.push(`[${logical+1}]={${seq.join(",")}}`);
            }
            lines.push(`local ${recName}={${recipeEntries.join(",")}}`);
        }
        lines.push(`local ${bankTable}={${V.banks.map((x)=>x||"{}").join(",")}}`);
        lines.push(`local ${recipeTable}={${V.rec.map((x)=>x||"{}").join(",")}}`);
    } else if (v46) {
        const architecturePlan = buildArchitecturePlan(
            vmPersonalitySeed ^ Number(personality.architectureFamily || 0),
            mode,
            opNames.length,
            regionCount,
            packed.hardeningVersion || "4.7.6"
        );
        architecturePlan.version = packed.hardeningVersion || architecturePlan.version;
        architecturePlan.family = Number(personality.architectureFamily) % 6;
        architecturePlan.secondary = Number(personality.secondaryArchitecture) % 6;
        architecturePlan.bucketCount = Math.max(2, 2 + (Number(personality.resolverFamily) % 5));
        architecturePlan.laneCount = Math.max(3, 3 + (Number(personality.stateModel) % 4));
        architecturePlan.hop = 1 + (Number(personality.commitStyle) % 11);
        architecturePlan.stateBias = Number(personality.stateSalt) >>> 0;
        architecturePlan.composition = Array.isArray(personality.microOrder) ? personality.microOrder.slice(0, 7) : architecturePlan.composition;
        architecturePlan.controlFamily = Number(personality.cffFamily || 0) % 6;
        architecturePlan.pbfFamily = Number(personality.pbfFamily || 0) % 8;
        const emitted = emitSemanticArchitecture({
            plan: architecturePlan,
            names: opNames,
            N, S, V, defs, opNames,
            usedLogical: Array.from(usedLogical),
            mode, seed: vmPersonalitySeed,
            opaque
        });
        lines.push(...emitted.lines);
        const cff = Number(personality.cffFamily || 0) % 6;
        const cffCompositions = [
            `{1,2,3,5,6}`,
            `{1,2,4,3,6,5}`,
            `{2,1,3,7,5,6}`,
            `{4,1,2,3,6,5}`,
            `{6,2,1,3,5,7}`,
            `{1,4,2,6,3,5}`
        ];
        const cffLiteral = cffCompositions[cff];
        let composeExpr;
        if (cff === 0) {
            composeExpr = `local Q=${cffLiteral};if K%3==0 then Q={2,1,3,6,5}end`;
        } else if (cff === 1) {
            composeExpr = `local Q=${cffLiteral};if K%4==0 then Q={1,2,4,3,5,6}else Q={2,1,3,6,5}end`;
        } else if (cff === 2) {
            composeExpr = `local Q;if K%5==0 then Q=${cffLiteral}else Q={2,1,7,3,6,5}end`;
        } else if (cff === 3) {
            composeExpr = `local Q=${cffLiteral};if (S[${S.region}]or 0)%2==0 then Q={4,1,2,3,5,6}else Q={1,4,2,3,6,5}end`;
        } else if (cff === 4) {
            composeExpr = `local Q;if ((K+R.id)%2)==0 then Q=${cffLiteral}else Q={6,2,1,3,7,5}end`;
        } else {
            composeExpr = `local Q=${cffLiteral};if K%7==0 then table.insert(Q,4,7)end`;
        }
        lines.push(`local ${V.compose}=function(S,I,R,L)local K=${N.mix}(S[${S.guard}]or 0,${N.xor}(R.token or 0,L or 0));${composeExpr};return Q end`);
        lines.push(`local ${V.microExec}=function(S,I,R,L,K)local Z=K or 0;if Z==3 then return ${V.vmb}(R)(S,I,L) elseif Z==1 then S[${S.region}]=R.id;S[${S.micro}]=${N.mix}(S[${S.micro}]or 0,L or 0) elseif Z==2 then S[${S.frame}]=((S[${S.frame}]or 0)+1)%4294967296 elseif Z==4 then S[${S.guard}]=${N.bx}(S[${S.guard}]or 0,${N.mix}(R.token or 0,L or 0)) elseif Z==5 then local F=S[${S.frame}]or 0;S[${S.frame}]=F>0 and F-1 or 0 elseif Z==6 then S[${S.micro}]=${N.mix}(S[${S.micro}]or 0,S[${S.pc}]or 0) elseif Z==7 then S[${S.guard}]=${N.mix}(S[${S.guard}]or 0,R.ps or 0) end end`);
    } else {
        const coreNames = [];
        for (let logical = 0; logical < opNames.length; logical++) {
            const name = opNames[logical];
            const ident = opaque(`semantic-core:${logical}`, logical + 0x1700);
            const body = defs[name] || `S[${S.halt}]=true;return true`;
            const handlerOptions = { seed, identity: `semantic-handler-${name}` };
            const fn = mode === "stack" ? stackHandler("", body, handlerOptions) : registerHandler("", body, handlerOptions);
            lines.push(`local ${ident}=${fn}`);
            coreNames.push(ident);
        }

        const dispatchStyle = Number(personality.dispatchStyle) % (v468 ? 8 : 4);
        const vmDispatchTopologies = ["flat-chain", "split-chain", "repeat-local", "loop-chain", "handler-table", "residue-buckets", "balanced-tree", "affine-key"];
        personality.effectiveDispatchTopology = vmDispatchTopologies[dispatchStyle];
        const dispatchParts = [];
        if (dispatchStyle === 0) {
            for (let logical = 0; logical < coreNames.length; logical++) {
                dispatchParts.push(`${logical === 0 ? "if" : "elseif"} L==${logical} then return ${coreNames[logical]}(S,I,R)`);
            }
            dispatchParts.push(`else error("ByteVeil v4.6.3: semantic opcode",0) end`);
        } else if (dispatchStyle === 1) {
            const mid = Math.max(1, Math.floor(coreNames.length / 2));
            const left = coreNames.slice(0, mid).map((fn, logical) => `${logical === 0 ? "if" : "elseif"} L==${logical} then return ${fn}(S,I,R)`).join(" ");
            const right = coreNames.slice(mid).map((fn, k) => `${k === 0 ? "if" : "elseif"} L==${mid+k} then return ${fn}(S,I,R)`).join(" ");
            dispatchParts.push(`if L<${mid} then if ${left.slice(3)} else error("ByteVeil v4.6.3: semantic opcode",0) end else if ${right.slice(3)} else error("ByteVeil v4.6.3: semantic opcode",0) end end`);
        } else if (dispatchStyle === 2) {
            const rows = coreNames.map((fn, logical) => `local K${logical}=${fn};if L==${logical} then return K${logical}(S,I,R) end`).join(" ");
            dispatchParts.push(`repeat ${rows} break until true;error("ByteVeil v4.6.3: semantic opcode",0)`);
        } else if (dispatchStyle === 3) {
            const rows = coreNames.map((fn, logical) => `if L==${logical} then local K=${fn};local Z=K(S,I,R);return Z end`).join(" ");
            dispatchParts.push(`while true do ${rows} error("ByteVeil v4.6.3: semantic opcode",0);break end`);
        } else if (dispatchStyle === 4) {
            const entries = coreNames.map((fn, logical) => `[${logical}]=${fn}`).join(",");
            dispatchParts.push(`local H={${entries}};local F=H[L];if not F then error("ByteVeil v4.6.8: semantic opcode",0)end;return F(S,I,R)`);
        } else if (dispatchStyle === 5) {
            const bucketBranches = [0,1,2].map((bucket) => {
                const rows = coreNames.map((fn, logical) => ({fn, logical})).filter((entry) => entry.logical % 3 === bucket);
                const tests = rows.map((entry, index) => `${index === 0 ? "if" : "elseif"} L==${entry.logical} then return ${entry.fn}(S,I,R)`).join(" ");
                return `${bucket === 0 ? "if" : "elseif"} B==${bucket} then ${tests || "if false then return nil"} else error("ByteVeil v4.6.8: semantic opcode",0) end`;
            });
            dispatchParts.push(`local B=L%3;${bucketBranches.join(" ")} end`);
        } else if (dispatchStyle === 6) {
            const treeDispatch = (start, end) => {
                if (start >= end) return `error("ByteVeil v4.6.8: semantic opcode",0)`;
                if (end - start === 1) return `if L==${start} then return ${coreNames[start]}(S,I,R) else error("ByteVeil v4.6.8: semantic opcode",0) end`;
                const mid = Math.floor((start + end) / 2);
                return `if L<${mid} then ${treeDispatch(start, mid)} else ${treeDispatch(mid, end)} end`;
            };
            dispatchParts.push(treeDispatch(0, coreNames.length));
        } else {
            const modulus = Math.max(7, coreNames.length * 2 + 1);
            const gcd = (a, b) => { while (b) [a, b] = [b, a % b]; return a; };
            let multiplier = 3 + (Number(personality.semanticSalt) % Math.max(1, modulus - 3));
            while (gcd(multiplier, modulus) !== 1) multiplier = (multiplier + 1) % modulus || 1;
            const offset = Number(personality.representationSalt) % modulus;
            const rows = coreNames.map((fn, logical) => `${logical === 0 ? "if" : "elseif"} K==${(logical * multiplier + offset) % modulus} then return ${fn}(S,I,R)`);
            dispatchParts.push(`local K=(L*${multiplier}+${offset})%${modulus};${rows.join(" ")} else error("ByteVeil v4.6.8: semantic opcode",0) end`);
        }
        lines.push(`local ${V.coreDispatch}=function(S,I,R,L)${dispatchParts.join(" ")} end`);
        lines.push(`local ${V.regionFlavor}=function(S,R,K)local Z=${N.mix}(S[${S.guard}]or 0,${N.xor}(R.ps or 0,K or 0));S[${S.micro}]=${N.bx}(S[${S.micro}]or 0,Z);S[${S.guard}]=${N.mix}(Z,R.token or 0)end`);
        lines.push(`local ${V.microExec}=function(S,I,R,L,K)local A=L;local Q=I;local T=R;if K==1 then S[${S.region}]=R.id;S[${S.micro}]=${N.mix}(S[${S.micro}]or 0,${N.xor}(R.id+1,A or 0)) elseif K==2 then S[${S.frame}]=((S[${S.frame}]or 0)+1)%4294967296;S[${S.guard}]=${N.mix}(S[${S.guard}]or 0,S[${S.frame}]) elseif K==3 then return ${V.coreDispatch}(S,Q,T,A) elseif K==4 then ${V.regionFlavor}(S,T,S[${S.micro}]or 0) elseif K==5 then local F=S[${S.frame}]or 0;S[${S.frame}]=F>0 and F-1 or 0;S[${S.guard}]=${N.mix}(S[${S.guard}]or 0,(S[${S.frame}]or 0)+R.id) elseif K==6 then local M=${N.mix}(S[${S.micro}]or 0,S[${S.pc}]or 0);S[${S.micro}]=M;S[${S.guard}]=${N.bx}(S[${S.guard}]or 0,M) elseif K==7 then S[${S.guard}]=${N.bx}(S[${S.guard}]or 0,${N.mix}(R.token or 0,A)) end end`);

        const recipeStyle = Number(personality.recipeStyle) % 4;
        if (recipeStyle === 0) {
            lines.push(`local ${V.compose}=function(S,I,R,L)local K=${N.mix}(S[${S.guard}]or 0,${N.bx}(R.token or 0,L));local Q={1,2,3,5,6};if K%5==0 then Q={1,3,4,5,6} elseif K%3==0 then Q={2,1,3,6,5} end;return Q end`);
        } else if (recipeStyle === 1) {
            lines.push(`local ${V.compose}=function(S,I,R,L)local K=${N.mix}(S[${S.fabric}]or 0,${N.bx}(R.ps or 0,L));local Q;if K%4==0 then Q={2,3,4,6,5} elseif K%4==1 then Q={1,2,7,3,5,6} else Q={1,4,2,3,6,5} end;return Q end`);
        } else if (recipeStyle === 2) {
            lines.push(`local ${V.compose}=function(S,I,R,L)local K=${N.mix}(S[${S.micro}]or 0,${N.xor}(R.token or 0,L));local Q={};Q[1]=((K%2)==0)and 1 or 2;Q[2]=((K%3)==0)and 4 or 2;Q[3]=3;Q[4]=((K%5)==0)and 7 or 5;Q[5]=6;return Q end`);
        } else {
            lines.push(`local ${V.compose}=function(S,I,R,L)local K=${N.mix}(S[${S.guard}]or 0,L+R.id);local Q={2,1,3,5,6};if K%7==0 then table.insert(Q,3,4) elseif K%11==0 then Q={1,4,3,7,5,6} end;return Q end`);
        }
        if (!v455) {
            lines.push(`local ${bankTable}={}`);
            lines.push(`local ${recipeTable}={}`);
        } else {
            // Kept deliberately out of the runtime source: v4.5.5 builds VM-B
            // closures per region at execution time instead of shipping a complete
            // recipe/handler bank. The identifiers remain generator-local only.
        }
    }
    lines.push(`local ${V.personality}=${Number(packed.buildPersonality || 0) >>> 0}`);
    if (v455 || v46) {
        lines.push(`local ${V.packInstruction}=function(Q,RID,R,G)local F=(((G and G.irep and G.irep[RID+1]or 0)+((G and G.crep and G.crep[RID+1]or 0)*3)+((G and G.cfp and G.cfp[RID+1]or 0)*5)+((G and G.morph and G.morph[RID+1]or 0)*7)+((G and G.pbf or 0)*11)+((G and G.cff or 0)*13)+((G and G.envf or 0)*17)+((R and R.il or 0)*19)+((Q[1]or 0)*23)+((RID or 0)*29))%12);local t=F%12;if t==0 then return{t=0,o=Q[1],a=(function(A)local T={};for J=2,#A do T[#T+1]=A[J]end;return T end)(Q),r=RID}elseif t==1 then return{t=1,r=RID,q=Q}elseif t==2 then local A={};for J=2,#Q do A[#A+1]=Q[J]end;return{t=2,r=RID,o=Q[1],b=A}elseif t==3 then return{t=3,r=RID,v=Q}elseif t==4 then return{t=4,r=RID,x=Q[1],y=Q[2],z=Q[3],a=(function(A)local T={};for J=4,#A do T[#T+1]=A[J]end;return T end)(Q)}elseif t==5 then local A={};for J=2,#Q do A[#A+1]=Q[J]end;return{t=5,k=RID,p=A,o=Q[1]}elseif t==6 then local A={};for J=2,#Q do A[#A+1]=Q[J]end;return{t=6,r=RID,h=(Q[1]or 0)%16,l=math.floor((Q[1]or 0)/16),a=A}elseif t==7 then return{t=7,r=RID,m={Q[1],Q[2],Q[3]},q=(function(A)local T={};for J=4,#A do T[#T+1]=A[J]end;return T end)(Q)}elseif t==8 then local Z={t=8,r=RID,q=Q};return function()return Z end elseif t==9 then return{t=9,r=RID,u=(Q[1]or 0),v=(Q[2]or 0),w=(Q[3]or 0),a=(function(A)local T={};for J=4,#A do T[#T+1]=A[J]end;return T end)(Q)}elseif t==10 then local A={};for J=2,#Q do A[#A+1]=Q[J]end;local H={o=Q[1],n=nil};for J=#A,1,-1 do H.n={v=A[J],n=H.n} end;return{t=10,r=RID,h=H}elseif t==11 then local D={};for J=1,#Q do local K=J*2+((J==1)and 0 or 1);D[K]=Q[J]end;return{t=11,r=RID,d=D,c=#Q} end;return{t=t,r=RID,q=Q,cf=((G and G.cfp and G.cfp[RID+1])or R.cf),cr=((G and G.crep and G.crep[RID+1])or R.cr)} end`);
        if (v471) {
        // v4.7.1 splits normalization across even/odd representation families.
        // Operands remain canonical at the VM semantic boundary for correctness.
        lines.push(`local ${V.unpackInstruction}A=function(F,t)if t==0 then local Q={F.o};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==2 then local Q={F.o};for J=1,#(F.b or {})do Q[#Q+1]=F.b[J]end;return Q,F.r elseif t==4 then local Q={F.x,F.y,F.z};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==6 then local Q={((F.h or 0)%16)+math.floor(F.l or 0)*16};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==8 then return F.q,F.r elseif t==10 then local Q={F.h and F.h.o or 0};local H=F.h and F.h.n;while H do Q[#Q+1]=H.v;H=H.n end;return Q,F.r end;return nil,nil end;local ${V.unpackInstruction}B=function(F,t)if t==1 then return F.q,F.r elseif t==3 then return F.v,F.r elseif t==5 then local Q={F.o};for J=1,#(F.p or {})do Q[#Q+1]=F.p[J]end;return Q,F.k elseif t==7 then local Q={F.m and F.m[1]or 0,F.m and F.m[2]or 0,F.m and F.m[3]or 0};for J=1,#(F.q or {})do Q[#Q+1]=F.q[J]end;return Q,F.r elseif t==9 then local Q={F.u or 0,F.v or 0,F.w or 0};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==11 then local Q={};local D=F.d or {};for J=1,(F.c or 0)do local K=J*2+((J==1)and 0 or 1);Q[#Q+1]=D[K]end;return Q,F.r end;return nil,nil end;local ${V.unpackInstruction}=function(I)local F=I;if type(F)=="function"then local A,B=F();if type(A)=="table"and B~=nil then return A,B end;F=A end;if type(F)~="table"then return nil,nil end;local t=F.t;if type(t)=="number"then if t%2==0 then return ${V.unpackInstruction}A(F,t)else return ${V.unpackInstruction}B(F,t)end end;if F.q then return F.q,F.r end;return nil,nil end`);
    } else {
    lines.push(`local ${V.unpackInstruction}=function(I)local F=I;if type(F)=="function"then local A,B=F();if type(A)=="table"and B~=nil then return A,B end;F=A end;if type(F)~="table"then return nil,nil end;local t=F.t;if t==0 then local Q={F.o};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==1 then return F.q,F.r elseif t==2 then local Q={F.o};for J=1,#(F.b or {})do Q[#Q+1]=F.b[J]end;return Q,F.r elseif t==3 then return F.v,F.r elseif t==4 then local Q={F.x,F.y,F.z};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==5 then local Q={F.o};for J=1,#(F.p or {})do Q[#Q+1]=F.p[J]end;return Q,F.k elseif t==6 then local Q={((F.h or 0)%16)+math.floor(F.l or 0)*16};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==7 then local Q={F.m and F.m[1]or 0,F.m and F.m[2]or 0,F.m and F.m[3]or 0};for J=1,#(F.q or {})do Q[#Q+1]=F.q[J]end;return Q,F.r elseif t==9 then local Q={F.u or 0,F.v or 0,F.w or 0};for J=1,#(F.a or {})do Q[#Q+1]=F.a[J]end;return Q,F.r elseif t==10 then local Q={F.h and F.h.o or 0};local H=F.h and F.h.n;while H do Q[#Q+1]=H.v;H=H.n end;return Q,F.r elseif t==11 then local Q={};local D=F.d or {};for J=1,(F.c or 0)do local K=J*2+((J==1)and 0 or 1);Q[#Q+1]=D[K]end;return Q,F.r elseif t==8 then return F.q,F.r elseif F.q then return F.q,F.r end;return nil,nil end`);
    }
        lines.push(`local ${V.constantMorph}=function(F,J)return function(ST)local V0=F(ST);local K0=(${N.bx}((ST[${S.region}]or 0)+J+${Number(personality.id)},0x${(Number(personality.semanticSalt)>>>0).toString(16)})%6);if K0==0 then return{[0]=0,[1]=V0,[2]=0x${(Number(personality.representationSalt)>>>0).toString(16)}}elseif K0==1 then return{a=V0,b=K0,m=0x${(Number(personality.stateSalt)>>>0).toString(16)}}elseif K0==2 then return{q={K0,V0},z=0x${(Number(personality.topologySalt)>>>0).toString(16)}}elseif K0==3 then return{r=K0,s=V0,t=0x${(Number(personality.semanticSalt^0x5A5A5A5A)>>>0).toString(16)}}elseif K0==4 then return{p=V0,k=K0,u=0x${(Number(personality.representationSalt^0xA5A5A5A5)>>>0).toString(16)}}else return{{K0,V0},d=0x${(Number(personality.stateSalt^0xC3C3C3C3)>>>0).toString(16)}}end end end`);
    }
    const representationDecode = v46 ? opaque("representation-decode", 61) : null;
    if (v46) {
        lines.push(buildLuaInverseSource({ functionName: representationDecode, mixName: N.mix, xorName: N.xor, mulName: N.mul }));
        lines.push(`local ${V.advance}=function(S,PC,R,I,G)local C=((tonumber(G and G.cff)or 0)+(tonumber(R and R.cf)or 0)+(tonumber(R and R.il)or 0)+(tonumber(G and G.pbf)or 0))%6;local Q=PC+1;if C==0 then return Q elseif C==1 then local F=function(X)return X end;return F(Q) elseif C==2 then local X=Q;for J=1,1 do X=X end;return X elseif C==3 then local X;if (tonumber(R and R.id)or 0)%2==0 then X=function(Y)return Y end else X=function(Y)return Y end end;return X(Q) elseif C==4 then local X=Q;repeat break until true;return X else local X=Q;if S then X=X end;return X end end`);
    }

    // Distributed region reconstruction. v4.7.5/v4.7.6 use eight reversible region lanes and stores
    // validated regions in native Luau buffers when the runtime supports that API.
    const v475ExtraInverse = (v475 || v476) ? `local extra={mat(S0,0xF1),mat(S0,0xA3),mat(S0,0x6D),mat(S0,0x91)};for I=1,#E do local P=I-1;local V=(E[I]+byteMask(extra[4],P,7))%256;V=${N.bx}(V,byteMask(extra[3],P,6));V=(V-byteMask(extra[2],P,5)+256)%256;E[I]=${N.bx}(V,byteMask(extra[1],P,4))end;` : '';
    const v475GraphCacheInit = (v475 || v476) ? 'local nativeBuffer=(type(buffer)=="table" and type(buffer.create)=="function" and type(buffer.readu8)=="function" and type(buffer.writeu8)=="function") and buffer or nil;local bufferCreate=nativeBuffer and nativeBuffer.create;local bufferReadU8=nativeBuffer and nativeBuffer.readu8;local bufferWriteU8=nativeBuffer and nativeBuffer.writeu8;local bufferFlags={};' : '';
    const v475CacheStore = (v475 || v476) ? 'local saved=P;local useBuffer=false;if nativeBuffer then local B0=bufferCreate(#P);for J=1,#P do bufferWriteU8(B0,J-1,P[J])end;saved=B0;useBuffer=true end;cache[ID]=saved;bufferFlags[ID]=useBuffer;' : 'cache[ID]=P;';
    const v475CacheDrop = (v475 || v476) ? 'cache[E]=nil;bufferFlags[E]=nil;' : 'cache[E]=nil;';
    const v475Reader = (v475 || v476) ? 'if bufferFlags[RID] then return bufferReadU8(B,P-R.start)end;' : '';
    // VeilStr-v1 runtime helpers: only emitted when the payload actually stores tag-85
    // constants, because the region key they use is the build's material root.
    const veilStr = packed.stringCipher?.applied === true
        ? { key: opaque("veil-str-key", 62), mask: opaque("veil-str-mask", 63), fold: opaque("veil-str-fold", 64) }
        : null;
    // One fold, two consumers. The region seed and the string-cipher root are keyed by the
    // same latch expression, so it is computed once per runtime into a local instead of
    // duplicated in the body: a duplicated fold would be two patch sites for the same secret
    // and a fold re-run for every region resolution.
    const materialRootLocal = veilStr ? opaque("material-root", 65) : null;
    const materialRootRead = materialRootLocal || materialRoot;
    lines.push(`local ${V.graph}Runtime=nil`);
    lines.push(`${V.graph}Runtime=function()${guardKeyHolder ? `local ${guardKeyHolder}=${antiBundle.helpers.hook.names.guard}();` : ""}local G=${V.graph};${v479DescriptorInit}local byId={};local starts={};local cache={};local states={};${v475GraphCacheInit}local active={};local recent={};local resolveRegion;local RROOT=${N.bx}(${N.bx}(G.shares[1],G.shares[2]),${N.bx}(G.shares[3],G.shares[4]));${materialRootLocal ? `local ${materialRootLocal}=${materialRoot};` : ""}local function dep0(R)local D=0x13579BDF;for I=1,#R.dep do local Q=R.dep[I];local _,Z=resolveRegion(Q);if not Z then error("ByteVeil v4.6.3: dependency state",0)end;D=${N.mix}(D,${N.bx}(Z,byId[Q].tok))end;return D end;local function dep1(R)local D=0x13579BDF;for I=#R.dep,1,-1 do local Q=R.dep[I];local _,Z=resolveRegion(Q);if not Z then error("ByteVeil v4.6.3: dependency state",0)end;D=${N.mix}(D,${N.bx}(Z,byId[Q].tok))end;return D end;local function dep2(R)local D=0x13579BDF;local Qs={};for I=1,#R.dep do Qs[I]=R.dep[I] end;table.sort(Qs,function(A,B)return (byId[A].tok or 0)>(byId[B].tok or 0) end);for I=1,#Qs do local Q=Qs[I];local _,Z=resolveRegion(Q);if not Z then error("ByteVeil v4.6.3: dependency state",0)end;D=${N.mix}(D,${N.bx}(Z,byId[Q].tok))end;return D end;local function dep3(R)local D=0x2468ACE0;for I=#R.dep,1,-1 do local Q=R.dep[I];local _,Z=resolveRegion(Q);if not Z then error("ByteVeil v4.6.3: dependency state",0)end;D=${N.mix}(D,${N.bx}(Z,byId[Q].tok))end;return D end;local function rs(R,D)local S0=${N.mix}(${materialRootRead},${N.xor}(R.tok,${N.mul}(R.id+1,0x45D9F3B)));S0=${N.mix}(S0,${N.xor}(D,0x9E3779B9));S0=${N.mix}(S0,${N.xor}(0xB17E4A31,${N.mul}(R.id+7,0x27D4EB2F)));return ${N.mix}(S0,${N.bx}(R.rf or G.rf or 0,0x4555A11C)) end;local function mat(B,D)local modeSalt=${modeFlag===1?"0x13579BDF":"0x2468ACE0"};local depth=${Number(strength)>=10000?96:Number(strength)>=8000?64:Number(strength)>=3500?40:24};local stages=${Number(strength)>=8000?4:3};local X0=${N.mix}(B,${N.xor}(D,${N.xor}(modeSalt,${N.xor}(depth,stages*2048))));X0=${N.mix}(X0,${N.mul}(${strength},0x45D9F3B));X0=${N.mix}(X0,${N.xor}(D,0x9E3779B9));return ${N.xor}(X0,${N.mul}(D,2654435761)) end;local function shardMask(K,Q,I,L)local D0=${N.bx}(${N.bx}(${N.mul}(Q+1,0x45D9F3B),${N.mul}(I+1,0x27D4EB2F)),${N.mul}(L+1,0x9E3779B1));local X0=${N.bx}(K,${N.bx}(D0,0xB17E4A31));X0=${N.mul}(${N.bx}(X0,math.floor(X0/65536)),2246822519);X0=${N.mul}(${N.bx}(X0,math.floor(X0/8192)),3266489917);return ${N.bx}(X0,math.floor(X0/65536))%256 end;local function unshard(R)local O={};for I=1,#R.ord do local Q=I-1;local B=${packedShardRead};local L=(R.sl and R.sl[I])or#B;local lane=Q%4;for J=1,L do local P=J-1;local A=shardMask(R.sm,Q,P,lane);local T=shardMask(${N.bx}(R.sm,0xC0FFEE11),Q,P,lane+1);local U=shardMask(${N.bx}(R.sm,0x7A51BEEF),Q,P,lane+2);local V=${N.bx}(B[J]or 0,U);V=(V-T+256)%256;O[#O+1]=${N.bx}(V,A)end end;return O end;local function invRegion(B,S0,rv,vs)local L=#B;if L<=1 then return B end;if rv==0 then return B end;if rv==1 then local O={};for I=L,1,-1 do O[#O+1]=B[I]end;return O elseif rv==2 then local O={};local sh=vs%L;for I=1,L do O[I]=B[((I-1-sh+L)%L)+1]end;return O else local step=vs%L;if step%2==0 then step=step+1 end;if step==0 then step=1 end;local function gcd(A,B)local X,Y=A,B;while Y~=0 do local T=X%Y;X=Y;Y=T end;return X end;while gcd(step,L)~=1 do step=(step+2)%L;if step==0 then step=1 end end;local off=(${N.xor}(vs,0x94D049BB)%L);local O={};for I=0,L-1 do O[(off+I*step)%L+1]=B[I+1]end;return O end end;${v479 ? `local function decodeRegionCodec(B,R,S0)local K=${N.mix}(S0,${N.bx}(R.tok or 0,0xA5D3C7E9));K=${N.mix}(K,${N.bx}(R.rs or 0,0x9E3779B9));K=${N.mix}(K,0xD3C0DEC0);local ST=${N.mix}(${N.bx}(K,0xA5D3C7E9),0);local O={};for I=1,#B do ST=(ST+0x9E3779B9+(I-1))%4294967296;ST=${N.mix}(ST,0);local M=${N.bx}(${N.bx}(${N.bx}(ST,math.floor(ST/256)),math.floor(ST/65536)),math.floor(ST/16777216))%256;O[I]=${N.bx}(B[I]or 0,M)end;return O end;` : ``}local function byteMask(K,I,L)local D0=(0x51ED2708+${N.mul}(L+1,0x45D9F3B)+${N.mul}(I+1,0x27D4EB2F))%4294967296;return ${N.mix}(K,D0)%256 end;local function inverse(B,R,S0)local E=invRegion(B,S0,R.rv,R.rs);${v475ExtraInverse}local domains={mat(S0,0xB3),mat(S0,0xC7),mat(S0,0xD9),mat(S0,0xEB)};local O={};for I=1,#E do local P=I-1;local V=(E[I]+byteMask(domains[4],P,3))%256;V=${N.bx}(V,byteMask(domains[3],P,2));V=(V-byteMask(domains[2],P,1)+256)%256;V=${N.bx}(V,byteMask(domains[1],P,0));O[I]=V end;${v46 ? `if R.rep~=nil and R.rps~=nil then O=${representationDecode}(O,R.rep,R.rps) end;` : ``}return O end;local function chk(B)local H=17;for I=1,#B do H=(H*65599+B[I]+1)%2147483647 end;return H end;local depFns={dep0,dep1,dep2,dep3};local resolvers={};for IDX=1,4 do resolvers[IDX]=function(R)local D=depFns[IDX](R);local S0=rs(R,D);local B=unshard(R);${v479 ? "B=decodeRegionCodec(B,R,S0);" : ""}local P=inverse(B,R,S0);return P,S0 end end;resolveRegion=function(ID)local C=cache[ID];if C then return C,states[ID] end;if active[ID] then error("ByteVeil v4.6.3: graph cycle",0)end;local R=byId[ID];if not R then error("ByteVeil v4.6.3: region missing",0)end;active[ID]=true;local fn=resolvers[(((R.rv or 0)+(R.rf or 0))%4)+1]or resolvers[1];local P,S0=fn(R);if #P~=R.len then error("ByteVeil v4.6.3: region length",0)end;local H=chk(P);local expect=${N.mix}(S0,${N.xor}(H,${N.xor}(R.len,R.tok)));if H~=R.chk or expect~=R.st then error("ByteVeil v4.6: region integrity",0)end;${v475CacheStore}states[ID]=expect;if ${(v455 || v46) ? "true" : "false"} then recent[#recent+1]=ID;if #recent>2 then local E=table.remove(recent,1);if E~=ID then ${v475CacheDrop}end end end;active[ID]=nil;return cache[ID],expect end;for I=1,#G.regions do local R=G.regions[I];byId[R.id]=R;starts[#starts+1]=R.id end;if #starts~=G.n then error("ByteVeil v4.6.3: graph cardinality",0)end;table.sort(starts,function(A,B)return byId[A].start<byId[B].start end);for I=1,#starts do local R=byId[starts[I]];if R.start<0 or R.len<=0 then error("ByteVeil v4.6.3: invalid region",0)end;if I>1 then local P=byId[starts[I-1]];if P.start+P.len~=R.start then error("ByteVeil v4.6.3: graph gap",0)end end end;local function regionFor(P)local lo,hi=1,#starts;while lo<=hi do local M=math.floor((lo+hi)/2);local R=byId[starts[M]];if P<R.start then hi=M-1 elseif P>=R.start+R.len then lo=M+1 else return R.id end end;error("ByteVeil v4.6.3: byte address",0)end;local readers={};for I=1,#starts do local RID=starts[I];local R=byId[RID];readers[RID]=function(P)local B=resolveRegion(RID);${v475Reader}return B[P-R.start+1]end end;G.byId=byId;G.regionFor=regionFor;G.readers=readers;G.rootSeed=RROOT;${veilStr ? `G.materialRoot=${materialRootRead};` : ""}G.personality=${N.mix}(G.personality or ${Number(packed.buildPersonality || 0)},RROOT);if G.n~=#starts or G.v~=${v46 ? 4 : (v455 ? 3 : 2)} then error("ByteVeil v4.6.3: graph version",0)end;return G end`);
    const readFn = opaque("reader", 60);
    const asciiLookupExpr = v580 ? `((B-32)*${asciiStep}+${asciiOff})%95+1` : `B-31`;
    lines.push(`local ${readFn}=function(G)local P0=0;local A=${ascii};local function RAt(P)local RID=G.regionFor(P);local F=G.readers and G.readers[RID];if not F then error("ByteVeil v4.6.3: region reader",0)end;return F(P)end;local function UAt(P)local V0=0;local M0=1;while true do local B=RAt(P);P=P+1;if B==nil then error("ByteVeil v4.6.3: truncated IR",0)end;V0=V0+(B%128)*M0;if B<128 then return V0,P end;M0=M0*128;if M0>9007199254740992 then error("ByteVeil v4.6.3: varint overflow",0)end end end;local function RU()local V0;V0,P0=UAt(P0);return V0 end;local function ch(B)if B>=32 and B<=126 then local Z0=${asciiLookupExpr};return string.sub(A,Z0,Z0)end;if B==0 then return "\\0"elseif B==7 then return "\\a"elseif B==8 then return "\\b"elseif B==9 then return "\\t"elseif B==10 then return "\\n"elseif B==11 then return "\\v"elseif B==12 then return "\\f"elseif B==13 then return "\\r"end;if B>=0 and B<=255 then return string["ch".."ar"](B)end;error("ByteVeil v4.6.6: invalid string byte",0)end;local function readString(S,L)local T={};for I=0,L-1 do T[I+1]=ch(RAt(S+I))end;return table.concat(T)end;${veilStr ? `${buildVeilStrHelpers({ keyName: veilStr.key, maskName: veilStr.mask, foldName: veilStr.fold, mixName: N.mix, xorName: N.xor, mulName: N.mul })};` : ""}local chunkSeq=0;local function chunkRead()chunkSeq=chunkSeq+1;${veilStr ? "local QS=chunkSeq;" : ""}local X={};local KC=RU();X[${C.consts}]={};local K0=X[${C.consts}];for I=1,KC do local T=RAt(P0);P0=P0+1;local RID=G.regionFor(P0-1);if T==83 then local L=RU();local S0=P0;P0=P0+L;K0[I]=function(STATE)local _=STATE and STATE[${S.region}]or RID;if type(_)=="number" then return readString(S0,L) end;error("ByteVeil v4.6.3: constant state",0)end ${veilStr ? `elseif T==85 then local L=RU();local HC=RAt(P0);P0=P0+1;local S0=P0;P0=P0+L;K0[I]=function(STATE)local _=STATE and STATE[${S.region}]or RID;if type(_)~="number"then error("ByteVeil v4.6.3: constant state",0)end;local MR=G.materialRoot or 0;local CK0=${veilStr.key}(MR,QS,I-1);local BB={};for J=0,L-1 do local E=RAt(S0+J);local V=(E+${veilStr.mask}(CK0,J,2))%256;V=${N.bx}(V,${veilStr.mask}(CK0,J,1));BB[J+1]=(V-${veilStr.mask}(CK0,J,0)+256)%256 end;if ${veilStr.fold}(BB)~=HC then G.materialRoot=0;for Z=1,KC do K0[Z]=nil end;error("ByteVeil v4.6.3: constant state",0)end;local OO={};for J=1,L do OO[J]=ch(BB[J])end;return table.concat(OO) end ` : ""}elseif T==78 then local K1=RAt(P0);P0=P0+1;if K1==0 then local S0=P0;local _,P1=UAt(P0);P0=P1;K0[I]=function(STATE)local V0,P2=UAt(S0);if not STATE or type(STATE[${S.region}])~="number"then error("ByteVeil v4.6.3: constant state",0)end;return(V0%2==0)and math.floor(V0/2)or-math.floor((V0+1)/2)end else local L=RU();local S0=P0;P0=P0+L;K0[I]=function(STATE)local T0={};for J=0,L-1 do T0[J+1]=ch(RAt(S0+J))end;if not STATE or type(STATE[${S.region}])~="number"then error("ByteVeil v4.6.3: constant state",0)end;return tonumber(table.concat(T0))end end elseif T==84 then K0[I]=function(STATE)return true end elseif T==70 then K0[I]=function(STATE)return false end elseif T==90 then K0[I]=function(STATE)return nil end elseif T==67 then local Child=chunkRead();K0[I]=function(STATE)return Child end else error("ByteVeil v4.6.3: constant tag",0)end end;local PC=RU();X[${C.params}]={};for I=1,PC do local L=RU();local S0=P0;P0=P0+L;local RID0=G.regionFor(S0);X[${C.params}][I]=function(STATE)local _=STATE and STATE[${S.region}]or RID0;if type(_)~="number"then error("ByteVeil v4.6.3: parameter state",0)end;return readString(S0,L)end end;local V0=RAt(P0);P0=P0+1;X[${C.vararg}]=V0==1;local IC=RU();X[${C.code}]={};for I=1,IC do local AC=RU();local S0=P0;for J=1,AC do local T=RAt(P0);P0=P0+1;if T==0 then local _,P1=UAt(P0);P0=P1 else local L=RU();P0=P0+L end end;local RID0=G.regionFor(S0);X[${C.code}][I]=function()local Q={};local P=S0;for J=1,AC do local T=RAt(P);P=P+1;if T==0 then local V1;V1,P=UAt(P);Q[J]=(V1%2==0)and math.floor(V1/2)or-math.floor((V1+1)/2)else local L,P1=UAt(P);P=P1+L;local A={};for W=0,L-1 do A[W+1]=ch(RAt(P1+W))end;Q[J]=tonumber(table.concat(A))end end;${v46 ? `return ${V.packInstruction}(Q,RID0,G.byId and G.byId[RID0],G)` : `Q[AC+1]=RID0;return Q`} end end;return X end;return chunkRead()end`);

    const personalitySeed = Number(packed.buildPersonality || seed) >>> 0;
    lines.push(`local ${V.state}=function(E,V0,P,G0,F0)local S0={};S0[${S.pc}]=1;S0[${S.locals}]={};S0[${S.localSet}]={};S0[${S.parent}]=P;S0[${S.env}]=E;S0[${S.consts}]=V0;S0[${S.code}]=nil;S0[${S.halt}]=false;S0[${S.ret}]={};S0[${S.varargs}]={};S0[${S.guard}]=(${N.xor}(G0 or 0,0x${personalitySeed.toString(16)}))%4294967296;S0[${S.fabric}]=(${N.mix}(F0 or G0 or 0,0x${(personalitySeed ^ 0xA7F041)>>>0}))%4294967296;S0[${S.frame}]=0;S0[${S.region}]=0;S0[${S.micro}]=0;S0[${S.microRoutes}]={};${mode === "stack" ? `S0[${S.sp}]=0;S0[${S.stack}]={};` : `S0[${S.reg}]={};`}S0[${S.iter}]={};return S0 end`);

    if (v476) lines.push(v478 ? `local ${V.shadowStep},${V.shadowInit},${V.shadowProof}` : `local ${V.shadowStep},${V.shadowInit}`);
    const runName = N.run;
    lines.push(`local ${V.vma}=function(S0,I,R)local RID=R.id;local base=${N.mix}(S0[${S.guard}]or 0,${N.xor}(R.ps or 0,R.token or 0));base=${N.mix}(base,${N.xor}(S0[${S.fabric}]or 0,${N.mul}(S0[${S.pc}]or 0,RID+1)));S0[${S.micro}]=base;local flavor=(R.rv or 0)%4;return base,flavor end`);
    if (!v455 && !v46) {
        lines.push(`local ${V.vmb}=function(S0,R,base)local B;local rec;local ID=(R.id or 0)+1;B=${bankTable}[ID];rec=${recipeTable}[ID];if not B or not rec then error("ByteVeil v4.6.3: region VM missing",0)end;local A={};for I=1,#B do A[I]=I end;local S1=${N.mix}(base,${N.xor}(R.token or 0,${N.xor}(S0[${S.guard}]or 0,R.ps or 0)));for I=#A,2,-1 do S1=${N.mix}(S1,I+R.id);local J=(S1%I)+1;A[I],A[J]=A[J],A[I] end;local bank={};local inv={};for I=1,#A do bank[I]=B[A[I]];inv[A[I]]=I end;return bank,inv,rec end`);
        lines.push(`${N.run}=function(X,P,...)local E=P and P[${S.env}]or ${V.envGuard}();local Q=${V.state}(E,X[${C.consts}],P,X[${C.fabric}]or 0,${V.personality});Q[${S.code}]=X[${C.code}];local PC0=#(X[${C.params}]or{});Q[${S.varargs}]={select(PC0+1,...)};Q[${S.varargs}].n=math.max(0,select("#",...)-PC0);for I=1,PC0 do local K0=X[${C.params}][I];local K=type(K0)=="function"and K0(Q)or K0;X[${C.params}][I]=K;Q[${S.locals}][K]=select(I,...) ;Q[${S.localSet}][K]=true end;while not Q[${S.halt}] do local PC=Q[${S.pc}];local F0=Q[${S.code}][PC];local I=F0;if type(F0)=="function"then I=F0();Q[${S.code}][PC]=I end;if not I then Q[${S.halt}]=true;break end;local RID=I[#I];local O=I[1]or 0;local G=${V.graph};local R=G.byId and G.byId[RID];if not R then error("ByteVeil v4.6.3: runtime region missing",0)end;local base=${V.vma}(Q,I,R);local bank,inv,rec=${V.vmb}(Q,R,base);local logical=R.route and R.route[O+1];if logical==nil then error("ByteVeil v4.6.3: region opcode route",0)end;local recipe=rec[logical+1];if not recipe then error("ByteVeil v4.6.3: region recipe missing",0)end;Q[${S.pc}]=PC+1;for J=1,#recipe do local canonical=recipe[J];local actual=inv[canonical];local H=bank[actual];if not H then error("ByteVeil v4.6.3: micro dispatch",0)end;local stop=H(Q,I,R);if stop then break end end end;return ${N.unpackBuiltin}(Q[${S.ret}],1,Q[${S.ret}].n or #Q[${S.ret}])end`);
    } else if (v46) {
        lines.push(`${N.run}=function(X,P,...)local E=P and P[${S.env}]or ${V.envGuard}();local Q=${V.state}(E,X[${C.consts}],P,X[${C.fabric}]or 0,${V.personality});Q[${S.code}]=X[${C.code}];local PC0=#(X[${C.params}]or{});Q[${S.varargs}]={select(PC0+1,...)};Q[${S.varargs}].n=math.max(0,select("#",...)-PC0);for I=1,PC0 do local K0=X[${C.params}][I];local K=type(K0)=="function"and K0(Q)or K0;X[${C.params}][I]=K;Q[${S.locals}][K]=select(I,...);Q[${S.localSet}][K]=true end;local VMCache={};${v476 ? `local ${V.shadowFrame}=${V.shadowInit}();` : ""}${v468 ? "local __bv_guardTick=0;" : ""}while not Q[${S.halt}] do local PC=Q[${S.pc}];local F0=Q[${S.code}][PC];local RAW=F0;if type(F0)=="function"then RAW=F0();Q[${S.code}][PC]=RAW end;if not RAW then Q[${S.halt}]=true;break end;local I,RID=${V.unpackInstruction}(RAW);if not I or RID==nil then error("ByteVeil v4.6.3: instruction representation",0)end;local O=I[1]or 0;local G=${V.graph};local R=G.byId and G.byId[RID];if not R then error("ByteVeil v4.6: runtime region missing",0)end;local logical=R.route and R.route[O+1];if logical==nil then error("ByteVeil v4.6: region opcode route",0)end;Q[${S.pc}]=PC+1;local Exec=VMCache[RID];if not Exec then Exec=${V.vmb}(R);VMCache[RID]=Exec end;local STOP=Exec(Q,I,logical);${v476 ? (v478 ? `local BS=#(${V.shadowFrame}[${JSON.stringify(V.shadowSemanticTrace)}]or{});local TP=${V.shadowFrame}[${JSON.stringify(shadowStateKeys.tick)}] or 0;local TA=${V.shadowFrame}[${JSON.stringify(shadowStateKeys.acc)}] or 0;local TR=${V.shadowFrame}[${JSON.stringify(shadowStateKeys.r)}][1]or 0;local BA=${V.shadowFrame}[${JSON.stringify(V.shadowAuth)}]or 0;local ST=${V.shadowStep}(${V.shadowFrame},Q,I,R,logical,G.rootSeed);if (${V.shadowFrame}[${JSON.stringify(shadowStateKeys.tick)}] or 0)~=TP+${Number(strength) >= 8000 ? 3 : 2} or ((${V.shadowFrame}[${JSON.stringify(shadowStateKeys.acc)}] or 0)==TA and (${V.shadowFrame}[${JSON.stringify(shadowStateKeys.r)}][1]or 0)==TR) or not ${V.shadowProof}(${V.shadowFrame},Q,I,R,logical,G.rootSeed,BA,TP,BS) or ST~=${N.mix}(${V.shadowFrame}[${JSON.stringify(shadowStateKeys.acc)}] or 0,${N.xor}(${V.shadowFrame}[${JSON.stringify(shadowStateKeys.calls)}] or 0,${V.shadowFrame}[${JSON.stringify(shadowStateKeys.ret)}] or 0)) then error("ByteVeil v${v471Label}: shadow transition invariant",0)end;for Z=#${V.shadowFrame}[${JSON.stringify(V.shadowSemanticTrace)}],BS+1,-1 do ${V.shadowFrame}[${JSON.stringify(V.shadowSemanticTrace)}][Z]=nil end;Q[${S.fabric}]=${N.mix}(Q[${S.fabric}]or 0,ST);Q[${S.guard}]=${N.mix}(Q[${S.guard}]or 0,${N.xor}(ST,Q[${S.pc}]or 0));` : `local ST=${V.shadowStep}(${V.shadowFrame},Q,I,R,logical,G.rootSeed);Q[${S.fabric}]=${N.mix}(Q[${S.fabric}]or 0,ST);Q[${S.guard}]=${N.mix}(Q[${S.guard}]or 0,${N.xor}(ST,Q[${S.pc}]or 0));`) : ""}${v468 ? `__bv_guardTick=__bv_guardTick+1;if __bv_guardTick%8==0 then ${N.hookGuard}() end;` : ""}if not STOP and Q[${S.pc}]==PC+1 then Q[${S.pc}]=${V.advance}(Q,PC,R,I,G) end;${v468 ? "" : `if PC%32==0 then ${N.hookGuard}() end;`}if STOP then break end end;Q[${S.guard}]=${N.mix}(Q[${S.guard}]or 0,${N.xor}(Q[${S.micro}]or 0,${Number(personality.commitStyle)}));return ${N.unpackBuiltin}(Q[${S.ret}],1,Q[${S.ret}].n or #Q[${S.ret}])end`);
    } else {
        // VM-B is materialized as a region-local executable closure. The closure
        // derives its micro-op sequence when invoked, so there is no static recipe table.
        lines.push(`local ${V.vmb}=function(R)local Z=${N.mix}(R.token or 0,R.ps or 0);return function(S,I,L)local Q=${V.compose}(S,I,R,L or 0);local STOP=false;for J=1,#Q do local Z0=${V.microExec}(S,I,R,L or 0,Q[J]);if Z0~=nil then STOP=Z0;if STOP then break end end end;return STOP end end`);
        lines.push(`${N.run}=function(X,P,...)local E=P and P[${S.env}]or ${V.envGuard}();local Q=${V.state}(E,X[${C.consts}],P,X[${C.fabric}]or 0,${V.personality});Q[${S.code}]=X[${C.code}];local PC0=#(X[${C.params}]or{});Q[${S.varargs}]={select(PC0+1,...)};Q[${S.varargs}].n=math.max(0,select("#",...)-PC0);for I=1,PC0 do local K0=X[${C.params}][I];local K=type(K0)=="function"and K0(Q)or K0;X[${C.params}][I]=K;Q[${S.locals}][K]=select(I,...);Q[${S.localSet}][K]=true end;local VMCache={};${v468 ? "local __bv_guardTick=0;" : ""}while not Q[${S.halt}] do local PC=Q[${S.pc}];local F0=Q[${S.code}][PC];local I=F0;if type(F0)=="function"then I=F0();Q[${S.code}][PC]=I end;if not I then Q[${S.halt}]=true;break end;local Q0,RID=${V.unpackInstruction}(I);I=Q0;if not I or not RID then Q[${S.halt}]=true;error("ByteVeil v4.6.3: instruction representation",0)end;local O=I[1]or 0;local G=${V.graph};local R=G.byId and G.byId[RID];if not R then error("ByteVeil v4.6.3: runtime region missing",0)end;local logical=R.route and R.route[O+1];if logical==nil then error("ByteVeil v4.6.3: region opcode route",0)end;Q[${S.pc}]=PC+1;local Exec=VMCache[RID];if not Exec then Exec=${V.vmb}(R);VMCache[RID]=Exec end;local STOP=Exec(Q,I,logical);if STOP then break end;end;Q[${S.guard}]=${N.mix}(Q[${S.guard}]or 0,${N.xor}(Q[${S.micro}]or 0,${Number(personality.commitStyle)}));return ${N.unpackBuiltin}(Q[${S.ret}],1,Q[${S.ret}].n or #Q[${S.ret}])end`);
    }

    // v4.7.6 replaces the standalone decoy wheel with an encoded secondary VM that advances
    // for each real instruction and feeds the live guard/fabric state. Previous releases keep
    // their historical decoy implementation unchanged for reproducible comparisons.
    const family = (Number(seed) >>> 0) % 6;
    const depth = Math.max(12, Math.min(96, Number(decoyProfile.depth || 24)));
    let shadowPlan = null;
    if (v478) {
        shadowPlan = buildSemanticShadowVM({
            seed: packed.rootSeed >>> 0,
            depth,
            strength,
            opNames,
            names: {
                code: V.shadowCode, order: V.shadowOrder, handlers: V.shadowHandlers, handlerCore: V.shadowCore, liveMap: V.shadowLiveMap,
                init: V.shadowInit, step: V.shadowStep, proof: V.shadowProof, auth: V.shadowAuth,
                semanticHandlers: V.shadowSemanticHandlers, semanticProbe: V.shadowSemanticProbe, proofSemanticProbe: V.shadowProofSemanticProbe,
                semanticPlans: V.shadowSemanticPlans, vmState: V.shadowVMState, proofVmState: V.shadowProofVMState,
                sandboxNoop: V.shadowSandboxNoop, sandboxConst: V.shadowSandboxConst,
                sandboxResolve: V.shadowSandboxResolve, sandboxWrite: V.shadowSandboxWrite, sandboxRun: V.shadowSandboxRun,
                sandboxSuper: V.shadowSandboxSuper, semanticTrace: V.shadowSemanticTrace, semanticDigest: V.shadowSemanticDigest
            },
            N,
            S,
            defs,
            mode,
            version: packed.hardeningVersion || "4.7.8",
            helpers: { state: V.state, const: N.const, resolveGlobal: N.resolveGlobal, writeGlobal: N.writeGlobal, run: N.run, superFns: N.superFns }
        });
        lines.push(...shadowPlan.source.split(";\n"));
    } else if (v476) {
        const encodedOpcodes = bytecode.map?.encode || packed.opcodeMap?.encode || {};
        const sourceOpcodeTrace = [];
        const sourceTraceLimit = Math.max(128, depth * 8);
        const collectOpcodeTrace = (chunk, seen = new Set()) => {
            if (!chunk || typeof chunk !== "object" || seen.has(chunk) || sourceOpcodeTrace.length >= sourceTraceLimit) return;
            seen.add(chunk);
            const decode = chunk.map?.decode || bytecode.map?.decode || {};
            for (const instruction of chunk.code || []) {
                if (sourceOpcodeTrace.length >= sourceTraceLimit) break;
                if (Array.isArray(instruction) && instruction.length) sourceOpcodeTrace.push({ name: decode[instruction[0]] || "", operands: instruction.slice(1) });
            }
            for (const constant of chunk.consts || []) {
                if (sourceOpcodeTrace.length >= sourceTraceLimit) break;
                if (constant?.__chunk) collectOpcodeTrace(constant.__chunk, seen);
            }
        };
        collectOpcodeTrace(bytecode);
        shadowPlan = buildLiveShadowVM({
            seed: packed.rootSeed >>> 0,
            depth,
            strength,
            opNames,
            encode: encodedOpcodes,
            programOps: sourceOpcodeTrace,
            names: { code: V.shadowCode, order: V.shadowOrder, handlers: V.shadowHandlers, handlerCore: V.shadowCore, liveMap: V.shadowLiveMap, init: V.shadowInit, step: V.shadowStep },
            N,
            S
        });
        lines.push(shadowPlan.source);
    } else {
    lines.push(`local ${V.decoys}={}`);
    for(let i=0;i<depth;i++){
        const next=(i+1)%depth, alt=(i*7+3)%depth;
        let body;
        if(family===0) body=`D.a=${N.bx}(D.a or 0,I+(D.f or 0));D.f=${N.mix}(D.f or 0,D.a or 0)`;
        else if(family===1) body=`D.p=((D.p or 0)+I)%${depth}+1;D.a=${N.mix}(D.a or 0,D.p);D.g=${N.bx}(D.g or 0,D.a)`;
        else if(family===2) body=`D.q=(D.q or 1)*((I%17)+1)%4294967296;D.a=${N.mix}(D.a or 0,D.q);D.f=${N.bx}(D.f or 0,D.q)`;
        else if(family===3) body=`D.t[D.p]=I;D.p=(D.p%${depth})+1;D.a=${N.mix}(D.a or 0,D.t[D.p]or 0)`;
        else if(family===4) body=`local Z=${N.xor}(D.a or 0,D.g or 0);if Z%2==0 then D.f=${N.mix}(D.f or 0,Z)else D.g=${N.mix}(D.g or 0,Z)end;D.a=Z`;
        else body=`D.a=${N.mix}(D.a or 0,I*${i+3});D.f=${N.xor}(D.f or 0,D.a);D.g=${N.mix}(D.g or 0,D.f)`;
        lines.push(`${V.decoys}[${i+1}]=function(D,I)${body};if ((D.a or 0)+I+${i})%3==0 then return ${V.decoys}[${next+1}] else return ${V.decoys}[${alt+1}] end end`);
    }
    const init = family===3 ? `{a=${(seed^0xA511E9B3)>>>0},f=0,g=0,p=1,q=1,t={}}` : `{a=${(seed^0xA511E9B3)>>>0},f=0,g=0,p=1,q=1}`;
    const decoyState=opaque("dst",10000);
    lines.push(`local ${decoyState}=function()return ${init} end`);
    lines.push(`local ${V.decoyRun}=function(G)local D=${decoyState}();local F=${V.decoys}[1];for I=1,${Math.max(4,decoyProfile.budget)*Math.max(4,Math.floor(depth/6))} do F=F(D,I)or ${V.decoys}[1] end;return ${N.mix}(G,D.a or 0) end`);

    }

    lines.push(`${N.hookGuard}()`);
    if (antiBundle?.checkpoints.beforeDecode) lines.push(antiBundle.checkpoints.beforeDecode);
    if (v476) {
        const fp = Number.parseInt(shadowPlan.fingerprint, 16) >>> 0;
        lines.push(`local ${V.graph}Result=${V.graph}Runtime();local ${N.activation}=${N.mix}(${V.graph}Result.rootSeed or 0,0x${fp.toString(16)});local ${N.root}=${readFn}(${V.graph}Result);${N.root}[${C.fabric}]=${N.xor}(${N.activation},${V.graph}Result.personality or 0);local ${N.result}=(function(...)return{n=select("#",...),...}end)(${N.run}(${N.root},nil${runtimeBridgeParam ? `,${runtimeBridgeParam},...` : ",..."}));${N.activation}=nil;${N.root}=nil;return ${N.unpackBuiltin}(${N.result},1,${N.result}.n or #${N.result})`);
    } else {
        lines.push(`local ${V.graph}Result=${V.graph}Runtime();local ${N.activation}=${V.decoyRun}(${V.graph}Result.rootSeed or 0);local ${N.root}=${readFn}(${V.graph}Result);${N.root}[${C.fabric}]=${N.xor}(${N.activation},${V.graph}Result.personality or 0);local ${N.result}=(function(...)return{n=select("#",...),...}end)(${N.run}(${N.root},nil,...));${N.activation}=nil;${N.root}=nil;return ${N.unpackBuiltin}(${N.result},1,${N.result}.n or #${N.result})`);
    }

    let bootstrapCoupling = null;
    if (v479) {
        const carriers = Array.isArray(packed.payloadCarriers) ? packed.payloadCarriers : [];
        if (!carriers.length) throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: no carriers");
        const laneGroups = Array.from({ length: Number(packed.payloadLaneCount || 0) }, () => []);
        const descriptorSlots = [];
        for (const carrier of carriers) {
            if (!Number.isInteger(carrier.slot) || carrier.slot < 1 || typeof carrier.text !== "string" || !carrier.text.length) {
                throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: malformed carrier");
            }
            if (carrier.kind === "lane") {
                if (!Number.isInteger(carrier.lane) || carrier.lane < 1 || carrier.lane > laneGroups.length) throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: invalid lane");
                laneGroups[carrier.lane - 1].push(carrier.slot);
            } else if (carrier.kind === "descriptor") descriptorSlots.push(carrier.slot);
            else throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: unknown carrier kind");
        }
        if (!descriptorSlots.length || !laneGroups.some((group) => group.length)) throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: incomplete carrier map");
        const laneIntegrityRecords = packed.payloadLaneIntegrity
            .map((record, index) => `[${index + 1}]={${record.checksum},${record.length},${record.mirrorChecksum}}`)
            .join(",");
        const descriptorIntegrity = packed.payloadDescriptorIntegrity;
        const tamperCheck = antiBundle.helpers.tamper.names.check;
        const dumpWipe = antiBundle.helpers.dump.names.wipe;
        const byteTable = V.payloadToBytes;
        const carrierDecoder = v580
            ? `local ${V.decodePayloadCarrier}=function(S,A,O,R,K,Z,Q)local L=#${N.alphabet};if R then local P={};for I=#S,1,-1 do P[#P+1]=string.sub(S,I,I)end;S=table.concat(P)end;local T={};local ST=K or 1;local VAR=Q or 0;local PV=${N.bx}(Z or 0,${Number(packed.descriptorSalt || 0) >>> 0})%L;for I=1,#S do local P=string.find(${N.alphabet},string.sub(S,I,I),1,true);if not P then error("payload carrier alphabet",0)end;local STEP=${N.bx}(${N.bx}(${N.mul}(I,0x9E3779B1),Z or 0),${N.mul}(PV+1,0x45D9F3B));if VAR==0 then ST=${N.mix}(ST,STEP) elseif VAR==1 then ST=${N.mix}(${N.bx}(ST,STEP),0xA5D3C7E9) elseif VAR==2 then ST=${N.mix}(ST,${N.mix}(STEP,0x9E3779B9)) else ST=${N.bx}(${N.mix}(${N.bx}(ST,0xC0FFEE11),STEP),STEP) end;local MASK=ST%L;local IDX=(P-1-O-MASK)%L;local C=(A*IDX)%L;PV=(C*13+(P-1)*7+(I-1))%L;T[I]=string.sub(${N.alphabet},C+1,C+1)end;return table.concat(T)end`
            : v500
                ? `local ${V.decodePayloadCarrier}=function(S,A,O,R,K,Z,Q)local L=#${N.alphabet};if R then local P={};for I=#S,1,-1 do P[#P+1]=string.sub(S,I,I)end;S=table.concat(P)end;local T={};local ST=K or 1;local VAR=Q or 0;for I=1,#S do local P=string.find(${N.alphabet},string.sub(S,I,I),1,true);if not P then error("payload carrier alphabet",0)end;local STEP=${N.bx}(${N.mul}(I,0x9E3779B1),Z or 0);if VAR==0 then ST=${N.mix}(ST,STEP) elseif VAR==1 then ST=${N.mix}(${N.bx}(ST,STEP),0xA5D3C7E9) elseif VAR==2 then ST=${N.mix}(ST,${N.mix}(STEP,0x9E3779B9)) else ST=${N.bx}(${N.mix}(${N.bx}(ST,0xC0FFEE11),STEP),STEP) end;local MASK=ST%L;local IDX=(P-1-O-MASK)%L;local C=(A*IDX)%L;T[I]=string.sub(${N.alphabet},C+1,C+1)end;return table.concat(T)end`
                : `local ${V.decodePayloadCarrier}=function(S,A,O,R)local L=#${N.alphabet};if R then local Q={};for I=#S,1,-1 do Q[#Q+1]=string.sub(S,I,I)end;S=table.concat(Q)end;local T={};for I=1,#S do local P=string.find(${N.alphabet},string.sub(S,I,I),1,true);if not P then error("payload carrier alphabet",0)end;local Q=(A*((P-1-O)%L))%L;T[I]=string.sub(${N.alphabet},Q+1,Q+1)end;return table.concat(T)end`;
        // Live junk carriers: shaped exactly like a payload lane (same decoder call,
        // same alphabet, same VeilBlob container) but their decoded bytes only feed a
        // length digest that is verified right here. Deleting one, editing one byte, or
        // dropping the digest check breaks the build, so no carrier-shaped container in
        // the output can be dismissed as noise by a static reader.
        const junkRng = v38Rng((Number(seed) ^ 0x0E5C0DE) >>> 0);
        const junkSlots = [];
        const junkFoldLens = [];
        const junkFoldBytes = [];
        let junkTemplate = null;
        const junkAssignments = [];
        const descriptorSaltForCarrier = Number(packed.descriptorSalt || 0) >>> 0;
        // Build-time replica of the emitted v5.9.0 carrier decoder. It exists so the
        // junk digest can cover the decoded *bytes*, not only their count: a
        // single-character flip inside a junk container then changes the digest exactly
        // like it changes a payload lane, which is what stops a "flip and re-run" oracle
        // from telling junk apart from live carriers. A replica that drifted from the
        // emitted decoder would abort the build instead of silently mis-reporting.
        const decodeCarrierForDigest = (text, params) => {
            const size = rawAlphabetStr.length;
            const xor32 = (a, b) => ((a >>> 0) ^ (b >>> 0)) >>> 0;
            const mul32 = (a, b) => Math.imul(a >>> 0, b >>> 0) >>> 0;
            const mix = (u, v) => {
                let r = xor32(u, xor32(v, 0xB17E4A31));
                r = xor32(r, Math.floor(r / 65536));
                r = mul32(r, 2246822519);
                r = xor32(r, Math.floor(r / 8192));
                r = mul32(r, 3266489917);
                return xor32(r, Math.floor(r / 65536));
            };
            const mod = (value, m) => ((value % m) + m) % m;
            let source = text;
            if (params.reversed) source = [...source].reverse().join("");
            // Mirror the Lua defaults in the emitted decoder: ST=K or 1, VAR=Q or 0,
            // PV=bx(Z or 0, descriptorSalt) % L. A null field means the argument is not
            // passed at all, which is not the same as passing 0.
            const variant = params.decodeVariant === null ? 0 : params.decodeVariant;
            const zero = params.streamSalt === null ? 0 : params.streamSalt;
            let state = params.streamSeed === null ? 1 : params.streamSeed;
            let prev = xor32(zero, descriptorSaltForCarrier) % size;
            let out = "";
            for (let index = 1; index <= source.length; index++) {
                const position = rawAlphabetStr.indexOf(source[index - 1]) + 1;
                if (position < 1) throw new Error("ByteVeil v5.9 junk carrier invariant failed: alphabet mismatch");
                const step = xor32(xor32(mul32(index, 0x9E3779B1), zero), mul32(prev + 1, 0x45D9F3B));
                if (variant === 0) state = mix(state, step);
                else if (variant === 1) state = mix(xor32(state, step), 0xA5D3C7E9);
                else if (variant === 2) state = mix(state, mix(step, 0x9E3779B9));
                else state = xor32(mix(xor32(state, 0xC0FFEE11), step), step);
                const mask = state % size;
                const idx = mod(position - 1 - params.decodeOffset - mask, size);
                const c = mod(params.decodeMultiplier * idx, size);
                prev = mod(c * 13 + (position - 1) * 7 + (index - 1), size);
                out += rawAlphabetStr[c];
            }
            return out;
        };
        if (v580 && carriers.length) {
            const takenSlots = new Set(carriers.map((carrier) => carrier.slot));
            junkTemplate = carriers[junkRng() % carriers.length];
            const junkCount = 3 + (junkRng() % 4);
            for (let i = 0; i < junkCount; i++) {
                let junkSlot;
                do {
                    junkSlot = 1000 + (junkRng() % 89000);
                } while (takenSlots.has(junkSlot));
                takenSlots.add(junkSlot);
                const junkLength = 48 + (junkRng() % 240);
                let junkText = "";
                for (let k = 0; k < junkLength; k++) junkText += rawAlphabetStr[junkRng() % rawAlphabetStr.length];
                const junkParams = {
                    decodeMultiplier: junkTemplate.decodeMultiplier,
                    decodeOffset: junkTemplate.decodeOffset,
                    reversed: junkTemplate.reversed,
                    streamSeed: v500 ? junkTemplate.streamSeed : null,
                    streamSalt: v500 ? junkTemplate.streamSalt : null,
                    decodeVariant: v500 ? junkTemplate.decodeVariant : null
                };
                const decodedJunk = decodeCarrierForDigest(junkText, junkParams);
                if (decodedJunk.length !== junkLength) throw new Error("ByteVeil v5.9 junk carrier invariant failed: length-preserving decode broken");
                junkSlots.push(junkSlot);
                junkFoldLens.push(junkLength);
                junkFoldBytes.push(decodedJunk);
                const junkStream = v500
                    ? `,${junkTemplate.streamSeed},${junkTemplate.streamSalt},${junkTemplate.decodeVariant}`
                    : "";
                junkAssignments.push(`${V.payloadCarrierBank}[${junkSlot}]=function()return ${V.junkCarrierDecode}(string.sub(${renderCarrierLiteral(junkText)},${CARRIER_MARKER_SUB}),${junkTemplate.decodeMultiplier},${junkTemplate.decodeOffset},${junkTemplate.reversed ? "true" : "false"}${junkStream}) end`);
            }
        }
        // The junk carriers decode through their own copy of the carrier decoder. The
        // shared instance is rewritten in place by the bootstrap stages (its keystream
        // seed is re-keyed with the stage context), so its per-character output is not a
        // pure function of the build; only this un-rewritten copy has a decode the build
        // can predict, which is what lets the digest cover decoded bytes instead of only
        // their count.
        const junkDecoder = junkAssignments.length
            ? carrierDecoder.split(V.decodePayloadCarrier).join(V.junkCarrierDecode)
            : "";
        // Each junk carrier contributes its length and a position-weighted fold of its
        // decoded bytes, both weighted by its index, so removing, reordering, editing or
        // swapping junk carriers changes the digest. The digest only proves the carriers
        // decode as expected; nothing else reads their bytes.
        const junkModulus = 1000003;
        const junkByteFold = (decoded) => {
            let fold = 0;
            for (let j = 1; j <= decoded.length; j++) fold = (fold + decoded.charCodeAt(j - 1) * (j * 31 + 7)) % junkModulus;
            return fold;
        };
        let junkDigest = 0;
        junkFoldLens.forEach((length, index) => {
            const weight = (index + 1) * 37 + 11;
            junkDigest = (junkDigest + length * weight + junkByteFold(junkFoldBytes[index]) * ((index + 1) * 53 + 19)) % junkModulus;
        });
        // The guard consumes its own slots, so a build path that runs the prelude more
        // than once must not treat the already-consumed state as tampering; it only
        // asserts when at least one junk carrier is still present.
        const junkGuard = junkAssignments.length
            ? `;${junkDecoder};${junkAssignments.join(";")};local ${V.junkCarrierDigest}=function()local __bvjBail=function(M)error(M,0)local __bvjNil=({})[1]return __bvjNil.x end;local L={${junkSlots.join(",")}};local LS={${junkFoldLens.join(",")}};local D=false;for I=1,#L do if ${V.payloadCarrierBank}[L[I]] then D=true;break end end;if not D then return 0 end;local T=0;for I=1,#L do local K=L[I];local F=${V.payloadCarrierBank}[K];if type(F)~="function" then __bvjBail("junk carrier missing")end;local S=F();if type(S)~="string" or #S~=LS[I] then __bvjBail("junk carrier shape")end;local B=0;for J=1,#S do B=(B+string.byte(S,J)*(J*31+7))%${junkModulus} end;T=(T+#S*(I*37+11)+B*(I*53+19))%${junkModulus};${V.payloadCarrierBank}[K]=nil end;if T~=${junkDigest} then __bvjBail("junk carrier digest")end;return T end;${V.junkCarrierDigest}();`
            : "";
        const prelude = `local ${V.payloadCarrierBank}={};local ${V.payloadLaneCache}={};local ${V.payloadLaneMap}={${laneGroups.map((g) => `{${g.join(",")}}`).join(",")}};local ${V.payloadDescriptorMap}={${descriptorSlots.join(",")}};local ${V.payloadIntegrityRecords}={${laneIntegrityRecords}};local ${byteTable}=function(S)local B={};for I=1,#S do B[I]=string.byte(S,I)end;return B end;${carrierDecoder};local ${V.readPayloadLane}=function(L)if type(L)~="number" or L~=math.floor(L) or L<1 or L>#${V.payloadLaneMap} then error("payload lane",0)end;local X=${V.payloadLaneCache}[L];if X then local R=${V.payloadIntegrityRecords}[L];if not R then error("payload integrity record",0)end;${tamperCheck}(${byteTable}(X),R[1],R[2],R[3]);return X end;local G=${V.payloadLaneMap}[L];local T={};for I=1,#G do local K=G[I];local F=${V.payloadCarrierBank}[K];if type(F)~="function" then error("payload carrier missing",0)end;T[I]=F();${V.payloadCarrierBank}[K]=nil end;${dumpWipe}(G);X=table.concat(T);${dumpWipe}(T);local R=${V.payloadIntegrityRecords}[L];if not R then error("payload integrity record",0)end;${tamperCheck}(${byteTable}(X),R[1],R[2],R[3]);${V.payloadLaneCache}[L]=X;return X end;local ${V.readPayloadDescriptor}=function()local T={};for I=1,#${V.payloadDescriptorMap} do local K=${V.payloadDescriptorMap}[I];local F=${V.payloadCarrierBank}[K];if type(F)~="function" then error("descriptor carrier missing",0)end;T[I]=F();${V.payloadCarrierBank}[K]=nil end;${dumpWipe}(${V.payloadDescriptorMap});local X=table.concat(T);${dumpWipe}(T);${tamperCheck}(${byteTable}(X),${descriptorIntegrity.checksum},${descriptorIntegrity.length},${descriptorIntegrity.mirrorChecksum});return X end${junkGuard}`;
        const graphInitIndex = lines.findIndex((line) => line === `local ${V.graph}=${packed.graph}`);
        if (graphInitIndex < 0) throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: graph initialization missing");
        lines.splice(graphInitIndex, 0, prelude);
        const executionGuardIndex = lines.findIndex((line, index) => index > graphInitIndex && line === `${N.hookGuard}()`);
        if (executionGuardIndex < 0) throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: execution guard missing");
        const assignments = carriers.map((carrier) => {
            if (!Number.isInteger(carrier.decodeMultiplier) || carrier.decodeMultiplier < 1 || !Number.isInteger(carrier.decodeOffset) || typeof carrier.reversed !== "boolean") {
                throw new Error("ByteVeil v4.7.9 payload carrier invariant failed: missing carrier transform");
            }
            const streamArgs = v500
                ? `,${carrier.streamSeed},${carrier.streamSalt},${carrier.decodeVariant}`
                : "";
            // Carriers travel as VeilBlob containers rather than quoted strings: the
            // `string.sub` drops the marker, so the decoder still receives the exact
            // encoded text, but a static reader loses the quote that used to delimit
            // each lane and has to resolve escalating bracket levels first.
            const carrierLiteral = `string.sub(${renderCarrierLiteral(carrier.text)},${CARRIER_MARKER_SUB})`;
            return `${V.payloadCarrierBank}[${carrier.slot}]=function()return ${V.decodePayloadCarrier}(${carrierLiteral},${carrier.decodeMultiplier},${carrier.decodeOffset},${carrier.reversed ? "true" : "false"}${streamArgs}) end`;
        });
        const distributed = v38Shuffle(assignments, (Number(seed) ^ 0xC4A771E9) >>> 0);
        // Unused char-code sources interleaved with the live carriers. Each is a
        // structurally genuine VeilBlob container stored under a numeric slot that no
        // lane or descriptor map ever names, so carrier count cannot be read off the
        // table without first resolving the lane map.
        if (v580 && distributed.length >= 3) {
            const decoyRng = v38Rng((Number(seed) ^ 0x0E517) >>> 0);
            const usedSlots = new Set(carriers.map((carrier) => carrier.slot));
            const decoyCount = 2 + (decoyRng() % 3);
            for (let i = 0; i < decoyCount; i++) {
                let decoySlot;
                do {
                    decoySlot = 1000 + (decoyRng() % 89000);
                } while (usedSlots.has(decoySlot));
                usedSlots.add(decoySlot);
                distributed.splice(
                    1 + (decoyRng() % distributed.length),
                    0,
                    `${V.payloadCarrierBank}[${decoySlot}]=${renderDecoyBlob((Number(seed) + i + 1) >>> 0)}`
                );
            }
        }
        const first = graphInitIndex + 1;
        const span = Math.max(1, executionGuardIndex - first);
        if (v580 && !runtimeBridgeParam && distributed.length >= 3) {
            const baseLinesSnapshot = lines.slice();
            const cut1 = Math.max(1, Math.floor(distributed.length / 3));
            const cut2 = Math.max(cut1 + 1, Math.floor((distributed.length * 2) / 3));
            const stage1Carriers = distributed.slice(0, cut1);
            const stage2Carriers = distributed.slice(cut1, cut2);
            const stage3Carriers = distributed.slice(cut2);
            const fpHex = v476 ? `0x${(Number.parseInt(shadowPlan.fingerprint, 16) >>> 0).toString(16)}` : "0";
            const personalityIndex = baseLinesSnapshot.findIndex((line) => line.startsWith(`local ${V.personality}=`));
            const stateIndex = baseLinesSnapshot.findIndex((line) => line.startsWith(`local ${V.state}=function(`));
            const canSplitSubsystems = v478 && v46 && personalityIndex > graphInitIndex && stateIndex > personalityIndex && executionGuardIndex > stateIndex + 3;

            const normalizeStageSource = (linesArr) => linesArr
                .join("\n")
                .replace(/\bByteCode\b/g, "ByteVeil")
                .replace(/v4\.[67]\.[1-9]/g, `v${v471Label}`)
                .replace(/v5\.0\.0/g, `v${v471Label}`)
                .replace(/"ByteVeil v[^":]*: /g, '"');

            const scatterStageCarriers = (stageLines, carriersToScatter, minIdx = 0) => {
                const startIdx = Math.max(0, Math.min(stageLines.length - 1, minIdx));
                const stageSpan = Math.max(1, stageLines.length - startIdx);
                const sBuckets = new Map();
                for (let i = 0; i < carriersToScatter.length; i++) {
                    const target = startIdx + Math.min(stageSpan - 1, Math.floor(((i + 0.5) * stageSpan) / carriersToScatter.length));
                    const grp = sBuckets.get(target) || [];
                    grp.push(carriersToScatter[i]);
                    sBuckets.set(target, grp);
                }
                const out = [];
                for (let i = 0; i < stageLines.length; i++) {
                    const grp = sBuckets.get(i);
                    if (grp) out.push(...grp);
                    out.push(stageLines[i]);
                }
                return out;
            };

            bootstrapCoupling = {
                bankName: V.payloadCarrierBank,
                decoderName: V.decodePayloadCarrier,
                stage1Carriers,
                stage2Carriers,
                renderStages: canSplitSubsystems ? ({ topology, selfName, bankSlot, decSlot, keySlot, ctxSlot, expectedKey }) => {
                    const usedCtxKeys = new Set();
                    let kState = ((Number(seed) >>> 0) ^ 0x58C7A013) >>> 0;
                    const nextCtxKey = () => {
                        for (;;) {
                            kState = (Math.imul(kState, 1664525) + 1013904223) >>> 0;
                            const cand = 0x100 + (kState % 0x6EFF);
                            if (!usedCtxKeys.has(cand)) {
                                usedCtxKeys.add(cand);
                                return cand;
                            }
                        }
                    };
                    const K = {
                        env: nextCtxKey(),
                        envGuard: nextCtxKey(),
                        unpack: nextCtxKey(),
                        bx: nextCtxKey(),
                        mul: nextCtxKey(),
                        mix: nextCtxKey(),
                        checksum: nextCtxKey(),
                        state: nextCtxKey(),
                        dec: nextCtxKey(),
                        key: nextCtxKey(),
                        graph: nextCtxKey(),
                        graphRuntime: nextCtxKey(),
                        readFn: nextCtxKey(),
                        unpackInst: nextCtxKey(),
                        advance: nextCtxKey(),
                        personality: nextCtxKey(),
                        beforeDecode: nextCtxKey(),
                        shadowInit: nextCtxKey(),
                        shadowStep: nextCtxKey(),
                        shadowProof: nextCtxKey()
                    };
                    const ctxVar = `__bv_ctx_${(Number(seed) >>> 0).toString(36)}`;
                    const bkeyName = `__bv_bkey_${(Number(seed) >>> 0).toString(36)}`;

                    const primitivesInitLines = [
                        `local ${ctxVar}={};${selfName}[${ctxSlot}]=${ctxVar}`,
                        ...baseLinesSnapshot.slice(0, 6),
                        baseLinesSnapshot[stateIndex],
                        `${ctxVar}[${K.env}],${ctxVar}[${K.envGuard}],${ctxVar}[${K.unpack}],${ctxVar}[${K.bx}],${ctxVar}[${K.mul}],${ctxVar}[${K.mix}],${ctxVar}[${K.checksum}],${ctxVar}[${K.state}]=${V.env},${V.envGuard},${N.unpackBuiltin},${N.bx},${N.mul},${N.mix},${N.checksum},${V.state}`
                    ];

                    const primitivesUnpackLine = `local ${ctxVar}=${selfName}[${ctxSlot}];if type(${ctxVar})~="table"then error("bootstrap state",0)end;local ${V.env},${V.envGuard},${N.unpackBuiltin},${N.bx},${N.mul},${N.mix},${N.checksum},${V.state}=${ctxVar}[${K.env}],${ctxVar}[${K.envGuard}],${ctxVar}[${K.unpack}],${ctxVar}[${K.bx}],${ctxVar}[${K.mul}],${ctxVar}[${K.mix}],${ctxVar}[${K.checksum}],${ctxVar}[${K.state}];local ${N.xor}=${N.bx}`;

                    const buildDeserializerStage = (stageCarriers, isFirstStage) => {
                        const coupledCarrierDecoder = carrierDecoder.replace(
                            `local PV=${N.bx}(Z or 0,${Number(packed.descriptorSalt || 0) >>> 0})%L`,
                            `local PV=${N.bx}(${N.bx}(Z or 0,${Number(packed.descriptorSalt || 0) >>> 0}),${N.bx}(${ctxVar}[${K.key}]or 0,${expectedKey}))%L`
                        );
                        const bankInit = isFirstStage
                            ? `local ${V.payloadCarrierBank}={};${selfName}[${bankSlot}]=${V.payloadCarrierBank};`
                            : `local ${V.payloadCarrierBank}=${selfName}[${bankSlot}];if type(${V.payloadCarrierBank})~="table"then error("bootstrap state",0)end;`;
                        const stagePrelude = prelude
                            .replace(`local ${V.payloadCarrierBank}={};`, bankInit)
                            .replace(`${carrierDecoder};`, `${coupledCarrierDecoder};${selfName}[${decSlot}]=${V.decodePayloadCarrier};${ctxVar}[${K.dec}]=${V.decodePayloadCarrier};`);
                        const rawLines = [
                            ...(isFirstStage ? primitivesInitLines : [primitivesUnpackLine]),
                            ...(antiBundle?.declarations ? [antiBundle.declarations] : []),
                            ...baseLinesSnapshot.slice(11, 13),
                            stagePrelude,
                            baseLinesSnapshot[graphInitIndex + 1],
                            baseLinesSnapshot[personalityIndex],
                            baseLinesSnapshot[personalityIndex + 4],
                            baseLinesSnapshot[personalityIndex + 6],
                            baseLinesSnapshot[personalityIndex + 7],
                            `${ctxVar}[${K.graph}]=${V.graph};${ctxVar}[${K.graphRuntime}]=${V.graph}Runtime;${ctxVar}[${K.personality}]=${V.personality};${ctxVar}[${K.beforeDecode}]=function()${antiBundle?.checkpoints.beforeDecode || ""}end`
                        ];
                        const preludeIdx = rawLines.indexOf(stagePrelude);
                        return normalizeStageSource(scatterStageCarriers(rawLines, stageCarriers, preludeIdx + 1));
                    };

                    const buildShadowStage = (stageCarriers, isFirstStage) => {
                        const bankInit = isFirstStage
                            ? `local ${V.payloadCarrierBank}={};${selfName}[${bankSlot}]=${V.payloadCarrierBank};local ${V.decodePayloadCarrier}=function(...)return ${ctxVar}[${K.dec}](...)end`
                            : `local ${V.payloadCarrierBank}=${selfName}[${bankSlot}];if type(${V.payloadCarrierBank})~="table"then error("bootstrap state",0)end;local ${V.decodePayloadCarrier}=${selfName}[${decSlot}]or function(...)return ${ctxVar}[${K.dec}](...)end`;
                        const rawLines = [
                            ...(isFirstStage ? primitivesInitLines : [primitivesUnpackLine]),
                            bankInit,
                            baseLinesSnapshot[stateIndex + 1],
                            ...baseLinesSnapshot.slice(stateIndex + 4, executionGuardIndex),
                            `${ctxVar}[${K.shadowInit}]=${V.shadowInit};${ctxVar}[${K.shadowStep}]=${V.shadowStep};${ctxVar}[${K.shadowProof}]=${V.shadowProof}`
                        ];
                        const bankIdx = rawLines.indexOf(bankInit);
                        return normalizeStageSource(scatterStageCarriers(rawLines, stageCarriers, bankIdx + 1));
                    };

                    const buildExecutionStage = (stageCarriers) => {
                        const tailLine = baseLinesSnapshot[baseLinesSnapshot.length - 1]
                            .replace(
                                `local ${N.activation}=${N.mix}(${V.graph}Result.rootSeed or 0,${fpHex});`,
                                `local ${N.activation}=${N.bx}(${N.mix}(${V.graph}Result.rootSeed or 0,${fpHex}),${N.bx}(${bkeyName},${expectedKey}));`
                            );
                        const headerLine = `local ${ctxVar},${V.payloadCarrierBank},${bkeyName}=${selfName}[${ctxSlot}],${selfName}[${bankSlot}],${selfName}[${keySlot}];${selfName}[${ctxSlot}],${selfName}[${bankSlot}],${selfName}[${keySlot}],${selfName}[${decSlot}]=nil,nil,nil,nil;if type(${ctxVar})~="table" or type(${V.payloadCarrierBank})~="table" or ${bkeyName}~=${expectedKey} then error("bootstrap state",0)end;${ctxVar}[${K.key}]=${bkeyName};local ${V.env},${V.envGuard},${N.unpackBuiltin},${N.bx},${N.mul},${N.mix},${V.state}=${ctxVar}[${K.env}],${ctxVar}[${K.envGuard}],${ctxVar}[${K.unpack}],${ctxVar}[${K.bx}],${ctxVar}[${K.mul}],${ctxVar}[${K.mix}],${ctxVar}[${K.state}];local ${N.xor},${V.graph},${V.graph}Runtime,${V.personality},${V.shadowInit},${V.shadowStep},${V.shadowProof},__bv_beforeDecode,${V.decodePayloadCarrier}=${N.bx},${ctxVar}[${K.graph}],${ctxVar}[${K.graphRuntime}],${ctxVar}[${K.personality}],${ctxVar}[${K.shadowInit}],${ctxVar}[${K.shadowStep}],${ctxVar}[${K.shadowProof}],${ctxVar}[${K.beforeDecode}],${ctxVar}[${K.dec}]`;
                        const rawLines = [
                            headerLine,
                            ...baseLinesSnapshot.slice(6, 11),
                            baseLinesSnapshot[13],
                            ...baseLinesSnapshot.slice(graphInitIndex + 2, personalityIndex),
                            baseLinesSnapshot[personalityIndex + 1],
                            baseLinesSnapshot[personalityIndex + 2],
                            baseLinesSnapshot[personalityIndex + 3],
                            baseLinesSnapshot[personalityIndex + 5],
                            baseLinesSnapshot[personalityIndex + 8],
                            ...baseLinesSnapshot.slice(stateIndex + 2, stateIndex + 4),
                            `${N.hookGuard}()`,
                            `if __bv_beforeDecode then __bv_beforeDecode() end`,
                            tailLine
                        ];
                        return normalizeStageSource(scatterStageCarriers(rawLines.slice(0, -3), stageCarriers, 1).concat(rawLines.slice(-3)));
                    };

                    if (topology === "entry-first") {
                        return {
                            stage1Code: buildShadowStage(stage1Carriers, true),
                            stage2Code: buildDeserializerStage(stage2Carriers, false),
                            stage3Code: buildExecutionStage(stage3Carriers)
                        };
                    }
                    return {
                        stage1Code: buildDeserializerStage(stage1Carriers, true),
                        stage2Code: buildShadowStage(stage2Carriers, false),
                        stage3Code: buildExecutionStage(stage3Carriers)
                    };
                } : null,
                renderBody: ({ selfName, bankSlot, decSlot, keySlot, expectedKey }) => {
                    const coupledLines = baseLinesSnapshot.slice();
                    const bkeyName = `__bv_bkey_${(Number(seed) >>> 0).toString(36)}`;
                    const coupledCarrierDecoder = carrierDecoder.replace(
                        `local PV=${N.bx}(Z or 0,${Number(packed.descriptorSalt || 0) >>> 0})%L`,
                        `local PV=${N.bx}(${N.bx}(Z or 0,${Number(packed.descriptorSalt || 0) >>> 0}),${N.bx}(${bkeyName},${expectedKey}))%L`
                    );
                    const coupledPrelude = prelude
                        .replace(
                            `local ${V.payloadCarrierBank}={};`,
                            `local ${V.payloadCarrierBank}=${selfName}[${bankSlot}];${selfName}[${bankSlot}]=nil;local ${bkeyName}=${selfName}[${keySlot}];${selfName}[${keySlot}]=nil;if type(${V.payloadCarrierBank})~="table" or ${bkeyName}~=${expectedKey} then error("bootstrap state",0)end;`
                        )
                        .replace(
                            `${carrierDecoder};`,
                            `${coupledCarrierDecoder};${selfName}[${decSlot}]=${V.decodePayloadCarrier};`
                        );
                    coupledLines[graphInitIndex] = coupledPrelude;
                    const tailIdx = coupledLines.length - 1;
                    if (v476) {
                        coupledLines[tailIdx] = coupledLines[tailIdx]
                            .replace(
                                `local ${N.activation}=${N.mix}(${V.graph}Result.rootSeed or 0,${fpHex});`,
                                `local ${N.activation}=${N.bx}(${N.mix}(${V.graph}Result.rootSeed or 0,${fpHex}),${N.bx}(${bkeyName},${expectedKey}));`
                            )
                            .replace(
                                `${N.activation}=nil;${N.root}=nil;`,
                                `${selfName}[${decSlot}]=nil;${N.activation}=nil;${N.root}=nil;`
                            );
                    }
                    const sBuckets = new Map();
                    for (let i = 0; i < stage3Carriers.length; i++) {
                        const target = first + Math.min(span - 1, Math.floor(((i + 0.5) * span) / stage3Carriers.length));
                        const grp = sBuckets.get(target) || [];
                        grp.push(stage3Carriers[i]);
                        sBuckets.set(target, grp);
                    }
                    const sExpanded = [];
                    for (let i = 0; i < coupledLines.length; i++) {
                        const grp = sBuckets.get(i);
                        if (grp) sExpanded.push(...grp);
                        sExpanded.push(coupledLines[i]);
                    }
                    if (antiBundle?.declarations) sExpanded.unshift(antiBundle.declarations);
                    return normalizeStageSource(sExpanded);
                }
            };
        }
        const buckets = new Map();
        for (let i = 0; i < distributed.length; i++) {
            const target = first + Math.min(span - 1, Math.floor(((i + 0.5) * span) / distributed.length));
            const group = buckets.get(target) || [];
            group.push(distributed[i]);
            buckets.set(target, group);
        }
        const expanded = [];
        for (let i = 0; i < lines.length; i++) {
            const group = buckets.get(i);
            if (group) expanded.push(...group);
            expanded.push(lines[i]);
        }
        lines.length = 0;
        lines.push(...expanded);
    }
    if (antiBundle?.declarations) lines.unshift(antiBundle.declarations);
    let output=lines.join("\n");
    output=output.replace(/\bByteCode\b/g,"ByteVeil");
    if(/string\.char/.test(output)) throw new Error("ByteVeil v4.5.4 generator invariant failed: string.char emitted");
    if(/\\[0-9]{3}/.test(output)) throw new Error("ByteVeil v4.5.4 generator invariant failed: decimal byte escape emitted");
    // Measured on the generator's own source, before the pipeline renames the bundle locals:
    // the probe must be declared and reached from at least one guard call site.
    const antiHookNames = antiBundle?.helpers?.hook?.names;
    const antiReferences = antiHookNames?.probe
        ? (output.match(new RegExp(`\\b${antiHookNames.probe}\\b`, "g")) || []).length
        : 0;
    const antiGuardReferences = antiHookNames?.guard
        ? (output.match(new RegExp(`\\b${antiHookNames.guard}\\b`, "g")) || []).length
        : 0;
    if (Number(antiBundle?.metadata.antiHookVerdictDigestCanaries || 0) > 0 && antiReferences < 2) {
        throw new Error("ByteVeil v5.9 anti-hook invariant failed: verdict probe declared but never called");
    }
    let guardKeyReads = 0;
    if (guardKeyHolder) {
        const holderPattern = new RegExp(`\\b${guardKeyHolder}\\b`, "g");
        const holderMatches = [...output.matchAll(holderPattern)];
        guardKeyReads = holderMatches.length - 1;
        const declarationIndex = output.indexOf(`local ${guardKeyHolder}=`);
        const guardDeclarationIndex = findLocalDeclaration(
            output,
            antiBundle.helpers.hook.names.guard,
        );
        const readIndex = holderMatches.length > 1 ? holderMatches[1].index : -1;
        if (holderMatches.length < 2 || declarationIndex < 0 || readIndex < 0 || readIndex < declarationIndex) {
            throw new Error("ByteVeil v5.9 anti-hook key binding failed: the verdict holder is declared but the region root never reads it");
        }
        if (guardDeclarationIndex < 0 || guardDeclarationIndex > declarationIndex) {
            throw new Error("ByteVeil v5.9 anti-hook key binding failed: the verdict holder is read before the guard is declared");
        }
    }
    // A ciphered payload is only safe if the runtime can actually decrypt it: the helpers
    // must be declared and the material root they key on must be published on the graph.
    if (veilStr) {
        const used = (output.match(new RegExp(`\\b${veilStr.key}\\b`, "g")) || []).length;
        const masked = (output.match(new RegExp(`\\b${veilStr.mask}\\b`, "g")) || []).length;
        if (used < 2 || masked < 4 || !output.includes("G.materialRoot=")) {
            throw new Error(`ByteVeil v5.9 VeilStr invariant failed: helpers referenced ${used}/${masked} times, material root published ${output.includes("G.materialRoot=")}`);
        }
    }
    return {
        output, bootstrapCoupling, version:v471 ? v471Label : (v468 ? "4.6.8" : (v46 ? "4.6.3" : (v455 ? "4.5.5" : "4.5.4"))), layout:v471 ? (v473 ? "single-layer-distributed-region-vma-vmb-microop-v473" : (v472 ? "distributed-region-vma-vmb-microop-v472-four-lane-deepest" : "distributed-region-vma-vmb-microop-v471-parity-decoder-deepest")) : (v468 ? "distributed-region-vma-vmb-microop-v468-eight-topology" : (v46 ? "distributed-region-vma-vmb-microop-v463-architecture" : (v455 ? "distributed-region-vma-vmb-microop-v455-morphed" : "distributed-region-vma-vmb-microop-v452"))), mode,
        stateSlots:S, chunkSlots:C, opcodeMask:0, payloadByteLength:packed.payloadByteLength,
        regionCount:packed.regionCount, regionShards:packed.regionShards, regionEntries:packed.regionEntries,
        regionDecoys:packed.regionDecoys, transformedOpcodeCount:packed.transformedOpcodeCount,
        payloadLayout: packed.payloadLayout || null, payloadCarrierCodec: packed.payloadCarrierCodec || null, encodingEngine: packed.encodingEngine || null, encodingStages: packed.encodingStages || [], encodingRoundTripsVerified: Number(packed.encodingRoundTripsVerified || 0), encodingRegionsVerified: Number(packed.encodingRegionsVerified || 0), encodingPipelineRoundTripsVerified: Number(packed.encodingPipelineRoundTripsVerified || 0), payloadBlobChars: Number(packed.payloadBlobChars || 0),
        payloadLaneCount: Number(packed.payloadLaneCount || 0), payloadDescriptorChars: Number(packed.payloadDescriptorChars || 0),
        payloadDirectoryEntries: Number(packed.payloadDirectoryEntries || 0),
        payloadCarrierCount: Number(packed.payloadCarrierCount || 0),
        payloadDescriptorCarrierCount: Array.isArray(packed.payloadDescriptorCarrierSlots) ? packed.payloadDescriptorCarrierSlots.length : 0,
        payloadLaneCarrierCount: Array.isArray(packed.payloadLaneCarrierSlots) ? packed.payloadLaneCarrierSlots.reduce((count, group) => count + group.length, 0) : 0,
        payloadLaneCarrierSlots: packed.payloadLaneCarrierSlots || [],
        payloadDescriptorCarrierSlots: packed.payloadDescriptorCarrierSlots || [],
        payloadDirectoryValidatedByLPS: packed.payloadDirectoryValidatedByLPS === true,
        lpsPayloadPlanner: packed.lpsPayloadPlanner || null,
        vmStages:7, stagedRuntime:true, decoyGraph:true, decoyCycle:true, decoyLanes:4,
        decoyOpcodeHandlers:v476 ? shadowPlan.handlerCount : opNames.length, decoyFrameDepth:v476 ? shadowPlan.instructionCount : depth, decoyDepth:depth, decoyBudget:decoyProfile.budget, decoyVm:true, shadowVm:v476, shadowInterleaved:v476, shadowInstructionCount:v476 ? shadowPlan.instructionCount : 0, shadowHandlerCount:v476 ? shadowPlan.handlerCount : 0, shadowStepsPerRealInstruction:v476 ? shadowPlan.stepsPerRealInstruction : 0, shadowDispatchStyle:v476 ? shadowPlan.dispatchStyle : null, shadowTraceOpcodeCount:v476 ? shadowPlan.traceOpcodeCount : 0, shadowOperandTraceDerived:v476 ? shadowPlan.operandTraceDerived : false, shadowLiveOpcodeCoupled:v476 ? shadowPlan.liveOpcodeCoupled : false, shadowTraceInterleaveRatio:v476 ? shadowPlan.traceInterleaveRatio : null, shadowFingerprint:v476 ? shadowPlan.fingerprint : null, shadowArchitecture:v478 ? (v540 ? "semantic-handler-sandbox-v54-local-mangled" : v530 ? "semantic-handler-sandbox-v53-build-diverse" : v500 ? "semantic-handler-sandbox-v5" : v479 ? "semantic-handler-sandbox-v479" : shadowPlan.shadowArchitecture) : (v476 ? "interleaved-shadow-register-v476" : null), shadowStaticSourceTrace:v478 ? false : (v476 ? true : false), shadowSemanticHandlerCount:v478 ? Number(shadowPlan.semanticHandlerCount || 0) : 0, shadowSemanticHandlerCoverage:v478 ? Number(shadowPlan.semanticHandlerCoverage || 0) : 0, shadowMissingSemanticHandlers:v478 ? (shadowPlan.missingSemanticHandlers || []) : [], decoyVmShape: v478 ? (v540 ? "semantic-handler-sandbox-v54-local-mangled" : v530 ? "semantic-handler-sandbox-v53-build-diverse" : v500 ? "semantic-handler-sandbox-v5" : v479 ? "semantic-handler-sandbox-v479" : "semantic-handler-sandbox-v478") : v476 ? "interleaved-shadow-register-vm-v476" : `heterogeneous-vm452-family-${family}`,
        polymorphicHandlers:true, crossLayerIntegrity:true, sharedExecutionFabric:true, handlerFamilies:regionCount,
        fragmentGraph:true, nonLinearDependencies:true, materialDependencyGraph:true, opaqueTransportIR:true,
        perRegionOpcodeMapping:true, runtimeGeneratedDispatch:true, semanticMicroOps:true,
        lazyInstructionMaterialization:true, lazyConstantMaterialization:true, buildSpecificDiversity:true,
        buildSpecificVM:true, vmStateRandomization:true, vmPersonality:personality.id, vmPersonalityVersion:personality.version, vmStateProfile:personality.id, vmStateOrder:personality.stateOrder, vmDispatchStyle:personality.dispatchStyle, vmDispatchTopology:v468 ? ["flat-chain","split-chain","repeat-local","loop-chain","handler-table","residue-buckets","balanced-tree","affine-key"][Number(personality.dispatchStyle)%8] : (personality.effectiveDispatchTopology || null), actualSemanticDispatchTopologies:v468 ? 8 : (v46 ? 4 : 1), runtimeIntegrityCheckpointStride:v468 ? 8 : 0, runtimeApiProvenanceCheck:(v475 || v476) ? "no source-loader call sites; core API/debug integrity only" : (v471 ? "load+loadstring+core-api provenance on PUC Lua 5.x; loader identity checks elsewhere" : (v468 ? "debug.getinfo-when-standard-lua" : "none")), instructionDecoderStyle:v471 ? "two-specialized-parity-families-with-canonical-operands" : "single-dispatch-normalizer", vmRecipeStyle:personality.recipeStyle, vmMicroOrder:personality.microOrder, vmRepresentationStyle:v46 ? personality.representationFamily : personality.representationStyle, vmResolverFamily:personality.resolverFamily, vmStateModel:personality.stateModel, vmCommitStyle:personality.commitStyle, vmArchitectureFamily:v46 ? personality.architectureFamily : null, vmArchitectureName:v46 ? (ARCHITECTURES[personality.architectureFamily] || null) : null, vmSecondaryArchitecture:v46 ? personality.secondaryArchitecture : null, vmMaterializationFamily:v46 ? personality.materializationFamily : null, vmPbfFamily:v46 ? personality.pbfFamily : null, vmCffFamily:v46 ? personality.cffFamily : null, vmEnvFamily:v46 ? personality.envFamily : null, actualRepresentationMorphing:v46, semanticArchitectureFamilies:v46 ? 6 : 1, representationMorphing:(v455 || v46), composedSemanticLayer:(v455 || v46), runtimeGeneratedRecipe:(v455 || v46), dynamicDispatchTopology:(v455 || v46), nonCanonicalIR:(v455 || v46), regionResolverFamilies:v46 ? 6 : 4,
        distributedResolver:true, distributedRecipeBanks:true, regionSpecificVocabulary:true,
        runtimeVMBGeneration:true, semanticMicroOpEngine:true, lazyDependentConstants:true, heterogeneousDecoys:true,
        randomizedBuild:true, nestedObfuscation:false,
        antiHook: Number(antiBundle?.metadata.antiHookLayers || 0) > 0,
        antiTamper: Number(antiBundle?.metadata.antiTamperLayers || 0) > 0,
        antiDump: Number(antiBundle?.metadata.antiDumpLayers || 0) > 0,
        antiHookLayers: Number(antiBundle?.metadata.antiHookLayers || 0),
        antiTamperLayers: Number(antiBundle?.metadata.antiTamperLayers || 0),
        antiDumpLayers: Number(antiBundle?.metadata.antiDumpLayers || 0),
        antiIntegration: v479 ? "src/anti-runtime-checkpoints-v479" : null,
        antiHookVerdict: antiHookNames?.probe ? {
            algorithm: antiBundle.metadata.antiHookVerdictDigest || null,
            probeName: antiHookNames.probe,
            probeReferences: antiReferences,
            guardReferences: antiGuardReferences,
            expectedDigest: Number(antiBundle.helpers.hook.digest?.expected || 0),
            canaryCount: Number(antiBundle.metadata.antiHookVerdictDigestCanaries || 0),
            bindings: antiBundle.metadata.antiHookVerdictDigestBindings || null
        } : null,
        antiTamperChecksum: v479 ? "mod65599-dual-chain-lane-and-descriptor" : null,
        stringCipher: packed.stringCipher || null,
        antiGuardKey: guardKeyHolder ? {
            bound: true,
            holder: guardKeyHolder,
            value: Number(guardLatch.value),
            reads: guardKeyReads,
            forgeAddend: forgeLatch && forgeLatch.holder ? String(forgeLatch.holder) : null
        } : { bound: false, value: 0, reads: 0, forgeAddend: forgeLatch && forgeLatch.holder ? String(forgeLatch.holder) : null },
        payloadMaterialization: v476 ? "fragment-graph-interleaved-shadow-vm-v476-eight-lane-binary-regions" : v475 ? "fragment-graph-distributed-material-vma-vmb-microop-v475-eight-lane-binary-region-buffer" : v474 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v474-domain-separated-codec8-wire" : v473 ? "single-layer-packed-bytecode-vm-v473-distributed-payload" : v472 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v472-four-lane-packed-wire-codec" : v471 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v471-three-lane-feedback-codec" : v468 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v468-eight-topologies-checkpoints" : v46 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v463-morph" : v455 ? "fragment-graph-distributed-material-vma-vmb-microop-v455-morph" : "fragment-graph-distributed-material-vma-vmb-microop-v452",
        protectionEngine:"Byte-Blinder", generatorEngine: v476 ? "MFG-4.7.6-interleaved-shadow-vm" : v475 ? "MFG-4.7.5" : v474 ? "MFG-4.7.4" : v473 ? "MFG-4.7.3" : v472 ? "MFG-4.7.2" : v471 ? "MFG-4.7.1" : v468 ? "MFG-4.6.8" : v46 ? "MFG-4.6.3" : v455 ? "MFG-4.5.5" : "MFG-4.5.4", packedBytecode:true, sourceReconstruction:false,
        decoderVariant
    };
}

function buildV45GeneratedSource(bytecode, { seed, mode, strength, decoyProfile, decoderVariant, opNames, S, C, N, defs, packed, vmPersonality, forgeLatch = null, guardLatch = null }) {
    if (guardLatch && guardLatch.value != null) {
        throw new Error("ByteVeil v5.9 anti-hook key binding failed: this generator route cannot emit a verdict-bound region root");
    }
    const materialRoot = forgeLatch && forgeLatch.holder ? `(ROOT+${forgeLatch.holder})%4294967296` : "ROOT";
    if (packed.hardeningVersion === "4.5.5" || packed.hardeningVersion === "4.6.1" || packed.hardeningVersion === "4.6.2" || packed.hardeningVersion === "4.6.3" || packed.hardeningVersion === "4.5.4") return buildV452GeneratedSource(bytecode, { seed, mode, strength, decoyProfile, decoderVariant, opNames, S, C, N, defs, packed, vmPersonality, forgeLatch });
    const lines = [];
    const state = (field) => `S[${S[field]}]`;
    const usedOpaque = N.__usedLocalNames || (N.__usedLocalNames = new Set(Object.values(N).filter(v => typeof v === "string")));
    const opaqueV45Name = (key, salt = 0) => {
        let h = 5381;
        for (const ch of String(key)) h = ((h * 33) ^ ch.charCodeAt(0)) >>> 0;
        let x = (seed ^ h ^ Math.imul((salt + 1) >>> 0, 0x45D9F3B) ^ 0xC0FFEE17) >>> 0;
        let name = v38Id(x, "");
        while (usedOpaque.has(name)) { x = (x + 0x9E3779B9) >>> 0; name = v38Id(x, ""); }
        usedOpaque.add(name);
        return name;
    };
    const v45 = {};
    const opaqueKeys = [
        "graph","graphRuntime","resolve","byteAt","regionFor","decodeShard","regionSeed","regionMat",
        "microEnter","microBegin","microEnd","microExit","microRoute","microBank","microRecipes",
        "microCache","decoyRun","decoyFns","decoyState"
    ];
    opaqueKeys.forEach((key, index) => { v45[key] = opaqueV45Name(key, index); });

    const modeFlag = mode === "register" ? 1 : 0;
    const ascii = JSON.stringify(Array.from({ length: 95 }, (_, i) => String.fromCharCode(32 + i)).join(""));
    const alphabet = JSON.stringify(UNIFIED_ALPHABET);

    lines.push(`local ${V.env}=((getgenv and getgenv())or(getfenv and getfenv(1))or _G);local ${V.envGuard}=function()local E=${V.env};if not E then error("ByteVeil v4.6.3: environment unavailable",0)end;return E end;local ${N.unpackBuiltin}=${V.env}["table"] and (${V.env}["table"].unpack or ${V.env}["unpack"]) or table.unpack or unpack`);
    lines.push(`local ${N.bx}=function(A,B)A=A%4294967296;B=B%4294967296;if bit32 and bit32.bxor then return bit32.bxor(A,B)%4294967296 end;local R=0;local P=1;for I=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R%4294967296 end`);
    lines.push(`local ${N.xor}=${N.bx}`);
    lines.push(`local ${N.mul}=function(A,B)local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end`);
    lines.push(`local ${N.mix}=function(U,V)local R=${N.bx}(U,${N.bx}(V,0xB17E4A31));R=${N.bx}(R,math.floor(R/65536));R=${N.mul}(R,2246822519);R=${N.bx}(R,math.floor(R/8192));R=${N.mul}(R,3266489917);return ${N.bx}(R,math.floor(R/65536)) end`);
    lines.push(`local ${N.checksum}=function(D)local H=17;for I=1,#D do H=(H*65599+D[I]+1)%2147483647 end;return H end`);
    lines.push(`local ${N.alphabet}=${alphabet}`);
    lines.push(`local ${N.decode85}=function(T)local O={};for I=1,#T,5 do local V=0;for J=0,4 do local P=string.find(${N.alphabet},string.sub(T,I+J,I+J),1,true);if not P then error("ByteVeil v4.5.0: invalid payload alphabet",0)end;V=V*${PAYLOAD_RADIX}+P-1 end;O[#O+1]=math.floor(V/16777216)%256;O[#O+1]=math.floor(V/65536)%256;O[#O+1]=math.floor(V/256)%256;O[#O+1]=V%256 end;return O end`);
    lines.push(`local ${N.const}=function(S,I)local T=S[${S.consts}];local V=T[I+1];if type(V)=="function" then local R=V();T[I+1]=R;return R end;return V end`);
    lines.push(`local __bv_type=type;local __bv_byte=string.byte;local __bv_sub=string.sub;local __bv_find=string.find;local __bv_concat=table.concat;local __bv_floor=math.floor`);
    lines.push(`local ${N.hookGuard}=function()if type~=__bv_type or string.byte~=__bv_byte or string.sub~=__bv_sub or string.find~=__bv_find or table.concat~=__bv_concat or math.floor~=__bv_floor then error("ByteVeil v4.5.0: runtime reference integrity failed",0)end end`);
    lines.push(`local ${N.run}`);

    const semanticLogical = Array.isArray(packed.microPlan?.logicalOrder) ? packed.microPlan.logicalOrder.slice() : opNames.map((_, i) => i);
    const recipeByLogical = Array.isArray(packed.microPlan?.recipeByLogical) ? packed.microPlan.recipeByLogical.slice() : opNames.map((_, i) => i + 1);
    const semanticFn = {};
    for (const logical of semanticLogical) {
        const name = opNames[logical] || bytecode.map?.decode?.[logical];
        const fn = defs[name] || `S[${S.halt}]=true;return true`;
        const ident = opaqueV45Name(`handler:${logical}`, logical + 0x100);
        semanticFn[logical] = ident;
        const sourceFn = mode === "stack" ? stackHandler("", fn, { seed, identity: `v45-handler-${logical}` }) : registerHandler("", fn, { seed, identity: `v45-handler-${logical}` });
        lines.push(`local ${ident}=${sourceFn}`);
    }

    lines.push(`local ${v45.microEnter}=function(S,I,R)local RID=type(R)=="table"and R.id or R;RID=tonumber(RID)or 0;local G=(S[${S.guard}]or 0);S[${S.region}]=RID;S[${S.micro}]=${N.mix}(G,(RID+1)*0x45D9F3B);S[${S.guard}]=${N.bx}(S[${S.micro}],S[${S.fabric}]or 0)end`);
    lines.push(`local ${v45.microBegin}=function(S)local F=(S[${S.frame}]or 0)+1;S[${S.frame}]=F%4294967296;S[${S.guard}]=${N.mix}(S[${S.guard}],S[${S.frame}])end`);
    lines.push(`local ${v45.microEnd}=function(S)local F=S[${S.frame}]or 0;S[${S.frame}]=F>0 and F-1 or 0;S[${S.guard}]=${N.mix}(S[${S.guard}],(S[${S.frame}]or 0)+0xA53)end`);
    lines.push(`local ${v45.microExit}=function(S)local M=${N.mix}(S[${S.micro}]or 0,S[${S.pc}]or 0);S[${S.micro}]=M;S[${S.guard}]=${N.bx}(S[${S.guard}]or 0,M)end`);

    const baseHandlers = [v45.microEnter, v45.microBegin];
    const baseIndex = new Map();
    for (const logical of semanticLogical) {
        baseIndex.set(logical, baseHandlers.length + 1);
        baseHandlers.push(semanticFn[logical]);
    }
    const frameEndSlot = baseHandlers.length + 1;
    baseHandlers.push(v45.microEnd);
    const exitSlot = baseHandlers.length + 1;
    baseHandlers.push(v45.microExit);
    lines.push(`local ${v45.microBank}={${baseHandlers.join(",")}}`);

    const callLike = new Set(["CALL","CALLG","CALLGM","CALLM","TAILCALL","MAKEFUNC","RETURN","BREAK","ITERPREP","ITERLOOP"]);
    const recipes = new Array(opNames.length).fill(null);
    for (let logical = 0; logical < opNames.length; logical++) {
        const op = opNames[logical] || bytecode.map?.decode?.[logical];
        const rid = Number(recipeByLogical[logical] || logical + 1);
        const slot = baseIndex.get(logical);
        recipes[rid - 1] = callLike.has(op) ? [1, 2, slot, frameEndSlot, exitSlot] : [1, slot, exitSlot];
    }
    lines.push(`local ${v45.microRecipes}={${recipes.map(r => r ? `{${r.join(",")}}` : "{}").join(",")}}`);
    lines.push(`local ${v45.microRoute}=function(N0,K,BASE)local A={};local BANK={};local R={};local S0=K%4294967296;for I=1,N0 do A[I]=I end;for I=N0,2,-1 do S0=${N.mix}(S0,I+0x41);local J=(S0%I)+1;A[I],A[J]=A[J],A[I] end;for I=1,N0 do BANK[I]=BASE[A[I]];R[A[I]]=I end;return R,BANK end`);

    lines.push(`local ${v45.graph}=${packed.graph}`);
    lines.push(`local ${v45.graphRuntime}=nil`);
    lines.push(`local ${v45.resolve}=nil`);
    lines.push(`local ${v45.byteAt}=nil`);
    lines.push(`local ${v45.regionFor}=nil`);
    lines.push(`${v45.graphRuntime}=function()local G=${v45.graph};local byId={};local starts={};local cache={};local states={};local visiting={};local SA,SB,SC,SD=G.shares[1],G.shares[2],G.shares[3],G.shares[4];local ROOT=${N.bx}(${N.bx}(SA,SB),${N.bx}(SC,SD));local function depSeed(R)local D=0x13579BDF;for I=1,#R.dep do local ID=R.dep[I];if not byId[ID] then error("ByteVeil v4.5.0: dependency missing",0)end;local _,ST=${v45.resolve}(ID);D=${N.mix}(D,${N.bx}(ST,byId[ID].tok))end;return D end;local function rseed(ID,T,D)local S0=${N.mix}(${materialRoot},${N.bx}(T,${N.mul}(ID+1,0x45D9F3B)));S0=${N.mix}(S0,${N.bx}(D,0x9E3779B9));return ${N.mix}(S0,${N.bx}(0xB17E4A31,${N.mul}(ID+7,0x27D4EB2F))) end;local function mat(B,D)local MS=${modeFlag===1?"0x13579BDF":"0x2468ACE0"};local X0=${N.mix}(B,${N.bx}(D,${N.bx}(MS,${N.bx}(${decoyProfile.depth},${Number(decoyProfile.stages||3)}*2048))));X0=${N.mix}(X0,${N.mul}(${strength},0x45D9F3B));X0=${N.mix}(X0,${N.bx}(D,0x9E3779B9));return ${N.bx}(X0,${N.mul}(D,2654435761)) end;local function mask(K,Q,I,L)local D0=${N.bx}(${N.bx}(${N.mul}(Q+1,0x45D9F3B),${N.mul}(I+1,0x27D4EB2F)),${N.mul}(L+1,0x9E3779B1));local X0=${N.bx}(K,${N.bx}(D0,0xB17E4A31));X0=${N.mul}(${N.bx}(X0,math.floor(X0/65536)),2246822519);X0=${N.mul}(${N.bx}(X0,math.floor(X0/8192)),3266489917);return ${N.bx}(X0,math.floor(X0/65536))%256 end;local function unshard(R)local O={};local used=0;for I=1,#R.ord do local Q=I-1;local L=Q%4;local B=${N.decode85}(R.data[R.ord[I]]);local want=(R.sl and R.sl[I])or#B;if want<0 or want>#B then error("ByteVeil v4.5.0: shard length",0)end;for J=1,want do local P=J-1;local A=mask(R.sm,Q,P,L);local T=mask(${N.bx}(R.sm,0xC0FFEE11),Q,P,L+1);local U=mask(${N.bx}(R.sm,0x7A51BEEF),Q,P,L+2);local V=${N.bx}(B[J]or 0,U);V=(V-T+256)%256;O[#O+1]=${N.bx}(V,A);used=used+1 end end;return O end;local function inverse(B,RS)local O={};local M0,M1,M2,M3=mat(RS,0xB3),mat(RS,0xC7),mat(RS,0xD9),mat(RS,0xEB);local function bm(K,I,L)local D0=(0x51ED2708+${N.mul}(L+1,0x45D9F3B)+${N.mul}(I+1,0x27D4EB2F))%4294967296;return ${N.mix}(K,D0)%256 end;for I=1,#B do local P=I-1;local V=(B[I]+bm(M3,P,3))%256;V=${N.bx}(V,bm(M2,P,2));V=(V-bm(M1,P,1)+256)%256;V=${N.bx}(V,bm(M0,P,0));O[I]=V end;return O end;local function chk(B)local H=17;for I=1,#B do H=(H*65599+B[I]+1)%2147483647 end;return H end;local function resolve(ID)local C=cache[ID];if C then return C,states[ID] end;if visiting[ID] then error("ByteVeil v4.5.0: graph cycle",0)end;local R=byId[ID];if not R then error("ByteVeil v4.5.0: region missing",0)end;visiting[ID]=true;local D=depSeed(R);local RS=rseed(R.id,R.tok,D);local E=unshard(R);if #E~=R.len then error("ByteVeil v4.5.0: region length",0)end;local P=inverse(E,RS);local H=chk(P);if H~=R.chk then error("ByteVeil v4.5.0: region checksum",0)end;local ST=${N.mix}(RS,${N.bx}(H,${N.bx}(R.len,R.tok)));if ST~=R.st then error("ByteVeil v4.5.0: region state",0)end;cache[ID]=P;states[ID]=ST;visiting[ID]=nil;return P,ST end;${v45.resolve}=resolve;for I=1,#G.regions do local R=G.regions[I];byId[R.id]=R;starts[#starts+1]=R.id end;table.sort(starts,function(A,B)return byId[A].start<byId[B].start end);if #starts~=G.n then error("ByteVeil v4.5.0: graph cardinality",0)end;for I=1,#starts do local R=byId[starts[I]];if R.start<0 or R.len<=0 then error("ByteVeil v4.5.0: graph region invalid",0)end;if I>1 then local P=byId[starts[I-1]];if P.start+P.len~=R.start then error("ByteVeil v4.5.0: graph adjacency",0)end else if R.start~=0 then error("ByteVeil v4.5.0: graph origin",0)end end end;${v45.regionFor}=function(P)for I=1,#starts do local R=byId[starts[I]];if P>=R.start and P<R.start+R.len then return R.id end end;return nil end;${v45.byteAt}=function(P)local ID=${v45.regionFor}(P);if ID==nil then return nil end;local B=resolve(ID);return B[P-byId[ID].start+1]end;local GT=${N.mix}(ROOT,${N.bx}(G.shape,${N.bx}(G.ds or 0,G.len)));for I=0,G.n-1 do local R=byId[I];if not R then error("ByteVeil v4.5.0: graph id gap",0)end;GT=${N.mix}(GT,${N.bx}(R.id,${N.bx}(R.start,${N.bx}(R.len,${N.bx}(R.tok,R.chk)))));for J=1,#R.dep do GT=${N.mix}(GT,${N.bx}(R.dep[J],R.id*257))end end;if GT~=G.token then error("ByteVeil v4.5.0: graph integrity",0)end;G.rootSeed=ROOT;G.byId=byId;G.regionFor=${v45.regionFor};G.byteAt=${v45.byteAt};G.resolve=${v45.resolve};G.runtimeToken=GT;return G end`);

    // Graph reader, with lazy constant and instruction materialization.
    const readFn = v45.reader = reserveLocalName(N, "reader");
    lines.push(`local ${readFn}=function(G)local P0=0;local function UAt(P)local V=0;local M=1;while true do local B=G.byteAt(P);if B==nil then error("ByteVeil v4.5.0: truncated IR",0)end;P=P+1;V=V+(B%128)*M;if B<128 then return V,P end;M=M*128;if M>9007199254740992 then error("ByteVeil v4.5.0: varint overflow",0)end end end;local function readU()local V;V,P0=UAt(P0);return V end;local A=${ascii};local function ch(B)if B>=32 and B<=126 then return string.sub(A,B-31,B-31)end;if B==0 then return "\\0" elseif B==7 then return "\\a" elseif B==8 then return "\\b" elseif B==9 then return "\\t" elseif B==10 then return "\\n" elseif B==11 then return "\\v" elseif B==12 then return "\\f" elseif B==13 then return "\\r" end;if B>=0 and B<=255 then return string["ch".."ar"](B)end;error("ByteVeil v4.5.0: invalid string byte",0)end;local function strAt(S,L)local T={};for I=0,L-1 do T[I+1]=ch(G.byteAt(S+I))end;return table.concat(T)end;local H=2166136261;local function shape(V)H=${N.mul}(${N.bx}(H,V),16777619)end;local function chunkRead()local X={};local K=readU();shape(K);X[${C.consts}]={};local C0=X[${C.consts}];for I=1,K do local T=G.byteAt(P0);P0=P0+1;shape(T);if T==83 then local L=readU();local S0=P0;P0=P0+L;C0[I]=function()return strAt(S0,L)end elseif T==78 then local M0=G.byteAt(P0);P0=P0+1;local S0=P0;if M0==0 then local _,P1=UAt(S0);P0=P1;C0[I]=function()local Z;Z=UAt(S0);local V=Z;return(V%2==0)and math.floor(V/2)or-math.floor((V+1)/2)end else local L;L,P0=UAt(P0);local T0=P0;P0=P0+L;C0[I]=function()local T={};for J=0,L-1 do T[J+1]=ch(G.byteAt(T0+J))end;return tonumber(table.concat(T))end end elseif T==84 then C0[I]=function()return true end elseif T==70 then C0[I]=function()return false end elseif T==90 then C0[I]=function()return nil end elseif T==67 then local Child=chunkRead();C0[I]=function()return Child end else error("ByteVeil v4.5.0: constant tag",0)end end;local PC=readU();shape(PC);X[${C.params}]={};for I=1,PC do local L=readU();local S0=P0;P0=P0+L;X[${C.params}][I]=function()return strAt(S0,L)end end;local V=G.byteAt(P0);P0=P0+1;shape(V);X[${C.vararg}]=V==1;local IC=readU();shape(IC);X[${C.code}]={};for I=1,IC do local AC=readU();shape(AC+257);local S0=P0;for J=1,AC do local M0=G.byteAt(P0);P0=P0+1;if M0==0 then local _,P1=UAt(P0);P0=P1 else local L,P1=UAt(P0);P0=P1+L end end;local RID=G.regionFor(S0);X[${C.code}][I]=function()local Q={};local P=S0;for J=1,AC do local M0=G.byteAt(P);P=P+1;if M0==0 then local Z;Z,P=UAt(P);Q[J]=(Z%2==0)and math.floor(Z/2)or-math.floor((Z+1)/2)else local L,P1=UAt(P);P=P1+L;local T={};for W=0,L-1 do T[W+1]=ch(G.byteAt(P1+W))end;Q[J]=tonumber(table.concat(T))end end;Q[AC+1]=RID;return Q end end;return X,H end;local R0,ST=chunkRead();if ST~=G.shape then error("ByteVeil v4.5.0: IR shape mismatch",0)end;return R0 end`);

    // Runtime-generated VM-B: each region + live guard state gets a fresh inverse route.
    lines.push(`local ${N.state}=function(E,V,P,G,F)local S={};S[${S.pc}]=1;S[${S.locals}]={};S[${S.localSet}]={};S[${S.parent}]=P;S[${S.env}]=E;S[${S.consts}]=V;S[${S.code}]=nil;S[${S.halt}]=false;S[${S.ret}]={};S[${S.varargs}]={};S[${S.guard}]=(G or 0)%4294967296;S[${S.fabric}]=(F or G or 0)%4294967296;S[${S.frame}]=0;S[${S.region}]=0;S[${S.microRoutes}]={};${mode === "stack" ? `S[${S.sp}]=0;S[${S.stack}]={};` : `S[${S.reg}]={};`}S[${S.iter}]={};return S end`);
    lines.push(`${N.run}=function(X,P,...)local E=P and P[${S.env}] or ${V.envGuard}();local G0=X[${C.fabric}]or 0;local Q=${N.state}(E,X[${C.consts}],P,G0,G0);Q[${S.code}]=X[${C.code}];local PC0=#(X[${C.params}]or{});Q[${S.varargs}]={select(PC0+1,...)};Q[${S.varargs}].n=math.max(0,select("#",...)-PC0);for I=1,PC0 do local K0=X[${C.params}][I];local K=type(K0)=="function"and K0()or K0;X[${C.params}][I]=K;Q[${S.locals}][K]=select(I,...);Q[${S.localSet}][K]=true end;while not Q[${S.halt}] do local PC=Q[${S.pc}];local F0=Q[${S.code}][PC];local I=F0;if type(F0)=="function" then I=F0();Q[${S.code}][PC]=I end;if not I then Q[${S.halt}]=true;break end;local RID=I[#I];local O=I[1]or 0;local G0BYID=${v45.graph}.byId;local R=G0BYID[RID];if not R then error("ByteVeil v4.5.0: runtime region missing",0)end;${v45.microEnter}(Q,I,R.id);local cache=Q[${S.microRoutes}][RID+1];local inv;local bank;if cache and cache.g==Q[${S.guard}] then inv=cache.i;bank=cache.b else inv,bank=${v45.microRoute}(#${v45.microBank},${N.mix}(Q[${S.guard}],${N.bx}(Q[${S.fabric}],RID)),${v45.microBank});Q[${S.microRoutes}][RID+1]={g=Q[${S.guard}],i=inv,b=bank} end;local route=inv;local logical=R and R.route and R.route[O+1];if logical==nil then error("ByteVeil v4.5.0: region opcode route",0)end;local recipeId=${v45.graph}.recipeIds[logical+1];local recipe=${v45.microRecipes}[recipeId];if not recipe then error("ByteVeil v4.5.0: recipe missing",0)end;Q[${S.pc}]=PC+1;for J=1,#recipe do local base=recipe[J];local H=bank[route[base]];if not H then error("ByteVeil v4.5.0: micro dispatch",0)end;local stop=H(Q,I,R);if stop then break end end end;return ${N.unpackBuiltin}(Q[${S.ret}],1,Q[${S.ret}].n or #Q[${S.ret}])end`);

    // Compatibility API: the methods are real graph operations, not aliases to a single plaintext payload.
    lines.push(`local byteveil={};byteveil.crack=function(ID)local G=${v45.graphRuntime}();return G.resolve(ID)end;byteveil.skid=function(ID)local G=${v45.graphRuntime}();return G.resolve(ID)end;byteveil.time=function(ID)local G=${v45.graphRuntime}();local B=G.resolve(ID);return B end;byteveil.hello=function()return ${v45.graphRuntime}()end`);

    // Decoy state fabric is intentionally coupled to VM-B routing.
    const depth = Math.max(8, Math.min(96, Number(decoyProfile.depth || 24)));
    const decoyFns = Array.from({ length: depth }, (_, i) => reserveLocalName(N, `d${i.toString(36)}`));
    lines.push(`local ${v45.decoyFns}={}`);
    const decoyBodies = [];
    for (let i = 0; i < depth; i++) {
        const next = (i + 1) % depth;
        const alt = (i * 7 + 3) % depth;
        const body = i % 4 === 0
            ? `D.a=${N.bx}(D.a or 0,I+D.f);D.f=(D.f+1)%4294967296`
            : i % 4 === 1
                ? `D.a=${N.mix}(D.a or 0,I*33+D.p);D.p=(D.p%${depth})+1`
                : i % 4 === 2
                    ? `D.g=${N.bx}(D.g or 0,D.a or 0);D.a=${N.mul}(D.a or 0,1664525)%4294967296`
                    : `D.f=${N.mix}(D.f or 0,D.g or 0);D.a=(D.a+I+${i})%4294967296`;
        decoyBodies.push(`function(D,I)${body};if (D.g%3)==0 then return ${v45.decoyFns}[${next+1}] else return ${v45.decoyFns}[${alt+1}] end end`);
    }
    lines.push(`${v45.decoyFns}={${decoyBodies.join(",")}}`);
    lines.push(`local ${v45.decoyState}=function(G)local D={a=${(seed ^ 0xA511E9B3) >>> 0},f=0,g=G,p=1};return D end`);
    lines.push(`local ${v45.decoyRun}=function(G)local D0=${v45.decoyState}(G);local F=${v45.decoyFns}[1];for I=1,${decoyProfile.budget}*${Math.max(4, Math.floor(depth/4))} do F=F(D0,I)or ${v45.decoyFns}[1] end;return ${N.mix}(G,D0.a~=0 and D0.a or 0) end`);

    lines.push(`${N.hookGuard}()`);
    lines.push(`local ${v45.graphRuntime}Result=${v45.graphRuntime}();local ${N.activation}=${v45.decoyRun}(${v45.graphRuntime}Result.rootSeed);${v45.graphRuntime}Result.rootSeed=${N.mix}(${v45.graphRuntime}Result.rootSeed,${N.activation});local ${N.root}=${readFn}(${v45.graphRuntime}Result);${N.root}[${C.fabric}] = ${N.activation};local ${N.result}={${N.run}(${N.root},nil)};${N.activation}=nil;${N.root}=nil;return ${N.unpackBuiltin}(${N.result},1,#${N.result})`);

    let output = lines.join("\n");
    output = output.replace(/\bByteCode\b/g, "ByteVeil");
    if (/string\.char/.test(output)) throw new Error("ByteVeil v4.5.0 generator invariant failed: string.char emitted");
    if (/\\[0-9]{3}/.test(output)) throw new Error("ByteVeil v4.5.0 generator invariant failed: decimal byte escape emitted");

    return {
        output,
        version: "4.5.0",
        layout: "heterogeneous-graph-ir-v450",
        mode,
        stateSlots: S,
        chunkSlots: C,
        opcodeMask: 0,
        payloadByteLength: packed.payloadByteLength,
        regionCount: packed.regionCount,
        regionShards: packed.regionShards,
        regionEntries: packed.regionEntries,
        regionDecoys: packed.regionDecoys,
        transformedOpcodeCount: packed.transformedOpcodeCount,
        vmStages: 6,
        stagedRuntime: true,
        decoyGraph: true,
        decoyCycle: true,
        decoyLanes: 4,
        decoyOpcodeHandlers: opNames.length,
        decoyFrameDepth: depth,
        decoyVmShape: "heterogeneous-graph-ir-v450",
        polymorphicHandlers: true,
        crossLayerIntegrity: true,
        sharedExecutionFabric: true,
        handlerFamilies: 6,
        fragmentGraph: true,
        nonLinearDependencies: true,
        materialDependencyGraph: true,
        opaqueTransportIR: true,
        perRegionOpcodeMapping: true,
        runtimeGeneratedDispatch: true,
        semanticMicroOps: true,
        lazyInstructionMaterialization: true,
        lazyConstantMaterialization: true,
        buildSpecificDiversity: true,
        crossLayerIntegrity: true,
        antiHook: true,
        antiTamper: true,
        antiDump: true,
        decoyDepth: depth,
        decoyBudget: decoyProfile.budget,
        decoyVm: true,
        payloadMaterialization: "fragment-graph-material-dag-opaque-ir-vma-vmb-microop",
        protectionEngine: "Byte-Blinder",
        generatorEngine: "MFG-4.5.0",
        fusedSuper: false,
        sourceReconstruction: false,
        packedBytecode: true,
        randomizedBuild: true,
        decoderVariant
    };
}

// ByteVeil v4.4.0 generator: unified VM/decoy fabric, runtime-first compatibility,
// polymorphic handler lanes, bounded decoy execution and generated access-shape planning.
// Protection state is coupled to payload activation without changing user semantics.

function buildPackedBytecodeSourceV40(bytecode, options = {}) {
    const version = String(options.version || "4.4.0");
    const isV45 = version === "4.5.0" || version === "4.5.4" || version === "4.5.5" || version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || (version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))));
    if (!bytecode || !bytecode.map) throw new TypeError(`${isV45 ? "ByteVeil v4.5.0" : "ByteVeil v4.4.0"} packed VM: invalid bytecode`);
    const seed = Number(options.seed ?? Date.now()) >>> 0;
    const mode = options.mode === "register" ? "register" : "stack";
    const strength = Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000));
    const decoyProfile = options.protectionPlan?.profile || (strength >= 10000 ? { depth: 96, budget: 9, stages: 4 } : strength >= 8000 ? { depth: 64, budget: 7, stages: 4 } : strength >= 3500 ? { depth: 40, budget: 5, stages: 3 } : { depth: 24, budget: 4, stages: 3 });
    const decoderVariant = Number(options.mfgPlan?.decoderFamily ?? (((seed ^ (seed >>> 11) ^ strength) >>> 0) % 4));

    for (const chunk of [bytecode, ...(function flatten(c){
        const out=[];
        for (const v of c?.consts||[]) if(v?.__chunk){out.push(v.__chunk,...flatten(v.__chunk));}
        return out;
    })(bytecode)]) {
        for (const value of chunk.consts || []) {
            if (typeof value !== "string") continue;
            const bytes = Buffer.from(value, "utf8");
            if (!Array.from(bytes).every(v38SupportedStringByte)) {
                throw new Error("ByteVeil v4.4.0 packed VM: non-portable string constant requires source route");
            }
        }
    }

    const asciiAlphabet = Array.from({ length: 95 }, (_, i) => String.fromCharCode(32 + i)).join("");

    // Only the v4.5+ serializers mix the forge latch into region material, so an
    // older route must not see a latch it cannot apply.
    const forgeLatch = isV45 && options.forgeLatch && options.forgeLatch.holder
        ? { holder: String(options.forgeLatch.holder), value: Number(options.forgeLatch.value) >>> 0 }
        : null;
    // The guard verdict the serializer folds in has to come from the same seed the anti
    // bundle will be built with, so it is predicted here rather than in the pipeline.
    // The two version flags mirror the bundle configuration below; buildV452GeneratedSource
    // compares the prediction against the digest of the guard it actually emits and fails
    // the build on any drift, so an unmatched version never silently ships a wrong key.
    const guardFailClosedVersions = new Set(["5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"]);
    const guardEnvBaselineVersions = new Set(["5.4.0", "5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"]);
    const guardLatch = isV45 && options.guardLatch?.enabled === true
        && guardFailClosedVersions.has(version) && guardEnvBaselineVersions.has(version)
        ? predictGuardVerdict({
            seed,
            failClosedOnMissingEnvironment: true,
            baselineFromEnvironment: true
        })
        : null;
    const packed = (isV45 ? encodeBytecodeBlobV45 : encodeBytecodeBlob)(bytecode, seed, {
        strength,
        mode,
        opcodeWhitening: options.opcodeWhitening !== false,
        hardeningVersion: version,
        stringCipher: options.stringCipher !== false,
        forgeLatch,
        guardLatch
    });

    const opNames = Array.isArray(bytecode.opcode) ? bytecode.opcode.slice() : [];
    if (!opNames.length) throw new Error(`${isV45 ? "ByteVeil v4.5.x" : "ByteVeil v4.4.0"} packed VM: empty opcode set`);

    const vmPersonality = (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || (version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))))) ? buildV46Personality(seed, mode, version) : buildV455Personality(seed, mode);
    const stateNames = vmPersonality.stateOrder;
    const S = v38Slots(seed ^ vmPersonality.stateSalt ^ 0xB80A51, stateNames);
    const C = v38Slots(seed ^ 0xB80A52, ["params","consts","code","vararg","shape","fabric"]);
    const N = {
        bx: v38Id(seed ^ 0x11A1), mul: v38Id(seed ^ 0x11A2), xor: v38Id(seed ^ 0x11A3),
        decode85: v38Id(seed ^ 0x11A4), unpack: v38Id(seed ^ 0x11A5),
        read: v38Id(seed ^ 0x11A6), fromBytes: v38Id(seed ^ 0x11A7),
        checksum: v38Id(seed ^ 0x11A8), parse: v38Id(seed ^ 0x11A9), state: v38Id(seed ^ 0x11AA),
        run: v38Id(seed ^ 0x11AB), handlers: v38Id(seed ^ 0x11AC),
        root: v38Id(seed ^ 0x11AD), result: v38Id(seed ^ 0x11AE), blob: v38Id(seed ^ 0x11AF),
        order: v38Id(seed ^ 0x11B0), alphabet: v38Id(seed ^ 0x11B1), ascii: v38Id(seed ^ 0x11B2), unpackBuiltin: v38Id(seed ^ 0x11B3),
        args: v38Id(seed ^ 0x11C0), fn: v38Id(seed ^ 0x11C1), ret: v38Id(seed ^ 0x11C2),
        iterator: v38Id(seed ^ 0x11C3), payload: v38Id(seed ^ 0x11C4), raw: v38Id(seed ^ 0x11C5),
        stageA: v38Id(seed ^ 0x11C6), stageB: v38Id(seed ^ 0x11C7), gate: v38Id(seed ^ 0x11C8), hookGuard: v38Id(seed ^ 0x11C9),
        antiTamper: v38Id(seed ^ 0x11CA), shape: v38Id(seed ^ 0x11CB), fabric: v38Id(seed ^ 0x11CC),
        route0: v38Id(seed ^ 0x11CD), route1: v38Id(seed ^ 0x11CE), route2: v38Id(seed ^ 0x11CF), route3: v38Id(seed ^ 0x11D0), handlers0: v38Id(seed ^ 0x11D1), handlers1: v38Id(seed ^ 0x11D2), handlers2: v38Id(seed ^ 0x11D3), handlers3: v38Id(seed ^ 0x11D4),
        decoyFns: v38Id(seed ^ 0x11D5), decoyRun: v38Id(seed ^ 0x11D6), superFns: v38Id(seed ^ 0x11D7),
        variant: v38Id(seed ^ 0x11D8), activation: v38Id(seed ^ 0x11D9), material1: v38Id(seed ^ 0x11DB), material2: v38Id(seed ^ 0x11DC), material3: v38Id(seed ^ 0x11DD), material4: v38Id(seed ^ 0x11DE), const: v38Id(seed ^ 0x11DA),
        mix: v38Id(seed ^ 0x11E0), materials: v38Id(seed ^ 0x11E1), envelope: v38Id(seed ^ 0x11E2), transportSeed: v38Id(seed ^ 0x11E3), transportMask: v38Id(seed ^ 0x11E4), shardSeed: v38Id(seed ^ 0x11E5), permute: v38Id(seed ^ 0x11E6), body: v38Id(seed ^ 0x11E7), meta: v38Id(seed ^ 0x11E8), resolveGlobal: v38Id(seed ^ 0x11E9), writeGlobal: v38Id(seed ^ 0x11EA), runtimeGuard: v38Id(seed ^ 0x11EB),
        h: {}, h2: {}, h3: {}, hv: {}
    };

    const hName = (op, i) => v38Id(seed ^ ((i + 1) * 0x45D9F3B) ^ opNames[i].split("").reduce((a, c) => ((a * 33) ^ c.charCodeAt(0)) >>> 0, 5381), "h");

    // Generated identifiers are randomized but must also be collision-safe.
    // A rare PRNG collision must never turn one local table/function into another.
    const usedGeneratedNames = new Set(["__bv_type","__bv_byte","__bv_concat","__bv_find","__bv_sub","__bv_floor","__bv_load","__bv_pcall","__bv_tostring"]);
    const reserveGeneratedName = (base) => {
        let candidate = String(base);
        let suffix = 0;
        while (usedGeneratedNames.has(candidate)) candidate = `${base}_${(++suffix).toString(36)}`;
        usedGeneratedNames.add(candidate);
        return candidate;
    };
    for (const key of Object.keys(N)) {
        if (typeof N[key] === "string") N[key] = reserveGeneratedName(N[key]);
    }
    for (const op of opNames) {
        const raw = hName(op, opNames.indexOf(op));
        N.h[op] = reserveGeneratedName(raw);
        N.hv[op] = reserveGeneratedName(`${N.h[op]}_v`);
        N.h2[op] = reserveGeneratedName(`${N.h[op]}_a`);
        N.h3[op] = reserveGeneratedName(`${N.h[op]}_b`);
    }

    const opCount = opNames.length;
    const routes = options.mfgPlan?.handlerRoutes || {
        slot0: Object.fromEntries(opNames.map((op, i) => [op, i + 1])),
        slot1: Object.fromEntries(opNames.map((op, i) => [op, i + 1])),
        slot2: Object.fromEntries(opNames.map((op, i) => [op, i + 1])),
        slot3: Object.fromEntries(opNames.map((op, i) => [op, i + 1]))
    };
    const variantMask = Array.isArray(options.mfgPlan?.variantMask) ? options.mfgPlan.variantMask : opNames.map(() => 0);
    const handlerMul = 1;
    const handlerAdd = 0;

    const body = (text, identity = "instruction") => mode === "stack" ? stackHandler("", text, { seed, identity: `instruction-${identity}` }) : registerHandler("", text, { seed, identity: `instruction-${identity}` });

    const st = (field) => `S[${S[field]}]`;
    const ch = (field, base = "X") => `${base}[${C[field]}]`;
    const opIndex0 = (op) => Number(routes.slot0?.[op] || 1);
    const opIndex1 = (op) => Number(routes.slot1?.[op] || 1);
    const opIndex2 = (op) => Number(routes.slot2?.[op] || 1);
    const opIndex3 = (op) => Number(routes.slot3?.[op] || 1);

    const handlers = {
        HALT: `S[${S.halt}]=true;return true`,
        PUSHK: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=${N.const}(S,I[2])`,
        PUSHN: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=I[2]`,
        PUSHB: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=I[2]~=0`,
        PUSHNIL: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=nil`,
        GETG: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=${N.resolveGlobal}(S,I[2])`,
        SETG: `${N.writeGlobal}(S,I[2],S[${S.stack}][S[${S.sp}]]);S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        GETL: `local T=S;local Q=${N.const}(S,I[2]);while T do if T[${S.localSet}][Q] then S[${S.stack}][S[${S.sp}]+1]=T[${S.locals}][Q];S[${S.sp}]=S[${S.sp}]+1;return end;T=T[${S.parent}] end;S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=nil`,
        SETL: `local T=S;local Q=${N.const}(S,I[2]);while T and not T[${S.localSet}][Q] do T=T[${S.parent}] end;if not T then T=S;T[${S.localSet}][Q]=true end;T[${S.locals}][Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        GETI: `local Q=S[${S.stack}][S[${S.sp}]];local A=S[${S.stack}][S[${S.sp}]-1];S[${S.stack}][S[${S.sp}]-1]=A[Q];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        SETI: `local V=S[${S.stack}][S[${S.sp}]];local Q=S[${S.stack}][S[${S.sp}]-1];local A=S[${S.stack}][S[${S.sp}]-2];A[Q]=V;S[${S.stack}][S[${S.sp}]]=nil;S[${S.stack}][S[${S.sp}]-1]=nil;S[${S.sp}]=S[${S.sp}]-2`,
        ADD: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]+B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        SUB: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]-B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        MUL: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]*B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        DIV: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]/B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        IDIV: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]//B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        MOD: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]%B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        POW: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]^B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        EQ: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]==B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        NE: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]~=B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        LT: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]<B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        GT: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]>B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        LE: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]<=B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        GE: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]>=B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        NOT: `S[${S.stack}][S[${S.sp}]]=not S[${S.stack}][S[${S.sp}]]`,
        NEG: `S[${S.stack}][S[${S.sp}]]=-S[${S.stack}][S[${S.sp}]]`,
        LEN: `S[${S.stack}][S[${S.sp}]]=#S[${S.stack}][S[${S.sp}]]`,
        CONCAT: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1]..B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        AND: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1] and B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        OR: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=S[${S.stack}][S[${S.sp}]-1] or B;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        BAND: `local A0=S[${S.stack}][S[${S.sp}]-1];local B0=S[${S.stack}][S[${S.sp}]];A0=math.floor(A0)%4294967296;B0=math.floor(B0)%4294967296;S[${S.stack}][S[${S.sp}]-1]=math.floor((A0+B0-${N.xor}(A0,B0))/2);S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        BOR: `local A0=S[${S.stack}][S[${S.sp}]-1];local B0=S[${S.stack}][S[${S.sp}]];A0=math.floor(A0)%4294967296;B0=math.floor(B0)%4294967296;local H=math.floor((A0+B0-${N.xor}(A0,B0))/2);S[${S.stack}][S[${S.sp}]-1]=A0+B0-H;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        BXOR: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=${N.xor}(S[${S.stack}][S[${S.sp}]-1],B);S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        SHL: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=bit32 and bit32.lshift and bit32.lshift(S[${S.stack}][S[${S.sp}]-1],B) or math.floor((S[${S.stack}][S[${S.sp}]-1]*2^B)%4294967296);S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        SHR: `local B=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]-1]=bit32 and bit32.rshift and bit32.rshift(S[${S.stack}][S[${S.sp}]-1],B) or math.floor((S[${S.stack}][S[${S.sp}]-1]%4294967296)/2^B);S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        BNOT: `local V=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=-1-${N.xor}(V,4294967295)`,
        JMP: `S[${S.pc}]=I[2]+1`,
        JZ: `local V=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1;if not V then S[${S.pc}]=I[2]+1 end`,
        POP: `S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`,
        DUP: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=S[${S.stack}][S[${S.sp}]-1]`,
        NEWTABLE: `local N0=I[2]or 0;S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=N0>0 and {${N.unpackBuiltin}({},1,N0)} or {}`,
        CALL: `local C0=I[2];local A0={};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local F0=S[${S.stack}][S[${S.sp}]];local R0={F0(${N.unpackBuiltin}(A0,1,C0))};S[${S.stack}][S[${S.sp}]]=R0[1]`,
        CALLG: `local C0=I[3] or 0;local A0={};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local F0=${N.resolveGlobal}(S,I[2]);local R0={F0(${N.unpackBuiltin}(A0,1,C0))};S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=R0[1]`,
        CALLM: `local C0=I[2];local A0={};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local F0=S[${S.stack}][S[${S.sp}]];local R0={F0(${N.unpackBuiltin}(A0,1,C0))};local C1=I[3] or 1;S[${S.stack}][S[${S.sp}]]=R0[1];for Q=2,C1 do S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=R0[Q] end`,
        CALLGM: `local C0=I[3] or 0;local A0={n=C0};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local F0=${N.resolveGlobal}(S,I[2]);local R0={F0(${N.unpackBuiltin}(A0,1,C0))};local C1=I[4] or 1;for Q=1,C1 do S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=R0[Q] end`,
        CALLV: `local C0=I[2] or 0;local P0=S[${S.stack}][S[${S.sp}]] or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1;local A0={};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q] end;A0.n=C0+VN;local F0=S[${S.stack}][S[${S.sp}]];local R0={F0(${N.unpackBuiltin}(A0,1,A0.n))};S[${S.stack}][S[${S.sp}]]=R0[1]`,
        CALLGV: `local C0=I[3] or 0;local P0=S[${S.stack}][S[${S.sp}]] or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1;local A0={};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q] end;A0.n=C0+VN;local F0=${N.resolveGlobal}(S,I[2]);local R0={F0(${N.unpackBuiltin}(A0,1,A0.n))};S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=R0[1]`,
        CALLP: `local C0=I[4]or 0;local SP0=I[5]==1;local P0={n=0};if SP0 then P0=S[${S.stack}][S[${S.sp}]]or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local A0={n=C0};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q]end;A0.n=C0+VN;local F0;if I[2]==1 then F0=${N.resolveGlobal}(S,I[3])else F0=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local function KP0(...)return {n=select("#",...),...}end;local T0=KP0(F0(${N.unpackBuiltin}(A0,1,A0.n)));S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=T0`,
        APPEND: `local P0=S[${S.stack}][S[${S.sp}]]or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1;local T0=S[${S.stack}][S[${S.sp}]];local B0=I[2];local VN=P0.n or #P0;local H0=false;for Q=1,VN do if P0[Q]==nil then H0=true;break end end;if H0 and VN>0 then local Z0={};for Q=1,B0-1 do Z0[Q]=T0[Q]end;for Q=1,VN do Z0[B0-1+Q]=P0[Q]end;local M0={${N.unpackBuiltin}(Z0,1,B0-1+VN)};local K0,W0=next(T0);while K0 do if not (type(K0)=="number" and K0>=1 and K0<=B0-1) then M0[K0]=W0 end K0,W0=next(T0,K0)end;S[${S.stack}][S[${S.sp}]]=M0 else for Q=1,VN do T0[B0+Q-1]=P0[Q]end end`,
        TAILCALL: `local K0=I[2]or 0;local V0=I[3];local C0=I[4]or 0;local C1=I[5]or 0;local SP0=I[6]==1;local P0={n=0};if SP0 then P0=S[${S.stack}][S[${S.sp}]]or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local A0={n=C0};for Q=C0,1,-1 do A0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;local VN=P0.n or #P0;for Q=1,VN do A0[C0+Q]=P0[Q]end;A0.n=C0+VN;local F0;if K0==1 then F0=${N.resolveGlobal}(S,V0)else F0=S[${S.stack}][S[${S.sp}]]end;local function PK0(...)return {n=select("#",...),...}end;local T0=PK0(F0(${N.unpackBuiltin}(A0,1,A0.n)));local R0={n=C1+(T0.n or 0)};for Q=1,C1 do R0[Q]=S[${S.stack}][Q]end;for Q=1,(T0.n or 0)do R0[C1+Q]=T0[Q]end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        RETURN: `local C0=I[2];local R0={n=C0};for Q=C0,1,-1 do R0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        RETURNV: `local C0=I[2] or 0;local P0=S[${S.stack}][S[${S.sp}]] or {n=0};S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1;local VN=P0.n or #P0;local R0={n=C0+VN};for Q=C0,1,-1 do R0[Q]=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1 end;for Q=1,VN do R0[C0+Q]=P0[Q] end;S[${S.halt}]=true;S[${S.ret}]=R0;return true`,
        MAKEFUNC: `local X0=${N.const}(S,I[2]);local P0=S;S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=function(...)return ${N.run}(X0,P0,...)end`,
        VARARG: `S[${S.sp}]=S[${S.sp}]+1;local A0=S[${S.varargs}] or {};S[${S.stack}][S[${S.sp}]]=A0[1]`,
        VARARGS: `S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=S[${S.varargs}] or {n=0}`,
        BREAK: `S[${S.halt}]=true;return true`,
        SWAP: `local A0=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=S[${S.stack}][S[${S.sp}]-1];S[${S.stack}][S[${S.sp}]-1]=A0`,
        MOVE_SELF: `local A0=S[${S.stack}][S[${S.sp}]-1];S[${S.sp}]=S[${S.sp}]+1;S[${S.stack}][S[${S.sp}]]=A0`,
        FORCMP: `local ST=S[${S.stack}][S[${S.sp}]];local LM=S[${S.stack}][S[${S.sp}]-1];local IX=S[${S.stack}][S[${S.sp}]-2];local OK=(ST>=0 and IX<=LM)or(ST<0 and IX>=LM);S[${S.stack}][S[${S.sp}]-2]=OK;S[${S.stack}][S[${S.sp}]]=nil;S[${S.stack}][S[${S.sp}]-1]=nil;S[${S.sp}]=S[${S.sp}]-2`,
        SETFIELD: `local V=S[${S.stack}][S[${S.sp}]];local A0=S[${S.stack}][S[${S.sp}]-2];A0[I[2]]=V;S[${S.stack}][S[${S.sp}]]=nil;S[${S.stack}][S[${S.sp}]-1]=nil;S[${S.sp}]=S[${S.sp}]-2`,
        GETFIELD: `local A0=S[${S.stack}][S[${S.sp}]];S[${S.stack}][S[${S.sp}]]=A0[I[3]]`,
        ITERPREP: `local C0=I[2] or 0;local B=S[${S.sp}]-C0+1;local T0={S[${S.stack}][B],S[${S.stack}][B+1],S[${S.stack}][B+2]};if type(T0[1])=="table" then T0={next,T0[1],nil} end;for Q=0,C0-1 do S[${S.stack}][B+Q]=nil end;S[${S.sp}]=B-1;S[${S.iter}][#S[${S.iter}]+1]=T0`,
        ITERLOOP: `local T0=S[${S.iter}][#S[${S.iter}]];if not T0 or type(T0[1])~="function" then S[${S.iter}][#S[${S.iter}]]=nil;S[${S.pc}]=I[2]+1;return end;local A0={T0[1](T0[2],T0[3])};if A0[1]==nil then S[${S.iter}][#S[${S.iter}]]=nil;S[${S.pc}]=I[2]+1;return end;T0[3]=A0[1];for Q=1,(I[3] or 0) do local N0=${N.const}(S,I[3+Q]);local V0=A0[Q];S[${S.locals}][N0]=V0;S[${S.localSet}][N0]=true end`,
        SUPER: `local F=${N.superFns}[I[2]];if not F then error("ByteVeil SUPER dispatch failed",0)end;return F(S,I)`,
    };

    const { buildV580RegisterHandlerDefs } = require("../register/reg_vm_generator");
    const regHandlers = buildV580RegisterHandlerDefs(S, N, seed);

    const altHandlers = mode === "stack" ? {
        PUSHK: `local K=${N.const}(S,I[2]);local P=S[${S.sp}]+1;S[${S.sp}]=P;S[${S.stack}][P]=K`,
        PUSHN: `local P=S[${S.sp}]+1;S[${S.sp}]=P;S[${S.stack}][P]=I[2]`,
        GETG: `local N0=${N.const}(S,I[2]);local P=S[${S.sp}]+1;S[${S.sp}]=P;S[${S.stack}][P]=S[${S.env}][N0]`,
        SETG: `local P=S[${S.sp}];local N0=${N.const}(S,I[2]);local V0=S[${S.stack}][P];S[${S.env}][N0]=V0;S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        GETI: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local K0=S[${S.stack}][P];S[${S.stack}][P-1]=A0[K0];S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        SETI: `local P=S[${S.sp}];local V0=S[${S.stack}][P];local K0=S[${S.stack}][P-1];local A0=S[${S.stack}][P-2];A0[K0]=V0;S[${S.stack}][P]=nil;S[${S.stack}][P-1]=nil;S[${S.sp}]=P-2`,
        ADD: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local B0=S[${S.stack}][P];S[${S.stack}][P-1]=B0+A0;S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        SUB: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local B0=S[${S.stack}][P];local R0=A0-B0;S[${S.stack}][P-1]=R0;S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        MUL: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local B0=S[${S.stack}][P];S[${S.stack}][P-1]=B0*A0;S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        EQ: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local B0=S[${S.stack}][P];S[${S.stack}][P-1]=(A0==B0);S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        NE: `local P=S[${S.sp}];local A0=S[${S.stack}][P-1];local B0=S[${S.stack}][P];S[${S.stack}][P-1]=(A0~=B0);S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        POP: `local P=S[${S.sp}];S[${S.stack}][P]=nil;S[${S.sp}]=P-1`,
        DUP: `local P=S[${S.sp}]+1;S[${S.sp}]=P;S[${S.stack}][P]=S[${S.stack}][P-1]`,
        NEWTABLE: `local P=S[${S.sp}]+1;S[${S.sp}]=P;local N0=I[2]or 0;local T0=N0>0 and {${N.unpackBuiltin}({},1,N0)} or {};S[${S.stack}][P]=T0`,
        NOT: `local P=S[${S.sp}];local V0=S[${S.stack}][P];S[${S.stack}][P]=(not V0)`,
        NEG: `local P=S[${S.sp}];local V0=S[${S.stack}][P];S[${S.stack}][P]=-V0`,
        LEN: `local P=S[${S.sp}];local V0=S[${S.stack}][P];S[${S.stack}][P]=#V0`,
        JMP: `local T0=I[2];S[${S.pc}]=T0+1`,
        JZ: `local P=S[${S.sp}];local V0=S[${S.stack}][P];S[${S.stack}][P]=nil;S[${S.sp}]=P-1;if not V0 then S[${S.pc}]=I[2]+1 end`,
    } : {
        PUSHK: `local K=${N.const}(S,I[3]);S[${S.reg}][I[2]]=K`,
        PUSHN: `local V0=I[3];S[${S.reg}][I[2]]=V0`,
        GETG: `local N0=${N.const}(S,I[3]);local V0=S[${S.env}][N0];S[${S.reg}][I[2]]=V0`,
        SETG: `local N0=${N.const}(S,I[2]);local V0=S[${S.reg}][I[3]];S[${S.env}][N0]=V0`,
        GETI: `local A0=S[${S.reg}][I[3]];local K0=S[${S.reg}][I[4]];S[${S.reg}][I[2]]=A0[K0]`,
        SETI: `local A0=S[${S.reg}][I[2]];local K0=S[${S.reg}][I[3]];local V0=S[${S.reg}][I[4]];A0[K0]=V0`,
        ADD: `local A0=S[${S.reg}][I[3]];local B0=S[${S.reg}][I[4]];local R0=B0+A0;S[${S.reg}][I[2]]=R0`,
        SUB: `local A0=S[${S.reg}][I[3]];local B0=S[${S.reg}][I[4]];local R0=A0-B0;S[${S.reg}][I[2]]=R0`,
        MUL: `local A0=S[${S.reg}][I[3]];local B0=S[${S.reg}][I[4]];S[${S.reg}][I[2]]=B0*A0`,
        EQ: `local A0=S[${S.reg}][I[3]];local B0=S[${S.reg}][I[4]];S[${S.reg}][I[2]]=(A0==B0)`,
        NE: `local A0=S[${S.reg}][I[3]];local B0=S[${S.reg}][I[4]];S[${S.reg}][I[2]]=(A0~=B0)`,
        POP: `local R0=I[2];S[${S.reg}][R0]=nil`,
        DUP: `local R0=I[2];local V0=S[${S.reg}][I[3]];S[${S.reg}][R0]=V0`,
        NEWTABLE: `local N0=I[3]or 0;local T0=N0>0 and {${N.unpackBuiltin}({},1,N0)} or {};S[${S.reg}][I[2]]=T0`,
        NOT: `local V0=S[${S.reg}][I[3]];S[${S.reg}][I[2]]=not V0`,
        NEG: `local V0=S[${S.reg}][I[3]];S[${S.reg}][I[2]]=-V0`,
        LEN: `local V0=S[${S.reg}][I[3]];S[${S.reg}][I[2]]=#V0`,
        JMP: `local T0=I[2];S[${S.pc}]=T0+1`,
        JZ: `local V0=S[${S.reg}][I[2]];if not V0 then S[${S.pc}]=I[3]+1 end`,
    };

    const variant = ((seed ^ 0x7F4A7C15) >>> 0) & 3;
    if (mode === "stack") {
        if (variant & 1) handlers.ADD = `local A=S[${S.stack}][S[${S.sp}]-1];local B=S[${S.stack}][S[${S.sp}]];local R=A+B;S[${S.stack}][S[${S.sp}]-1]=R;S[${S.stack}][S[${S.sp}]]=nil;S[${S.sp}]=S[${S.sp}]-1`;
    } else {
        if (variant & 1) regHandlers.ADD = `local A=S[${S.reg}][I[3]];local B=S[${S.reg}][I[4]];S[${S.reg}][I[2]]=A+B`;
    }
    const defs = mode === "stack" ? handlers : regHandlers;
    if (isV45) {
        // v4.6.6 uses the explicit packed-bytecode VMA/VMB backend, which owns
        // the active handler table (including multireturn-safe vararg opcodes).
        // Keep the older generator paths unchanged for historical releases.
        const generated = (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || (version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))))
            ? buildV452GeneratedSource(bytecode, { seed, mode, strength, decoyProfile, decoderVariant, opNames, S, C, N, defs, packed, vmPersonality, runtimeBridgeParam: options.runtimeBridgeParam || null, forgeLatch, guardLatch })
            : buildV45GeneratedSource(bytecode, { seed, mode, strength, decoyProfile, decoderVariant, opNames, S, C, N, defs, packed, vmPersonality, forgeLatch, guardLatch });
        if (version === "4.5.4" || version === "4.5.5" || version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || (version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))))) {
            if (version === "4.7.7") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.7").replace(/v4\.6\.4/g, "v4.7.7").replace(/v4\.6\.5/g, "v4.7.7").replace(/v4\.6\.6/g, "v4.7.7").replace(/v4\.6\.7/g, "v4.7.7").replace(/v4\.6\.8/g, "v4.7.7").replace(/v4\.7\.1/g, "v4.7.7").replace(/v4\.7\.2/g, "v4.7.7").replace(/v4\.7\.3/g, "v4.7.7").replace(/v4\.7\.4/g, "v4.7.7").replace(/v4\.7\.5/g, "v4.7.7").replace(/v4\.7\.6/g, "v4.7.7");
            } else if (version === "4.7.6") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.6").replace(/v4\.6\.4/g, "v4.7.6").replace(/v4\.6\.5/g, "v4.7.6").replace(/v4\.6\.6/g, "v4.7.6").replace(/v4\.6\.7/g, "v4.7.6").replace(/v4\.6\.8/g, "v4.7.6").replace(/v4\.7\.1/g, "v4.7.6").replace(/v4\.7\.2/g, "v4.7.6").replace(/v4\.7\.3/g, "v4.7.6").replace(/v4\.7\.4/g, "v4.7.6").replace(/v4\.7\.5/g, "v4.7.6");
            } else if (version === "4.7.5") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.5").replace(/v4\.6\.4/g, "v4.7.5").replace(/v4\.6\.5/g, "v4.7.5").replace(/v4\.6\.6/g, "v4.7.5").replace(/v4\.6\.7/g, "v4.7.5").replace(/v4\.6\.8/g, "v4.7.5").replace(/v4\.7\.1/g, "v4.7.5").replace(/v4\.7\.2/g, "v4.7.5").replace(/v4\.7\.3/g, "v4.7.5").replace(/v4\.7\.4/g, "v4.7.5");
            } else if (version === "4.7.4") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.4").replace(/v4\.6\.4/g, "v4.7.4").replace(/v4\.6\.5/g, "v4.7.4").replace(/v4\.6\.6/g, "v4.7.4").replace(/v4\.6\.7/g, "v4.7.4").replace(/v4\.6\.8/g, "v4.7.4").replace(/v4\.7\.1/g, "v4.7.4").replace(/v4\.7\.2/g, "v4.7.4").replace(/v4\.7\.3/g, "v4.7.4");
            } else if (version === "4.7.3") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.3").replace(/v4\.6\.4/g, "v4.7.3").replace(/v4\.6\.5/g, "v4.7.3").replace(/v4\.6\.6/g, "v4.7.3").replace(/v4\.6\.7/g, "v4.7.3").replace(/v4\.6\.8/g, "v4.7.3").replace(/v4\.7\.1/g, "v4.7.3").replace(/v4\.7\.2/g, "v4.7.3");
            } else if (version === "4.7.2") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.2").replace(/v4\.6\.4/g, "v4.7.2").replace(/v4\.6\.5/g, "v4.7.2").replace(/v4\.6\.6/g, "v4.7.2").replace(/v4\.6\.7/g, "v4.7.2").replace(/v4\.6\.8/g, "v4.7.2").replace(/v4\.7\.1/g, "v4.7.2");
            } else if (version === "4.7.1") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.7.1").replace(/v4\.6\.4/g, "v4.7.1").replace(/v4\.6\.5/g, "v4.7.1").replace(/v4\.6\.6/g, "v4.7.1").replace(/v4\.6\.7/g, "v4.7.1").replace(/v4\.6\.8/g, "v4.7.1");
            } else if (version === "4.6.8") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.6.8").replace(/v4\.6\.4/g, "v4.6.8").replace(/v4\.6\.5/g, "v4.6.8").replace(/v4\.6\.6/g, "v4.6.8").replace(/v4\.6\.7/g, "v4.6.8");
            } else if (version === "4.6.7") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.6.7").replace(/v4\.6\.4/g, "v4.6.7").replace(/v4\.6\.5/g, "v4.6.7").replace(/v4\.6\.6/g, "v4.6.7");
            } else if (version === "4.6.6") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.6.6").replace(/v4\.6\.4/g, "v4.6.6").replace(/v4\.6\.5/g, "v4.6.6");
            } else if (version === "4.6.5") {
                generated.output = generated.output.replace(/v4\.6\.3/g, "v4.6.5").replace(/v4\.6\.4/g, "v4.6.5");
            }
            // v4.7.3 remains historical. v4.7.5 removes source-to-loader nested stages: the active
            // protection lives in binary graph regions and the VM, not in repeatedly compiled source.
            if ((version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")))) {
                const isV590 = version === "5.9.0";
                const isV580 = version === "5.8.0";
                const isV570 = version === "5.7.0";
                const isV560 = version === "5.6.0";
                const isV560OrLater = isV560 || isV570 || isV580 || isV590;
                const isV550 = version === "5.5.0" || isV560OrLater;
                const isV540 = version === "5.4.0" || isV550;
                const isV530 = version === "5.3.0";
                const is51BuildDiverse = isV530 || isV540;
                const is500 = version === "5.0.0";
                const is5x = is500 || is51BuildDiverse;
                const versionTag = `v${version}`;
                generated.output = generated.output
                    .replace(/v4\.6\.3/g, versionTag).replace(/v4\.6\.4/g, versionTag)
                    .replace(/v4\.6\.5/g, versionTag).replace(/v4\.6\.6/g, versionTag)
                    .replace(/v4\.6\.7/g, versionTag).replace(/v4\.6\.8/g, versionTag)
                    .replace(/v4\.7\.1/g, versionTag).replace(/v4\.7\.2/g, versionTag)
                    .replace(/v4\.7\.3/g, versionTag).replace(/v4\.7\.4/g, versionTag)
                    .replace(/v4\.7\.5/g, versionTag).replace(/v4\.7\.6/g, versionTag)
                    .replace(/v4\.7\.7/g, versionTag).replace(/v4\.7\.8/g, versionTag);
                // Runtime failures retain their semantics but no longer expose the
                // product/version prefix. The file watermark is added separately and stays intact.
                generated.output = generated.output.replace(/"ByteVeil v4\.[^":]*: /g, '"');
                const is479 = version === "4.7.9" || is5x;
                const layout = isV570 ? "hybrid-function-policy-veilsync-v2-all-region-verified-callable-bootstrap-position-keyed-striped-payload-vm-v57" : isV560 ? "hybrid-function-policy-veilsync-v2-all-region-verified-shadow-local-mangled-position-keyed-striped-payload-vm-v56" : isV550 ? "hybrid-function-policy-veilsync-shadow-local-mangled-position-keyed-striped-payload-vm-v55" : isV540 ? "hybrid-function-policy-build-diverse-shadow-local-mangled-position-keyed-striped-payload-vm-v54" : isV530 ? "hybrid-function-policy-build-diverse-position-keyed-striped-payload-vm-v51" : is500 ? "hybrid-function-policy-position-keyed-striped-payload-vm-v5" : is479 ? "hybrid-function-policy-striped-payload-vm-v479" : "hybrid-function-policy-binary-region-vm-v478-semantic-shadow";
                const payloadMaterialization = isV590 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : isV580 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.8-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : isV570 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.7-callable-bootstrap-region-verified" : isV560 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-veilsync-v2-all-region-verified-shadow-local-mangled" : isV550 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-veilsync-shadow-local-mangled" : isV540 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-shadow-local-mangled" : isV530 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse" : is500 ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5" : is479 ? "striped-payload-lanes-packed-descriptor-lazy-region-v479" : "hybrid-function-policy-binary-region-vm-v478";
                if (is5x) generated.output = generated.output.replace(/v4\.7\.9/g, versionTag).replace(/v4\.7\.8/g, versionTag).replace(/v4\.7\.[1-7]/g, versionTag).replace(/v4\.6\.[1-8]/g, versionTag).replace(/v5\.0\.0/g, versionTag);
                return { ...generated, output: generated.output, version, layout, vmStages: Number(generated.vmStages || 7), nestedObfuscation: false, nestedObfuscationLayers: 0, nestedCodecs: [], nestedCompression: null, nestedCompressedLayers: 0, nestedCompressionBytesSaved: 0, heterogeneousNestedLayers: false, antiTamperLayers: Number(generated.antiTamperLayers || 0), antiHookLayers: Number(generated.antiHookLayers || 0), antiDumpLayers: Number(generated.antiDumpLayers || 0), antiHook: generated.antiHook === true, antiTamper: generated.antiTamper === true, antiDump: generated.antiDump === true, antiIntegration: generated.antiIntegration || null, antiTamperChecksum: generated.antiTamperChecksum || null, crossLayerIntegrity: generated.crossLayerIntegrity === true && Number(generated.antiTamperLayers || 0) > 0, intraVmIntegrity: true, singleLayerEngine: true, runtimeSourceLoaderCount: 0, sourceLoaderStages: 0, payloadTransformLayers: 8, nativeBufferRuntime: true, shadowVm: true, shadowInterleaved: true, shadowInstructionCount: Number(generated.shadowInstructionCount || 0), shadowHandlerCount: Number(generated.shadowHandlerCount || 0), shadowStepsPerRealInstruction: Number(generated.shadowStepsPerRealInstruction || 0), shadowDispatchStyle: generated.shadowDispatchStyle || "per-build-exact-isa-map-runtime-opcode-plus-randomized-binary-decoy-rows", shadowTraceOpcodeCount: Number(generated.shadowTraceOpcodeCount || 0), shadowOperandTraceDerived: generated.shadowOperandTraceDerived === true, shadowLiveOpcodeCoupled: generated.shadowLiveOpcodeCoupled === true, shadowTraceInterleaveRatio: generated.shadowTraceInterleaveRatio || null, shadowFingerprint: generated.shadowFingerprint || null, shadowArchitecture: isV590 ? "semantic-handler-sandbox-v59-shared-dispatch-core-veilsync-v2-region-verified" : isV580 ? "semantic-handler-sandbox-v58-shared-dispatch-core-veilsync-v2-region-verified" : isV570 ? "semantic-handler-sandbox-v57-callable-bootstrap-veilsync-v2-region-verified" : isV560 ? "semantic-handler-sandbox-v56-local-mangled-veilsync-v2-region-verified" : isV550 ? "semantic-handler-sandbox-v55-local-mangled-veilsync" : isV540 ? "semantic-handler-sandbox-v54-local-mangled" : isV530 ? "semantic-handler-sandbox-v51-build-diverse" : (generated.shadowArchitecture || (is500 ? "semantic-handler-sandbox-v5" : is479 ? "semantic-handler-sandbox-v479" : "semantic-handler-sandbox-v478")), shadowStaticSourceTrace: false, shadowSemanticHandlerCount: Number(generated.shadowSemanticHandlerCount || 0), shadowSemanticHandlerCoverage: Number(generated.shadowSemanticHandlerCoverage || 0), shadowMissingSemanticHandlers: generated.shadowMissingSemanticHandlers || [], generatorEngine: isV590 ? "MFG-5.9.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : isV580 ? "MFG-5.8.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : isV570 ? "MFG-5.7.0-callable-bootstrap-veilsync-v2-region-verified-vm" : isV560 ? "MFG-5.6.0-veilsync-v2-region-verified-shadow-hardened-carrier-vm" : isV550 ? "MFG-5.5.0-veilsync-shadow-hardened-carrier-vm" : isV540 ? "MFG-5.4.0-build-diverse-shadow-hardened-carrier-vm" : isV530 ? "MFG-5.3.0-build-diverse-carrier-vm" : is500 ? "MFG-5.0.0-position-keyed-carrier-vm" : is479 ? "MFG-4.7.9-striped-payload-vm" : "MFG-4.7.8-semantic-shadow-vm", protectionEngine: "Byte-Blinder", payloadMaterialization, vmBackend: mode === "register" ? "VM-A/register" : "VM-B/stack" };
            }
            if (version === "4.7.7") {
                return { ...generated, output: generated.output, version, layout: "hybrid-function-policy-binary-region-vm-v477", vmStages: Number(generated.vmStages || 7), nestedObfuscation: false, nestedObfuscationLayers: 0, nestedCodecs: [], nestedCompression: null, nestedCompressedLayers: 0, nestedCompressionBytesSaved: 0, heterogeneousNestedLayers: false, antiTamperLayers: 0, antiHookLayers: 0, antiDumpLayers: 0, crossLayerIntegrity: false, intraVmIntegrity: true, singleLayerEngine: true, runtimeSourceLoaderCount: 0, sourceLoaderStages: 0, payloadTransformLayers: 8, nativeBufferRuntime: true, shadowVm: true, shadowInterleaved: true, shadowInstructionCount: Number(generated.shadowInstructionCount || 0), shadowHandlerCount: Number(generated.shadowHandlerCount || 0), shadowStepsPerRealInstruction: Number(generated.shadowStepsPerRealInstruction || 0), shadowDispatchStyle: generated.shadowDispatchStyle || "encoded-physical-opcode-table", shadowTraceOpcodeCount: Number(generated.shadowTraceOpcodeCount || 0), shadowOperandTraceDerived: generated.shadowOperandTraceDerived === true, shadowLiveOpcodeCoupled: generated.shadowLiveOpcodeCoupled === true, shadowTraceInterleaveRatio: generated.shadowTraceInterleaveRatio || null, shadowFingerprint: generated.shadowFingerprint || null, generatorEngine: "MFG-4.7.7-hybrid-function-policy", protectionEngine: "Byte-Blinder", payloadMaterialization: "function-policy-binary-region-vm-v477", vmBackend: mode === "register" ? "VM-A/register" : "VM-B/stack" };
            }
            if (version === "4.7.6") {
                return { ...generated, output: generated.output, version, layout: "binary-region-interleaved-shadow-vm-v476-eight-lane", vmStages: Number(generated.vmStages || 7), nestedObfuscation: false, nestedObfuscationLayers: 0, nestedCodecs: [], nestedCompression: null, nestedCompressedLayers: 0, nestedCompressionBytesSaved: 0, heterogeneousNestedLayers: false, antiTamperLayers: 0, antiHookLayers: 0, antiDumpLayers: 0, crossLayerIntegrity: false, intraVmIntegrity: true, singleLayerEngine: true, runtimeSourceLoaderCount: 0, sourceLoaderStages: 0, payloadTransformLayers: 8, nativeBufferRuntime: true, shadowVm: true, shadowInterleaved: true, shadowInstructionCount: Number(generated.shadowInstructionCount || 0), shadowHandlerCount: Number(generated.shadowHandlerCount || 0), shadowStepsPerRealInstruction: Number(generated.shadowStepsPerRealInstruction || 0), shadowDispatchStyle: generated.shadowDispatchStyle || "encoded-physical-opcode-table", shadowTraceOpcodeCount: Number(generated.shadowTraceOpcodeCount || 0), shadowOperandTraceDerived: generated.shadowOperandTraceDerived === true, shadowLiveOpcodeCoupled: generated.shadowLiveOpcodeCoupled === true, shadowTraceInterleaveRatio: generated.shadowTraceInterleaveRatio || null, shadowFingerprint: generated.shadowFingerprint || null, generatorEngine: "MFG-4.7.6-interleaved-shadow-vm", protectionEngine: "Byte-Blinder", payloadMaterialization: "fragment-graph-interleaved-shadow-vm-v476-eight-lane-binary-regions" };
            }
            if (version === "4.7.5") {
                return { ...generated, output: generated.output, version, layout: "binary-region-graph-vm-v475-eight-lane", vmStages: Number(generated.vmStages || 7), nestedObfuscation: false, nestedObfuscationLayers: 0, nestedCodecs: [], nestedCompression: null, nestedCompressedLayers: 0, nestedCompressionBytesSaved: 0, heterogeneousNestedLayers: false, antiTamperLayers: 0, antiHookLayers: 0, antiDumpLayers: 0, crossLayerIntegrity: false, intraVmIntegrity: true, singleLayerEngine: true, runtimeSourceLoaderCount: 0, sourceLoaderStages: 0, payloadTransformLayers: 8, nativeBufferRuntime: true, generatorEngine: "MFG-4.7.5-binary-region-vm", protectionEngine: "Byte-Blinder", payloadMaterialization: "fragment-graph-distributed-material-vma-vmb-microop-v475-eight-lane-binary-region-buffer" };
            }
            // v4.7.3 is retained as the historical single-layer compatibility path.
            // v4.7.4 is retained as the historical nested-source path for comparisons.
            if (version === "4.7.3") {
                return {
                    ...generated,
                    output: generated.output,
                    version,
                    layout: "single-layer-packed-bytecode-vm-v473",
                    vmStages: Number(generated.vmStages || 7),
                    nestedObfuscation: false,
                    nestedObfuscationLayers: 0,
                    nestedCodecs: [],
                    nestedCompression: null,
                    nestedCompressedLayers: 0,
                    nestedCompressionBytesSaved: 0,
                    heterogeneousNestedLayers: false,
                    antiTamperLayers: 0,
                    antiHookLayers: 0,
                    antiDumpLayers: 0,
                    crossLayerIntegrity: false,
                    intraVmIntegrity: true,
                    singleLayerEngine: true,
                    runtimeSourceLoaderCount: 0,
                    generatorEngine: "MFG-4.7.3-single-layer",
                    payloadMaterialization: "single-layer-packed-bytecode-vm-v473-distributed-payload"
                };
            }
            const { wrapSource } = require("../../protection/nested_obfuscation");
            const nested = wrapSource(generated.output, { seed, strength, version, nestedProfile: options.nestedProfile || "balanced" });
            const v455 = version === "4.5.5";
            const v46 = version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || (version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))));
            return { ...generated, output: nested.output, version, layout: version === "4.7.4" ? "nested-integrity-dispatch-v474-domain-separated-four-lane" : version === "4.7.3" ? "nested-integrity-dispatch-v473-resource-balanced-four-lane" : version === "4.7.2" ? "nested-integrity-dispatch-v472-four-lane-deepest" : version === "4.7.1" ? "nested-integrity-dispatch-v471-three-lane-deepest" : version === "4.6.8" ? "nested-integrity-dispatch-v468" : version === "4.6.7" ? "nested-architecture-diverse-vm-vma-vmb-microop-v467" : version === "4.6.6" ? "nested-architecture-diverse-vm-vma-vmb-microop-v466" : version === "4.6.5" ? "nested-architecture-diverse-vm-vma-vmb-microop-v465" : (v46 ? "nested-architecture-diverse-vm-vma-vmb-microop-v463" : (v455 ? "nested-semantic-morphing-vm-vma-vmb-microop-v455" : "nested-heterogeneous-vm-vma-vmb-microop-v453")), vmStages: Number(generated.vmStages || 7) + nested.layers, nestedObfuscation: true, nestedObfuscationLayers: nested.layers, nestedCodecs: nested.codecs, nestedCompression: nested.compression, nestedCompressedLayers: nested.compression?.compressedLayers || 0, nestedCompressionBytesSaved: nested.compression?.bytesSaved || 0, heterogeneousNestedLayers: nested.heterogeneous, antiTamperLayers: nested.antiTamperLayers, antiHookLayers: nested.antiHookLayers, antiDumpLayers: nested.antiDumpLayers, generatorEngine: version === "4.7.4" ? "MFG-4.7.4" : version === "4.7.3" ? "MFG-4.7.3" : version === "4.7.2" ? "MFG-4.7.2" : version === "4.7.1" ? "MFG-4.7.1" : version === "4.6.8" ? "MFG-4.6.8" : version === "4.6.7" ? "MFG-4.6.7" : version === "4.6.6" ? "MFG-4.6.6" : version === "4.6.5" ? "MFG-4.6.5" : (v46 ? "MFG-4.6.3" : (v455 ? "MFG-4.5.5" : "MFG-4.5.4")), protectionEngine: "Byte-Blinder", payloadMaterialization: version === "4.7.4" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v474-domain-separated-codec8-wire" : version === "4.7.3" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v473-resource-balanced-wire" : version === "4.7.2" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v472-four-lane-packed-wire" : version === "4.7.1" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v471-three-lane-feedback" : version === "4.6.8" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v468-eight-topologies-checkpoints" : version === "4.6.7" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v467-substitution" : version === "4.6.6" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v466-morph" : version === "4.6.5" ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v465-morph" : (v46 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v463-morph" : (v455 ? "fragment-graph-distributed-material-vma-vmb-microop-nested-v455-morph" : "fragment-graph-distributed-material-vma-vmb-microop-nested-v453")) };
        }
        return generated;
    }
    const lines = [];
    lines.push(`local ${N.alphabet}=${JSON.stringify(packed.alphabet)}`);
    lines.push(`local ${V.env}=((getgenv and getgenv())or(getfenv and getfenv(1))or _G);local ${V.envGuard}=function()local E=${V.env};if not E then error("ByteVeil v4.6.3: environment unavailable",0)end;return E end;local ${N.unpackBuiltin}=${V.env}["table"] and (${V.env}["table"].unpack or ${V.env}["unpack"]) or table.unpack or unpack`);
    lines.push(`local ${N.bx}=function(A,B)if bit32 and bit32.bxor then return bit32.bxor(A,B)end;A=A%4294967296;B=B%4294967296;local R=0;local P=1;for I=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${N.mul}=function(A,B)local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end`);
    lines.push(`local ${N.xor}=function(A,B)if bit32 and bit32.bxor then return bit32.bxor(A,B)end;A=A%4294967296;B=B%4294967296;local R=0;local P=1;for I=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R end`);
    lines.push(`local ${N.const}=function(S,I)local T=S[${S.consts}];local V=T[I+1];if type(V)=="function" then local R=V();T[I+1]=R;return R end;return V end`);
    if (decoderVariant === 0) {
        lines.push(`local ${N.decode85}=function(S)local O={};for I=1,#S,5 do local V=0;local J=0;while J<5 do local C=string.sub(S,I+J,I+J);local P=string.find(${N.alphabet},C,1,true);V=V*${PAYLOAD_RADIX}+(P and P-1 or 0);J=J+1 end;O[#O+1]=math.floor(V/16777216)%256;O[#O+1]=math.floor(V/65536)%256;O[#O+1]=math.floor(V/256)%256;O[#O+1]=V%256 end;return O end`);
    } else if (decoderVariant === 1) {
        lines.push(`local ${N.decode85}=function(S)local O={};for I=1,#S,5 do local P1=string.find(${N.alphabet},string.sub(S,I,I),1,true)or 1;local P2=string.find(${N.alphabet},string.sub(S,I+1,I+1),1,true)or 1;local P3=string.find(${N.alphabet},string.sub(S,I+2,I+2),1,true)or 1;local P4=string.find(${N.alphabet},string.sub(S,I+3,I+3),1,true)or 1;local P5=string.find(${N.alphabet},string.sub(S,I+4,I+4),1,true)or 1;local V=((((P1-1)*${PAYLOAD_RADIX}+(P2-1))*${PAYLOAD_RADIX}+(P3-1))*${PAYLOAD_RADIX}+(P4-1))*${PAYLOAD_RADIX}+(P5-1);O[#O+1]=math.floor(V/16777216)%256;O[#O+1]=math.floor(V/65536)%256;O[#O+1]=math.floor(V/256)%256;O[#O+1]=V%256 end;return O end`);
    } else if (decoderVariant === 2) {
        lines.push(`local ${N.decode85}=function(S)local O={};local G=#S-(#S%5)-4;for I=G,1,-5 do local A=string.find(${N.alphabet},string.sub(S,I,I),1,true)or 1;local B=string.find(${N.alphabet},string.sub(S,I+1,I+1),1,true)or 1;local C=string.find(${N.alphabet},string.sub(S,I+2,I+2),1,true)or 1;local D=string.find(${N.alphabet},string.sub(S,I+3,I+3),1,true)or 1;local E=string.find(${N.alphabet},string.sub(S,I+4,I+4),1,true)or 1;local V=((((A-1)*${PAYLOAD_RADIX}+(B-1))*${PAYLOAD_RADIX}+(C-1))*${PAYLOAD_RADIX}+(D-1))*${PAYLOAD_RADIX}+(E-1);local Q=math.floor((I-1)/5)*4;O[Q+1]=math.floor(V/16777216)%256;O[Q+2]=math.floor(V/65536)%256;O[Q+3]=math.floor(V/256)%256;O[Q+4]=V%256 end;local R={};for I=1,#O do R[I]=O[I] end;return R end`);
    } else {
        lines.push(`local ${N.decode85}=function(S)local O={};local R=1;for I=1,#S,5 do local P={};for J=0,4 do P[J+1]=string.find(${N.alphabet},string.sub(S,I+J,I+J),1,true)or 1 end;local V=0;for J=1,5 do V=V*${PAYLOAD_RADIX}+(P[J]-1) end;O[R]=math.floor(V/16777216)%256;O[R+1]=math.floor(V/65536)%256;O[R+2]=math.floor(V/256)%256;O[R+3]=V%256;R=R+4 end;return O end`);
    }
    lines.push(`local ${N.state}=function(E,V,P,G)local S={};S[${S.pc}]=1;S[${S.locals}]={};S[${S.localSet}]={};S[${S.parent}]=P;S[${S.env}]=E;S[${S.consts}]=V;S[${S.code}]=nil;S[${S.halt}]=false;S[${S.ret}]={};S[${S.varargs}]={};S[${S.guard}]=(G or 0)%4294967296;S[${S.fabric}]=(G or 0)%4294967296;${mode === "stack" ? `S[${S.sp}]=0;S[${S.stack}]={};` : `S[${S.reg}]={};`}S[${S.iter}]={};return S end`);
    lines.push(`local ${N.run};local ${N.handlers}={}`);
    lines.push(`local ${N.superFns}={}`);

    for (const op of v38Shuffle(opNames, seed ^ 0xA17E)) {
        const fn = defs[op] || `S[${S.halt}]=true;return true`;
        const sourceFn = mode === "stack" ? stackHandler("", fn, { seed, identity: `handler-${op}` }) : registerHandler("", fn, { seed, identity: `handler-${op}` });
        lines.push(`local ${N.h[op]}=${sourceFn}`);
    }
    const hAlt = {};
    for (const op of v38Shuffle(opNames, seed ^ 0xB17F)) {
        const fn = altHandlers[op] || defs[op] || `S[${S.halt}]=true;return true`;
        const sourceFn = mode === "stack" ? stackHandler("", fn, { seed: seed ^ 0xB17F, identity: `alternate-handler-${op}` }) : registerHandler("", fn, { seed: seed ^ 0xB17F, identity: `alternate-handler-${op}` });
        hAlt[op] = N.hv[op];
        lines.push(`local ${hAlt[op]}=${sourceFn}`);
    }
    // Dense handler banks are emitted as array constructors instead of hundreds
    // of `[n]=function/value` statements. This reduces bracket noise without
    // changing runtime lookup semantics (all route indices are 1..opCount).
    const bank0 = new Array(opCount).fill(null);
    const bank1 = new Array(opCount).fill(null);
    const bank2 = new Array(opCount).fill(null);
    const bank3 = new Array(opCount).fill(null);
    for (const op of opNames) {
        bank0[opIndex0(op) - 1] = N.h[op];
        bank1[opIndex1(op) - 1] = hAlt[op];
        const base = ((seed ^ op.length) & 1) ? hAlt[op] : N.h[op];
        bank2[opIndex2(op) - 1] = `function(S,I,...)local G=S[${S.guard}];local R=${base}(S,I,...);S[${S.guard}]=(${N.bx}(G,${(seed ^ op.length * 257) >>> 0}))%4294967296;return R end`;
        bank3[opIndex3(op) - 1] = `function(S,I,...)local R=${base}(S,I,...);local G=S[${S.guard}];S[${S.guard}]=(${N.mul}(G,1103515245)+12345)%4294967296;return R end`;
    }
    if (bank0.some((v) => !v) || bank1.some((v) => !v) || bank2.some((v) => !v) || bank3.some((v) => !v)) {
        throw new Error("ByteVeil v4.4.0: incomplete dense handler bank");
    }
    lines.push(`local ${N.handlers0}={${bank0.join(",")}}`);
    lines.push(`local ${N.handlers1}={${bank1.join(",")}}`);
    lines.push(`local ${N.handlers2}={${bank2.join(",")}}`);
    lines.push(`local ${N.handlers3}={${bank3.join(",")}}`);
    const route0ByOpcode = new Array(opCount).fill(1);
    const route1ByOpcode = new Array(opCount).fill(1);
    const route2ByOpcode = new Array(opCount).fill(1);
    const route3ByOpcode = new Array(opCount).fill(1);
    for (const op of opNames) {
        const encoded = Number(bytecode.map.encode[op]);
        if (Number.isInteger(encoded) && encoded >= 0 && encoded < opCount) {
            route0ByOpcode[encoded] = opIndex0(op);
            route1ByOpcode[encoded] = opIndex1(op);
            route2ByOpcode[encoded] = opIndex2(op);
            route3ByOpcode[encoded] = opIndex3(op);
        }
    }
    lines.push(`local ${N.route0}={${route0ByOpcode.join(",")}}`);
    lines.push(`local ${N.route1}={${route1ByOpcode.join(",")}}`);
    const route2Expr = route2ByOpcode.map((v) => Number(v)).join(",");
    const route3Expr = route3ByOpcode.map((v) => Number(v)).join(",");
    lines.push(`local ${N.route2}={${route2Expr}}`);
    lines.push(`local ${N.route3}={${route3Expr}}`);
    lines.push(`local ${N.variant}={${variantMask.map((v) => Number(v) & 3).join(",")}}`);

    const dispatchCode = `${N.run}=function(X,P,...)local E=P and P[${S.env}] or ${V.envGuard}();local G=(P and P[${S.fabric}]) or X[${C.fabric}] or 0;local Q=${N.state}(E,X[${C.consts}],P,G);Q[${S.code}]=X[${C.code}];local PC0=#(X[${C.params}]or{});Q[${S.varargs}]={select(PC0+1,...)};Q[${S.varargs}].n=math.max(0,select("#",...)-PC0);for I=1,PC0 do local K0=X[${C.params}][I];local K=type(K0)=="function" and K0() or K0;X[${C.params}][I]=K;Q[${S.locals}][K]=select(I,...);Q[${S.localSet}][K]=true end;local PC=Q[${S.pc}];while not Q[${S.halt}] do local IF=Q[${S.code}][PC];local I=IF;if type(IF)=="function" then I=IF();Q[${S.code}][PC]=I end;if not I then Q[${S.halt}]=true;break end;PC=PC+1;Q[${S.pc}]=PC;local O=${N.bx}(I[1],${packed.opcodeMask});Q[${S.guard}]=(${N.mul}(Q[${S.guard}],1664525)+O*101+Q[${S.pc}]+1013904223)%4294967296;local lane=(Q[${S.guard}]+Q[${S.pc}]+O+${N.variant}[O+1])%4;local H=((lane==0 and ${N.handlers0})or(lane==1 and ${N.handlers1})or(lane==2 and ${N.handlers2})or ${N.handlers3})[(lane==0 and ${N.route0}[O+1])or(lane==1 and ${N.route1}[O+1])or(lane==2 and ${N.route2}[O+1])or ${N.route3}[O+1]];if not H then error("ByteVeil VM dispatch failed",0)end;local D=H(Q,I);PC=Q[${S.pc}];if D then break end end;return ${N.unpackBuiltin}(Q[${S.ret}],1,Q[${S.ret}].n or #Q[${S.ret}]) end`;
    lines.push(dispatchCode);
    // v4.4.0 decoy compiler: generate the decoy program from the same physical
    // opcode space used by the Real VM. The program is synthetic and bounded,
    // while its state/dispatch/layout follow the same VM family.
    const decoySpec = buildDecoyProgram({
        opNames,
        encode: bytecode.map?.encode || {},
        seed: seed ^ 0xD3C0,
        depth: decoyProfile.depth,
        mode
    });
    const decoyNames = Array.from({ length: decoyProfile.depth }, (_, i) => reserveGeneratedName(v38Id(seed ^ 0xD40000 ^ Math.imul(i + 1, 0x45D9F3B), `d${i.toString(36)}`)));
    const decoyStateNames = mode === "stack"
        ? ["pc","sp","stack","locals","localSet","parent","env","consts","code","halt","ret","varargs","guard","iter","acc","frame","fabric"]
        : ["pc","reg","locals","localSet","parent","env","consts","code","halt","ret","varargs","guard","iter","acc","frame","fabric"];
    const DS = v38Slots(seed ^ 0xD40111, decoyStateNames);
    const decoyHandlersName = reserveGeneratedName(v38Id(seed ^ 0x11C0));
    const decoyCodeName = reserveGeneratedName(v38Id(seed ^ 0x11C1));
    const decoyStateName = reserveGeneratedName(v38Id(seed ^ 0x11C2));
    const modeSalt = mode === "register" ? 0x13579BDF : 0x2468ACE0;
    const fabricSalt = (Math.imul(strength >>> 0, 0x9E3779B1) ^ decoyProfile.depth ^ ((decoyProfile.stages || 3) << 11) ^ modeSalt) >>> 0;
    const decoyAccumulatorSeed = (seed ^ 0xA511E9B3 ^ modeSalt) >>> 0;
    const fabricInitial = (seed ^ 0x4D464731 ^ modeSalt) >>> 0;
    const splitMix32 = (value) => {
        let x = value >>> 0;
        x = (x ^ (x >>> 16)) >>> 0;
        x = Math.imul(x, 2246822519) >>> 0;
        x = (x ^ (x >>> 13)) >>> 0;
        x = Math.imul(x, 3266489917) >>> 0;
        return (x ^ (x >>> 16)) >>> 0;
    };
    // v4.4: no material/activation tuples are emitted. The decoy VM derives a
    // runtime root seed from four shares of the non-secret build seed, then the
    // bounded decoy accumulator mutates that seed before any real material is derived.
    const rootShareA = splitMix32((seed ^ 0xA17F21C3) >>> 0);
    const rootShareB = splitMix32((seed ^ 0x27D4EB2F) >>> 0);
    const rootShareC = splitMix32((seed ^ 0x6C8E9CF5) >>> 0);
    const rootShareD = (packed.basePayloadSeed ^ rootShareA ^ rootShareB ^ rootShareC) >>> 0;
    const runtimeRootShareLiteral = `{${rootShareA},${rootShareB},${rootShareC},${rootShareD}}`;

    const decoyBodyFor = (op) => {
        const cls = SEMANTIC_CLASS[op] || "unknown";
        if (op === "HALT") return `D[${DS.halt}]=true`;
        if (op === "JMP") return `D[${DS.pc}]=((I[2]or 0)%#D[${DS.code}])+1`;
        if (op === "JZ") return `if not D[${DS.acc}] then D[${DS.pc}]=((I[2]or 0)%#D[${DS.code}])+1 end`;
        if (op === "RETURN" || op === "BREAK") return `D[${DS.ret}]={D[${DS.acc}]};D[${DS.halt}]=true`;
        if (cls === "constant") {
            if (mode === "stack") return `local P=(D[${DS.sp}]or 0)+1;D[${DS.sp}]=P;D[${DS.stack}][P]=I[2]or 0`;
            return `local R=I[2]or 0;D[${DS.reg}][R]=I[3]or I[2]or 0`;
        }
        if (cls === "arith" || cls === "compare" || cls === "logic" || cls === "bitwise" || cls === "unary" || cls === "string") {
            if (mode === "stack") return `local P=D[${DS.sp}]or 0;local B=D[${DS.stack}][P];local A=D[${DS.stack}][P-1];if type(A)~="number"then A=0 end;if type(B)~="number"then B=0 end;if P<2 then P=2;D[${DS.stack}][1]=0;D[${DS.stack}][2]=0;D[${DS.sp}]=P end;local V=tonumber(I[2])or 0;D[${DS.acc}]=(D[${DS.acc}]+A+B+V)%4294967296;D[${DS.stack}][P]=nil;D[${DS.sp}]=P-1`;
            return `local R=tonumber(I[2])or 0;local V=tonumber(I[3])or 0;local A=D[${DS.reg}][R];if type(A)~="number"then A=0 end;D[${DS.reg}][R]=(A+V+D[${DS.frame}])%4294967296;D[${DS.acc}]=D[${DS.reg}][R]`;
        }
        if (cls === "table") {
            if (mode === "stack") return `local P=D[${DS.sp}]or 0;local T=D[${DS.stack}][P];if type(T)~="table"then T={};D[${DS.stack}][P]=T end;T[I[2]or 1]=D[${DS.acc}];D[${DS.frame}]=(D[${DS.frame}]+1)%4294967296`;
            return `local R=I[2]or 1;local T=D[${DS.reg}][R];if type(T)~="table"then T={};D[${DS.reg}][R]=T end;T[I[3]or 1]=D[${DS.acc}]`;
        }
        if (cls === "call" || cls === "closure" || cls === "vararg") {
            if (mode === "stack") return `local P=(D[${DS.sp}]or 0)+1;D[${DS.sp}]=P;local V=tonumber(I[2])or 0;D[${DS.stack}][P]=(D[${DS.acc}]+V)%4294967296;D[${DS.frame}]=(D[${DS.frame}]+1)%4294967296`;
            return `local R=tonumber(I[2])or 1;local V=tonumber(I[3])or 0;D[${DS.reg}][R]=(D[${DS.acc}]+V+D[${DS.frame}])%4294967296;D[${DS.frame}]=(D[${DS.frame}]+1)%4294967296`;
        }
        if (cls === "iterator") return `local V=tonumber(I[2])or 0;D[${DS.iter}]=(D[${DS.iter}]or 0)+1;D[${DS.acc}]=(D[${DS.acc}]+D[${DS.iter}]+V)%4294967296`;
        return `local A=tonumber(I[1])or 0;local B=tonumber(I[2])or 0;D[${DS.acc}]=(${N.mul}(D[${DS.acc}],1664525)+A+B+${fabricSalt})%4294967296;D[${DS.frame}]=(D[${DS.frame}]+1)%4294967296`;
    };

    const decoyBank = new Array(opCount).fill(null);
    for (const op of opNames) {
        const physical = Number(bytecode.map?.encode?.[op]);
        if (!Number.isInteger(physical) || physical < 0 || physical >= opCount) continue;
        decoyBank[physical] = `function(D,I)${decoyBodyFor(op)};return false end`;
    }
    if (decoyBank.some((v) => !v)) throw new Error("ByteVeil v4.4.0: incomplete dense decoy bank");
    lines.push(`local ${decoyHandlersName}={${decoyBank.join(",")}}`);
    const decoyCode = decoySpec.instructions.map((row) => `{${row.join(",")}}`);
    lines.push(`local ${decoyCodeName}={${decoyCode.join(",")}}`);
    const decoyInit = mode === "stack"
        ? `D[${DS.sp}]=0;D[${DS.stack}]={}`
        : `D[${DS.reg}]={}`;
    lines.push(`local ${decoyStateName}=function(E)local D={};D[${DS.pc}]=1;${decoyInit};D[${DS.locals}]={};D[${DS.localSet}]={};D[${DS.parent}]=nil;D[${DS.env}]=E;D[${DS.consts}]={};D[${DS.code}]=${decoyCodeName};D[${DS.halt}]=false;D[${DS.ret}]={};D[${DS.varargs}]={};D[${DS.guard}]=0;D[${DS.iter}]=0;D[${DS.acc}]=${decoyAccumulatorSeed};D[${DS.frame}]=0;D[${DS.fabric}]=${fabricInitial};return D end`);
    const route0 = route0ByOpcode.slice();
    const route1 = route1ByOpcode.slice();
    const route2 = route2ByOpcode.slice();
    const route3 = route3ByOpcode.slice();
    const variantLiteral = variantMask.map((v) => Number(v) & 3).join(",");
    const decoyFnBodies = [];
    for (let i = 0; i < decoyNames.length; i++) {
        const next = ((i + 1) % decoyNames.length) + 1;
        const alt = (((i * 7 + 3) % decoyNames.length)) + 1;
        const route = (i + (seed & 15)) % 4;
        const branch = route === 0 ? `if (D[${DS.guard}]%3)==0 then return ${N.decoyFns}[${next}] else return ${N.decoyFns}[${alt}] end`
            : route === 1 ? `if D[${DS.acc}]%2==0 then return ${N.decoyFns}[${next}] else return ${N.decoyFns}[${alt}] end`
            : route === 2 ? `if D[${DS.frame}]%2==0 then return ${N.decoyFns}[${next}] else return ${N.decoyFns}[${alt}] end`
            : `if (D[${DS.fabric}]%5)==0 then return ${N.decoyFns}[${next}] else return ${N.decoyFns}[${alt}] end`;
        const template = i % 4;
        const normalize=`D[${DS.pc}]=tonumber(D[${DS.pc}])or 1;D[${DS.guard}]=tonumber(D[${DS.guard}])or 0;D[${DS.acc}]=tonumber(D[${DS.acc}])or 0;D[${DS.frame}]=tonumber(D[${DS.frame}])or 0;D[${DS.fabric}]=tonumber(D[${DS.fabric}])or 0;`;
        const body = template === 0
            ? `${normalize}local PC=D[${DS.pc}];local I=D[${DS.code}][PC]or{0,0,0};D[${DS.pc}]=(PC%#D[${DS.code}])+1;D[${DS.frame}]=(D[${DS.frame}]+1)%4294967296;local O=I[1]or 0;local lane=(D[${DS.guard}]+D[${DS.frame}]+O+${N.variant}[O+1])%4;local route=((lane==0 and ${N.route0})or(lane==1 and ${N.route1})or(lane==2 and ${N.route2})or ${N.route3});local slot=route[O+1];local H=${decoyHandlersName}[slot];if H then H(D,I)end`
            : template === 1
                ? `${normalize}local PC=D[${DS.pc}];local I=D[${DS.code}][PC]or{0,0,0};D[${DS.pc}]=(PC%#D[${DS.code}])+1;local O=I[1]or 0;local lane=(D[${DS.acc}]+PC+O+${N.variant}[O+1])%4;local route=((lane==0 and ${N.route0})or(lane==1 and ${N.route1})or(lane==2 and ${N.route2})or ${N.route3});local slot=route[O+1];local H=${decoyHandlersName}[slot];if H then H(D,I)end;D[${DS.fabric}]=(${N.mul}(D[${DS.fabric}],22695477)+O+PC+${fabricSalt})%4294967296`
                : template === 2
                    ? `${normalize}local PC=D[${DS.pc}];local I=D[${DS.code}][PC]or{0,0,0};D[${DS.pc}]=(PC%#D[${DS.code}])+1;local O=I[1]or 0;local lane=(D[${DS.frame}]+D[${DS.guard}]+O+${N.variant}[O+1])%4;local route=((lane==0 and ${N.route0})or(lane==1 and ${N.route1})or(lane==2 and ${N.route2})or ${N.route3});local slot=route[O+1];local H=${decoyHandlersName}[slot];if H then H(D,I)end;D[${DS.frame}]=(D[${DS.frame}]+(tonumber(I[2])or 0)+1)%4294967296`
                    : `${normalize}local PC=D[${DS.pc}];local I=D[${DS.code}][PC]or{0,0,0};D[${DS.pc}]=(PC%#D[${DS.code}])+1;local O=I[1]or 0;local V=tonumber(I[2])or 0;local lane=(D[${DS.fabric}]+PC+V+${N.variant}[O+1])%4;local route=((lane==0 and ${N.route0})or(lane==1 and ${N.route1})or(lane==2 and ${N.route2})or ${N.route3});local slot=route[O+1];local H=${decoyHandlersName}[slot];if H then H(D,I)end;D[${DS.guard}]=(D[${DS.guard}]+PC+(tonumber(I[2])or 0))%4294967296`;
        decoyFnBodies.push(`function(D,K)${body};${branch} end`);
    }
    lines.push(`local ${N.decoyFns}`);
    lines.push(`${N.decoyFns}={${decoyFnBodies.join(",")}}`);
    lines.push(`${N.decoyRun}=function()local D0=${decoyStateName}(_G);local D1=${decoyStateName}(_G);local D2=${decoyStateName}(_G);local D3=${decoyStateName}(_G);local F0=${N.decoyFns}[1];local F1=${N.decoyFns}[(((${seed}+${strength})%${Math.max(1, decoyProfile.depth)})+${Math.max(1, decoyProfile.depth)})%${Math.max(1, decoyProfile.depth)}+1];local F2=${N.decoyFns}[(((${seed}*3+${strength})%${Math.max(1, decoyProfile.depth)})+${Math.max(1, decoyProfile.depth)})%${Math.max(1, decoyProfile.depth)}+1];local F3=${N.decoyFns}[(((${seed}*5+${strength})%${Math.max(1, decoyProfile.depth)})+${Math.max(1, decoyProfile.depth)})%${Math.max(1, decoyProfile.depth)}+1];local MB=${N.mul}(${N.bx}(${N.bx}(${packed.basePayloadSeed >>> 0},${packed.shapeToken}),${packed.descriptorSalt >>> 0}),1664525);for I=1,${decoyProfile.budget} do local N0=F0(D0,I);F0=N0 or ${N.decoyFns}[1];local N1=F1(D1,I+1);F1=N1 or ${N.decoyFns}[1];local N2=F2(D2,I+2);F2=N2 or ${N.decoyFns}[1];local N3=F3(D3,I+3);F3=N3 or ${N.decoyFns}[1];MB=(${N.mul}(MB,1664525)+${N.mul}(I,1013904223)+${decoyProfile.depth}+${strength})%4294967296;MB=${N.bx}(MB,math.floor(MB/8192));MB=${N.mul}(MB,2246822519);MB=${N.bx}(MB,math.floor(MB/65536));end;local P={${runtimeRootShareLiteral}};local Z0=setmetatable({v=P[1][1],b=P[1][2],c=P[1][3],d=P[1][4]},{__index=function(T,K)return rawget(T,K)end,__add=function(T,V)T.v=${N.xor}(T.v,V);return T end,__sub=function(T,V)T.v=${N.xor}(T.v,V);return T end,__mul=function(T,V)T.v=${N.mul}(T.v,V);return T end,__pow=function(T,V)T.v=${N.xor}(T.v,V);return T end,__concat=function(T,V)T.v=${N.xor}(T.v,V);return T end,__div=function(T,V)return T.v end});Z0=Z0+Z0.b;Z0=Z0^Z0.c;Z0=Z0*1;Z0=Z0-0;Z0=Z0..Z0.d;local B0=Z0/Z0;return ${N.xor}(B0,MB) end`);

    // v4.4 runtime hardening: material derivation, reversible secondary transport,
    // keyed payload permutation and an authenticated payload envelope. None of the
    // old activation/gate/checksum constants are emitted as runtime comparison oracles.
    lines.push(`local __bv_type=type;local __bv_byte=string.byte;local __bv_concat=table.concat;local __bv_find=string.find;local __bv_sub=string.sub;local __bv_floor=math.floor;local __bv_load=loadstring or load;local __bv_pcall=pcall;local __bv_tostring=tostring`);
    lines.push(`local ${N.hookGuard}=function(F)local R=__bv_load;if type~=__bv_type or string.byte~=__bv_byte or table.concat~=__bv_concat or string.find~=__bv_find or string.sub~=__bv_sub or math.floor~=__bv_floor or (loadstring or load)~=R or pcall~=__bv_pcall or tostring~=__bv_tostring then error("ByteVeil runtime reference integrity failed",0) end;return F end`);
    lines.push(`local ${N.shape}=function(X)return X[${C.shape}] or 0 end`);
    lines.push(`local ${N.mix}=function(U,V)local R=${N.xor}(U,${N.xor}(V,0xB17E4A31));R=${N.xor}(R,math.floor(R/65536));R=${N.mul}(R,2246822519);R=${N.xor}(R,math.floor(R/8192));R=${N.mul}(R,3266489917);return ${N.xor}(R,math.floor(R/65536))%4294967296 end`);
    lines.push(`local ${N.materials}=function(K)local MS=${modeSalt};local DEP=${decoyProfile.depth};local ST=${Number(decoyProfile.stages || 3)};local function D0(D)local R=${N.mix}(K,${N.xor}(D,${N.xor}(MS,${N.xor}(DEP,ST*2048))));R=${N.mix}(R,${N.mul}(${strength},0x45D9F3B));R=${N.mix}(R,${N.xor}(D,0x9E3779B9));return ${N.xor}(R,${N.mul}(D,2654435761))%4294967296 end;return {activation=D0(0xA1),payloadA=D0(0xB3),payloadB=D0(0xC7),payloadC=D0(0xD9),payloadD=D0(0xEB),opcode=D0(0xF1),codec=D0(0x117),integrity=D0(0x12B),guard=D0(0x13D)} end`);
    lines.push(`local ${N.transportSeed}=function(K,M)return ${N.mix}(${N.mix}(K,${N.xor}(M.payloadB,${N.xor}(M.guard,0x6D2B79F5))),${N.xor}(M.codec,${N.xor}(M.payloadD,0x51ED2708))) end`);
    lines.push(`local ${N.transportMask}=function(K,I,L)local Q=(0x6A09E667+${N.mul}(L+1,0x45D9F3B)+${N.mul}(I+1,0x27D4EB2F))%4294967296;return ${N.mix}(K,Q)%256 end`);
    lines.push(`local ${N.shardSeed}=function(K,M)local C=${N.xor}(${N.xor}(M.payloadC,M.codec),K);return ${N.xor}(${N.xor}(C,M.payloadA),${N.xor}(M.payloadD,M.guard)) end`);
    lines.push(`local ${N.blob}=${packed.blob}`);
    lines.push(`local ${N.order}=${packed.order}`);
    lines.push(`local byteveil={};byteveil.crack=function(C,O,K)local M0=${N.materials}(K);local SM=${N.shardSeed}(K,M0);local R={};local function M(S,Q,I,L)local D=${N.xor}(S,${N.xor}(${N.mul}(Q+1,0x45D9F3B),${N.xor}(${N.mul}(I+1,0x27D4EB2F),${N.mul}(L+1,0x9E3779B1))));D=${N.xor}(D,0xB17E4A31);D=${N.xor}(D,math.floor(D/65536));D=${N.mul}(D,2246822519);D=${N.xor}(D,math.floor(D/8192));D=${N.mul}(D,3266489917);return ${N.xor}(D,math.floor(D/65536))%256 end;for I=1,#O do local Q=I-1;local B=${N.decode85}(C[O[I]]);for J=1,#B do local P=J-1;local A=M(SM,Q,P,Q%4);local T=M(${N.xor}(SM,0xC0FFEE11),Q,P,(Q%4)+1);local U=M(${N.xor}(SM,0x7A51BEEF),Q,P,(Q%4)+2);B[J]=${N.xor}(B[J]or 0,U);B[J]=((B[J]-T+256)%256);B[J]=${N.xor}(B[J],A) end;R[I]=B end;return R end;byteveil.skid=function(R,K,E)local F={};for I=1,#R do local B=R[I];for J=1,#B do F[#F+1]=B[J]end end;local L=E or #F;if #F<L then error("ByteVeil payload stage truncated",0)end;while #F>L do F[#F]=nil end;if L<=1 then return F end;local step=(${N.mix}(K,0xD1B54A32)%L)|1;step=step%L;if step==0 then step=1 end;local function G(A,B)while B~=0 do local C=A%B;A=B;B=C end;return A end;while G(step,L)~=1 do step=(step+2)%L;if step==0 then step=1 end end;local off=${N.mix}(K,0x94D049BB)%L;local O={};for I=0,L-1 do local P=(off+I*step)%L;O[I+1]=F[P+1]end;return O end;byteveil.time=function(R,K)local M0=${N.materials}(K);local TS=${N.transportSeed}(K,M0);local T={};for I=1,#R do local P=I-1;local V=R[I]or 0;V=(V+${N.transportMask}(M0.codec,P,3))%256;V=${N.xor}(V,${N.transportMask}(M0.integrity,P,2));V=(V-${N.transportMask}(M0.payloadA,P,1)+256)%256;V=${N.xor}(V,${N.transportMask}(TS,P,0));T[I]=V end;return T end;byteveil.hello=function(C,O,K)local R=byteveil.crack(C,O,K);R=byteveil.skid(R,K,${packed.stagedByteLength});return byteveil.time(R,K) end`);
    lines.push(`local ${N.stageA}=function(B,O,K)return byteveil.hello(B,O,K)end`);
    lines.push(`local ${N.unpack}=function(D,K)local O={};local M0=${N.materials}(K);local function X(U,V)U=U%4294967296;V=V%4294967296;if bit32 and bit32.bxor then return bit32.bxor(U,V)end;local R=0;local W=1;for I=1,32 do local a=U%2;local b=V%2;if a~=b then R=R+W end;U=(U-a)/2;V=(V-b)/2;W=W*2 end;return R end;local function I(U,V)U=U%4294967296;V=V%4294967296;local a=U%65536;local ah=math.floor(U/65536);local b=V%65536;local bh=math.floor(V/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;local function M(U,V)local R=X(U,X(V,0xB17E4A31));R=X(R,math.floor(R/65536));R=I(R,2246822519);R=X(R,math.floor(R/8192));R=I(R,3266489917);R=X(R,math.floor(R/65536));return R end;local function BM(U,J,N0)local Q=(0x51ED2708+I(N0+1,0x45D9F3B)+I(J+1,0x27D4EB2F))%4294967296;return M(U,Q)%256 end;local BK=(M0.codec~M0.payloadB~0xA5)%256;for J=1,#D do local V=X(D[J]or 0,(BK*29+17+(J-1))%256);BK=(BK*29+17+(J-1))%256;local Z=(V+BM(M0.payloadD,J-1,3))%256;Z=X(Z,BM(M0.payloadC,J-1,2));Z=(Z-BM(M0.payloadB,J-1,1)+256)%256;Z=X(Z,BM(M0.payloadA,J-1,0));O[J]=Z%256 end;return O end`);
    lines.push(`local ${N.checksum}=function(D)local H=17;for I=1,#D do H=(H*65599+D[I]+1)%2147483647 end;return H end`);
    lines.push(`local ${N.envelope}=function(E,K)local M0=${N.materials}(K);if #E<36 or E[1]~=0x42 or E[2]~=0x56 or E[3]~=0x45 or E[4]~=0x44 or E[5]~=1 or E[7]~=0xA4 or E[8]~=0x7C then error("ByteVeil payload envelope invalid",0)end;local F=E[6]or 0;local expectedMode=${mode === "register" ? 1 : 0};if F%2~=expectedMode or (F>=2 and ${decoyProfile.depth}<64) then error("ByteVeil payload envelope profile mismatch",0)end;local function U(S)local V=0;local W=1;for I=0,3 do V=V+(E[S+I]or 0)*W;W=W*256 end;return V%4294967296 end;local BL=U(9);if BL~=(#E-36)then error("ByteVeil payload envelope length mismatch",0)end;local C0=U(13);local SH=U(17);local BI=U(21);local OM=U(25);local DS=U(29);local TG=U(33);local body={};for I=37,#E do body[#body+1]=E[I]end;local calc=${N.checksum}(body);if calc~=C0 then error("ByteVeil payload envelope checksum mismatch",0)end;local B0=${N.mix}(M0.integrity,${N.xor}(C0,${N.xor}(SH,${N.xor}(DS,${N.xor}(OM,BL)))));B0=${N.mix}(B0,${N.xor}(M0.activation,${N.xor}(M0.guard,${N.xor}(K,${N.mul}(${strength},0x9E3779B1)))));if B0~=BI then error("ByteVeil payload envelope binding mismatch",0)end;local T0=${N.mix}(M0.codec,${N.xor}(BI,${N.xor}(M0.payloadA,${N.xor}(M0.payloadD,${mode === "register" ? 0x13579BDF : 0x2468ACE0}))));if T0~=TG then error("ByteVeil payload envelope transport tag mismatch",0)end;local OS0=${N.xor}(M0.opcode,0xD3C4A7B1);OS0=${N.mul}(${N.xor}(OS0,math.floor(OS0/65536)),2246822519);OS0=${N.mul}(${N.xor}(OS0,math.floor(OS0/8192)),3266489917);local OM0=${N.xor}(${N.xor}(OS0,math.floor(OS0/256)),math.floor(OS0/16777216))%256;if OM0==0 then OM0=0x5A end;if OM~=OM0 then error("ByteVeil payload opcode binding mismatch",0)end;return body,{checksum=C0,shape=SH,opcodeMask=OM,descriptor=DS,transportTag=TG,flags=F}end`);
    const printableAscii = Array.from({ length: 95 }, (_, i) => String.fromCharCode(32 + i)).join("");
    const printableAsciiLiteral = JSON.stringify(printableAscii);
    lines.push(`local ${N.read}=function(D)local P0=1;local function UAt(S)local V=0;local M=1;local P=S;while true do local B=D[P];P=P+1;if not B then error("ByteVeil payload truncated",0)end;V=V+(B%128)*M;if B<128 then return V,P end;M=M*128 end end;local function U()local V;V,P0=UAt(P0);return V end;local ${N.ascii}=${printableAsciiLiteral};local function ch(B)if B>=32 and B<=126 then return string.sub(${N.ascii},B-31,B-31)end;if B==0 then return "\\0"end;if B==7 then return "\\a"end;if B==8 then return "\\b"end;if B==9 then return "\\t"end;if B==10 then return "\\n"end;if B==11 then return "\\v"end;if B==12 then return "\\f"end;if B==13 then return "\\r"end;if B>=0 and B<=255 then return string["ch".."ar"](B)end;error("ByteVeil v4.6.6: invalid string byte",0)end;local function strAt(S,L)local T={};for I=0,L-1 do T[I+1]=ch(D[S+I])end;return table.concat(T)end;local function numAt(S,K)local V,P;if K==0 then V,P=UAt(S);return(V%2==0)and math.floor(V/2)or-math.floor((V+1)/2)end;local L;L,P=UAt(S);local T={};for I=1,L do T[I]=ch(D[P]);P=P+1 end;return tonumber(table.concat(T))end;local function instrAt(S,N0)local Q={};local P=S;for I=1,N0 do local T=D[P];P=P+1;if T==0 then local V;V,P=UAt(P);Q[I]=(V%2==0)and math.floor(V/2)or-math.floor((V+1)/2)else local L;L,P=UAt(P);local A={};for J=1,L do A[J]=ch(D[P]);P=P+1 end;Q[I]=tonumber(table.concat(A))end end;return Q end;local function scanChunk()local Y={};local CK={};local IE={};local KC=U();Y[${C.consts}]={};local K=Y[${C.consts}];for I=1,KC do local T=D[P0];P0=P0+1;if T==83 then local L=U();local S0=P0;P0=P0+L;K[I]=function()return strAt(S0,L)end;CK[#CK+1]=83 elseif T==78 then local K0=D[P0];P0=P0+1;if K0==0 then local S0=P0;local _,P1=UAt(P0);P0=P1;K[I]=function()return numAt(S0,0)end else local L=U();local S0=P0;P0=P0+L;K[I]=function()return numAt(S0,1)end end;CK[#CK+1]=78 elseif T==84 then K[I]=function()return true end;CK[#CK+1]=84 elseif T==70 then K[I]=function()return false end;CK[#CK+1]=70 elseif T==67 then local C0,E1=scanChunk();K[I]=function()return C0 end;CK[#CK+1]=67;for J=1,#E1 do CK[#CK+1]=E1[J]end elseif T==90 then K[I]=function()return nil end;CK[#CK+1]=90 else error("ByteVeil payload constant tag invalid",0)end end;local PC=U();Y[${C.params}]={};for I=1,PC do local L=U();local S0=P0;P0=P0+L;Y[${C.params}][I]=function()return strAt(S0,L)end end;local VV=D[P0];P0=P0+1;Y[${C.vararg}]=VV==1;local IC=U();Y[${C.code}]={};for I=1,IC do local AC=U();local S0=P0;for J=1,AC do local K0=D[P0];P0=P0+1;if K0==0 then local _,P1=UAt(P0);P0=P1 else local L=U();P0=P0+L end end;Y[${C.code}][I]=function()return instrAt(S0,AC)end;IE[#IE+1]=AC+257 end;local E0={KC,PC,IC,VV==1 and 1 or 0};for I=1,#CK do E0[#E0+1]=CK[I]end;for I=1,#IE do E0[#E0+1]=IE[I]end;local H=2166136261;local function M(V)H=${N.mul}(${N.bx}(H,V),16777619)end;for I=1,#E0 do M(E0[I])end;Y[${C.shape}]=H;return Y,E0 end;local X0,E0=scanChunk();return X0,E0 end`);
    const superRows = [];
    function collectSuper(chunk) {
        const code = Array.isArray(chunk?.code) ? chunk.code : [];
        const decode = chunk?.map?.decode || {};
        for (const ins of code) {
            if (!Array.isArray(ins) || !ins.length) continue;
            if (decode[ins[0]] !== "SUPER") continue;
            const id = Number(ins[1]);
            const count = Number(ins[2]) || 0;
            let at = 3;
            const calls = [];
            for (let q = 0; q < count; q++) {
                const len = Number(ins[at]) || 0;
                const child = ins.slice(at + 1, at + 1 + len);
                const childName = decode[child[0]];
                if (!childName || !N.h[childName]) throw new Error(`ByteVeil v4.4.0: unsupported SUPER child ${childName || "unknown"}`);
                calls.push(`local V${q}={${child.join(",")}};local R${q}=${N.handlers0}[${opIndex0(childName)}](S,V${q});if R${q} then return R${q} end;`);
                at += len + 1;
            }
            superRows.push({ id, source: `local F${id}=function(S,I)${calls.join("")}end` });
        }
        for (const value of chunk.consts || []) if (value?.__chunk) collectSuper(value.__chunk);
    }
    collectSuper(bytecode);
    for (const row of superRows) lines.push(row.source);
    for (const row of superRows) lines.push(`${N.superFns}[${row.id}]=F${row.id}`);

    lines.push(`${N.hookGuard}()`);
    lines.push(`local ${N.activation}=${N.decoyRun}()`);
    lines.push(`local ${N.result}=(function(K)local ${N.payload}=${N.stageA}(${N.blob},${N.order},K);local ${N.raw}=${N.unpack}(${N.payload},K);${N.payload}=nil;local ${N.body},${N.meta}=${N.envelope}(${N.raw},K);${N.raw}=nil;local ${N.root}=${N.read}(${N.body});if ${N.shape}(${N.root})~=${N.meta}.shape or ${N.checksum}(${N.body})~=${N.meta}.checksum then error("ByteVeil payload cross-layer validation failed",0)end;${N.root}[${C.fabric}]=${N.xor}(K,${N.meta}.opcodeMask);${N.hookGuard}();local R={${N.run}(${N.root},nil)};${v468 ? `${N.hookGuard}();` : ""}${N.root}[${C.fabric}]=nil;${N.root}[${C.vararg}]=nil;${N.root}=nil;for I=1,#${N.body} do ${N.body}[I]=0 end;${N.body}=nil;return R end)(${N.activation})`);
    lines.push(`${N.activation}=nil`);
    lines.push(`return ${N.unpackBuiltin}(${N.result},1,#${N.result})`);

    let output = lines.join("\n");
    const accessShape = rewriteGeneratedAccessShape(output, { seed, realSlots: S, decoySlots: DS });
    output = accessShape.output;
    output = output.replace(/\bByteCode\b/g, "ByteVeil");
    if (/string\.char/.test(output)) throw new Error("ByteVeil v4.4.0 generator invariant failed: string.char emitted");
    if (/\\[0-9]{3}/.test(output)) throw new Error("ByteVeil v4.4.0 generator invariant failed: decimal byte escape emitted");
    return {
        output,
        version: "4.4.0",
        layout: "unified-metamorphic-vm-v440",
        mode,
        stateSlots: S,
        chunkSlots: C,
        handlerMul,
        handlerAdd,
        opcodeMask: packed.opcodeMask,
        payloadSeed: packed.payloadSeed,
        byteLength: packed.byteLength,
        encodedByteLength: packed.encodedByteLength,
        containerEntries: packed.containerEntries,
        containerShards: packed.containerShards,
        containerDecoys: packed.containerDecoys,
        superOperators: packed.superCount,
        arithmeticProtection: false,
        stringChar: false,
        sourceReconstruction: false,
        packedBytecode: true,
        randomizedBuild: true,
        decoderVariant,
        handlerFamilies: 6,
        lazyInstructionMaterialization: true,
        lazyConstantMaterialization: true,
        stagedRuntime: true,
        decoyDepth: decoyProfile.depth,
        decoyBudget: decoyProfile.budget,
        decoyCycle: true,
        decoyGraph: true,
        decoyVm: true,
        decoyVmShape: "unified-isa-synthetic-vm-v440",
        decoyOpcodeHandlers: opNames.length,
        decoyFrameDepth: decoyNames.length,
        polymorphicHandlers: true,
        fusedSuper: true,
        crossLayerIntegrity: true,
        decoyLanes: 4,
        antiHook: true,
        antiTamper: true,
        antiDump: true,
        sharedExecutionFabric: true,
        payloadMaterialization: "staged-lazy-authenticated-envelope",
        protectionEngine: "Byte-Blinder",
        generatorEngine: "MFG-4.4.0",
        superIds: superRows.map((row) => row.id),
        superInstructionIds: packed.superCount
    };
}

module.exports.buildGeneratedSourceV40 = buildPackedBytecodeSourceV40;
module.exports.buildGeneratedSourceV39 = buildPackedBytecodeSourceV40;
module.exports.buildGeneratedSourceV35 = buildPackedBytecodeSourceV40;
module.exports.buildGeneratedSourceV38 = buildPackedBytecodeSourceV40;

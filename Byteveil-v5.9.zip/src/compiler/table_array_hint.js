"use strict";

// Lua sizes a table constructor's array part from its list fields before any of
// their values are known, so a nil that only appears at run time still leaves the
// following indices reachable through `#`, `next` and `ipairs`. A VM that builds
// the table one assignment at a time loses that pre-size and reports a shorter
// length (and, on Luau, a different length than on Lua 5.4). NEWTABLE therefore
// carries the list-field count so the runtime can materialise the same holes.
// Static literals can never hole out, so those constructors keep the cheap
// empty-table path.
const LITERAL_NONNULL = new Set(["Number", "String", "Boolean", "Table", "FunctionExpr"]);

function tableArraySizeHint(fields = []) {
    let list = 0;
    let lastListAt = -1;
    for (let i = 0; i < fields.length; i++) {
        if (fields[i].explicit) continue;
        list++;
        lastListAt = i;
    }
    if (list === 0) return 0;
    // Only a nil that still has a slot after it can hide those values.
    for (let i = 0; i < lastListAt; i++) {
        const field = fields[i];
        if (field.explicit) continue;
        if (!LITERAL_NONNULL.has(field.value?.type)) return list;
    }
    return 0;
}

module.exports = { tableArraySizeHint };

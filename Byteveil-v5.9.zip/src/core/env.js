const fs = require('fs');
const path = require('path');

function parseDotEnv(text) {
  const out = {};
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let value = m[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[m[1]] = value;
  }
  return out;
}

function loadEnv(file = path.resolve(process.cwd(), '.env')) {
  if (!fs.existsSync(file)) return {};
  const parsed = parseDotEnv(fs.readFileSync(file, 'utf8'));
  for (const [key, value] of Object.entries(parsed)) {
    if (process.env[key] === undefined) process.env[key] = value;
  }
  return parsed;
}

function bool(value, fallback = false) {
  if (value === undefined || value === '') return fallback;
  return /^(1|true|yes|on)$/i.test(String(value));
}

function num(value, fallback) {
  if (value === undefined || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function engineConfig(overrides = {}) {
  loadEnv();
  return {
    mode: overrides.mode || process.env.ENGINE_MODE || 'stack',
    seed: overrides.seed ?? (process.env.ENGINE_SEED ? num(process.env.ENGINE_SEED, undefined) : undefined),
    wrapper: {
      enabled: overrides.wrapper?.enabled ?? bool(process.env.ENGINE_WRAPPER, true),
      argumentCount: overrides.wrapper?.argumentCount ?? num(process.env.ENGINE_ARGUMENT_COUNT, 8),
      setmeta: overrides.wrapper?.setmeta ?? true,
      invoke: overrides.wrapper?.invoke ?? true,
      returnMode: overrides.wrapper?.returnMode ?? process.env.ENGINE_WRAPPER_MODE ?? ((overrides.wrapper?.setmeta ?? true) ? 'setmetatable' : 'direct'),
      shape: overrides.wrapper?.shape ?? process.env.ENGINE_WRAPPER_SHAPE ?? 'auto'
    },
    transforms: {
      rename: overrides.transforms?.rename ?? bool(process.env.ENGINE_RENAME, true),
      numbers: overrides.transforms?.numbers ?? bool(process.env.ENGINE_NUMBERS, true),
      strings: overrides.transforms?.strings ?? bool(process.env.ENGINE_STRINGS, true),
      controlFlow: overrides.transforms?.controlFlow ?? bool(process.env.ENGINE_CONTROL_FLOW, true),
      watermark: overrides.transforms?.watermark ?? Boolean(process.env.ENGINE_WATERMARK),
      // Preserve v2.8 advanced transform controls (opcode/gsub/shard settings)
      // instead of silently dropping them during config normalization.
      ...(overrides.transforms || {})
    },
    watermark: overrides.watermark ?? (process.env.ENGINE_WATERMARK || 'This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]')
  };
}

module.exports = { parseDotEnv, loadEnv, engineConfig };

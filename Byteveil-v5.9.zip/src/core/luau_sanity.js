"use strict";

/**
 * Lightweight generated-Luau sanity checker.
 * It intentionally validates lexical errors + delimiter balance only; a real
 * Luau compiler is still the authoritative grammar/runtime validator.
 */

// `[=[ ... ]=]` and `[[ ... ]]` are the same construct at different levels: an opener is
// `[` + N `=` + `[` and only a `]` + N `=` + `]` closes it. Scanning for a bare `]]` instead
// stops at the first inner `]]`, so every bracket character left in the payload reaches the
// delimiter stack — which is what made this checker reject the engine's own `[==[...]==]`
// blob containers.
function longBracketLevel(source, index) {
    if (source[index] !== "[") return -1;
    let cursor = index + 1;
    let level = 0;
    while (source[cursor] === "=") { cursor++; level++; }
    return source[cursor] === "[" ? level : -1;
}

function skipLongBracket(source, index, level) {
    let cursor = index + level + 2;
    for (;;) {
        const close = source.indexOf("]", cursor);
        if (close < 0) return -1;
        let after = close + 1;
        let equals = 0;
        while (source[after] === "=") { after++; equals++; }
        // A closer is `]` + exactly `level` `=` + `]`; `]==x` is payload, not an end.
        if (equals === level && source[after] === "]") return after + 1;
        cursor = close + 1;
    }
}

function stripLexicalUnits(source) {
  let out = "";
  let i = 0;
  let quote = null;
  while (i < source.length) {
    const c = source[i];
    const n = source[i + 1];
    if (!quote && c === "-" && n === "-") {
      const commentLevel = longBracketLevel(source, i + 2);
      if (commentLevel >= 0) {
        const end = skipLongBracket(source, i + 2, commentLevel);
        if (end < 0) throw new Error("unterminated string/long string in generated Luau");
        i = end;
        out += " ";
        continue;
      }
      i += 2;
      while (i < source.length && source[i] !== "\n") i++;
      out += " ";
      continue;
    }
    if (!quote) {
      const stringLevel = longBracketLevel(source, i);
      if (stringLevel >= 0) {
        const end = skipLongBracket(source, i, stringLevel);
        if (end < 0) throw new Error("unterminated string/long string in generated Luau");
        i = end;
        out += " ";
        continue;
      }
    }
    if (quote) {
      if (c === "\\") i += 2;
      else { if (c === quote) quote = null; i++; }
      out += " ";
      continue;
    }
    if (c === '"' || c === "'") { quote = c; i++; out += " "; continue; }
    out += c;
    i++;
  }
  if (quote) throw new Error("unterminated string/long string in generated Luau");
  return out;
}

function validateGeneratedLuau(source) {
  if (typeof source !== "string" || !source.trim()) throw new Error("generated Luau is empty");
  const stripped = stripLexicalUnits(source.replace(/^\uFEFF/, ""));
  const joinedTokenPatterns = [
    /\bend(?:do|local|function|if|for|while|repeat|return)\b/,
    /\bthen(?:local|return|do|for|while|repeat)\b/,
    /\belse(?:local|return|do|for|while|repeat)\b/,
    /\bdo(?:local|return|function|if|for|while|repeat)\b/,
    /\blocal(?:local|function|if|for|while|repeat|return)\b/,
    /\b(?:do|then|else);/
  ];
  for (const pattern of joinedTokenPatterns) {
    if (pattern.test(stripped)) throw new Error(`joined Luau tokens detected: ${pattern}`);
  }
  const stack = [];
  const pairs = { ")":"(", "]":"[", "}":"{" };
  for (const c of stripped) {
    if (c === "(" || c === "[" || c === "{") stack.push(c);
    else if (pairs[c]) {
      if (stack.pop() !== pairs[c]) throw new Error(`unbalanced delimiter near '${c}'`);
    }
  }
  if (stack.length) throw new Error(`unclosed delimiter '${stack[stack.length - 1]}'`);
  const codeSemicolons = (stripped.match(/;/g) || []).length;
  return { ok: true, delimiters: true, codeSemicolons };
}

module.exports = { validateGeneratedLuau };

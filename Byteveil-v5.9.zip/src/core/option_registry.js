"use strict";

// Closed registry of the option surface the shipped route really reads.
// A knob that no code path consumes is worse than no knob at all: the caller believes the
// build is protected. Every key below has a reader in src/ (test-v590-tree.js re-checks
// that claim), and a key that used to exist but no longer drives anything is listed in
// RETIRED so asking for it refuses the build instead of silently doing nothing.

const TOP_LEVEL = new Set([
    "preset", "mode", "strength", "target", "backend", "filename", "seed",
    "transforms", "wrapper", "watermark", "compatibilityRoute",
    "vmPolicy", "functionPolicies", "allowPolicyFallback", "maxOutputBytes",
    "junkForge", "stringCipher", "precheck", "strictOptions"
]);

const TRANSFORM_KEYS = new Set([
    "rename", "strings", "numbers", "controlFlow", "functionTransform", "watermark",
    "opcodeWhitening", "opcodeGuard", "opcodeCount", "shardMin", "shardMax"
]);

const WRAPPER_KEYS = new Set([
    "enabled", "argumentCount", "setmeta", "invoke", "returnMode", "shape"
]);

const JUNK_FORGE_KEYS = new Set([
    "enabled", "maxBytes", "paddingCapBytes", "floorBytes", "headroomBytes",
    "containerMinBytes", "containerMaxBytes", "bankMin", "bankMax"
]);

const PRECHECK_KEYS = new Set(["enabled"]);

const RETIRED = new Map([
    ["debug", "no live module reads a debug flag; build truth is reported in vmMeta/stats"],
    ["nestedSourceEngine", "the nest preset always wraps with the runtime loader reported in stats.nestedSourceEngine; the key selected nothing"],
    ["nestedProfile", "every shipped VM version pins the profile in customVM.js (chosenNestedProfile ignores the caller) and the nest branch hardcodes full, so no caller value was ever applied"],
    ["transforms.gsubAnchor", "no route implements a gsub anchor; the compatibility shell hardcodes it off"],
    ["transforms.payloadDecoys", "no route emits decoy payloads from this key; carrier decoys belong to JunkForge/VeilBlob"]
]);

// A registered key is only half the contract: `normalizeOptions` and `resolveTarget` each
// map an unrecognised *value* onto a working one, so a typo used to change which engine
// produced the artifact instead of refusing the build. `backend` was the worst case — any
// string outside its set silently left the custom-VM route for the source-container route,
// with the guard/JunkForge key binding switched off too. The sets below are the values the
// code actually branches on (test-v590-tree.js re-checks that every one still routes).
const ENUMS = new Map([
    ["backend", new Set(["vm35", "vm33", "source"])],
    ["target", new Set(["auto", "lua", "luau"])],
    ["mode", new Set(["stack", "register", "hybrid"])],
    ["wrapper.returnMode", new Set(["setmetatable", "direct", "gsub"])]
]);

const ENUM_REASONS = new Map([
    ["backend", "vm35 and vm33 run the shipped custom VM, source builds the source-container route; anything else silently downgraded the build and skipped the guard/JunkForge key binding"],
    ["target", "anything else fell through to auto-detection, so a typo changed the host the artifact was built for"],
    ["mode", "stack and register select the VM, hybrid leaves the choice to the function policies; anything else was mapped to register"],
    ["wrapper.returnMode", "the wrapper branches only on setmetatable and gsub, so any other string produced the direct-return shape"]
]);

function optionValueAt(options, key) {
    const holder = key.includes(".") ? (options[key.split(".")[0]] || {}) : options;
    return holder[key.includes(".") ? key.split(".")[1] : key];
}

function enablesValue(value) {
    if (value === undefined || value === null || value === false || value === 0 || value === "") return false;
    if (typeof value === "number") return value > 0;
    return true;
}

function keysOf(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? Object.keys(value) : [];
}

// Returns { notApplied } and refuses the build when the caller asked for something the
// engine no longer implements. Unknown keys are reported (not fatal) unless the caller
// sets strictOptions, so an existing script cannot start failing on an upgrade.
function auditOptions(options = {}) {
    const notApplied = [];
    const complaints = [];

    for (const [key, reason] of RETIRED) {
        if (enablesValue(optionValueAt(options, key))) {
            complaints.push(`ByteVeil v5.9.0 option ${key} is not implemented (${reason})`);
        }
    }

    for (const [key, allowed] of ENUMS) {
        const value = optionValueAt(options, key);
        if (value === undefined || value === null || value === "") continue;
        if (typeof value !== "string" || !allowed.has(value)) {
            complaints.push(`ByteVeil v5.9.0 option ${key} has unsupported value ${JSON.stringify(value)} `
                + `(accepted: ${[...allowed].join(", ")}); ${ENUM_REASONS.get(key)}`);
        }
    }

    for (const key of Object.keys(options)) {
        if (TOP_LEVEL.has(key)) continue;
        if (RETIRED.has(key)) continue;
        notApplied.push(key);
    }
    const bucket = [
        ["transforms", TRANSFORM_KEYS],
        ["wrapper", WRAPPER_KEYS],
        ["junkForge", JUNK_FORGE_KEYS],
        ["precheck", PRECHECK_KEYS]
    ];
    for (const [parent, allowed] of bucket) {
        for (const key of keysOf(options[parent])) {
            if (!allowed.has(key) && !RETIRED.has(`${parent}.${key}`)) notApplied.push(`${parent}.${key}`);
        }
    }

    if (complaints.length) throw new Error(complaints.join(" | "));
    if (options.strictOptions === true && notApplied.length) {
        throw new Error(`ByteVeil v5.9.0 strictOptions: unrecognized option key(s) ${notApplied.join(", ")}`);
    }
    return { notApplied };
}

module.exports = {
    TOP_LEVEL, TRANSFORM_KEYS, WRAPPER_KEYS, JUNK_FORGE_KEYS, PRECHECK_KEYS,
    RETIRED, ENUMS, ENUM_REASONS, optionValueAt, auditOptions, enablesValue
};

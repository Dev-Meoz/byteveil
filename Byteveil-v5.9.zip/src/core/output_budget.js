"use strict";

// The brief uses KB, so report decimal units (1 KB = 1000 bytes).
const TARGET_MIN_BYTES = 375_000;
const TARGET_MAX_BYTES = 475_000;

function analyzeOutputBudget({ source = "", output = "", preset = "custom", vmMeta = {}, options = {}, floorBytes = null, capBytes = null, paddingBytes = 0 } = {}) {
  const sourceBytes = Buffer.byteLength(String(source), "utf8");
  const outputBytes = Buffer.byteLength(String(output), "utf8");
  const extraBytes = outputBytes - sourceBytes;
  const layers = Math.max(0, Number(vmMeta.nestedObfuscationLayers) || 0);
  const singleLayer = vmMeta.singleLayerEngine === true;
  // Callers with a JunkForge envelope pass it in; callers without one keep the
  // historical 375–475 KB nested-output window.
  const targetMaxBytes = Number.isFinite(Number(capBytes)) ? Math.floor(Number(capBytes)) : TARGET_MAX_BYTES;
  const targetMinBytes = Number.isFinite(Number(floorBytes))
    ? Math.floor(Number(floorBytes))
    : (singleLayer ? 0 : TARGET_MIN_BYTES);
  const padding = Math.max(0, Number(paddingBytes) || 0);
  const protectionBytes = Math.max(0, outputBytes - padding);
  const normalizedPreset = String(preset || "custom").toLowerCase();
  const status = outputBytes > targetMaxBytes
    ? "over-target"
    : (outputBytes < targetMinBytes && !(singleLayer && !Number.isFinite(Number(floorBytes))))
      ? "below-target"
      : "in-target";

  const likelyContributors = [];
  if (sourceBytes >= TARGET_MIN_BYTES) likelyContributors.push("large-input-source");
  if (["df", "lz", "maximum"].includes(normalizedPreset)) likelyContributors.push("high-strength-preset");
  if (layers >= 7) likelyContributors.push("nested-protection-runtime");
  if (options.wrapper?.enabled !== false) likelyContributors.push("wrapper");
  if (options.transforms?.watermark) likelyContributors.push("watermark");
  if (vmMeta.backend === "custom-vm") likelyContributors.push("vm-runtime-and-serialized-payload");
  if (padding > 0) likelyContributors.push("junk-forge-padding");

  let recommendation;
  if (status === "over-target") {
    if (options.wrapper?.enabled === false && options.transforms?.watermark === false) {
      recommendation = `Output exceeds ${targetMaxBytes} bytes even with optional wrapper and watermark disabled. Profile serialized VM payload and repeated runtime-helper overhead; no protection layer or preset was removed.`;
    } else {
      recommendation = `Output exceeds ${targetMaxBytes} bytes. No protection layer or preset was removed. Compare the same source/preset with optional wrapper and watermark disabled, then profile serialized VM payload and runtime-helper overhead before changing protection.`;
    }
  } else if (status === "below-target") {
    recommendation = padding > 0
      ? `Output is below the ${targetMinBytes}-byte density floor even though JunkForge padding was applied, which means the profile ran out of room before the floor. Compare by source size and preset.`
      : `Output is below the ${targetMinBytes}-byte density floor. JunkForge did not apply (disabled, floor already met by the payload, or no statement boundary at the prefix point).`;
  } else if (padding > 0) {
    recommendation = `Output is inside the ${targetMinBytes}–${targetMaxBytes} byte envelope. ${padding} bytes are live-verified JunkForge padding; ${protectionBytes} bytes are protection payload. Size is a density property of the build, not a measure of protection strength.`;
  } else if ((vmMeta.version === "4.7.5" || vmMeta.version === "4.7.6" || vmMeta.version === "4.7.7" || vmMeta.version === "4.7.8" || vmMeta.version === "4.7.9" || (vmMeta.version === "5.0.0" || vmMeta.version === "5.3.0" || vmMeta.version === "5.4.0" || (vmMeta.version === "5.5.0" || vmMeta.version === "5.6.0" || vmMeta.version === "5.7.0" || vmMeta.version === "5.8.0" || vmMeta.version === "5.9.0")))) {
    recommendation = "Output is within the binary-region VM output budget. No nested source-loader stages or padding were added.";
  } else if (singleLayer) {
    recommendation = "Output is within the single-layer output budget. No padding or nested source stages were added.";
  } else {
    recommendation = `Output is within the ${targetMinBytes}–${targetMaxBytes} byte target window.`;
  }

  return {
    unit: "bytes",
    targetMinBytes,
    targetMaxBytes,
    targetMinKB: targetMinBytes / 1000,
    targetMaxKB: targetMaxBytes / 1000,
    targetMinKiB: Number((targetMinBytes / 1024).toFixed(2)),
    targetMaxKiB: Number((targetMaxBytes / 1024).toFixed(2)),
    sourceBytes,
    outputBytes,
    paddingBytes: padding,
    protectionBytes,
    overheadBytes: extraBytes,
    outputToSourceRatio: sourceBytes > 0 ? Number((outputBytes / sourceBytes).toFixed(3)) : null,
    preset: normalizedPreset,
    nestedLayers: layers,
    status,
    withinTarget: status === "in-target",
    overMaximum: status === "over-target",
    likelyContributors,
    recommendation
  };
}

module.exports = { TARGET_MIN_BYTES, TARGET_MAX_BYTES, analyzeOutputBudget };

module.exports = { TARGET_MIN_BYTES, TARGET_MAX_BYTES, analyzeOutputBudget };

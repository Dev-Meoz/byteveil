"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("node:crypto");
const { mangleGeneratedInternals } = require("../utils/lua_identifier_rewriter");
const { encodeDiagnosticStrings } = require("../utils/diagnostic_string_encoder");
const { engineConfig, loadEnv } = require("./env");
const { getPreset } = require("../presets");
const watermarkModule = require("../transforms/watermark");
const { minify, wrap } = require("../wrappers/WrapInFunction");
// One compatibility engine serves both targets: inside `source_engine_v46_compat` the
// `target` option only selects its own `runtime` label, so a second "Luau engine" import
// would claim a route that does not exist.
const { buildSourceEngine: buildCompatSourceEngine } = require("../backend/source_engine_v46_compat");
const { printChunk } = require("../backend/luau_printer");
const { resolveTarget } = require("./target");
const { Lexer } = require("../frontend/lexer");
const { Parser } = require("../frontend/parser");
const { build: buildIR } = require("../compiler/ir_builder");
const { mangle } = require("../mangler");
const { apply: applyProtectionTransforms, buildProtectionPlan } = require("../transforms");
const { build: buildCustomVM } = require("../customVM");
const { analyzeOutputBudget, TARGET_MAX_BYTES } = require("./output_budget");
const precheckModule = require("./precheck");
const { auditOptions } = require("./option_registry");
const { applyJunkForge, planJunkForge, planForgeLatch, outputCapForTarget, MIN_FLOOR_BYTES } = require("../obfuscation/junk_forge");
const { prepareFunctionPolicy, normalizePolicy, rememberPolicyNames } = require("../compiler/function_policy");
const { ENGINE_VERSION, NESTED_PROFILE, PAYLOAD_LAYOUT } = require("./version");
const { wrapSource: wrapLegacyNestedSource } = require("../protection/nested_obfuscation");
const ACTIVE_VM_VERSION = ENGINE_VERSION;

// `wrap()` already honours the boolean form (`{wrapper:false}` => minify only), so
// `obfuscate()` has to read it the same way: spreading a boolean drops every key and
// the preset's `enabled:true` silently wins, shipping a wrapper the caller removed.
function wrapperSpec(value) {
    if (value === false) return { enabled: false };
    if (value === true) return { enabled: true };
    return typeof value === "object" && value !== null ? value : {};
}

function merge(a = {}, b = {}) {
    return {
        ...a,
        ...b,
        transforms: { ...(a.transforms || {}), ...(b.transforms || {}) },
        wrapper: { ...wrapperSpec(a.wrapper), ...wrapperSpec(b.wrapper) }
    };
}

function normalizeOptions(options = {}) {
    loadEnv();
    const base = options.preset ? getPreset(options.preset) : {};
    const merged = merge(base, options);
    const cfg = engineConfig(merged);
    const requestedLegacyMode = options.mode === "stack" || options.mode === "register";
    cfg.mode = cfg.mode === "stack" ? "stack" : "register";
    cfg.strength = Math.max(100, Math.min(10000, Number(options.strength ?? merged.strength ?? 1000) || 1000));
    cfg.target = options.target || "auto";
    cfg.preset = options.preset || "custom";
    cfg.backend = options.backend || "vm35";
    cfg.filename = options.filename || "";
    cfg.transforms = { ...(cfg.transforms || {}) };
    cfg.wrapper = { ...(cfg.wrapper || {}) };
    cfg.compatibilityRoute = options.compatibilityRoute === true || merged.compatibilityRoute === true;
    cfg.wrapper.enabled = cfg.wrapper.enabled !== false;
    if (!Number.isInteger(cfg.wrapper.argumentCount) || cfg.wrapper.argumentCount < 0) cfg.wrapper.argumentCount = 8;
    // `returnMode` is the shape selector and `setmeta` is its legacy boolean alias — env.js
    // derives returnMode from setmeta when the caller names neither. Two holes followed from
    // that pairing: wrap() tests `returnMode === "setmetatable" || setmeta`, so `{returnMode:
    // "direct"}` with setmeta at its true default emitted the bootstrap and the knob did
    // nothing; and every preset spells `returnMode: "setmetatable"`, so a caller flipping
    // only `{setmeta: false}` was overruled by a preset it never asked about. The caller's
    // own wrapper spec decides this pair, and the named selector wins.
    const callerWrapper = wrapperSpec(options.wrapper);
    if (callerWrapper.setmeta === false && callerWrapper.returnMode === undefined) cfg.wrapper.returnMode = "direct";
    if (cfg.wrapper.returnMode === "direct") cfg.wrapper.setmeta = false;

    // Keep the historical explicit `mode` API for callers which pass mode directly.
    // New callers use the named policy selector: VM-A defaults to register, VM-B to stack.
    cfg.vmPolicy = options.vmPolicy !== undefined
        ? normalizePolicy(options.vmPolicy)
        : (options.functionPolicies !== undefined ? "balanced" : (requestedLegacyMode ? "legacy-mode" : normalizePolicy(merged.vmPolicy || "balanced")));
    cfg.functionPolicies = options.functionPolicies && typeof options.functionPolicies === "object"
        ? { ...options.functionPolicies }
        : {};
    if (cfg.vmPolicy === "balanced") cfg.mode = "register";
    else if (cfg.vmPolicy === "hardened") cfg.mode = "stack";
    else if (cfg.vmPolicy === "compiler-transformed") cfg.mode = "register";
    // Density envelope: the historical 475 KB ceiling is replaced by the Luraph
    // size envelope (2.5 MB Lua / 3 MB Luau) once JunkForge padding is in play.
    // An explicit maxOutputBytes from the caller always wins.
    cfg.maxOutputBytes = Number.isFinite(Number(options.maxOutputBytes))
        ? Math.max(1, Math.floor(Number(options.maxOutputBytes)))
        : outputCapForTarget(cfg.target === "luau" ? "luau" : "lua");
    cfg.maxOutputBytesWasRequested = Number.isFinite(Number(options.maxOutputBytes));
    cfg.junkForge = typeof merged.junkForge === "object" && merged.junkForge !== null
        ? { ...merged.junkForge, ...(typeof options.junkForge === "object" && options.junkForge !== null ? options.junkForge : {}) }
        : (options.junkForge === false ? { enabled: false } : { ...(merged.junkForge || {}) });
    cfg.allowPolicyFallback = options.allowPolicyFallback === true;
    // `engineConfig` is a whitelist, so any knob the pipeline reads has to be carried here
    // or a caller-supplied `false` would be silently dropped and the feature unswitchable.
    cfg.stringCipher = merged.stringCipher !== false;
    cfg.precheck = merged.precheck === false
        ? { enabled: false }
        : (merged.precheck && typeof merged.precheck === "object" ? { ...merged.precheck } : {});
    return cfg;
}

function canVirtualize(ast) {
    const UNSAFE = new Set(["ForNum", "ForIn", "Repeat", "Do"]);
    let safe = true;
    function walkExpr(node) {
        if (!node || !safe) return;
        if (node.type === "FunctionExpr") {
            (node.body || []).forEach(walkStmt);
            return;
        }
        if (node.type === "Binary") { walkExpr(node.left); walkExpr(node.right); return; }
        if (node.type === "Unary") { walkExpr(node.arg); return; }
        if (node.type === "Index") { walkExpr(node.obj); walkExpr(node.key); return; }
        if (node.type === "Call") { walkExpr(node.callee); (node.args || []).forEach(walkExpr); return; }
        if (node.type === "Table") {
            (node.fields || []).forEach(f => { walkExpr(f.key); walkExpr(f.value); });
            return;
        }
        const known = new Set(["Number","String","Boolean","Nil","Id","Vararg"]);
        if (!known.has(node.type)) safe = false;
    }
    function walkStmt(node) {
        if (!node || !safe) return;
        if (UNSAFE.has(node.type)) { safe = false; return; }
        switch (node.type) {
            case "Local":
            case "Assign":
                (node.values || []).forEach(walkExpr); (node.vars || []).forEach(v => typeof v === "object" && walkExpr(v)); break;
            case "Compound": walkExpr(node.left); walkExpr(node.value); break;
            case "CallStmt": walkExpr(node.call); break;
            case "Return": (node.values || []).forEach(walkExpr); break;
            case "If":
                (node.branches || []).forEach(b => { walkExpr(b.cond); (b.body || []).forEach(walkStmt); });
                (node.elseBody || []).forEach(walkStmt); break;
            case "While":
                walkExpr(node.cond); (node.body || []).forEach(walkStmt); break;
            case "LocalFunction":
            case "Function":
                (node.fn?.body || []).forEach(walkStmt); break;
            case "Break":
                // Supported by the VM.
                break;
            default:
                safe = false;
        }
    }
    (ast?.body || []).forEach(walkStmt);
    return safe;
}


const VM_EXPR_TYPES = new Set(["Number","String","Boolean","Nil","Id","Vararg","Unary","Binary","Index","Call","FunctionExpr","Table","IfElseExpression"]);
const VM_STMT_TYPES = new Set(["Local","Assign","Compound","CallStmt","Return","If","While","Repeat","Do","ForNum","ForIn","Break","Continue","LocalFunction","Function"]);

function normalizeVMSourceAST(ast, target) {
    if (!ast || ast.type !== "Chunk") return ast;

    // Reserve every existing string atom so compiler-generated temporaries cannot
    // collide with source locals, globals, keys, or literal strings.
    const usedNames = new Set();
    const seenNodes = new WeakSet();
    function collectNames(value) {
        if (typeof value === "string") { usedNames.add(value); return; }
        if (!value || typeof value !== "object" || seenNodes.has(value)) return;
        seenNodes.add(value);
        if (Array.isArray(value)) { value.forEach(collectNames); return; }
        for (const child of Object.values(value)) collectNames(child);
    }
    collectNames(ast);
    let tempSequence = 0;
    function tempName(role) {
        let candidate;
        do { candidate = `__bv479_${role}_${++tempSequence}`; } while (usedNames.has(candidate));
        usedNames.add(candidate);
        return candidate;
    }

    function expr(node) {
        if (!node || typeof node !== "object") return node;
        switch (node.type) {
            case "Binary": expr(node.left); expr(node.right); break;
            case "Unary": expr(node.arg); break;
            case "Index": expr(node.obj); expr(node.key); break;
            case "Call": expr(node.callee); (node.args || []).forEach(expr); break;
            case "FunctionExpr": node.body = normalizeBody(node.body || []); node.returnType = null; node.params = (node.params || []).map(String); break;
            case "Table": (node.fields || []).forEach((f) => { expr(f.key); expr(f.value); }); break;
            case "IfElseExpression": expr(node.cond); expr(node.consequent); expr(node.alternate); break;
        }
        return node;
    }

    function functionAssignment(node) {
        const parts = Array.isArray(node.namePath) ? node.namePath : [];
        if (parts.length <= 1 && !node.method) return node;
        if (!parts.length) return node;
        let object = { type: "Id", name: String(parts[0].value) };
        for (let i = 1; i < parts.length - 1; i++) {
            object = { type: "Index", obj: object, key: { type: "String", value: String(parts[i].value) } };
        }
        const key = { type: "String", value: String(parts[parts.length - 1].value) };
        const sourceParams = (node.fn?.params || []).map(String);
        // The parser records the method token as a synthetic leading parameter.
        // Lua/Luau method syntax instead supplies the receiver as implicit `self`.
        // Normalize that slot now so strict VM codegen preserves colon-call semantics.
        const params = node.method
            ? ["self", ...sourceParams.slice(1)]
            : sourceParams;
        const fn = {
            type: "FunctionExpr",
            params,
            vararg: !!node.fn?.vararg,
            body: normalizeBody(node.fn?.body || []),
            returnType: null
        };
        const normalized = { type: "Assign", vars: [{ type: "Index", obj: object, key }], values: [fn], __normalizedMethod: true };
        if (node.__line) Object.defineProperty(normalized, "__line", { value: node.__line, enumerable: false, configurable: true });
        if (node.__col) Object.defineProperty(normalized, "__col", { value: node.__col, enumerable: false, configurable: true });
        return normalized;
    }

    function statement(node) {
        if (!node) return null;
        switch (node.type) {
            case "Type":
            case "ExportType":
                return null; // compile-time-only Luau type declarations
            case "Local":
                for (const variable of node.vars || []) {
                    if (variable && variable.typeAnnotation) variable.typeAnnotation = null;
                    if (variable?.attribute === "<const>") variable.attribute = null;
                    if (variable?.attribute === "<close>") {
                        throw new Error("ByteVeil v5.9.0 strict VM rejected input: Luau <close> local requires close-semantics lowering");
                    }
                }
                node.values = (node.values || []).map(expr);
                return node;
            case "LocalFunction":
                node.fn = node.fn || { body: [], params: [], vararg: false };
                node.fn.params = (node.fn.params || []).map(String);
                node.fn.returnType = null;
                node.fn.body = normalizeBody(node.fn.body || []);
                return node;
            case "Function": {
                const normalized = functionAssignment(node);
                if (normalized !== node) return normalized;
                node.fn = node.fn || { body: [], params: [], vararg: false };
                node.fn.params = (node.fn.params || []).map(String);
                node.fn.returnType = null;
                node.fn.body = normalizeBody(node.fn.body || []);
                return node;
            }
            case "ForIn":
                node.names = (node.names || []).map((entry) => typeof entry === "string" ? entry : String(entry?.name ?? "_"));
                node.it = (node.it || []).map(expr);
                node.body = normalizeBody(node.body || []);
                return node;
            case "If":
                node.branches = (node.branches || []).map((b) => ({ ...b, cond: expr(b.cond), body: normalizeBody(b.body || []) }));
                node.elseBody = normalizeBody(node.elseBody || []);
                return node;
            case "While":
                node.cond = expr(node.cond); node.body = normalizeBody(node.body || []); return node;
            case "Repeat":
                node.body = normalizeBody(node.body || []); node.cond = expr(node.cond); return node;
            case "Do": node.body = normalizeBody(node.body || []); return node;
            case "ForNum": node.start = expr(node.start); node.end = expr(node.end); node.step = expr(node.step); node.body = normalizeBody(node.body || []); return node;
            case "Assign": {
                node.vars = (node.vars || []).map(expr);
                node.values = (node.values || []).map(expr);
                const vars = node.vars;
                if (vars.length <= 1) return node;
                const names = vars.map((v) => typeof v === "string" ? v : v?.type === "Id" ? String(v.name) : null);
                const needsLowering = vars.some((v) => v && typeof v === "object" && v.type !== "Id")
                    || names.some((name, index) => name !== null && names.indexOf(name) !== index);
                if (!needsLowering) return node;

                // Lua evaluates every indexed assignment target (table and key) before
                // evaluating the RHS list. Capture those addresses, then capture the
                // adjusted RHS values, and only then perform stores in source order.
                const lowered = [];
                const targets = [];
                for (const variable of vars) {
                    if (typeof variable === "string" || variable?.type === "Id") {
                        targets.push(typeof variable === "string" ? { type: "Id", name: variable } : variable);
                    } else if (variable?.type === "Index") {
                        const objectName = tempName("lhs_object");
                        const keyName = tempName("lhs_key");
                        lowered.push({ type: "Local", vars: [{ type: "Id", name: objectName }], values: [variable.obj] });
                        lowered.push({ type: "Local", vars: [{ type: "Id", name: keyName }], values: [variable.key] });
                        targets.push({ type: "Index", obj: { type: "Id", name: objectName }, key: { type: "Id", name: keyName } });
                    } else {
                        // Preserve fail-closed behavior for targets the VM cannot lower.
                        return node;
                    }
                }

                const valueNames = vars.map(() => tempName("rhs"));
                lowered.push({
                    type: "Local",
                    vars: valueNames.map((name) => ({ type: "Id", name })),
                    values: node.values
                });
                for (let index = 0; index < targets.length; index++) {
                    lowered.push({
                        type: "Assign",
                        vars: [targets[index]],
                        values: [{ type: "Id", name: valueNames[index] }]
                    });
                }
                return lowered;
            }
            case "Compound": node.left = expr(node.left); node.value = expr(node.value); return node;
            case "CallStmt": node.call = expr(node.call); return node;
            case "Return": node.values = (node.values || []).map(expr); return node;
            default:
                if (node.body) node.body = normalizeBody(node.body);
                return node;
        }
    }

    function normalizeBody(body) {
        const out = [];
        for (const node of body || []) {
            const value = statement(node);
            if (Array.isArray(value)) out.push(...value);
            else if (value) out.push(value);
        }
        return out;
    }

    ast.body = normalizeBody(ast.body || []);
    const retained = new Set(["goto", "labels", "stringInterpolation", "unsupported", "compoundSyntax"]);
    for (const key of Object.keys(ast.features || {})) ast.features[key] = retained.has(key) ? !!ast.features[key] : false;
    if (ast.features) ast.features.unsupported = !!(ast.features.goto || ast.features.labels || ast.features.stringInterpolation || ast.features.compoundSyntax);
    Object.defineProperty(ast, "__vmNormalized", { value: { version: ACTIVE_VM_VERSION, target, erasedTypes: true, normalizedMethods: true }, enumerable: false, configurable: true });
    return ast;
}

function containsExprType(node, target) {
    if (!node || typeof node !== "object") return false;
    if (node.type === target) return true;
    switch (node.type) {
        case "Binary": return containsExprType(node.left, target) || containsExprType(node.right, target);
        case "Unary": return containsExprType(node.arg, target);
        case "Index": return containsExprType(node.obj, target) || containsExprType(node.key, target);
        case "Call": return containsExprType(node.callee, target) || (node.args || []).some((x) => containsExprType(x, target));
        case "FunctionExpr": return (node.body || []).some((x) => containsStmtExprType(x, target));
        case "Table": return (node.fields || []).some((f) => containsExprType(f.key, target) || containsExprType(f.value, target));
        case "IfElseExpression": return containsExprType(node.cond, target) || containsExprType(node.consequent, target) || containsExprType(node.alternate, target);
        default: return false;
    }
}

function containsStmtExprType(node, target) {
    if (!node || typeof node !== "object") return false;
    switch (node.type) {
        case "Local":
        case "Assign": return (node.values || []).some((x) => containsExprType(x, target)) || (node.vars || []).some((x) => containsExprType(x, target));
        case "Compound": return containsExprType(node.left, target) || containsExprType(node.value, target);
        case "CallStmt": return containsExprType(node.call, target);
        case "Return": return (node.values || []).some((x) => containsExprType(x, target));
        case "If": return (node.branches || []).some((b) => containsExprType(b.cond, target) || (b.body || []).some((x) => containsStmtExprType(x, target))) || (node.elseBody || []).some((x) => containsStmtExprType(x, target));
        case "While": return containsExprType(node.cond, target) || (node.body || []).some((x) => containsStmtExprType(x, target));
        case "Do": return (node.body || []).some((x) => containsStmtExprType(x, target));
        case "ForNum": return containsExprType(node.start, target) || containsExprType(node.end, target) || containsExprType(node.step, target) || (node.body || []).some((x) => containsStmtExprType(x, target));
        case "LocalFunction":
        case "Function": return (node.fn?.body || []).some((x) => containsStmtExprType(x, target));
        default: return false;
    }
}

function assertCustomVMCompatible(ast) {
    const errors = [];
    function expr(n) {
        if (!n) return;
        if (!VM_EXPR_TYPES.has(n.type)) { errors.push(`unsupported expression: ${n.type}`); return; }
        if (n.type === "Number") {
            if (!Number.isFinite(n.value)) {
                errors.push(`non-finite numeric literal requires source route: ${n.raw || n.value}`);
            } else {
                const raw = String(n.raw ?? n.value).replace(/_/g, "");
                                const integerLiteral = /^(?:0[xX][0-9a-fA-F]+|0[bB][01]+|[0-9]+)$/.test(raw);
                if (integerLiteral && !Number.isSafeInteger(n.value)) {
                    errors.push(`unsafe integer literal requires native source route: ${n.raw || n.value}`);
                }
            }
        }
        if (n.type === "IfElseExpression") {
            expr(n.cond); expr(n.consequent); expr(n.alternate);
        }
        if (n.type === "String") {
            // v4.6.6 stores string constants as UTF-8 bytes in the packed payload.
            // Lua strings are byte sequences, so every byte (including non-ASCII UTF-8
            // bytes and control bytes) is materialized by the byte-safe runtime reader.
            // Buffer conversion also makes this check explicit and rejects no valid UTF-8
            // script text merely because it contains non-Latin characters.
            Buffer.from(String(n.value), "utf8");
        }
            switch (n.type) {
            case "Binary": expr(n.left); expr(n.right); break;
            case "Unary": expr(n.arg); break;
            case "Index": expr(n.obj); expr(n.key); break;
            case "Call":
                expr(n.callee);
                (n.args || []).forEach(expr);
                // Expression calls are lowered to a single-result CALL by the VM.
                // A nested call used as an ordinary argument therefore has the
                // same single-result semantics as native Lua/Luau. Multireturn
                // hazards are rejected only in contexts that actually require
                // multiple results (assignment, return, table tail, iterator setup).
                break;
            case "FunctionExpr":
                (n.body || []).forEach(stmt);
                break;
            case "Table":
                (n.fields || []).forEach((f, index) => {
                    if (f.key) expr(f.key);
                    expr(f.value);
                    // A trailing list field keeps every result of its call or vararg:
                    // CALLP materialises the full result pack and APPEND writes it into
                    // the table, so this shape no longer needs the source route.
                });
                break;
        }
    }
    function stmt(n) {
        if (!n) return;
        if (!VM_STMT_TYPES.has(n.type)) { errors.push(`unsupported statement: ${n.type}`); return; }
        switch (n.type) {
            case "Local": case "Assign": {
                const values = n.values || [];
                const vars = n.vars || [];
                values.forEach(expr); vars.forEach(v => typeof v === "object" && expr(v));
                if (vars.length > 1) {
                    const ids = vars.map(v => typeof v === "string" ? { type: "Id", name: v } : v);
                    if (ids.some(v => !v || v.type !== "Id")) errors.push("indexed multiple assignment requires source route");
                    const seen = new Set();
                    for (const v of ids) {
                        if (v?.type === "Id") {
                            const name = String(v.name);
                            if (seen.has(name)) errors.push("repeated assignment target requires source route");
                            seen.add(name);
                        }
                    }
                }
                const hasVarargTail = values.length > 0 && values[values.length - 1]?.type === "Vararg";
                if (hasVarargTail) {
                    const prefixCount = values.length - 1;
                    const spreadSupported = vars.length > prefixCount && vars.every((v) => (typeof v === "string") || v?.type === "Id");
                    if (!spreadSupported) errors.push("trailing vararg assignment requires identifier targets and at least one expanded target");
                }
                break;
            }
            case "Compound": expr(n.left); expr(n.value); if (n.left?.type !== "Id") errors.push("compound assignment target must be identifier"); break;
            case "CallStmt": expr(n.call); break;
            case "Return":
                (n.values || []).forEach(expr);
                // v4.7.9 lowers an expandable final Call through dedicated TAILCALL*
                // opcodes, retaining the exact return-value count (including nils).
                break;
            case "If": (n.branches || []).forEach(b => { expr(b.cond); (b.body || []).forEach(stmt); }); (n.elseBody || []).forEach(stmt); break;
            case "While": expr(n.cond); (n.body || []).forEach(stmt); break;
            case "Repeat": (n.body || []).forEach(stmt); expr(n.cond); break;
            case "Do": (n.body || []).forEach(stmt); break;
            case "ForNum": expr(n.start); expr(n.end); expr(n.step); (n.body || []).forEach(stmt); break;
            case "ForIn":
                if (!Array.isArray(n.names) || !n.names.length || !Array.isArray(n.it) || !n.it.length || n.it.length > 3) errors.push("generic-for iterator setup shape is unsupported");
                if (n.it?.length && n.it[n.it.length - 1]?.type === "Vararg") errors.push("generic-for vararg iterator expansion is not supported by this VM path");
                (n.it || []).forEach(expr);
                (n.body || []).forEach(stmt);
                break;
            case "Break": case "Continue": break;
            case "LocalFunction": case "Function":
                (n.fn?.body || []).forEach(stmt); break;
        }
    }
    (ast.body || []).forEach(stmt);
    if (ast?.features) {
        for (const key of ["typeSyntax","attributes","goto","labels","ifExpression","stringInterpolation","unsupported","compoundSyntax"]) {
            if (ast.features[key]) errors.push(`unsupported syntax feature: ${key}`);
        }
    }
    if (errors.length) {
        const unique = [...new Set(errors)];
        throw new Error(`ByteVeil v5.9.0 strict VM rejected input: ${unique.join("; ")}`);
    }
}

function assertNoUnsafeStackClosures(ast, mode) {
    if (mode !== "stack") return;
    const reserved = new Set(["_ENV","_G","game","workspace","script","shared","print","warn","error","assert","pairs","ipairs","next","type","typeof","tostring","tonumber","select","unpack","require","getmetatable","setmetatable","rawget","rawset","rawequal","rawlen","string","table","math","coroutine","bit32","os","debug","utf8","task","wait","delay","spawn","tick","pcall","xpcall"]);

    function collectBodyBindings(body, out) {
        for (const s of body || []) {
            if (!s) continue;
            if (s.type === "Local") for (const v of s.vars || []) out.add(String(typeof v === "string" ? v : v?.name));
            else if (s.type === "LocalFunction") out.add(String(s.name));
            else if (s.type === "ForNum") out.add(String(s.name));
            else if (s.type === "ForIn") for (const n of s.names || []) out.add(String(n));
        }
    }

    function walkDirect(node, bound, visibleOuter, captures) {
        if (!node || typeof node !== "object") return;
        switch (node.type) {
            case "Id":
                if (visibleOuter.has(String(node.name)) && !bound.has(String(node.name)) && !reserved.has(String(node.name))) captures.add(String(node.name));
                return;
            case "Binary": walkDirect(node.left, bound, visibleOuter, captures); walkDirect(node.right, bound, visibleOuter, captures); return;
            case "Unary": walkDirect(node.arg, bound, visibleOuter, captures); return;
            case "Index": walkDirect(node.obj, bound, visibleOuter, captures); walkDirect(node.key, bound, visibleOuter, captures); return;
            case "Call": walkDirect(node.callee, bound, visibleOuter, captures); (node.args || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); return;
            case "Table": for (const f of node.fields || []) { walkDirect(f.key, bound, visibleOuter, captures); walkDirect(f.value, bound, visibleOuter, captures); } return;
            case "FunctionExpr": case "LocalFunction": case "Function":
                // Nested functions are analyzed separately with the current lexical
                // bindings visible to them; their internals are not direct captures.
                return;
        }
        if (node.type === "Local" || node.type === "Assign") {
            (node.values || []).forEach(x => walkDirect(x, bound, visibleOuter, captures));
            (node.vars || []).forEach(x => typeof x === "object" && walkDirect(x, bound, visibleOuter, captures));
            return;
        }
        if (node.type === "Compound") { walkDirect(node.left, bound, visibleOuter, captures); walkDirect(node.value, bound, visibleOuter, captures); return; }
        if (node.type === "CallStmt") { walkDirect(node.call, bound, visibleOuter, captures); return; }
        if (node.type === "Return") { (node.values || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); return; }
        if (node.type === "If") { for (const b of node.branches || []) { walkDirect(b.cond, bound, visibleOuter, captures); (b.body || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); } (node.elseBody || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); return; }
        if (node.type === "While") { walkDirect(node.cond, bound, visibleOuter, captures); (node.body || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); return; }
        if (node.type === "Do") { (node.body || []).forEach(x => walkDirect(x, bound, visibleOuter, captures)); return; }
        if (node.type === "ForNum") { walkDirect(node.start,bound,visibleOuter,captures); walkDirect(node.end,bound,visibleOuter,captures); walkDirect(node.step,bound,visibleOuter,captures); (node.body||[]).forEach(x=>walkDirect(x,bound,visibleOuter,captures)); return; }
        if (node.type === "ForIn") { (node.it||[]).forEach(x=>walkDirect(x,bound,visibleOuter,captures)); (node.body||[]).forEach(x=>walkDirect(x,bound,visibleOuter,captures)); return; }
    }

    function checkFunction(fn, outerVisible, label) {
        const bound = new Set((fn.params || []).map(String));
        collectBodyBindings(fn.body, bound);
        const captures = new Set();
        for (const s of fn.body || []) walkDirect(s, bound, outerVisible, captures);
        if (captures.size) throw new Error(`ByteVeil v5.9.0 strict VM rejected input: stack closure capture requires source route (${label}: ${Array.from(captures).join(",")})`);
        const visibleForChildren = new Set([...outerVisible, ...bound]);
        walkNested(fn.body, visibleForChildren, `${label}.nested`);
    }
    function walkNested(body, visibleOuter, label) {
        for (const s of body || []) {
            if (!s) continue;
            if (s.type === "LocalFunction" || s.type === "Function") checkFunction(s.fn || { body: [], params: [] }, visibleOuter, `${label}.${s.name || "function"}`);
            else if (s.type === "FunctionExpr") checkFunction(s, visibleOuter, `${label}.expr`);
            else if (s.body) walkNested(s.body, visibleOuter, label);
            if (s.elseBody) walkNested(s.elseBody, visibleOuter, label);
            if (s.branches) for (const b of s.branches || []) walkNested(b.body, visibleOuter, label);
        }
    }

    const rootBound = new Set(ast?.params || []);
    collectBodyBindings(ast?.body, rootBound);
    // Root locals are visible to nested functions declared after their binding.
    walkNested(ast?.body, rootBound, "root");
}

function isTokenStructureSane(tokens) {
    const pairs = { "(": ")", "[": "]", "{": "}" };
    const delimiters = [];
    const blocks = [];
    const values = Array.isArray(tokens) ? tokens.map((t) => t.value) : [];

    for (let index = 0; index < values.length; index++) {
        const value = values[index];
        if (value === "<eof>") break;

        if (Object.prototype.hasOwnProperty.call(pairs, value)) {
            delimiters.push(value);
            continue;
        }
        if (value === ")" || value === "]" || value === "}") {
            const open = delimiters.pop();
            if (!open || pairs[open] !== value) return false;
            continue;
        }

        if (value === "function") {
            blocks.push({ type: "function", needsDo: false });
            continue;
        }
        if (value === "if") {
            blocks.push({ type: "if", needsDo: false });
            continue;
        }
        if (value === "for" || value === "while") {
            blocks.push({ type: value, needsDo: true });
            continue;
        }
        if (value === "repeat") {
            blocks.push({ type: "repeat", needsDo: false });
            continue;
        }
        if (value === "do") {
            const top = blocks[blocks.length - 1];
            if (top && top.needsDo) {
                top.needsDo = false;
            } else {
                blocks.push({ type: "do", needsDo: false });
            }
            continue;
        }
        if (value === "end") {
            const top = blocks.pop();
            if (!top || top.type === "repeat" || top.needsDo) return false;
            continue;
        }
        if (value === "until") {
            const top = blocks.pop();
            if (!top || top.type !== "repeat") return false;
            continue;
        }
    }

    return delimiters.length === 0 && blocks.length === 0;
}

function nativeLuaSyntaxCheck(source) {
    try {
        const { resolveRuntime, runSyntaxCheck } = require("../../tools/native-runtime");
        const executable = resolveRuntime("lua");
        if (!executable) return null;
        return runSyntaxCheck(executable, source, "lua");
    } catch {
        return null;
    }
}


function buildWrappedVMSource(vm, target, seed, opts, runtimeBridgeParam = null) {
    let output = minify(String(vm.output).replace(/\r\n/g, "\n"));
    if (opts.wrapper?.enabled !== false) {
        output = wrap(output, {
            argumentCount: opts.wrapper.argumentCount,
            invoke: opts.wrapper.invoke !== false,
            setmeta: opts.wrapper.setmeta !== false,
            wrapper: true,
            target,
            seed,
            backend: opts.mode,
            mode: opts.mode,
            preserveLayout: target === "luau",
            returnMode: opts.wrapper.returnMode || (opts.wrapper.setmeta === false ? "direct" : "setmetatable"),
            wrapperShape: opts.wrapper.shape || "auto",
            bootstrapCoupling: !runtimeBridgeParam ? (vm.structural?.bootstrapCoupling || null) : null
        });
    }
    return minify(output);
}

function generateFunctionPolicyProvider(entry, target, seed, opts) {
    const fnChunk = {
        type: "Chunk",
        body: [{ type: "Return", values: [entry.fn] }],
        params: [],
        vararg: false,
        features: {}
    };
    if (entry.policy === "compiler-transformed") {
        const source = minify(printChunk(fnChunk, { minify: true }));
        return { source, backend: "compiler-transformed", mode: null, instructionRepresentation: "native-source", serializer: "none", bytecode: null, outputBytes: Buffer.byteLength(source, "utf8") };
    }

    const mode = entry.policy === "hardened" ? "stack" : "register";
    assertCustomVMCompatible(fnChunk);
    const ir = buildIR(fnChunk, mode, ACTIVE_VM_VERSION);
    const protectionPlan = buildProtectionPlan(fnChunk, {
        ...opts.transforms,
        strength: opts.strength,
        seed,
        ir,
        version: ACTIVE_VM_VERSION
    });
    const vm = buildCustomVM(fnChunk, {
        mode,
        seed,
        strength: opts.strength,
        nestedProfile: opts.nestedProfile,
        opcodeWhitening: opts.transforms?.opcodeWhitening !== false,
        protection: protectionPlan,
        ir,
        forgeLatch: opts.forgeLatch || null,
        stringCipher: opts.stringCipher !== false,
        guardLatch: opts.guardLatch || null
    });
    const source = buildWrappedVMSource(vm, target, seed, opts);
    return {
        source,
        backend: mode === "stack" ? "VM-B/stack" : "VM-A/register",
        mode,
        instructionRepresentation: mode === "stack" ? "stack-value-stack-operands-v479" : "register-file-register-operands-v479",
        serializer: "binary-region-v479-semantic-shadow-with-mode-specific-operands",
        bytecode: vm.bytecode,
        outputBytes: Buffer.byteLength(source, "utf8"),
        structural: vm.structural
    };
}

function wrapHybridVMOutput(mainOutput, bridgeName, entries, target, seed, opts) {
    const suffix = (Number(seed) >>> 0).toString(36);
    const bridgeLocal = `__bv_hybrid_table_${suffix}`;
    const resultLocal = `__bv_hybrid_result_${suffix}`;
    const packLocal = `__bv_hybrid_pack_${suffix}`;
    const unpackLocal = `__bv_hybrid_unpack_${suffix}`;
    const fields = entries.map((entry) => `[${JSON.stringify(entry.runtimeName || entry.name)}]=(function(...)${entry.provider.source};end)()`).join(",");
    // Keep the cross-backend bridge as a lexical value. It is passed as a synthetic
    // root VM parameter, never installed in _G/getgenv, so pairs(_G) semantics are not
    // polluted by temporary bridge names.
    const source = `(function(...)local ${bridgeLocal}={${fields}};local function ${packLocal}(...)return{n=select("#",...),...}end;local ${resultLocal}=${packLocal}((function(${bridgeName},...)${mainOutput};end)(${bridgeLocal},...));local ${unpackLocal}=table.unpack or unpack;return ${unpackLocal}(${resultLocal},1,${resultLocal}.n)end)(...)`;
    return minify(source).replace(/\r\n/g, "\n");
}

function buildCompilerTransformedResult(ast, source, target, seed, opts, lexed, functionPolicyPlan = null) {
    let output = minify(printChunk(ast, { minify: true }));
    if (opts.wrapper?.enabled !== false) {
        // This policy explicitly opts out of virtualization; adding a VM wrapper here
        // would misrepresent the selected policy and make the source-transformed mode
        // indistinguishable from a VM route in metadata.
        output = minify(output);
    }
    if (opts.transforms?.watermark) {
        const wmOptions = typeof opts.transforms.watermark === "object"
            ? opts.transforms.watermark
            : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
        output = watermarkModule.prependWatermark(output, wmOptions);
    }
    return {
        output,
        target,
        runtime: target === "luau" ? "native Luau compiler-transformed source" : "native Lua compiler-transformed source",
        layout: "compiler-transformed-source",
        detection: "v5.9.0 explicit compiler-transformed policy; no VM fallback",
        bytecode: null,
        vmMeta: {
            fallback: false,
            backend: "compiler-transformed",
            version: ACTIVE_VM_VERSION,
            vmPolicy: "compiler-transformed",
            sourceReconstruction: true,
            sourceLoaderStages: 0,
            runtimeSourceLoaderCount: 0,
            packedBytecode: false,
            functionPolicyReport: functionPolicyPlan?.report || [],
            explicitFallbacks: functionPolicyPlan?.explicitFallbacks || [],
            warning: "This explicit policy emits transformed source and does not provide VM virtualization."
        },
        validation: { target, backend: "compiler-transformed", parser: "parsed", nativeLua: target === "lua" ? nativeLuaSyntaxCheck(output)?.ok ?? null : null },
        ast,
        analysis: null,
        initialAnalysis: null,
        seed,
        preset: opts.preset || "custom",
        stats: {
            tokens: lexed.tokens.length,
            errors: 0,
            mode: "compiler-transformed",
            bytes: Buffer.byteLength(output, "utf8"),
            sourceBytes: Buffer.byteLength(source, "utf8"),
            bodyOneLine: !/[\r\n]/.test(output),
            hasPlainSource: true,
            hasEncodedPool: false,
            vmVersion: ACTIVE_VM_VERSION,
            cleanOutput: true,
            engine: "ByteVeil Compiler Transformation Pipeline v5.9.0",
            fallback: false,
            fallbackReason: null
        }
    };
}

function buildCustomVMBackend(source, target, seed, opts) {
    // Syntax errors are never swallowed. A valid-but-unsupported feature may
    // use the structural protected-source route; malformed input must report
    // its real lexer/parser diagnostic.
    const lexed = new Lexer(source).lex();
    if (lexed.errors?.length) {
        throw new Error(`ByteVeil v5.9.0 lexer error: ${lexed.errors[0].message}`);
    }

    const parser = new Parser(lexed.tokens);
    const ast = parser.parse();
    if (parser.errors?.length) {
        const structuralOk = isTokenStructureSane(lexed.tokens);
        const nativeCheck = target === "lua" && process.env.BYTEVEIL_SKIP_NATIVE_SYNTAX !== "1"
            ? nativeLuaSyntaxCheck(source)
            : null;
        const validByRuntime = nativeCheck ? nativeCheck.ok : structuralOk;
        if (!structuralOk || (nativeCheck && !nativeCheck.ok)) {
            const first = parser.errors[0];
            const token = lexed.tokens.find((t) => t.line === first?.line && t.col === first?.col);
            const position = first?.line ? `${first.line}:${first.col || 1}` : "unknown position";
            const near = token && token.value !== "<eof>" ? ` near ${JSON.stringify(token.value)}` : "";
            const detail = nativeCheck?.stderr?.trim() || `${first?.message || "Invalid syntax"} at ${position}${near}`;
            throw new Error(`ByteVeil v5.9.0 parser error: ${detail}`);
        }
        if (!opts.compatibilityRoute) {
            const detail = parser.errors.map((x) => x.message).join("; ");
            throw new Error(`ByteVeil v5.9.0 strict VM rejected input: parser capability: ${detail}`);
        }
        const compatibilityEngine = require("../backend/source_engine_v46_compat");
        const protectedSource = compatibilityEngine.buildSourceEngine(source, { target, seed, strength: opts.strength, nestedProfile: opts.nestedProfile });
        let output = minify(protectedSource.output).replace(/\r\n/g, "\n");
        if (opts.wrapper?.enabled !== false) {
            output = wrap(output, { argumentCount: opts.wrapper.argumentCount, invoke: opts.wrapper.invoke !== false, setmeta: opts.wrapper.setmeta !== false, wrapper: true, target, seed, backend: opts.mode, mode: opts.mode, preserveLayout: target === "luau", wrapperShape: opts.wrapper.shape || "auto", returnMode: opts.wrapper.returnMode || (opts.wrapper.setmeta === false ? "direct" : "setmetatable") });
            output = minify(output);
        }
        if (opts.transforms?.watermark) {
            const wmOptions = typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
            output = watermarkModule.prependWatermark(output, wmOptions);
        }
        if (/string\.char/.test(output)) throw new Error("ByteVeil v4.2 compatibility route invariant failed: string.char emitted");
        return { output, target, runtime: protectedSource.runtime, layout: "structural-source-v35", detection: "v4.7.9 explicit compatibility source route", bytecode: null, vmMeta: { fallback: true, backend: "structural-source", version: "4.7.9", reason: "parser capability fallback (explicit compatibilityRoute=true)", strength: opts.strength, structure: "random-sharded-source", sourceReconstruction: true, packedBytecode: false, customAlgorithm: protectedSource.customAlgorithm, seed }, validation: { target, backend: "structural-source", parser: "capability-fallback", structural: structuralOk, nativeLua: nativeCheck ? nativeCheck.ok : null }, ast: null, analysis: null, initialAnalysis: null, seed, preset: opts.preset || "custom", stats: { tokens: lexed.tokens.length, errors: 0, mode: "structural-source", bytes: Buffer.byteLength(output, "utf8"), sourceBytes: Buffer.byteLength(source, "utf8"), junkBytes: 0, junkCount: 0, bodyOneLine: !/\r?\n/.test(output), hasPlainSource: false, hasStringChar: false, hasArithmeticJunk: false, hasEncodedPool: true, vmMarkers: ["structural-source", "compatibility-route"], junkAfterVM: false, vmIsland: false, vmVersion: "4.7.9", cleanOutput: true, watermark: opts.transforms?.watermark ? watermarkModule.createWatermark(typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : {}) : "", engine: protectedSource.engine, scopes: 0, semanticWarnings: 0, fallback: true, fallbackReason: "parser capability fallback" } };
    }

    normalizeVMSourceAST(ast, target);
    rememberPolicyNames(ast);

    let protectionPlan = null;
    try {
        applyProtectionTransforms(ast, { ...opts.transforms, source, vmOnly: false, strength: opts.strength, seed, version: ACTIVE_VM_VERSION });
        const defaultPolicy = opts.vmPolicy === "legacy-mode"
            ? (opts.mode === "stack" ? "hardened" : "balanced")
            : opts.vmPolicy;
        const functionPolicyPlan = prepareFunctionPolicy(ast, {
            vmPolicy: defaultPolicy,
            functionPolicies: opts.functionPolicies,
            allowPolicyFallback: opts.allowPolicyFallback,
            seed
        });
        const compilerTransformedMain = defaultPolicy === "compiler-transformed";
        if (compilerTransformedMain && functionPolicyPlan.routed.length === 0) {
            return buildCompilerTransformedResult(ast, source, target, seed, opts, lexed, functionPolicyPlan);
        }

        let vm = null;
        let ir = null;
        let mainOutput = "";
        if (compilerTransformedMain) {
            // This is an explicit selected policy, not an error fallback. Unsupported VM
            // syntax in this main chunk is allowed because it stays native source.
            mainOutput = minify(printChunk(ast, { minify: true }));
        } else {
            ir = buildIR(ast, opts.mode, ACTIVE_VM_VERSION);
            protectionPlan = buildProtectionPlan(ast, { ...opts.transforms, strength: opts.strength, seed, ir, version: ACTIVE_VM_VERSION });
            assertCustomVMCompatible(ast);
            vm = buildCustomVM(ast, {
                mode: opts.mode,
                seed,
                strength: opts.strength,
                nestedProfile: ast.__byteVeilNestedProfile || opts.nestedProfile,
                opcodeWhitening: opts.transforms?.opcodeWhitening !== false,
                protection: protectionPlan,
                ir,
                runtimeBridgeParam: functionPolicyPlan.bridgeName,
                forgeLatch: opts.forgeLatch || null,
                stringCipher: opts.stringCipher !== false,
                guardLatch: opts.guardLatch || null
            });
            protectionPlan = vm.compiled?.protectionPlan || protectionPlan;
            mainOutput = buildWrappedVMSource(vm, target, seed, opts, functionPolicyPlan.bridgeName);
        }

        if (functionPolicyPlan.routed.length) {
            const entries = [];
            for (let index = 0; index < functionPolicyPlan.routed.length; index++) {
                const entry = functionPolicyPlan.routed[index];
                const providerSeed = (seed ^ Math.imul(index + 1, 0x45D9F3B) ^ 0x477A11CE) >>> 0;
                entry.provider = generateFunctionPolicyProvider(entry, target, providerSeed, opts);
                entries.push(entry);
            }
            let output = wrapHybridVMOutput(mainOutput, functionPolicyPlan.bridgeName, entries, target, seed, opts);
            if (opts.transforms?.watermark) {
                const wmOptions = typeof opts.transforms.watermark === "object"
                    ? opts.transforms.watermark
                    : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
                output = watermarkModule.prependWatermark(output, wmOptions);
            }
            if (Buffer.byteLength(output, "utf8") > opts.maxOutputBytes) {
                throw new Error(`ByteVeil v5.9.0 output budget exceeded: ${Buffer.byteLength(output, "utf8")} bytes > ${opts.maxOutputBytes}; VM policies were not downgraded`);
            }
            const policyRows = functionPolicyPlan.report.map((row) => ({ ...row }));
            for (const entry of entries) {
                const row = policyRows.find((item) => item.name === entry.name);
                if (row) {
                    row.backend = entry.provider.backend;
                    row.providerBytes = entry.provider.outputBytes;
                    row.runtimeVerified = false;
                }
            }
            const mainBackend = compilerTransformedMain ? "compiler-transformed" : (opts.mode === "stack" ? "VM-B/stack" : "VM-A/register");
            return {
                output,
                target,
                runtime: compilerTransformedMain ? (target === "luau" ? "Luau source + isolated VM functions" : "Lua source + isolated VM functions") : (target === "luau" ? "Luau hybrid VM-A/VM-B" : "Lua hybrid VM-A/VM-B"),
                layout: "hybrid-function-level-vm-v477",
                detection: "v5.9.0 function-level policy selector with lexical bridge; no source-loader fallback",
                bytecode: vm?.bytecode || null,
                vmMeta: {
                    fallback: false,
                    backend: compilerTransformedMain ? "hybrid-compiler-transformed-and-vm" : "hybrid-vm-a-vm-b",
                    version: ACTIVE_VM_VERSION,
                    vmPolicy: defaultPolicy,
                    mode: vm?.mode || "compiler-transformed",
                    rootBackend: mainBackend,
                    functionPolicyReport: policyRows,
                    routedFunctionCount: entries.length,
                    functionProviders: entries.map((entry) => ({ name: entry.name, runtimeName: entry.runtimeName || entry.name, policy: entry.policy, backend: entry.provider.backend, mode: entry.provider.mode, instructionRepresentation: entry.provider.instructionRepresentation, serializer: entry.provider.serializer, layout: entry.provider.structural?.layout || "compiler-transformed-source", outputBytes: entry.provider.outputBytes })),
                    explicitFallbacks: functionPolicyPlan.explicitFallbacks,
                    fallback: false,
                    strength: opts.strength,
                    sourceReconstruction: compilerTransformedMain,
                    packedBytecode: !compilerTransformedMain,
                    sourceLoaderStages: Number(vm?.structural?.sourceLoaderStages || 0),
                    runtimeSourceLoaderCount: Number(vm?.structural?.runtimeSourceLoaderCount || 0),
                    payloadTransformLayers: Number(vm?.structural?.payloadTransformLayers || 0),
                    nativeBufferRuntime: vm?.structural?.nativeBufferRuntime === true,
                nativeBufferValidation: target === "luau" ? "not-run-in-this-environment" : "conditional-fast-path-with-byte-array-fallback",
                    shadowVm: vm?.structural?.shadowVm === true,
                    shadowArchitecture: vm?.structural?.shadowArchitecture || null,
                    shadowStaticSourceTrace: vm?.structural?.shadowStaticSourceTrace === true,
                    shadowTraceOpcodeCount: Number(vm?.structural?.shadowTraceOpcodeCount || 0),
                    shadowLiveOpcodeCoupled: vm?.structural?.shadowLiveOpcodeCoupled === true,
                    fragmentGraph: vm?.structural?.fragmentGraph === true,
                    protectionPlan,
                    seed,
                    outputBudget: { bytes: Buffer.byteLength(output, "utf8"), maxBytes: opts.maxOutputBytes, withinBudget: true }
                },
                validation: { target, backend: "hybrid-function-policy", compiler: vm?.compiled?.validation || null, policyPlan: policyRows },
                ast,
                analysis: null,
                initialAnalysis: null,
                seed,
                preset: opts.preset || "custom",
                stats: {
                    tokens: lexed.tokens.length,
                    errors: 0,
                    mode: vm?.mode || "hybrid",
                    bytes: Buffer.byteLength(output, "utf8"),
                    sourceBytes: Buffer.byteLength(source, "utf8"),
                    bodyOneLine: !/[\r\n]/.test(output),
                    hasPlainSource: compilerTransformedMain,
                    hasEncodedPool: !compilerTransformedMain,
                    vmVersion: ACTIVE_VM_VERSION,
                    cleanOutput: true,
                    engine: "ByteVeil Hybrid VM Architecture v5.9.0",
                    fallback: false,
                    fallbackReason: null,
                    sizeBudget: { bytes: Buffer.byteLength(output, "utf8"), maxBytes: opts.maxOutputBytes, withinBudget: true }
                }
            };
        }

        if (!vm) throw new Error("ByteVeil v5.9.0: internal policy routing produced no VM for a VM-backed program");
        if (vm.structural?.version === ACTIVE_VM_VERSION) {
            const structural = vm.structural;
            const missingAnti = [
                ["anti-hook", Number(structural.antiHookLayers || 0)],
                ["anti-tamper", Number(structural.antiTamperLayers || 0)],
                ["anti-dump", Number(structural.antiDumpLayers || 0)]
            ].filter(([, layers]) => layers < 1).map(([name]) => name);
            if (missingAnti.length) {
                throw new Error(`ByteVeil v5.9.0: runtime anti integration incomplete (${missingAnti.join(", ")})`);
            }
        }
        let output = mainOutput;
        if (opts.transforms?.watermark) {
            const wmOptions = typeof opts.transforms.watermark === "object"
                ? opts.transforms.watermark
                : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
            output = watermarkModule.prependWatermark(output, wmOptions);
        }
        // Generated guard aliases are internal symbols, not public Lua/Luau APIs.
        // Rename their identifier tokens per build while leaving strings/comments/API names untouched.
        output = mangleGeneratedInternals(output, seed);

        if (!["4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7", "4.7.6", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.7.0", "5.8.0", "5.9.0"].includes(vm.structural?.version) && /string\.char/.test(output)) {
            throw new Error(`ByteVeil ${vm.structural?.version || ACTIVE_VM_VERSION} invariant failed: generated protected source contains string.char`);
        }
        if (["4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7", "4.7.6", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.7.0", "5.8.0", "5.9.0"].includes(vm.structural?.version) && !vm.structural?.fragmentGraph) {
            throw new Error(`ByteVeil ${vm.structural?.version} invariant failed: v4.5 graph runtime missing`);
        }

        return {
            output,
            target,
            runtime: target === "luau" ? "Luau custom VM" : "Lua 5.1-5.4 custom VM",
            layout: vm.structural?.layout || "random-graph-structural-vm",
            detection: "v5.9.0 hybrid policy-capable graph VM with shared shadow-dispatch core, callable bootstrap, and verified binary regions and no source-loader stages",
            bytecode: vm.bytecode,
            vmMeta: {
                fallback: false,
                backend: "custom-vm",
                version: vm.structural?.version || ACTIVE_VM_VERSION,
                vmPolicy: opts.vmPolicy === "legacy-mode" ? (vm.mode === "stack" ? "hardened" : "balanced") : opts.vmPolicy,
                selectedBackend: vm.mode === "stack" ? "VM-B/stack" : "VM-A/register",
                instructionRepresentation: vm.mode === "stack" ? "stack-value-stack-operands-v479" : "register-file-register-operands-v479",
                registerInstructionSet: vm.mode === "register" ? (vm.compiled?.registerInstructionSet || "register-command-abi-unreported") : null,
                serializer: "binary-region-v479-semantic-shadow-with-mode-specific-operands",
                runtimeDispatchArchitecture: vm.mode === "stack" ? "stack-machine-state-and-handler-map" : "register-machine-state-and-handler-map",
                functionPolicyReport: functionPolicyPlan.report,
                explicitFallbacks: functionPolicyPlan.explicitFallbacks,
                mode: vm.mode,
                strength: opts.strength,
                transformRounds: 1,
                protectionLayers: vm.structural?.singleLayerEngine === true ? 1 : 10,
                byteBlinder: vm.compiled?.protectionPlan?.engine || "Byte-Blinder",
                mfgEngine: vm.compiled?.mfgPlan?.family || "MFG-5.4.0-build-diverse-shadow-hardened-carrier-vm",
                generatorEngine: vm.structural?.generatorEngine || vm.compiled?.mfgPlan?.family || "MFG-5.4.0-build-diverse-shadow-hardened-carrier-vm",
                protectionIR: vm.compiled?.protectionIR || null,
                opcodeWhitening: vm.compiled.opcodeWhitening !== false,
                structure: vm.structural?.layout || "staged-polymorphic-vm-v41",
                statePermutation: vm.compiled.ironbrew?.statePermutation || null,
                strict: true,
                arithmeticProtection: false,
                stringProtection: true,
                stringChar: false,
                sourceReconstruction: false,
                randomizedBuild: true,
                controlFlow: true,
                distributedConstants: true,
                protectionPlan,
                packedBytecode: true,
                containerFormat: vm.structural?.layout || "nested-heterogeneous-vm-v453",
                containerEntries: vm.structural?.containerEntries ?? vm.structural?.regionEntries ?? 0,
                containerShards: vm.structural?.containerShards ?? vm.structural?.regionShards ?? 0,
                containerDecoys: vm.structural?.containerDecoys ?? vm.structural?.regionDecoys ?? 0,
                superOperators: vm.structural?.superOperators || 0,
                superFused: vm.bytecode?.superActual?.fused || 0,
                superMaxDepth: vm.bytecode?.superActual?.maxDepth || 0,
                superInstructionIds: vm.bytecode?.superActual?.instructionIds || 0,
                decoderVariant: vm.structural?.decoderVariant ?? null,
                vmPersonality: vm.structural?.vmPersonality ?? null,
                vmPersonalityVersion: vm.structural?.vmPersonalityVersion ?? null,
                vmStateProfile: vm.structural?.vmStateProfile ?? null,
                vmStateOrder: vm.structural?.vmStateOrder ?? null,
                vmDispatchStyle: vm.structural?.vmDispatchStyle ?? null,
                vmDispatchTopology: vm.structural?.vmDispatchTopology ?? null,
                actualSemanticDispatchTopologies: vm.structural?.actualSemanticDispatchTopologies ?? 0,
                runtimeIntegrityCheckpointStride: vm.structural?.runtimeIntegrityCheckpointStride ?? 0,
                runtimeApiProvenanceCheck: vm.structural?.runtimeApiProvenanceCheck ?? "none",
                instructionDecoderStyle: vm.structural?.instructionDecoderStyle ?? "single-dispatch-normalizer",
                vmRecipeStyle: vm.structural?.vmRecipeStyle ?? null,
                vmMicroOrder: vm.structural?.vmMicroOrder ?? null,
                vmRepresentationStyle: vm.structural?.vmRepresentationStyle ?? null,
                vmResolverFamily: vm.structural?.vmResolverFamily ?? null,
                vmStateModel: vm.structural?.vmStateModel ?? null,
                vmCommitStyle: vm.structural?.vmCommitStyle ?? null,
                vmArchitectureFamily: vm.structural?.vmArchitectureFamily ?? null,
                vmArchitectureName: vm.structural?.vmArchitectureName ?? null,
                vmSecondaryArchitecture: vm.structural?.vmSecondaryArchitecture ?? null,
                vmMaterializationFamily: vm.structural?.vmMaterializationFamily ?? null,
                vmPbfFamily: vm.structural?.vmPbfFamily ?? null,
                vmCffFamily: vm.structural?.vmCffFamily ?? null,
                vmEnvFamily: vm.structural?.vmEnvFamily ?? null,
                actualRepresentationMorphing: vm.structural?.actualRepresentationMorphing === true,
                semanticArchitectureFamilies: vm.structural?.semanticArchitectureFamilies ?? null,
                representationMorphing: vm.structural?.representationMorphing === true,
                composedSemanticLayer: vm.structural?.composedSemanticLayer === true,
                runtimeGeneratedRecipe: vm.structural?.runtimeGeneratedRecipe === true,
                dynamicDispatchTopology: vm.structural?.dynamicDispatchTopology === true,
                nonCanonicalIR: vm.structural?.nonCanonicalIR === true,
                vmStateRandomization: vm.structural?.vmStateRandomization === true || vm.structural?.buildSpecificVM === true,
                buildSpecificVM: vm.structural?.buildSpecificVM === true,
                buildSpecificDiversity: vm.structural?.buildSpecificDiversity === true,
                regionResolverFamilies: vm.structural?.regionResolverFamilies || 0,
                distributedResolver: vm.structural?.distributedResolver === true,
                distributedRecipeBanks: vm.structural?.distributedRecipeBanks === true,
                regionSpecificVocabulary: vm.structural?.regionSpecificVocabulary === true,
                runtimeVMBGeneration: vm.structural?.runtimeVMBGeneration === true,
                semanticMicroOpEngine: vm.structural?.semanticMicroOpEngine === true,
                lazyDependentConstants: vm.structural?.lazyDependentConstants === true,
                heterogeneousDecoys: vm.structural?.heterogeneousDecoys === true,
                nestedObfuscation: vm.structural?.nestedObfuscation === true,
                nestedProfile: ((vm.structural?.version === "4.7.9" || (vm.structural?.version === "5.0.0" || vm.structural?.version === "5.3.0" || vm.structural?.version === "5.4.0" || (vm.structural?.version === "5.5.0" || vm.structural?.version === "5.7.0" || vm.structural?.version === "5.8.0" || vm.structural?.version === "5.9.0")))) ? NESTED_PROFILE : (vm.structural?.version === "4.7.7" || vm.structural?.version === "4.7.8") ? "hybrid-function-policy-binary-region-vm-semantic-shadow-no-source-loader" : vm.structural?.version === "4.7.6" ? "binary-region-interleaved-shadow-vm-no-source-loader" : (vm.structural?.singleLayerEngine === true ? "disabled-single-layer" : (vm.compiled?.nestedProfile || ast.__byteVeilNestedProfile || opts.nestedProfile)),
                singleLayerEngine: vm.structural?.singleLayerEngine === true,
                payloadTransformLayers: Number(vm.structural?.payloadTransformLayers || 0),
                nativeBufferRuntime: vm.structural?.nativeBufferRuntime === true,
                sourceLoaderStages: Number(vm.structural?.sourceLoaderStages || 0),
                runtimeSourceLoaderCount: Number(vm.structural?.runtimeSourceLoaderCount || 0),
                singleLayerProfile: ast.__byteVeilSingleLayerProfile || "standard-packed",
                intraVmIntegrity: vm.structural?.intraVmIntegrity === true,
                nestedObfuscationLayers: Number(vm.structural?.nestedObfuscationLayers || 0),
                nestedCodecs: vm.structural?.nestedCodecs || [],
                nestedCompression: vm.structural?.nestedCompression || null,
                nestedCompressedLayers: Number(vm.structural?.nestedCompressedLayers || 0),
                nestedCompressionBytesSaved: Number(vm.structural?.nestedCompressionBytesSaved || 0),
                heterogeneousNestedLayers: vm.structural?.heterogeneousNestedLayers === true,
                antiTamperLayers: Number(vm.structural?.antiTamperLayers || 0),
                antiHookLayers: Number(vm.structural?.antiHookLayers || 0),
                antiDumpLayers: Number(vm.structural?.antiDumpLayers || 0),
                handlerFamilies: vm.structural?.handlerFamilies || 0,
                lazyInstructionMaterialization: vm.structural?.lazyInstructionMaterialization === true,
                lazyConstantMaterialization: vm.structural?.lazyConstantMaterialization === true,
                decoyLanes: vm.structural?.decoyLanes || 0,
                stagedRuntime: vm.structural?.stagedRuntime === true,
                decoyGraph: vm.structural?.decoyGraph === true,
                decoyCycle: vm.structural?.decoyCycle === true,
                decoyDepth: vm.structural?.decoyDepth || 0,
                decoyBudget: vm.structural?.decoyBudget || 0,
                decoyVm: vm.structural?.decoyVm === true,
                shadowVm: vm.structural?.shadowVm === true,
                shadowInterleaved: vm.structural?.shadowInterleaved === true,
                shadowInstructionCount: Number(vm.structural?.shadowInstructionCount || 0),
                shadowHandlerCount: Number(vm.structural?.shadowHandlerCount || 0),
                shadowStepsPerRealInstruction: Number(vm.structural?.shadowStepsPerRealInstruction || 0),
                shadowDispatchStyle: vm.structural?.shadowDispatchStyle || null,
                shadowTraceOpcodeCount: Number(vm.structural?.shadowTraceOpcodeCount || 0),
                shadowOperandTraceDerived: vm.structural?.shadowOperandTraceDerived === true,
                shadowLiveOpcodeCoupled: vm.structural?.shadowLiveOpcodeCoupled === true,
                shadowTraceInterleaveRatio: vm.structural?.shadowTraceInterleaveRatio || null,
                shadowFingerprint: vm.structural?.shadowFingerprint || null,
                shadowArchitecture: vm.structural?.shadowArchitecture || null,
                shadowSemanticHandlerCount: Number(vm.structural?.shadowSemanticHandlerCount || 0),
                shadowSemanticHandlerCoverage: Number(vm.structural?.shadowSemanticHandlerCoverage || 0),
                shadowMissingSemanticHandlers: vm.structural?.shadowMissingSemanticHandlers || [],
                shadowStaticSourceTrace: vm.structural?.shadowStaticSourceTrace === true,
                decoyVmShape: vm.structural?.decoyVmShape || null,
                decoyOpcodeHandlers: vm.structural?.decoyOpcodeHandlers || 0,
                decoyFrameDepth: vm.structural?.decoyFrameDepth || 0,
                polymorphicHandlers: vm.structural?.polymorphicHandlers === true,
                fusedSuper: vm.structural?.fusedSuper === true,
                crossLayerIntegrity: vm.structural?.crossLayerIntegrity === true,
                antiHook: vm.structural?.antiHook === true,
                antiTamper: vm.structural?.antiTamper === true,
                antiDump: vm.structural?.antiDump === true,
                sharedExecutionFabric: vm.structural?.sharedExecutionFabric === true,
                stagedPayloadMaterialization: vm.structural?.payloadMaterialization || null,
                payloadCarrierCodec: vm.structural?.payloadCarrierCodec || vm.compiled?.bytecode?.mutation?.codecVersion || null,
                payloadLayout: vm.structural?.payloadLayout || null,
                encodingEngine: vm.structural?.encodingEngine || null,
                encodingStages: vm.structural?.encodingStages || [],
                encodingRoundTripsVerified: Number(vm.structural?.encodingRoundTripsVerified || 0),
                encodingRegionsVerified: Number(vm.structural?.encodingRegionsVerified || 0),
                encodingPipelineRoundTripsVerified: Number(vm.structural?.encodingPipelineRoundTripsVerified || 0),
                payloadBlobChars: Number(vm.structural?.payloadBlobChars || 0),
                payloadDirectoryEntries: Number(vm.structural?.payloadDirectoryEntries || 0),
                payloadDirectoryValidatedByLPS: vm.structural?.payloadDirectoryValidatedByLPS === true,
                lpsPayloadPlanner: vm.structural?.lpsPayloadPlanner || null,
                payloadLaneCount: Number(vm.structural?.payloadLaneCount || 0),
                payloadCarrierCount: Number(vm.structural?.payloadCarrierCount || 0),
                payloadLaneCarrierCount: Number(vm.structural?.payloadLaneCarrierCount || 0),
                payloadDescriptorCarrierCount: Number(vm.structural?.payloadDescriptorCarrierCount || 0),
                payloadLaneCarrierSlots: vm.structural?.payloadLaneCarrierSlots || [],
                payloadDescriptorCarrierSlots: vm.structural?.payloadDescriptorCarrierSlots || [],
                antiIntegration: vm.structural?.antiIntegration || null,
                antiTamperChecksum: vm.structural?.antiTamperChecksum || null,
                antiHookVerdict: vm.structural?.antiHookVerdict || null,
                antiGuardKey: vm.structural?.antiGuardKey || null,
                stringCipher: vm.structural?.stringCipher || null,
                fragmentGraph: vm.structural?.fragmentGraph === true,
                nonLinearDependencies: vm.structural?.nonLinearDependencies === true,
                materialDependencyGraph: vm.structural?.materialDependencyGraph === true,
                opaqueTransportIR: vm.structural?.opaqueTransportIR === true,
                perRegionOpcodeMapping: vm.structural?.perRegionOpcodeMapping === true,
                runtimeGeneratedDispatch: vm.structural?.runtimeGeneratedDispatch === true,
                semanticMicroOps: vm.structural?.semanticMicroOps === true,
                regionCount: vm.structural?.regionCount || 0,
                regionShards: vm.structural?.regionShards || 0,
                regionEntries: vm.structural?.regionEntries || 0,
                regionDecoys: vm.structural?.regionDecoys || 0,
                vmStages: vm.structural?.vmStages || 0,
                customAlgorithm: vm.structural?.layout || "heterogeneous-graph-ir-v452",
                seed
            },
            validation: { target, backend: "custom-vm", compiler: vm.compiled.validation },
            ast,
            analysis: null,
            initialAnalysis: null,
            seed,
            preset: opts.preset || "custom",
            stats: {
                tokens: lexed.tokens.length,
                errors: 0,
                mode: opts.mode,
                bytes: Buffer.byteLength(output, "utf8"),
                sourceBytes: Buffer.byteLength(source, "utf8"),
                junkBytes: 0,
                junkCount: 0,
                bodyOneLine: !/\r?\n/.test(output),
                hasPlainSource: false,
                hasStringChar: false,
                hasArithmeticJunk: false,
                hasEncodedPool: false,
                vmMarkers: ["custom-vm", "packed-bytecode", "opaque-payload", "structured-dispatch", "byte-blinder", "mfg-5.9.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-shadow-hardened-carrier-vm", "binary-regions", "lazy-materialization"],
                junkAfterVM: false,
                vmIsland: true,
                vmVersion: ACTIVE_VM_VERSION,
                cleanOutput: true,
                watermark: opts.transforms?.watermark
                    ? watermarkModule.createWatermark(typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : {})
                    : "",
                engine: "ByteVeil Custom VM v5.9.0",
                scopes: 0,
                semanticWarnings: 0,
                fallback: false,
                fallbackReason: null
            }
        };
    } catch (error) {
        // Only an explicit VM-compatibility rejection may use the protected-source route.
        // Compiler, serializer, generator, and runtime regressions must surface instead of
        // being silently hidden by a fallback.
        if (!opts.compatibilityRoute || !String(error?.message || "").startsWith(`ByteVeil v${ACTIVE_VM_VERSION} strict VM rejected input:`) && !String(error?.message || "").startsWith("ByteVeil v4.7.9 strict VM rejected input:")) {
            throw error;
        }
        // Valid source that the VM compiler cannot safely lower yet uses the
        // structural source protector. It does not mutate the original source,
        // and it never injects executable junk into the payload.
        let fallbackSource = source;
        try { fallbackSource = printChunk(ast, { minify: true }); } catch (_) { /* preserve original only when printer cannot represent AST */ }
        const compatibilityEngine = require("../backend/source_engine_v46_compat");
        const protectedSource = compatibilityEngine.buildSourceEngine(fallbackSource, { target, seed, strength: opts.strength, nestedProfile: opts.nestedProfile });
        let output = minify(protectedSource.output).replace(/\r\n/g, "\n");
        if (opts.wrapper?.enabled !== false) {
            output = wrap(output, {
                argumentCount: opts.wrapper.argumentCount,
                invoke: opts.wrapper.invoke !== false,
                setmeta: opts.wrapper.setmeta !== false,
                wrapper: true,
                target,
                seed,
                backend: opts.mode,
                mode: opts.mode,
                preserveLayout: target === "luau",
                wrapperShape: opts.wrapper.shape || "auto",
                returnMode: opts.wrapper.returnMode || (opts.wrapper.setmeta === false ? "direct" : "setmetatable")
            });
            output = minify(output);
        }
        if (opts.transforms?.watermark) {
            const wmOptions = typeof opts.transforms.watermark === "object"
                ? opts.transforms.watermark
                : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
            output = watermarkModule.prependWatermark(output, wmOptions);
        }
        return {
            output,
            target,
            runtime: protectedSource.runtime,
            layout: "structural-source-v35",
            detection: `v4.7.9 explicit compatibility source route: ${error.message}`,
            bytecode: null,
            vmMeta: {
                fallback: true,
                backend: "structural-source",
                version: ACTIVE_VM_VERSION,
                reason: error.message,
                strength: opts.strength,
                structure: "random-sharded-source",
                arithmeticProtection: false,
                stringProtection: true,
                stringChar: false,
                randomizedBuild: true,
                controlFlow: true,
                distributedConstants: true,
                protectionPlan,
                packedBytecode: false,
                containerFormat: "protected-source",
                containerEntries: 0,
                containerShards: 0,
                containerDecoys: 0,
                superOperators: 0,
                antiHook: true,
                antiTamper: true,
                sourceReconstruction: true,
                customAlgorithm: protectedSource.customAlgorithm,
                seed
            },
            validation: {
                target,
                backend: "structural-source",
                parser: "validated-before-route"
            },
            ast,
            analysis: null,
            initialAnalysis: null,
            seed,
            preset: opts.preset || "custom",
            stats: {
                tokens: lexed.tokens.length,
                errors: 0,
                mode: "structural-source",
                bytes: Buffer.byteLength(output, "utf8"),
                sourceBytes: Buffer.byteLength(source, "utf8"),
                junkBytes: 0,
                junkCount: 0,
                bodyOneLine: !/\r?\n/.test(output),
                hasPlainSource: false,
                hasStringChar: false,
                hasArithmeticJunk: false,
                hasEncodedPool: true,
                vmMarkers: ["structural-source", "random-sharded-source"],
                junkAfterVM: false,
                vmIsland: false,
                vmVersion: ACTIVE_VM_VERSION,
                cleanOutput: true,
                watermark: opts.transforms?.watermark
                    ? watermarkModule.createWatermark(typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : {})
                    : "",
                engine: protectedSource.engine,
                scopes: 0,
                semanticWarnings: 0,
                fallback: true,
                fallbackReason: error.message
            }
        };
    }
}

function buildSourceFallback(source, target, seed, opts, reason) {
    const shellOptions = {
        target,
        seed,
        gsubAnchor: false,
        junkCount: 0,
        decoys: 0,
        opcodeGuard: opts.transforms?.opcodeGuard !== false,
        opcodeCount: Number(opts.transforms?.opcodeCount ?? 0),
        shardMin: Number(opts.transforms?.shardMin ?? (opts.preset === "lz" ? 96 : opts.preset === "l2" ? 90 : 84)),
        shardMax: Number(opts.transforms?.shardMax ?? (opts.strength >= 7500 ? 128 : opts.strength >= 3500 ? 144 : opts.preset === "lz" ? 170 : opts.preset === "l2" ? 150 : 142)),
        strength: opts.strength
    };
    const sourceEngine = buildCompatSourceEngine(source, shellOptions);
    const isLuau = target === "luau";
    let generated = isLuau ? sourceEngine.output : minify(sourceEngine.output);
    if (opts.wrapper.enabled) {
        generated = wrap(generated, {
            argumentCount: opts.wrapper.argumentCount,
            invoke: opts.wrapper.invoke !== false,
            setmeta: opts.wrapper.setmeta !== false,
            wrapper: true,
            target,
            seed,
            backend: opts.mode,
            mode: opts.mode,
            preserveLayout: isLuau,
            wrapperShape: opts.wrapper.shape || "auto",
            returnMode: opts.wrapper.returnMode || (opts.wrapper.setmeta === false ? "direct" : "setmetatable")
        });
    }
    const generatedBytes = Buffer.byteLength(generated, "utf8");
    const sizeResult = {
        output: generated, originalBytes: generatedBytes, bytes: generatedBytes,
        targetBytes: generatedBytes, applied: false, inRange: true,
        impossible: false, disabled: true, blocks: 0, seed
    };
    generated = minify(generated).replace(/\r\n/g, "\n");
    if (opts.transforms?.watermark) {
        const wmOptions = typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK };
        generated = watermarkModule.prependWatermark(generated, wmOptions);
    }
    let generatedValidation = null;
    if (target === "luau") {
        const { validateGeneratedLuau } = require("./luau_sanity");
        generatedValidation = validateGeneratedLuau(generated);
    }
    // This route builds no VM (`bytecode:null`, `vmMeta.fallback:true`), so it reports the
    // runtime the compatibility engine itself names instead of a "custom VM" label.
    const runtimeLabel = sourceEngine.runtime
        || (target === "luau" ? "Luau compatibility runtime" : "Lua 5.1-5.4 compatibility runtime");
    return {
        output: generated,
        target,
        runtime: runtimeLabel,
        layout: target === "luau" ? "single-line-minified" : "legacy-minified",
        detection: reason,
        bytecode: null,
        vmMeta: {
            fallback: true,
            reason,
            engine: sourceEngine.engine,
            version: ACTIVE_VM_VERSION,
            runtimeBaseVersion: sourceEngine.runtimeBaseVersion || "2.9.0",
            hardeningVersion: sourceEngine.vmVersion || "3.9-layered-semantic-hardening",
            containerEntries: sourceEngine.containerEntries || 0,
            containerShards: sourceEngine.containerShards || 0,
            containerDecoys: sourceEngine.containerDecoys || 0,
            strength: sourceEngine.strength || opts.strength,
            transformRounds: sourceEngine.transformRounds || 1
        },
        validation: { target, runtime: runtimeLabel, generated: generatedValidation },
        ast: null,
        analysis: null,
        initialAnalysis: null,
        seed,
        preset: opts.preset || "custom",
        stats: {
            tokens: 0, errors: 0, mode: "source-fallback", bytes: Buffer.byteLength(generated, "utf8"),
            sourceBytes: Buffer.byteLength(source, "utf8"), junkBytes: 0, junkCount: 0,
            bodyOneLine: !/[\r\n]/.test(generated), hasPlainSource: false, hasStringChar: true,
            hasArithmeticJunk: false, hasEncodedPool: true, vmMarkers: [], junkAfterVM: false, vmIsland: sourceEngine.vmIsland === true, vmVersion: sourceEngine.vmVersion || null,
            sizeBuff: sizeResult,
            cleanOutput: true,
            watermark: opts.transforms?.watermark ? watermarkModule.createWatermark(typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : {}) : "",
            engine: sourceEngine.engine, scopes: 0, semanticWarnings: 0,
            fallback: true, fallbackReason: reason
        }
    };
}

// The region root is a sum of chunk-local holders folded with `%4294967296`. The key-bed
// holder is one addend and the anti-hook verdict holder is appended after it, so the bed
// read is proven by the holder appearing anywhere in the sum, not only in last position.
function keyExpressionReadsHolder(body, holderName) {
    const holder = String(holderName).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`\\((?:[A-Za-z_]\\w*\\+)*${holder}(?:\\+[A-Za-z_]\\w*)*\\)%4294967296`).test(body);
}

function finalizeGeneratedOutput(source, seed, options = {}, isPureVm = true, target = "lua", forgeLatch = null) {    const watermarkValue = options.transforms?.watermark;
    const watermarkOptions = watermarkValue
        ? (typeof watermarkValue === "object" ? watermarkValue : { text: options.watermark || watermarkModule.DEFAULT_WATERMARK })
        : null;
    const visibleWatermark = watermarkOptions ? watermarkModule.createWatermark(watermarkOptions) : "";
    let body = String(source).replace(/^\uFEFF/, "").replace(/\r\n/g, "\n");
    if (visibleWatermark && body.startsWith(`${visibleWatermark}\n`)) {
        body = body.slice(visibleWatermark.length + 1);
    }
    body = mangleGeneratedInternals(body, seed, { vmOnly: isPureVm });
    body = minify(body).replace(/\r\n/g, "\n");
    // JunkForge runs after mangling and minification on purpose: the block is a
    // self-contained statement prefix, so its generated names only have to avoid
    // the final body (checked against the emitted identifiers) and its long-bracket
    // containers never go through the minifier at all.
    const forgePlan = planJunkForge({
        preset: options.preset,
        strength: options.strength,
        target,
        options
    });
    // A route only binds the bed if its own body reads the holder. The VM routes do
    // (`rs()`/`rseed()` add it to the region root); `nest` loads the body from another
    // chunk and `compiler-transformed` never builds a VM, so they keep the block as
    // self-checked padding and report `keyBedBound:false`.
    const holderRead = Boolean(forgeLatch && forgeLatch.enabled && options.forgeLatch
        && keyExpressionReadsHolder(body, forgeLatch.holderName));
    const forge = applyJunkForge({ body, seed, target, preset: options.preset, strength: options.strength, options, plan: forgePlan, latch: holderRead ? forgeLatch : null });
    if (holderRead) {
        // The block is only a decoration if nothing reads its holder, but a body that
        // reads a holder the build never emits is a broken script, so both halves of the
        // binding have to agree or the build must not ship.
        if (!forge.applied) {
            throw new Error(`ByteVeil v5.9.0 JunkForge binding failed: the payload key is bound to a key-bed block that was not emitted (${forge.reason || "unknown"})`);
        }
        if (forge.holderName !== options.forgeLatch.holder) {
            throw new Error(`ByteVeil v5.9.0 JunkForge binding failed: block holder ${forge.holderName} != ${options.forgeLatch.holder}`);
        }
    }
    if (forge.applied) body = `${body.slice(0, forge.insertAt)}${forge.prefix}${body.slice(forge.insertAt)}`;
    return { output: visibleWatermark ? watermarkModule.prependWatermark(body, watermarkOptions) : body, forge, keyBedBound: holderRead && forge.applied === true };
}

function obfuscate(source, options = {}) {
    if (typeof source !== "string") throw new TypeError("source must be a string");
    const optionAudit = auditOptions(options);
    const opts = normalizeOptions(options);
    const seed = opts.seed === undefined || opts.seed === null
        ? (crypto.randomBytes(4).readUInt32LE(0) || 0x6D2B79F5)
        : (Number(opts.seed) >>> 0);
    const target = resolveTarget(source, opts);
    // `auto` targets are only known after detection, so the density cap follows the
    // resolved target unless the caller pinned maxOutputBytes themselves.
    if (!opts.maxOutputBytesWasRequested) opts.maxOutputBytes = outputCapForTarget(target.target);
    // The junk budget is a property of the *input*: a small script gets a small padding
    // allowance and a large one gets the full envelope. It has to be measured here, on
    // the user's source, because by the time the forge runs the body it is handed is the
    // generated VM payload, which is 5-40x larger and would always read as "large".
    opts.junkForgeSourceBytes = Buffer.byteLength(source, "utf8");

    // JunkForge key bed. The padding block returns a digest folded byte-by-byte out of
    // five containers, and that number is the addend the VM derives its region key
    // with, so removing the block (or flipping any character in it) costs the payload
    // its decode key instead of only shrinking the file. Offering the binding is not
    // the same as having it: `nest` wraps the VM body in a loader string (a different
    // chunk, so the holder local is not visible) and `compiler-transformed` never
    // builds a VM, so those routes keep the padding and report `keyBedBound:false`.
    const forgeLatch = planForgeLatch({
        seed,
        preset: opts.preset,
        strength: opts.strength,
        target: target.target,
        options: opts
    });
    const forgeBindingOffered = forgeLatch.enabled === true && String(opts.preset || "").toLowerCase() !== "nest";
    if (forgeBindingOffered) opts.forgeLatch = { holder: forgeLatch.holderName, value: forgeLatch.key };

    // Anti-hook verdict as a second key addend. The number itself is predicted inside the
    // VM generator, because the guard's seed is the derived build seed the serializer
    // already uses; here the pipeline only decides whether the route can bind at all.
    // The generator re-checks the prediction against the digest of the guard it actually
    // emitted, so a route that cannot bind fails the build instead of shipping a script
    // that cannot decode itself.
    const guardBindingOffered = (opts.backend === "vm35" || opts.backend === "vm33")
        && String(opts.preset || "").toLowerCase() !== "nest";
    if (guardBindingOffered) opts.guardLatch = { enabled: true };

    let result;
    if (opts.backend === "vm35" || opts.backend === "vm33") {
        result = buildCustomVMBackend(source, target.target, seed, opts);
    } else if (target.target === "lua") {
        // auditOptions() closes `backend` to vm35/vm33/source, so this is the explicit
        // source-container route and no longer an accidental landing for a typo.
        result = buildSourceFallback(source, "lua", seed, opts, "portable Lua target");
    } else {
        result = buildSourceFallback(source, "luau", seed, opts, "Luau runtime-safe source container");
    }

    // The explicit Nest preset reuses the historical nested-source engine
    // (v4.7.4 codec family) around the already-built VM output. This is a real
    // runtime-loader path and is intentionally opt-in because it needs load/loadstring.
    if (opts.preset === "nest" && result.output && result.vmMeta?.version === ACTIVE_VM_VERSION) {
        const watermarkOptions = opts.transforms?.watermark
            ? (typeof opts.transforms.watermark === "object" ? opts.transforms.watermark : { text: opts.watermark || watermarkModule.DEFAULT_WATERMARK })
            : null;
        const visibleWatermark = watermarkOptions ? watermarkModule.createWatermark(watermarkOptions) : "";
        let nestedInput = result.output;
        if (visibleWatermark && nestedInput.startsWith(`${visibleWatermark}\n`)) nestedInput = nestedInput.slice(visibleWatermark.length + 1);
        const nested = wrapLegacyNestedSource(nestedInput, {
            seed: seed ^ 0x4E455354,
            strength: opts.strength,
            version: "4.7.4",
            nestedProfile: "full",
            maxIntermediateBytes: Math.max(opts.maxOutputBytes, 4_000_000)
        });
        result.output = nested.output;
        if (visibleWatermark) result.output = watermarkModule.prependWatermark(result.output, watermarkOptions);
        result.vmMeta = { ...result.vmMeta, nestedObfuscation: true, nestedObfuscationLayers: nested.layers, nestedCodecs: nested.codecs, nestedCompression: nested.compression, nestedCompressedLayers: nested.compression.compressedLayers, nestedCompressionBytesSaved: nested.compression.bytesSaved, heterogeneousNestedLayers: nested.heterogeneous, nestedSourceEngine: "legacy-wrapSource-v4.7.4", nestedRequiresDynamicLoader: true, nestedMaxObservedIntermediateBytes: nested.maxObservedIntermediateBytes };
        result.stats = { ...(result.stats || {}), nestedObfuscationLayers: nested.layers, nestedSourceEngine: "legacy-wrapSource-v4.7.4" };
    }

    // One emit gate now covers VM, policy, compatibility and source-container routes.
    // This prevents a wrapper/hybrid early return from skipping generated-name blending
    // or token-safe minification. Requested watermark comments remain outside the body.
    const isPureVm = result.vmMeta?.backend !== "compiler-transformed"
        && !result.vmMeta?.fallback
        && !(result.vmMeta?.functionPolicyReport || []).some((r) => r.policy === "compiler-transformed");
    const finalized = finalizeGeneratedOutput(result.output, seed, opts, isPureVm, target.target, forgeLatch);
    result.output = finalized.output;
    const junkForgeReport = finalized.forge;

    // The verdict addend is only real if the shipped body still reads a holder that the
    // region root arithmetic consumes *and* that holder is declared before that read in
    // the same chunk. Mangling renames the holder and the callable bootstrap re-partitions
    // the leading statements, so this is the post-emit half of the binding check; the
    // generator already proved it on the pre-mangle source with the real names.
    const guardKeyBound = result.vmMeta?.antiGuardKey?.bound === true;
    if (guardKeyBound) {
        const reads = [...result.output.matchAll(/\(([A-Za-z_]\w*)\+([A-Za-z_]\w*)(?:\+([A-Za-z_]\w*))?\)%4294967296/g)];
        const proven = reads.some((match) => {
            const holder = match[3] || match[2];
            const declared = result.output.indexOf(`local ${holder}=`);
            return declared >= 0 && declared < match.index;
        });
        if (!proven) {
            throw new Error("ByteVeil v5.9 anti-hook key binding failed: the finished body reads a verdict holder that is not declared in its own chunk");
        }
    }
    if (result.vmMeta) result.vmMeta.guardKeyBound = guardKeyBound;

    // Encode human-readable engine diagnostics only after output generation. The
    // pass skips comments and long-bracket literals and preserves every string's
    // runtime value; this is obfuscation, not cryptographic secrecy.
    // VeilBlob is the default representation: diagnostics become accessor calls
    // backed by one encrypted `[==[byteveil&...]==]` blob instead of hundreds of
    // reversible `\ddd` escape chains. Decimal escapes remain the fallback for
    // routes whose body does not start at a statement boundary.
    const blobSeed = (seed ^ 0xB10B5EED) >>> 0;
    const diagnosticEncoding = encodeDiagnosticStrings(result.output, { mode: "blob", seed: blobSeed });
    result.output = diagnosticEncoding.source;
    if (result.stats) {
        result.stats.bytes = Buffer.byteLength(result.output, "utf8");
        result.stats.bodyOneLine = !/[\r\n]/.test(result.output);
        result.stats.diagnosticStringsEncoded = diagnosticEncoding.encoded;
        result.stats.diagnosticErrorCallsAliased = diagnosticEncoding.errorCallsAliased;
        result.stats.diagnosticEncodingMode = diagnosticEncoding.mode;
    }
    if (result.vmMeta) {
        result.vmMeta.diagnosticEncoding = { mode: diagnosticEncoding.mode, strings: diagnosticEncoding.encoded, blobBytes: diagnosticEncoding.blobBytes || 0, decoys: diagnosticEncoding.decoys || 0 };
    }
    if (result.vmMeta?.outputBudget) {
        result.vmMeta.outputBudget.bytes = Buffer.byteLength(result.output, "utf8");
        result.vmMeta.outputBudget.withinBudget = Buffer.byteLength(result.output, "utf8") <= opts.maxOutputBytes;
    }
    // Report the wrapper tail as it was actually emitted, not as it was requested: with
    // `shape: "auto"` the choice is seed-derived, and routes that re-wrap the body (the
    // nest preset) end in a different container.
    if (result.vmMeta) {
        const emittedTail = result.output.trim();
        // On the nest route the callable bootstrap is real but lives inside an encoded
        // inner source, so a scan of the outer tail cannot prove absence. Report the
        // limit instead of claiming there is no bootstrap.
        const hiddenInNestedSource = result.vmMeta.nestedObfuscation === true && opts.wrapper.enabled !== false;
        result.vmMeta.wrapper = {
            shape: emittedTail.endsWith(")(...)")
                ? (/\}\):[A-Za-z_][A-Za-z0-9_]*\(\)\(\.\.\.\)$/.test(emittedTail)
                    ? "colon-dispatch"
                    // The callable bootstrap closes the metatable before the tail (`})(...)`),
                    // the direct shape closes the wrapper function instead (`end)(...)`); both
                    // are callable, but only the first one is a bootstrap table.
                    : (emittedTail.endsWith("})(...)") ? "callable-object" : "direct-callable-tail"))
                : (hiddenInNestedSource ? "bootstrap-in-nested-source" : "no-callable-bootstrap-tail"),
            // `shape` alone cannot tell "wrapper off" from "wrapper on, gsub container" — both
            // end in a non-callable tail — so echo the selector that produced the tail.
            enabled: opts.wrapper.enabled !== false,
            returnMode: opts.wrapper.returnMode || "setmetatable",
            requested: opts.wrapper.shape || "auto"
        };
    }
    result.stats = { ...(result.stats || {}), junkForge: junkForgeReport };
    if (result.vmMeta) {
        result.vmMeta.junkForge = {
            engine: junkForgeReport.engine || null,
            applied: junkForgeReport.applied === true,
            reason: junkForgeReport.reason || null,
            containers: junkForgeReport.containers || 0,
            banks: junkForgeReport.banks || 0,
            paddingBytes: junkForgeReport.paddingBytes || 0,
            keyBedBytes: junkForgeReport.latchBytes || 0,
            keyBedContainers: junkForgeReport.latchContainers || 0,
            keyBedTextBytes: junkForgeReport.latchTextBytes || 0,
            keyBedBound: finalized.keyBedBound === true,
            baseBytes: junkForgeReport.baseBytes || 0,
            floorBytes: junkForgeReport.floorBytes || 0,
            maxBytes: junkForgeReport.maxBytes || 0,
            paddingCapBytes: junkForgeReport.paddingCapBytes || 0,
            capBinding: junkForgeReport.capBinding || null,
            partial: junkForgeReport.partial === true
        };
    }

    // Report size as telemetry only: never pad/truncate code or silently change
    // the selected engine/preset to satisfy an output-size target. JunkForge
    // padding is the one deliberate size change and it is reported per build.
    if (result.vmMeta?.version === ACTIVE_VM_VERSION && Buffer.byteLength(result.output, "utf8") > opts.maxOutputBytes) {
        throw new Error(`ByteVeil v5.9.0 output budget exceeded: ${Buffer.byteLength(result.output, "utf8")} bytes > ${opts.maxOutputBytes}; backend policy was not downgraded`);
    }

    // Engine precheck: the finished text is reparsed with the engine's own front end and
    // every latch/cipher claim in vmMeta is re-derived from it. A mismatch crashes the
    // build here instead of shipping a script that cannot decode itself.
    if (opts.precheck?.enabled !== false) {
        // Resolved through the module object at call time, not destructured at require time,
        // so the suite can drive the gate with a deliberately failing verdict.
        const precheck = precheckModule.precheckArtifact({
            output: result.output,
            source,
            target: target.target,
            vmMeta: result.vmMeta || {},
            options: opts
        });
        if (result.vmMeta) {
            result.vmMeta.precheck = {
                ok: precheck.ok,
                fatal: precheck.fatal.slice(),
                notices: precheck.notices.slice(),
                ...precheck.report
            };
        }
        if (!precheck.ok) {
            throw new Error(`ByteVeil v5.9 engine precheck failed (${precheck.fatal.length}): ${precheck.fatal.join(" | ")}`);
        }
    }

    const sizeBudget = analyzeOutputBudget({
        source,
        output: result.output,
        preset: opts.preset,
        vmMeta: result.vmMeta || {},
        options: opts,
        floorBytes: junkForgeReport.floorBytes || MIN_FLOOR_BYTES,
        capBytes: opts.maxOutputBytes,
        paddingBytes: junkForgeReport.bytes || 0
    });
    result.sizeBudget = sizeBudget;
    result.stats = { ...(result.stats || {}), sizeBudget };
    result.optionAudit = optionAudit;
    return result;
}


function obfuscateFile(input, output, options = {}) {
    const source = fs.readFileSync(input, "utf8");
    const result = obfuscate(source, { ...options, filename: input });
    let finalOutput = String(output || (result.target === "lua" ? "output.lua" : "output.luau"));
    const ext = result.target === "lua" ? "lua" : "luau";
    if (!new RegExp(`\\.${ext}$`, "i").test(finalOutput)) finalOutput = finalOutput.replace(/\.(lua|luau|txt)$/i, "") + `.${ext}`;
    finalOutput = path.resolve(finalOutput);
    fs.writeFileSync(finalOutput, result.output, "utf8");
    result.outputFile = finalOutput;
    return result;
}

module.exports = { obfuscate, obfuscateFile, normalizeOptions };
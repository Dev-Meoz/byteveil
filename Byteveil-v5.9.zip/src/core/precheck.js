"use strict";

// ByteVeil v5.9 engine precheck.
//
// The generator proves its invariants on the source it writes, but the shipped body is the
// product of mangling, minification, JunkForge padding, the callable bootstrap and the
// diagnostic-blob pass. Precheck re-reads the finished text: it reparses the artifact with
// the engine's own parser, re-derives every latch binding the build claims, and refuses the
// build when the artifact and the metadata disagree. A failed precheck is a build crash, not
// a warning - the alternative is shipping a script that cannot decode itself.

const { parse, parseDetailed } = require("../frontend");
const { ENGINE_VERSION } = require("./version");

// The region root is a sum of chunk-local holders folded into a 32-bit word.
const KEY_SUM_PATTERN = /\(([A-Za-z_]\w*(?:\+[A-Za-z_]\w*){1,2})\)%4294967296/g;
const TEMPLATE_HOLE_PATTERN = /\b(undefined|NaN|\[object Object\])\b/g;
const WATERMARK_PATTERN = /ByteVeil Obfuscator v(\d+\.\d+\.\d+)/g;
// The material-root publication. An assignment whose right-hand side really reads a holder is
// a computed root; `0`, `nil` or a string literal (blank to spaces by the mask) is a constant
// an analyst can pin without touching a latch.
const MATERIAL_ROOT_PATTERN = /G\.materialRoot=([^;]*)/g;
const LITERAL_ONLY_WORDS = /\b(?:nil|true|false)\b/g;

function readsAHolder(expression) {
    return /[A-Za-z_]\w*/.test(String(expression).replace(LITERAL_ONLY_WORDS, ""));
}

// Blank out comments and string literals while keeping every offset, so text checks never
// fire on the payload blobs (a 2 MB base-N alphabet can contain any word). The scan also
// counts the long-bracket literals it consumed, which is the only trustworthy way to do it:
// the blob alphabet contains `[` and `=`, so a regex over the raw text counts content too.
function maskNonCode(text) {
    const out = Array.from(text);
    let longBrackets = 0;
    const blank = (from, to) => {
        for (let i = from; i < to && i < out.length; i++) {
            if (out[i] !== "\n") out[i] = " ";
        }
    };
    let i = 0;
    while (i < text.length) {
        const ch = text[i];
        if (ch === "-" && text[i + 1] === "-") {
            let end = i + 2;
            const open = /^\[(=*)\[/.exec(text.slice(end));
            if (open) {
                const close = new RegExp(`\\]${"=".repeat(open[1].length)}\\]`);
                const rest = text.slice(end + open[0].length);
                const hit = close.exec(rest);
                end = hit ? end + open[0].length + hit.index + hit[0].length : text.length;
            } else {
                while (end < text.length && text[end] !== "\n") end++;
            }
            blank(i, end);
            i = end;
            continue;
        }
        if (ch === "[") {
            const open = /^\[(=*)\[/.exec(text.slice(i));
            if (open) {
                const close = new RegExp(`\\]${"=".repeat(open[1].length)}\\]`);
                const rest = text.slice(i + open[0].length);
                const hit = close.exec(rest);
                const end = hit ? i + open[0].length + hit.index + hit[0].length : text.length;
                blank(i, end);
                longBrackets++;
                i = end;
                continue;
            }
        }
        if (ch === '"' || ch === "'") {
            let end = i + 1;
            while (end < text.length) {
                if (text[end] === "\\") { end += 2; continue; }
                if (text[end] === ch || text[end] === "\n") { end++; break; }
                end++;
            }
            blank(i, end);
            i = end;
            continue;
        }
        i++;
    }
    return { text: out.join(""), longBrackets };
}

function collectStringLiterals(node, out = [], visited = new Set()) {
    if (typeof node === "string") return out;
    if (!node || typeof node !== "object" || visited.has(node)) return out;
    visited.add(node);
    if (node.type === "String" && typeof node.value === "string") out.push(node.value);
    for (const key of Object.keys(node)) {
        if (key === "loc" || key === "range") continue;
        collectStringLiterals(node[key], out, visited);
    }
    return out;
}

function declaredBefore(body, name, at) {
    const match = new RegExp(`local\\s+(?:function\\s+)?${name}\\b`).exec(body);
    return Boolean(match && match.index < at);
}

function keySumReads(body) {
    return [...body.matchAll(KEY_SUM_PATTERN)].map((match) => ({
        at: match.index,
        addends: String(match[1]).split("+")
    }));
}

function precheckArtifact({ output, source, vmMeta = {}, target = "lua", options = {} } = {}) {
    const fatal = [];
    const notices = [];
    const report = {
        target,
        bytes: Buffer.byteLength(String(output || ""), "utf8"),
        checks: []
    };
    const record = (name, detail) => report.checks.push({ name, ...detail });
    const body = String(output || "");

    // 1. The artifact must be parseable by the engine's own front end. `parse()` recovers from
    //    errors instead of throwing, so the proof is the diagnostic list, not the AST.
    let artifactAst = null;
    try {
        const detailed = parseDetailed(body);
        artifactAst = detailed.ast;
        const errors = Array.isArray(detailed.errors) ? detailed.errors : [];
        report.reparsed = errors.length === 0;
        report.parseErrors = errors.length;
        report.topLevelStatements = Array.isArray(artifactAst?.body) ? artifactAst.body.length : 0;
        record("reparse", { ok: errors.length === 0, errors: errors.length, first: errors.length ? String(errors[0]?.message || errors[0]) : null, topLevelStatements: report.topLevelStatements });
        if (errors.length > 0) {
            fatal.push(`the finished artifact does not parse cleanly: ${String(errors[0]?.message || errors[0]).split("\n")[0]} (${errors.length} diagnostic(s))`);
        }
    } catch (error) {
        report.reparsed = false;
        report.parseErrors = -1;
        fatal.push(`the finished artifact does not parse: ${String(error.message).split("\n")[0]}`);
        record("reparse", { ok: false, error: String(error.message).split("\n")[0] });
    }

    // 2. A build that claims a key latch must ship a body whose region root really reads
    //    holders declared in that same chunk.
    const claimsKeyBed = vmMeta?.junkForge?.keyBedBound === true;
    const claimsGuardKey = vmMeta?.guardKeyBound === true;
    const reads = keySumReads(body);
    const provenReads = reads.filter((read) => read.addends.every((name) => declaredBefore(body, name, read.at)));
    report.keySumReads = reads.length;
    report.provenKeySumReads = provenReads.length;
    record("key-latch", { ok: !claimsKeyBed && !claimsGuardKey ? true : provenReads.length >= 1, reads: reads.length, proven: provenReads.length });
    if ((claimsKeyBed || claimsGuardKey) && provenReads.length < 1) {
        fatal.push("the build reports a bound key latch but no region root reads holders declared in its own chunk");
    }
    if (claimsKeyBed && claimsGuardKey && reads.length === 1 && provenReads.length === 1
        && reads[0].addends.length !== 3) {
        fatal.push(`a double-bound build must fold three addends into the region root, measured ${reads[0].addends.length}`);
    }

    // 3. The bound verdict must be the digest the guard actually compares against.
    if (claimsGuardKey) {
        const bound = Number(vmMeta?.antiGuardKey?.value);
        const predicted = Number(vmMeta?.antiHookVerdict?.expectedDigest);
        const readsReported = Number(vmMeta?.antiGuardKey?.reads || 0);
        record("verdict-agreement", { ok: bound === predicted && readsReported >= 1, bound, predicted, reads: readsReported });
        if (!Number.isInteger(bound) || bound !== predicted) {
            fatal.push(`the payload key addend ${bound} is not the emitted guard verdict ${predicted}`);
        }
        if (readsReported < 1) fatal.push("the generator reports a bound verdict with no read");
    }

    // 4. No JavaScript template holes may survive into the emitted Lua.
    const maskedScan = maskNonCode(body);
    const masked = maskedScan.text;
    const holes = [...masked.matchAll(TEMPLATE_HOLE_PATTERN)].map((match) => match[1]);
    report.templateHoles = holes.length;
    record("template-holes", { ok: holes.length === 0, holes: [...new Set(holes)] });
    if (holes.length > 0) fatal.push(`template hole(s) ${[...new Set(holes)].join(", ")} leaked into the emitted code`);

    // 5. Stale engine stamps are a packaging bug, not a cosmetic one. The watermark is a
    //    string literal, so this scan uses the raw text: the phrase needs spaces and dots,
    //    which no blob alphabet can carry, so an encoded payload can never match it.
    const stamps = [...body.matchAll(WATERMARK_PATTERN)].map((match) => match[1]);
    report.versionStamps = [...new Set(stamps)];
    record("version-stamp", { ok: stamps.every((value) => value === ENGINE_VERSION), active: ENGINE_VERSION, found: report.versionStamps });
    if (stamps.some((value) => value !== ENGINE_VERSION)) {
        fatal.push(`the artifact carries engine stamp(s) ${report.versionStamps.join(", ")} while the engine is ${ENGINE_VERSION}`);
    }

    // 6. Virtualized routes should not leave user string constants in plain sight, but only
    //    a fraction of the source is virtualized at the lower presets (a `#"中文"` or a
    //    `select("#", ...)` stays in the generated glue). This is a measured resistance gap
    //    that belongs in the build log and the LIMITATIONS document, not a build defect.
    const virtualized = Number(vmMeta?.regionCount || 0) > 0
        && vmMeta?.backend !== "compiler-transformed"
        && vmMeta?.fallback !== true;
    if (virtualized && typeof source === "string" && artifactAst) {
        let shipped;
        try {
            shipped = new Set(collectStringLiterals(artifactAst));
        } catch (error) {
            shipped = null;
            notices.push(`the artifact literals could not be enumerated: ${String(error.message).split("\n")[0]}`);
        }
        if (shipped) {
            let sourceLiterals = [];
            try {
                sourceLiterals = [...new Set(collectStringLiterals(parse(source)))];
            } catch (error) {
                notices.push(`the source literals could not be enumerated: ${String(error.message).split("\n")[0]}`);
            }
            const leaked = sourceLiterals.filter((value) => value.length > 0 && shipped.has(value));
            report.sourceStringLiterals = sourceLiterals.length;
            report.plaintextLeaks = leaked.length;
            record("plaintext-strings", { ok: true, leaked: leaked.length });
            if (leaked.length > 0) {
                notices.push(`${leaked.length} user string literal(s) stay in plaintext outside the VM region (${leaked.slice(0, 3).map((value) => JSON.stringify(value)).join(", ")})`);
            }
        }
    }

    // 7. The output cap is a promise to the caller (Roblox/FiveM limits).
    const cap = Number(options?.maxOutputBytes);
    if (Number.isFinite(cap) && cap > 0) {
        const within = report.bytes <= cap;
        record("size-cap", { ok: within, bytes: report.bytes, cap });
        if (!within) fatal.push(`output is ${report.bytes} bytes, over the ${cap} byte cap for ${target}`);
    }

    // 8. Blob census is reported for the build log; the forge block must not shrink.
    const forgeContainers = Number(vmMeta?.junkForge?.containers || 0);
    report.longBracketLiterals = maskedScan.longBrackets;
    report.forgeContainers = forgeContainers;
    record("container-census", { ok: maskedScan.longBrackets >= forgeContainers, measured: maskedScan.longBrackets, claimed: forgeContainers });
    if (maskedScan.longBrackets < forgeContainers) {
        fatal.push(`the body carries ${maskedScan.longBrackets} long-bracket literal(s) but the build claims ${forgeContainers} forge containers`);
    }

    // 9. A ciphered payload must publish the key its reader decrypts with. The `nest` preset
    //    ships the VM body through the legacy source loader, so the reader half - and the
    //    root it publishes - live inside an encoded inner source this scan cannot see. That
    //    route is reported as unproven rather than as a fault, exactly like its key bed.
    const nestedLoader = vmMeta?.nestedObfuscation === true || vmMeta?.nestedRequiresDynamicLoader === true;
    const cipher = vmMeta?.stringCipher;
    if (cipher?.applied === true && nestedLoader) {
        report.stringCipher = { algorithm: cipher.algorithm || null, constants: Number(cipher.constants || 0), cipheredBytes: Number(cipher.cipheredBytes || 0), materialPublished: null };
        record("veil-str", { ok: true, skipped: "nested-source-loader", constants: Number(cipher.constants || 0) });
    } else if (cipher?.applied === true) {
        // Presence is not the invariant. The crash ladder also writes `G.materialRoot=0`, so a
        // build whose only root assignment is a literal has a key an analyst can pin without
        // touching a latch. The published root has to read something.
        const assignments = [...masked.matchAll(MATERIAL_ROOT_PATTERN)].map((match) => match[1].trim());
        const computed = assignments.filter((rhs) => rhs.length > 0 && readsAHolder(rhs));
        const materialPublished = computed.length >= 1;
        const census = Number(cipher.constants || 0);
        report.stringCipher = {
            algorithm: cipher.algorithm || null, constants: census, cipheredBytes: Number(cipher.cipheredBytes || 0),
            materialPublished, rootAssignments: assignments.length, computedRoots: computed.length
        };
        record("veil-str", { ok: materialPublished && census > 0, constants: census, materialPublished, roots: assignments.length, computed: computed.length });
        if (assignments.length === 0) {
            fatal.push("the payload cipher is applied but the artifact never publishes the material root its string keys derive from");
        } else if (computed.length === 0) {
            fatal.push(`the payload cipher is applied but all ${assignments.length} material root assignment(s) are literals (${assignments.slice(0, 3).join(", ")}), so the string keys are not bound to the build`);
        }
        if (census < 1) fatal.push("the payload cipher reports zero ciphered constants while the route claims it applied");
    }

    return { ok: fatal.length === 0, fatal, notices, report };
}

module.exports = { precheckArtifact, maskNonCode, collectStringLiterals, keySumReads };

"use strict";

const { detect, detectLuaVersions } = require("../detect");

function detectTarget(source, filename = "") {
    const result = detect(source, filename);
    return {
        target: result.target,
        runtime: result.target === "luau" ? "Luau (source-compatible)" : "Lua 5.1-5.4 (auto-compatible)",
        reason: result.reason,
        confidence: result.confidence,
        languageFamily: result.languageFamily || result.target,
        luaVersions: result.luaVersions || []
    };
}

function resolveTarget(source, options = {}) {
    const requested = String(options.target || "auto").toLowerCase();
    if (requested === "luau") return { target: "luau", runtime: "Luau (source-compatible)", reason: "explicit target", confidence: 1, languageFamily: "luau", luaVersions: [] };
    if (requested === "lua") return { target: "lua", runtime: "Lua 5.1-5.4 (auto-compatible)", reason: "explicit target", confidence: 1, languageFamily: "lua", luaVersions: detectLuaVersions(source) };
    return detectTarget(source, options.filename);
}

module.exports = { detectTarget, resolveTarget };

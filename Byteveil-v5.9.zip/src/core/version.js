"use strict";

// v5.9 ships on the v5.8 profile: callable bootstrap, VeilSync-v2 payload ABI, every active region
// verified, repeated shadow-dispatch shared through a build-specific core. Historical wire formats, and the
// "5.8.0" release tag callers may still pin, keep their own behaviour.
const ENGINE_VERSION = "5.9.0";
const COMPATIBILITY_PROFILE = "4.7.9";
const PAYLOAD_LAYOUT = "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified";
const NESTED_PROFILE = "hybrid-function-policy-veilsync-v2-region-verified-shared-shadow-dispatch-core-callable-bootstrap-position-keyed-striped-payload-vm-no-source-loader";

module.exports = { ENGINE_VERSION, COMPATIBILITY_PROFILE, PAYLOAD_LAYOUT, NESTED_PROFILE };

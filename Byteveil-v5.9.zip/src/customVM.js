"use strict";

const crypto = require("node:crypto");

const {
    compile: compileStack
} = require("./compiler/stack/stack_compiler");

const {
    buildGeneratedSourceV40: buildStackGeneratedSourceV40
} = require("./compiler/stack/vm_generator");

const {
    compile: compileRegister
} = require("./compiler/register/register_compiler");

const {
    buildGeneratedSourceV40: buildRegisterGeneratedSourceV40
} = require("./compiler/register/reg_vm_generator");

const {
    SEMANTIC_OPS
} = require("./Opcode");

const {
    buildISAPlan,
    deriveDispatchKey,
    deriveStatePermutation
} = require("./obfuscation/isa_engine");

const {
    buildRegisterISAPlan,
    REGISTER_ISA_VERSION
} = require("./compiler/register/register_isa_v479");

const {
    descriptor,
    constantOperandIndexes
} = require("./opcode-table");

const {
    applyOpcodePlan
} = require("./opcode-mutator");

const {
    createContext
} = require("./ironbrew/context");

const {
    planSuperOperators
} = require("./ironbrew/super_operators");

const {
    validateBytecode
} = require("./ironbrew/validator");

const {
    buildProtectionPlan
} = require("./protection/byte_blinder");

const {
    buildMfgPlan
} = require("./protection/mfg");

const {
    buildProtectionIR
} = require("./protection/protection_ir");

const VM_MODES = Object.freeze(["stack", "register"]);
const { ENGINE_VERSION } = require("./core/version");
const VM_VERSION = ENGINE_VERSION;

function normalizeBuildSeed(seed, deterministic = false) {
    if (seed === undefined || seed === null) {
        if (deterministic) {
            return 1;
        }

        return crypto.randomBytes(4).readUInt32LE(0) || 0x6D2B79F5;
    }

    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 0x6D2B79F5;
    }

    let hash = 0x811C9DC5;

    for (const character of String(seed)) {
        hash ^= character.charCodeAt(0);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 0x6D2B79F5;
}

function mixSeed(seed, fingerprint) {
    let state = (normalizeBuildSeed(seed) >>> 0) ^ 0xC001D00D;
    const text = String(fingerprint || "");

    for (let i = 0; i < text.length; i++) {
        state = Math.imul(
            (state ^ text.charCodeAt(i)) >>> 0,
            16777619
        ) >>> 0;
    }

    state ^= state >>> 16;
    state = Math.imul(state, 2246822519) >>> 0;
    state ^= state >>> 13;

    return state >>> 0;
}

function permuteConstants(root, seed) {
    const visited = new WeakSet();

    function shuffle(values, salt) {
        const output = values.slice();

        let state = (
            (Number(seed) >>> 0) ^
            (Number(salt) >>> 0)
        ) >>> 0;

        if (state === 0) {
            state = 0x6D2B79F5;
        }

        const next = () => {
            state = (state + 0x6D2B79F5) >>> 0;

            let value = state;

            value = Math.imul(
                value ^ (value >>> 15),
                value | 1
            );

            value ^= value + Math.imul(
                value ^ (value >>> 7),
                value | 61
            );

            return (value ^ (value >>> 14)) >>> 0;
        };

        for (let i = output.length - 1; i > 0; i--) {
            const j = next() % (i + 1);
            [output[i], output[j]] = [output[j], output[i]];
        }

        return output;
    }

    function remapChunk(chunk, pathSalt) {
        if (
            !chunk ||
            typeof chunk !== "object" ||
            visited.has(chunk)
        ) {
            return;
        }

        visited.add(chunk);

        if (
            !Array.isArray(chunk.consts) ||
            !Array.isArray(chunk.code)
        ) {
            throw new TypeError(
                `ByteVeil ${VM_VERSION}: malformed chunk during constant permutation`
            );
        }

        const oldConstants = chunk.consts.slice();

        if (oldConstants.length > 1) {
            const order = shuffle(
                Array.from(
                    { length: oldConstants.length },
                    (_, index) => index
                ),
                Math.imul(pathSalt + 1, 0x45D9F3B) >>> 0
            );

            const oldToNew = new Array(oldConstants.length);
            const reordered = new Array(oldConstants.length);

            for (let newIndex = 0; newIndex < order.length; newIndex++) {
                const oldIndex = order[newIndex];

                oldToNew[oldIndex] = newIndex;
                reordered[newIndex] = oldConstants[oldIndex];
            }

            chunk.consts = reordered;

            const mode = chunk.mode === "stack"
                ? "stack"
                : "register";

            const decode = chunk.map?.decode || Object.create(null);

            for (const instruction of chunk.code) {
                if (
                    !Array.isArray(instruction) ||
                    instruction.length === 0
                ) {
                    continue;
                }

                const semanticName = decode[instruction[0]];

                if (typeof semanticName !== "string") {
                    throw new Error(
                        `ByteVeil ${VM_VERSION}: unknown opcode while permuting constants`
                    );
                }

                const operandIndexes = constantOperandIndexes(
                    semanticName,
                    instruction,
                    mode
                );

                for (const operandIndex of operandIndexes) {
                    const oldIndex = instruction[operandIndex];

                    if (
                        Number.isInteger(oldIndex) &&
                        oldIndex >= 0 &&
                        oldIndex < oldToNew.length
                    ) {
                        instruction[operandIndex] = oldToNew[oldIndex];
                    }
                }
            }
        }

        // Walk the already-reordered constant pool, including nested chunks.
        for (let index = 0; index < chunk.consts.length; index++) {
            const entry = chunk.consts[index];

            if (entry && entry.__chunk) {
                remapChunk(
                    entry.__chunk,
                    pathSalt + index + 1
                );
            }
        }
    }

    remapChunk(root, 1);

    return root;
}

// SUPER fusion stays disabled. Planning candidates and serializing a packed
// instruction is not sufficient: both production executors need a matching
// semantic executor and compatible jump relocation first.
function compile(ast, options = {}) {
    if (!ast || typeof ast !== "object" || Array.isArray(ast)) {
        throw new TypeError(
            "ByteVeil customVM.compile: expected AST object"
        );
    }

    if (!options || typeof options !== "object" || Array.isArray(options)) {
        throw new TypeError(
            "ByteVeil customVM.compile: options must be an object"
        );
    }

    const requestedMode = options.mode === undefined
        ? "register"
        : options.mode;

    const selected = VM_MODES.includes(requestedMode)
        ? requestedMode
        : "register";

    const inputSeed = normalizeBuildSeed(
        options.seed,
        options.deterministic === true
    );

    const opcodeWhitening = options.opcodeWhitening !== false;
    const protection = options.protection ?? null;
    const ir = options.ir ?? null;

    const strengthValue = Number(options.strength ?? 1000);

    const strength = Number.isFinite(strengthValue)
        ? Math.max(0, Math.min(10000, strengthValue))
        : 1000;

    const nestedProfile = options.nestedProfile || "balanced";

    const irFingerprint =
        ir?.fingerprint ||
        ir?.meta?.fingerprint ||
        "";

    const directiveSalt =
        Number(ast?.__byteVeilDirectiveSalt) >>> 0;

    const buildSeed = mixSeed(
        inputSeed,
        directiveSalt
            ? `${irFingerprint}|directive:${directiveSalt}`
            : irFingerprint
    );

    const bytecode = selected === "stack"
        ? compileStack(ast, buildSeed)
        : compileRegister(ast, buildSeed);

    bytecode.mode = selected;

    bytecode.irFingerprint =
        ir?.fingerprint ||
        ir?.meta?.fingerprint ||
        null;

    // Semantic instruction identities come from the compiler.
    // Opcode.js is only the backward-compatibility facade.
    const opNames =
        Array.isArray(bytecode.opcode) &&
        bytecode.opcode.length > 0
            ? bytecode.opcode.slice()
            : SEMANTIC_OPS.slice();

    const isaSeed = (buildSeed ^ 0x9E3779B9) >>> 0;

    const mutation = selected === "register"
        ? buildRegisterISAPlan(
            isaSeed,
            { lanes: 4 }
        )
        : buildISAPlan(
            opNames,
            isaSeed,
            { lanes: 4 }
        );

    const ironbrew = createContext(buildSeed, opNames);

    ironbrew.opcodeMap = {
        encode: { ...mutation.encode },
        decode: { ...mutation.decode },
        order: mutation.order.slice(),
        lanes: mutation.lanes.map(lane => ({ ...lane }))
    };

    // Apply one validated mapping to the bytecode tree before changing constants.
    const remapStats = applyOpcodePlan(
        bytecode,
        mutation,
        { recursive: true }
    );

    permuteConstants(
        bytecode,
        buildSeed ^ 0x6A09E667
    );

    const superActual = {
        fused: 0,
        maxDepth: 0,
        level: 0,
        rate: 0,
        instructionIds: 0
    };

    bytecode.superActual = superActual;
    bytecode.mutation = mutation;

    bytecode.opcodeMutation = {
        version: "physical-opcode-remap-v2",
        fingerprint: remapStats.fingerprint,
        chunks: remapStats.chunks,
        instructions: remapStats.instructions,
        mode: selected,
        validated: true
    };

    bytecode.registerISA = selected === "register"
        ? REGISTER_ISA_VERSION
        : null;

    ironbrew.superPlan = planSuperOperators(
        bytecode,
        buildSeed,
        ironbrew.superOperators
    );

    const polyPlan = {
        ...mutation,
        route: opNames.map(name => mutation.encode[name]),
        isaEngine: "semantic-isa-with-build-scoped-physical-remap-v2"
    };

    bytecode.polyPlan = polyPlan;
    bytecode.protection = protection;

    const protectionIR = buildProtectionIR({
        ast,
        ir,
        strength,
        mode: selected,
        preset: "custom",
        version: VM_VERSION
    });

    const protectionPlan = buildProtectionPlan({
        seed: buildSeed,
        strength,
        mode: selected,
        opcodeCount: opNames.length,
        macroPlan: ast?.__byteVeilMacros,
        lphPlan: ast?.__byteVeilLPH,
        version: VM_VERSION
    });

    const mfgPlan = buildMfgPlan({
        seed: buildSeed,
        strength,
        mode: selected,
        opNames,
        version: VM_VERSION
    });

    bytecode.protectionIR = protectionIR;
    bytecode.protectionPlan = protectionPlan;
    bytecode.mfgPlan = mfgPlan;

    bytecode.superPlan = {
        ...ironbrew.superPlan,
        planned: superActual.fused,
        actual: superActual
    };

    const descriptors = opNames
        .map(name => descriptor(name, selected))
        .filter(Boolean);

    bytecode.descriptorSalt = descriptors.reduce(
        (hash, item, index) => {
            const operandList = Array.isArray(item.ops)
                ? item.ops
                : [];

            const text =
                `${item.category}:${operandList.join(",")}:${index}`;

            for (const character of text) {
                hash = (
                    (hash * 33) ^
                    character.charCodeAt(0)
                ) >>> 0;
            }

            return hash;
        },
        5381
    ) >>> 0;

    ironbrew.statePermutation = deriveStatePermutation(
        buildSeed,
        12
    );

    const validation = validateBytecode(bytecode);

    const chosenNestedProfile =
        VM_VERSION === "4.7.3"
            ? "disabled-single-layer"
            : ["4.7.6", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.7.0", "5.8.0", "5.9.0"].includes(VM_VERSION)
                ? "binary-region-no-source-loader"
                : nestedProfile === "full"
                    ? "full"
                    : "balanced";

    return {
        mode: selected,
        bytecode,
        mutation,
        ironbrew,
        validation,

        registerInstructionSet: selected === "register"
            ? REGISTER_ISA_VERSION
            : "stack-semantic-isa-v479",

        nestedProfile: chosenNestedProfile,

        dispatchSeed: deriveDispatchKey(
            buildSeed,
            bytecode.code?.length || 0
        ),

        buildSeed,
        inputSeed,

        deterministic:
            options.deterministic === true ||
            options.seed !== undefined,

        version: VM_VERSION,
        opcodeWhitening,

        structure: "architecture-diverse-vm-vma-vmb-microop-v470",

        polyPlan,
        descriptorSalt: bytecode.descriptorSalt,
        superInstructionIds: superActual.instructionIds,

        protectionIR,
        protectionPlan,
        mfgPlan,

        opcodeRemap: bytecode.opcodeMutation
    };
}

function generate(compiled, options = {}) {
    if (
        !compiled ||
        typeof compiled !== "object" ||
        !compiled.bytecode
    ) {
        throw new TypeError(
            "ByteVeil customVM.generate: expected compiled VM object"
        );
    }

    if (!options || typeof options !== "object" || Array.isArray(options)) {
        throw new TypeError(
            "ByteVeil customVM.generate: options must be an object"
        );
    }

    const { mode, bytecode } = compiled;
    const vmSeed = Number(compiled.buildSeed ?? options.seed ?? 1) >>> 0;
    const buildVMGenerator = mode === "register"
        ? buildRegisterGeneratedSourceV40
        : buildStackGeneratedSourceV40;

    const structural = buildVMGenerator(bytecode, {
        seed: vmSeed,
        mode,
        strength: options.strength,
        opcodeWhitening:
            options.opcodeWhitening ??
            compiled.opcodeWhitening ??
            true,

        protectionPlan: compiled.protectionPlan,
        mfgPlan: compiled.mfgPlan,
        version: VM_VERSION,

        nestedProfile:
            options.nestedProfile ||
            compiled.nestedProfile ||
            "balanced",

        // The JunkForge key-bed holder is a chunk-level local inserted by the
        // pipeline after generation, so the region key can only be rebuilt when
        // that block is present and unmodified.
        forgeLatch: options.forgeLatch || null,

        // VeilStr-v1 ciphers every string constant in the region. Callers may opt out; the
        // fold check then never runs, so the payload keeps the plaintext vocabulary.
        stringCipher: options.stringCipher !== false,

        // The anti-hook verdict addend is predicted from the same guard the generator
        // bundles; the generator re-checks the number before it emits either half.
        guardLatch: options.guardLatch || null,

        runtimeBridgeParam: options.runtimeBridgeParam || null
    });

    const semanticNames = Array.isArray(bytecode.opcode)
        ? bytecode.opcode
        : SEMANTIC_OPS;

    return {
        output: structural.output,
        mode,
        bytecode,

        opcodeDescriptors: semanticNames
            .map(name => descriptor(name, mode))
            .filter(Boolean),

        structural
    };
}

function build(ast, options = {}) {
    const compiled = compile(ast, options);

    return {
        ...generate(compiled, options),
        compiled
    };
}

module.exports = {
    VM_MODES,
    compile,
    generate,
    build
};
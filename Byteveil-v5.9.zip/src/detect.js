"use strict";

const { lex } = require("./frontend/lexer");

const LUAU_PATTERNS = Object.freeze([
    /^\s*--!strict\b/m,
    /^\s*--!nonstrict\b/m,
    /^\s*--!nolint\b/m
]);

const IDENTIFIER = /^[\p{ID_Start}_][\p{ID_Continue}_]*$/u;

const LUAAU_COMPOUND = new Set([
    "+=", "-=", "*=", "/=", "%=", "..=", "^=", "&=", "|="
]);

const STRING_TOKEN_TYPES = new Set([
    "string",
    "interpolated",
    "longstring",
    "comment"
]);

function extension(name = "") {
    const text = String(name);
    const index = text.lastIndexOf(".");
    return index >= 0 ? text.slice(index).toLowerCase() : "";
}

function lexSource(text) {
    try {
        const result = lex(text);
        const all = Array.isArray(result?.tokens) ? result.tokens : [];

        const tokens = all.filter(
            token => token && token.type !== "eof"
        );

        const codeTokens = tokens.filter(
            token => !STRING_TOKEN_TYPES.has(token.type)
        );

        return {
            tokens,
            codeTokens,
            errors: Array.isArray(result?.errors)
                ? result.errors.slice()
                : [],
            failed: false
        };
    } catch (error) {
        return {
            tokens: [],
            codeTokens: [],
            errors: [{
                message: error?.message || String(error),
                line: null,
                column: null
            }],
            failed: true
        };
    }
}

function tokenObjects(text) {
    return lexSource(String(text)).tokens;
}

function tokenValues(text) {
    return tokenObjects(text).map(token => token.value);
}

function valuesOf(tokens) {
    return tokens.map(token => token.value);
}

function hasTokenSequence(tokens, sequence) {
    if (
        !Array.isArray(tokens) ||
        !Array.isArray(sequence) ||
        sequence.length === 0
    ) {
        return false;
    }

    outer: for (let i = 0; i + sequence.length <= tokens.length; i++) {
        for (let j = 0; j < sequence.length; j++) {
            if (tokens[i + j] !== sequence[j]) continue outer;
        }

        return true;
    }

    return false;
}

function hasTokenType(tokens, type, value = undefined) {
    return tokens.some(token =>
        token.type === type &&
        (value === undefined || token.value === value)
    );
}

function hasLuauDirective(text) {
    const lines = String(text)
        .replace(/^\uFEFF/, "")
        .split(/\r?\n/);

    let inspected = 0;

    for (const line of lines) {
        if (inspected >= 12) break;

        const trimmed = line.trim();

        if (!trimmed) {
            inspected++;
            continue;
        }

        if (/^--!\s*(?:strict|nonstrict|nolint)\b/.test(trimmed)) {
            return true;
        }

        if (trimmed.startsWith("--")) {
            if (/^--\[=*\[/.test(trimmed)) break;

            inspected++;
            continue;
        }

        break;
    }

    return false;
}

function hasTypeAlias(tokens) {
    for (let i = 0; i < tokens.length; i++) {
        if (tokens[i] !== "type") continue;
        if (!IDENTIFIER.test(String(tokens[i + 1] ?? ""))) continue;

        let cursor = i + 2;
        let generic = false;

        if (tokens[cursor] === "<") {
            let depth = 0;
            let closed = false;
            generic = true;

            for (; cursor < tokens.length; cursor++) {
                const value = tokens[cursor];

                if (value === "<") {
                    depth++;
                } else if (value === ">") {
                    depth--;

                    if (depth === 0) {
                        cursor++;
                        closed = true;
                        break;
                    }
                }
            }

            if (!closed) continue;
        }

        if (tokens[cursor] === "=" || tokens[cursor] === ">=") {
            return { found: true, generic };
        }
    }

    return { found: false, generic: false };
}

function hasFunctionGenerics(tokens) {
    for (let i = 0; i < tokens.length; i++) {
        if (tokens[i] !== "function") continue;

        let cursor = i + 1;

        if (IDENTIFIER.test(String(tokens[cursor] ?? ""))) {
            cursor++;
        }

        if (tokens[cursor] === "." || tokens[cursor] === ":") {
            while (
                cursor < tokens.length &&
                !["(", "=", ";", "end"].includes(tokens[cursor])
            ) {
                cursor++;
            }
        }

        if (tokens[cursor] === "<") {
            return true;
        }
    }

    return false;
}

function hasTypeAnnotation(tokens, tokenObjectsList) {
    const functionParameterRanges = [];

    for (let i = 0; i < tokens.length; i++) {
        if (tokens[i] !== "function") continue;

        let open = -1;

        for (let j = i + 1; j < Math.min(tokens.length, i + 256); j++) {
            if (tokens[j] === "(") {
                open = j;
                break;
            }

            if (["=", ";", "then", "do"].includes(tokens[j])) {
                break;
            }
        }

        if (open < 0) continue;

        let depth = 0;

        for (let j = open; j < tokens.length; j++) {
            if (tokens[j] === "(") {
                depth++;
            } else if (tokens[j] === ")") {
                depth--;

                if (depth === 0) {
                    functionParameterRanges.push([open, j]);
                    break;
                }
            }
        }
    }

    const inParameters = index => functionParameterRanges.some(
        ([open, close]) => index > open && index < close
    );

    for (let i = 1; i < tokens.length; i++) {
        if (tokens[i] !== ":") continue;

        const prev = tokens[i - 1];
        const beforePrev = tokens[i - 2];
        const next = tokens[i + 1];
        const afterNext = tokens[i + 2];

        const nextIsType =
            (typeof next === "string" && IDENTIFIER.test(next)) ||
            next === "{" ||
            next === "(" ||
            next === "?";

        if (!nextIsType) continue;

        const localAnnotation = beforePrev === "local";
        const parameterAnnotation =
            inParameters(i) &&
            (beforePrev === "(" || beforePrev === ",");
        const returnAnnotation = prev === ")";
        const optionalOrGeneric = next === "?" || afterNext === "?";

        if (
            localAnnotation ||
            parameterAnnotation ||
            returnAnnotation ||
            optionalOrGeneric
        ) {
            return true;
        }
    }

    return tokenObjectsList.some((token, index) => {
        if (token.value !== ":") return false;

        const previous = tokenObjectsList[index - 1];
        const next = tokenObjectsList[index + 1];

        return Boolean(
            previous &&
            next &&
            previous.type === "id" &&
            next.type === "id"
        );
    });
}

function detectLuaVersions(text, inputTokens = undefined) {
    const lexical = Array.isArray(inputTokens)
        ? null
        : lexSource(String(text));

    const tokens = Array.isArray(inputTokens)
        ? inputTokens
        : valuesOf(lexical.codeTokens);

    const candidates = new Set(["5.1", "5.2", "5.3", "5.4"]);
    const has = value => tokens.includes(value);
    const hasCall = name => hasTokenSequence(tokens, [name, "("]);

    if (hasCall("setfenv") || hasCall("getfenv")) {
        candidates.delete("5.3");
        candidates.delete("5.4");
    }

    if (
        has("goto") ||
        tokens.some((value, index) =>
            value === "::" &&
            IDENTIFIER.test(String(tokens[index + 1] ?? "")) &&
            tokens[index + 2] === "::"
        )
    ) {
        candidates.delete("5.1");
    }

    const hasLua53Operators = tokens.some((value, index) => {
        if (["//", "<<", ">>", "&", "|"].includes(value)) {
            return true;
        }

        if (value === "~" && tokens[index + 1] !== "=") {
            return true;
        }

        return false;
    });

    if (hasLua53Operators) {
        candidates.delete("5.1");
        candidates.delete("5.2");
    }

    const localAttribute = tokens.some((value, index) =>
        value === "<" &&
        ["const", "close"].includes(tokens[index + 1]) &&
        [">", ">="].includes(tokens[index + 2])
    );

    if (localAttribute) {
        candidates.delete("5.1");
        candidates.delete("5.2");
        candidates.delete("5.3");
    }

    return [...candidates];
}

function makeResult(target, confidence, reason, extra = {}) {
    return {
        target,
        confidence: Math.max(0, Math.min(0.99, confidence)),
        reason,
        languageFamily: target,
        luaVersions: target === "lua"
            ? (extra.luaVersions || [])
            : [],
        ...extra
    };
}

function detect(source, filename = "", options = {}) {
    if (!options || typeof options !== "object" || Array.isArray(options)) {
        throw new TypeError("detect: options must be an object");
    }

    const text = String(source ?? "").replace(/^\uFEFF/, "");
    const ext = extension(filename);
    const lexical = lexSource(text);
    const tokens = valuesOf(lexical.codeTokens);
    const tokenRecords = lexical.codeTokens;
    const evidence = [];

    if (hasLuauDirective(text)) evidence.push("luau-directive");

    const typeAlias = hasTypeAlias(tokens);

    if (typeAlias.found) {
        evidence.push(
            typeAlias.generic
                ? "generic-type-alias"
                : "type-alias"
        );
    }

    if (hasTokenSequence(tokens, ["export", "type"])) {
        evidence.push("export-type");
    }

    if (tokenRecords.some(
        token => token.value === "continue" && token.type === "keyword"
    )) {
        evidence.push("continue-statement");
    }

    if (tokenRecords.some(token => LUAAU_COMPOUND.has(token.value))) {
        evidence.push("compound-assignment");
    }

    if (
        tokenRecords.some(token => token.value === "@") &&
        tokens.includes("native")
    ) {
        evidence.push("attribute-syntax");
    }

    if (lexical.tokens.some(token => token.type === "interpolated")) {
        evidence.push("interpolated-string");
    }

    if (hasFunctionGenerics(tokens)) evidence.push("generic-function");

    if (hasTypeAnnotation(tokens, tokenRecords)) {
        evidence.push("type-annotation");
    }

    if (hasTokenSequence(tokens, ["if", "local"])) {
        evidence.push("if-local-expression-form");
    }

    if (tokenRecords.some(
        token => typeof token.raw === "string" &&
            /^0[bB][01]/.test(token.raw)
    )) {
        evidence.push("binary-literal");
    }

    const strongEvidence = evidence;

    if (strongEvidence.length > 0) {
        const directive = strongEvidence.includes("luau-directive");

        const confidence = directive
            ? 0.99
            : Math.min(
                0.97,
                0.79 + Math.min(3, strongEvidence.length - 1) * 0.055
            );

        return makeResult(
            "luau",
            confidence,
            `Luau syntax evidence: ${strongEvidence.join(", ")}`,
            {
                evidence: strongEvidence,
                lexErrors: lexical.errors,
                usedExtensionFallback: false
            }
        );
    }

    const versions = detectLuaVersions(text, tokens);

    if (ext === ".luau") {
        return makeResult(
            "luau",
            lexical.errors.length ? 0.45 : 0.61,
            lexical.errors.length
                ? "lexer errors; .luau extension fallback"
                : "source ambiguous; .luau extension fallback",
            {
                evidence,
                lexErrors: lexical.errors,
                usedExtensionFallback: true
            }
        );
    }

    if (ext === ".lua") {
        return makeResult(
            "lua",
            lexical.errors.length ? 0.42 : 0.61,
            lexical.errors.length
                ? "lexer errors; .lua extension fallback"
                : "source ambiguous; .lua extension fallback",
            {
                luaVersions: versions,
                evidence,
                lexErrors: lexical.errors,
                usedExtensionFallback: true
            }
        );
    }

    if (lexical.errors.length > 0) {
        return makeResult(
            "lua",
            0.35,
            "lexer errors; Lua-compatible fallback",
            {
                luaVersions: versions,
                evidence,
                lexErrors: lexical.errors,
                usedExtensionFallback: true
            }
        );
    }

    return makeResult(
        "lua",
        options.sourceFirst === false ? 0.72 : 0.8,
        options.sourceFirst === false
            ? "Lua-compatible default"
            : "Lua-compatible source default",
        {
            luaVersions: versions,
            evidence,
            lexErrors: [],
            usedExtensionFallback: false
        }
    );
}

module.exports = {
    detect,
    extension,
    tokenObjects,
    tokenValues,
    hasTokenSequence,
    LUAU_PATTERNS,
    detectLuaVersions
};
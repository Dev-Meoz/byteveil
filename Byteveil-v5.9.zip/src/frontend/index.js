const {lex,Lexer}=require('./lexer');
const {Parser,parse,parseDetailed}=require('./parser');
module.exports={lex,Lexer,Parser,parse,parseDetailed};

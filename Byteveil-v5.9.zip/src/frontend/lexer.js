
// Lua 5.4 and Luau disagree about which numeric spellings exist, and Number() can read none of the
// hex float forms, so the hex numeral is evaluated here. Measured host truth behind the accepted
// shapes (scratch/probe_hexfloat.js): Lua 5.4 takes "0x1.8", "0x.8" and "0x1." (exponent optional,
// either side of the dot may be empty) but rejects a leading "_"; Luau rejects those three but
// takes "0x_FF" and "0b_1". Both take "5.". The lexer therefore accepts the union of the two
// grammars; per-target legality stays with the host that finally runs the file.
const NUMERIC_LITERAL = /^(?:0[xX](?:_?[0-9a-fA-F])*\.(?:_?[0-9a-fA-F])*(?:[pP][+-]?[0-9](?:_?[0-9])*)?|0[xX](?:_?[0-9a-fA-F])+(?:[pP][+-]?[0-9](?:_?[0-9])*)?|0[bB](?:_?[01])+|(?:[0-9](?:_?[0-9])*)\.(?:_?[0-9](?:_?[0-9])*)?(?:[eE][+-]?[0-9](?:_?[0-9])*)?|(?:[0-9](?:_?[0-9])*)(?:[eE][+-]?[0-9](?:_?[0-9])*)?|\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?)/;

function parseNumericLiteral(raw) {
  const text = String(raw).replace(/_/g, "");
  const hex = text.match(/^0[xX]([0-9a-fA-F]*)(?:\.([0-9a-fA-F]*))?(?:[pP]([+-]?\d+))?$/);
  if (hex && (hex[1] || hex[2])) {
    let value = hex[1] ? parseInt(hex[1], 16) : 0;
    const frac = hex[2] || "";
    for (let i = 0; i < frac.length; i++) value += parseInt(frac[i], 16) / Math.pow(16, i + 1);
    if (hex[3] !== undefined) value *= Math.pow(2, Number(hex[3]));
    return value;
  }
  const binary = text.match(/^0[bB]([01]+)$/);
  if (binary) return parseInt(binary[1], 2);
  return Number(text);
}

const KEYWORDS = new Set([
  'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
  'continue', 'export', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then',
  'true', 'type', 'until', 'while'
]);

// Lua's native grammar traditionally restricts identifiers to ASCII, but
// ByteVeil's custom VM can safely virtualize Unicode identifiers and mangle
// them before generating the runtime. Accept Unicode ID_Start/ID_Continue so
// source variables may use Vietnamese, Chinese, Japanese, Korean, Cyrillic,
// Arabic, Indic and other scripts. String/comment handling remains unchanged.
const IDENTIFIER_START = /^[_\p{ID_Start}]$/u;
const IDENTIFIER_CONTINUE = /^[_\u200C\u200D\p{ID_Continue}]$/u;

function readIdentifier(source, start) {
  let offset = start;
  let first = true;
  while (offset < source.length) {
    const codePoint = source.codePointAt(offset);
    const character = String.fromCodePoint(codePoint);
    if (!(first ? IDENTIFIER_START : IDENTIFIER_CONTINUE).test(character)) break;
    offset += character.length;
    first = false;
  }
  return source.slice(start, offset);
}

class Lexer {
  constructor(src) {
    this.s = String(src).replace(/^\uFEFF/, '');
    this.i = 0;
    this.line = 1;
    this.col = 1;
    this.lastWasCR = false;
    this.tokens = [];
    this.errors = [];
  }

  adv(n = 1) {
    while (n-- > 0 && this.i < this.s.length) {
      const c = this.s[this.i];
      if (c === '\r') {
        // Treat CRLF as one logical newline even when callers advance one
        // code unit at a time (for example, while decoding a string escape).
        this.line++;
        this.col = 1;
        this.lastWasCR = true;
      } else if (c === '\n') {
        if (!this.lastWasCR) this.line++;
        this.col = 1;
        this.lastWasCR = false;
      } else {
        this.col++;
        this.lastWasCR = false;
      }
      this.i++;
    }
  }

  add(type, value, line = this.line, col = this.col) {
    this.tokens.push({ type, value, line, col });
  }

  // Lua/Luau long bracket: [[...]], [=[...]=], [==[...]==], ...
  longBracket() {
    const m = this.s.slice(this.i).match(/^\[(=*)\[/);
    if (!m) return null;
    return {
      open: m[0],
      close: `]${m[1]}]`
    };
  }

  readLongString() {
    const info = this.longBracket();
    if (!info) return false;

    const line = this.line;
    const col = this.col;
    this.adv(info.open.length);

    const start = this.i;
    const end = this.s.indexOf(info.close, this.i);

    if (end === -1) {
      const value = this.s.slice(start);
      this.adv(this.s.length - this.i);
      this.errors.push({
        message: 'Unterminated long string',
        line,
        col
      });
      this.add('string', value, line, col);
      return true;
    }

    const value = this.s.slice(start, end);
    this.adv(end - this.i + info.close.length);
    this.add('string', value, line, col);
    return true;
  }

  readLongComment(startLine = this.line, startCol = this.col) {
    const info = this.s.slice(this.i).match(/^\[(=*)\[/);
    if (!info) return false;

    const open = info[0];
    const close = `]${info[1]}]`;
    const line = startLine;
    const col = startCol;

    // Current position is the '[' immediately after '--'.
    this.adv(open.length);
    const end = this.s.indexOf(close, this.i);

    if (end === -1) {
      this.adv(this.s.length - this.i);
      this.errors.push({
        message: 'Unterminated long comment',
        line,
        col
      });
      return true;
    }

    this.adv(end - this.i + close.length);
    return true;
  }

  readEscapedString(quote, line, col) {
    let value = '';
    this.adv();

    const simple = {
      a: String.fromCharCode(7),
      b: '\b',
      f: '\f',
      n: '\n',
      r: '\r',
      t: '\t',
      v: String.fromCharCode(11),
      '\\': '\\',
      '"': '"',
      "'": "'"
    };

    while (this.i < this.s.length && this.s[this.i] !== quote) {
      const c = this.s[this.i];
      if (c === '\n' || c === '\r') {
        this.errors.push({ message: 'Unescaped newline in quoted string', line, col });
        // Recover through this malformed literal so a closing quote on the
        // next physical line does not become a misleading new string token.
        let cursor = this.i;
        let closingQuote = -1;
        while (cursor < this.s.length) {
          if (this.s[cursor] === '\\') { cursor += 2; continue; }
          if (this.s[cursor] === quote) { closingQuote = cursor; break; }
          cursor++;
        }
        if (closingQuote >= 0) {
          this.adv(closingQuote - this.i + 1);
        } else {
          this.adv(this.s.length - this.i);
          this.errors.push({ message: 'Unterminated string', line, col });
        }
        this.add('string', value, line, col);
        return;
      }
      if (c !== '\\') {
        value += c;
        this.adv();
        continue;
      }

      this.adv();
      if (this.i >= this.s.length) break;
      const e = this.s[this.i];

      // Lua/Luau decimal byte escape: \\ddd (up to 3 digits).
      if (/[0-9]/.test(e)) {
        let digits = '';
        let count = 0;
        while (this.i < this.s.length && /[0-9]/.test(this.s[this.i]) && count < 3) {
          digits += this.s[this.i];
          this.adv();
          count++;
        }
        const code = Number(digits);
        if (code > 255) {
          this.errors.push({ message: `Decimal escape out of range: \\${digits}`, line, col });
        } else {
          value += String.fromCharCode(code);
        }
        continue;
      }

      // Lua/Luau hexadecimal byte escape requires exactly two hex digits.
      if (e === 'x') {
        const hex = this.s.slice(this.i + 1, this.i + 3);
        if (/^[0-9A-Fa-f]{2}$/.test(hex)) {
          value += String.fromCharCode(parseInt(hex, 16));
          this.adv(3); // x plus two digits
          continue;
        }
        this.errors.push({ message: 'Malformed hexadecimal escape: expected \\x followed by two hex digits', line, col });
        value += 'x';
        this.adv();
        continue;
      }

      // Lua/Luau Unicode escape: \\u{...}; reject non-scalar code points
      // so quoted and interpolated strings apply consistent Unicode rules.
      if (e === 'u' && this.s[this.i + 1] === '{') {
        const close = this.s.indexOf('}', this.i + 2);
        if (close < 0) {
          this.errors.push({ message: 'Malformed Unicode escape: missing closing }', line, col });
          value += 'u';
          this.adv();
          continue;
        }
        const body = this.s.slice(this.i + 2, close);
        if (!/^[0-9A-Fa-f]+$/.test(body)) {
          this.errors.push({ message: `Malformed Unicode escape: \\u{${body}}`, line, col });
          value += `u{${body}}`;
          this.adv(close - this.i + 1);
          continue;
        }
        const cp = parseInt(body, 16);
        if (cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) {
          this.errors.push({ message: `Unicode escape is not a valid scalar value: \\u{${body}}`, line, col });
        } else {
          value += String.fromCodePoint(cp);
        }
        this.adv(close - this.i + 1);
        continue;
      }

      // Lua \\z consumes all following whitespace, including newlines.
      if (e === 'z') {
        this.adv();
        while (this.i < this.s.length && /\s/.test(this.s[this.i])) this.adv();
        continue;
      }

      // A backslash followed by LF, CRLF, or CR continues as one newline.
      if (e === '\n' || e === '\r') {
        value += '\n';
        const wasCR = e === '\r';
        this.adv();
        if (wasCR && this.s[this.i] === '\n') this.adv();
        continue;
      }

      value += Object.prototype.hasOwnProperty.call(simple, e) ? simple[e] : e;
      this.adv();
    }

    if (this.s[this.i] === quote) this.adv();
    else this.errors.push({ message: 'Unterminated string', line, col });
    this.add('string', value, line, col);
  }

  readInterpolatedString() {
    if (this.s[this.i] !== '`') return false;
    const line = this.line;
    const col = this.col;
    const start = this.i;
    this.adv();
    while (this.i < this.s.length) {
      const c = this.s[this.i];
      if (c === '\\') {
        this.adv();
        if (this.s[this.i] === 'u' && this.s[this.i + 1] === '{') {
          this.adv(); this.adv();
          while (this.i < this.s.length && this.s[this.i] !== '}') this.adv();
          if (this.s[this.i] === '}') this.adv();
          continue;
        }
        if (this.i < this.s.length) this.adv();
        if (this.s[this.i - 1] === 'x' && /^[0-9a-fA-F]{2}$/.test(this.s.slice(this.i, this.i + 2))) { this.adv(); this.adv(); }
        continue;
      }
      if (c === '`') {
        this.adv();
        this.add('interpolated', this.s.slice(start, this.i), line, col);
        return true;
      }
      this.adv();
    }
    this.errors.push({ message: 'Unterminated interpolated string', line, col });
    this.add('interpolated', this.s.slice(start), line, col);
    return true;
  }

  lex() {
    // Lua interpreters treat a leading shebang line as a comment. Ignore it
    // before tokenization so CLI scripts do not fail on the initial `#!`.
    if (this.i === 0 && this.s.startsWith('#!')) {
      while (this.i < this.s.length && this.s[this.i] !== '\n') this.adv();
    }
    while (this.i < this.s.length) {
      const c = this.s[this.i];

      if (/\s/.test(c)) {
        this.adv();
        continue;
      }

      // Lua/Luau comments, including --!strict / --!native directives.
      if (c === '-' && this.s[this.i + 1] === '-') {
        const commentLine = this.line;
        const commentCol = this.col;
        const afterDashes = this.i + 2;
        if (this.s[afterDashes] === '[') {
          // Advance through the dashes instead of moving the index directly;
          // otherwise token columns after long comments drift by two columns.
          this.adv(2);
          if (this.readLongComment(commentLine, commentCol)) continue;
        } else {
          this.adv(2);
        }

        while (this.i < this.s.length && this.s[this.i] !== '\n' && this.s[this.i] !== '\r') this.adv();
        continue;
      }

      const line = this.line;
      const col = this.col;

      // Long strings must be recognized before '[' is tokenized as punctuation.
      // This is what prevents valid source such as [[hello !]] from reporting
      // "Unexpected character !".
      if (c === '[' && this.readLongString()) continue;

      if (c === '"' || c === "'") {
        this.readEscapedString(c, line, col);
        continue;
      }

      // Luau interpolated strings are retained as raw tokens here. The parser
      // lowers their interpolation expressions into concat/tostring AST nodes
      // before compilation into either VM.
      if (c === '`' && this.readInterpolatedString()) continue;

      if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(this.s[this.i + 1] || ''))) {
        const m = this.s.slice(this.i).match(NUMERIC_LITERAL);
        if (m) {
          const raw = m[0];
          const next = this.s[this.i + raw.length] || '';
          if (/^[_\p{ID_Continue}]$/u.test(next)) {
            this.errors.push({ message: `Malformed numeric literal near ${JSON.stringify(raw + next)}`, line, col });
          }
          this.add('number', parseNumericLiteral(raw), line, col);
          this.tokens[this.tokens.length - 1].raw = raw;
          this.adv(raw.length);
          continue;
        }
      }

      // Read identifiers by Unicode code point (not UTF-16 code unit), so
      // supplementary-plane letters and combining marks are not split into
      // unrelated lexer errors. ASCII keywords remain reserved as before.
      const identifier = readIdentifier(this.s, this.i);
      if (identifier) {
        this.add(KEYWORDS.has(identifier) ? 'keyword' : 'id', identifier, line, col);
        this.adv(identifier.length);
        continue;
      }

      const three = this.s.slice(this.i, this.i + 3);
      const two = this.s.slice(this.i, this.i + 2);

      if (three === '...') {
        this.add('op', three, line, col);
        this.adv(3);
        continue;
      }

      if (
        ['==', '~=', '<=', '>=', '..', '+=', '-=', '*=', '/=', '//=', '%=', '^=', '::', '//',
          '<<', '>>', '&=', '|=', '->'].includes(two) ||
        three === '//' || three === '//=' || three === '<<=' || three === '>>=' || three === '..='
      ) {
        const op = ['//=', '<<=', '>>=', '..='].includes(three) ? three : two;
        this.add('op', op, line, col);
        this.adv(op.length);
        continue;
      }

      if ('+-*/%^#=<>~&|'.includes(c)) {
        this.add('op', c, line, col);
        this.adv();
        continue;
      }

      if ('(){}[];,.:?@'.includes(c)) {
        this.add('punc', c, line, col);
        this.adv();
        continue;
      }

      this.errors.push({ message: `Unexpected character ${c}`, line, col });
      this.adv();
    }

    this.tokens.push({
      type: 'eof',
      value: '<eof>',
      line: this.line,
      col: this.col
    });

    return {
      tokens: this.tokens,
      errors: this.errors
    };
  }
}

module.exports = {
  Lexer,
  lex: (s) => new Lexer(s).lex()
};

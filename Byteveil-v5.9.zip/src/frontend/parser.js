"use strict";

const { lex } = require("./lexer");

const BIN_PREC = Object.freeze({
  or: 1,
  and: 2,
  "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3,
  "|": 4,
  "~": 5,
  "&": 6,
  "<<": 7, ">>": 7,
  "..": 8,
  "+": 9, "-": 9,
  "*": 10, "/": 10, "//": 10, "%": 10,
  "^": 12
});

const RIGHT_ASSOC = new Set(["^", ".."]);
const UNARY = new Set(["not", "-", "#", "~"]);
const COMPOUND = new Set(["+=", "-=", "*=", "/=", "//=", "%=", "^=", "..="]);
const TERMINATORS = new Set(["end", "else", "elseif", "until", "<eof>"]);
// Sentinel returned by `Parser#value()` for string-literal tokens. Identifier, keyword,
// operator, punctuation and <eof> token text never contains a NUL byte, so the sentinel
// compares false against every grammar lookup while still being a plain string.
const LITERAL_TOKEN = "\0literal";

function longBracketAt(source, index) {
  const match = source.slice(index).match(/^\[(=*)\[/);
  if (!match) return null;
  return { equals: match[1], end: index + match[0].length };
}

function skipQuoted(source, index) {
  const quote = source[index];
  let i = index + 1;
  while (i < source.length) {
    if (source[i] === '\\') { i += 2; continue; }
    if (source[i] === quote) return i + 1;
    i++;
  }
  return i;
}

function skipLongBracket(source, index) {
  const open = longBracketAt(source, index);
  if (!open) return index;
  const close = `]${open.equals}]`;
  const at = source.indexOf(close, open.end);
  return at < 0 ? source.length : at + close.length;
}

function skipInterpolatedEscape(source, index) {
  let i = Math.min(index + 2, source.length);
  if (source[index] !== "\\") return index + 1;
  const escaped = source[index + 1];
  if (escaped === "u" && source[index + 2] === "{") {
    const close = source.indexOf("}", index + 3);
    return close < 0 ? source.length : close + 1;
  }
  if (escaped === "x" && /^[0-9a-fA-F]{2}$/.test(source.slice(index + 2, index + 4))) return index + 4;
  if (/[0-9]/.test(escaped || "")) {
    i = index + 2;
    while (i < source.length && i < index + 4 && /[0-9]/.test(source[i])) i++;
    return i;
  }
  return i;
}

function findInterpolationClose(source, start) {
  let depth = 0;
  let i = start;
  while (i < source.length) {
    const c = source[i];
    if (c === "'" || c === '"') { i = skipQuoted(source, i); continue; }
    if (c === '[') {
      const next = skipLongBracket(source, i);
      if (next !== i) { i = next; continue; }
    }
    if (c === '-' && source[i + 1] === '-') {
      const next = skipLongBracket(source, i + 2);
      if (next !== i + 2) { i = next; continue; }
      i += 2;
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    // A nested backtick literal inside an interpolation expression is a
    // string, so its braces must not affect the outer expression's depth.
    if (c === '`') {
      i++;
      while (i < source.length) {
        if (source[i] === '\\') { i += 2; continue; }
        if (source[i++] === '`') break;
      }
      continue;
    }
    if (c === '{') { depth++; i++; continue; }
    if (c === '}') {
      if (depth === 0) return i;
      depth--; i++; continue;
    }
    i++;
  }
  return -1;
}

function decodeInterpolatedChunk(raw) {
  let out = '';
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (c !== '\\') { out += c; continue; }
    if (i + 1 >= raw.length) { out += '\\'; continue; }
    const e = raw[++i];
    if (e === '\n') { out += '\n'; continue; }
    if (e === '\r') { if (raw[i + 1] === '\n') i++; out += '\n'; continue; }
    if (e === 'z') {
      while (i + 1 < raw.length && /\s/.test(raw[i + 1])) i++;
      continue;
    }
    if (e === 'x' && /^[0-9a-fA-F]{2}$/.test(raw.slice(i + 1, i + 3))) {
      out += String.fromCharCode(parseInt(raw.slice(i + 1, i + 3), 16)); i += 2; continue;
    }
    if (e === 'u' && raw[i + 1] === '{') {
      const end = raw.indexOf('}', i + 2);
      if (end > i + 2) {
        const hex = raw.slice(i + 2, end);
        const cp = /^[0-9a-fA-F]+$/.test(hex) ? Number.parseInt(hex, 16) : -1;
        if (cp >= 0 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff)) {
          out += String.fromCodePoint(cp); i = end; continue;
        }
      }
      out += 'u'; continue;
    }
    if (/[0-9]/.test(e)) {
      let digits = e;
      while (digits.length < 3 && /[0-9]/.test(raw[i + 1] || '')) digits += raw[++i];
      out += String.fromCharCode(Number(digits) & 0xff); continue;
    }
    const simple = { a: '\x07', b: '\b', f: '\f', n: '\n', r: '\r', t: '\t', v: '\x0b', '\\': '\\', '`': '`', '{': '{', '}': '}' };
    out += Object.prototype.hasOwnProperty.call(simple, e) ? simple[e] : e;
  }
  return out;
}

class Parser {
  constructor(tokens) {
    this.t = Array.isArray(tokens) ? tokens : [];
    this.i = 0;
    this.errors = [];
    this.features = {
      typeSyntax: false,
      genericSyntax: false,
      attributes: false,
      goto: false,
      labels: false,
      ifExpression: false,
      stringInterpolation: false,
      unsupported: false
    };
    this.eof = { type: "eof", value: "<eof>", line: 0, col: 0 };
  }

  p(offset = 0) { return this.t[this.i + offset] || this.eof; }

  // A string literal is data, never grammar. Its text can be `}`, `;` or even `end`, and the
  // lookups below (block terminators, empty expression lists, table-field ends, operator
  // dispatch) all compare raw token text, so without this guard `f("}")` parses as a call with
  // no argument. `value()` is the single place that fixes every call site at once; the AST
  // still reads the literal through `p()`, which is untouched.
  value(offset = 0) {
    const token = this.p(offset);
    if (token.type === "string" || token.type === "interpolated") return LITERAL_TOKEN;
    return token.value;
  }

  eat(value) {
    if (this.value() === value) return this.t[this.i++];
    return null;
  }

  expect(value) {
    const token = this.eat(value);
    if (token) return token;
    const t = this.p();
    this.errors.push({ message: `Expected ${value}, got ${t.value}`, line: t.line, col: t.col });
    return null;
  }

  markUnsupported(kind) {
    this.features.unsupported = true;
    if (kind) this.features[kind] = true;
  }

  parse() {
    const body = [];
    while (!TERMINATORS.has(this.value())) {
      const at = this.i;
      const stmt = this.statement();
      if (stmt) body.push(stmt);
      if (this.i === at) this.i++;
    }
    return { type: "Chunk", body, features: this.features };
  }

  parseBlock(stop = TERMINATORS) {
    const body = [];
    while (!stop.has(this.value())) {
      const at = this.i;
      const stmt = this.statement();
      if (stmt) body.push(stmt);
      if (this.i === at) this.i++;
    }
    return body;
  }

  statement() {
    const start = this.p();
    const node = this._statement();
    if (node && typeof node === "object" && !Array.isArray(node)) {
      // Keep source coordinates as non-enumerable metadata so compile-time
      // directives can bind to their next statement without polluting the AST/IR.
      if (!Object.prototype.hasOwnProperty.call(node, "__line")) {
        Object.defineProperty(node, "__line", { value: Number(start?.line) || 0, enumerable: false, configurable: true });
        Object.defineProperty(node, "__col", { value: Number(start?.col) || 0, enumerable: false, configurable: true });
      }
    }
    return node;
  }

  _statement() {
    if (this.eat(";")) return null;

    // Luau attributes such as @native are valid source syntax. They are
    // preserved by the source-protection route while remaining outside the
    // strict VM subset until a dedicated lowering exists.
    if (this.eat("@")) {
      this.expectId();
      this.markUnsupported("attributes");
      return this.statement();
    }

    if (this.eat("local")) return this.parseLocal();
    if (this.eat("function")) return this.parseFunctionStatement(false);
    if (this.eat("return")) return this.parseReturn();
    if (this.eat("if")) return this.parseIfStatement();
    if (this.eat("while")) return this.parseWhile();
    if (this.eat("repeat")) return this.parseRepeat();
    if (this.eat("for")) return this.parseFor();
    if (this.eat("do")) return { type: "Do", body: this.parseBlock(new Set(["end", "<eof>"])), end: this.expect("end") };
    if (this.eat("break")) return { type: "Break" };
    if (this.eat("continue")) return { type: "Continue" };
    if (this.eat("goto")) { this.markUnsupported("goto"); return { type: "Goto", name: this.expectId() }; }

    if (this.value() === "::") return this.parseLabel();
    if (this.value() === "type" || (this.value() === "export" && this.value(1) === "type")) {
      return this.parseTypeStatement();
    }

    const first = this.p();
    const lhs = this.prefixExpression();
    if (!lhs) return null;

    // Parse the complete variable list before checking for '='. The previous
    // parser only accepted `lhs = ...`, so valid `a,b = ...` statements were
    // incorrectly rejected before the compiler could apply parallel semantics.
    if (this.value() === ",") {
      const vars = [lhs, ...this.moreLhs()];
      if (this.eat("=")) {
        const values = this.exprListOrEmpty();
        return { type: "Assign", vars, values };
      }
      this.errorAt(first, "Expected assignment after multiple variables");
      return null;
    }

    if (this.eat("=")) {
      const values = this.exprListOrEmpty();
      return { type: "Assign", vars: [lhs], values };
    }

    if (COMPOUND.has(this.value())) {
      const op = this.t[this.i++].value;
      if (!["+=", "-=", "*=", "/=", "//=", "%=", "^=", "..="].includes(op) || lhs.type !== "Id") this.markUnsupported("compoundSyntax");
      return { type: "Compound", left: lhs, op, value: this.expression() };
    }

    if (lhs.type === "Call") return { type: "CallStmt", call: lhs };

    this.errorAt(first, "Expected assignment or call");
    return null;
  }

  parseLocal() {
    if (this.eat("function")) {
      const name = this.expectId();
      const generic = this.readGenericParameters();
      if (generic) this.markUnsupported("genericSyntax");
      const fn = this.functionBody();
      fn.genericParameters = generic;
      return { type: "LocalFunction", name, fn };
    }

    const vars = [];
    while (true) {
      const name = this.expectId();
      const typeAnnotation = this.readTypeAnnotation();
      const attribute = this.readAttribute();
      if (typeAnnotation || attribute) this.markUnsupported(attribute === "<close>" || attribute === "<const>" ? "attributes" : "typeSyntax");
      vars.push({ type: "Id", name, typeAnnotation, attribute });
      if (!this.eat(",")) break;
    }

    const values = this.eat("=") ? this.exprListOrEmpty() : [];
    return { type: "Local", vars, values };
  }

  parseFunctionStatement(local) {
    const nameParts = [];
    const first = this.expectId();
    nameParts.push({ type: "name", value: first });
    while (this.eat(".")) nameParts.push({ type: "member", value: this.expectId() });
    let method = false;
    if (this.eat(":")) {
      method = true;
      nameParts.push({ type: "method", value: this.expectId() });
    }

    const generic = this.readGenericParameters();
    if (generic) this.markUnsupported("genericSyntax");

    if (nameParts.length > 1 || method) this.markUnsupported();
    const fn = this.functionBody(method ? [nameParts[nameParts.length - 1].value] : []);
    return {
      type: local ? "LocalFunction" : "Function",
      name: nameParts.map((x) => x.value).join(method ? "." : "."),
      namePath: nameParts,
      method,
      fn
    };
  }

  parseReturn() {
    if (TERMINATORS.has(this.value()) || this.value() === ";") return { type: "Return", values: [] };
    return { type: "Return", values: this.exprListOrEmpty() };
  }

  parseIfStatement() {
    const branches = [];
    const cond = this.expression();
    this.expect("then");
    branches.push({ cond, body: this.parseBlock(new Set(["elseif", "else", "end", "<eof>"])) });
    while (this.eat("elseif")) {
      const c = this.expression();
      this.expect("then");
      branches.push({ cond: c, body: this.parseBlock(new Set(["elseif", "else", "end", "<eof>"])) });
    }
    const elseBody = this.eat("else")
      ? this.parseBlock(new Set(["end", "<eof>"]))
      : [];
    this.expect("end");
    return { type: "If", branches, elseBody };
  }

  parseWhile() {
    const cond = this.expression();
    this.expect("do");
    const body = this.parseBlock(new Set(["end", "<eof>"]));
    this.expect("end");
    return { type: "While", cond, body };
  }

  parseRepeat() {
    const body = this.parseBlock(new Set(["until", "<eof>"]));
    this.expect("until");
    return { type: "Repeat", body, cond: this.expression() };
  }

  parseFor() {
    const firstName = this.expectId();
    if (this.eat("=")) {
      const start = this.expression();
      this.expect(",");
      const end = this.expression();
      const step = this.eat(",") ? this.expression() : null;
      this.expect("do");
      const body = this.parseBlock(new Set(["end", "<eof>"]));
      this.expect("end");
      return { type: "ForNum", name: firstName, start, end, step, body };
    }

    const names = [{ name: firstName, typeAnnotation: null }];
    while (this.eat(",")) {
      const name = this.expectId();
      const typeAnnotation = this.readTypeAnnotation([",", "in"]);
      names.push({ name, typeAnnotation });
    }
    const firstTypeAnnotation = this.readTypeAnnotation([",", "in"]);
    if (firstTypeAnnotation) names[0].typeAnnotation = firstTypeAnnotation;
    this.expect("in");
    const it = this.exprListOrEmpty();
    this.expect("do");
    const body = this.parseBlock(new Set(["end", "<eof>"]));
    this.expect("end");
    return { type: "ForIn", names, it, body };
  }

  parseLabel() {
    this.expect("::");
    const name = this.expectId();
    this.expect("::");
    this.markUnsupported("labels");
    return { type: "Label", name };
  }

  parseTypeStatement() {
    const exported = Boolean(this.eat("export"));
    this.expect("type");
    const name = this.expectId();
    const generic = this.readGenericParameters();
    if (generic) this.markUnsupported("genericSyntax");
    this.expect("=");
    const start = this.i;
    let paren = 0;
    let brace = 0;
    let bracket = 0;
    let angle = 0;
    let previous = null;
    const statementStarters = new Set(["local", "function", "return", "if", "while", "repeat", "for", "do", "type", "export", "break", "continue"]);
    while (this.value() !== "<eof>") {
      const t = this.p();
      const v = t.value;
      const top = paren === 0 && brace === 0 && bracket === 0 && angle === 0;
      if (top && (v === ";" || statementStarters.has(v))) break;
      if (top && previous && t.line > previous.line &&
          (t.type === "id" || t.type === "keyword") &&
          !["=", "|", "&", "->", "<", ",", ":", "or", "and"].includes(previous.value)) break;
      if (v === "(" ) paren++;
      else if (v === ")" && paren > 0) paren--;
      else if (v === "{") brace++;
      else if (v === "}" && brace > 0) brace--;
      else if (v === "[") bracket++;
      else if (v === "]" && bracket > 0) bracket--;
      else if (v === "<") angle++;
      else if (v === ">" && angle > 0) angle--;
      previous = t;
      this.i++;
    }
    this.markUnsupported("typeSyntax");
    return { type: exported ? "ExportType" : "Type", name, tokenStart: start, tokenEnd: this.i };
  }

  functionBody(extraParams = []) {
    this.expect("(");
    const params = [];
    let vararg = false;

    if (!this.eat(")")) {
      while (true) {
        // Malformed parameter lists must terminate at EOF. Without this guard,
        // expectId() advanced beyond the EOF token while this loop ran forever.
        if (this.value() === "<eof>") {
          this.errorAt(this.p(), "Unterminated function parameter list");
          break;
        }
        if (this.eat("...")) {
          vararg = true;
          this.expect(")");
          break;
        }

        const name = this.expectId();
        const annotation = this.readTypeAnnotation();
        if (annotation) this.markUnsupported("typeSyntax");
        params.push(name);

        if (this.eat(")")) break;
        this.expect(",");
      }
    }

    const returnType = this.readFunctionReturnType();
    if (returnType) this.markUnsupported("typeSyntax");

    const body = this.parseBlock(new Set(["end", "<eof>"]));
    this.expect("end");

    return {
      type: "FunctionExpr",
      params: [...extraParams, ...params],
      vararg,
      body,
      returnType
    };
  }

  moreLhs() {
    const vars = [];
    while (this.eat(",")) vars.push(this.prefixExpression());
    return vars;
  }

  exprListOrEmpty() {
    if (TERMINATORS.has(this.value()) || [";", "}", ")", "]", ","].includes(this.value())) {
      this.errorAt(this.p(), "Expected expression");
      return [];
    }
    const first = this.expression();
    if (!first) {
      this.errorAt(this.p(), "Expected expression");
      if (!TERMINATORS.has(this.value()) && ![";", "}", ")", "]", ","].includes(this.value())) this.i++;
      return [];
    }
    const values = [first];
    while (this.eat(",")) {
      const value = this.expression();
      if (!value) {
        this.errorAt(this.p(), "Expected expression after ','");
        if (!TERMINATORS.has(this.value()) && ![";", "}", ")", "]", ","].includes(this.value())) this.i++;
        break;
      }
      values.push(value);
    }
    return values;
  }

  expression() { return this.binary(0); }

  binary(min) {
    let left = this.unary();
    if (!left) return null;

    while (true) {
      if (this.eat("::")) {
        this.readTypeAssertion();
        continue;
      }
      const op = this.value();
      if (!(op in BIN_PREC)) break;
      const prec = BIN_PREC[op];
      if (prec < min) break;
      this.i++;
      const right = this.binary(RIGHT_ASSOC.has(op) ? prec : prec + 1);
      if (!right) this.errorAt(this.p(), `Expected expression after operator ${op}`);
      left = { type: "Binary", op, left, right };
    }
    return left;
  }

  unary() {
    const t = this.p();
    if ((t.type === "op" || t.type === "keyword") && UNARY.has(t.value)) {
      const op = this.t[this.i++].value;
      // In Lua, exponentiation binds more tightly than unary operators:
      // -2^2 is -(2^2), while 2^-3 remains valid. Parse the unary operand
      // at exponent precedence so the Pratt loop consumes the power first.
      const arg = this.binary(BIN_PREC["^"]);
      if (!arg) this.errorAt(this.p(), `Expected expression after unary operator ${op}`);
      return { type: "Unary", op, arg };
    }

    if (this.value() === "if") {
      this.markUnsupported("ifExpression");
      this.i++;
      const cond = this.expression();
      this.expect("then");
      const consequent = this.expression();
      // Luau allows `if ... then ... elseif ... then ... else ...`. The VM already lowers a
      // two-arm IfElseExpression into JZ+JMP, so a chain becomes nested two-arm nodes rather
      // than a new node shape the printers and IR builder would have to learn.
      if (this.value() === "elseif") {
        const arms = [{ cond, consequent }];
        while (this.eat("elseif")) {
          const armCond = this.expression();
          this.expect("then");
          arms.push({ cond: armCond, consequent: this.expression() });
        }
        this.expect("else");
        let alternate = this.expression();
        for (let k = arms.length - 1; k >= 0; k--) {
          alternate = { type: "IfElseExpression", cond: arms[k].cond, consequent: arms[k].consequent, alternate };
        }
        return alternate;
      }
      this.expect("else");
      const alternate = this.expression();
      return { type: "IfElseExpression", cond, consequent, alternate };
    }

    if (t.type === "number") { this.i++; return { type: "Number", value: t.value, raw: t.raw || String(t.value) }; }
    if (t.type === "string") { this.i++; return { type: "String", value: t.value }; }
    if (t.type === "interpolated") {
      this.i++;
      return this.parseInterpolatedString(t.value, t);
    }
    if (this.eat("true")) return { type: "Boolean", value: true };
    if (this.eat("false")) return { type: "Boolean", value: false };
    if (this.eat("nil")) return { type: "Nil" };
    if (this.eat("...")) return { type: "Vararg" };
    if (this.eat("function")) {
      const generic = this.readGenericParameters();
      if (generic) this.markUnsupported("genericSyntax");
      return this.functionBody();
    }
    if (this.value() === "{") return this.tableConstructor();
    return this.prefixExpression();
  }

  parseInterpolatedString(raw, token) {
    const body = String(raw).startsWith('`') && String(raw).endsWith('`')
      ? String(raw).slice(1, -1)
      : String(raw).replace(/^`/, '');
    const parts = [];
    let textStart = 0;
    let i = 0;
    const pushText = (chunk) => {
      if (chunk.length) parts.push({ type: "String", value: decodeInterpolatedChunk(chunk) });
    };

    while (i < body.length) {
      if (body[i] === '\\') { i = skipInterpolatedEscape(body, i); continue; }
      if (body[i] === '{') {
        if (body[i + 1] === '{') {
          this.errorAt(token, "Luau interpolation does not accept '{{'; escape a literal brace with '\\{'");
          return { type: "String", value: body };
        }
        pushText(body.slice(textStart, i));
        const close = findInterpolationClose(body, i + 1);
        if (close < 0) {
          this.errorAt(token, "Unterminated Luau interpolation expression");
          return { type: "String", value: body };
        }
        const expressionSource = body.slice(i + 1, close).trim();
        if (!expressionSource) {
          this.errorAt(token, "Empty Luau interpolation expression");
          return { type: "String", value: body };
        }
        const nestedLexed = lex(`return (${expressionSource})`);
        const nested = new Parser(nestedLexed.tokens);
        const nestedAst = nested.parse();
        if (nestedLexed.errors.length || nested.errors.length || nestedAst.body.length !== 1 || nestedAst.body[0]?.type !== "Return" || nestedAst.body[0]?.values?.length !== 1) {
          const detail = nestedLexed.errors[0]?.message || nested.errors[0]?.message || "expected one expression";
          this.errorAt(token, `Invalid Luau interpolation expression: ${detail}`);
          return { type: "String", value: body };
        }
        const value = nestedAst.body[0].values[0];
        parts.push({ type: "Call", callee: { type: "Id", name: "tostring" }, args: [value] });
        i = close + 1;
        textStart = i;
        continue;
      }
      if (body[i] === '}') {
        this.errorAt(token, "Unexpected '}' in Luau interpolation text; escape a literal brace with '\\}'");
        return { type: "String", value: body };
      }
      i++;
    }
    pushText(body.slice(textStart));
    if (!parts.length) return { type: "String", value: "" };
    let result = parts[0];
    for (let index = 1; index < parts.length; index++) {
      result = { type: "Binary", op: "..", left: result, right: parts[index] };
    }
    return result;
  }

  tableConstructor() {
    this.expect("{");
    const fields = [];
    let arrayIndex = 1;

    while (this.value() !== "}" && this.value() !== "<eof>") {
      if (this.eat("[")) {
        const key = this.expression();
        this.expect("]");
        this.expect("=");
        const value = this.expression();
        fields.push({ key, value, explicit: true });
      } else if ((this.p().type === "id" || this.p().type === "keyword") && this.value(1) === "=") {
        const keyName = this.expectId();
        this.expect("=");
        fields.push({ key: { type: "String", value: keyName }, value: this.expression(), explicit: true });
      } else {
        fields.push({ key: { type: "Number", value: arrayIndex++ }, value: this.expression(), explicit: false });
      }

      if (!this.eat(",") && !this.eat(";")) break;
      while (this.eat(",") || this.eat(";")) {}
    }

    this.expect("}");
    return { type: "Table", fields };
  }

  prefixExpression() {
    let e;
    const t = this.p();

    if (t.type === "id" || t.type === "keyword") {
      if (["end", "else", "elseif", "until", "then", "do", "in", "local", "return", "function", "for", "while", "repeat", "if", "break", "continue"].includes(t.value)) {
        return null;
      }
      this.i++;
      e = { type: "Id", name: t.value };
    } else if (this.eat("(")) {
      e = this.expression();
      if (!e) this.errorAt(this.p(), "Expected expression after '('");
      this.expect(")");
      // Lua's parenthesized expression form adjusts a function call to one
      // result. Retain that semantic fact in the AST instead of erasing it.
      if (e && typeof e === "object") e.singleResult = true;
    } else {
      return null;
    }

    while (true) {
      if (this.eat(".")) {

        e = { type: "Index", obj: e, key: { type: "String", value: this.expectId() } };
        continue;
      }

      if (this.eat("[")) {
        const key = this.expression();
        this.expect("]");
        e = { type: "Index", obj: e, key };
        continue;
      }

      if (this.eat(":")) {
        const method = this.expectId();
        const args = this.callArgs();
        e = {
          type: "Call",
          callee: { type: "Index", obj: e, key: { type: "String", value: method } },
          args,
          method: true
        };
        continue;
      }

      if (this.value() === "(") {
        e = { type: "Call", callee: e, args: this.callArgs() };
        continue;
      }

      // Lua/Luau permit call sugar without parentheses: f "text" and
      // f { key = value }. Method calls use the same argument forms, e.g.
      // object:Method "text" or object:Method { key = value }.
      if (this.p().type === "string") {
        const arg = this.unary();
        e = { type: "Call", callee: e, args: [arg] };
        continue;
      }
      if (this.value() === "{") {
        e = { type: "Call", callee: e, args: [this.tableConstructor()] };
        continue;
      }

      break;
    }

    if (e && typeof e === "object") {
      if (!Object.prototype.hasOwnProperty.call(e, "__line")) Object.defineProperty(e, "__line", { value: Number(t.line) || 0, enumerable: false, configurable: true });
      if (!Object.prototype.hasOwnProperty.call(e, "__col")) Object.defineProperty(e, "__col", { value: Number(t.col) || 0, enumerable: false, configurable: true });
    }
    return e;
  }

  callArgs() {
    if (this.eat("(")) {
      if (this.eat(")")) return [];
      const args = this.exprListOrEmpty();
      this.expect(")");
      return args;
    }
    if (this.value() === "{") return [this.tableConstructor()];
    if (this.p().type === "string") return [this.unary()];
    this.errorAt(this.p(), "Expected function-call arguments");
    return [];
  }

  expectId() {
    const t = this.p();
    if (t.type !== "id" && t.type !== "keyword") {
      this.errors.push({ message: `Expected identifier`, line: t.line, col: t.col });
      this.i++;
      return "_error";
    }
    this.i++;
    return t.value;
  }

  readTypeAssertion() {
    this.features.typeSyntax = true;
    let paren = 0, brace = 0, bracket = 0, angle = 0;
    let previous = null;
    const statementStarters = new Set(["local", "function", "return", "if", "while", "repeat", "for", "do", "break", "continue", "end", "type", "export"]);
    while (this.value() !== "<eof>") {
      const t = this.p();
      const v = t.value;
      const top = paren === 0 && brace === 0 && bracket === 0 && angle === 0;
      if (top && ([",", ";", "=", ")", "]", "}"].includes(v) || (v in BIN_PREC && !["|", "&", "or", "and", "<", ">"].includes(v)))) break;
      if (top && previous && t.line > previous.line && statementStarters.has(v)) break;
      if (v === "(") paren++;
      else if (v === ")" && paren > 0) paren--;
      else if (v === "{") brace++;
      else if (v === "}" && brace > 0) brace--;
      else if (v === "[") bracket++;
      else if (v === "]" && bracket > 0) bracket--;
      else if (v === "<") angle++;
      else if (v === ">" && angle > 0) angle--;
      previous = t;
      this.i++;
    }
  }

  readTypeAnnotation(extraStops = []) {
    if (!this.eat(":")) return null;
    this.features.typeSyntax = true;
    const start = this.i;
    let paren = 0;
    let brace = 0;
    let bracket = 0;
    let angle = 0;
    const stops = new Set([",", "=", "->", ...extraStops]);

    while (this.value() !== "<eof>") {
      const v = this.value();
      const top = paren === 0 && brace === 0 && bracket === 0 && angle === 0;
      if (top && stops.has(v)) break;
      if (v === ")" && paren === 0 || v === "}" && brace === 0 || v === "]" && bracket === 0) break;
      if (top && v === ">" && extraStops.includes(">")) break;

      if (v === "(") paren++;
      else if (v === ")" && paren > 0) paren--;
      else if (v === "{") brace++;
      else if (v === "}" && brace > 0) brace--;
      else if (v === "[") bracket++;
      else if (v === "]" && bracket > 0) bracket--;
      else if (v === "<") angle++;
      else if (v === ">" && angle > 0) angle--;
      this.i++;
    }
    return this.t.slice(start, this.i).map((x) => x.value).join(" ");
  }

  readFunctionReturnType() {
    if (!this.eat(":")) return null;
    this.features.typeSyntax = true;
    const start = this.i;
    let paren = 0;
    let brace = 0;
    let bracket = 0;
    let angle = 0;
    const bodyStarters = new Set(["local", "return", "if", "while", "repeat", "for", "do", "function", "break", "continue", "goto", "end", "type", "export"]);
    let previous = null;

    while (this.value() !== "<eof>") {
      const t = this.p();
      const v = t.value;
      const top = paren === 0 && brace === 0 && bracket === 0 && angle === 0;
      if (top && (bodyStarters.has(v) || v === "=" || v === ";")) break;
      // A later-line identifier may start a body statement (for example,
      // a typed function followed by `work()`); adjacent bare identifiers
      // are not a valid type expression without a joining operator.
      if (top && previous && t.line > previous.line &&
          (t.type === "id" || t.type === "keyword") &&
          previous.type === "id" && !["|", "&", "->", "<", ",", ":"].includes(previous.value)) break;
      if (v === ")" && paren === 0 || v === "}" && brace === 0 || v === "]" && bracket === 0) break;

      if (v === "(") paren++;
      else if (v === ")" && paren > 0) paren--;
      else if (v === "{") brace++;
      else if (v === "}" && brace > 0) brace--;
      else if (v === "[") bracket++;
      else if (v === "]" && bracket > 0) bracket--;
      else if (v === "<") angle++;
      else if (v === ">" && angle > 0) angle--;
      previous = t;
      this.i++;
    }
    return this.t.slice(start, this.i).map((x) => x.value).join(" ");
  }

  readAttribute() {
    if (this.value() !== "<") return null;
    const start = this.i;
    this.i++;
    const name = this.expectId();
    this.expect(">" );
    this.features.attributes = true;
    return this.t.slice(start, this.i).map((x) => x.value).join("");
  }

  readGenericParameters() {
    if (this.value() !== "<") return null;
    const start = this.i;
    let depth = 0;
    while (this.value() !== "<eof>") {
      const v = this.value();
      if (v === "<") depth++;
      else if (v === ">") { depth--; if (depth === 0) { this.i++; break; } }
      this.i++;
    }
    return this.t.slice(start, this.i).map((x) => x.value).join("");
  }

  errorAt(token, message) {
    this.errors.push({ message, line: token?.line ?? 0, col: token?.col ?? 0 });
  }
}

function parseDetailed(sourceOrTokens) {
  let tokens;
  let lexerErrors = [];
  if (Array.isArray(sourceOrTokens)) {
    tokens = sourceOrTokens;
  } else {
    const lexed = lex(sourceOrTokens);
    tokens = lexed.tokens;
    lexerErrors = Array.isArray(lexed.errors) ? lexed.errors.slice() : [];
  }

  const parser = new Parser(tokens);
  const ast = parser.parse();
  const parserErrors = parser.errors.slice();
  return {
    ast,
    tokens,
    errors: [...lexerErrors, ...parserErrors],
    lexerErrors,
    parserErrors,
    features: { ...parser.features }
  };
}

// Keep the historical AST-only API intact. Callers that need diagnostics can
// use parseDetailed() without constructing Lexer and Parser separately.
function parse(sourceOrTokens) {
  return parseDetailed(sourceOrTokens).ast;
}

module.exports = { Parser, parse, parseDetailed };

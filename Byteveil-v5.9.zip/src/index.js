const { obfuscate, obfuscateFile, normalizeOptions } = require('./core/pipeline');
const { engineConfig, loadEnv } = require('./core/env');
const { PRESETS, getPreset } = require('./presets');
const { detect } = require('./detect');
const macros = require('./macros');
const lph = require('./lph');
const lps = require('./lps');

loadEnv();

module.exports = {
  obfuscate,
  obfuscateFile,
  normalizeOptions,
  engineConfig,
  loadEnv,
  PRESETS,
  getPreset,
  detect,
  macros,
  lph,
  lps
};

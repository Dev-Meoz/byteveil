"use strict";
// Compatibility facade: legacy imports are retained for API stability, but the
// actual opcode/ISA planning now comes from the unified v4.5.5 ISA engine.
const { buildISAPlan, deriveStatePermutation } = require("../obfuscation/isa_engine");
function rng(seed){
  let s=(Number(seed)>>>0)||0xA341316C;
  return()=>{s^=s>>>16;s=Math.imul(s,2246822519)>>>0;s^=s>>>13;s=Math.imul(s,3266489917)>>>0;s^=s>>>16;return s>>>0;};
}
function shuffle(values,next){const out=values.slice();for(let i=out.length-1;i>0;i--){const j=next()%(i+1);[out[i],out[j]]=[out[j],out[i]];}return out;}
function createContext(seed,opcodeNames){
  const plan=buildISAPlan(opcodeNames,seed,{lanes:4});
  return {
    version:"ByteVeil-ISA-compat-v4.5.5",
    seed:Number(seed)>>>0,
    primaryXorKey:plan.handlerSalt&0xff,
    instructionXorKeys:plan.operandVariant.slice(0,3).map(v=>v&0xff),
    opcodeMap:{encode:{...plan.encode},decode:{...plan.decode},order:plan.order.slice(),lanes:plan.lanes},
    layout:{chunkSteps:shuffle(["parameterCount","constants","instructions","functions","lineInfo"],rng(seed)),instructionSteps1:shuffle(["type","A","B","C"],rng(seed^1)),instructionSteps2:shuffle(["op","Bx","D"],rng(seed^2)),constantTypes:shuffle(["nil","boolean","number","string"],rng(seed^3))},
    statePermutation:deriveStatePermutation(seed,12),
    opaqueBranchCount:Math.min(1024,Math.max(48,opcodeNames.length*7)),
    mutations:Math.min(1600,Math.max(64,Math.floor(opcodeNames.length*8))),
    handlerBuckets:Math.min(12,Math.max(4,Math.ceil(Math.sqrt(Math.max(1,opcodeNames.length))))),
    superOperators:{miniMax:420,megaMax:620,minMini:2,minMega:4}
  };
}
function remapChunk(chunk,encode){if(!chunk||typeof chunk!=="object")return;const oldDecode=chunk.map?.decode||{};for(const ins of chunk.code||[]){if(!Array.isArray(ins)||!ins.length)continue;const name=oldDecode[ins[0]];if(name&&encode[name]!==undefined)ins[0]=encode[name];}chunk.map={encode:{...encode},decode:Object.fromEntries(Object.entries(encode).map(([name,code])=>[code,name]))};for(const value of chunk.consts||[])if(value?.__chunk)remapChunk(value.__chunk,encode);}
function remapBytecodeOpcodes(bytecode,context){if(!bytecode||!bytecode.map||!context?.opcodeMap)return bytecode;remapChunk(bytecode,context.opcodeMap.encode);bytecode.map={encode:{...context.opcodeMap.encode},decode:{...context.opcodeMap.decode}};bytecode.ironbrew=context;return bytecode;}
module.exports={rng,shuffle,createContext,remapBytecodeOpcodes};

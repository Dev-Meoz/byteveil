"use strict";
const BARRIER=new Set(["JMP","JZ","RETURN","CALLP","TAILCALL","HALT","BREAK","CALL","MAKEFUNC","ITERLOOP"]);
function planSuperOperators(bytecode,seed,options={}){
  const maxMini=Math.max(0,Number(options.maxMini??300)),maxMega=Math.max(0,Number(options.maxMega??400));
  let s=(Number(seed)>>>0)||1;const next=()=>{s=(Math.imul(s^(s>>>16),2246822519)+3266489917)>>>0;return s;};
  const candidates=[];
  function walk(chunk,path="root"){
    const code=chunk?.code||[];let i=0;
    while(i<code.length){const start=i,names=[];while(i<code.length&&names.length<12){const name=chunk?.map?.decode?.[code[i]?.[0]]||null;if(!name||BARRIER.has(name))break;names.push(name);i++;}if(names.length>=2)candidates.push({path,start,length:names.length,ops:names.slice(),key:next()});i=Math.max(i,start+1);}
    for(let j=0;j<(chunk?.consts||[]).length;j++){const v=chunk.consts[j];if(v?.__chunk)walk(v.__chunk,`${path}.k${j}`);}
  }
  walk(bytecode);for(let i=candidates.length-1;i>0;i--){const j=next()%(i+1);[candidates[i],candidates[j]]=[candidates[j],candidates[i]];}
  const mega=candidates.filter(x=>x.length>=5).slice(0,maxMega),megaPaths=new Set(mega.map(x=>`${x.path}:${x.start}`));
  const mini=candidates.filter(x=>!megaPaths.has(`${x.path}:${x.start}`)&&x.length>=2).slice(0,maxMini);
  return {mini,mega,planned:mini.length+mega.length,dispatchNoise:next()%65536};
}
module.exports={planSuperOperators};

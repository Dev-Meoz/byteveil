"use strict";

const { isFloatOperand, isFloatText } = require("../compiler/number_operand");

const ARITY = Object.freeze({
  register: Object.freeze({ HALT:0, PUSHK:2, PUSHN:2, PUSHB:2, PUSHNIL:1, GETG:2, SETG:2, GETL:2, SETL:2, GETI:3, SETI:3, ADD:3, SUB:3, MUL:3, DIV:3, IDIV:3, MOD:3, POW:3, EQ:3, NE:3, LT:3, GT:3, LE:3, GE:3, NOT:2, NEG:2, LEN:2, CONCAT:3, JMP:1, JZ:2, CALL:null, RETURN:null, POP:1, DUP:2, NEWTABLE:2, SETFIELD:3, GETFIELD:3, MAKEFUNC:2, VARARG:1, CALLG:null, CALLGM:null, CALLV:null, CALLGV:null, RETURNV:null, VARARGS:1, BREAK:0, MOVE_SELF:2, FORCMP:3, ITERPREP:1, ITERLOOP:null, CALLM:2, BNOT:2, SWAP:2, CALLP:null, APPEND:3 }),
  stack: Object.freeze({ HALT:0, PUSHK:1, PUSHN:1, PUSHB:1, PUSHNIL:0, GETG:1, SETG:1, GETL:1, SETL:1, GETI:0, SETI:0, ADD:0, SUB:0, MUL:0, DIV:0, IDIV:0, MOD:0, POW:0, EQ:0, NE:0, LT:0, GT:0, LE:0, GE:0, NOT:0, NEG:0, LEN:0, CONCAT:0, JMP:1, JZ:1, CALL:1, RETURN:1, POP:0, DUP:0, NEWTABLE:1, SETFIELD:3, GETFIELD:3, MAKEFUNC:1, VARARG:0, CALLG:2, CALLGM:3, CALLV:1, CALLGV:2, RETURNV:1, VARARGS:0, BREAK:0, MOVE_SELF:0, FORCMP:0, ITERPREP:1, ITERLOOP:null, CALLM:null, SUPER:null, BNOT:0, SWAP:0, CALLP:4, APPEND:1 })
});

const VALID = new Set([
  "HALT","PUSHK","PUSHN","PUSHB","PUSHNIL","GETG","SETG","GETL","SETL","GETI","SETI",
  "ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE",
  "NOT","NEG","LEN","CONCAT","JMP","JZ","CALL","RETURN","POP","DUP","NEWTABLE","SETFIELD","GETFIELD",
  "MAKEFUNC","VARARG","VARARGS","CALLG","CALLGM","CALLV","CALLGV","TAILCALL","RETURNV","CALLM","CALLP","APPEND","SUPER","AND","OR","BAND","BOR","BXOR","SHL","SHR","BNOT","BREAK","SWAP","MOVE_SELF","FORCMP","ITERPREP","ITERLOOP"
]);

function validateChunk(chunk, path, seen, mode = "register") {
  if (!chunk || typeof chunk !== "object") throw new Error(`invalid bytecode chunk at ${path}`);
  if (!Array.isArray(chunk.code) || !Array.isArray(chunk.consts)) throw new Error(`invalid chunk arrays at ${path}`);
  for (let i = 0; i < chunk.code.length; i++) {
    const ins = chunk.code[i];
    if (!Array.isArray(ins) || !Number.isInteger(ins[0])) throw new Error(`invalid instruction ${path}.c${i}`);
    const name = chunk.map?.decode?.[ins[0]];
    if (!name || !VALID.has(name)) throw new Error(`unknown virtual opcode ${ins[0]} at ${path}.c${i}`);
    const floatSlot = name === "PUSHN" ? (mode === "register" ? 2 : 1) : -1;
    for (let j = 1; j < ins.length; j++) {
      const operand = ins[j];
      // A float literal is the one operand that is not a number: it carries the source's decimal
      // text so Lua 5.4 keeps 5.0 apart from 5. Only the PUSHN value slot may hold it.
      if (j === floatSlot && isFloatOperand(operand)) {
        if (!isFloatText(operand.text)) throw new Error(`invalid float literal operand ${path}.c${i}.${j}: ${JSON.stringify(operand.text)}`);
        continue;
      }
      if (typeof operand !== "number" || !Number.isFinite(operand)) throw new Error(`invalid operand ${path}.c${i}.${j}`);
    }
    const expected = ARITY[mode]?.[name];
    if (name === "TAILCALL" && mode === "register") {
      const argc = Number(ins[3]);
      const prefixCount = Number(ins[4]);
      const hasVarargs = Number(ins[5]) === 1;
      const expectedOperands = 5 + (Number.isInteger(argc) && argc >= 0 ? argc : -100000) + (Number.isInteger(prefixCount) && prefixCount >= 0 ? prefixCount : -100000) + (hasVarargs ? 1 : 0);
      if (expectedOperands < 5 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for TAILCALL at ${path}.c${i}: got ${ins.length - 1}, expected ${expectedOperands}`);
    } else if (name === "TAILCALL" && mode === "stack") {
      if (ins.length - 1 !== 5) throw new Error(`invalid arity for TAILCALL at ${path}.c${i}: got ${ins.length - 1}, expected 5`);
    } else if ((name === "CALLV" || name === "CALLGV") && mode === "register") {
      const prefixCount = Number(ins[3]);
      const expectedOperands = 4 + (Number.isInteger(prefixCount) && prefixCount >= 0 ? prefixCount : -1);
      if (expectedOperands < 4 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for ${name} at ${path}.c${i}`);
    } else if (name === "RETURN" && mode === "register") {
      // Register RETURN states how many result registers follow; the runtime never
      // infers it from the instruction length because short instructions can be
      // materialised with padded operand slots.
      const count = ins[1];
      if (!Number.isInteger(count) || count < 0 || ins.length - 1 !== 1 + count) throw new Error(`invalid arity for RETURN at ${path}.c${i}: got ${ins.length - 1}, expected ${1 + (Number.isInteger(count) && count >= 0 ? count : 0)}`);
    } else if (name === "RETURNV" && mode === "register") {
      const prefixCount = ins[1];
      const expectedOperands = 2 + (Number.isInteger(prefixCount) && prefixCount >= 0 ? prefixCount : -1);
      if (expectedOperands < 2 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for RETURNV at ${path}.c${i}`);
    } else if (name === "CALLG" && mode === "register") {
      const argc = ins[3];
      const expectedOperands = 3 + (Number.isInteger(argc) && argc >= 0 ? argc : -1);
      if (expectedOperands < 3 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for CALLG at ${path}.c${i}`);
    } else if (name === "CALLGM" && mode === "register") {
      const argc = ins[3];
      const expectedOperands = 4 + (Number.isInteger(argc) && argc >= 0 ? argc : -1);
      if (expectedOperands < 4 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for CALLGM at ${path}.c${i}`);
    } else if (name === "CALLV" && mode === "stack") {
      if (ins.length - 1 !== 1) throw new Error(`invalid arity for CALLV at ${path}.c${i}`);
    } else if (name === "CALLGV" && mode === "stack") {
      if (ins.length - 1 !== 2) throw new Error(`invalid arity for CALLGV at ${path}.c${i}`);
    } else if (name === "RETURNV" && mode === "stack") {
      if (ins.length - 1 !== 1) throw new Error(`invalid arity for RETURNV at ${path}.c${i}`);
    } else if (name === "CALLG" && mode === "stack") {
      if (ins.length - 1 !== 2) throw new Error(`invalid arity for CALLG at ${path}.c${i}`);
    } else if (name === "CALLGM" && mode === "stack") {
      if (ins.length - 1 !== 3) throw new Error(`invalid arity for CALLGM at ${path}.c${i}`);
    } else if (name === "CALLM" && mode === "register") {
      const argc = ins[3];
      const expectedOperands = 4 + (Number.isInteger(argc) && argc >= 0 ? argc : -1);
      if (expectedOperands < 4 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for CALLM at ${path}.c${i}: got ${ins.length - 1}, expected ${expectedOperands}`);
    } else if (name === "SUPER") {
      // v4.2 SUPER layout: [opcode, specializationId, count, len, child..., ...]
      const id = ins[1];
      const count = ins[2];
      if (!Number.isInteger(id) || id < 1) throw new Error(`invalid SUPER specialization id at ${path}.c${i}`);
      if (!Number.isInteger(count) || count < 2 || count > 8) throw new Error(`invalid SUPER count at ${path}.c${i}`);
      let p = 3;
      for (let n = 0; n < count; n++) {
        const len = ins[p++];
        if (!Number.isInteger(len) || len < 1 || p + len > ins.length) throw new Error(`invalid SUPER body at ${path}.c${i}`);
        for (let j = 0; j < len; j++) {
          if (typeof ins[p + j] !== "number" || !Number.isFinite(ins[p + j])) throw new Error(`invalid SUPER operand at ${path}.c${i}`);
        }
        p += len;
      }
      if (p !== ins.length) throw new Error(`invalid SUPER payload length at ${path}.c${i}`);
    } else if (name === "ITERPREP" && mode === "register") {
      const nameCount = ins[2];
      const expectedOperands = 2 + (Number.isInteger(nameCount) && nameCount >= 0 ? nameCount : -1);
      if (expectedOperands < 2 || ins.length - 1 !== expectedOperands) throw new Error(`invalid arity for ITERPREP at ${path}.c${i}: got ${ins.length - 1}, expected ${expectedOperands}`);
    } else if (name === "CALLP" && mode === "register") {
      // [opcode, DEST, GLOBAL_FLAG, FUNCTION_OR_K, ARGC, VARARG_FLAG, REGS..., PACK?]
      const argc = ins[4];
      const hasVarargs = ins[5] === 1;
      if (!Number.isInteger(argc) || argc < 0) throw new Error(`invalid arity for CALLP at ${path}.c${i}`);
      if (ins.length - 1 !== 5 + argc + (hasVarargs ? 1 : 0)) throw new Error(`invalid arity for CALLP at ${path}.c${i}: got ${ins.length - 1}, expected ${5 + argc + (hasVarargs ? 1 : 0)}`);
    } else if (expected !== null && expected !== undefined && ins.length - 1 !== expected) {
      throw new Error(`invalid arity for ${name} at ${path}.c${i}: got ${ins.length - 1}, expected ${expected}`);
    }
    if (name === "JMP" && (!Number.isInteger(ins[1]) || ins[1] < 0 || ins[1] > chunk.code.length)) throw new Error(`invalid jump ${path}.c${i}`);
    if (name === "JZ") {
      const jumpOperandIndex = mode === "register" ? 2 : 1;
      if (!Number.isInteger(ins[jumpOperandIndex]) || ins[jumpOperandIndex] < 0 || ins[jumpOperandIndex] > chunk.code.length) {
        throw new Error(`invalid jump ${path}.c${i}`);
      }
    }
  }
  for (let i = 0; i < chunk.consts.length; i++) {
    const v = chunk.consts[i];
    if (v?.__chunk) validateChunk(v.__chunk, `${path}.k${i}`, seen, v.__chunk.mode || mode);
    else if (!(v === null || typeof v === "string" || typeof v === "number" || typeof v === "boolean")) throw new Error(`unsupported constant ${path}.k${i}`);
  }
  seen.add(chunk);
}

function validateStackPrefix(chunk, path) {
  const binary = new Set(["ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE","CONCAT","AND","OR","BAND","BOR","BXOR","SHL","SHR"]);
  // NOT/NEG/LEN/BNOT rewrite the top stack slot in place; they require one
  // operand but have zero net stack effect. POP/JZ/SETG/SETL consume a slot.
  const unaryInPlace = new Set(["NOT","NEG","LEN","BNOT"]);
  const consume = new Set(["POP","JZ","SETG","SETL"]);
  const push = new Set(["PUSHK","PUSHN","PUSHB","PUSHNIL","GETG","GETL","NEWTABLE","VARARG","MAKEFUNC","DUP","MOVE_SELF"]);
  let depth = 0;
  for (let i = 0; i < (chunk.code || []).length; i++) {
    const ins = chunk.code[i];
    const name = chunk.map?.decode?.[ins?.[0]];
    if (!name) return;
    if (["JMP","JZ","CALL","CALLG","CALLGM","CALLM","CALLP","APPEND","TAILCALL","RETURN","HALT","BREAK","ITERPREP","ITERLOOP","SUPER","GETI","SETI","SETFIELD","GETFIELD","FORCMP"].includes(name)) break;
    const required = binary.has(name) ? 2 : (unaryInPlace.has(name) || consume.has(name)) ? 1 : 0;
    if (depth < required) throw new Error(`invalid stack depth before ${name} at ${path}.c${i}: need ${required}, have ${depth}`);
    if (push.has(name)) depth++;
    else if (binary.has(name) || consume.has(name)) depth--;
    // In-place unary instructions leave the stack depth unchanged.
    if (depth < 0) throw new Error(`invalid negative stack depth at ${path}.c${i}`);
  }
}

function validateBytecode(bytecode) {
  const mode = bytecode.mode === "stack" ? "stack" : "register";
  validateChunk(bytecode, "root", new Set(), mode);
  if (mode === "stack") {
    const walk = (chunk, path = "root") => {
      validateStackPrefix(chunk, path);
      for (let i = 0; i < (chunk.consts || []).length; i++) {
        const v = chunk.consts[i];
        if (v?.__chunk) walk(v.__chunk, `${path}.k${i}`);
      }
    };
    walk(bytecode);
  }
  return { ok: true, chunks: countChunks(bytecode), instructions: countInstructions(bytecode) };
}
function countChunks(c){return 1+(c.consts||[]).filter(x=>x?.__chunk).reduce((n,x)=>n+countChunks(x.__chunk),0)}
function countInstructions(c){return (c.code||[]).length+(c.consts||[]).filter(x=>x?.__chunk).reduce((n,x)=>n+countInstructions(x.__chunk),0)}

module.exports = { validateBytecode };

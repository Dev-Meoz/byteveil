"use strict";

const actions = require("../protection/directive_actions");

const { ENGINE_VERSION: VERSION } = require("../core/version");
const DIRECTIVES = Object.freeze([
  "byteveil-obfuscated", "byteveil-line", "byteveil-crash", "byteveil-no-virtualization",
  "byteveil-enc-func", "byteveil-pre-check", "byteveil-rewrite", "byteveil-encstr",
  "byteveil-cff", "byteveil-index-to-num"
]);
const DIRECTIVE_SET = new Set(DIRECTIVES);
const LPH_ALIASES = Object.freeze({
  LPH_OBFUSCATED: "byteveil-obfuscated",
  LPH_JIT: "byteveil-cff",
  LPH_JIT_MAX: "byteveil-obfuscated",
  LPH_JIT_ULTRA: "byteveil-obfuscated",
  LPH_NO_UPVALUES: "byteveil-enc-func",
  LPH_ENCNUM: "byteveil-rewrite",
  LPH_ENC_NUM: "byteveil-rewrite",
  LPH_LINE: "byteveil-line",
  LPH_CRASH: "byteveil-crash",
  LPH_NO_VIRTUALIZE: "byteveil-no-virtualization",
  LPH_NO_VIRTUALIZATION: "byteveil-no-virtualization",
  LPH_ENCFUNC: "byteveil-enc-func",
  LPH_ENC_FUNC: "byteveil-enc-func",
  LPH_ENCSTR: "byteveil-encstr",
  LPH_ENC_STR: "byteveil-encstr",
  LPH_CFF: "byteveil-cff",
  LPH_INDEX_TO_NUM: "byteveil-index-to-num",
  LPH_PRE_CHECK: "byteveil-pre-check",
  LPH_PRECHECK: "byteveil-pre-check",
  LPH_REWRITE: "byteveil-rewrite"
});
const EFFECTS = Object.freeze({
  "byteveil-obfuscated": "obfuscated", "byteveil-line": "line", "byteveil-crash": "crash",
  "byteveil-no-virtualization": "noVirtualization", "byteveil-enc-func": "encFunc",
  "byteveil-pre-check": "preCheck", "byteveil-rewrite": "rewrite", "byteveil-encstr": "encStr",
  "byteveil-cff": "cff", "byteveil-index-to-num": "indexToNum"
});

function parseArgs(raw) {
  if (!raw) return [];
  const text = String(raw);
  const out = [];
  let item = "", quote = "", escaped = false;
  for (const ch of text) {
    if (escaped) { item += ch; escaped = false; continue; }
    if (ch === "\\") { item += ch; escaped = true; continue; }
    if (quote) { item += ch; if (ch === quote) quote = ""; continue; }
    if (ch === "'" || ch === '"') { item += ch; quote = ch; continue; }
    if (ch === ",") { if (item.trim()) out.push(cleanArg(item)); item = ""; continue; }
    item += ch;
  }
  if (item.trim()) out.push(cleanArg(item));
  return out;
}

function cleanArg(value) {
  return String(value).trim().replace(/^(['"])(.*)\1$/s, "$2");
}

function scan(source) {
  const lines = String(source || "").split(/\r?\n/);
  const directives = [];
  const re = /^\s*--\s*(?:@\s*)?([A-Za-z_][A-Za-z0-9_-]*)(?:\s*\(([^)]*)\))?\s*$/;
  for (let i = 0; i < lines.length; i++) {
    const match = re.exec(lines[i]);
    if (!match) continue;
    const rawName = match[1];
    const normalized = rawName.toLowerCase();
    // Keep LPH's compatibility surface independent from native ByteVeil
    // directives. A `-- byteveil-encstr` line belongs only to Macro Engine.
    if (!normalized.startsWith("lph_")) continue;
    const name = LPH_ALIASES[rawName.toUpperCase()];
    if (!name || !DIRECTIVE_SET.has(name)) continue;
    directives.push({ name, alias: normalized.startsWith("lph_") ? rawName.toUpperCase() : null, args: parseArgs(match[2]), line: i + 1, scope: "next-statement", sourceKind: "comment", raw: lines[i] });
  }
  return directives;
}

function canonicalCallName(name) {
  const upper = String(name || "").toUpperCase();
  return LPH_ALIASES[upper] || null;
}

function findCallSites(ast) {
  const calls = [];
  actions.walk(ast, (node, parent, key) => {
    if (node.type !== "Call" || node.callee?.type !== "Id") return;
    const normalized = String(node.callee.name || "").toUpperCase();
    const canonical = canonicalCallName(normalized);
    if (!canonical || !parent) return;
    calls.push({ name: canonical, alias: normalized, node, parent, key, args: node.args || [], sourceKind: "call", line: Number(node.__line) || 0, scope: "expression" });
  });
  // Inner wrappers must be expanded before the wrapper containing them.
  return calls.reverse();
}

function validate(directives) {
  const errors = [];
  for (const directive of directives || []) {
    if (directive.name === "byteveil-no-virtualization" && directive.args.includes("virtualization")) {
      errors.push("byteveil-no-virtualization cannot request virtualization in the same directive");
    }
  }
  return [...new Set(errors)];
}

function resolve(source, ast = null, options = {}) {
  const comments = scan(source);
  const callSites = ast && typeof ast === "object" ? findCallSites(ast) : [];
  const callDirectives = callSites.map(call => {
    const directive = { name: call.name, alias: call.alias, args: [], line: call.line, scope: call.scope, sourceKind: "call", status: "call-site" };
    call.directive = directive;
    return directive;
  });
  const directives = [...comments, ...callDirectives];
  const errors = validate(comments);
  const effects = Object.create(null);
  for (const directive of directives) {
    const effect = EFFECTS[directive.name];
    if (effect) effects[effect] = { enabled: true, args: (directive.args || []).slice(), line: directive.line, scope: directive.scope };
  }
  const plan = {
    version: VERSION,
    engine: "ByteVeil LPH Compatibility Engine",
    directives,
    aliases: directives.filter(d => d.alias).map(d => ({ alias: d.alias, name: d.name })),
    effects,
    errors,
    resolved: errors.length === 0,
    enabled: options.enabled !== false,
    applied: false,
    commentDirectiveCount: comments.length,
    callDirectiveCount: callSites.length,
    effectiveDirectiveCount: 0
  };
  if (ast && typeof ast === "object") {
    const commentPlan = { ...plan, directives: comments };
    actions.annotate(ast, commentPlan);
    Object.defineProperty(plan, "_bindings", { value: commentPlan._bindings || [], enumerable: false, configurable: true });
    Object.defineProperty(plan, "_calls", { value: callSites, enumerable: false, configurable: true });
    Object.defineProperty(ast, "__byteVeilLPH", { value: plan, enumerable: false, configurable: true, writable: true });
  }
  return plan;
}

function lowerCallSites(ast, plan, options = {}) {
  let applied = 0;
  for (const callSite of plan._calls || []) {
    const { node, parent, key, name } = callSite;
    if (!parent || key == null || parent[key] !== node) continue;
    const args = Array.isArray(node.args) ? node.args : [];
    if (name === "byteveil-line") {
      if (args.length !== 0) {
        throw new Error(`ByteVeil LPH: ${callSite.alias} expects zero arguments (got ${args.length})`);
      }
      parent[key] = { type: "Number", value: Number(node.__line) || 0 };
      if (callSite.directive) callSite.directive.effectStatus = "lowered";
      applied++;
      continue;
    }
    if (args.length !== 1) {
      // A compatibility wrapper with wrong arity would otherwise survive into
      // runtime as an undefined global. Fail explicitly instead of emitting a
      // broken program that looks successfully obfuscated.
      throw new Error(`ByteVeil LPH: ${callSite.alias} expects exactly one argument (got ${args.length})`);
    }
    let replacement = args[0];
    if (name === "byteveil-no-virtualization") {
      // The current v4.6 backend virtualizes the complete chunk; a selective
      // non-VM island is not available yet. Lower to the wrapped expression to
      // preserve semantics, and expose the limitation in diagnostics metadata.
      actions.hidden(replacement, "__byteVeilNoVirtualizationHint", true);
      if (callSite.directive) callSite.directive.effectStatus = "limited-whole-chunk-vm";
    } else {
      replacement = actions.applyOne(replacement, callSite.directive || { name, args: [], line: callSite.line }, options);
      // Lowering the compatibility wrapper is real work, but it must not
      // overwrite an explicit limitation reported by the transform handler.
      if (callSite.directive && [undefined, "no-effective-transform", "pending-profile"].includes(callSite.directive.effectStatus)) {
        callSite.directive.effectStatus = "lowered";
      }
    }
    parent[key] = replacement;
    applied++;
  }
  return applied;
}

function apply(ast, plan, options = {}) {
  if (!plan || !plan.enabled || plan.errors?.length) return ast;
  const commentPlan = { ...plan, directives: plan.directives.filter(d => d.sourceKind !== "call") };
  Object.defineProperty(commentPlan, "_bindings", { value: plan._bindings || [], enumerable: false, configurable: true });
  actions.applyPlan(ast, commentPlan, options);
  const callsApplied = lowerCallSites(ast, plan, options);
  if (plan.callDirectiveCount) {
    const callDirectives = plan.directives.filter(d => d.sourceKind === "call");
    const extraSalt = actions.directiveSalt([{ engine: plan.engine, directives: callDirectives }]);
    actions.hidden(ast, "__byteVeilDirectiveSalt", ((Number(ast.__byteVeilDirectiveSalt) || 0) ^ extraSalt) >>> 0);
  }
  plan.applied = true;
  plan.effectiveDirectiveCount = (plan.directives || []).filter(d => d.effectStatus === "applied" || d.effectStatus === "backend-active" || d.effectStatus === "backend-shield-active" || d.effectStatus === "lowered").length;
  plan.warnings = (plan.directives || []).filter(d => d.effectStatus && !["applied", "backend-active", "backend-shield-active", "lowered"].includes(d.effectStatus)).map(d => `${d.alias || d.name}: ${d.effectStatus}`);
  plan.selectiveVirtualization = "not-supported-by-current-whole-chunk-vm";
  return ast;
}

module.exports = { VERSION, DIRECTIVES, LPH_ALIASES, EFFECTS, parseArgs, scan, canonicalCallName, findCallSites, validate, resolve, apply };

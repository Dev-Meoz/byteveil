"use strict";

const { ENGINE_VERSION: LPS_VERSION } = require("../core/version");
const DEFAULT_STEP_LIMIT = 100000;

class LPSError extends Error {
  constructor(message, pc = null) {
    super(pc == null ? `LPS: ${message}` : `LPS: ${message} at instruction ${pc}`);
    this.name = "LPSError";
    this.pc = pc;
  }
}

/**
 * Function registry for LPS and cooperating VM engines.
 * Entries are references, not generated wrapper functions. Native API aliases
 * therefore preserve identity and do not reimplement the target API.
 */
function createCallRegistry(initial = {}) {
  const table = new Map();
  const pathValue = (root, path) => {
    const parts = String(path).split(".").filter(Boolean);
    let value = root;
    for (const part of parts) {
      if (value == null) return undefined;
      value = value[part];
    }
    return value;
  };
  const register = (name, fn, options = {}) => {
    const key = String(name || "").trim();
    if (!key) throw new TypeError("LPS registry name must be non-empty");
    if (typeof fn !== "function") throw new TypeError(`LPS registry entry '${key}' must be a function reference`);
    if (table.has(key) && options.replace !== true) throw new LPSError(`duplicate registry entry '${key}'`);
    table.set(key, fn);
    return fn;
  };
  const alias = (name, target) => {
    const fn = table.get(String(target));
    if (typeof fn !== "function") throw new LPSError(`alias target '${target}' is not registered`);
    return register(name, fn);
  };
  for (const [name, fn] of Object.entries(initial)) register(name, fn);
  return Object.freeze({
    register,
    alias,
    resolve(name) {
      const value = table.get(String(name));
      if (typeof value !== "function") throw new LPSError(`unresolved call '${name}'`);
      return value;
    },
    bindNative(name, environment, path = name) {
      const value = pathValue(environment, path);
      if (typeof value !== "function") throw new LPSError(`native API '${path}' is not callable`);
      return register(name, value);
    },
    has(name) { return table.has(String(name)); },
    names() { return [...table.keys()].sort(); },
    get size() { return table.size; }
  });
}

const OPS = Object.freeze({
  CONST: 1, MOVE: 2, GET: 3, SET: 4, GETI: 22, ISINT: 23, ADD: 5, SUB: 6, MUL: 7,
  MOD: 8, XOR: 9, EQ: 10, LT: 11, LE: 12, NOT: 13,
  CALL: 14, JMP: 15, JZ: 16, JNZ: 17, GETCTX: 18, SETCTX: 19,
  FAIL: 20, RET: 21
});

function requireRegister(registers, index, pc) {
  if (!Number.isInteger(index) || index < 0 || index > 255) throw new LPSError(`invalid register ${index}`, pc);
  return registers[index];
}

function validateLPSProgram(program) {
  if (!Array.isArray(program) || program.length === 0 || program.length > 1000000) throw new LPSError("program must contain 1..1000000 instructions");
  const arity = { CONST: 3, MOVE: 3, GET: 4, GETI: 4, SET: 4, GETCTX: 3, SETCTX: 3, ADD: 4, SUB: 4, MUL: 4, MOD: 4, XOR: 4, EQ: 4, LT: 4, LE: 4, ISINT: 3, NOT: 3, CALL: 4, JMP: 2, JZ: 3, JNZ: 3, FAIL: 2, RET: 2 };
  const destination = new Set(["CONST", "MOVE", "GET", "GETI", "ADD", "SUB", "MUL", "MOD", "XOR", "EQ", "LT", "LE", "ISINT", "NOT", "CALL"]);
  const sourceRegisters = {
    MOVE: [2], GET: [2], GETI: [2, 3], SET: [1, 3], SETCTX: [2],
    ADD: [2, 3], SUB: [2, 3], MUL: [2, 3], MOD: [2, 3], XOR: [2, 3],
    EQ: [2, 3], LT: [2, 3], LE: [2, 3], ISINT: [2], NOT: [2], JZ: [1], JNZ: [1], RET: [1]
  };
  for (let pc = 0; pc < program.length; pc++) {
    const row = program[pc];
    if (!Array.isArray(row) || typeof row[0] !== "string") throw new LPSError("malformed instruction", pc);
    const op = row[0].toUpperCase();
    if (!(op in arity)) throw new LPSError(`unknown opcode '${op}'`, pc);
    if (row.length !== arity[op]) throw new LPSError(`invalid arity for '${op}'`, pc);
    if (destination.has(op) && (!Number.isInteger(row[1]) || row[1] < 0 || row[1] > 255)) throw new LPSError(`invalid destination register ${row[1]}`, pc);
    for (const operand of sourceRegisters[op] || []) {
      const register = row[operand];
      if (!Number.isInteger(register) || register < 0 || register > 255) throw new LPSError(`invalid register ${register}`, pc);
    }
    if (op === "CALL") {
      if (typeof row[2] !== "string" || !row[2] || !Array.isArray(row[3]) || row[3].some(index => !Number.isInteger(index) || index < 0 || index > 255)) throw new LPSError("invalid CALL operands", pc);
    }
    if ((op === "JMP" && (!Number.isInteger(row[1]) || row[1] < 0 || row[1] >= program.length)) || ((op === "JZ" || op === "JNZ") && (!Number.isInteger(row[2]) || row[2] < 0 || row[2] >= program.length))) throw new LPSError("invalid jump target", pc);
    if ((op === "GETCTX" && typeof row[2] !== "string") || (op === "SETCTX" && typeof row[1] !== "string")) throw new LPSError("context key must be a string", pc);
  }
  return true;
}

/** Execute a validated LPS bytecode program.
 * Instruction format (arrays): [OP, ...operands]. Jump targets are zero-based.
 * CALL format: ["CALL", dst, registryName, argRegisterIndexes].
 */
function executeLPS(program, options = {}) {
  validateLPSProgram(program);
  const registry = options.registry;
  const context = options.context && typeof options.context === "object" ? options.context : Object.create(null);
  const registers = new Array(256);
  const stepLimit = Math.max(1, Math.min(10000000, Number(options.stepLimit) || DEFAULT_STEP_LIMIT));
  let pc = 0;
  let steps = 0;
  while (pc >= 0 && pc < program.length) {
    if (++steps > stepLimit) throw new LPSError("step limit exceeded", pc);
    const instruction = program[pc];
    if (!Array.isArray(instruction) || typeof instruction[0] !== "string") throw new LPSError("malformed instruction", pc);
    const op = instruction[0].toUpperCase();
    const a = instruction[1], b = instruction[2], c = instruction[3];
    const next = pc + 1;
    switch (op) {
      case "CONST": {
        if (!Number.isInteger(a) || a < 0 || a > 255) throw new LPSError("invalid destination register", pc);
        registers[a] = b;
        break;
      }
      case "MOVE": registers[a] = requireRegister(registers, b, pc); break;
      case "GET": {
        const object = requireRegister(registers, b, pc);
        if (object == null) throw new LPSError("GET from nil", pc);
        registers[a] = object[c];
        break;
      }
      case "GETI": {
        const object = requireRegister(registers, b, pc);
        if (object == null) throw new LPSError("GETI from nil", pc);
        registers[a] = object[requireRegister(registers, c, pc)];
        break;
      }
      case "SET": {
        const object = requireRegister(registers, a, pc);
        if (object == null || (typeof object !== "object" && typeof object !== "function")) throw new LPSError("SET target is not mutable", pc);
        object[b] = requireRegister(registers, c, pc);
        break;
      }
      case "GETCTX": registers[a] = context[b]; break;
      case "SETCTX": context[a] = requireRegister(registers, b, pc); break;
      case "ADD": registers[a] = requireRegister(registers, b, pc) + requireRegister(registers, c, pc); break;
      case "SUB": registers[a] = requireRegister(registers, b, pc) - requireRegister(registers, c, pc); break;
      case "MUL": registers[a] = requireRegister(registers, b, pc) * requireRegister(registers, c, pc); break;
      case "MOD": registers[a] = requireRegister(registers, b, pc) % requireRegister(registers, c, pc); break;
      case "XOR": registers[a] = (Number(requireRegister(registers, b, pc)) ^ Number(requireRegister(registers, c, pc))) >>> 0; break;
      case "EQ": registers[a] = requireRegister(registers, b, pc) === requireRegister(registers, c, pc); break;
      case "LT": registers[a] = requireRegister(registers, b, pc) < requireRegister(registers, c, pc); break;
      case "LE": registers[a] = requireRegister(registers, b, pc) <= requireRegister(registers, c, pc); break;
      case "ISINT": registers[a] = Number.isSafeInteger(requireRegister(registers, b, pc)); break;
      case "NOT": registers[a] = !requireRegister(registers, b, pc); break;
      case "CALL": {
        if (!registry || typeof registry.resolve !== "function") throw new LPSError("CALL requires a registry", pc);
        if (!Array.isArray(c)) throw new LPSError("CALL arguments must be register indexes", pc);
        const fn = registry.resolve(b);
        const args = c.map(index => requireRegister(registers, index, pc));
        registers[a] = fn(...args);
        break;
      }
      case "JMP":
        if (!Number.isInteger(a) || a < 0 || a >= program.length) throw new LPSError("invalid jump target", pc);
        pc = a; continue;
      case "JZ":
        if (!Number.isInteger(b) || b < 0 || b >= program.length) throw new LPSError("invalid jump target", pc);
        if (!requireRegister(registers, a, pc)) { pc = b; continue; }
        break;
      case "JNZ":
        if (!Number.isInteger(b) || b < 0 || b >= program.length) throw new LPSError("invalid jump target", pc);
        if (requireRegister(registers, a, pc)) { pc = b; continue; }
        break;
      case "FAIL": throw new LPSError(String(a || "explicit failure"), pc);
      case "RET": return { value: requireRegister(registers, a, pc), context, steps, pc };
      default: throw new LPSError(`unknown opcode '${op}'`, pc);
    }
    pc = next;
  }
  throw new LPSError("program exited without RET", pc);
}

/** Execute striped-lane directory partition validation using LPS bytecode. */
function validatePayloadDirectory(blob, directory) {
  if (typeof blob !== "string" || !Array.isArray(directory)) throw new LPSError("invalid payload lane layout");
  const context = { blobLength: blob.length, directory: [null, ...directory.map(entry => ({ offset: entry?.offset, length: entry?.length }))], count: directory.length };
  const program = [
    ["CONST", 0, 1],
    ["CONST", 1, 1],
    ["CONST", 2, 0],
    ["GETCTX", 3, "count"],
    ["GETCTX", 4, "directory"],
    ["GETCTX", 5, "blobLength"],
    ["LE", 6, 0, 3],
    ["JZ", 6, 27],
    ["GETI", 7, 4, 0],
    ["GET", 8, 7, "offset"],
    ["GET", 9, 7, "length"],
    ["ISINT", 10, 8],
    ["JZ", 10, 31],
    ["ISINT", 10, 9],
    ["JZ", 10, 31],
    ["ADD", 11, 2, 1],
    ["EQ", 10, 8, 11],
    ["JZ", 10, 31],
    ["LE", 10, 1, 9],
    ["JZ", 10, 31],
    ["ADD", 12, 8, 9],
    ["SUB", 12, 12, 1],
    ["LE", 10, 12, 5],
    ["JZ", 10, 31],
    ["MOVE", 2, 12],
    ["ADD", 0, 0, 1],
    ["JMP", 6],
    ["EQ", 10, 2, 5],
    ["JZ", 10, 31],
    ["CONST", 13, true],
    ["RET", 13],
    ["FAIL", "payload directory partition invalid"]
  ];
  const result = executeLPS(program, { context, stepLimit: Math.max(100, directory.length * 25 + 50) });
  if (result.value !== true) throw new LPSError("payload directory validator did not return true");
  return true;
}

module.exports = { LPS_VERSION, LPSError, OPS, createCallRegistry, validateLPSProgram, executeLPS, validatePayloadDirectory };

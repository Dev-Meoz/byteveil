"use strict";

const actions = require("../protection/directive_actions");

const { ENGINE_VERSION: VERSION } = require("../core/version");
const MACROS = Object.freeze([
  "byteveil-inline", "byteveil-outline", "byteveil-virtualization", "byteveil-super",
  "byteveil-cfg", "byteveil-mfg", "byteveil-cgi", "byteveil-pre-check", "byteveil-rewrite",
  "byteveil-enc-func", "byteveil-vm", "byteveil-cff", "byteveil-encstr", "byteveil-index-to-num",
  "byteveil-obfuscated", "byteveil-crash", "byteveil-omit", "byteveil-line", "byteveil-compress"
]);
const MACRO_SET = new Set(MACROS);
const EFFECTS = Object.freeze({
  "byteveil-inline": "inline", "byteveil-outline": "outline", "byteveil-virtualization": "virtualization",
  "byteveil-super": "super", "byteveil-cfg": "cfg", "byteveil-mfg": "mfg", "byteveil-cgi": "cgi",
  "byteveil-pre-check": "preCheck", "byteveil-rewrite": "rewrite", "byteveil-enc-func": "encFunc",
  "byteveil-vm": "vm", "byteveil-cff": "cff", "byteveil-encstr": "encStr",
  "byteveil-index-to-num": "indexToNum", "byteveil-obfuscated": "obfuscated", "byteveil-crash": "crash",
  "byteveil-omit": "omit", "byteveil-line": "line", "byteveil-compress": "compress"
});

function parseArgs(raw) {
  if (!raw) return [];
  const text = String(raw);
  const out = [];
  let item = "", quote = "", escaped = false;
  for (const ch of text) {
    if (escaped) { item += ch; escaped = false; continue; }
    if (ch === "\\") { item += ch; escaped = true; continue; }
    if (quote) { item += ch; if (ch === quote) quote = ""; continue; }
    if (ch === "'" || ch === '"') { quote = ch; item += ch; continue; }
    if (ch === ",") { if (item.trim()) out.push(cleanArg(item)); item = ""; continue; }
    item += ch;
  }
  if (item.trim()) out.push(cleanArg(item));
  return out;
}
function cleanArg(value) { return String(value).trim().replace(/^(["'])(.*)\1$/s, "$2"); }

function scan(source) {
  const lines = String(source || "").split(/\r?\n/);
  const directives = [];
  const re = /^\s*--\s*(?:@\s*)?(byteveil-[a-z0-9-]+)(?:\s*\((.*)\))?\s*$/i;
  for (let i = 0; i < lines.length; i++) {
    const match = re.exec(lines[i]);
    if (!match) continue;
    const name = match[1].toLowerCase();
    if (!MACRO_SET.has(name)) continue;
    directives.push({ name, args: parseArgs(match[2]), line: i + 1, scope: "next-statement", sourceKind: "comment", raw: lines[i] });
  }
  return directives;
}

function validate(directives) {
  const errors = [];
  for (const directive of directives || []) {
    const names = directives.filter(other => other.line === directive.line).map(other => other.name);
    if (names.includes("byteveil-inline") && names.includes("byteveil-outline")) {
      const error = "byteveil-inline and byteveil-outline cannot target the same scope";
      if (!errors.includes(error)) errors.push(error);
    }
    if (["byteveil-enc-func", "byteveil-super"].includes(directive.name) && directive.args[0] !== undefined) {
      const numeric = Number(directive.args[0]);
      if (!Number.isFinite(numeric) || numeric < 1 || numeric > 5) errors.push(`${directive.name} depth/level must be between 1 and 5`);
    }
  }
  return [...new Set(errors)];
}

function resolve(source, ast = null, options = {}) {
  const directives = scan(source);
  const errors = validate(directives);
  const effects = Object.create(null);
  for (const directive of directives) {
    const effect = EFFECTS[directive.name];
    if (effect) effects[effect] = { enabled: true, args: directive.args.slice(), line: directive.line, scope: directive.scope };
  }
  const plan = {
    version: VERSION,
    engine: "ByteVeil Macro Engine",
    directives,
    effects,
    errors,
    resolved: errors.length === 0,
    enabled: options.enabled !== false,
    applied: false,
    commentDirectiveCount: directives.length,
    effectiveDirectiveCount: 0
  };
  if (ast && typeof ast === "object") {
    actions.annotate(ast, plan);
    Object.defineProperty(ast, "__byteVeilMacros", { value: plan, enumerable: false, configurable: true, writable: true });
  }
  return plan;
}

function apply(ast, plan, options = {}) {
  if (!plan || !plan.enabled || plan.errors?.length) return ast;
  actions.applyPlan(ast, plan, options);
  plan.applied = true;
  plan.effectiveDirectiveCount = (plan.directives || []).filter(d => d.effectStatus === "applied" || d.effectStatus === "backend-active" || d.effectStatus === "backend-shield-active").length;
  plan.warnings = (plan.directives || []).filter(d => d.effectStatus && !["applied", "backend-active", "backend-shield-active"].includes(d.effectStatus)).map(d => `${d.name}: ${d.effectStatus}`);
  return ast;
}

module.exports = { VERSION, MACROS, EFFECTS, parseArgs, scan, validate, resolve, apply };

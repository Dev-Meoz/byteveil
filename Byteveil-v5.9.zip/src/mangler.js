"use strict";

const RESERVED = new Set([
    "_ENV", "_G", "game", "workspace", "script", "shared",
    "print", "warn", "error", "assert", "pairs", "ipairs",
    "next", "type", "typeof", "tostring", "tonumber", "select",
    "unpack", "require", "getmetatable", "setmetatable",
    "rawget", "rawset", "rawequal", "rawlen", "string", "table",
    "math", "coroutine", "bit32", "os", "debug", "utf8",
    "task", "wait", "delay", "spawn", "tick", "pcall", "xpcall",
    "Instance", "Players", "ReplicatedStorage", "ServerStorage",
    "ServerScriptService", "RunService", "TweenService",
    "UserInputService", "CollectionService", "Color3", "Vector2",
    "Vector3", "CFrame", "Enum", "UDim", "UDim2",
    "RaycastParams", "RaycastResult"
]);

const LUA_RESERVED = new Set((
    "and break do else elseif end false for function if in local nil not or repeat return then true until while goto"
).split(/\s+/));

const NAME_HEAD = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const NAME_BODY = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";

function isObject(value) {
    return value !== null && typeof value === "object";
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 0x9E3779B9;
    }

    if (seed === undefined || seed === null) {
        return (Date.now() >>> 0) || 0x9E3779B9;
    }

    let hash = 0x811C9DC5;

    for (const char of String(seed)) {
        hash ^= char.charCodeAt(0);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 0x9E3779B9;
}

function makeRng(seed) {
    let state = normalizeSeed(seed);

    return () => {
        state = (state + 0x6D2B79F5) >>> 0;

        let value = state;
        value = Math.imul(value ^ (value >>> 15), value | 1);
        value ^= value + Math.imul(value ^ (value >>> 7), value | 61);

        return (value ^ (value >>> 14)) >>> 0;
    };
}

function collectSourceNames(root) {
    const names = new Set();
    const visited = new WeakSet();

    function add(value) {
        if (typeof value === "string" && value.length > 0) {
            names.add(value);
        }
    }

    function walk(node) {
        if (!isObject(node) || visited.has(node)) return;
        visited.add(node);

        if (node.type === "Id") add(node.name);
        if (node.type === "LocalFunction" || node.type === "Function") add(node.name);
        if (node.type === "ForNum") add(node.name);

        for (const key of ["params", "names"]) {
            if (!Array.isArray(node[key])) continue;

            for (const entry of node[key]) {
                if (typeof entry === "string") add(entry);
                else if (isObject(entry)) add(entry.name);
            }
        }

        if (Array.isArray(node.namePath)) {
            for (const part of node.namePath) {
                if (isObject(part)) add(part.value);
            }
        }

        for (const [key, value] of Object.entries(node)) {
            if (key.startsWith("__")) continue;

            if (Array.isArray(value)) {
                value.forEach(walk);
            } else if (isObject(value)) {
                walk(value);
            }
        }
    }

    walk(root);
    return names;
}

function createNameFactory(seed, existingNames = new Set()) {
    const next = makeRng(normalizeSeed(seed) ^ 0xB17E4A31);
    const used = new Set([
        ...RESERVED,
        ...LUA_RESERVED,
        ...existingNames
    ]);

    let fallbackSerial = 0;

    return function nextName(_role, serial) {
        for (let attempt = 0; attempt < 1024; attempt++) {
            const length = 7 + (next() % 10);

            let candidate = "_" + NAME_HEAD[next() % NAME_HEAD.length];

            for (let i = 1; i < length; i++) {
                candidate += NAME_BODY[next() % NAME_BODY.length];
            }

            if ((next() & 3) === 0) {
                candidate += (Number(serial) >>> 0).toString(36);
            }

            if (!used.has(candidate)) {
                used.add(candidate);
                return candidate;
            }
        }

        for (;;) {
            const candidate = `_BV${(fallbackSerial++).toString(36)}`;

            if (!used.has(candidate)) {
                used.add(candidate);
                return candidate;
            }
        }
    };
}

function mangle(ast, seed = Date.now(), options = {}) {
    if (!isObject(ast) || Array.isArray(ast)) {
        throw new TypeError("mangler.mangle: expected AST object");
    }

    if (isObject(seed) && !Array.isArray(seed)) {
        options = seed;
        seed = options.seed === undefined ? Date.now() : options.seed;
    }

    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError("mangler.mangle: options must be an object");
    }

    const normalizedSeed = normalizeSeed(seed);
    const sourceNames = collectSourceNames(ast);
    const nextName = createNameFactory(normalizedSeed, sourceNames);

    // Each scope contains declarations owned by that scope only.
    // Parent scopes are searched separately so shadowing is explicit.
    const scopes = [new Map()];
    const visitedExpr = new WeakSet();
    const visitedStmt = new WeakSet();

    const stats = {
        seed: normalizedSeed,
        renamedDeclarations: 0,
        renamedReferences: 0,
        preservedEnvBindings: 0,
        visitedFunctions: 0,
        maxScopeDepth: 1,
        unresolvedIdentifiers: 0
    };

    const renameGlobalBindings = options.renameGlobalBindings === true;

    function currentScope() {
        return scopes[scopes.length - 1];
    }

    function pushScope() {
        scopes.push(new Map());

        if (scopes.length > stats.maxScopeDepth) {
            stats.maxScopeDepth = scopes.length;
        }
    }

    function popScope() {
        if (scopes.length <= 1) {
            throw new Error("mangler: attempted to pop root lexical scope");
        }

        scopes.pop();
    }

    function bind(name, role) {
        if (
            typeof name !== "string" ||
            name.length === 0 ||
            name === "..."
        ) {
            return name;
        }

        const scope = currentScope();

        // _ENV has language-defined meaning and must remain a stable binding.
        if (name === "_ENV") {
            scope.set(name, name);
            stats.preservedEnvBindings++;
            return name;
        }

        const renamed = nextName(role, stats.renamedDeclarations);

        scope.set(name, renamed);
        stats.renamedDeclarations++;

        return renamed;
    }

    function lookup(name) {
        if (typeof name !== "string") return name;

        for (let i = scopes.length - 1; i >= 0; i--) {
            if (scopes[i].has(name)) {
                stats.renamedReferences++;
                return scopes[i].get(name);
            }
        }

        if (
            renameGlobalBindings &&
            !RESERVED.has(name) &&
            !LUA_RESERVED.has(name)
        ) {
            // Never guess a global rename without a real global symbol table.
            stats.unresolvedIdentifiers++;
        }

        return name;
    }

    function visitIdentifierNode(node, declaration = false, role = "local") {
        if (!isObject(node) || node.type !== "Id") return node;

        node.name = declaration
            ? bind(node.name, role)
            : lookup(node.name);

        return node;
    }

    function visitExpression(node) {
        if (!isObject(node) || visitedExpr.has(node)) return node;
        visitedExpr.add(node);

        switch (node.type) {
            case "Id":
                visitIdentifierNode(node, false);
                break;

            case "Binary":
                node.left = visitExpression(node.left);
                node.right = visitExpression(node.right);
                break;

            case "Unary":
                node.arg = visitExpression(node.arg);
                break;

            case "Index":
                node.obj = visitExpression(node.obj);
                node.key = visitExpression(node.key);
                break;

            case "Call":
                node.callee = visitExpression(node.callee);
                node.args = (node.args || []).map(visitExpression);
                break;

            case "IfElseExpression":
                node.cond = visitExpression(node.cond);
                node.consequent = visitExpression(node.consequent);
                node.alternate = visitExpression(node.alternate);
                break;

            case "FunctionExpr":
                visitFunction(node);
                break;

            case "Table":
                node.fields = (node.fields || []).map(field => {
                    if (!isObject(field)) return field;

                    return {
                        ...field,
                        key: visitExpression(field.key),
                        value: visitExpression(field.value)
                    };
                });
                break;

            case "Paren":
            case "Group":
                if (node.expression) {
                    node.expression = visitExpression(node.expression);
                } else if (node.expr) {
                    node.expr = visitExpression(node.expr);
                }
                break;
        }

        return node;
    }

    function declareNameEntry(entry, role) {
        if (typeof entry === "string") {
            return bind(entry, role);
        }

        if (!isObject(entry)) return entry;

        if (entry.type === "Id") {
            entry.name = bind(entry.name, role);
            return entry;
        }

        if (typeof entry.name === "string") {
            entry.name = bind(entry.name, role);
            return entry;
        }

        return entry;
    }

    function visitFunction(fn) {
        if (!isObject(fn)) return;

        stats.visitedFunctions++;
        pushScope();

        fn.params = (fn.params || []).map(param =>
            declareNameEntry(param, "parameter")
        );

        visitBody(fn.body);

        popScope();
    }

    function visitFunctionTarget(statement) {
        if (Array.isArray(statement.namePath) && statement.namePath.length > 0) {
            const parts = statement.namePath.map((part, index) => {
                if (!isObject(part)) return part;

                const copy = { ...part };

                // Rename only the lexical root. Member and method names are
                // keys; renaming them changes public table semantics.
                if (index === 0 && copy.type === "name") {
                    copy.value = lookup(copy.value);
                }

                return copy;
            });

            statement.namePath = parts;

            let assembled = isObject(parts[0])
                ? String(parts[0].value)
                : String(parts[0]);

            for (let index = 1; index < parts.length; index++) {
                const part = parts[index];
                const separator =
                    isObject(part) && part.type === "method" ? ":" : ".";

                assembled += separator +
                    (isObject(part) ? String(part.value) : String(part));
            }

            statement.name = assembled;
            return;
        }

        if (typeof statement.name !== "string") return;

        const firstDot = statement.name.search(/[.:]/);

        if (firstDot < 0) {
            statement.name = lookup(statement.name);
            return;
        }

        const root = statement.name.slice(0, firstDot);

        statement.name =
            lookup(root) + statement.name.slice(firstDot);
    }

    function visitLValue(node) {
        if (!isObject(node)) return node;

        if (node.type === "Id") {
            node.name = lookup(node.name);
            return node;
        }

        return visitExpression(node);
    }

    function visitStatement(node) {
        if (!isObject(node) || visitedStmt.has(node)) return node;
        visitedStmt.add(node);

        switch (node.type) {
            case "Local":
                // Local RHS expressions resolve before the new bindings exist.
                node.values = (node.values || []).map(visitExpression);
                node.vars = (node.vars || []).map(value =>
                    declareNameEntry(value, "local")
                );
                break;

            case "LocalFunction":
                // Declare first to support recursive references.
                node.name = bind(node.name, "function");
                visitFunction(node.fn);
                break;

            case "Function":
                visitFunctionTarget(node);
                visitFunction(node.fn);
                break;

            case "Assign":
                node.values = (node.values || []).map(visitExpression);
                node.vars = (node.vars || []).map(visitLValue);
                break;

            case "Compound":
                node.left = visitLValue(node.left);
                node.value = visitExpression(node.value);
                break;

            case "CallStmt":
                node.call = visitExpression(node.call);
                break;

            case "Return":
                node.values = (node.values || []).map(visitExpression);
                break;

            case "If":
                node.branches = (node.branches || []).map(branch => {
                    if (!isObject(branch)) return branch;

                    const cond = visitExpression(branch.cond);
                    pushScope();
                    const body = (branch.body || []).map(visitStatement);
                    popScope();

                    return { ...branch, cond, body };
                });

                pushScope();
                node.elseBody = (node.elseBody || []).map(visitStatement);
                popScope();
                break;

            case "While":
                node.cond = visitExpression(node.cond);
                pushScope();
                node.body = (node.body || []).map(visitStatement);
                popScope();
                break;

            case "Repeat":
                // `until` condition can see locals declared by the repeat body.
                pushScope();
                node.body = (node.body || []).map(visitStatement);
                node.cond = visitExpression(node.cond);
                popScope();
                break;

            case "ForNum":
                node.start = visitExpression(node.start);
                node.end = visitExpression(node.end);
                node.step = visitExpression(node.step);

                pushScope();
                node.name = bind(node.name, "loop");
                node.body = (node.body || []).map(visitStatement);
                popScope();
                break;

            case "ForIn":
                node.it = (node.it || []).map(visitExpression);

                pushScope();
                node.names = (node.names || []).map(value =>
                    declareNameEntry(value, "loop")
                );
                node.body = (node.body || []).map(visitStatement);
                popScope();
                break;

            case "Do":
                pushScope();
                node.body = (node.body || []).map(visitStatement);
                popScope();
                break;

            default:
                // Unknown statement types remain untouched rather than guessed.
                break;
        }

        return node;
    }

    function visitBody(body) {
        if (!Array.isArray(body)) return;

        for (let i = 0; i < body.length; i++) {
            body[i] = visitStatement(body[i]);
        }
    }

    visitBody(ast.body);

    Object.defineProperty(ast, "__mangler", {
        value: Object.freeze({
            seed: normalizedSeed,
            renamed: stats.renamedDeclarations,
            roles: "scope-frame-identity-v2",
            ...stats,
            supported: true
        }),
        enumerable: false,
        configurable: true,
        writable: true
    });

    return ast;
}

module.exports = {
    mangle,
    makeRng,
    createNameFactory,
    collectSourceNames,
    RESERVED,
    LUA_RESERVED
};
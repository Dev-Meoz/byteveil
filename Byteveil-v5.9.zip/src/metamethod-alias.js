"use strict";

/**
 * ByteVeil — Metamethod Key Alias Pass
 *
 * This is an AST transformation module, not a runtime metamethod
 * implementation and not a facade for ./metamethod.js.
 *
 * Example transformation:
 *
 *   setmetatable(t, {
 *       ["__index"] = handler
 *   })
 *
 * Into the equivalent AST:
 *
 *   local _ma_xxx = "__index"
 *
 *   setmetatable(t, {
 *       [_ma_xxx] = handler
 *   })
 *
 * The runtime key remains "__index". Only the source representation
 * of selected explicit string-key references changes.
 *
 * Intended pipeline order:
 *   parse -> metamethod-alias -> scope analysis/mangler -> string transform
 *
 * This pass intentionally does not rewrite:
 *   - implicit name-key fields represented outside `field.key`;
 *   - arbitrary string literals used as values;
 *   - method names;
 *   - runtime magic-key values.
 */

const DEFAULT = Object.freeze([
    "__index",
    "__newindex",
    "__call",
    "__add",
    "__sub",
    "__mul",
    "__div",
    "__idiv",
    "__mod",
    "__pow",
    "__concat",
    "__eq",
    "__lt",
    "__le",
    "__unm",
    "__len",
    "__tostring",
    "__pairs",
    "__ipairs",
    "__mode",
    "__metatable",
    "__gc",
    "__close"
]);

const LUA_RESERVED = new Set((
    "and break do else elseif end false for function if in local nil not or repeat return then true until while goto"
).split(/\s+/));

const hasOwn = (value, key) =>
    Object.prototype.hasOwnProperty.call(value, key);

function isObject(value) {
    return value !== null && typeof value === "object";
}

function defineHidden(object, key, value) {
    Object.defineProperty(object, key, {
        value,
        enumerable: false,
        configurable: true,
        writable: true
    });
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 0x6D2B79F5;
    }

    if (seed === undefined || seed === null) {
        return 1;
    }

    const text = String(seed);
    let hash = 0x811C9DC5;

    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 0x6D2B79F5;
}

function createRng(seed) {
    let state = normalizeSeed(seed);

    return function next() {
        state = (state + 0x6D2B79F5) >>> 0;

        let value = state;

        value = Math.imul(
            value ^ (value >>> 15),
            value | 1
        );

        value ^= value + Math.imul(
            value ^ (value >>> 7),
            value | 61
        );

        value = (value ^ (value >>> 14)) >>> 0;

        return value || 0x6D2B79F5;
    };
}

function validateNames(names) {
    if (!Array.isArray(names)) {
        throw new TypeError(
            "metamethod-alias: names must be an array"
        );
    }

    const result = [];
    const seen = new Set();

    for (const name of names) {
        if (
            typeof name !== "string" ||
            !/^__[A-Za-z][A-Za-z0-9_]*$/.test(name)
        ) {
            throw new TypeError(
                `metamethod-alias: invalid key ${String(name)}`
            );
        }

        if (!seen.has(name)) {
            seen.add(name);
            result.push(name);
        }
    }

    return result;
}

/**
 * Collect existing identifier names to avoid generating colliding aliases.
 */
function collectIdentifiers(ast) {
    const names = new Set();
    const visited = new WeakSet();

    function add(name) {
        if (typeof name === "string" && name.length > 0) {
            names.add(name);
        }
    }

    function visit(node) {
        if (!isObject(node) || visited.has(node)) {
            return;
        }

        visited.add(node);

        if (node.type === "Id") {
            add(node.name);
        }

        if (
            node.type === "LocalFunction" ||
            node.type === "Function"
        ) {
            add(node.name);
        }

        if (node.type === "ForNum") {
            add(node.name);
        }

        if (Array.isArray(node.vars)) {
            for (const value of node.vars) {
                if (typeof value === "string") {
                    add(value);
                } else if (isObject(value) && value.type === "Id") {
                    add(value.name);
                }
            }
        }

        if (Array.isArray(node.names)) {
            for (const value of node.names) {
                if (typeof value === "string") {
                    add(value);
                } else if (isObject(value)) {
                    add(value.name);
                }
            }
        }

        if (Array.isArray(node.params)) {
            for (const value of node.params) {
                if (typeof value === "string") {
                    add(value);
                } else if (isObject(value)) {
                    add(value.name);
                }
            }
        }

        for (const [key, value] of Object.entries(node)) {
            // Avoid walking our own generated metadata.
            if (key.startsWith("__")) {
                continue;
            }

            if (Array.isArray(value)) {
                for (const child of value) {
                    visit(child);
                }
            } else if (isObject(value)) {
                visit(value);
            }
        }
    }

    visit(ast);

    for (const keyword of LUA_RESERVED) {
        names.add(keyword);
    }

    return names;
}

/**
 * Generate a deterministic mapping:
 *
 * {
 *   "__index": "_ma_xxxxx",
 *   "__call": "_ma_yyyyy"
 * }
 *
 * Values are local variable names, not replacement magic-key strings.
 */
function aliasMap(seed = 1, names = DEFAULT, reserved = []) {
    const keys = validateNames(names);
    const next = createRng(seed);
    const used = new Set();

    if (
        reserved == null ||
        typeof reserved[Symbol.iterator] !== "function"
    ) {
        throw new TypeError(
            "metamethod-alias.aliasMap: reserved must be iterable"
        );
    }

    for (const name of reserved) {
        used.add(String(name));
    }

    for (const keyword of LUA_RESERVED) {
        used.add(keyword);
    }

    const output = {};

    for (const key of keys) {
        let alias;

        do {
            alias = `_ma_${next().toString(36)}_${next().toString(36)}`;
        } while (used.has(alias));

        used.add(alias);
        output[key] = alias;
    }

    return output;
}

function readStringKey(node) {
    if (!isObject(node)) {
        return null;
    }

    if (
        (node.type === "String" || node.type === "StringLiteral") &&
        typeof node.value === "string"
    ) {
        return node.value;
    }

    return null;
}

function makeIdentifier(alias, original) {
    const node = {
        type: "Id",
        name: alias
    };

    // Preserve source-location information where available.
    for (const key of [
        "line",
        "column",
        "loc",
        "range",
        "start",
        "end",
        "source"
    ]) {
        if (original && original[key] !== undefined) {
            node[key] = original[key];
        }
    }

    return node;
}

function makeString(value) {
    return {
        type: "String",
        value
    };
}

function makeAliasDeclaration(alias, key) {
    return {
        type: "Local",
        vars: [alias],
        values: [makeString(key)]
    };
}

/**
 * Analyze locations eligible for aliasing without modifying the AST.
 *
 * Eligible locations:
 *   - Index.key string literals;
 *   - Table field key string literals.
 *
 * This deliberately does not replace matching literals in arbitrary
 * expression/value positions.
 */
function analyze(ast, names = DEFAULT) {
    if (!isObject(ast) || Array.isArray(ast)) {
        throw new TypeError(
            "metamethod-alias.analyze: expected AST object"
        );
    }

    const selected = new Set(validateNames(names));
    const counts = Object.create(null);
    const locations = Object.create(null);
    const visited = new WeakSet();

    for (const name of selected) {
        counts[name] = {
            indexKeys: 0,
            tableKeys: 0,
            total: 0
        };

        locations[name] = [];
    }

    function record(name, kind, path) {
        if (!selected.has(name)) {
            return;
        }

        counts[name][kind]++;
        counts[name].total++;

        locations[name].push({
            kind,
            path
        });
    }

    function visit(node, path) {
        if (!isObject(node) || visited.has(node)) {
            return;
        }

        visited.add(node);

        if (node.type === "Index") {
            const key = readStringKey(node.key);

            if (key !== null) {
                record(key, "indexKeys", `${path}.key`);
            }
        }

        if (node.type === "Table" && Array.isArray(node.fields)) {
            for (let i = 0; i < node.fields.length; i++) {
                const field = node.fields[i];

                if (!isObject(field)) {
                    continue;
                }

                const key = readStringKey(field.key);

                if (key !== null) {
                    record(
                        key,
                        "tableKeys",
                        `${path}.fields[${i}].key`
                    );
                }
            }
        }

        for (const [key, value] of Object.entries(node)) {
            if (key.startsWith("__")) {
                continue;
            }

            if (Array.isArray(value)) {
                for (let i = 0; i < value.length; i++) {
                    visit(value[i], `${path}.${key}[${i}]`);
                }
            } else if (isObject(value)) {
                visit(value, `${path}.${key}`);
            }
        }
    }

    visit(ast, "root");

    const publicCounts = {};

    for (const name of selected) {
        publicCounts[name] = Object.freeze({
            ...counts[name]
        });

        locations[name] = Object.freeze(
            locations[name].map(entry => Object.freeze({ ...entry }))
        );
    }

    const usedKeys = [...selected].filter(
        key => counts[key].total > 0
    );

    return Object.freeze({
        version: "metamethod-key-alias-v1",
        counts: Object.freeze(publicCounts),
        locations: Object.freeze(locations),
        usedKeys: Object.freeze(usedKeys),
        candidates: selected.size,
        eligibleReferences: usedKeys.reduce(
            (total, key) => total + counts[key].total,
            0
        )
    });
}

/**
 * Rewrite eligible key expressions and prepend local aliases.
 *
 * Legacy API:
 *   attach(ast, seed)
 *
 * Extended API:
 *   attach(ast, seed, { enabled, names })
 *
 * Returns the same AST object.
 */
function attach(ast, seed = 1, options = {}) {
    if (!isObject(ast) || Array.isArray(ast)) {
        throw new TypeError(
            "metamethod-alias.attach: expected AST object"
        );
    }

    if (
        !isObject(options) ||
        Array.isArray(options)
    ) {
        throw new TypeError(
            "metamethod-alias.attach: options must be an object"
        );
    }

    if (options.enabled === false) {
        return ast;
    }

    // A second pass with the same transformation marker is a no-op.
    if (ast.__metamethodAliasInfo?.applied === true) {
        return ast;
    }

    const names = validateNames(
        Array.isArray(options.names)
            ? options.names
            : DEFAULT
    );

    const analysis = analyze(ast, names);
    const usedKeys = analysis.usedKeys;

    const normalizedSeed = normalizeSeed(seed);
    const reserved = collectIdentifiers(ast);

    const allAliases = aliasMap(
        normalizedSeed,
        usedKeys,
        reserved
    );

    // No matching references: record analysis but do not add dead locals.
    if (usedKeys.length === 0) {
        defineHidden(ast, "__metamethodAliases", allAliases);

        defineHidden(
            ast,
            "__metamethodAliasInfo",
            Object.freeze({
                version: "metamethod-key-alias-v1",
                enabled: true,
                applied: false,
                seed: normalizedSeed,
                keysRewritten: 0,
                aliasesDeclared: 0,
                analysis
            })
        );

        return ast;
    }

    if (!Array.isArray(ast.body)) {
        throw new TypeError(
            "metamethod-alias.attach: AST must contain a body array to insert local aliases"
        );
    }

    const aliasByKey = allAliases;
    const visited = new WeakSet();

    const stats = {
        indexKeys: 0,
        tableKeys: 0,
        keysRewritten: 0
    };

    function shouldAlias(node) {
        const key = readStringKey(node);

        return key !== null &&
            Object.prototype.hasOwnProperty.call(aliasByKey, key);
    }

    function aliasExpression(node, kind) {
        if (!shouldAlias(node)) {
            return node;
        }

        const key = readStringKey(node);
        stats[kind]++;
        stats.keysRewritten++;

        return makeIdentifier(aliasByKey[key], node);
    }

    function rewrite(node) {
        if (!isObject(node) || visited.has(node)) {
            return node;
        }

        visited.add(node);

        if (node.type === "Index") {
            node.key = aliasExpression(node.key, "indexKeys");
        }

        if (node.type === "Table" && Array.isArray(node.fields)) {
            for (const field of node.fields) {
                if (!isObject(field)) {
                    continue;
                }

                field.key = aliasExpression(
                    field.key,
                    "tableKeys"
                );
            }
        }

        // Walk after local key replacement so the replacement identifier
        // remains intact and is not revisited as a string literal.
        for (const [key, value] of Object.entries(node)) {
            if (key.startsWith("__")) {
                continue;
            }

            if (Array.isArray(value)) {
                for (let i = 0; i < value.length; i++) {
                    value[i] = rewrite(value[i]);
                }
            } else if (isObject(value)) {
                node[key] = rewrite(value);
            }
        }

        return node;
    }

    rewrite(ast);

    const declarations = [];

    for (const key of usedKeys) {
        declarations.push(
            makeAliasDeclaration(aliasByKey[key], key)
        );
    }

    // Declare aliases before any rewritten reference can execute.
    ast.body.unshift(...declarations);

    defineHidden(
        ast,
        "__metamethodAliases",
        allAliases
    );

    defineHidden(
        ast,
        "__metamethodAliasInfo",
        Object.freeze({
            version: "metamethod-key-alias-v1",
            enabled: true,
            applied: true,
            seed: normalizedSeed,

            keysRewritten: stats.keysRewritten,
            indexKeysRewritten: stats.indexKeys,
            tableKeysRewritten: stats.tableKeys,

            aliasesDeclared: declarations.length,
            usedKeys: Object.freeze(usedKeys.slice()),

            semanticValuesPreserved: true,
            magicKeysRenamed: false,
            analysis
        })
    );

    return ast;
}

function transform(ast, options = {}) {
    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError(
            "metamethod-alias.transform: options must be an object"
        );
    }

    const seed = options.seed === undefined
        ? 1
        : options.seed;

    return attach(ast, seed, options);
}

module.exports = {
    DEFAULT,
    aliasMap,
    collectIdentifiers,
    analyze,
    attach,
    transform
};
"use strict";

// Single source of truth for the opaque-text alphabets ByteVeil emits.
//
// Every container class (payload carriers, VeilBlob diagnostics, decoys, junk
// carriers) draws from the same 93 characters. The carrier route used an
// 85-character set with digits while the blob route used an 84-character set
// without them, so a static reader could sort containers by character
// distribution alone, with no decoding at all.
//
// `\` is deliberately excluded: container text is emitted through JSON-escaped
// Lua string literals, where a backslash becomes `\\`, and three payload digits
// following it then read as a `\ddd` decimal byte escape — which both trips the
// generator invariant forbidding that representation and is exactly the shape
// the output is built to avoid producing.
//
// The order below is a fixed Fisher-Yates shuffle of the 33..126 range minus
// the backslash, seeded once, so the emitted alphabet is not the ASCII table and
// letter/digit/symbol classes do not cluster.

const PRINTABLE_ASCII = Array.from({ length: 94 }, (_, index) => String.fromCharCode(33 + index)).join("");

const UNIFIED_ALPHABET = '2uHL<ojJ5Wl.7{w"MtR`8xmcCr&Gg%](KYZ9Q1};^,Xz$[E~B?60i_*U=/F:Dk>)@3qh!TbvPe\'pasIdSA|#yNVOn4f+-';
const UNIFIED_BASE = UNIFIED_ALPHABET.length;

const isPrintable = [...UNIFIED_ALPHABET].every((character) => {
  const code = character.codePointAt(0);
  return code >= 33 && code <= 126 && character !== "\\";
});
if (!isPrintable) throw new Error("ByteVeil blob alphabet: characters outside the printable range, or a backslash");
if (UNIFIED_BASE !== PRINTABLE_ASCII.length - 1) {
  throw new Error(`ByteVeil blob alphabet: expected ${PRINTABLE_ASCII.length - 1} characters, found ${UNIFIED_BASE}`);
}
if (new Set(UNIFIED_ALPHABET).size !== UNIFIED_BASE) {
  throw new Error("ByteVeil blob alphabet: duplicate character in the unified alphabet");
}
if ([...PRINTABLE_ASCII].filter((c) => c !== "\\").some((c) => !UNIFIED_ALPHABET.includes(c))) {
  throw new Error("ByteVeil blob alphabet: unified alphabet no longer covers the printable range");
}

function shuffleAlphabet(alphabet, rng) {
  const chars = [...alphabet];
  for (let i = chars.length - 1; i > 0; i--) {
    const j = rng() % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

module.exports = {
  PRINTABLE_ASCII,
  UNIFIED_ALPHABET,
  UNIFIED_BASE,
  shuffleAlphabet
};

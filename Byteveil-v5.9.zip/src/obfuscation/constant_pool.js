"use strict";

class ConstantPool {
    #target;
    #items;
    #index;
    #negativeZero;
    #dirty;

    constructor(initialItems = []) {
        if (!Array.isArray(initialItems)) {
            throw new TypeError(
                "ConstantPool: initialItems must be an array"
            );
        }

        // Normalize sparse arrays into a dense sequence of values.
        this.#target = Array.from(initialItems);

        this.#index = new Map();
        this.#negativeZero = Symbol("ConstantPool.negativeZero");
        this.#dirty = true;

        const pool = this;

        /*
         * Keep the existing mutable `items` API for compatibility.
         *
         * Direct writes, deletions and property definitions invalidate
         * the index, even when the array length remains unchanged.
         */
        this.#items = new Proxy(this.#target, {
            set(target, property, value) {
                const success = Reflect.set(
                    target,
                    property,
                    value,
                    target
                );

                if (success) {
                    pool.#dirty = true;
                }

                return success;
            },

            deleteProperty(target, property) {
                const success = Reflect.deleteProperty(
                    target,
                    property
                );

                if (success) {
                    pool.#dirty = true;
                }

                return success;
            },

            defineProperty(target, property, descriptor) {
                const success = Reflect.defineProperty(
                    target,
                    property,
                    descriptor
                );

                if (success) {
                    pool.#dirty = true;
                }

                return success;
            }
        });

        this.rebuildIndex();
    }

    /*
     * Expose the original array-like API, but track mutations so
     * the internal index cannot silently become stale.
     */
    get items() {
        return this.#items;
    }

    #key(value) {
        /*
         * Map uses SameValueZero:
         *   +0 and -0 normally refer to the same key.
         *
         * Use a private sentinel to preserve negative zero separately.
         * NaN values still deduplicate consistently.
         */
        if (
            typeof value === "number" &&
            Object.is(value, -0)
        ) {
            return this.#negativeZero;
        }

        return value;
    }

    #ensureIndex() {
        if (this.#dirty) {
            this.rebuildIndex();
        }
    }

    #hasOwnIndex(index) {
        return Object.prototype.hasOwnProperty.call(
            this.#target,
            index
        );
    }

    #assertIndex(index) {
        return (
            Number.isInteger(index) &&
            index >= 0 &&
            index < this.#target.length &&
            this.#hasOwnIndex(index)
        );
    }

    rebuildIndex() {
        /*
         * Build a replacement map and publish it only after the
         * complete scan succeeds. A failed rebuild won't leave a
         * partially populated index.
         */
        const nextIndex = new Map();
        const length = this.#target.length;

        for (let i = 0; i < length; i++) {
            // A deleted array element is a hole, not a stored value.
            if (!this.#hasOwnIndex(i)) {
                continue;
            }

            const key = this.#key(this.#target[i]);

            // Preserve the earliest index if external writes created
            // duplicate values in the backing array.
            if (!nextIndex.has(key)) {
                nextIndex.set(key, i);
            }
        }

        this.#index = nextIndex;
        this.#dirty = false;

        return this;
    }

    add(value) {
        this.#ensureIndex();

        const key = this.#key(value);

        if (this.#index.has(key)) {
            return this.#index.get(key);
        }

        const index = this.#target.length;

        /*
         * Use the built-in operation on the private backing array.
         * This avoids relying on a potentially overwritten `items.push`
         * property. The array is private to the pool except for its
         * mutation-tracking Proxy.
         */
        Array.prototype.push.call(this.#target, value);

        this.#index.set(key, index);
        this.#dirty = false;

        return index;
    }

    intern(value) {
        return this.add(value);
    }

    addString(value) {
        if (typeof value !== "string") {
            throw new TypeError(
                "ConstantPool.addString: value must be a string"
            );
        }

        return this.add(value);
    }

    addNumber(value) {
        if (typeof value !== "number") {
            throw new TypeError(
                "ConstantPool.addNumber: value must be a number"
            );
        }

        return this.add(value);
    }

    addBoolean(value) {
        if (typeof value !== "boolean") {
            throw new TypeError(
                "ConstantPool.addBoolean: value must be a boolean"
            );
        }

        return this.add(value);
    }

    addAll(values) {
        if (
            values == null ||
            typeof values[Symbol.iterator] !== "function"
        ) {
            throw new TypeError(
                "ConstantPool.addAll: values must be iterable"
            );
        }

        /*
         * Materialize first. If the input iterator throws halfway
         * through, the pool is not partially modified by this call.
         */
        const batch = Array.from(values);
        const indices = new Array(batch.length);

        for (let i = 0; i < batch.length; i++) {
            indices[i] = this.add(batch[i]);
        }

        return indices;
    }

    get(index) {
        if (!this.#assertIndex(index)) {
            return undefined;
        }

        return this.#target[index];
    }

    indexOf(value) {
        this.#ensureIndex();

        const key = this.#key(value);

        return this.#index.has(key)
            ? this.#index.get(key)
            : -1;
    }

    has(value) {
        this.#ensureIndex();
        return this.#index.has(this.#key(value));
    }

    get size() {
        return this.#target.length;
    }

    getString(index) {
        const value = this.get(index);

        if (typeof value !== "string") {
            throw new TypeError(
                `ConstantPool: constant ${index} is not a string`
            );
        }

        return value;
    }

    getNumber(index) {
        const value = this.get(index);

        if (typeof value !== "number") {
            throw new TypeError(
                `ConstantPool: constant ${index} is not a number`
            );
        }

        return value;
    }

    getBoolean(index) {
        const value = this.get(index);

        if (typeof value !== "boolean") {
            throw new TypeError(
                `ConstantPool: constant ${index} is not a boolean`
            );
        }

        return value;
    }

    clear() {
        this.#target.length = 0;
        this.#index = new Map();
        this.#dirty = false;

        return this;
    }

    toArray() {
        // Return a copy, preserving holes if direct array mutation
        // introduced any.
        return Array.prototype.slice.call(this.#target);
    }

    getStats() {
        const types = Object.create(null);

        for (let i = 0; i < this.#target.length; i++) {
            /*
             * Keep the legacy behavior of counting a hole as undefined,
             * while preventing inherited prototype values from being
             * mistaken for stored constants.
             */
            const value = this.#hasOwnIndex(i)
                ? this.#target[i]
                : undefined;

            let type = value === null
                ? "null"
                : typeof value;

            if (Array.isArray(value)) {
                type = "array";
            }

            types[type] = (types[type] || 0) + 1;
        }

        return {
            size: this.#target.length,
            types
        };
    }

    /*
     * Extended diagnostics. Kept separate from getStats() so existing
     * callers that rely on its original return shape remain compatible.
     */
    getDetailedStats() {
        this.#ensureIndex();

        const types = Object.create(null);
        let entries = 0;
        let holes = 0;
        let negativeZeroCount = 0;
        let positiveZeroCount = 0;
        let nanCount = 0;

        for (let i = 0; i < this.#target.length; i++) {
            if (!this.#hasOwnIndex(i)) {
                holes++;
                continue;
            }

            entries++;

            const value = this.#target[i];

            let type = value === null
                ? "null"
                : typeof value;

            if (Array.isArray(value)) {
                type = "array";
            }

            types[type] = (types[type] || 0) + 1;

            if (typeof value === "number") {
                if (Number.isNaN(value)) {
                    nanCount++;
                } else if (Object.is(value, -0)) {
                    negativeZeroCount++;
                } else if (Object.is(value, 0)) {
                    positiveZeroCount++;
                }
            }
        }

        return {
            size: this.#target.length,
            entries,
            holes,
            uniqueCount: this.#index.size,
            duplicateCount: entries - this.#index.size,
            types,
            numbers: {
                negativeZero: negativeZeroCount,
                positiveZero: positiveZeroCount,
                nan: nanCount
            }
        };
    }

    /*
     * Rebuild the index and verify that every stored constant resolves
     * to its earliest occupied index. Useful for compiler assertions
     * and regression tests.
     */
    validate() {
        this.rebuildIndex();

        for (let i = 0; i < this.#target.length; i++) {
            if (!this.#hasOwnIndex(i)) {
                continue;
            }

            const value = this.#target[i];
            const key = this.#key(value);

            if (!this.#index.has(key)) {
                throw new Error(
                    `ConstantPool: missing index for constant ${i}`
                );
            }

            const indexedAt = this.#index.get(key);

            if (indexedAt > i) {
                throw new Error(
                    `ConstantPool: index does not point to the first occurrence at ${i}`
                );
            }
        }

        return true;
    }

    *[Symbol.iterator]() {
        /*
         * Avoid relying on a possibly overwritten iterator property
         * on the publicly exposed `items` array.
         */
        for (let i = 0; i < this.#target.length; i++) {
            yield this.#hasOwnIndex(i)
                ? this.#target[i]
                : undefined;
        }
    }
}

module.exports = {
    ConstantPool
};
"use strict";

const CODEC_VERSION = 2;
const U32_MASK = 0xFFFFFFFF;

function u8(value) {
    return Number(value) & 0xFF;
}

function u32(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number >>> 0 : 0;
}

/**
 * 32-bit avalanche mixer.
 * Tương ứng với primitive M(0, value) trong Lua runtime.
 */
function mix32(value) {
    let x = (u32(value) ^ 0xB17E4A31) >>> 0;

    x = (x ^ (x >>> 16)) >>> 0;
    x = Math.imul(x, 2246822519) >>> 0;
    x = (x ^ (x >>> 13)) >>> 0;
    x = Math.imul(x, 3266489917) >>> 0;

    return (x ^ (x >>> 16)) >>> 0;
}

function normalizeBytes(bytes) {
    if (bytes == null) return [];

    if (typeof bytes === "string") {
        return Array.from(Buffer.from(bytes, "utf8"), u8);
    }

    if (bytes instanceof ArrayBuffer) {
        return Array.from(new Uint8Array(bytes), u8);
    }

    if (ArrayBuffer.isView(bytes)) {
        return Array.from(
            new Uint8Array(
                bytes.buffer,
                bytes.byteOffset,
                bytes.byteLength
            ),
            u8
        );
    }

    if (typeof bytes[Symbol.iterator] === "function") {
        return Array.from(bytes, u8);
    }

    if (
        typeof bytes === "object" &&
        Number.isSafeInteger(bytes.length) &&
        bytes.length >= 0
    ) {
        const output = new Array(bytes.length);

        for (let i = 0; i < bytes.length; i++) {
            output[i] = u8(bytes[i]);
        }

        return output;
    }

    throw new TypeError(
        "ByteVeil encoder: expected byte data or an iterable"
    );
}

/**
 * Derive a per-byte mask from the 32-bit stream state.
 *
 * This is an obfuscation codec, not a cryptographic cipher.
 */
function nextMask(state) {
    return (
        state ^
        (state >>> 8) ^
        (state >>> 16) ^
        (state >>> 24)
    ) & 0xFF;
}

/**
 * Codec v2.
 *
 * Encoding and decoding are symmetric:
 *   plaintext[i] XOR mask[i] = encoded[i]
 *   encoded[i] XOR mask[i] = plaintext[i]
 */
function encodeBytes(bytes, key = 0x5A) {
    const input = normalizeBytes(bytes);
    const output = new Array(input.length);

    let state = mix32(
        (u32(key) ^ 0xA5D3C7E9) >>> 0
    );

    for (let i = 0; i < input.length; i++) {
        state = (
            state +
            0x9E3779B9 +
            i
        ) >>> 0;

        state = mix32(state);

        output[i] = input[i] ^ nextMask(state);
    }

    return output;
}

function decodeBytes(bytes, key = 0x5A) {
    return encodeBytes(bytes, key);
}

/**
 * Derive a codec key from independent build-scoped materials.
 *
 * The pair mixer below is intentionally equivalent to the `mix32(seed, value)`
 * primitive in protection/byte_blinder.js. Keep the same sequence in the Lua
 * VM decoder so the serialized v4.7.9 region bytes can be restored exactly.
 */
function deriveCodecKey(seed, token, variant) {
    const mixPair = (left, right) => mix32((u32(left) ^ u32(right)) >>> 0);

    let key = mixPair(seed, u32(token) ^ 0xA5D3C7E9);
    key = mixPair(key, u32(variant) ^ 0x9E3779B9);
    key = mixPair(key, 0xD3C0DEC0);
    return key >>> 0;
}

function encodeString(value, key = 0x5A) {
    return encodeBytes(
        Buffer.from(String(value), "utf8"),
        key
    );
}

function decodeString(bytes, key = 0x5A) {
    return Buffer.from(
        decodeBytes(bytes, key)
    ).toString("utf8");
}

module.exports = {
    CODEC_VERSION,
    encodeBytes,
    decodeBytes,
    encodeString,
    decodeString,
    mix32,
    deriveCodecKey
};
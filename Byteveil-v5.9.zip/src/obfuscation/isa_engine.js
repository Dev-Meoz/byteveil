"use strict";

// ByteVeil v4.5.5 unified ISA engine.
// This replaces the older parallel opcode facades with one build-aware plan.

const OPS = Object.freeze([
  "HALT","PUSHK","PUSHN","PUSHB","PUSHNIL","GETG","SETG","GETL","SETL",
  "GETI","SETI","CALLG","CALLGM","TAILCALL","ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE",
  "NOT","NEG","LEN","CONCAT","JMP","JZ","CALL","RETURN","POP","DUP","NEWTABLE","SETFIELD","GETFIELD",
  "MAKEFUNC","VARARG","VARARGS","CALLV","CALLGV","RETURNV","CALLM","AND","OR","BAND","BOR","BXOR","SHL","SHR","BNOT","BREAK","SWAP","MOVE_SELF","FORCMP","ITERPREP","ITERLOOP","SUPER","CALLP","APPEND"
]);

const SEMANTIC_CLASS = Object.freeze({
  HALT:"flow", PUSHK:"constant", PUSHN:"constant", PUSHB:"constant", PUSHNIL:"constant",
  GETG:"global", SETG:"global", GETL:"local", SETL:"local", GETI:"table", SETI:"table",
  CALLG:"call", CALLGM:"call", CALL:"call", CALLM:"call", CALLV:"call", CALLGV:"call", CALLP:"call", TAILCALL:"call", MAKEFUNC:"closure", VARARG:"vararg", VARARGS:"vararg", RETURNV:"flow",
  JMP:"flow", JZ:"flow", RETURN:"flow", BREAK:"flow", ITERPREP:"iterator", ITERLOOP:"iterator",
  NEWTABLE:"table", SETFIELD:"table", GETFIELD:"table", APPEND:"table", MOVE:"register", DUP:"register", POP:"register", SWAP:"register",
  ADD:"arith", SUB:"arith", MUL:"arith", DIV:"arith", IDIV:"arith", MOD:"arith", POW:"arith",
  EQ:"compare", NE:"compare", LT:"compare", GT:"compare", LE:"compare", GE:"compare",
  NOT:"unary", NEG:"unary", LEN:"unary", CONCAT:"string", AND:"logic", OR:"logic",
  BAND:"bitwise", BOR:"bitwise", BXOR:"bitwise", SHL:"bitwise", SHR:"bitwise", BNOT:"bitwise",
  MOVE_SELF:"method", FORCMP:"iterator", SUPER:"super"
});

function u32(n){ return Number(n) >>> 0; }
function mix(a,b){
  let s = u32(a) ^ u32(b) ^ 0x9E3779B9;
  s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}
function rng(seed){
  let s = u32(seed) || 0x6D2B79F5;
  return () => { s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0; s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0; s ^= s >>> 16; return s >>> 0; };
}
function permutation(count,next){
  const out = Array.from({length:count},(_,i)=>i);
  for(let i=count-1;i>0;i--){ const j=next()%(i+1); [out[i],out[j]]=[out[j],out[i]]; }
  return out;
}
function buildISAPlan(names, seed, options={}){
  const ops = Array.isArray(names)&&names.length ? names.slice() : OPS.slice();
  const next = rng(seed ^ 0xB17E4A31);
  const physical = permutation(ops.length,next);
  const encode = Object.create(null), decode = Object.create(null);
  physical.forEach((src,i)=>{ const name=ops[src]; encode[name]=i; decode[i]=name; });
  const lanes = [];
  const laneCount = Math.max(2, Math.min(4, Number(options.lanes||4)));
  for(let lane=0; lane<laneCount; lane++){
    const p = permutation(ops.length, rng(next() ^ Math.imul(lane+1,0x45D9F3B)));
    const map = Object.create(null);
    for(let i=0;i<ops.length;i++) map[ops[i]]=p[i]+1;
    lanes.push(map);
  }
  const operandSeed = mix(seed, ops.length * 131 + laneCount * 17);
  const variant = ops.map((name,i)=> mix(operandSeed,i+name.length*257)%8);
  return {version:"4.5.5", names:ops, encode, decode, order:physical.map(i=>ops[i]), route:ops.map(name=>encode[name]), lanes, operandVariant:variant,
    slotMul:(next()|1)>>>0, slotAdd:next()>>>0, handlerSalt:next()&0xffff, semanticClass:SEMANTIC_CLASS};
}
function deriveOperandMask(seed, physicalOpcode, pc, lane, operandIndex, variant=0){
  return mix(mix(seed, physicalOpcode*131+pc*17+lane*7+operandIndex*3), variant*97) >>> 0;
}
function deriveDispatchKey(seed, opcode){ return mix(seed, Math.imul(Number(opcode)>>>0,0x45D9F3B)); }
function deriveStatePermutation(seed,count=12){ const next=rng(seed^0xC001D00D); return permutation(Math.max(1,count|0),next).map(v=>v+1); }
function makeOpcodeMap(seed=1, options={}) { const p=buildISAPlan(OPS,seed,options); return {encode:p.encode,decode:p.decode,names:p.names.slice(), order:p.order.slice(), lanes:p.lanes, operandVariant:p.operandVariant, slotMul:p.slotMul,slotAdd:p.slotAdd,handlerSalt:p.handlerSalt}; }

module.exports={OPS,SEMANTIC_CLASS,u32,mix,rng,buildISAPlan,makeOpcodeMap,deriveOperandMask,deriveDispatchKey,deriveStatePermutation};

"use strict";

// JunkForge-v1: Luraph-density padding for the emitted body, plus the key bed
// the payload's decode key is folded out of.
//
// Why: the VM output of an ordinary script is ~130 KB, while a Luraph v15.x
// sample is a wall of encrypted long-bracket text. The forge closes that gap
// with `[==[byteveil&...]==]` containers that are *live*: five of them carry the
// key the VM activates the payload with, and the rest are covered by a digest
// seeded from that key, so deleting, truncating or flipping the block costs the
// payload rather than a few bytes of density.
//
// Container bodies are genuine VeilBlob ciphertext over random bytes, so a
// padding container decodes through the same codec as a live carrier and carries
// a valid length header. The marker text is never written in cleartext outside a
// container: the verifier only compares lengths and bytes at sampled offsets.
//
// Honest scope (see LIMITATIONS-V5.9.0.md): the *bed* fold reads every byte of
// its five containers, so any edit there changes the key. The padding fold only
// reads each container's length, four byte positions and the bank character-class
// counts — walking megabytes of padding byte by byte on every start costs more
// than padding is worth. It proves the padding set is present and unmodified at
// those points; it does not make padding undetectable.

const { createBlobCodec, lehmerRng, lehmerSeed, makeNamePool, collectUsedNames, BLOB_MARKER } = require("./veil_blob");

const FORGE_DOMAIN = 0x0E5C0DE5;
const OUTPUT_CAP_BYTES = { lua: 2_500_000, luau: 3_000_000 };
const MIN_FLOOR_BYTES = 204_800;

// Junk budget, measured in bytes added by the forge and not in total file size.
// The distinction is load-bearing: a 64 KB source already compiles to ~530 KB of VM
// payload with the forge switched off (scratch/probe_junk_caps.js), so a 400 KB
// *file* ceiling for small inputs would refuse the mandatory key bed and abort the
// build instead of shrinking it. The budget therefore caps the padding only; the
// payload is never asked to fit inside it.
const SMALL_INPUT_BYTES = 100_000;
const SMALL_INPUT_PADDING_CAP_BYTES = 400_000;
const LARGE_INPUT_PADDING_CAP_BYTES = { lua: 2_000_000, luau: 3_000_000 };
// The budget is charged against the *emitted* block, and the block is not only
// containers: every bank adds a builder call and the digest walk/verify code grows with
// the container list. The top-up loop sizes itself on the previous round's code length,
// so without a reservation the last round can overshoot the promise (measured +781 B).
// 16 KB is well above the largest realized growth (a few hundred bytes per bank) and is
// a fraction of every budget it guards.
const PADDING_CODE_MARGIN_BYTES = 16_384;
// The diagnostic-blob prelude is emitted after the forge, so padding leaves room
// for it instead of tripping the output-budget throw.
const HEADROOM_BYTES = 32_768;
const MIN_CONTAINER_TEXT = 60;

// Preset floors stay strictly ordered, so a lighter profile is always a smaller
// file than a heavier one built from the same source.
const PRESET_FLOORS = {
  l1: 204_800,
  default: 204_800,
  l2: 400_000,
  nest: 700_000,
  df: 1_200_000,
  lz: 2_000_000,
  maximum: 2_400_000
};

// Every modulus is a 31-bit prime. The digest state is a `hash*w+c` accumulator,
// so a smaller prime would put part of the padding oracle inside a brute-forceable
// range and a composite would let the accumulator collapse. With 2^31-sized states
// and weights under 100, each step stays under 2^38 and every product is exact in
// Lua 5.1/Luau double arithmetic and inside 5.3+ integer range.
const MODULUS_CHOICES = [
  2147483647, 2147483629, 2147483587, 2147483579, 2147483563, 2147483549
];
const WEIGHT_POOL = [17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97];

// ---------------------------------------------------------------------------
// Key bed: the part of the padding that the payload actually depends on.
//
// A self-contained digest block is only worth what its comparison oracle is
// worth: the expected hash sits in the output, so deleting the block and
// keeping a stub that returns the printed constant is enough to survive. The
// bed closes that hole by making the digest a *decode key* instead of a
// comparison: five containers drawn from a stream that never touches the body
// are folded into `key`, the block returns `key`, and the VM adds it to the
// runtime root seed before any payload material is derived. Delete the block
// and the activation reads nil (arithmetic error before a single payload byte
// is decoded); edit a bed container and both the key and the padding digest
// that is seeded from it go wrong.
//
// The bed is deliberately independent of the output budget: its containers come
// from `LATCH_DOMAIN` and a fixed length rule, so the same five literals exist
// whether the build pads to 200 KB or skips padding because the payload is
// already large.
//
// Unlike the padding digest, which can only afford lengths, four sampled
// positions and class counts over megabytes of text, the key fold reads *every
// byte* of the five bed containers: ~2.5 KB of ciphertext costs a few thousand
// Lua steps once per start, and in exchange a same-class flip at any position in
// the bed changes the key the payload is activated with.
// ---------------------------------------------------------------------------
const LATCH_DOMAIN = 0x1F0A6E5;
const LATCH_STREAM_SALT = 0x1AD5;
const LATCH_MODULUS = 2147483587;
const LATCH_START_HASH = 0x51F0ED1;
const LATCH_WEIGHTS = [83, 97];
const LATCH_CONTAINER_COUNT = 5;
const LATCH_NAME_ALPHABET = "abcdefghijklmnopqrstuvwxyz";
const LATCH_NAME_LENGTH = 8;

// Container-character-class counts, done by `string.gsub` in C so they cost
// microseconds per bank instead of one Lua step per byte. Four point samples
// alone would only cover ~2% of positions, so a flip somewhere else would pass;
// the counts make any edit that moves a character between classes change the
// digest, whatever its position. They are taken over the concatenated bank, which
// is why one `table.concat` per bank replaces four gsubs per container. Ranges are
// the C-locale ASCII classes, which is exactly the container alphabet.
const CLASS_COUNTS = [
  { lua: '"%a"', name: "alpha", test: (code) => (code >= 65 && code <= 90) || (code >= 97 && code <= 122) },
  { lua: '"%d"', name: "digit", test: (code) => code >= 48 && code <= 57 },
  { lua: '"%u"', name: "upper", test: (code) => code >= 65 && code <= 90 },
  { lua: '"%p"', name: "punct", test: (code) => (code >= 33 && code <= 47) || (code >= 58 && code <= 64) || (code >= 91 && code <= 96) || (code >= 123 && code <= 126) }
];

function countClass(value, test) {
  let n = 0;
  for (let i = 0; i < value.length; i++) if (test(value.charCodeAt(i))) n++;
  return n;
}

// Each expression stays inside 1..L for any L >= 60 and has a JS twin, so the
// build-time digest and the load-time digest walk exactly the same values. `L`
// is the container length and `I`/`J` are the bank/element indices, which the
// emitter binds to its own generated names.
//
// Positions below `SAMPLE_MIN_POSITION` are excluded on purpose: the container
// value starts with the nine-character blob marker, so a sample landing there
// would read a constant and prove nothing about the ciphertext underneath.
const SAMPLE_MIN_POSITION = BLOB_MARKER.length + 1;
const SAMPLE_OFFSETS = [
  { lua: ({ L }) => `${SAMPLE_MIN_POSITION}+(${L}%5)`, js: (L) => SAMPLE_MIN_POSITION + (L % 5) },
  { lua: ({ L }) => `${L}-(${L}%7)`, js: (L) => L - (L % 7) },
  { lua: ({ L }) => `math.floor(${L}/3)+1`, js: (L) => Math.floor(L / 3) + 1 },
  { lua: ({ L }) => `math.floor(${L}/2)+1`, js: (L) => Math.floor(L / 2) + 1 },
  { lua: ({ L }) => `${SAMPLE_MIN_POSITION}+(${L}%11)`, js: (L) => SAMPLE_MIN_POSITION + (L % 11) },
  { lua: ({ L }) => `${L}-(${L}%3)`, js: (L) => L - (L % 3) },
  { lua: ({ L }) => `math.floor(${L}/7)*2+1`, js: (L) => Math.floor(L / 7) * 2 + 1 },
  { lua: ({ L, I, J }) => `${SAMPLE_MIN_POSITION}+((${I}*17+${J})%(${L}-${SAMPLE_MIN_POSITION - 1}))`, js: (L, I, J) => SAMPLE_MIN_POSITION + ((I * 17 + J) % (L - SAMPLE_MIN_POSITION + 1)) }
];
const SAMPLE_SPOT_COUNT = 4;

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

function outputCapForTarget(target) {
  return OUTPUT_CAP_BYTES[String(target || "lua").toLowerCase()] || OUTPUT_CAP_BYTES.lua;
}

// How much padding this build is allowed to add. Below the small-input threshold the
// budget is the same for both targets; above it the budget follows the target, because
// a Luau payload has more room to spend. An unknown input size falls back to the large
// budget, so a caller that forgets to thread the size gets today's behaviour instead of
// a silently truncated file.
function paddingCapFor(target, inputBytes) {
  const large = LARGE_INPUT_PADDING_CAP_BYTES[String(target || "lua").toLowerCase()]
    || LARGE_INPUT_PADDING_CAP_BYTES.lua;
  const n = Number(inputBytes);
  return Number.isFinite(n) && n < SMALL_INPUT_BYTES
    ? Math.min(SMALL_INPUT_PADDING_CAP_BYTES, large)
    : large;
}

function planJunkForge({ preset = "custom", strength = 1000, target = "lua", options = {}, inputBytes = null } = {}) {
  const forge = options && typeof options.junkForge === "object" ? options.junkForge : {};
  const enabled = forge.enabled !== false && options.junkForge !== false;
  const maxBytes = clampInt(forge.maxBytes, 1, 64_000_000, outputCapForTarget(target));
  // `null` is the "not told" sentinel, and `Number(null)` is 0, which would silently read as
  // a zero-byte input and put every build under the small budget. Only a real number counts.
  const sourceBytes = inputBytes === null || inputBytes === undefined
    ? Number(options.junkForgeSourceBytes)
    : Number(inputBytes);
  const paddingCapBytes = clampInt(forge.paddingCapBytes, 1, 64_000_000, paddingCapFor(target, sourceBytes));
  const namedFloor = PRESET_FLOORS[String(preset || "custom").toLowerCase()];
  // Unnamed/custom profiles scale with strength so the floor still means
  // something for hand-tuned builds.
  const scaledFloor = namedFloor !== undefined
    ? namedFloor
    : MIN_FLOOR_BYTES + Math.max(0, clampInt(strength, 100, 10_000, 1000) - 1000) * 24;
  const floorBytes = clampInt(forge.floorBytes, 0, maxBytes, Math.min(scaledFloor, maxBytes));
  return {
    engine: "JunkForge-v1",
    enabled,
    floorBytes,
    maxBytes,
    paddingCapBytes,
    inputBytes: Number.isFinite(sourceBytes) ? Math.floor(sourceBytes) : null,
    headroomBytes: clampInt(forge.headroomBytes, 0, 1_048_576, HEADROOM_BYTES),
    containerMinBytes: clampInt(forge.containerMinBytes, MIN_CONTAINER_TEXT, 4096, 200),
    containerMaxBytes: clampInt(forge.containerMaxBytes, MIN_CONTAINER_TEXT, 8192, 600),
    bankMin: clampInt(forge.bankMin, 1, 512, 8),
    bankMax: clampInt(forge.bankMax, 1, 512, 32)
  };
}

function runtimeValue(literal) {
  const match = /^\[(=*)\[([\s\S]*)\]\1\]$/.exec(String(literal));
  if (!match) throw new Error("JunkForge-v1: container is not a long-bracket literal");
  return match[2];
}

// One padding container. Same call in the latch plan and in the block builder, so
// a bed container is byte-identical no matter which stage of the pipeline drew it.
function drawContainer(rng, codec, profile) {
  const span = profile.containerMinBytes + (rng() % (profile.containerMaxBytes - profile.containerMinBytes + 1));
  const payload = Buffer.alloc(Math.max(1, Math.floor((span - 17) * 3 / 4)));
  for (let i = 0; i < payload.length; i++) {
    const draw = rng();
    payload[i] = (draw + Math.floor(draw / 65536) * 7) % 256;
  }
  return codec.renderBlob(payload);
}

// 8 lowercase letters can never collide with the engine's own pools (4-5 chars,
// digits allowed) and are long enough that a body identifier matching one by
// chance is not a case worth engineering around. `function` and Luau's
// `continue` are the only keywords of this shape.
const LATCH_RESERVED = new Set(["function", "continue"]);

function pickDistinct(rng, source, count) {
  const pool = source.slice();
  const out = [];
  while (out.length < count && pool.length) {
    const at = rng() % pool.length;
    out.push(pool[at]);
    pool.splice(at, 1);
  }
  if (out.length !== count) throw new Error(`JunkForge-v1: unable to draw ${count} distinct parameters`);
  return out;
}

/**
 * The load-time key the payload is activated with. Deliberately independent of
 * the body: the containers, the fold parameters and the holder name all come out
 * of a dedicated stream, so the same key is available before the VM body exists
 * and the emitted block can hand it back at load time.
 */
function planForgeLatch({ seed = 1, preset = "custom", strength = 1000, target = "lua", options = {} } = {}) {
  const profile = planJunkForge({ preset, strength, target, options });
  if (!profile.enabled) return { enabled: false, reason: "disabled", holderName: null, containers: [], key: 0 };
  const buildSeed = (Number(seed) >>> 0) ^ FORGE_DOMAIN;
  const rng = lehmerRng(lehmerSeed(buildSeed ^ LATCH_DOMAIN, LATCH_STREAM_SALT));
  const codec = createBlobCodec(buildSeed >>> 0);
  let holderName = "";
  while (!holderName) {
    let name = LATCH_NAME_ALPHABET[rng() % LATCH_NAME_ALPHABET.length];
    for (let i = 1; i < LATCH_NAME_LENGTH; i++) name += LATCH_NAME_ALPHABET[rng() % LATCH_NAME_ALPHABET.length];
    if (!LATCH_RESERVED.has(name)) holderName = name;
  }
  const containers = [];
  for (let i = 0; i < LATCH_CONTAINER_COUNT; i++) containers.push(drawContainer(rng, codec, profile));
  // Length first, then every byte: a flip that keeps its character class still moves the
  // key, which the sampled-position-only padding fold cannot promise.
  let key = LATCH_START_HASH;
  for (const literal of containers) {
    const value = runtimeValue(literal);
    if (value.length < MIN_CONTAINER_TEXT) throw new Error(`JunkForge-v1: latch container ${value.length} is below the sampled minimum`);
    if (/[\s\\]/.test(value)) throw new Error("JunkForge-v1: latch container text escaped the container alphabet");
    key = (key * LATCH_WEIGHTS[0] + value.length) % LATCH_MODULUS;
    for (let i = 0; i < value.length; i++) key = (key * LATCH_WEIGHTS[1] + value.charCodeAt(i)) % LATCH_MODULUS;
  }
  return {
    enabled: true,
    holderName,
    containers,
    key,
    modulus: LATCH_MODULUS,
    weights: LATCH_WEIGHTS.slice(),
    startHash: LATCH_START_HASH,
    literalBytes: containers.reduce((acc, lit) => acc + lit.length + 1, 0)
  };
}

/**
 * Statement prefix that can host a `local`/expression statement. Returns -1 when
 * the body does not start at a statement boundary, in which case no padding is
 * emitted rather than risking a syntax error.
 */
function statementInsertionPoint(body) {
  let at = 0;
  const newline = String(body).indexOf("\n");
  if (newline >= 0 && /^\s*--/.test(String(body).slice(0, newline))) at = newline + 1;
  return /^(?:return|local|do|if|for|while|repeat|;|\()/.test(String(body).slice(at)) ? at : -1;
}

/**
 * @returns {{applied:boolean, reason?:string, prefix?:string, bytes:number, paddingBytes:number, latchBytes:number,
 *            latchKey:number, holderName:string, containers:number, banks:number}}
 */
function applyJunkForge({ body = "", seed = 1, target = "lua", preset = "custom", strength = 1000, options = {}, plan = null, latch = null } = {}) {
  const profile = plan || planJunkForge({ preset, strength, target, options });
  const binding = latch || planForgeLatch({ seed, preset, strength, target, options });
  const source = String(body);
  const baseBytes = Buffer.byteLength(source, "utf8");
  const insertAt = statementInsertionPoint(source);
  const holderName = binding.holderName || "";

  const noop = (reason, extra = {}) => ({
    applied: false,
    reason,
    prefix: "",
    insertAt: -1,
    bytes: 0,
    paddingBytes: 0,
    latchBytes: 0,
    containers: 0,
    banks: 0,
    latchKey: binding.enabled ? binding.key : 0,
    holderName,
    floorBytes: profile.floorBytes,
    maxBytes: profile.maxBytes,
    paddingCapBytes: profile.paddingCapBytes,
    baseBytes,
    ...extra
  });

  if (!profile.enabled || !binding.enabled) return noop("disabled");
  if (!binding.containers.length || !holderName) return noop("no-latch-binding");
  if (insertAt < 0) return noop("no-statement-boundary");

  const buildSeed = (Number(seed) >>> 0) ^ FORGE_DOMAIN;
  const rng = lehmerRng(lehmerSeed(buildSeed, 0x0E5C));
  const codec = createBlobCodec(buildSeed >>> 0);
  const usedNames = collectUsedNames(source);
  usedNames.add(holderName);
  const names = makeNamePool(rng, usedNames, 20);
  const [bankTable, bankFns, bankIndex, bailName, nilName, hashName, modName, bankLoop, rowIndex, elementLoop,
    textName, lenName, joinedName, bedTable, bedLoop, bedText, bedLen, keyName, bedModName, bedByteLoop] = names;
  const bindings = { L: lenName, I: bankLoop, J: elementLoop };
  const modulus = MODULUS_CHOICES[rng() % MODULUS_CHOICES.length];
  const weights = pickDistinct(rng, WEIGHT_POOL, 1 + SAMPLE_SPOT_COUNT + CLASS_COUNTS.length + 2);
  const [wLen, ...restWeights] = weights;
  const byteWeights = restWeights.slice(0, SAMPLE_SPOT_COUNT);
  const classWeights = restWeights.slice(SAMPLE_SPOT_COUNT, SAMPLE_SPOT_COUNT + CLASS_COUNTS.length);
  const [seedMul, seedSalt] = restWeights.slice(SAMPLE_SPOT_COUNT + CLASS_COUNTS.length);
  const offsets = pickDistinct(rng, SAMPLE_OFFSETS, SAMPLE_SPOT_COUNT);

  const emitContainer = () => drawContainer(rng, codec, profile);

  // Bank boundaries come from their own stream, so re-partitioning a grown
  // container list keeps every earlier boundary and the digest stays reproducible.
  const partition = (count) => {
    const sizeRng = lehmerRng(lehmerSeed(buildSeed ^ 0x51CE5, 0x8A47));
    const banks = [];
    let remaining = count;
    while (remaining > 0) {
      const size = Math.min(remaining, profile.bankMin + (sizeRng() % (profile.bankMax - profile.bankMin + 1)));
      banks.push(size);
      remaining -= size;
    }
    return banks;
  };

  // The five bed containers are emitted verbatim and re-folded at load time with
  // the engine constants planForgeLatch used, so the returned key is the same
  // number the build activated the payload with. The walk is byte-complete: the
  // bed is ~2.5 KB, so full coverage costs a few thousand steps once per start.
  const bedFold =
    `local ${bedTable}={${binding.containers.join(",")}} ` +
    `local ${keyName}=${binding.startHash} local ${bedModName}=${binding.modulus} ` +
    `for ${bedLoop}=1,#${bedTable} do local ${bedText}=${bedTable}[${bedLoop}] ` +
    `local ${bedLen}=#${bedText} if ${bedLen}<${MIN_CONTAINER_TEXT} then ${bailName}() end ` +
    `${keyName}=(${keyName}*${LATCH_WEIGHTS[0]}+${bedLen})%${bedModName} ` +
    `for ${bedByteLoop}=1,${bedLen} do ${keyName}=(${keyName}*${LATCH_WEIGHTS[1]}+string.byte(${bedText},${bedByteLoop}))%${bedModName} end ` +
    `end `;

  const bailDecl =
    `local ${bailName}=function()local ${nilName}=({})[1] return ${nilName}.k end `;

  const seal = (containers) => {
    const banks = partition(containers.length);
    let hash = (binding.key * seedMul + seedSalt) % modulus;
    let cursor = 0;
    for (let bankAt = 1; bankAt <= banks.length; bankAt++) {
      let joined = "";
      for (let element = 1; element <= banks[bankAt - 1]; element++) {
        const value = runtimeValue(containers[cursor++]);
        if (value.length < MIN_CONTAINER_TEXT) throw new Error(`JunkForge-v1: container text ${value.length} is below the sampled minimum`);
        if (/[\s\\]/.test(value)) throw new Error("JunkForge-v1: container text escaped the class-count alphabet");
        joined += value;
        hash = (hash * wLen + value.length) % modulus;
        for (let k = 0; k < offsets.length; k++) {
          const position = offsets[k].js(value.length, bankAt, element);
          if (position < 1 || position > value.length) throw new Error(`JunkForge-v1: sample offset ${position} outside container`);
          hash = (hash * byteWeights[k] + value.charCodeAt(position - 1)) % modulus;
        }
      }
      for (let k = 0; k < CLASS_COUNTS.length; k++) {
        hash = (hash * classWeights[k] + countClass(joined, CLASS_COUNTS[k].test)) % modulus;
      }
    }
    const hasPadding = containers.length > 0;
    let bankBodies = "";
    let bankDecl = "";
    let bankWalk = "";
    let bankVerify = "";
    if (hasPadding) {
      cursor = 0;
      const body = [];
      for (const size of banks) {
        body.push(`function()${bankTable}[#${bankTable}+1]={${containers.slice(cursor, cursor + size).join(",")}}end`);
        cursor += size;
      }
      const elementAccum =
        `${hashName}=(${hashName}*${wLen}+${lenName})%${modName} ` +
        offsets.map((offset, k) =>
          `${hashName}=(${hashName}*${byteWeights[k]}+string.byte(${textName},${offset.lua(bindings)}))%${modName} `).join("");
      const bankAccum =
        CLASS_COUNTS.map((klass, k) =>
          `${hashName}=(${hashName}*${classWeights[k]}+select(2,${joinedName}:gsub(${klass.lua},"")))%${modName} `).join("");
      bankDecl = `local ${bankTable}={} local ${bankFns}={${body.join(",")}} for ${bankIndex}=1,#${bankFns} do ${bankFns}[${bankIndex}]() end `;
      bankWalk =
        `for ${bankLoop}=1,#${bankTable} do local ${rowIndex}=${bankTable}[${bankLoop}] ` +
        `for ${elementLoop}=1,#${rowIndex} do local ${textName}=${rowIndex}[${elementLoop}] ` +
        `local ${lenName}=#${textName} if ${lenName}<${MIN_CONTAINER_TEXT} then ${bailName}() end ${elementAccum}` +
        `end local ${joinedName}=table.concat(${rowIndex}) ${bankAccum}` +
        `end `;
      bankVerify = `if ${hashName}~=${hash} then ${bailName}() end `;
    }
    // The block opens with `local` on purpose: the diagnostic encoder only inserts
    // its runtime in front of a body that starts on a statement keyword, so an
    // expression-statement prefix would push the whole build back to decimal
    // escapes. One extra top-level local is also what the rest of the output looks like.
    const prefix =
      `local ${holderName}=(function()${bankDecl}${bailDecl}${bedFold}` +
      (hasPadding ? `local ${modName}=${modulus} local ${hashName}=(${keyName}*${seedMul}+${seedSalt})%${modName} ${bankWalk}` : "") +
      `${bankVerify}return ${keyName} end)();`;
    return {
      prefix,
      hash,
      banks: banks.length,
      offsetExprs: offsets.map((offset) => offset.lua(bindings)),
      overheadBytes: Buffer.byteLength(prefix, "utf8") - containers.reduce((acc, lit) => acc + lit.length + 1, 0)
    };
  };

  const bedOnly = seal([]);
  const latchBytes = Buffer.byteLength(bedOnly.prefix, "utf8");

  const emit = (prefix, paddingBytes, sealed, extra = {}) => {
    const bytes = Buffer.byteLength(prefix, "utf8");
    if (baseBytes + bytes > profile.maxBytes) return noop("would-exceed-cap");
    return {
      applied: true,
      engine: profile.engine,
      prefix,
      insertAt,
      bytes,
      paddingBytes,
      latchBytes,
      containers: extra.containers ?? 0,
      banks: sealed.banks,
      digest: sealed.hash,
      latchKey: binding.key,
      holderName,
      latchContainers: binding.containers.length,
      latchTextBytes: binding.containers.reduce((acc, lit) => acc + runtimeValue(lit).length, 0),
      modulus,
      weights,
      classes: CLASS_COUNTS.map((klass) => klass.name),
      offsets: sealed.offsetExprs,
      partial: extra.partial ?? false,
      floorBytes: profile.floorBytes,
      maxBytes: profile.maxBytes,
      paddingCapBytes: profile.paddingCapBytes,
      capBinding: extra.partial === true ? capBinding : null,
      headroomBytes: profile.headroomBytes,
      baseBytes,
      ...extra.fields
    };
  };

  // A body that already clears the floor gets the bed without the padding: the
  // payload still needs the key, and the key does not depend on how big the file is.
  if (baseBytes >= profile.floorBytes) {
    return emit(bedOnly.prefix, 0, bedOnly, { containers: 0, fields: { reason: "key-bed-only" } });
  }

  // The digest is only known once the container list is final, and the code
  // length feeds back into how much padding the floor needs, so top up, re-seal
  // and repeat until the floor is met or the remaining room is used up.
  // Two rooms have to be respected: the output envelope still has to hold the payload
  // plus the block, and the junk budget says how much of the file may be *added*. The
  // smaller one binds, and which one it was is reported so a capped file is never
  // mistaken for a payload that simply did not need padding.
  const envelopeRoom = Math.max(0, profile.maxBytes - profile.headroomBytes - baseBytes);
  // A hand-built plan (the module is public API) may predate the budget field; without a
  // number here the room comparison turns into NaN and the top-up loop never stops early.
  const budget = Number.isFinite(Number(profile.paddingCapBytes)) ? Number(profile.paddingCapBytes) : profile.maxBytes;
  const roomBytes = Math.min(envelopeRoom, Math.max(0, budget - PADDING_CODE_MARGIN_BYTES));
  const capBinding = budget - PADDING_CODE_MARGIN_BYTES < envelopeRoom ? "junk-budget" : "output-envelope";
  const containers = [];
  let sealed = null;
  let literalBytes = 0;
  for (let round = 0; round < 10; round++) {
    const overhead = sealed ? sealed.overheadBytes : 1024;
    let grew = false;
    while (literalBytes + overhead < profile.floorBytes - baseBytes) {
      if (literalBytes + profile.containerMaxBytes + overhead > roomBytes) break;
      const literal = emitContainer();
      containers.push(literal);
      literalBytes += literal.length + 1;
      grew = true;
    }
    sealed = seal(containers);
    if (!grew) break;
    if (baseBytes + Buffer.byteLength(sealed.prefix, "utf8") >= profile.floorBytes) break;
    if (baseBytes + Buffer.byteLength(sealed.prefix, "utf8") >= profile.maxBytes - profile.headroomBytes) break;
  }

  if (!sealed || !containers.length) {
    // No room to pad, but the key bed is still mandatory for activation, so emit
    // it on its own and report the padding as skipped.
    return emit(bedOnly.prefix, 0, bedOnly, { containers: 0, reason: "no-room", fields: { skippedPadding: true } });
  }
  const padded = emit(sealed.prefix, Buffer.byteLength(sealed.prefix, "utf8") - latchBytes, sealed, {
    containers: containers.length,
    partial: baseBytes + Buffer.byteLength(sealed.prefix, "utf8") < profile.floorBytes
  });
  if (!padded.applied) return emit(bedOnly.prefix, 0, bedOnly, { containers: 0, reason: padded.reason, fields: { skippedPadding: true } });
  return padded;
}

module.exports = {
  FORGE_DOMAIN,
  OUTPUT_CAP_BYTES,
  MIN_FLOOR_BYTES,
  SMALL_INPUT_BYTES,
  SMALL_INPUT_PADDING_CAP_BYTES,
  LARGE_INPUT_PADDING_CAP_BYTES,
  PADDING_CODE_MARGIN_BYTES,
  HEADROOM_BYTES,
  MIN_CONTAINER_TEXT,
  PRESET_FLOORS,
  LATCH_DOMAIN,
  LATCH_MODULUS,
  LATCH_START_HASH,
  LATCH_WEIGHTS,
  LATCH_CONTAINER_COUNT,
  planJunkForge,
  planForgeLatch,
  outputCapForTarget,
  paddingCapFor,
  applyJunkForge,
  runtimeValue,
  statementInsertionPoint
};

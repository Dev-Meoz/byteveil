"use strict";

const { makeOpcodeMap } = require("./isa_engine");

function shuffle(seed = 1, options = {}) {
    if (
        options == null ||
        typeof options !== "object" ||
        Array.isArray(options)
    ) {
        throw new TypeError(
            "opcode shuffle: options must be an object"
        );
    }

    const normalizedSeed = Number(seed) >>> 0;
    const plan = makeOpcodeMap(normalizedSeed, options);

    if (
        !plan ||
        !Array.isArray(plan.names) ||
        !plan.encode ||
        !plan.decode
    ) {
        throw new Error(
            "ByteVeil opcode shuffle: ISA engine returned an invalid plan"
        );
    }

    const seen = new Set();

    for (const name of plan.names) {
        const encoded = plan.encode[name];

        if (
            !Number.isInteger(encoded) ||
            encoded < 0 ||
            encoded >= plan.names.length
        ) {
            throw new Error(
                `ByteVeil opcode shuffle: invalid opcode slot for ${name}`
            );
        }

        if (seen.has(encoded)) {
            throw new Error(
                `ByteVeil opcode shuffle: slot collision at ${encoded}`
            );
        }

        if (plan.decode[encoded] !== name) {
            throw new Error(
                `ByteVeil opcode shuffle: reverse mapping mismatch for ${name}`
            );
        }

        seen.add(encoded);
    }

    if (seen.size !== plan.names.length) {
        throw new Error(
            "ByteVeil opcode shuffle: mapping is not bijective"
        );
    }

    // Trả plan riêng để caller không sửa trực tiếp map nội bộ.
    return {
        ...plan,
        encode: Object.assign(
            Object.create(null),
            plan.encode
        ),
        decode: Object.assign(
            Object.create(null),
            plan.decode
        ),
        names: plan.names.slice(),
        order: Array.isArray(plan.order)
            ? plan.order.slice()
            : [],
        lanes: Array.isArray(plan.lanes)
            ? plan.lanes.map((lane) =>
                Object.assign(Object.create(null), lane)
            )
            : [],
        operandVariant: Array.isArray(plan.operandVariant)
            ? plan.operandVariant.slice()
            : []
    };
}

module.exports = { shuffle };
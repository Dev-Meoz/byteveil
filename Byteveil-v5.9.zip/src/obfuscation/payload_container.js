/* ByteCode payload containers. Lua keeps the proven numeric-shard path;
 * Luau v2.8 can opt into the compact printable shard path. */
"use strict";

const { makeNumericContainer } = require("./payload_container_v29");

function u32(n) { return Number(n) >>> 0; }

function mix(seed) {
    let s = u32(seed ^ 0x6D2B79F5);
    return function next() {
        s = u32(Math.imul(s ^ (s >>> 15), 1 | s));
        s ^= s + u32(Math.imul(s ^ (s >>> 7), 61 | s));
        return u32(s ^ (s >>> 14));
    };
}

function makeFragment(bytes, start, length) {
    return bytes.slice(start, start + length);
}

function decoyBytes(next, length) {
    const out = new Array(length);
    for (let i = 0; i < length; i++) out[i] = next() & 0xFF;
    return out;
}

function luaNumberArray(arr) { return `{${arr.join(",")}}`; }

function makeNumericPayloadContainer(bytes, seed, options = {}) {
    const next = mix(seed);
    const min = options.minShard || 19;
    const max = options.maxShard || 47;
    const decoyCount = options.decoys ?? Math.max(8, Math.ceil(bytes.length / 96));
    const entries = [];
    const actualIds = [];
    let offset = 0;

    while (offset < bytes.length) {
        const span = min + (next() % (max - min + 1));
        const frag = makeFragment(bytes, offset, Math.min(span, bytes.length - offset));
        const id = entries.length;
        entries.push({ d: frag, a: true, seq: actualIds.length });
        actualIds.push(id);
        offset += frag.length;
        if ((next() & 3) === 0) {
            const decoyLen = min + (next() % (max - min + 1));
            entries.push({ d: decoyBytes(next, decoyLen), a: false });
        }
    }
    for (let i = 0; i < decoyCount; i++) {
        const length = min + (next() % (max - min + 1));
        entries.push({ d: decoyBytes(next, length), a: false });
    }
    for (let i = entries.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [entries[i], entries[j]] = [entries[j], entries[i]];
    }
    const physicalActual = [];
    for (let i = 0; i < entries.length; i++) if (entries[i].a) physicalActual.push(i);
    const order = physicalActual.slice().sort((a, b) => entries[a].seq - entries[b].seq);
    const entryCode = entries.map(entry => luaNumberArray(entry.d)).join(",");
    const runtime = `(function(C,O)local R={};local U=table.unpack or unpack;for I=1,#O do local N=C[O[I]];R[#R+1]=string.char(U(N))end;return table.concat(R)end)({${entryCode}},{${order.map(v => v + 1).join(",")}})`;
    return { expression: runtime, entryCount: entries.length, shardCount: physicalActual.length, decoyCount: entries.length - physicalActual.length, format: "numeric" };
}

const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function base64Encode(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i += 3) {
        const a = bytes[i] ?? 0;
        const b = bytes[i + 1];
        const c = bytes[i + 2];
        out += B64[a >> 2];
        out += B64[((a & 3) << 4) | ((b ?? 0) >> 4)];
        out += b === undefined ? "=" : B64[((b & 15) << 2) | ((c ?? 0) >> 6)];
        out += c === undefined ? "=" : B64[c & 63];
    }
    return out;
}

function makeCompactPayloadContainer(bytes, seed, options = {}) {
    const next = mix(seed ^ 0x51ED2708);
    const min = options.minShard || 45;
    const max = options.maxShard || 95;
    const decoyCount = options.decoys ?? Math.max(6, Math.ceil(bytes.length / 160));
    const entries = [];
    let seq = 0;
    for (let offset = 0; offset < bytes.length;) {
        const span = min + (next() % (max - min + 1));
        const frag = makeFragment(bytes, offset, Math.min(span, bytes.length - offset));
        entries.push({ d: base64Encode(frag), a: true, seq: seq++ });
        offset += frag.length;
        if ((next() & 7) === 0) {
            const decoy = decoyBytes(next, min + (next() % (max - min + 1)));
            entries.push({ d: base64Encode(decoy), a: false });
        }
    }
    for (let i = 0; i < decoyCount; i++) {
        const decoy = decoyBytes(next, min + (next() % (max - min + 1)));
        entries.push({ d: base64Encode(decoy), a: false });
    }
    for (let i = entries.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [entries[i], entries[j]] = [entries[j], entries[i]];
    }
    const actual = [];
    for (let i = 0; i < entries.length; i++) if (entries[i].a) actual.push([entries[i].seq, i + 1]);
    actual.sort((a, b) => a[0] - b[0]);

    const chunkCode = entries.map(e => JSON.stringify(e.d)).join(",");
    const orderCode = actual.map(x => x[1]).join(",");
    const runtime = `(function(C,O)local A="${B64}";local R={};local function D(S)local T={};local n=1;while n<=#S do local a=string.find(A,S:sub(n,n),1,true)-1;local b=string.find(A,S:sub(n+1,n+1),1,true)-1;local c0=S:sub(n+2,n+2);local d0=S:sub(n+3,n+3);if c0=="=" then c0=0 else c0=string.find(A,c0,1,true)-1 end;if d0=="=" then d0=0 else d0=string.find(A,d0,1,true)-1 end;local x=a*4+math.floor(b/16);T[#T+1]=string.char(x);if S:sub(n+2,n+2)~="=" then T[#T+1]=string.char((b%16)*16+math.floor(c0/4)) end;if S:sub(n+3,n+3)~="=" then T[#T+1]=string.char((c0%4)*64+d0) end;n=n+4 end;return table.concat(T)end;for I=1,#O do R[I]=D(C[O[I]])end;return table.concat(R)end)({${chunkCode}},{${orderCode}})`;
    return { expression: runtime, entryCount: entries.length, shardCount: actual.length, decoyCount: entries.length - actual.length, format: "compact-base64" };
}

function makePayloadContainer(bytes, seed, options = {}) {
    if (options.format === "opaque85") return makeNumericContainer(bytes, seed, options);
    if (options.format === "compact") return makeCompactPayloadContainer(bytes, seed, options);
    return makeNumericPayloadContainer(bytes, seed, options);
}

module.exports = { makePayloadContainer, makeNumericPayloadContainer, makeCompactPayloadContainer, base64Encode };

"use strict";

/*
 * ByteCode v2.9 payload container.
 *
 * The container intentionally contains no executable junk blocks. It stores
 * transformed bytes in small printable shards, then keeps the reconstruction
 * order separate from the physical payload order. v3.2 can add inert decoy shards.
 */

const { UNIFIED_ALPHABET } = require("./blob_alphabet");

// Payload shards share the unified 94-character printable alphabet with the
// VeilBlob container route; keeping two different character sets let a static
// reader sort containers by which alphabet they used.
const ALPHABET = UNIFIED_ALPHABET;
const RADIX = ALPHABET.length;
const POW24 = 0x1000000;
const POW16 = 0x10000;
const MOD32 = 0x100000000;

function u32(n) { return Number(n) >>> 0; }

function mix(seed) {
    let s = u32(seed ^ 0xC2B2AE35) || 0x9E3779B9;
    return function next() {
        const lo = s % 65536;
        const hi = Math.floor(s / 65536);
        s = (lo * 32671 + hi * 251 + 977 * ((s % 4096) + 1)) % MOD32;
        s = (s + Math.floor(s / 65536) * 29 + 0x7F4A7C15) % MOD32;
        s = u32(s ^ Math.floor(s / 8192));
        return s;
    };
}

function base85Encode(bytes) {
    const input = Array.from(bytes || []);
    let out = "";
    for (let i = 0; i < input.length; i += 4) {
        const a = input[i] || 0;
        const b = i + 1 < input.length ? input[i + 1] : 0;
        const c = i + 2 < input.length ? input[i + 2] : 0;
        const d = i + 3 < input.length ? input[i + 3] : 0;
        let v = a * POW24 + b * POW16 + c * 256 + d;
        const row = new Array(5);
        for (let j = 4; j >= 0; j--) {
            row[j] = ALPHABET[v % RADIX];
            v = Math.floor(v / RADIX);
        }
        out += row.join("");
    }
    return out;
}

function decoyBytes(next, length) {
    const out = new Uint8Array(length);
    for (let i = 0; i < length; i++) out[i] = next() & 0xFF;
    return out;
}

function weirdRuntimeNames(seed) {
    let state = (Number(seed) >>> 0) ^ 0x6D2B79F5;
    const used = new Set();
    const first = "lIOQxZzYyAaEeUuNnMmWwVvKkHhRrTtPp";
    const rest = "lI0OqQxXzZyYvVwWmMnNaAeEiIoOuUcCsSdDfFgGhHjJk";
    const digits = "0135792468";

    function next() {
        state ^= state >>> 16;
        state = Math.imul(state, 2246822519) >>> 0;
        state ^= state >>> 13;
        state = Math.imul(state, 3266489917) >>> 0;
        state ^= state >>> 16;
        return state >>> 0;
    }

    function name() {
        for (;;) {
            const seedA = next();
            const length = 7 + (seedA % 7);
            let out = first[seedA % first.length];
            for (let i = 1; i < length; i++) {
                const value = next();
                if (value % 13 === 0 || value % 17 === 0) out += "_";
                else if (value % 5 === 0) out += digits[value % digits.length];
                else out += rest[value % rest.length];
            }
            out += "_" + used.size.toString(36);
            if (!used.has(out)) {
                used.add(out);
                return out;
            }
        }
    }

    return {
        outerC: name(),
        outerO: name(),
        alphabet: name(),
        result: name(),
        decode: name(),
        text: name(),
        index: name(),
        value: name(),
        charValue: name(),
        inner: name(),
        orderLen: name(),
        order: name(),
        offset: name()
    };
}

function makeContainer(bytes, seed, options = {}) {
    const next = mix(seed ^ 0x71E33A19);
    const rawMin = Math.max(48, Number(options.minShard || 88));
    const rawMax = Math.max(rawMin, Number(options.maxShard || 156));
    const minShard = Math.ceil(rawMin / 4) * 4;
    const maxShard = Math.max(minShard, Math.floor(rawMax / 4) * 4);
    const decoyCount = Math.max(0, Math.floor(Number(options.decoys) || 0));
    const entries = [];
    const actual = [];

    for (let offset = 0, seq = 0; offset < bytes.length; seq++) {
        const span = minShard + ((next() % (Math.floor((maxShard - minShard) / 4) + 1)) * 4);
        const frag = bytes.slice(offset, Math.min(bytes.length, offset + span));
        entries.push({ data: base85Encode(frag), actual: true, seq });
        actual.push(entries.length - 1);
        offset += frag.length;
    }

    for (let i = 0; i < decoyCount; i++) {
        const length = minShard + ((next() % (Math.floor((maxShard - minShard) / 4) + 1)) * 4);
        entries.push({ data: base85Encode(decoyBytes(next, length)), actual: false });
    }

    for (let i = entries.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [entries[i], entries[j]] = [entries[j], entries[i]];
    }

    const order = [];
    for (let i = 0; i < entries.length; i++) {
        if (entries[i].actual) order[entries[i].seq] = i + 1;
    }

    const encodedEntries = entries.map((entry) => JSON.stringify(entry.data)).join(",");
    const orderBytes = [order.length & 0xFF, (order.length >>> 8) & 0xFF];
    for (const x of order) orderBytes.push(x & 0xFF, (x >>> 8) & 0xFF);
    const orderString = base85Encode(Buffer.from(orderBytes));

    const n = weirdRuntimeNames(seed);
    const runtime = [
        `(function(${n.outerC},${n.outerO})`,
        `local ${n.alphabet}=${JSON.stringify(ALPHABET)}`,
        `local ${n.result}={}`,
        `local function ${n.decode}(${n.text})`,
        `local ${n.inner}={}`,
        `for ${n.index}=1,#${n.text},5 do`,
        `local ${n.value}=0`,
        `for ${n.offset}=0,4 do`,
        `${n.value}=${n.value}*${RADIX}+(string.find(${n.alphabet},${n.text}:sub(${n.index}+${n.offset},${n.index}+${n.offset}),1,true)-1)`,
        `end`,
        `${n.inner}[#${n.inner}+1]=string.char(math.floor(${n.value}/16777216)%256,math.floor(${n.value}/65536)%256,math.floor(${n.value}/256)%256,${n.value}%256)`,
        `end`,
        `return table.concat(${n.inner})`,
        `end`,
        `local ${n.orderLen}=${n.decode}(${n.outerO})`,
        `local ${n.order}={}`,
        `for ${n.index}=1,((string.byte(${n.orderLen},1)or 0)+((string.byte(${n.orderLen},2)or 0)*256)) do`,
        `local ${n.offset}=2+${n.index}*2-1`,
        `${n.order}[${n.index}]=string.byte(${n.orderLen},${n.offset})+((string.byte(${n.orderLen},${n.offset}+1)or 0)*256)`,
        `end`,
        `for ${n.index}=1,#${n.order} do`,
        `${n.result}[#${n.result}+1]=${n.decode}(${n.outerC}[${n.order}[${n.index}]])`,
        `end`,
        `return table.concat(${n.result})`,
        `end)({${encodedEntries}},${JSON.stringify(orderString)})`
    ].join("\n");

    return {
        expression: runtime,
        entryCount: entries.length,
        shardCount: actual.length,
        decoyCount: entries.length - actual.length,
        format: `v29-radix${RADIX}-sharded`,
        alphabetLength: ALPHABET.length
    };
}



/*
 * v3.9 opaque transport. Unlike the legacy container, it returns only
 * radix-93 printable shards; the generated VM decodes them to numeric bytes.
 * No string.char is required in the protected output.
 */
function shardMaskByte(seed, seq, index, lane) {
    const domain = u32(
        Math.imul((Number(seq) >>> 0) + 1, 0x45D9F3B) ^
        Math.imul((Number(index) >>> 0) + 1, 0x27D4EB2F) ^
        Math.imul((Number(lane) >>> 0) + 1, 0x9E3779B1)
    );
    let x = u32((Number(seed) >>> 0) ^ domain ^ 0xB17E4A31);
    x = Math.imul(x ^ (x >>> 16), 2246822519) >>> 0;
    x = Math.imul(x ^ (x >>> 13), 3266489917) >>> 0;
    x = u32(x ^ (x >>> 16));
    return x & 0xFF;
}

function protectShard(bytes, seed, seq, lane = 0) {
    const out = Array.from(bytes || [], (v) => Number(v) & 0xFF);
    for (let i = 0; i < out.length; i++) {
        const a = shardMaskByte(seed, seq, i, lane);
        const b = shardMaskByte(seed ^ 0xC0FFEE11, seq, i, lane + 1);
        const c = shardMaskByte(seed ^ 0x7A51BEEF, seq, i, lane + 2);
        out[i] = (((out[i] ^ a) + b) ^ c) & 0xFF;
    }
    return out;
}

function makeNumericContainer(bytes, seed, options = {}) {
    const next = mix(seed ^ 0x38A5EED);
    const shardMaskSeed = u32(Number(options.shardMaskSeed ?? (seed ^ 0xB17E4A31)));

    const rawMin = Math.max(40, Number(options.minShard || 88));
    const rawMax = Math.max(rawMin, Number(options.maxShard || (Number(options.strength || 0) >= 8000 ? 196 : 152)));
    const min = Math.max(4, Math.ceil(rawMin / 4) * 4);
    const max = Math.max(min, Math.floor(rawMax / 4) * 4);
    const decoys = Math.max(0, Math.floor(Number(options.decoys || 0)));
    const entries = [];
    const lengths = [];
    let seq = 0;

    for (let offset = 0; offset < bytes.length;) {
        const span = min + ((next() % (Math.floor((max - min) / 4) + 1)) * 4);
        const logicalSeq = seq++;
        const frag = Array.from(bytes).slice(offset, Math.min(bytes.length, offset + span));
        const protectedFrag = protectShard(frag, shardMaskSeed, logicalSeq, logicalSeq & 3);
        entries.push({ text: base85Encode(protectedFrag), actual: true, seq: logicalSeq });
        lengths[logicalSeq] = frag.length;
        offset += frag.length;
    }

    for (let i = 0; i < decoys; i++) {
        const length = min + ((next() % (Math.floor((max - min) / 4) + 1)) * 4);
        const decoySeq = 0x40000000 + i;
        const decoy = protectShard(decoyBytes(next, length), shardMaskSeed, decoySeq, (decoySeq + i) & 3);
        entries.push({ text: base85Encode(decoy), actual: false, seq: -1 });
    }

    for (let i = entries.length - 1; i > 0; i--) {
        const j = next() % (i + 1);
        [entries[i], entries[j]] = [entries[j], entries[i]];
    }

    const order = [];
    for (let i = 0; i < entries.length; i++) {
        if (entries[i].actual) order[entries[i].seq] = i + 1;
    }

    const shardCode = entries.map((entry) => JSON.stringify(entry.text)).join(",");
    const orderCode = order.join(",");
    return {
        expression: `{${shardCode}}`,
        orderExpression: `{${orderCode}}`,
        entryCount: entries.length,
        shardCount: order.length,
        lengthsExpression: `{${lengths.join(",")}}`,
        decoyCount: entries.length - order.length,
        format: `v39-radix${RADIX}-numeric`,
        alphabet: ALPHABET,
        // Build-time metadata consumed by the v4.7.9 shared payload directory.
        // Historical callers continue to use expression/orderExpression unchanged.
        segments: entries.map((entry) => entry.text),
        order: order.slice(),
        lengths: lengths.slice()
    };
}

module.exports = { ALPHABET, base85Encode, makeContainer, makeNumericContainer, shardMaskByte, protectShard };

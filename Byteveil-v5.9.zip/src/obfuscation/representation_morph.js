"use strict";

const { mix, shuffle, u32 } = require("./vm_personality");
function morphMix(seed, value) {
  let r = u32(seed ^ value ^ 0xB17E4A31);
  r = u32(r ^ Math.floor(r / 65536));
  r = Math.imul(r, 2246822519) >>> 0;
  r = u32(r ^ Math.floor(r / 8192));
  r = Math.imul(r, 3266489917) >>> 0;
  return u32(r ^ Math.floor(r / 65536));
}


const FORMS = Object.freeze(["array", "sparse", "record", "tuple", "split", "tagged"]);

function buildMorphPlan(seed, regionCount, mode = "stack", version = "4.5.5") {
  const count = Math.max(1, Number(regionCount) || 1);
  const buildSeed = u32(seed);
  const forms = [];
  const constantForms = [];
  const instructionForms = [];
  const controlForms = [];
  let salt = mix(buildSeed, mode === "register" ? 0x13F00D : 0x24F00D);
  for (let i = 0; i < count; i++) {
    salt = mix(salt, i + 1);
    forms.push((((salt >>> 0) + i) >>> 0) % FORMS.length);
    salt = mix(salt, 0x45550000 ^ Math.imul(i + 3, 0x45D9F3B));
    constantForms.push(((salt ^ i) >>> 0) % FORMS.length);
    instructionForms.push((((salt >>> 0) + i * 3) >>> 0) % FORMS.length);
    controlForms.push(((salt ^ 0xA5A5A5A5) >>> 0) % 4);
  }
  return {
    version,
    forms,
    constantForms,
    instructionForms,
    controlForms,
    alphabet: shuffle(FORMS.map((_, i) => i), mix(buildSeed, 0x4555AA77)),
    diversity: new Set(forms).size,
    mode
  };
}


function buildInstructionLayoutPlan(seed, regionCount, mode = "stack") {
  const count = Math.max(1, Number(regionCount) || 1);
  let s = u32(seed ^ (mode === "register" ? 0x7614A11C : 0x51A7B20D));
  const out = [];
  for (let i = 0; i < count; i++) {
    s = mix(s, i + 1);
    const ir = s % 6;
    s = mix(s, 0x9E3779B9 ^ Math.imul(i + 7, 0x45D9F3B));
    const cr = s % 4;
    s = mix(s, 0xC0FFEE11 ^ Math.imul(i + 11, 0x27D4EB2F));
    const cf = s % 6;
    out.push((ir + cr * 3 + cf * 5 + i) % 12);
  }
  return out;
}

function formName(id) {
  return FORMS[Math.abs(Number(id) || 0) % FORMS.length];
}

function permutation(length, form, seed) {
  const n = Math.max(0, Number(length) || 0);
  const out = Array.from({ length: n }, (_, i) => i);
  if (n <= 1 || form === 0) return out;
  if (form === 1) return out.reverse();
  if (form === 2) {
    const shift = u32(seed) % n;
    return out.map((_, i) => (i + shift) % n);
  }
  if (form === 3) {
    const evens = out.filter(i => (i & 1) === 0);
    const odds = out.filter(i => (i & 1) === 1);
    return evens.concat(odds);
  }
  if (form === 4) {
    for (let i = 0; i + 1 < out.length; i += 2) [out[i], out[i + 1]] = [out[i + 1], out[i]];
    return out;
  }
  let step = (u32(seed) % n) || 1;
  if ((step & 1) === 0) step += 1;
  const gcd = (a, b) => { while (b) [a, b] = [b, a % b]; return a; };
  let guard = 0;
  while (gcd(step, n) !== 1 && guard++ < n + 3) step += 2;
  if (gcd(step, n) !== 1) step = 1;
  const offset = u32(seed ^ 0x94D049BB) % n;
  return Array.from({ length: n }, (_, i) => (offset + i * step) % n);
}

function byteKey(seed, form, index) {
  return morphMix(u32(seed ^ Math.imul(form + 1, 0x45D9F3B)), index + 1) & 0xff;
}

function transformByte(value, form, key, index) {
  const v = Number(value) & 0xff;
  if (form === 0) return v ^ key;
  if (form === 1) return (v + key) & 0xff;
  if (form === 2) {
    const n = ((v & 0x0f) << 4) | ((v >>> 4) & 0x0f);
    return n ^ key;
  }
  if (form === 3) {
    const r = ((v << 3) | (v >>> 5)) & 0xff;
    return r ^ key;
  }
  if (form === 4) return (v + key + (index % 31)) & 0xff;
  return ((v ^ key) + ((index * 7 + 13) & 0xff)) & 0xff;
}

function inverseByte(value, form, key, index) {
  const v = Number(value) & 0xff;
  if (form === 0) return v ^ key;
  if (form === 1) return (v - key + 256) & 0xff;
  if (form === 2) {
    const n = v ^ key;
    return ((n & 0x0f) << 4) | ((n >>> 4) & 0x0f);
  }
  if (form === 3) {
    const r = v ^ key;
    return ((r >>> 3) | (r << 5)) & 0xff;
  }
  if (form === 4) return (v - key - (index % 31) + 512) & 0xff;
  return ((v - ((index * 7 + 13) & 0xff) + 256) & 0xff) ^ key;
}

function morphEncode(bytes, form, seed) {
  const input = Array.from(bytes || [], v => Number(v) & 0xff);
  const p = permutation(input.length, Number(form) % FORMS.length, seed);
  const out = new Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const source = input[i];
    out[p[i]] = transformByte(source, Number(form) % FORMS.length, byteKey(seed, Number(form) % FORMS.length, i), i);
  }
  return Buffer.from(out);
}

function morphDecode(bytes, form, seed) {
  const input = Array.from(bytes || [], v => Number(v) & 0xff);
  const p = permutation(input.length, Number(form) % FORMS.length, seed);
  const out = new Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const encoded = input[p[i]];
    out[i] = inverseByte(encoded, Number(form) % FORMS.length, byteKey(seed, Number(form) % FORMS.length, i), i);
  }
  return Buffer.from(out);
}

function buildLuaInverseSource({ functionName, mixName, xorName, mulName }) {
  return `local ${functionName}=function(B,F,S0)local L=#B;if L<=1 then return B end;local f=(F or 0)%6;local function K(I)local Q=${mixName}(${xorName}((S0 or 0),((f+1)*0x45D9F3B)) or 0,I+1);return Q%256 end;local O={};local sh=(S0 or 0)%L;local E=math.ceil(L/2);local step=(S0 or 0)%L;if step%2==0 then step=step+1 end;if step==0 then step=1 end;local function C(A,D)local X,Y=A,D;while Y~=0 do local Z=X%Y;X=Y;Y=Z end;return X end;while C(step,L)~=1 do step=step+2 end;local off=${xorName}((S0 or 0),0x94D049BB)%L;for I=1,L do local src;if f==0 then src=I elseif f==1 then src=L-I+1 elseif f==2 then src=((I-1+sh)%L)+1 elseif f==3 then if I<=E then src=2*I-1 else src=2*(I-E) end elseif f==4 then if I%2==1 then src=(I<L)and(I+1)or I else src=I-1 end elseif f==5 then src=(off+(I-1)*step)%L+1 else src=I end;local V=B[src]or 0;local Q=K(I-1);if f==0 then V=${xorName}(V,Q)%256 elseif f==1 then V=(V-Q+256)%256 elseif f==2 then V=${xorName}(V,Q)%256;V=((V%16)*16+math.floor(V/16)) elseif f==3 then V=${xorName}(V,Q)%256;V=(math.floor(V/8)+((V%8)*32))%256 elseif f==4 then V=(V-Q-((I-1)%31)+512)%256 else V=(V-(((I-1)*7+13)%256)+256)%256;V=${xorName}(V,Q)%256 end;O[I]=V end;return O end`;
}

module.exports = {
  FORMS,
  buildMorphPlan,
  buildInstructionLayoutPlan,
  formName,
  permutation,
  morphEncode,
  morphDecode,
  buildLuaInverseSource,
  transformByte,
  inverseByte
};

"use strict";

// VeilBlob-v1: Luraph v15.x-style long-bracket blob codec for ByteVeil v5.9.
//
// Character set: the shared 93-character printable alphabet (blob_alphabet.js),
// digits included, so a blob container and a payload carrier are no longer
// separable by their character distribution.
//
// Wire format:  [==[byteveil&<base93 text>]==]
//   - bracket `=` level auto-escalates so the closer never occurs in the text
//   - plaintext frame: [4-byte big-endian length][payload bytes]
//   - stream cipher: Lehmer PRNG keystream + autokey + ciphertext feedback +
//     position mask, all modular arithmetic. No bitwise operations are used so
//     the emitted decoder runs identically on Lua 5.1, Lua 5.4 and Luau
//     (double-precision path included: every intermediate stays < 2^53).
//   - base93 packing: 3 bytes -> 4 chars (tail: 1 byte -> 2 chars, 2 -> 3)
//
// This is presentation/obfuscation-grade encryption consistent with the rest of
// ByteVeil (see LIMITATIONS): it defeats static scraping and casual decoding,
// not a determined cryptanalyst with the decoder in hand.

const { UNIFIED_ALPHABET } = require("./blob_alphabet");

const BLOB_CHARSET = UNIFIED_ALPHABET;
const BLOB_MARKER = "byteveil&";
const BLOB_BASE = UNIFIED_ALPHABET.length; // 93, shared printable ASCII
const BLOB_BASE2 = BLOB_BASE * BLOB_BASE;
const BLOB_BASE3 = BLOB_BASE2 * BLOB_BASE;

const LEHMER_A = 48271;
const LEHMER_M = 2147483647;
const POS_MASK_MULT = 1103515245;

function u32(value) { return Number(value) >>> 0; }

function lehmerSeed(seed, domain = 0) {
  // `^` yields a signed int32; normalize to u32 so the Lehmer state stays positive.
  return (((u32(seed) ^ u32(domain) ^ 0x5EED17B1) >>> 0) % (LEHMER_M - 1)) + 1;
}

function lehmerRng(k0) {
  let k = k0;
  return () => {
    k = (k * LEHMER_A) % LEHMER_M;
    return k;
  };
}

function shuffleText(text, rng) {
  const chars = [...text];
  for (let i = chars.length - 1; i > 0; i--) {
    const j = rng() % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

function keystreamEncrypt(bytes, k0) {
  const out = Buffer.alloc(bytes.length);
  let k = k0;
  let prevC = k0 % 256;
  let prevP = Math.floor(k0 / 256) % 256;
  for (let i = 0; i < bytes.length; i++) {
    k = (k * LEHMER_A) % LEHMER_M;
    const s = k % 256;
    const m = (((i + 1) * POS_MASK_MULT) % LEHMER_M) % 256;
    const p = bytes[i];
    const c = (p + s + m + prevC + prevP) % 256;
    out[i] = c;
    prevP = p;
    prevC = c;
  }
  return out;
}

function keystreamDecrypt(bytes, k0) {
  const out = Buffer.alloc(bytes.length);
  let k = k0;
  let prevC = k0 % 256;
  let prevP = Math.floor(k0 / 256) % 256;
  for (let i = 0; i < bytes.length; i++) {
    k = (k * LEHMER_A) % LEHMER_M;
    const s = k % 256;
    const m = (((i + 1) * POS_MASK_MULT) % LEHMER_M) % 256;
    const c = bytes[i];
    const p = ((((c - s - m - prevC - prevP) % 256) + 256) % 256);
    out[i] = p;
    prevP = p;
    prevC = c;
  }
  return out;
}

function textFromBytes(bytes, alphabet) {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const n = Math.min(3, bytes.length - i);
    let v = 0;
    for (let j = 0; j < n; j++) v = v * 256 + bytes[i + j];
    const chars = n + 1;
    const digits = [];
    for (let j = 0; j < chars; j++) {
      digits.unshift(alphabet[v % BLOB_BASE]);
      v = Math.floor(v / BLOB_BASE);
    }
    out += digits.join("");
  }
  return out;
}

function bytesFromText(text, alphabet) {
  const index = new Map();
  for (let i = 0; i < alphabet.length; i++) index.set(alphabet[i], i);
  const out = [];
  for (let i = 0; i < text.length; i += 4) {
    const nChars = Math.min(4, text.length - i);
    let v = 0;
    for (let j = 0; j < nChars; j++) {
      const d = index.get(text[i + j]);
      if (d === undefined) throw new Error(`VeilBlob-v1: character '${text[i + j]}' outside build alphabet at ${i + j}`);
      v = v * BLOB_BASE + d;
    }
    const nBytes = nChars - 1;
    const group = [];
    for (let j = 0; j < nBytes; j++) {
      group.unshift(v % 256);
      v = Math.floor(v / 256);
    }
    if (v !== 0) throw new Error("VeilBlob-v1: base93 group overflow (corrupt or foreign blob)");
    out.push(...group);
  }
  return Buffer.from(out);
}

function pickBracketLevel(text, minLevel = 2) {
  let level = Math.max(0, minLevel);
  for (;;) {
    const closer = `]${"=".repeat(level)}]`;
    // The literal is `text + closer`, so a closer is only safe when its first occurrence
    // in the joined string is the terminator itself. Testing `text.includes(closer)` misses
    // the overlap case, which is a real broken artifact: a payload ending in `]==` followed
    // by the terminator reads as `]==]==]`, Lua closes the container three characters early
    // and the leftovers (`==]`) are a syntax error in the shipped file.
    if (`${text}${closer}`.indexOf(closer) === text.length) return level;
    level++;
  }
}

function renderLongBracket(text, minLevel = 2) {
  const level = pickBracketLevel(text, minLevel);
  const eq = "=".repeat(level);
  return `[${eq}[${text}]${eq}]`;
}

/**
 * Carrier representation: the same bytes the quoted literal carried, wrapped in
 * the VeilBlob container instead. The call site reads it back with
 * `string.sub(<literal>, N)`, so the value handed to the decoder is byte-identical
 * and only the static shape changes: no quote character, no line to split on, and
 * a container that is already escalation-checked against `]==]` inside the text.
 */
function renderCarrierLiteral(text) {
  return renderLongBracket(`${BLOB_MARKER}${text}`);
}

/**
 * Unused char-code source: a structurally genuine VeilBlob container (same marker,
 * same base84 ciphertext, same escalating bracket level, and it really does decode
 * to a framed byte string) bound to a slot nobody ever reads. It exists so that
 * finding a container tells an analyst nothing about whether that container feeds
 * the runtime, and so the count/position of blobs no longer mirrors the number of
 * real payloads.
 */
function renderDecoyBlob(seed = 1, lengthOverride = 0) {
  const codec = createBlobCodec(seed);
  const rng = lehmerRng(lehmerSeed(seed, 0xDECA0));
  const length = lengthOverride > 0 ? lengthOverride : 24 + (rng() % 88);
  const bytes = Buffer.alloc(length);
  for (let i = 0; i < length; i++) bytes[i] = rng() % 256;
  return codec.renderBlob(bytes);
}

const CARRIER_MARKER_SUB = BLOB_MARKER.length + 1;

function createBlobCodec(seed = 1) {
  const alphaRng = lehmerRng(lehmerSeed(seed, 0xB10B5EED));
  const alphabet = shuffleText(BLOB_CHARSET, alphaRng);
  if (alphabet.length !== BLOB_BASE || new Set(alphabet).size !== BLOB_BASE) {
    throw new Error(`VeilBlob-v1: alphabet generation corrupted (${alphabet.length}/${BLOB_BASE} unique chars)`);
  }
  const k0 = lehmerSeed(seed, 0xC0DEC);

  function encodeBytes(payload) {
    const body = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), "utf8");
    const frame = Buffer.alloc(4 + body.length);
    frame.writeUInt32BE(body.length, 0);
    body.copy(frame, 4);
    return keystreamEncrypt(frame, k0);
  }

  function decodeBytes(cipher) {
    const frame = keystreamDecrypt(cipher, k0);
    if (frame.length < 4) throw new Error("VeilBlob-v1: truncated frame");
    const len = frame.readUInt32BE(0);
    if (len !== frame.length - 4) throw new Error("VeilBlob-v1: length header mismatch (corrupt or tampered blob)");
    return frame.subarray(4, 4 + len);
  }

  function encodeToText(payload) {
    return textFromBytes(encodeBytes(payload), alphabet);
  }

  function decodeFromText(text) {
    return decodeBytes(bytesFromText(String(text), alphabet));
  }

  function renderBlob(payload, { minLevel = 2, marker = BLOB_MARKER } = {}) {
    const text = encodeToText(payload);
    const level = pickBracketLevel(marker + text, minLevel);
    const eq = "=".repeat(level);
    return `[${eq}[${marker}${text}]${eq}]`;
  }

  return {
    engine: "VeilBlob-v1",
    seed: u32(seed),
    alphabet,
    k0,
    marker: BLOB_MARKER,
    base: BLOB_BASE,
    encodeBytes,
    decodeBytes,
    encodeToText,
    decodeFromText,
    renderBlob,
    renderLongBracket
  };
}

/**
 * Locate emitted blob literals. A plain `[^\]]*` scan is unsound because `]` is
 * itself a base84 digit; the closer is unique by construction (pickBracketLevel
 * escalates until it is absent from the text), so the first match after the open
 * is the true end.
 */
function findBlobLiterals(source) {
  const found = [];
  const opener = /\[(=*)\[byteveil&/g;
  let match;
  while ((match = opener.exec(String(source || "")))) {
    const closer = `]${match[1]}]`;
    const end = String(source).indexOf(closer, match.index + match[0].length);
    if (end < 0) continue;
    found.push({ start: match.index, end: end + closer.length, text: String(source).slice(match.index, end + closer.length) });
    opener.lastIndex = end + closer.length;
  }
  return found;
}

function stripBlobLiterals(source, replacement = " ") {
  const text = String(source || "");
  let out = "";
  let cursor = 0;
  for (const blob of findBlobLiterals(text)) {
    out += text.slice(cursor, blob.start) + replacement;
    cursor = blob.end;
  }
  return out + text.slice(cursor);
}

function planFragments(seed) {
  const rng = lehmerRng(lehmerSeed(seed, 0xF4A6));
  const rotation = 1 + (rng() % (BLOB_BASE - 1));
  const orders = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]];
  const fragmentOrder = orders[rng() % orders.length];
  const fragmentLevels = [1 + (rng() % 3), 1 + (rng() % 3), 1 + (rng() % 3)];
  return { rotation, fragmentOrder, fragmentLevels };
}

const LUA_KEYWORDS = new Set(["and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while"]);

function collectUsedNames(source) {
  const used = new Set();
  const re = /[A-Za-z_][A-Za-z0-9_]*/g;
  let match;
  while ((match = re.exec(String(source || "")))) used.add(match[0]);
  return used;
}

// Deterministic, collision-checked generated names. The blob runtime is emitted
// after minification, so a name that already appears in the body would shadow a
// live local and silently change semantics instead of failing loudly.
function makeNamePool(rng, used, count) {
  const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const taken = new Set(used);
  const out = [];
  let guard = 0;
  while (out.length < count && guard++ < 4096) {
    const len = 4 + (rng() % 2);
    let name = letters[rng() % letters.length];
    for (let i = 1; i < len; i++) {
      const alphabet = rng() % 3 === 0 ? "0123456789" : letters;
      name += alphabet[rng() % alphabet.length];
    }
    if (taken.has(name) || LUA_KEYWORDS.has(name)) continue;
    taken.add(name);
    out.push(name);
  }
  if (out.length !== count) throw new Error(`VeilBlob-v1: unable to allocate ${count} collision-free runtime names`);
  return out;
}

function manifestFromEntries(entries) {
  const parts = [];
  for (const value of entries) {
    const body = Buffer.from(String(value), "utf8");
    if (body.length > 0xffff) throw new Error(`VeilBlob-v1: manifest entry too large (${body.length} bytes)`);
    const head = Buffer.alloc(2);
    head.writeUInt16BE(body.length, 0);
    parts.push(head, body);
  }
  return Buffer.concat(parts);
}

/**
 * Emit the whole diagnostic-blob runtime: shuffled alphabet fragments, one
 * keyed stream decoder, the length-prefixed string manifest, an index
 * permutation and structurally valid decoy blobs. `get(i)` returns the exact
 * string the old `"\ddd"` encoder would have produced, so runtime error
 * behaviour is unchanged and only the source representation moves.
 *
 * Everything except the accessor local lives inside an IIFE, so the body's
 * top-level scope gains a single generated name. Failures raise through an
 * aliased `error` local: the generated body must not advertise a `then error(`
 * guard signature, which is exactly the pattern the release sweep forbids.
 */
function renderDiagnosticRuntime({ seed = 1, entries = [], decoys = 0, usedNames = [], errorCodes = [8421001, 8421002] }) {
  const codec = createBlobCodec(seed);
  const plan = planFragments(seed);
  const rng = lehmerRng(lehmerSeed(seed, 0xDEADC0DE));
  const used = new Set(usedNames);
  const reserved = makeNamePool(rng, used, 12);
  const [fragA, fragB, fragC, alpha, map, dec, manifest, table, cursor, perm, raise, get] = reserved;
  const frag = [fragA, fragB, fragC];

  const rotation = plan.rotation;
  const unroll = BLOB_BASE - rotation;
  const rotated = codec.alphabet.slice(rotation) + codec.alphabet.slice(0, rotation);
  const cut1 = 17 + (rotation % 11);
  const cut2 = cut1 + 23 + ((rotation * 7) % 13);
  const parts = [rotated.slice(0, cut1), rotated.slice(cut1, cut2), rotated.slice(cut2)];
  const fragDecls = `local ${frag.join(",")}=${plan.fragmentOrder
    .map((partIdx) => renderLongBracket(parts[partIdx], plan.fragmentLevels[partIdx]))
    .join(",")};`;
  const concatExpr = [0, 1, 2].map((partIdx) => frag[plan.fragmentOrder.indexOf(partIdx)]).join("..");

  const blobLiteral = codec.renderBlob(manifestFromEntries(entries));

  const decoyLits = [];
  for (let i = 0; i < decoys; i++) {
    const size = 24 + (rng() % 73);
    const junk = Buffer.alloc(size);
    for (let b = 0; b < size; b++) junk[b] = rng() % 256;
    decoyLits.push(codec.renderBlob(junk));
  }

  const decodeFn =
    `local ${dec}=function(S,K)local Y={}local n=0 local i=1 local L=#S ` +
    `while i+3<=L do if not ${map}[string.sub(S,i,i)]or not ${map}[string.sub(S,i+1,i+1)]or not ${map}[string.sub(S,i+2,i+2)]or not ${map}[string.sub(S,i+3,i+3)]then ${raise}(${errorCodes[0]},0)end;` +
    `local v=${map}[string.sub(S,i,i)]*${BLOB_BASE3}+${map}[string.sub(S,i+1,i+1)]*${BLOB_BASE2}+${map}[string.sub(S,i+2,i+2)]*${BLOB_BASE}+${map}[string.sub(S,i+3,i+3)];` +
    `Y[n+1]=math.floor(v/65536);Y[n+2]=math.floor(v/256)%256;Y[n+3]=v%256;n=n+3;i=i+4 end;` +
    `local r=L-i+1;if r==1 then ${raise}(${errorCodes[0]},0)elseif r==2 then if not ${map}[string.sub(S,i,i)]or not ${map}[string.sub(S,i+1,i+1)]then ${raise}(${errorCodes[0]},0)end;local v=${map}[string.sub(S,i,i)]*${BLOB_BASE}+${map}[string.sub(S,i+1,i+1)];` +
    `if v>255 then ${raise}(${errorCodes[0]},0)end;n=n+1;Y[n]=v elseif r==3 then if not ${map}[string.sub(S,i,i)]or not ${map}[string.sub(S,i+1,i+1)]or not ${map}[string.sub(S,i+2,i+2)]then ${raise}(${errorCodes[0]},0)end;local v=${map}[string.sub(S,i,i)]*${BLOB_BASE2}+${map}[string.sub(S,i+1,i+1)]*${BLOB_BASE}+${map}[string.sub(S,i+2,i+2)];` +
    `if v>65535 then ${raise}(${errorCodes[0]},0)end;Y[n+1]=math.floor(v/256);Y[n+2]=v%256;n=n+2 end;` +
    `local k=K;local pC=K%256;local pP=math.floor(K/256)%256;local W={}for j=1,n do k=(k*${LEHMER_A})%${LEHMER_M};` +
    `local s=k%256;local m=(j*${POS_MASK_MULT})%${LEHMER_M}%256;local p=(Y[j]-s-m-pC-pP)%256;W[j]=p;pP=p;pC=Y[j]end;` +
    `if n<4 then ${raise}(${errorCodes[1]},0)end;` +
    `local bl=W[1]*16777216+W[2]*65536+W[3]*256+W[4];if bl~=n-4 then ${raise}(${errorCodes[1]},0)end;` +
    `local t={}for j=5,n do t[j-4]=string.char(W[j])end;return table.concat(t)end;`;

  const parse =
    `local ${manifest}=${dec}(string.sub(${blobLiteral},${BLOB_MARKER.length + 1}),${codec.k0});` +
    `local ${table}={}local ${cursor}=1 local Z=#${manifest} ` +
    `while ${cursor}<=Z do local ln=string.byte(${manifest},${cursor})*256+string.byte(${manifest},${cursor}+1);` +
    `${table}[#${table}+1]=string.sub(${manifest},${cursor}+2,${cursor}+1+ln);${cursor}=${cursor}+2+ln end;`;

  // Emitted indices are permuted so a static reader cannot infer string order:
  // call site i resolves to table slot perm[i].
  const slots = entries.map((_, idx) => idx + 1);
  for (let i = slots.length - 1; i > 0; i--) {
    const j = rng() % (i + 1);
    [slots[i], slots[j]] = [slots[j], slots[i]];
  }
  const access =
    `local ${perm}={${slots.join(",")}}return function(i)local v=${table}[${perm}[i]or 0];` +
    `if v==nil then ${raise}(${errorCodes[1]},0)end;return v end;`;

  const dead = decoyLits.length
    ? `local ${makeNamePool(rng, new Set([...used, ...reserved]), decoyLits.length).join(",")}=${decoyLits.join(",")};`
    : "";

  // The reverse map is built from the reconstructed alphabet and then verified
  // against it. A corrupted fragment normally duplicates a character, which
  // would otherwise shift every later index silently; the verification makes an
  // alphabet tamper fail closed on its own.
  const alphabetBuild = `local ${map}={};for q=1,#${alpha} do ${map}[string.sub(${alpha},q,q)]=q-1 end;` +
    `for q=1,#${alpha} do if ${map}[string.sub(${alpha},q,q)]~=q-1 then ${raise}(${errorCodes[0]},0)end end;`;

  return {
    engine: "VeilBlob-v1",
    prelude: `local ${get}=(function()local ${raise}=error;${fragDecls}local ${alpha}=(function(J)return string.sub(J,${unroll}+1)..string.sub(J,1,${unroll})end)(${concatExpr});${alphabetBuild}${decodeFn}${parse}${access}end)();${dead}`,
    get,
    names: { frag, alpha, map, dec, manifest, table, cursor, perm, raise, get },
    codec,
    plan,
    decoyLiterals: decoyLits,
    blobBytes: Buffer.byteLength(blobLiteral, "utf8"),
    entryCount: entries.length
  };
}

module.exports = {
  BLOB_CHARSET,
  BLOB_MARKER,
  BLOB_BASE,
  LEHMER_M,
  createBlobCodec,
  renderLongBracket,
  renderCarrierLiteral,
  renderDecoyBlob,
  CARRIER_MARKER_SUB,
  pickBracketLevel,
  renderDiagnosticRuntime,
  collectUsedNames,
  makeNamePool,
  manifestFromEntries,
  findBlobLiterals,
  stripBlobLiterals,
  lehmerSeed,
  lehmerRng,
  planFragments,
  textFromBytes,
  bytesFromText
};

"use strict";

// VeilStr-v1: the string-constant cipher.
//
// A Lua/Luau payload that stores its string constants as plain bytes hands an analyst the
// program's vocabulary for free, even when the region carrying them is encrypted: decoding
// the region once reveals every constant in one linear sweep. VeilStr keeps the constants
// inside the same encrypted region but gives each one its own keystream lane, keyed by the
// build's *material root* - the value the runtime can only rebuild by folding the JunkForge
// key bed and re-running the anti-hook guard. Deleting either latch therefore does not just
// skip a check, it changes every string key in the program.
//
// The arithmetic is deliberately restricted to the two primitives the VM already proves
// equal in JavaScript and Lua (`mix` == mix32, `mul` == the split-16-bit modular multiply,
// `bx` == xor), so no 53-bit precision hazard is introduced on either side.

const { mix32 } = require("../protection/byte_blinder");

const VEIL_STR_TAG = 85; // "U"
const VEIL_STR_ALGORITHM = "veil-str-v1";

function mul32(a, b) {
    return Math.imul(a, b) >>> 0;
}

// Chunk sequence and constant index are traversal order, which the serializer and the
// runtime reader share (both walk the chunk tree pre-order).
function constantKey(materialRoot, chunkSeq, index) {
    const salt = (mul32(chunkSeq + 1, 0x27D4EB2F) ^ mul32(index + 1, 0x9E3779B1) ^ 0xD3C0DEC0) >>> 0;
    return mix32(materialRoot >>> 0, salt);
}

function laneMask(key, position, lane) {
    const domain = (0x51ED2708 + mul32(lane + 1, 0x45D9F3B) + mul32(position + 1, 0x27D4EB2F)) >>> 0;
    return mix32(key, domain) % 256;
}

function foldCheck(bytes) {
    let h = 17;
    for (const byte of bytes) h = (h * 65599 + byte + 1) % 2147483647;
    return h % 251;
}

function encryptConstant(text, { materialRoot, chunkSeq, index }) {
    const plain = Buffer.from(String(text), "utf8");
    const key = constantKey(materialRoot, chunkSeq, index);
    const cipher = Buffer.alloc(plain.length);
    for (let position = 0; position < plain.length; position++) {
        let value = (plain[position] + laneMask(key, position, 0)) % 256;
        value = (value ^ laneMask(key, position, 1)) >>> 0;
        cipher[position] = ((value - laneMask(key, position, 2)) % 256 + 256) % 256;
    }
    return { cipher, check: foldCheck(plain), plainLength: plain.length };
}

// JS mirror of the emitted Lua decoder; used by the parity tests and the precheck.
function decryptConstant(cipher, { materialRoot, chunkSeq, index }) {
    const key = constantKey(materialRoot, chunkSeq, index);
    const plain = Buffer.alloc(cipher.length);
    for (let position = 0; position < cipher.length; position++) {
        let value = (cipher[position] + laneMask(key, position, 2)) % 256;
        value = value ^ laneMask(key, position, 1);
        plain[position] = ((value - laneMask(key, position, 0)) % 256 + 256) % 256;
    }
    return plain;
}

// The runtime helpers are emitted as chunk-level locals so the reader can decrypt a
// constant per access without rebuilding a table.
function buildLuaHelpers({ keyName, maskName, foldName, mixName, xorName, mulName }) {
    return [
        `local ${keyName}=function(MR,Q,I)return ${mixName}(MR,${xorName}(${xorName}(${mulName}(Q+1,0x27D4EB2F),${mulName}(I+1,0x9E3779B1)),0xD3C0DEC0)) end`,
        `local ${maskName}=function(K,P,L)local D0=(0x51ED2708+${mulName}(L+1,0x45D9F3B)+${mulName}(P+1,0x27D4EB2F))%4294967296;return ${mixName}(K,D0)%256 end`,
        `local ${foldName}=function(B)local H=17;for I=1,#B do H=(H*65599+B[I]+1)%2147483647 end;return H%251 end`
    ].join(";");
}

module.exports = {
    VEIL_STR_TAG,
    VEIL_STR_ALGORITHM,
    constantKey,
    laneMask,
    foldCheck,
    encryptConstant,
    decryptConstant,
    buildLuaHelpers
};

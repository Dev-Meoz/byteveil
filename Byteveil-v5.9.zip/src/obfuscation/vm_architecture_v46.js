"use strict";

const { u32, mix, shuffle } = require("./vm_personality");

const ARCHITECTURES = Object.freeze([
  "region-matrix",
  "bucket-route",
  "continuation-chain",
  "split-lane",
  "state-machine",
  "directed-hop"
]);

function buildArchitecturePlan(seed, mode = "stack", opcodeCount = 0, regionCount = 1, version = "4.7.4") {
  const buildSeed = u32(seed);
  const modeSalt = mode === "register" ? 0x13579BDF : 0x2468ACE0;
  const family = mix(buildSeed ^ modeSalt, 0x46000001) % ARCHITECTURES.length;
  const secondary = mix(buildSeed, 0x46000002) % ARCHITECTURES.length;
  const bucketCount = 2 + (mix(buildSeed, 0x46000003) % 5);
  const laneCount = 3 + (mix(buildSeed, 0x46000004) % 4);
  const composition = shuffle([0, 1, 2, 3, 4, 5, 6], mix(buildSeed, 0x46000005));
  const regionOrder = shuffle(Array.from({ length: Math.max(1, regionCount) }, (_, i) => i), mix(buildSeed, 0x46000006));
  const opcodeSalt = mix(buildSeed, 0x46000007);
  const opBuckets = Array.from({ length: Math.max(1, opcodeCount) }, (_, i) => mix(opcodeSalt, i + 1) % bucketCount);
  const hop = 1 + (mix(buildSeed, 0x46000008) % 11);
  const stateBias = mix(buildSeed, 0x46000009);
  return {
    version: String(version || "4.7.4"),
    family,
    familyName: ARCHITECTURES[family],
    secondary,
    bucketCount,
    laneCount,
    composition,
    regionOrder,
    opBuckets,
    hop,
    stateBias
  };
}

function emitSemanticArchitecture({ plan, names, N, S, V, defs, opNames, usedLogical, mode, seed, opaque }) {
  if (!plan || typeof plan !== "object") throw new TypeError("ByteVeil v4.6: architecture plan required");
  const logicalSet = new Set((usedLogical || []).filter((x) => Number.isInteger(x) && x >= 0 && x < opNames.length));
  if (!logicalSet.size) logicalSet.add(0);
  const buildSeed = u32(seed);
  if (opNames.length > logicalSet.size) {
    const minTarget = Math.min(opNames.length, Math.max(16, logicalSet.size + 4));
    const candidates = shuffle(Array.from({ length: opNames.length }, (_, i) => i), mix(buildSeed, 0x584600));
    for (const cand of candidates) {
      if (logicalSet.size >= minTarget) break;
      logicalSet.add(cand);
    }
  }
  const logicals = Array.from(logicalSet).sort((a, b) => a - b);

  const lines = [];
  const cores = [];
  const emitOrder = shuffle(logicals.slice(), mix(buildSeed, 0x584601));
  for (const logical of emitOrder) {
    const name = opNames[logical];
    const ident = opaque(`v46-semantic-core:${logical}`, logical + 0x4600);
    const body = defs[name] || `S[${S.halt}]=true;return true`;
    lines.push(`local ${ident}=function(S,I,R)${body};end`);
    cores[logical] = ident;
  }

  const usedHex = new Set();
  const allocHex = (salt) => {
    let h = 0x1000 + (mix(buildSeed, salt) % 0xEFFF);
    while (usedHex.has(h)) h = 0x1000 + ((h - 0x1000 + 0x13B) % 0xEFFF);
    usedHex.add(h);
    return `0x${h.toString(16)}`;
  };
  const opHexByLogical = {};
  for (const logical of logicals) {
    opHexByLogical[logical] = allocHex(0x581000 + logical * 97);
  }
  const preHex = allocHex(0x584602);
  const postHex = allocHex(0x584603);
  const laneHex = allocHex(0x584604);
  const matHex = allocHex(0x584605);
  const routeHex = allocHex(0x584606);

  const coreArray = opaque("v46-core-vector", 0x4601);
  const pre = opaque("v46-pre", 0x4602);
  const post = opaque("v46-post", 0x4603);
  const lane = opaque("v46-lane", 0x4604);
  const material = opaque("v46-materialize", 0x4605);
  const choose = opaque("v46-choose", 0x4606);

  const family = Number(plan.family) % ARCHITECTURES.length;
  const tableOrder = shuffle(logicals.slice(), mix(buildSeed, 0x584607));
  const coreEntries = tableOrder.map((logical) => `[${opHexByLogical[logical]}]=${cores[logical]}`);
  const routeEntries = logicals.map((logical) => `[${logical + 1}]=${opHexByLogical[logical]}`);
  lines.push(`local ${coreArray}={${coreEntries.join(",")}}`);

  lines.push(`local ${pre}=function(S,R)local Z=${N.mix}(S[${S.guard}]or 0,${N.xor}(R.ps or 0,R.id or 0));S[${S.micro}]=${N.xor}(S[${S.micro}]or 0,Z);S[${S.region}]=R.id end`);
  lines.push(`local ${post}=function(S,R)local Z=${N.mix}(S[${S.micro}]or 0,${N.xor}(R.token or 0,${N.mul}(R.id+1,${Number(plan.stateBias) >>> 0})));S[${S.guard}]=${N.xor}(S[${S.guard}]or 0,Z);S[${S.micro}]=Z end`);
  lines.push(`local ${lane}=function(S,R,K)local Z=${N.mix}(S[${S.micro}]or 0,${N.xor}(K,R.rv or 0));S[${S.guard}]=${N.xor}(S[${S.guard}]or 0,Z);return Z end`);
  lines.push(`local ${choose}={[${preHex}]=${pre},[${postHex}]=${post},[${laneHex}]=${lane},[${routeHex}]={${routeEntries.join(",")}}}`);
  lines.push(`local ${material}=function(R)local B={};local RT=${choose}[${routeHex}];for I=1,#(R.voc or {}) do local L=R.voc[I];local HK=RT[L+1];if HK and ${coreArray}[HK] then B[#B+1]={l=L,f=${coreArray}[HK],k=I}end end;if #B==0 then error("ByteVeil v4.6: empty region semantic set",0)end;return B end`);
  lines.push(`${choose}[${matHex}]=${material}`);

  if (family === 0) {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local M={};for I=1,#B do M[B[I].l+1]=B[I].f end;local salt=${N.mix}(R.ps or 0,${Number(plan.hop)});return function(S,I,L)local F=M[L+1];if not F then error("ByteVeil v4.6: region matrix miss",0)end;${choose}[${preHex}](S,R);local K=${choose}[${laneHex}](S,R,L);local Q;if K%2==0 then Q=F(S,I,R)else Q=F(S,I,R)end;${choose}[${postHex}](S,R);return Q end end`);
  } else if (family === 1) {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local buckets={};for I=1,${Number(plan.bucketCount)} do buckets[I]={} end;for I=1,#B do local E=B[I];local K=(${N.mix}(R.ps or 0,E.l+${Number(plan.secondary)}))%${Number(plan.bucketCount)};buckets[K+1][#buckets[K+1]+1]=E end;return function(S,I,L)local K=(${N.mix}(R.ps or 0,L+${Number(plan.secondary)}))%${Number(plan.bucketCount)};local B0=buckets[K+1];for J=1,#B0 do local E=B0[J];if E.l==L then ${choose}[${preHex}](S,R);local Q=E.f(S,I,R);${choose}[${postHex}](S,R);return Q end end;error("ByteVeil v4.6: bucket route miss",0)end end`);
  } else if (family === 2) {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local routes={};for I=1,#B do local E=B[I];routes[E.l+1]=E.f end;return function(S,I,L)local F=routes[L+1];if not F then error("ByteVeil v4.6: continuation miss",0)end;local done=${choose}[${preHex}];local next=function()done=nil;return F(S,I,R)end;local q=done(S,R);if q then return q end;local out=next();${choose}[${postHex}](S,R);return out end end`);
  } else if (family === 3) {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local a={};local b={};for I=1,#B do local E=B[I];if (E.l+${Number(plan.secondary)})%2==0 then a[E.l+1]=E.f else b[E.l+1]=E.f end end;return function(S,I,L)local Z=${N.xor}(L,R.id or 0);local F;if Z%2==0 then F=a[L+1] or b[L+1]else F=b[L+1] or a[L+1]end;if not F then error("ByteVeil v4.6: split lane miss",0)end;${choose}[${preHex}](S,R);local Q=F(S,I,R);${choose}[${laneHex}](S,R,Z);${choose}[${postHex}](S,R);return Q end end`);
  } else if (family === 4) {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local states={};for I=1,#B do local E=B[I];states[#states+1]={s=(E.l+${Number(plan.secondary)})%${Number(plan.laneCount)},f=E.f,l=E.l}end;return function(S,I,L)local target=(L+R.id+${Number(plan.hop)})%${Number(plan.laneCount)};local F=nil;for J=1,#states do local E=states[J];if E.l==L and (E.s==target or not F) then F=E.f;if E.s==target then break end end end;if not F then error("ByteVeil v4.6: state machine miss",0)end;${choose}[${preHex}](S,R);local steps=${Number(plan.composition[0]) % 3 + 2};local Q;if steps%2==0 then ${choose}[${laneHex}](S,R,L);Q=F(S,I,R)else Q=F(S,I,R);${choose}[${laneHex}](S,R,L)end;${choose}[${postHex}](S,R);return Q end end`);
  } else {
    lines.push(`local ${V.vmb}=function(R)local B=${choose}[${matHex}](R);local hops={};for I=1,#B do local E=B[I];hops[E.l+1]=E.f end;return function(S,I,L)local H=${Number(plan.hop)};local key=((L+1)*H+(R.id or 0))%${Math.max(1, logicals.length)};local F=hops[L+1];if not F then error("ByteVeil v4.6: directed hop miss",0)end;${choose}[${preHex}](S,R);if key%3==0 then ${choose}[${laneHex}](S,R,key);local q=F(S,I,R);${choose}[${postHex}](S,R);return q elseif key%3==1 then local q=F(S,I,R);${choose}[${laneHex}](S,R,key);${choose}[${postHex}](S,R);return q else ${choose}[${laneHex}](S,R,key);${choose}[${postHex}](S,R);return F(S,I,R) end end end`);
  }

  return { lines, cores, familyName: ARCHITECTURES[family] };
}

module.exports = { ARCHITECTURES, buildArchitecturePlan, emitSemanticArchitecture };

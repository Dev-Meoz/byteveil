"use strict";

// ByteVeil build-personality planners.
// v4.5.5 remains available for historical compatibility; v4.6 adds
// architecture families that participate in the generated execution path.

function u32(n) { return Number(n) >>> 0; }

function mix(seed, value) {
  let s = u32(seed ^ value ^ 0xB17E4A31);
  s ^= s >>> 16;
  s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13;
  s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}

function shuffle(values, seed) {
  const out = values.slice();
  let s = u32(seed) || 0x9E3779B9;
  for (let i = out.length - 1; i > 0; i--) {
    s = mix(s, i + 1);
    const j = s % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function stateProfile(seed, mode, id) {
  const base = mode === "stack"
    ? ["pc","sp","stack","locals","localSet","parent","env","consts","code","halt","ret","varargs","guard","iter","fabric","frame","region","micro","microRoutes"]
    : ["pc","reg","locals","localSet","parent","env","consts","code","halt","ret","varargs","guard","iter","fabric","frame","region","micro","microRoutes"];
  const reverse = (id & 1) !== 0;
  const seedSalt = id < 8 ? 0x45D9F3B : 0x27D4EB2F;
  return shuffle(reverse ? base.slice().reverse() : base, mix(seed, Math.imul(id + 1, seedSalt)));
}

function buildV455Personality(seed, mode = "stack") {
  const buildSeed = u32(seed);
  const modeSalt = mode === "register" ? 0x13579BDF : 0x2468ACE0;
  const id = mix(buildSeed ^ modeSalt, 0x45500001) % 16;
  return {
    version: "4.5.5",
    id,
    mode,
    stateOrder: stateProfile(buildSeed, mode, id),
    dispatchStyle: mix(buildSeed, 0x4550D001) % 4,
    recipeStyle: mix(buildSeed, 0x4550D002) % 7,
    representationStyle: mix(buildSeed, 0x4550D003) % 6,
    resolverFamily: mix(buildSeed, 0x4550D004) % 4,
    stateModel: mix(buildSeed, 0x4550D005) % 4,
    commitStyle: mix(buildSeed, 0x4550D006) % 5,
    microOrder: shuffle([0,1,2,3,4,5,6,7,8], mix(buildSeed, 0x4550D007)),
    stateSalt: mix(buildSeed, 0x4555AA11),
    topologySalt: mix(buildSeed, 0x4555BB22),
    semanticSalt: mix(buildSeed, 0x4555CC33),
    representationSalt: mix(buildSeed, 0x4555DD44)
  };
}

function buildV46Personality(seed, mode = "stack", version = "4.6.7") {
  const buildSeed = u32(seed);
  const modeSalt = mode === "register" ? 0xA6B17C2D : 0x51E2D39A;
  const id = mix(buildSeed ^ modeSalt, 0x46000010) % 32;
  const architectureFamily = mix(buildSeed, 0x46000001) % 6;
  const secondaryArchitecture = mix(buildSeed, 0x46000002) % 6;
  const representationFamily = mix(buildSeed, 0x46000003) % 6;
  const resolverFamily = mix(buildSeed, 0x46000004) % 6;
  const stateModel = mix(buildSeed, 0x46000005) % 6;
  const commitStyle = mix(buildSeed, 0x46000006) % 6;
  const materializationFamily = mix(buildSeed, 0x46000007) % 6;
  const pbfFamily = mix(buildSeed, 0x46000008) % 8;
  const cffFamily = mix(buildSeed, 0x46000009) % 6;
  const envFamily = mix(buildSeed, 0x4600000A) % 4;
  const microOrder = shuffle([0,1,2,3,4,5,6,7,8], mix(buildSeed, 0x4600000B));
  return {
    version: String(version || "4.6.7"),
    id,
    mode,
    architectureFamily,
    secondaryArchitecture,
    representationFamily,
    representationStyle: representationFamily,
    resolverFamily,
    stateModel,
    commitStyle,
    materializationFamily,
    stateOrder: stateProfile(buildSeed ^ 0x4600A001, mode, id),
    dispatchStyle: mix(buildSeed, 0x4600000C) % 8,
    recipeStyle: mix(buildSeed, 0x4600000D) % 8,
    microOrder,
    pbfFamily,
    cffFamily,
    envFamily,
    stateSalt: mix(buildSeed, 0x4600AA11),
    topologySalt: mix(buildSeed, 0x4600BB22),
    semanticSalt: mix(buildSeed, 0x4600CC33),
    representationSalt: mix(buildSeed, 0x4600DD44),
    resolverSalt: mix(buildSeed, 0x4600EE55),
    materializationSalt: mix(buildSeed, 0x4600FF66)
  };
}

module.exports = { buildV455Personality, buildV46Personality, mix, shuffle, u32 };

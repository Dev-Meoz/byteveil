"use strict";

const crypto = require("node:crypto");

const {
    OPS,
    buildISAPlan,
    makeOpcodeMap,
    deriveDispatchKey,
    deriveStatePermutation,
    rng
} = require("./obfuscation/isa_engine");

const {
    REGISTER_SEMANTIC_OPS,
    REGISTER_ISA_VERSION,
    buildRegisterISAPlan
} = require("./compiler/register/register_isa_v479");

const PLAN_VERSION = "byteveil-physical-isa-plan-v2";
const PLAN_MARKER = "__byteVeilOpcodePlan";

function normalizeNames(names, mode) {
    const input = mode === "register"
        ? REGISTER_SEMANTIC_OPS
        : (Array.isArray(names) && names.length ? names : OPS);

    if (!Array.isArray(input) || input.length === 0) {
        throw new TypeError(
            "opcode-mutator: names must be a non-empty opcode array"
        );
    }

    const seen = new Set();
    const result = [];

    for (const name of input) {
        if (
            typeof name !== "string" ||
            !/^[A-Z][A-Z0-9_]*$/.test(name)
        ) {
            throw new TypeError(
                `opcode-mutator: invalid semantic opcode ${String(name)}`
            );
        }

        if (seen.has(name)) {
            throw new TypeError(
                `opcode-mutator: duplicate semantic opcode ${name}`
            );
        }

        seen.add(name);
        result.push(name);
    }

    return result;
}

function u32(value) {
    return Number(value) >>> 0;
}

function fingerprintPlan(plan) {
    const names = plan.names.slice().sort();
    let hash = 0x811C9DC5;

    for (const name of names) {
        const token = `${name}:${plan.encode[name]};`;

        for (let i = 0; i < token.length; i++) {
            hash ^= token.charCodeAt(i);
            hash = Math.imul(hash, 0x01000193) >>> 0;
        }
    }

    return hash.toString(16).padStart(8, "0");
}

function verifyPlan(plan) {
    if (
        !plan ||
        typeof plan !== "object" ||
        !Array.isArray(plan.names)
    ) {
        throw new TypeError("opcode-mutator: invalid ISA plan");
    }

    const usedPhysical = new Set();

    for (const name of plan.names) {
        const physical = plan.encode?.[name];

        if (!Number.isInteger(physical) || physical < 0) {
            throw new Error(
                `opcode-mutator: missing physical encoding for ${name}`
            );
        }

        if (usedPhysical.has(physical)) {
            throw new Error(
                `opcode-mutator: physical opcode collision at ${physical}`
            );
        }

        usedPhysical.add(physical);

        if (plan.decode?.[physical] !== name) {
            throw new Error(
                `opcode-mutator: encode/decode mismatch for ${name}`
            );
        }
    }

    return {
        ok: true,
        opcodeCount: plan.names.length,
        fingerprint: fingerprintPlan(plan)
    };
}

function buildRawPlan(names, seed, options = {}) {
    const mode = options.mode === "register"
        ? "register"
        : "stack";

    const canonicalNames = normalizeNames(names, mode);

    const buildSeed = seed === undefined || seed === null
        ? (
            crypto.randomBytes(4).readUInt32LE(0) ||
            0x6D2B79F5
        )
        : u32(seed);

    const base = mode === "register"
        ? buildRegisterISAPlan(buildSeed, options)
        : buildISAPlan(canonicalNames, buildSeed, options);

    const plan = {
        ...base,

        names: canonicalNames.slice(),
        semanticNames: canonicalNames.slice(),
        mode,
        buildSeed,
        planVersion: PLAN_VERSION,
        registerISA: mode === "register"
            ? REGISTER_ISA_VERSION
            : null
    };

    // Use private map copies so a caller cannot mutate the ISA provider's maps.
    plan.encode = Object.assign(
        Object.create(null),
        base.encode
    );

    plan.decode = Object.assign(
        Object.create(null),
        base.decode
    );

    plan.order = Array.isArray(base.order)
        ? base.order.slice()
        : canonicalNames.slice();

    plan.lanes = Array.isArray(base.lanes)
        ? base.lanes.map(lane =>
            Object.assign(Object.create(null), lane)
        )
        : [];

    plan.fingerprint = fingerprintPlan(plan);

    verifyPlan(plan);

    return plan;
}

function applyOpcodePlan(root, plan, options = {}) {
    if (!root || typeof root !== "object") {
        throw new TypeError(
            "opcode-mutator.apply: root chunk must be an object"
        );
    }

    verifyPlan(plan);

    const recursive = options.recursive !== false;
    const planFingerprint = plan.fingerprint || fingerprintPlan(plan);
    const planVersion = plan.planVersion || PLAN_VERSION;

    const seen = new WeakSet();

    let chunks = 0;
    let instructions = 0;

    function applyChunk(chunk, label) {
        if (!chunk || typeof chunk !== "object") {
            throw new TypeError(
                `opcode-mutator.apply: invalid chunk at ${label}`
            );
        }

        if (seen.has(chunk)) {
            return;
        }

        seen.add(chunk);

        if (!Array.isArray(chunk.code) || !Array.isArray(chunk.consts)) {
            throw new TypeError(
                `opcode-mutator.apply: malformed code/consts at ${label}`
            );
        }

        const existing = chunk[PLAN_MARKER];

        if (
            existing &&
            existing.fingerprint === planFingerprint
        ) {
            // Applying an identical plan again is a no-op.
            chunks++;

            if (recursive) {
                for (let i = 0; i < chunk.consts.length; i++) {
                    const entry = chunk.consts[i];

                    if (entry && entry.__chunk) {
                        applyChunk(entry.__chunk, `${label}.k${i}`);
                    }
                }
            }

            return;
        }

        const oldDecode = chunk.map?.decode;

        if (!oldDecode || typeof oldDecode !== "object") {
            throw new Error(
                `opcode-mutator.apply: missing pre-remap decode map at ${label}`
            );
        }

        for (let pc = 0; pc < chunk.code.length; pc++) {
            const instruction = chunk.code[pc];

            if (!Array.isArray(instruction) || instruction.length === 0) {
                throw new Error(
                    `opcode-mutator.apply: invalid instruction at ${label}.code[${pc}]`
                );
            }

            const semanticName = oldDecode[instruction[0]];

            if (typeof semanticName !== "string") {
                throw new Error(
                    `opcode-mutator.apply: cannot resolve old opcode ${instruction[0]} at ${label}.code[${pc}]`
                );
            }

            const physical = plan.encode[semanticName];

            if (!Number.isInteger(physical)) {
                throw new Error(
                    `opcode-mutator.apply: plan does not include ${semanticName} at ${label}.code[${pc}]`
                );
            }

            instruction[0] = physical;
            instructions++;
        }

        chunk.map = {
            encode: Object.assign(
                Object.create(null),
                plan.encode
            ),

            decode: Object.assign(
                Object.create(null),
                plan.decode
            ),

            names: plan.names.slice(),

            lanes: plan.lanes.map(lane =>
                Object.assign(Object.create(null), lane)
            ),

            order: plan.order.slice(),
            version: planVersion,
            fingerprint: planFingerprint
        };

        Object.defineProperty(chunk, PLAN_MARKER, {
            value: {
                fingerprint: planFingerprint,
                mode: plan.mode || chunk.mode || "stack"
            },
            enumerable: false,
            configurable: true,
            writable: true
        });

        chunks++;

        if (recursive) {
            for (let i = 0; i < chunk.consts.length; i++) {
                const entry = chunk.consts[i];

                if (entry && entry.__chunk) {
                    applyChunk(entry.__chunk, `${label}.k${i}`);
                }
            }
        }
    }

    applyChunk(root, "root");

    return {
        ok: true,
        chunks,
        instructions,
        fingerprint: planFingerprint,
        mode: plan.mode || root.mode || "stack"
    };
}

function mutateOpcodeMap(names, seed, options = {}) {
    const plan = buildRawPlan(names, seed, options);

    // Creating the plan does not silently mutate caller bytecode.
    return {
        ...plan,

        verify: () => verifyPlan(plan),

        apply: (chunk, applyOptions) =>
            applyOpcodePlan(chunk, plan, applyOptions),

        remapChunk: (chunk, applyOptions) =>
            applyOpcodePlan(chunk, plan, applyOptions)
    };
}

module.exports = {
    rng,
    mutateOpcodeMap,
    buildISAPlan,
    deriveDispatchKey,
    deriveStatePermutation,
    verifyPlan,
    applyOpcodePlan,
    makeOpcodeMap,
    PLAN_VERSION
};
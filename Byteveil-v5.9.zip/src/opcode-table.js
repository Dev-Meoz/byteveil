"use strict";

const {
    Opcode,
    SEMANTIC_OPS,
    SEMANTIC_CLASS
} = require("./Opcode");

const {
    REGISTER_COMMAND_BY_SEMANTIC
} = require("./compiler/register/register_isa_v479");

const REGISTER_ARITY = Object.freeze({
    HALT: 0,
    PUSHK: 2, PUSHN: 2, PUSHB: 2, PUSHNIL: 1,
    GETG: 2, SETG: 2, GETL: 2, SETL: 2,
    GETI: 3, SETI: 3,

    ADD: 3, SUB: 3, MUL: 3, DIV: 3, IDIV: 3,
    MOD: 3, POW: 3, EQ: 3, NE: 3, LT: 3,
    GT: 3, LE: 3, GE: 3,

    NOT: 2, NEG: 2, LEN: 2, CONCAT: 3,
    JMP: 1, JZ: 2,

    CALL: null, RETURN: null, POP: 1, DUP: 2,
    NEWTABLE: 2, SETFIELD: 3, GETFIELD: 3,
    MAKEFUNC: 2, VARARG: 1, VARARGS: 1,

    CALLG: null, CALLGM: null, TAILCALL: null,
    CALLV: null, CALLGV: null, RETURNV: null,
    CALLP: null, APPEND: 3,
    CALLM: null,

    AND: 3, OR: 3, BAND: 3, BOR: 3, BXOR: 3,
    SHL: 3, SHR: 3, BNOT: 2,

    BREAK: 0, SWAP: 2, MOVE_SELF: 2,
    FORCMP: 3, ITERPREP: null, ITERLOOP: null,
    SUPER: null
});

const STACK_ARITY = Object.freeze({
    HALT: 0,
    PUSHK: 1, PUSHN: 1, PUSHB: 1, PUSHNIL: 0,
    GETG: 1, SETG: 1, GETL: 1, SETL: 1,
    GETI: 0, SETI: 0,

    ADD: 0, SUB: 0, MUL: 0, DIV: 0, IDIV: 0,
    MOD: 0, POW: 0, EQ: 0, NE: 0, LT: 0,
    GT: 0, LE: 0, GE: 0,

    NOT: 0, NEG: 0, LEN: 0, CONCAT: 0,
    JMP: 1, JZ: 1,

    CALL: 1, RETURN: 1, POP: 0, DUP: 0,
    NEWTABLE: 1, SETFIELD: 3, GETFIELD: 3,
    MAKEFUNC: 1, VARARG: 0, VARARGS: 0,

    CALLG: 2, CALLGM: 3, TAILCALL: 5,
    CALLP: 4, APPEND: 1,
    CALLV: 1, CALLGV: 2, RETURNV: 1, CALLM: null,

    AND: 0, OR: 0, BAND: 0, BOR: 0, BXOR: 0,
    SHL: 0, SHR: 0, BNOT: 0,

    BREAK: 0, SWAP: 0, MOVE_SELF: 0,
    FORCMP: 0, ITERPREP: null, ITERLOOP: null,
    SUPER: null
});

const ARITH = new Set([
    "ADD", "SUB", "MUL", "DIV", "IDIV", "MOD", "POW"
]);

const COMPARE = new Set(["EQ", "NE", "LT", "GT", "LE", "GE"]);

const BITWISE = new Set(["BAND", "BOR", "BXOR", "SHL", "SHR", "BNOT"]);

const CALLS = new Set([
    "CALL", "CALLG", "CALLGM", "CALLM", "CALLV", "CALLGV", "CALLP", "TAILCALL"
]);

const FLOW = new Set(["HALT", "JMP", "JZ", "RETURN", "RETURNV", "BREAK"]);

function categoryFor(name) {
    if (ARITH.has(name)) return "arithmetic";
    if (COMPARE.has(name)) return "comparison";
    if (BITWISE.has(name)) return "bitwise";
    if (CALLS.has(name)) return "call";
    if (FLOW.has(name)) return "control-flow";

    return SEMANTIC_CLASS[name] || "other";
}

function operandNames(name, mode) {
    if (mode === "stack") {
        return {
            PUSHK: ["K"],
            PUSHN: ["N"],
            PUSHB: ["B"],
            GETG: ["K"],
            SETG: ["K"],
            GETL: ["K"],
            SETL: ["K"],
            JMP: ["TARGET"],
            JZ: ["TARGET"],
            RETURN: ["COUNT"],
            NEWTABLE: ["SIZE"],
            MAKEFUNC: ["K"],
            CALLG: ["K", "ARGC"],
            CALLGM: ["K", "ARGC", "WANTED"],
            CALLGV: ["K", "ARGC"],
            CALLV: ["ARGC"],
            CALLP: ["GLOBAL_FLAG", "K_OR_ZERO", "ARGC", "VARARG_FLAG"],
            APPEND: ["BASE"],
            RETURNV: ["PREFIX_COUNT"],
            ITERPREP: ["TARGET"]
        }[name] || [];
    }

    return {
        HALT: [],
        PUSHK: ["A", "K"],
        PUSHN: ["A", "N"],
        PUSHB: ["A", "B"],
        PUSHNIL: ["A"],

        GETG: ["A", "K"],
        SETG: ["K", "A"],
        GETL: ["A", "K"],
        SETL: ["K", "A"],
        GETI: ["A", "B", "C"],
        SETI: ["A", "B", "C"],

        ADD: ["A", "B", "C"],
        SUB: ["A", "B", "C"],
        MUL: ["A", "B", "C"],
        DIV: ["A", "B", "C"],
        IDIV: ["A", "B", "C"],
        MOD: ["A", "B", "C"],
        POW: ["A", "B", "C"],

        EQ: ["A", "B", "C"],
        NE: ["A", "B", "C"],
        LT: ["A", "B", "C"],
        GT: ["A", "B", "C"],
        LE: ["A", "B", "C"],
        GE: ["A", "B", "C"],

        NOT: ["A", "B"],
        NEG: ["A", "B"],
        LEN: ["A", "B"],
        CONCAT: ["A", "B", "C"],

        JMP: ["TARGET"],
        JZ: ["A", "TARGET"],

        NEWTABLE: ["A", "SIZE"],
        SETFIELD: ["A", "K", "C"],
        GETFIELD: ["A", "B", "K"],
        MAKEFUNC: ["A", "K"],

        VARARG: ["A"],
        VARARGS: ["A"],

        ITERPREP: ["A"],
        FORCMP: ["A", "B", "C"],
        MOVE_SELF: ["A", "B"],
        SWAP: ["A", "B"],
        POP: ["A"],
        DUP: ["A", "B"],
        BNOT: ["A", "B"],
        BREAK: [],

        CALL: ["DEST", "FUNCTION", "ARGC", "REGS..."],
        CALLG: ["DEST", "K", "ARGC", "REGS..."],
        CALLGM: ["BASE", "K", "ARGC", "WANTED", "REGS..."],
        CALLM: ["BASE", "FUNCTION", "ARGC", "WANTED", "REGS..."],

        CALLV: ["DEST", "FUNCTION", "ARGC", "REGS...", "VARARG_REG"],
        CALLGV: ["DEST", "K", "ARGC", "REGS...", "VARARG_REG"],
        CALLP: ["DEST", "GLOBAL_FLAG", "FUNCTION_OR_K", "ARGC", "VARARG_FLAG", "REGS...", "VARARG_REG"],
        APPEND: ["TABLE", "PACK", "BASE"],

        RETURN: ["COUNT", "REGS..."],
        RETURNV: ["PREFIX_COUNT", "REGS...", "VARARG_REG"],

        TAILCALL: [
            "GLOBAL_FLAG", "FUNCTION_OR_K", "ARGC",
            "PREFIX_COUNT", "VARARG_FLAG", "REGS..."
        ],

        ITERLOOP: ["TARGET", "COUNT", "K..."],
        SUPER: ["SPECIALIZATION_ID", "COUNT", "PACKED_BODY..."]
    }[name] || [];
}

function makeSemanticDescriptor(name) {
    const registerCommand = REGISTER_COMMAND_BY_SEMANTIC[name] || null;
    const stackArity = STACK_ARITY[name] === undefined ? null : STACK_ARITY[name];
    const registerArity = REGISTER_ARITY[name] === undefined ? null : REGISTER_ARITY[name];

    const stackOperands = Object.freeze(operandNames(name, "stack"));
    const registerOperands = Object.freeze(operandNames(name, "register"));

    return Object.freeze({
        name,
        semantic: name,
        category: categoryFor(name),
        registerCommand,

        stack: Object.freeze({
            arity: stackArity,
            operands: stackOperands
        }),

        register: Object.freeze({
            arity: registerArity,
            operands: registerOperands
        }),

        // Compatibility fields for callers that use descriptor(name).ops.
        arity: registerArity,
        ops: registerOperands,
        physicalId: null,
        dynamicArity: stackArity === null || registerArity === null
    });
}

const LEGACY_TABLE = Object.freeze({
    LOAD: { ops: ["A", "K"], category: "constant" },
    LOADNIL: { ops: ["A", "COUNT"], category: "constant" },
    LOADB: { ops: ["A", "B"], category: "constant" },
    LOADN: { ops: ["A", "N"], category: "constant" },
    LOADK: { ops: ["A", "K"], category: "constant" },

    GETGLOBAL: { ops: ["A", "K"], category: "global" },
    SETGLOBAL: { ops: ["K", "A"], category: "global" },
    GETUPVAL: { ops: ["A", "B"], category: "upvalue" },
    SETUPVAL: { ops: ["B", "A"], category: "upvalue" },
    CLOSEUPVALS: { ops: ["A"], category: "upvalue" },

    MOVE: { ops: ["A", "B"], category: "register" },
    GETTABLE: { ops: ["A", "B", "C"], category: "table" },
    SETTABLE: { ops: ["A", "B", "C"], category: "table" },
    GETTABLEKS: { ops: ["A", "B", "K"], category: "table" },
    SETTABLEKS: { ops: ["A", "K", "C"], category: "table" },
    GETTABLEN: { ops: ["A", "B", "C"], category: "table" },
    SETTABLEN: { ops: ["A", "B", "C"], category: "table" },

    NEWCLOSURE: { ops: ["A", "K"], category: "closure" },
    NAMECALL: { ops: ["A", "B", "K"], category: "method" },
    CALL: { ops: ["A", "B", "C"], category: "call" },
    RETURN: { ops: ["A", "B"], category: "control-flow" },

    JUMP: { ops: ["D"], category: "control-flow" },
    JUMPBACK: { ops: ["D"], category: "control-flow" },
    JUMPIF: { ops: ["A", "D"], category: "control-flow" },
    JUMPIFNOT: { ops: ["A", "D"], category: "control-flow" },
    JUMPIFEQ: { ops: ["A", "B", "D"], category: "control-flow" },
    JUMPIFLE: { ops: ["A", "B", "D"], category: "control-flow" },
    JUMPIFLT: { ops: ["A", "B", "D"], category: "control-flow" },
    JUMPIFNOTEQ: { ops: ["A", "B", "D"], category: "control-flow" },
    JUMPIFNOTLE: { ops: ["A", "B", "D"], category: "control-flow" },
    JUMPIFNOTLT: { ops: ["A", "B", "D"], category: "control-flow" },

    ADD: { ops: ["A", "B", "C"], category: "arithmetic" },
    SUB: { ops: ["A", "B", "C"], category: "arithmetic" },
    MUL: { ops: ["A", "B", "C"], category: "arithmetic" },
    DIV: { ops: ["A", "B", "C"], category: "arithmetic" },
    MOD: { ops: ["A", "B", "C"], category: "arithmetic" },
    POW: { ops: ["A", "B", "C"], category: "arithmetic" },
    IDIV: { ops: ["A", "B", "C"], category: "arithmetic" },
    CONCAT: { ops: ["A", "B", "C"], category: "string" },

    NOT: { ops: ["A", "B"], category: "unary" },
    MINUS: { ops: ["A", "B"], category: "unary" },
    LENGTH: { ops: ["A", "B"], category: "unary" },
    NEWTABLE: { ops: ["A"], category: "table" },
    SETLIST: { ops: ["A", "B", "C"], category: "table" },

    FORNPREP: { ops: ["A", "D"], category: "iterator" },
    FORNLOOP: { ops: ["A", "D"], category: "iterator" },
    FORGLOOP: { ops: ["A", "D"], category: "iterator" },
    GETVARARGS: { ops: ["A", "B"], category: "vararg" }
});

const SEMANTIC_TABLE = Object.freeze(
    Object.fromEntries(
        SEMANTIC_OPS.map(name => [name, makeSemanticDescriptor(name)])
    )
);

const tableEntries = Object.assign(Object.create(null), LEGACY_TABLE);

for (const name of SEMANTIC_OPS) {
    if (!Object.prototype.hasOwnProperty.call(tableEntries, name)) {
        tableEntries[name] = SEMANTIC_TABLE[name];
    }
}

const TABLE = Object.freeze(tableEntries);

function descriptor(name, mode = "legacy") {
    let key = name;

    if (typeof name === "number" && Number.isInteger(name)) {
        const { Name } = require("./Opcode");
        key = Name[name];
        mode = "legacy";
    } else {
        key = String(name);
    }

    if (!key) {
        return null;
    }

    if (mode === "legacy") {
        return LEGACY_TABLE[key] || SEMANTIC_TABLE[key] || null;
    }

    const semantic = SEMANTIC_TABLE[key];

    if (semantic && (mode === "stack" || mode === "register")) {
        const format = semantic[mode];

        return Object.freeze({
            ...semantic,
            mode,
            arity: format.arity,
            ops: format.operands,
            operands: format.operands
        });
    }

    if (mode === "semantic") {
        return semantic || LEGACY_TABLE[key] || null;
    }

    if (mode !== "stack" && mode !== "register") {
        return TABLE[key] || null;
    }

    return LEGACY_TABLE[key] || null;
}

/**
 * Return constant-pool operand positions in the complete instruction,
 * including opcode at index 0.
 */
function constantOperandIndexes(name, instruction, mode = "register") {
    if (!Array.isArray(instruction)) {
        throw new TypeError(
            "opcode-table.constantOperandIndexes: instruction must be an array"
        );
    }

    const indexes = [];

    if (mode === "stack") {
        if ([
            "PUSHK", "GETG", "SETG", "GETL", "SETL",
            "MAKEFUNC", "CALLG", "CALLGM", "CALLGV"
        ].includes(name)) {
            indexes.push(1);
        }

        if (name === "TAILCALL" && Number(instruction[1]) === 1) {
            indexes.push(2);
        }

        // CALLP carries the global callee name in operand slot 2 only when the
        // GLOBAL_FLAG operand (slot 1) selects the global resolution path.
        if (name === "CALLP" && Number(instruction[1]) === 1) {
            indexes.push(2);
        }

        if (name === "ITERLOOP") {
            const count = Number(instruction[2]) || 0;

            for (let i = 0; i < count; i++) {
                indexes.push(3 + i);
            }
        }

        return indexes;
    }

    if (["PUSHK", "GETG", "GETL"].includes(name)) indexes.push(2);
    if (["SETG", "SETL"].includes(name)) indexes.push(1);
    if (name === "SETFIELD") indexes.push(2);
    if (name === "GETFIELD") indexes.push(3);

    if ([
        "MAKEFUNC", "CALLG", "CALLGM", "CALLGV"
    ].includes(name)) {
        indexes.push(2);
    }

    if (name === "TAILCALL" && Number(instruction[1]) === 1) {
        indexes.push(2);
    }

    // Register CALLP: [opcode, DEST, GLOBAL_FLAG, FUNCTION_OR_K, ARGC, VARARG_FLAG, ...]
    if (name === "CALLP" && Number(instruction[2]) === 1) {
        indexes.push(3);
    }

    if (name === "ITERLOOP" || name === "ITERPREP") {
        const count = Number(instruction[2]) || 0;

        for (let i = 0; i < count; i++) {
            indexes.push(3 + i);
        }
    }

    return indexes;
}

function validateInstruction(name, instruction, mode = "register") {
    const entry = descriptor(name, mode);

    if (!entry || !Array.isArray(instruction) || instruction.length === 0) {
        return {
            ok: false,
            reason: "unknown-opcode-or-invalid-instruction"
        };
    }

    const arity = entry.arity;

    if (
        arity !== null &&
        arity !== undefined &&
        instruction.length - 1 !== arity
    ) {
        return {
            ok: false,
            reason: "operand-count-mismatch",
            expected: arity,
            actual: instruction.length - 1
        };
    }

    return {
        ok: true,
        opcode: name,
        category: entry.category,
        mode
    };
}

module.exports = {
    TABLE,
    LEGACY_TABLE,
    SEMANTIC_TABLE,
    descriptor,
    constantOperandIndexes,
    validateInstruction,
    Opcode
};
"use strict";

const COMMON = {
  mode: "stack",
  strength: 1800,
  wrapper: { enabled: true, argumentCount: 8, setmeta: true, invoke: true, returnMode: "setmetatable" }
};

const PRESETS = {
  l1: {
    ...COMMON,
    transforms: {
      rename: true,
      strings: { enabled: true, rate: 0.22 },
      numbers: { enabled: true, rate: 0.15 },
      controlFlow: { enabled: true, rate: 0.20 },
      functionTransform: { enabled: true, depth: 1 },
      opcodeGuard: false,
      opcodeCount: 0,
      shardMin: 84,
      shardMax: 142,
      watermark: { enabled: true, text: "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]" },
      opcodeWhitening: true,
    },
    wrapper: { enabled: true, argumentCount: 7, setmeta: true, invoke: true, returnMode: "setmetatable" }
  },
  l2: {
    ...COMMON,
    strength: 3500,
    transforms: {
      rename: true,
      strings: { enabled: true, rate: 0.45 },
      numbers: { enabled: true, rate: 0.38 },
      controlFlow: { enabled: true, rate: 0.4 },
      functionTransform: { enabled: true, depth: 1 },
      opcodeGuard: false,
      opcodeCount: 0,
      shardMin: 90,
      shardMax: 150,
      watermark: { enabled: true, text: "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]" },
      opcodeWhitening: true,
    },
    wrapper: { enabled: true, argumentCount: 10, setmeta: true, invoke: true, returnMode: "setmetatable" }
  },
  nest: {
    ...COMMON,
    strength: 6000,
    transforms: {
      rename: true,
      strings: { enabled: true, rate: 0.55 },
      numbers: { enabled: true, rate: 0.48 },
      controlFlow: { enabled: true, rate: 0.48 },
      functionTransform: { enabled: true, depth: 1 },
      opcodeGuard: true,
      opcodeCount: 0,
      shardMin: 96,
      shardMax: 160,
      watermark: { enabled: true, text: "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]" },
      opcodeWhitening: true,
    },
    wrapper: { enabled: true, argumentCount: 11, setmeta: true, invoke: true, returnMode: "setmetatable" }
  },
  df: {
    ...COMMON,
    strength: 8000,
    transforms: {
      rename: true,
      strings: { enabled: true, rate: 0.66 },
      numbers: { enabled: true, rate: 0.58 },
      controlFlow: { enabled: true, rate: 0.56 },
      functionTransform: { enabled: true, depth: 2 },
      opcodeGuard: true,
      opcodeCount: 0,
      shardMin: 104,
      shardMax: 196,
      watermark: { enabled: true, text: "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]" },
      opcodeWhitening: true,
    },
    wrapper: { enabled: true, argumentCount: 13, setmeta: true, invoke: true, returnMode: "setmetatable" }
  },
  lz: {
    ...COMMON,
    strength: 10000,
    transforms: {
      rename: true,
      strings: { enabled: true, rate: 0.72 },
      numbers: { enabled: true, rate: 0.65 },
      controlFlow: { enabled: true, rate: 0.6 },
      functionTransform: { enabled: true, depth: 2 },
      opcodeGuard: true,
      opcodeCount: 0,
      shardMin: 112,
      shardMax: 224,
      watermark: { enabled: true, text: "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]" },
      opcodeWhitening: true,
    },
    wrapper: { enabled: true, argumentCount: 14, setmeta: true, invoke: true, returnMode: "setmetatable" }
  },
  // Compatibility aliases for older bot configs.
  default: null,
  maximum: null,
};

const LEGACY_WATERMARK = "This file was protected by Bytecode [https://discord.gg/tBSS6Z6J6/]";
PRESETS.default = { ...PRESETS.l1, compatibilityRoute: true, transforms: { ...PRESETS.l1.transforms, watermark: { enabled: true, text: LEGACY_WATERMARK } } };
PRESETS.maximum = { ...PRESETS.lz, compatibilityRoute: true, transforms: { ...PRESETS.lz.transforms, watermark: { enabled: true, text: LEGACY_WATERMARK } } };
Object.freeze(PRESETS);

function getPreset(name = "l1") {
  const key = String(name).toLowerCase();
  if (!PRESETS[key]) throw new Error(`Unknown preset: ${name}`);
  return JSON.parse(JSON.stringify(PRESETS[key]));
}

module.exports = { PRESETS, getPreset };

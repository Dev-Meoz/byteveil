"use strict";

/**
 * ByteVeil v4.3 access-shape planner.
 *
 * The VM still uses numeric slot allocation internally, but generated source
 * does not need to expose every fixed state field as `S[14]`. We rewrite
 * statically-known VM/decoy state slots to randomized identifier fields.
 * Dynamic array/map access remains bracket-based.
 */

const RESERVED = new Set([
  "and","break","do","else","elseif","end","false","for","function","goto",
  "if","in","local","nil","not","or","repeat","return","then","true","until","while"
]);

function u32(n) { return Number(n) >>> 0; }

function mix(seed, value) {
  let s = u32(seed) ^ u32(value) ^ 0xA53C9E17;
  s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}

function fieldName(seed, index, prefix = "q") {
  const alphabet = "abcdefghijklmnopqrstuvwxyz";
  let x = mix(seed, index * 0x45D9F3B);
  let out = prefix;
  for (let i = 0; i < 3; i++) {
    out += alphabet[x % alphabet.length];
    x = Math.floor(x / alphabet.length);
  }
  if (RESERVED.has(out)) return `${prefix}_${out}`;
  return out;
}

function buildAliases(seed, slots, prefix = "q") {
  const names = Object.create(null);
  const used = new Set();
  for (const field of Object.keys(slots || {})) {
    let candidate = fieldName(seed ^ slots[field], slots[field], prefix);
    let n = 1;
    while (used.has(candidate)) candidate = `${candidate}${n++}`;
    used.add(candidate);
    names[field] = candidate;
  }
  return names;
}

function rewriteObjectSlots(output, objectName, slots, aliases) {
  let out = String(output);
  for (const field of Object.keys(slots || {})) {
    const slot = Number(slots[field]);
    const alias = aliases[field];
    if (!Number.isInteger(slot) || !alias) continue;
    out = out.replace(new RegExp(`\\b${objectName}\\[${slot}\\](?=[A-Za-z_])`, "g"), `${objectName}.${alias} `);
    out = out.replace(new RegExp(`\\b${objectName}\\[${slot}\\]`, "g"), `${objectName}.${alias}`);
  }
  return out;
}

function audit(output) {
  const text = String(output);
  const brackets = (text.match(/\[/g) || []).length;
  const nested = (text.match(/\[[^\]]*\[/g) || []).length;
  const keyedFunctions = (text.match(/\[[^\]]+\]\s*=\s*function/g) || []).length;
  const staticNumericAccess = (text.match(/\b(?:S|D)\[\d+\]/g) || []).length;
  return {
    brackets,
    nested,
    keyedFunctions,
    staticNumericAccess,
    dynamicAccessRatio: brackets ? Math.max(0, (brackets - staticNumericAccess) / brackets) : 1
  };
}

function rewriteGeneratedAccessShape(output, { seed = 1, realSlots = {}, decoySlots = {} } = {}) {
  // The legacy Real-VM handlers intentionally reuse `S` as a state alias and
  // as a local temporary in a few helper scopes. A global S/Q rewrite is not
  // scope-aware and can therefore desynchronize the state constructor. For
  // v4.3 the safe layout reduction is applied to the dedicated decoy state
  // instances and their handlers, whose object identities are unambiguous.
  const realAliases = buildAliases(u32(seed ^ 0x51A7), realSlots, "s");
  const decoyAliases = buildAliases(u32(seed ^ 0xD3C0), decoySlots, "d");
  let out = String(output);
  out = rewriteObjectSlots(out, "D", decoySlots, decoyAliases);
  for (const instance of ["D0", "D1", "D2", "D3"]) {
    out = rewriteObjectSlots(out, instance, decoySlots, decoyAliases);
  }
  const before = audit(output);
  const after = audit(out);
  return { output: out, realAliases, decoyAliases, before, after };
}

module.exports = { buildAliases, rewriteGeneratedAccessShape, audit };

"use strict";

function u32(n) {
  return Number(n) >>> 0;
}

function mix32(seed, value) {
  let s = u32(seed ^ value ^ 0xB17E4A31);
  s ^= s >>> 16;
  s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13;
  s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}

function deriveFabricToken(baseSeed, strength, mode = "stack") {
  const buildSeed = u32(baseSeed);
  const normalizedStrength = Math.max(100, Math.min(10000, Number(strength) || 1000));
  const profile = depthProfile(normalizedStrength);
  const modeSalt = String(mode) === "register" ? 0x13579BDF : 0x2468ACE0;
  const salt = u32((Math.imul(normalizedStrength >>> 0, 0x9E3779B1) ^ profile.depth ^ (profile.stages << 11) ^ modeSalt) >>> 0);
  let s = u32(buildSeed ^ 0x4D464731 ^ modeSalt);
  for (let i = 1; i <= profile.budget; i++) {
    s = u32(Math.imul(s, 1664525) + Math.imul(i, 1013904223) + salt);
  }
  s = u32(Math.imul((s ^ (s >>> 16)) >>> 0, 2246822519));
  s ^= s >>> 13;
  s = u32(Math.imul(s, 3266489917));
  s ^= s >>> 16;
  return u32(s ^ 0xA17B9C35);
}

/*
 * v4.5.5: domain-separated material dependency graph.
 * No returned value is reused as the universal payload/activation key.
 */
function deriveMaterial(baseSeed, domain, strength, mode = "stack") {
  const modeSalt = String(mode) === "register" ? 0x13579BDF : 0x2468ACE0;
  const profile = depthProfile(strength);
  let s = mix32(baseSeed, u32(domain ^ modeSalt ^ profile.depth ^ (profile.stages << 11)));
  s = mix32(s, u32(Math.imul((Number(strength) >>> 0), 0x45D9F3B)));
  s = mix32(s, u32(domain ^ 0x9E3779B9));
  return u32(s ^ u32(domain * 2654435761));
}

function deriveProtectionMaterials(baseSeed, strength = 1000, mode = "stack") {
  const seed = u32(baseSeed);
  return {
    activation: deriveMaterial(seed, 0xA1, strength, mode),
    payloadA: deriveMaterial(seed, 0xB3, strength, mode),
    payloadB: deriveMaterial(seed, 0xC7, strength, mode),
    payloadC: deriveMaterial(seed, 0xD9, strength, mode),
    payloadD: deriveMaterial(seed, 0xEB, strength, mode),
    opcode: deriveMaterial(seed, 0xF1, strength, mode),
    codec: deriveMaterial(seed, 0x117, strength, mode),
    integrity: deriveMaterial(seed, 0x12B, strength, mode),
    guard: deriveMaterial(seed, 0x13D, strength, mode)
  };
}

function depthProfile(strength) {
  if (strength >= 10000) return { depth: 96, budget: 9, stages: 4, hookChecks: 4, tamperChecks: 4 };
  if (strength >= 8000) return { depth: 64, budget: 7, stages: 4, hookChecks: 3, tamperChecks: 3 };
  if (strength >= 3500) return { depth: 40, budget: 5, stages: 3, hookChecks: 2, tamperChecks: 2 };
  return { depth: 24, budget: 4, stages: 3, hookChecks: 1, tamperChecks: 1 };
}

function buildProtectionPlan({ seed = 1, strength = 1000, mode = "stack", opcodeCount = 0, macroPlan = null, lphPlan = null, version = "4.5.5" } = {}) {
  const buildSeed = u32(seed);
  const singleLayer = version === "4.7.3" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"));
  const profile = depthProfile(strength);
  const materials = deriveProtectionMaterials(buildSeed, strength, mode);
  return {
    version,
    engine: "Byte-Blinder",
    generator: ["4.6.1", "4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7", "4.6.8", "4.7.1", "4.7.2", "4.7.3", "4.7.4", "4.7.5", "4.7.6", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(version)
      ? (version === "5.9.0" ? "MFG-5.9.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : version === "5.8.0" ? "MFG-5.8.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : version === "5.7.0" ? "MFG-5.7.0-callable-bootstrap-veilsync-v2-region-verified-vm" : version === "5.6.0" ? "MFG-5.6.0-veilsync-v2-region-verified-shadow-hardened-carrier-vm" : version === "5.5.0" ? "MFG-5.5.0-veilsync-shadow-hardened-carrier-vm" : version === "5.4.0" ? "MFG-5.4.0-build-diverse-shadow-hardened-carrier-vm" : version === "5.3.0" ? "MFG-5.3.0-build-diverse-carrier-vm" : version === "5.0.0" ? "MFG-5.0.0-position-keyed-carrier-vm" : version === "4.7.9" ? "MFG-4.7.9-striped-payload-vm" : version === "4.7.8" ? "MFG-4.7.8-semantic-shadow-vm" : version === "4.7.7" ? "MFG-4.7.7-hybrid-function-policy" : version === "4.7.6" ? "MFG-4.7.6-interleaved-shadow-vm" : version === "4.7.5" ? "MFG-4.7.5" : version === "4.7.4" ? "MFG-4.7.4" : version === "4.7.3" ? "MFG-4.7.3" : version === "4.7.2" ? "MFG-4.7.2" : version === "4.7.1" ? "MFG-4.7.1" : version === "4.6.8" ? "MFG-4.6.8" : version === "4.6.7" ? "MFG-4.6.7" : version === "4.6.6" ? "MFG-4.6.6" : version === "4.6.5" ? "MFG-4.6.5" : version === "4.6.4" ? "MFG-4.6.4" : "MFG-4.6.3")
      : "MFG-4.5.5",
    protectionIR: (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")))) ? "v4.6-architecture-graph-micro" : "v4.5.5-heterogeneous-graph-micro",
    mode: mode === "register" ? "register" : "stack",
    sharedExecutionFabric: true,
    fragmentGraph: true,
    nonLinearDependencies: true,
    materialDependencyGraph: true,
    opaqueTransportIR: true,
    perRegionOpcodeMapping: true,
    runtimeGeneratedDispatch: true,
    semanticMicroOps: true,
    realRepresentationMorphing: (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")))),
    buildSpecificArchitecture: (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")))),
    runtimeGeneratedSemanticVM: (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")))),
    payloadMaterialization: version === "5.9.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : version === "5.8.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.8-shared-shadow-dispatch-core-callable-bootstrap-region-verified" : version === "5.7.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.7-callable-bootstrap-region-verified" : version === "5.6.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-veilsync-v2-region-verified" : version === "5.5.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-veilsync" : version === "5.4.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse-shadow-local-mangled" : version === "5.3.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.1-build-diverse" : version === "5.0.0" ? "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5" : version === "4.7.9" ? "striped-payload-lanes-packed-descriptor-lazy-region-v479" : version === "4.7.8" ? "hybrid-function-policy-binary-region-semantic-shadow-v478" : version === "4.7.7" ? "hybrid-function-policy-binary-region-v477" : version === "4.7.6" ? "fragment-graph-binary-region-v476-interleaved-shadow-vm" : version === "4.7.5" ? "fragment-graph-binary-region-v475-eight-lane-buffer" : (singleLayer ? "single-layer-packed-bytecode-vm-v473-distributed-payload" : "fragment-graph-material-dag-opaque-ir-vma-vmb-microop"),
    isaVariants: 4,
    decoderFamilies: 4,
    antiHook: true,
    antiTamper: true,
    antiDump: true,
    profile,
    materialDomains: 9,
    materials,
    opcodeCount: Number(opcodeCount) || 0,
    macroEngine: { version: macroPlan?.version || null, directives: macroPlan?.directives?.length || 0, effectiveDirectives: macroPlan?.effectiveDirectiveCount || 0, applied: macroPlan?.applied === true, resolved: macroPlan?.resolved ?? null },
    lphEngine: { version: lphPlan?.version || null, directives: lphPlan?.directives?.length || 0, effectiveDirectives: lphPlan?.effectiveDirectiveCount || 0, applied: lphPlan?.applied === true, resolved: lphPlan?.resolved ?? null },
    nestedObfuscation: !singleLayer,
    nestedLayering: (version === "5.8.0" || version === "5.9.0") ? "hybrid-function-policy-veilsync-v2-region-verified-shared-shadow-dispatch-core-callable-bootstrap-position-keyed-striped-payload-vm-no-source-loader" : version === "5.7.0" ? "hybrid-function-policy-veilsync-v2-region-verified-callable-bootstrap-position-keyed-striped-payload-vm-no-source-loader" : version === "5.6.0" ? "hybrid-function-policy-veilsync-v2-all-region-verified-shadow-local-mangled-position-keyed-striped-payload-vm-no-source-loader" : version === "5.5.0" ? "hybrid-function-policy-veilsync-shadow-local-mangled-position-keyed-striped-payload-vm-no-source-loader" : version === "5.4.0" ? "hybrid-function-policy-build-diverse-shadow-local-mangled-position-keyed-striped-payload-vm-no-source-loader" : version === "5.3.0" ? "hybrid-function-policy-build-diverse-position-keyed-striped-payload-vm-no-source-loader" : version === "5.0.0" ? "hybrid-function-policy-position-keyed-striped-payload-vm-no-source-loader" : version === "4.7.9" ? "hybrid-function-policy-striped-payload-vm-no-source-loader" : version === "4.7.8" ? "hybrid-function-policy-binary-region-vm-semantic-shadow-no-source-loader" : version === "4.7.7" ? "hybrid-function-policy-binary-region-vm-no-source-loader" : version === "4.7.6" ? "binary-region-interleaved-shadow-vm-no-source-loader" : version === "4.7.5" ? "binary-region-transform-no-source-loader" : (singleLayer ? "single-packed-bytecode-vm" : "heterogeneous-source-onion"),
    singleLayerEngine: singleLayer,
    sourceLayerCount: version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0") ? 0 : singleLayer ? 1 : null,
    runtimeShield: { antiTamper: true, antiHook: true, antiDump: true, distributed: true }
  };
}

module.exports = {
  u32,
  mix32,
  deriveFabricToken,
  deriveMaterial,
  deriveProtectionMaterials,
  depthProfile,
  buildProtectionPlan
};

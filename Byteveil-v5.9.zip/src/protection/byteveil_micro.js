"use strict";

const crypto = require("node:crypto");

/**
 * ByteVeil-Micro v5.1.x
 *
 * Shared support helpers for Macro/LPH engines.
 *
 * Responsibilities:
 * - Hidden AST metadata.
 * - Safe effect merging.
 * - Deterministic identifier mangling.
 * - Binding-identity-based name mapping.
 *
 * This module does not own or rewrite either Macro or LPH engine.
 */

const hasOwn = (value, key) =>
    Object.prototype.hasOwnProperty.call(value, key);

const isObjectLike = value =>
    value !== null &&
    (typeof value === "object" || typeof value === "function");

const RESERVED_WORDS = new Set(`
    await break case catch class const continue debugger default delete do
    else enum export extends false finally for function if implements
    import in instanceof interface let new null package private protected
    public return static super switch this throw true try typeof var void
    while with yield arguments eval

    and end repeat until local then elseif nil not or goto
`.trim().split(/\s+/));

function normalizePropertyKey(key) {
    if (typeof key !== "string" && typeof key !== "symbol") {
        throw new TypeError(
            "byteveil_micro.attach: key must be a string or symbol"
        );
    }

    return key;
}

/**
 * Attach metadata to an AST/object without making it enumerable by default.
 *
 * Backward-compatible API:
 *   attach(ast, key, value)
 *
 * Optional descriptor:
 *   attach(ast, key, value, {
 *       enumerable: false,
 *       configurable: true,
 *       writable: true
 *   })
 */
function attach(ast, key, value, descriptor = undefined) {
    if (!isObjectLike(ast)) {
        return ast;
    }

    normalizePropertyKey(key);

    if (
        descriptor !== undefined &&
        (!isObjectLike(descriptor) || Array.isArray(descriptor))
    ) {
        throw new TypeError(
            "byteveil_micro.attach: descriptor must be an object"
        );
    }

    const extra = descriptor || {};

    const propertyDescriptor = {
        value,
        enumerable: extra.enumerable === true,
        configurable: extra.configurable !== false,
        writable: extra.writable !== false
    };

    const current = Object.getOwnPropertyDescriptor(ast, key);

    if (current && current.configurable === false) {
        if (
            Object.prototype.hasOwnProperty.call(current, "value") &&
            Object.is(current.value, value)
        ) {
            return ast;
        }

        throw new TypeError(
            `byteveil_micro.attach: property ${String(key)} is non-configurable`
        );
    }

    Object.defineProperty(ast, key, propertyDescriptor);

    return ast;
}

/**
 * Attach multiple enumerable source entries as AST metadata.
 */
function attachMany(ast, entries, descriptor = undefined) {
    if (!isObjectLike(ast)) {
        return ast;
    }

    if (!isObjectLike(entries) || Array.isArray(entries)) {
        throw new TypeError(
            "byteveil_micro.attachMany: entries must be an object"
        );
    }

    for (const key of Reflect.ownKeys(entries)) {
        const property = Object.getOwnPropertyDescriptor(entries, key);

        if (!property || !property.enumerable) {
            continue;
        }

        attach(ast, key, entries[key], descriptor);
    }

    return ast;
}

/**
 * Read an own metadata property.
 */
function readAttached(ast, key, fallback = undefined) {
    if (!isObjectLike(ast) || !hasOwn(ast, key)) {
        return fallback;
    }

    return ast[key];
}

/**
 * Validate a transformation plan and return its effects object.
 */
function normalizeEffects(plan, index) {
    if (plan == null) {
        return null;
    }

    if (!isObjectLike(plan) || Array.isArray(plan)) {
        throw new TypeError(
            `byteveil_micro.mergeEffects: plan ${index} must be an object`
        );
    }

    const effects = plan.effects;

    if (effects == null) {
        return null;
    }

    if (!isObjectLike(effects) || Array.isArray(effects)) {
        throw new TypeError(
            `byteveil_micro.mergeEffects: plan ${index}.effects must be an object`
        );
    }

    return effects;
}

/**
 * Merge plan.effects objects.
 *
 * Compatibility:
 * - The result has a null prototype, as in the original implementation.
 * - Later plans override earlier values.
 * - Missing/null effects are ignored.
 */
function mergeEffects(...plans) {
    const merged = Object.create(null);

    for (let i = 0; i < plans.length; i++) {
        const effects = normalizeEffects(plans[i], i);

        if (!effects) {
            continue;
        }

        for (const key of Object.keys(effects)) {
            merged[key] = effects[key];
        }
    }

    return merged;
}

/**
 * Merge effects and report conflicting assignments.
 *
 * Later plans still win, preserving mergeEffects semantics.
 */
function mergeEffectsDetailed(...plans) {
    const effects = Object.create(null);
    const conflicts = [];

    for (let i = 0; i < plans.length; i++) {
        const source = normalizeEffects(plans[i], i);

        if (!source) {
            continue;
        }

        for (const key of Object.keys(source)) {
            if (
                hasOwn(effects, key) &&
                !Object.is(effects[key], source[key])
            ) {
                conflicts.push({
                    key,
                    previousValue: effects[key],
                    nextValue: source[key],
                    planIndex: i
                });
            }

            effects[key] = source[key];
        }
    }

    return {
        effects,
        conflicts
    };
}

/**
 * Stable seed hashing.
 *
 * This is used to make generated identifier names reproducible.
 * It is not a cryptographic hash.
 */
function hashSeed(seed) {
    const text = String(seed);
    let hash = 2166136261;

    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619) >>> 0;
    }

    return hash || 0x6D2B79F5;
}

function sanitizePrefix(prefix) {
    const cleaned = String(prefix == null ? "_bv" : prefix)
        .replace(/[^A-Za-z0-9_]/g, "_");

    const valid = /^[A-Za-z_]/.test(cleaned)
        ? cleaned
        : `_${cleaned}`;

    return valid || "_bv";
}

/**
 * Create a collision-aware generated identifier factory.
 *
 * Options:
 *   seed       Reproducible output for the same seed/options.
 *   prefix     Generated identifier prefix. Default: "_bv".
 *   minLength  Minimum random suffix length. Default: 7.
 *   maxLength  Maximum random suffix length. Default: 12.
 *   reserved   Existing identifiers that must not be reused.
 *   reserve    Additional names to reserve immediately.
 *
 * Returned methods:
 *   next()          Generate a new identifier.
 *   reserve(name)   Mark an identifier as unavailable.
 *   has(name)       Test if a name is reserved/already generated.
 *   fork(label)     Create an independent deterministic factory.
 *   snapshot()      Inspect generated names and configuration.
 *
 * This is identifier mangling, not cryptographic randomness.
 */
function createNameFactory(options = {}) {
    if (
        typeof options === "string" ||
        typeof options === "number"
    ) {
        options = {
            seed: options
        };
    }

    if (!isObjectLike(options) || Array.isArray(options)) {
        throw new TypeError(
            "byteveil_micro.createNameFactory: options must be an object"
        );
    }

    const seed = options.seed === undefined
        ? crypto.randomBytes(16).toString("hex")
        : options.seed;

    let state = hashSeed(seed);

    const prefix = sanitizePrefix(options.prefix);

    const minLength = options.minLength === undefined
        ? 7
        : options.minLength;

    const maxLength = options.maxLength === undefined
        ? 12
        : options.maxLength;

    if (
        !Number.isInteger(minLength) ||
        minLength < 3 ||
        minLength > 64
    ) {
        throw new RangeError(
            "byteveil_micro.createNameFactory: minLength must be 3..64"
        );
    }

    if (
        !Number.isInteger(maxLength) ||
        maxLength < minLength ||
        maxLength > 96
    ) {
        throw new RangeError(
            "byteveil_micro.createNameFactory: maxLength must be minLength..96"
        );
    }

    const reserved = new Set(RESERVED_WORDS);
    const generated = new Set();

    if (options.reserved != null) {
        if (
            typeof options.reserved[Symbol.iterator] !== "function"
        ) {
            throw new TypeError(
                "byteveil_micro.createNameFactory: reserved must be iterable"
            );
        }

        for (const name of options.reserved) {
            reserved.add(String(name));
        }
    }

    const firstAlphabet =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    const bodyAlphabet =
        `${firstAlphabet}0123456789_`;

    function randomUint32() {
        // xorshift32: deterministic PRNG for name generation only.
        state ^= state << 13;
        state ^= state >>> 17;
        state ^= state << 5;

        state >>>= 0;

        if (state === 0) {
            state = 0x6D2B79F5;
        }

        return state;
    }

    function pick(alphabet) {
        return alphabet[
            randomUint32() % alphabet.length
        ];
    }

    function candidate() {
        const span = maxLength - minLength + 1;
        const length = minLength + (randomUint32() % span);

        let name = prefix + pick(firstAlphabet);

        for (let i = 1; i < length; i++) {
            name += pick(bodyAlphabet);
        }

        return name;
    }

    function has(name) {
        return reserved.has(name) || generated.has(name);
    }

    function reserve(name) {
        if (typeof name !== "string" || name.length === 0) {
            throw new TypeError(
                "byteveil_micro.nameFactory.reserve: name must be a non-empty string"
            );
        }

        reserved.add(name);

        return api;
    }

    function next() {
        for (let attempt = 0; attempt < 10000; attempt++) {
            const name = candidate();

            if (!has(name)) {
                generated.add(name);
                return name;
            }
        }

        // Deterministic collision fallback for unusually crowded spaces.
        let suffix = 0;

        for (;;) {
            const name =
                `${prefix}${pick(firstAlphabet)}${(++suffix).toString(36)}`;

            if (!has(name)) {
                generated.add(name);
                return name;
            }
        }
    }

    function fork(label) {
        return createNameFactory({
            seed: `${String(seed)}\u0000${String(label)}`,
            prefix,
            minLength,
            maxLength,
            reserved: [
                ...reserved,
                ...generated
            ]
        });
    }

    function snapshot() {
        return Object.freeze({
            seed: String(seed),
            prefix,
            reservedCount: reserved.size,
            generatedCount: generated.size,
            generatedNames: Object.freeze([
                ...generated
            ])
        });
    }

    const api = Object.freeze({
        next,
        reserve,
        has,
        fork,
        snapshot
    });

    if (Array.isArray(options.reserve)) {
        for (const name of options.reserve) {
            reserve(String(name));
        }
    }

    return api;
}

/**
 * Map source identifier strings to generated identifiers.
 *
 * Repeated occurrences of the same source name reuse the same output name.
 * For lexical scopes with shadowing, prefer mangleBindings().
 */
function mangleNames(names, options = {}) {
    if (
        names == null ||
        typeof names[Symbol.iterator] !== "function"
    ) {
        throw new TypeError(
            "byteveil_micro.mangleNames: names must be iterable"
        );
    }

    const factory = options.factory ||
        createNameFactory(options);

    const mapping = new Map();

    for (const name of names) {
        if (typeof name !== "string" || name.length === 0) {
            throw new TypeError(
                "byteveil_micro.mangleNames: every name must be a non-empty string"
            );
        }

        if (!mapping.has(name)) {
            mapping.set(name, factory.next());
        }
    }

    return mapping;
}

/**
 * Map binding objects by identity rather than by source spelling.
 *
 * Two different bindings named "value" can receive different output
 * names, which is necessary for lexical shadowing.
 *
 * Returns Map<bindingObject, generatedName>.
 */
function mangleBindings(bindings, options = {}) {
    if (
        bindings == null ||
        typeof bindings[Symbol.iterator] !== "function"
    ) {
        throw new TypeError(
            "byteveil_micro.mangleBindings: bindings must be iterable"
        );
    }

    const factory = options.factory ||
        createNameFactory(options);

    const mapping = new Map();

    for (const binding of bindings) {
        if (!isObjectLike(binding)) {
            throw new TypeError(
                "byteveil_micro.mangleBindings: each binding must be an object"
            );
        }

        if (!mapping.has(binding)) {
            mapping.set(binding, factory.next());
        }
    }

    return mapping;
}

module.exports = {
    attach,
    attachMany,
    readAttached,

    mergeEffects,
    mergeEffectsDetailed,

    createNameFactory,
    mangleNames,
    mangleBindings
};
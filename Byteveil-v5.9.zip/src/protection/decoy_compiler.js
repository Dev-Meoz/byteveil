"use strict";

const { SEMANTIC_CLASS } = require("../obfuscation/isa_engine");

function u32(n) { return Number(n) >>> 0; }
function mix(seed, value) {
  let s = u32(seed) ^ u32(value) ^ 0xC0DEC0DE;
  s ^= s >>> 16; s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13; s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}

const SAFE_SEQUENCE = [
  "PUSHN","PUSHB","PUSHNIL","DUP","SWAP","NOT","NEG","LEN","NEWTABLE",
  "ADD","SUB","MUL","DIV","IDIV","MOD","POW","EQ","NE","LT","GT","LE","GE",
  "AND","OR","BAND","BOR","BXOR","SHL","SHR","BNOT","CONCAT","GETI","SETI",
  "MOVE_SELF","FORCMP","ITERPREP","POP"
];

function operandShape(op, i, mode, seed) {
  // Previous decoy operands depended only on the instruction index, so every
  // build reused the same operand pattern even when opcode selection changed.
  // Derive independent bounded values from the per-build seed instead.
  const a = mix(seed ^ Math.imul(i + 1, 0x9E3779B1), i + 1) % 257;
  const b = mix(seed ^ 0xD1B54A35, Math.imul(i + 3, 0x85EBCA6B)) % 257;
  if (["PUSHN","PUSHB"].includes(op)) return [a];
  if (["GETG","GETL","SETG","SETL","MAKEFUNC"].includes(op)) return [a];
  if (["JMP","JZ"].includes(op)) return [a];
  if (["CALL","CALLG","CALLGM","CALLM"].includes(op)) return mode === "stack" ? [a % 3] : [0, b % 3, 1];
  if (op === "RETURN") return [a % 2];
  if (op === "ITERPREP") return mode === "stack" ? [a % 2] : [1, a % 2];
  if (op === "ITERLOOP") return [1, a % 2];
  if (op === "SUPER") return [1, 1];
  if (["PUSHK"].includes(op)) return [a];
  if (mode === "register" && ["GETI","SETI","GETFIELD","SETFIELD"].includes(op)) return [1,2,3];
  return [];
}

function buildDecoyProgram({ opNames = [], encode = {}, seed = 1, depth = 24, mode = "stack" } = {}) {
  const available = SAFE_SEQUENCE.filter((name) => opNames.includes(name) && Number.isInteger(encode[name]));
  const source = available.length ? available : opNames.filter((name) => Number.isInteger(encode[name]));
  if (!source.length) {
    throw new Error("ByteVeil decoy compiler: no valid physical opcodes were supplied");
  }
  const count = Math.max(1, Math.min(128, Number(depth) || 24));
  const instructions = [];
  for (let i = 0; i < count; i++) {
    const idx = mix(seed ^ 0x8A31, i + 1) % source.length;
    const op = source[idx];
    const physical = Number(encode[op]);
    if (!Number.isInteger(physical) || physical < 0) {
      throw new Error(`ByteVeil decoy compiler: invalid physical opcode for ${op}`);
    }
    instructions.push([physical, ...operandShape(op, i, mode, seed)]);
  }
  // Fingerprint the instruction contents rather than only the list length and
  // opcode count, which made materially different decoy programs collide.
  let fingerprintState = mix(seed ^ 0x3C6EF372, instructions.length);
  for (let i = 0; i < instructions.length; i++) {
    for (let j = 0; j < instructions[i].length; j++) {
      fingerprintState = mix(fingerprintState, (instructions[i][j] >>> 0) ^ Math.imul(i + 1, j + 17));
    }
  }
  return {
    instructions,
    operationNames: source.slice(),
    semanticClasses: source.map((name) => SEMANTIC_CLASS[name] || "unknown"),
    fingerprint: fingerprintState.toString(16).padStart(8, "0")
  };
}

module.exports = { buildDecoyProgram };

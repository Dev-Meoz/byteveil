"use strict";

const strings = require("../transforms/string_obfuscator");
const controlFlow = require("../transforms/control_flow");
const functionTransform = require("../transforms/function_transform");

const STATEMENTS = new Set([
  "Local", "LocalFunction", "Function", "Assign", "Compound", "CallStmt", "Return",
  "If", "While", "Repeat", "Do", "ForNum", "ForIn", "Break", "Continue", "Goto", "Label"
]);

function hidden(object, key, value) {
  Object.defineProperty(object, key, { value, enumerable: false, configurable: true, writable: true });
  return object;
}

function walk(node, visitor, parent = null, key = null, seen = new Set()) {
  if (!node || typeof node !== "object" || seen.has(node)) return;
  seen.add(node);
  visitor(node, parent, key);
  if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) walk(node[i], visitor, node, i, seen);
  } else {
    for (const childKey of Object.keys(node)) walk(node[childKey], visitor, node, childKey, seen);
  }
}

function collectStatementBindings(ast) {
  const result = [];
  walk(ast, (node, parent, key) => {
    if (!STATEMENTS.has(node.type) || !parent) return;
    const array = Array.isArray(parent) ? parent : null;
    result.push({ node, parent, key, array, index: array ? key : -1, line: Number(node.__line) || 0, col: Number(node.__col) || 0 });
  });
  return result;
}

function hashText(text, seed = 2166136261) {
  let h = Number(seed) >>> 0;
  for (const ch of String(text)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  return h >>> 0;
}

function directiveSalt(plans) {
  let h = 0x6D2B79F5;
  let count = 0;
  for (const plan of plans || []) {
    for (const d of plan?.directives || []) {
      count++;
      h = hashText(`${plan.engine || "engine"}:${d.name}:${(d.args || []).join("\u001f")}:${d.targetLine || d.line || 0}:${d.targetType || ""}`, h ^ 0x9E3779B9);
    }
  }
  return count ? (h >>> 0) : 0;
}

function makeChunk(node) {
  if (STATEMENTS.has(node?.type)) return { chunk: { type: "Chunk", body: [node] }, expression: false, holder: null };
  const holder = { type: "Return", values: [node] };
  return { chunk: { type: "Chunk", body: [holder] }, expression: true, holder };
}

function unwrapChunkResult(result, wrapped) {
  if (!wrapped.expression) return result?.body?.[0] || result;
  return wrapped.holder?.values?.[0];
}

function transformScoped(node, transformer, options) {
  const wrapped = makeChunk(node);
  const result = transformer(wrapped.chunk, options) || wrapped.chunk;
  return unwrapChunkResult(result, wrapped);
}

function splitKeyStrings(root) {
  let changed = 0;
  walk(root, node => {
    if (node.type !== "Index" || node.key?.type !== "String" || typeof node.key.value !== "string") return;
    const text = node.key.value;
    if (text.length < 4) return;
    const cut = Math.max(1, Math.floor(text.length / 2));
    node.key = {
      type: "Binary", op: "..",
      left: { type: "String", value: text.slice(0, cut) },
      right: { type: "String", value: text.slice(cut) }
    };
    changed++;
  });
  return changed;
}

function cloneTree(value) {
  if (Array.isArray(value)) return value.map(cloneTree);
  if (!value || typeof value !== "object") return value;
  const out = {};
  for (const [key, child] of Object.entries(value)) out[key] = cloneTree(child);
  return out;
}

function isInlineLiteral(node) {
  return !!node && ["Number", "String", "Boolean", "Nil"].includes(node.type);
}

function isInlineSafeExpression(node) {
  if (!node || typeof node !== "object") return false;
  switch (node.type) {
    case "Number": case "String": case "Boolean": case "Nil": case "Id": return true;
    case "Unary": return isInlineSafeExpression(node.arg);
    case "Binary": return isInlineSafeExpression(node.left) && isInlineSafeExpression(node.right);
    default: return false;
  }
}

function substituteInlineParams(expr, params, args) {
  const counts = Object.create(null);
  function replace(node) {
    if (!node || typeof node !== "object") return node;
    if (node.type === "Id" && Object.prototype.hasOwnProperty.call(params, node.name)) {
      const index = params[node.name];
      counts[node.name] = (counts[node.name] || 0) + 1;
      return cloneTree(args[index]);
    }
    const out = cloneTree(node);
    for (const key of Object.keys(out)) {
      if (Array.isArray(out[key])) out[key] = out[key].map(value => replace(value));
      else if (out[key] && typeof out[key] === "object") out[key] = replace(out[key]);
    }
    return out;
  }
  const result = replace(expr);
  return { result, counts };
}

function inlineSimpleFunction(binding) {
  const fnStmt = binding?.node;
  const body = binding?.array;
  if (fnStmt?.type !== "LocalFunction" || !body || !Array.isArray(fnStmt.fn?.body)) return 0;
  const fnBody = fnStmt.fn.body;
  if (fnBody.length !== 1 || fnBody[0]?.type !== "Return" || fnBody[0].values?.length !== 1 || fnStmt.fn.vararg) return 0;
  const params = (fnStmt.fn.params || []).map(String);
  const paramMap = Object.create(null);
  params.forEach((name, i) => { if (Object.prototype.hasOwnProperty.call(paramMap, name)) paramMap[name] = -1; else paramMap[name] = i; });
  if (Object.values(paramMap).some(value => value < 0)) return 0;
  const expression = fnBody[0].values[0];
  if (!isInlineSafeExpression(expression)) return 0;

  const fnIndex = body.indexOf(fnStmt);
  if (fnIndex < 0) return 0;
  const replacements = [];
  let invalidReference = false;
  function inspect(node, parent, key, nestedScope = false) {
    if (!node || typeof node !== "object" || invalidReference) return;
    if (node !== fnStmt && ["FunctionExpr", "LocalFunction", "Function"].includes(node.type)) {
      // Avoid crossing lexical function scopes in this conservative inliner.
      if (node.type === "FunctionExpr" || node.type === "LocalFunction" || node.type === "Function") { 
        const containsName = JSON.stringify(node).includes(`"name":"${fnStmt.name}"`);
        if (containsName) invalidReference = true;
        return;
      }
    }
    if (node.type === "Call" && node.callee?.type === "Id" && node.callee.name === fnStmt.name) {
      const args = node.args || [];
      if (args.length !== params.length || !args.every(isInlineLiteral)) { invalidReference = true; return; }
      const { result } = substituteInlineParams(expression, paramMap, args);
      // Replace the complete call node, not only its callee. Arguments are
      // literals, so duplicated formal references cannot duplicate side effects.
      replacements.push({ parent, key, result });
      return;
    }
    if (node.type === "Id" && node.name === fnStmt.name) {
      invalidReference = true;
      return;
    }
    if (Array.isArray(node)) {
      for (let i = 0; i < node.length; i++) inspect(node[i], node, i, nestedScope);
    } else {
      for (const childKey of Object.keys(node)) inspect(node[childKey], node, childKey, nestedScope);
    }
  }
  // Only scan the remainder of the current lexical block. Nested function
  // scopes are deliberately excluded; if a closure captures this local, we
  // decline the optimization instead of changing name resolution.
  for (let i = fnIndex + 1; i < body.length; i++) inspect(body[i], body, i, false);
  if (invalidReference || replacements.length === 0) return 0;
  for (const replacement of replacements) replacement.parent[replacement.key] = replacement.result;
  body.splice(fnIndex, 1);
  return replacements.length;
}

function wrapStatementInBlock(node) {
  // A block around a local declaration would narrow the variable's lexical
  // lifetime and can break later reads. Keep declarations at their original
  // scope; their values/function bodies are transformed directly instead.
  if (!node || !STATEMENTS.has(node.type) || ["Do", "Local", "LocalFunction", "Function", "Goto", "Label"].includes(node.type)) return false;
  const original = {};
  for (const key of Object.keys(node)) original[key] = node[key];
  if (node.__line) hidden(original, "__line", node.__line);
  if (node.__col) hidden(original, "__col", node.__col);
  for (const key of Object.keys(node)) delete node[key];
  node.type = "Do";
  node.body = [original];
  return true;
}

function applyOne(node, directive, options = {}) {
  if (!node || typeof node !== "object") return node;
  const name = String(directive?.name || "").toLowerCase();
  const args = Array.isArray(directive?.args) ? directive.args : [];
  const strength = Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000));
  const baseSeed = (Number(options.seed ?? 1) >>> 0) || 1;
  const seed = hashText(`${name}:${directive?.line || directive?.targetLine || 0}:${args.join(",")}`, baseSeed ^ 0xB17E4A31);
  let current = node;
  let didWork = false;
  let specialStatus = null;
  const snapshot = value => {
    try { return JSON.stringify(value); } catch { return ""; }
  };
  const runScoped = (transformer, config) => {
    const before = snapshot(current);
    current = transformScoped(current, transformer, config);
    if (snapshot(current) !== before) didWork = true;
  };
  const transformStrings = () => runScoped(strings.transform, { enabled: true, rate: 1, strength, seed });
  const transformCff = () => {
    runScoped(controlFlow.transform, {
      enabled: true, rate: 1, opaqueRate: strength >= 8000 ? 1 : 0.75, strength, seed
    });
    walk(current, value => {
      if (value.type === "If") hidden(value, "__byteVeilCffTransformed", true);
    });
  };
  const transformFunctions = () => runScoped(functionTransform.transform, { enabled: true, depth: Math.max(1, Math.min(3, Number(args[0]) || 1)), seed });
  const wrap = () => { if (wrapStatementInBlock(current)) didWork = true; };

  switch (name) {
    case "byteveil-encstr":
    case "byteveil-encstr-literal":
      transformStrings();
      break;
    case "byteveil-enc-func":
      transformFunctions();
      break;
    case "byteveil-cff":
    case "byteveil-cfg":
    case "byteveil-cgi":
      wrap();
      transformCff();
      break;
    case "byteveil-pre-check":
      wrap();
      transformCff();
      transformFunctions();
      specialStatus = "backend-shield-active";
      break;
    case "byteveil-crash":
      // Preserve program behavior: this marker requests a protected region, not
      // an unconditional runtime crash that would break the user's application.
      wrap();
      transformCff();
      transformFunctions();
      break;
    case "byteveil-index-to-num":
      if (splitKeyStrings(current) > 0) didWork = true;
      break;
    case "byteveil-inline": {
      const inlined = inlineSimpleFunction(directive._binding);
      if (inlined > 0) didWork = true;
      hidden(current, "__byteVeilInlineHint", true);
      if (!inlined) specialStatus = "no-safe-inline-site";
      break;
    }
    case "byteveil-outline":
      transformFunctions();
      wrap();
      break;
    case "byteveil-line":
      wrap();
      break;
    case "byteveil-rewrite": {
      if (current && current.type === "Number" && Number.isSafeInteger(current.value) && Math.abs(current.value) <= 100000000) {
        const v = current.value;
        const k1 = 17 + ((seed >>> 3) % 89);
        const k2 = 7 + ((seed >>> 11) % 47);
        const diff = v - (k1 * k2);
        current = {
          type: "Binary",
          op: "+",
          left: { type: "Binary", op: "*", left: { type: "Number", value: k1 }, right: { type: "Number", value: k2 } },
          right: { type: "Number", value: diff }
        };
        didWork = true;
      } else {
        wrap();
        transformStrings();
        transformCff();
      }
      break;
    }
    case "byteveil-obfuscated":
      wrap();
      transformStrings();
      transformCff();
      transformFunctions();
      break;
    case "byteveil-no-virtualization":
      hidden(current, "__byteVeilNoVirtualizationHint", true);
      specialStatus = "limited-whole-chunk-vm";
      break;
    case "byteveil-super":
      // SUPER fusion stays disabled in the v4.6 graph-micro-op format because
      // a fused semantic handler would bypass the intended routing topology.
      specialStatus = "suppressed-to-preserve-vm-routing";
      break;
    case "byteveil-mfg":
    case "byteveil-vm":
    case "byteveil-virtualization":
      // The active backend already compiles the entire chunk to the custom VM
      // and derives MFG/ISA/runtime topology for this build.
      specialStatus = "backend-active";
      break;
    case "byteveil-compress":
      specialStatus = "pending-profile";
      break;
    case "byteveil-omit": {
      const array = directive._binding?.array;
      const index = Array.isArray(array) ? array.indexOf(node) : -1;
      if (index >= 0) { array.splice(index, 1); didWork = true; }
      break;
    }
    default:
      specialStatus = "no-handler";
      break;
  }
  directive.effectStatus = didWork ? "applied" : (specialStatus || "no-effective-transform");
  return current;
}

function applyPlan(ast, plan, options = {}) {
  if (!ast || typeof ast !== "object" || !plan || plan.enabled === false) return ast;
  if (!(plan.directives || []).length) { plan.applied = true; plan.effectiveDirectiveCount = 0; return ast; }
  for (const binding of plan._bindings || []) {
    const directive = binding.directive;
    // Keep the binding private: it is needed only while applying the explicit
    // directive and must not leak into JSON diagnostics/metadata.
    hidden(directive, "_binding", binding);
    const result = applyOne(binding.node, directive, options);
    if (!STATEMENTS.has(binding.node?.type) && binding.parent && binding.key != null && result !== binding.node) {
      binding.parent[binding.key] = result;
    }
  }
  const salt = directiveSalt([plan]);
  if (salt) hidden(ast, "__byteVeilDirectiveSalt", ((Number(ast.__byteVeilDirectiveSalt) || 0) ^ salt) >>> 0);
  if (plan.directives.some(d => d.name === "byteveil-compress")) {
    const version = String(options.version || "4.7.4");
    const singleLayer = version === "4.7.3" || version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"));
    if (singleLayer) {
      // v4.7.3 used a single-layer compatibility build. v4.7.5 is a binary-region VM and
      // deliberately has no source-onion stages; the directive salts the build domain instead.
      hidden(ast, "__byteVeilSingleLayerProfile", (version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")) ? "binary-region-high" : "packed-high");
      for (const directive of plan.directives) if (directive.name === "byteveil-compress") directive.effectStatus = (version === "4.7.5" || version === "4.7.6" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0")) ? "applied-as-binary-region-build-profile" : "applied-as-single-layer-build-profile";
    } else {
      hidden(ast, "__byteVeilNestedProfile", "full");
      for (const directive of plan.directives) if (directive.name === "byteveil-compress") directive.effectStatus = "applied";
    }
  }
  plan.effectiveDirectiveCount = (plan.directives || []).filter(d => d.effectStatus === "applied" || d.effectStatus === "applied-as-single-layer-build-profile" || d.effectStatus === "applied-as-binary-region-build-profile" || d.effectStatus === "backend-active" || d.effectStatus === "backend-shield-active").length;
  hidden(ast, `__${String(plan.engine || "directive").toLowerCase().replace(/[^a-z0-9]/g, "")}_applied`, true);
  return ast;
}

function annotate(ast, plan) {
  if (!ast || typeof ast !== "object" || !plan) return plan;
  const statements = collectStatementBindings(ast);
  const bindings = [];
  for (const directive of plan.directives || []) {
    const target = statements
      .filter(x => x.line > Number(directive.line || 0))
      .sort((a, b) => a.line - b.line || a.col - b.col)[0];
    if (!target) {
      directive.targetLine = null;
      directive.targetType = null;
      directive.status = "no-following-statement";
      continue;
    }
    directive.targetLine = target.line;
    directive.targetType = target.node.type;
    directive.status = "bound";
    bindings.push({ directive, node: target.node, parent: target.parent, key: target.key, array: target.array, index: target.index });
  }
  hidden(plan, "_bindings", bindings);
  return plan;
}

module.exports = {
  STATEMENTS, hidden, walk, collectStatementBindings, directiveSalt,
  transformScoped, splitKeyStrings, wrapStatementInBlock, applyOne, applyPlan, annotate, cloneTree, inlineSimpleFunction
};

"use strict";

const { registerHandler } = require("../vm/vm_handlers");

// Build a build-specific secondary register VM. Unlike the old function wheel,
// its encoded instruction stream is advanced alongside every real VM operation;
// each trace then updates the real VM guard/fabric before the next dispatch.

const SHADOW_OPS = Object.freeze([
  "PUSHN", "PUSHB", "PUSHNIL", "DUP", "SWAP", "NOT", "NEG", "NEWTABLE",
  "ADD", "SUB", "MUL", "DIV", "IDIV", "MOD", "POW", "EQ", "NE", "LT",
  "GT", "LE", "GE", "AND", "OR", "BXOR", "BNOT", "SHL", "SHR", "GETI",
  "SETI", "JMP", "JZ", "ITERPREP", "FORCMP", "POP"
]);
const REQUIRED_OPS = Object.freeze([
  "PUSHN", "DUP", "ADD", "SUB", "MUL", "EQ", "GETI", "SETI", "JMP", "JZ", "POP"
]);

function u32(n) { return Number(n) >>> 0; }
function mix32(seed, value) {
  let s = u32(seed ^ value ^ 0xB17E4A31);
  s ^= s >>> 16;
  s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13;
  s = Math.imul(s, 3266489917) >>> 0;
  s ^= s >>> 16;
  return s >>> 0;
}
function createRng(seed) {
  let s = u32(seed) || 0x6D2B79F5;
  return () => {
    s ^= s >>> 16;
    s = Math.imul(s, 2246822519) >>> 0;
    s ^= s >>> 13;
    s = Math.imul(s, 3266489917) >>> 0;
    s ^= s >>> 16;
    return s >>> 0;
  };
}
function shuffle(values, next) {
  const out = values.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = next() % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function hashName(value) {
  let h = 5381;
  for (const ch of String(value)) h = ((h * 33) ^ ch.charCodeAt(0)) >>> 0;
  return h >>> 0;
}

// Rename local identifiers in the generated shadow source, not arbitrary text.
// This intentionally operates on lexer tokens so quoted diagnostics, long-bracket
// strings, comments, property names, and table-constructor keys are preserved.
function mangleLuaLocalIdentifiers(source, seed) {
  const text = String(source);
  const tokens = [];
  const isIdStart = (c) => /[A-Za-z_]/.test(c || "");
  const isIdPart = (c) => /[A-Za-z0-9_]/.test(c || "");
  const longOpenAt = (index) => {
    const match = text.slice(index).match(/^\[(=*)\[/);
    return match ? { length: match[0].length, close: `]${match[1]}]` } : null;
  };
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (/\s/.test(c)) { i++; continue; }
    if (c === "-" && text[i + 1] === "-") {
      const long = longOpenAt(i + 2);
      if (long) {
        const closeAt = text.indexOf(long.close, i + 2 + long.length);
        i = closeAt < 0 ? text.length : closeAt + long.close.length;
      } else {
        const end = text.indexOf("\n", i + 2);
        i = end < 0 ? text.length : end + 1;
      }
      continue;
    }
    if (c === "'" || c === '"') {
      const quote = c; const start = i++;
      while (i < text.length) {
        if (text[i] === "\\") { i = Math.min(text.length, i + 2); continue; }
        if (text[i++] === quote) break;
      }
      tokens.push({ type: "literal", value: text.slice(start, i), start, end: i });
      continue;
    }
    if (c === "[") {
      const long = longOpenAt(i);
      if (long) {
        const start = i; const contentStart = i + long.length;
        const closeAt = text.indexOf(long.close, contentStart);
        i = closeAt < 0 ? text.length : closeAt + long.close.length;
        tokens.push({ type: "literal", value: text.slice(start, i), start, end: i });
        continue;
      }
    }
    if (isIdStart(c)) {
      const start = i++;
      while (i < text.length && isIdPart(text[i])) i++;
      tokens.push({ type: "id", value: text.slice(start, i), start, end: i });
      continue;
    }
    const start = i;
    // Keep multi-character Lua tokens intact where they matter for declarations.
    if (text.startsWith("...", start)) i = start + 3;
    else if (text.startsWith("::", start)) i = start + 2;
    else i++;
    tokens.push({ type: "symbol", value: text.slice(start, i), start, end: i });
  }

  const keywords = new Set(["and", "break", "continue", "do", "else", "elseif", "end", "export", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "type", "until", "while"]);
  const globals = new Set(["_G", "_VERSION", "assert", "buffer", "collectgarbage", "coroutine", "debug", "dofile", "error", "getfenv", "getmetatable", "getgenv", "ipairs", "load", "loadfile", "loadstring", "math", "next", "pairs", "pcall", "print", "rawequal", "rawget", "rawlen", "rawset", "select", "setfenv", "setmetatable", "string", "table", "tonumber", "tostring", "type", "unpack", "utf8", "warn", "xpcall", "task", "game", "workspace", "Instance", "Enum", "Color3", "Vector3", "CFrame", "UDim", "UDim2", "TweenInfo", "typeof", "require", "script", "wait", "tick", "spawn", "time", "DateTime", "Random"]);
  const bound = new Set();
  const addParamNames = (openIndex) => {
    let depth = 0;
    for (let j = openIndex; j < tokens.length; j++) {
      const token = tokens[j];
      if (token.value === "(") depth++;
      else if (token.value === ")") {
        depth--;
        if (depth === 0) return;
      } else if (depth === 1 && token.type === "id" && token.value !== "..." && !keywords.has(token.value)) {
        // Parameters are identifiers between commas. Function type comments are
        // not present in generated VM source; non-identifier symbols are ignored.
        const prev = tokens[j - 1]?.value;
        const next = tokens[j + 1]?.value;
        if (j === openIndex + 1 || prev === "," || next === "," || next === ")") bound.add(token.value);
      }
    }
  };

  for (let j = 0; j < tokens.length; j++) {
    const token = tokens[j];
    if (token.type !== "id") continue;
    if (token.value === "local") {
      let k = j + 1;
      if (tokens[k]?.value === "function") {
        if (tokens[k + 1]?.type === "id") bound.add(tokens[k + 1].value);
        continue;
      }
      if (tokens[k]?.type === "id") {
        bound.add(tokens[k].value); k++;
        while (tokens[k]?.value === "," && tokens[k + 1]?.type === "id") {
          bound.add(tokens[k + 1].value); k += 2;
        }
      }
    } else if (token.value === "function") {
      let k = j + 1;
      while (k < tokens.length && tokens[k].value !== "(" && tokens[k].value !== "end" && tokens[k].value !== ";") k++;
      if (tokens[k]?.value === "(") addParamNames(k);
    } else if (token.value === "for") {
      let k = j + 1;
      while (k < tokens.length && tokens[k].value !== "=" && tokens[k].value !== "in" && tokens[k].value !== "do") {
        if (tokens[k].type === "id") bound.add(tokens[k].value);
        k++;
      }
    }
  }

  const alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const next = createRng(u32(seed) ^ 0x54A0B1D);
  const used = new Set(tokens.filter((t) => t.type === "id").map((t) => t.value));
  const mapping = new Map();
  for (const original of bound) {
    if (keywords.has(original) || globals.has(original)) continue;
    let candidate;
    for (let attempts = 0; attempts < 32; attempts++) {
      let value = "_";
      for (let n = 0; n < 5; n++) value += alphabet[next() % alphabet.length];
      if (!used.has(value)) { candidate = value; break; }
    }
    // A pathological/cyclic PRNG stream must never hang a build. The fallback
    // is still a legal, collision-checked local identifier and depends on the
    // original identifier, not on a global fixed alias table.
    if (!candidate) {
      const base = `_b${hashName(original).toString(36)}`;
      let suffix = 0;
      candidate = base;
      while (used.has(candidate)) candidate = `${base}_${(++suffix).toString(36)}`;
    }
    used.add(candidate);
    mapping.set(original, candidate);
  }
  if (!mapping.size) return text;

  const edits = [];
  for (let index = 0; index < tokens.length; index++) {
    const token = tokens[index];
    if (token.type !== "id" || !mapping.has(token.value)) continue;
    const prev = tokens[index - 1]?.value;
    const nextValue = tokens[index + 1]?.value;
    // A bare name after dot/colon is a field/method, not a variable reference.
    if (prev === "." || prev === ":" || prev === "::") continue;
    // Preserve named keys in table constructors: { name = value, ... }.
    if (nextValue === "=" && (prev === "{" || prev === ",")) continue;
    edits.push({ start: token.start, end: token.end, value: mapping.get(token.value) });
  }
  // Edits are collected in source order. Repeated whole-string slicing here
  // made large generated payloads quadratic; assemble untouched spans once.
  const chunks = [];
  let cursor = 0;
  for (const edit of edits) {
    if (edit.start < cursor) throw new Error("ByteVeil shadow mangler: overlapping token edits");
    chunks.push(text.slice(cursor, edit.start), edit.value);
    cursor = edit.end;
  }
  chunks.push(text.slice(cursor));
  const output = chunks.join("");
  return output;
}

function buildShadowStrings(seed, count = 16) {
  const alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const next = createRng(u32(seed) ^ 0x54A0C0DE);
  const result = [];
  const used = new Set();
  const randomAttempts = Math.max(64, count * 32);
  let attempts = 0;
  let fallbackIndex = 0;
  while (result.length < count) {
    let value = "";
    if (attempts++ < randomAttempts) {
      for (let i = 0, length = 9 + (next() % 5); i < length; i++) value += alphabet[next() % alphabet.length];
    } else {
      // Bound randomized retries and retain build diversity even if the PRNG
      // ever repeats a short sequence or collisions exhaust its candidate set.
      const suffix = (fallbackIndex++).toString(36);
      value = `x${mix32(u32(seed), result.length ^ 0x54A0C0DE).toString(36)}_${suffix}`;
    }
    if (!used.has(value)) { used.add(value); result.push(value); }
  }
  return result;
}
function mapTraceOp(name, available) {
  const source = String(name || "").toUpperCase();
  const exact = available.find((op) => op === source);
  if (exact) return exact;
  const candidates = (pattern) => available.filter((op) => pattern.test(op));
  let choices = [];
  if (/JMP|JUMP|BRANCH/.test(source)) choices = candidates(/^(JMP|JZ)$/);
  else if (/FORLOOP|LOOP|TEST|SKIP/.test(source)) choices = candidates(/^(JZ|FORCMP|ITERPREP)$/);
  else if (/EQ|NE|LT|LE|GT|GE|COMPARE/.test(source)) choices = candidates(/^(EQ|NE|LT|LE|GT|GE)$/);
  else if (/ADD|CONCAT/.test(source)) choices = candidates(/^(ADD|SUB)$/);
  else if (/SUB/.test(source)) choices = candidates(/^(SUB|ADD)$/);
  else if (/MUL|DIV|MOD|POW/.test(source)) choices = candidates(/^(MUL|DIV|IDIV|MOD|POW)$/);
  else if (/SET|STORE|PUT/.test(source)) choices = candidates(/^(SETI|SWAP)$/);
  else if (/GET|LOAD|MOVE|UPVAL|GLOBAL|CONST|SELF|VARARG/.test(source)) choices = candidates(/^(GETI|DUP|PUSHN|PUSHB)$/);
  else if (/TABLE|NEWTABLE/.test(source)) choices = candidates(/^(NEWTABLE|GETI|SETI)$/);
  else if (/CALL|RETURN|CLOSE|POP/.test(source)) choices = candidates(/^(POP|DUP|SWAP)$/);
  if (choices.length) return choices[hashName(source) % choices.length];
  return available[hashName(source) % Math.max(1, available.length)] || available[0];
}

function buildLiveShadowVM({ seed, depth = 24, opNames = [], encode = {}, programOps = [], names, N, S, strength = 1000 } = {}) {
  if (!names || !N || !S) throw new TypeError("live shadow VM requires generated names and VM slots");
  const available = SHADOW_OPS.filter((op) => opNames.includes(op) && Number.isInteger(encode[op]));
  const required = REQUIRED_OPS.filter((op) => available.includes(op));
  if (required.length < 8) throw new Error("ByteVeil shadow VM: insufficient shared ISA operations");

  // `seed` is the same reconstructed root seed used by the binary-region graph.
  // The payload fields are masked with it and decoded only inside the live stepper.
  const maskSeed = u32(seed);
  const next = createRng(seed ^ 0x4765A13D);
  const count = Math.max(24, Math.min(96, Number(depth) || 24));
  const optional = shuffle(available.filter((op) => !required.includes(op)), next);
  const selected = required.concat(optional.slice(0, Math.max(0, Math.min(available.length - required.length, count - required.length))));
  const schedule = shuffle(selected, next);
  const availableSet = new Set(available);
  const trace = [];
  for (const item of Array.isArray(programOps) ? programOps : []) {
    const name = item && typeof item === "object" ? item.name : item;
    const op = mapTraceOp(name, available);
    if (availableSet.has(op)) {
      const operands = item && typeof item === "object" && Array.isArray(item.operands)
        ? item.operands.map((value) => Number(value)).filter(Number.isFinite)
        : [];
      trace.push({ op, name: String(name || ""), operands });
    }
  }
  const logicalProgram = [];
  for (let i = 0; i < count; i++) {
    // Three of every four rows use the real opcode trace. Their register/immediate
    // fields are also derived from the source instruction's operands, then masked;
    // only one row in four follows a build-specific schedule.
    const traceEntry = trace.length && i % 4 !== 3
      ? trace[(i + Math.floor(i / 4)) % trace.length]
      : null;
    const op = traceEntry ? traceEntry.op : schedule[next() % schedule.length];
    const traceName = traceEntry ? traceEntry.name : op;
    const rawOperands = traceEntry ? traceEntry.operands : [];
    const traceSalt = traceEntry
      ? rawOperands.reduce((acc, value, index) => mix32(acc, u32(value) ^ u32(index * 0x45D9F3B)), hashName(`${traceName}:${i}`))
      : hashName(`${traceName}:${i}`);
    const a = 1 + (mix32(maskSeed, traceSalt ^ 0x76001001) % 8);
    const b = 1 + (mix32(maskSeed, traceSalt ^ 0x76001002) % 8);
    const c = 1 + (mix32(maskSeed, traceSalt ^ 0x76001003) % 8);
    const operandFold = rawOperands.reduce((acc, value, index) => mix32(acc, u32(value) + index * 0x27D4EB2F), traceSalt);
    const imm = mix32(maskSeed, operandFold ^ 0x76001004) % 65521;
    const target = (mix32(maskSeed, operandFold ^ 0x76001005) % count) + 1;
    logicalProgram.push({ op, fields: [Number(encode[op]), a, b, c, imm, target] });
  }

  // Logical-to-physical row order is seed-polymorphic and independent from opcode order.
  const logicalToPhysical = shuffle(Array.from({ length: count }, (_, i) => i + 1), next);
  const physicalRows = new Array(count);
  for (let logical = 1; logical <= count; logical++) {
    const fields = logicalProgram[logical - 1].fields;
    const physical = logicalToPhysical[logical - 1];
    physicalRows[physical - 1] = fields.map((value, field0) => {
      const field = field0 + 1;
      const maskInput = u32(Math.imul(logical, 0x1F123BB5) ^ Math.imul(field, 0x45D9F3B) ^ 0x76000001);
      return u32(value ^ mix32(maskSeed, maskInput));
    });
  }
  const encodedOrder = logicalToPhysical.map((physical, index) => {
    const logical = index + 1;
    const maskInput = u32(Math.imul(logical, 0x27D4EB2F) ^ 0x76000002);
    return u32(physical ^ mix32(maskSeed, maskInput));
  });
  const flatCode = physicalRows.flat();

  const codeName = names.code;
  const orderName = names.order;
  const handlersName = names.handlers;
  const liveMapName = names.liveMap;
  const initName = names.init;
  const stepName = names.step;
  const liveOpcodeMap = opNames.map((name) => Number(encode[mapTraceOp(name, available)]));
  const handlerSource = [];
  const add = (name, body) => {
    if (!Number.isInteger(encode[name])) return;
    handlerSource.push(`[${Number(encode[name])}]=function(P,A,B,C,V,T,E)local R=P.r;local X=R[B]or 0;local Y=R[C]or 0;local function n(Z)local K=type(Z);if K=="number"then return Z elseif K=="boolean"then return Z and 1 or 0 elseif K=="string"then return #Z end;return 0 end;do ${body} end;return nil end`);
  };

  add("PUSHN", "R[A]=V%65521");
  add("PUSHB", "R[A]=(V%2==0)and 0 or 1");
  add("PUSHNIL", "R[A]=false");
  add("DUP", "R[A]=R[B]or 0");
  add("SWAP", "R[A],R[B]=R[B],R[A]");
  add("NOT", "R[A]=(not (R[B]and R[B]~=false and R[B]~=0))and 1 or 0");
  add("NEG", "R[A]=(-n(X))%4294967296");
  add("NEWTABLE", "R[A]={}");
  add("ADD", "R[A]=(n(X)+n(Y)+V)%4294967296");
  add("SUB", "R[A]=(n(X)-n(Y)+4294967296)%4294967296");
  add("MUL", `R[A]=${N.mul}(n(X),n(Y))`);
  add("DIV", "R[A]=n(X)/(math.abs(n(Y))+1)");
  add("IDIV", "R[A]=math.floor(n(X)/(math.abs(n(Y))+1))");
  add("MOD", "R[A]=n(X)%(math.abs(n(Y))+1)");
  add("POW", "R[A]=((math.abs(n(X))%7)+1)^((math.abs(n(Y))%4))");
  add("EQ", "P.f=(n(X)==n(Y))");
  add("NE", "P.f=(n(X)~=n(Y))");
  add("LT", "P.f=(n(X)<n(Y))");
  add("GT", "P.f=(n(X)>n(Y))");
  add("LE", "P.f=(n(X)<=n(Y))");
  add("GE", "P.f=(n(X)>=n(Y))");
  add("AND", "R[A]=((n(X)~=0 and n(Y)~=0)and 1 or 0)");
  add("OR", "R[A]=((n(X)~=0 or n(Y)~=0)and 1 or 0)");
  add("BXOR", `R[A]=${N.xor}(n(X),n(Y))`);
  add("BNOT", "R[A]=(4294967295-(n(X)%4294967296))");
  add("SHL", "R[A]=(n(X)*2^(n(Y)%16))%4294967296");
  add("SHR", "R[A]=math.floor(n(X)/2^(n(Y)%16))");
  add("GETI", "local W=R[B];if type(W)==\"table\"then R[A]=W[(math.floor(n(Y))%8)+1]or 0 else R[A]=0 end");
  add("SETI", "if type(R[A])~=\"table\"then R[A]={}end;R[A][(math.floor(n(X))%8)+1]=R[C]or 0");
  add("JMP", "return T");
  add("JZ", "if not P.f then return T end");
  add("ITERPREP", "P.f=((n(X)+n(Y)+V)%2)==0");
  add("FORCMP", "P.f=(n(X)<=n(Y))");
  add("POP", "R[A]=0");

  const encodedStepsPerRealInstruction = Number(strength) >= 8000 ? 2 : 1;
  // One dynamic opcode-coupled handler always runs; high-strength builds add two
  // encoded stream steps and lower-strength builds add one.
  const stepsPerRealInstruction = encodedStepsPerRealInstruction + 1;
  const initSeed = mix32(maskSeed, 0x76000003);
  const initialRegs = Array.from({ length: 8 }, (_, i) => mix32(initSeed, i + 1) % 65521);
  const initialAcc = mix32(initSeed, 0x76000004);
  const codeLiteral = flatCode.join(",");
  const orderLiteral = encodedOrder.join(",");
  // The legacy shadow lane also gets a seed-specific handler-table order.
  // Opcode IDs are explicit keys, so table order does not affect dispatch.
  const renderedHandlerSource = shuffle(handlerSource.slice(), createRng(maskSeed ^ 0x7600A11D));
  const source = [
    `local ${codeName}={${codeLiteral}}`,
    `local ${orderName}={${orderLiteral}}`,
    `local ${handlersName}={${renderedHandlerSource.join(",")}}`,
    `local ${liveMapName}={${liveOpcodeMap.join(",")}}`,
    `${initName}=function()return{pc=1,r={${initialRegs.join(",")}},f=false,acc=${initialAcc},tick=0}end`,
    `${stepName}=function(P,Q,I,R,L,K)local function SN(Z)local T=type(Z);if T=="number"then return Z elseif T=="boolean"then return Z and 1 or 0 elseif T=="string"then return #Z end;return 0 end;local EV=${N.mix}(Q[${S.guard}]or 0,${N.xor}(I[1]or 0,${N.xor}(R.id or 0,${N.xor}(L or 0,Q[${S.pc}]or 0))));P.r[1]=${N.mix}(SN(P.r[1]or 0),EV);P.acc=${N.mix}(P.acc or 0,${N.xor}(EV,Q[${S.fabric}]or 0));local LIVEOP=${liveMapName}[(SN(L)+1)];if not LIVEOP then error("ByteVeil v4.7.6: live opcode correlation",0)end;local LA=(math.abs(SN(I[2]or 0))%8)+1;local LB=(math.abs(SN(I[3]or 0))%8)+1;local LC=(math.abs(SN(I[4]or 0))%8)+1;local LV=(math.abs(SN(I[5]or I[4]or 0))+EV)%65521;local LT=(math.abs(SN(I[6]or I[5]or 0))+EV)%${count}+1;local LH=${handlersName}[LIVEOP];if not LH then error("ByteVeil v4.7.6: live handler missing",0)end;local LJ=LH(P,LA,LB,LC,LV,LT,EV);if LJ then P.pc=((LJ-1)%${count})+1 else P.pc=((P.pc or 1)%${count})+1 end;P.tick=(P.tick or 0)+1;P.acc=${N.mix}(P.acc or 0,${N.xor}(SN(P.r[(P.pc%8)+1]or 0),P.tick));for Z=1,${encodedStepsPerRealInstruction} do local PC=P.pc or 1;local OM=${N.mix}(K or 0,${N.xor}((PC*${0x27D4EB2F})%4294967296,0x76000002));local PH=${N.xor}(${orderName}[PC]or 0,OM);local B0=(PH-1)*6;local function RD(J)local FM=${N.mix}(K or 0,${N.xor}((PC*${0x1F123BB5})%4294967296,${N.xor}((J*${0x45D9F3B})%4294967296,0x76000001)));return ${N.xor}(${codeName}[B0+J]or 0,FM)end;local OP=RD(1);local A=(RD(2)%8)+1;local B=(RD(3)%8)+1;local C=(RD(4)%8)+1;local V=RD(5)%65521;local T=(RD(6)-1)%${count}+1;local H=${handlersName}[OP];if H then local J=H(P,A,B,C,V,T,EV);if J then P.pc=((J-1)%${count})+1 else P.pc=(PC%${count})+1 end else P.pc=(PC%${count})+1;P.acc=${N.mix}(P.acc or 0,${N.xor}(OP,EV))end;P.tick=(P.tick or 0)+1;P.acc=${N.mix}(P.acc or 0,${N.xor}(SN(P.r[(P.pc%8)+1]or 0),P.tick))end;local O=SN(P.r[(EV%8)+1]or 0);return ${N.mix}(P.acc or 0,${N.xor}(O,EV))end`
  ].join(";\n");

  return {
    source,
    instructionCount: count,
    handlerCount: handlerSource.length,
    stepsPerRealInstruction,
    traceOpcodeCount: trace.length,
    operandTraceDerived: trace.length > 0 && trace.some((entry) => entry.operands.length > 0),
    liveOpcodeCoupled: true,
    traceInterleaveRatio: trace.length ? "runtime-opcode-coupled-plus-3-of-4-trace-and-operand-derived" : "runtime-opcode-coupled-plus-build-random-fallback",
    dispatchStyle: trace.length ? "runtime-opcode-coupled-source-trace-and-operand-correlated-encoded-physical-opcode-table" : "runtime-opcode-coupled-encoded-physical-opcode-table",
    fingerprint: mix32(maskSeed, count * 97 + handlerSource.length * 31 + stepsPerRealInstruction).toString(16).padStart(8, "0"),
    maskSeed
  };
}


// v4.7.8: operation-preserving shadow machine. The prior shadow VM used a
// regex-based approximation (for example mapping unrelated opcode names to
// ADD/SUB/POP), then filled operands with hashes. That made the secondary lane
// structurally distinct from the real ISA and easy to classify as synthetic.
// This builder gives every opcode in the active build a unique randomized
// shadow ID, dispatches the current runtime opcode through that exact map, and
// uses the same per-build handler family for masked decoy rows.
function buildSemanticShadowVM({ seed, depth = 24, opNames = [], names, N, S, strength = 1000, defs = {}, mode = "register", helpers = {}, version = "4.7.8" } = {}) {
  if (!names || !N || !S) throw new TypeError("semantic shadow VM requires generated names and VM slots");
  const runtimeVersion = String(version || "4.7.8");
  const sourceOps = [...new Set((Array.isArray(opNames) ? opNames : []).map((x) => String(x || "")).filter(Boolean))];
  if (sourceOps.length < 8) throw new Error("ByteVeil shadow VM: insufficient active ISA operations");

  const maskSeed = u32(seed);
  const hardenedShadow = runtimeVersion === "5.4.0" || (runtimeVersion === "5.5.0" || runtimeVersion === "5.6.0" || runtimeVersion === "5.7.0" || runtimeVersion === "5.8.0" || runtimeVersion === "5.9.0");
  const shadowStrings = buildShadowStrings(maskSeed, 24);
  const shadowStateNames = hardenedShadow ? {
    pc: shadowStrings[0], r: shadowStrings[1], m: shadowStrings[2], f: shadowStrings[3],
    acc: shadowStrings[4], tick: shadowStrings[5], calls: shadowStrings[6], ret: shadowStrings[7]
  } : { pc: "pc", r: "r", m: "m", f: "f", acc: "acc", tick: "tick", calls: "calls", ret: "ret" };
  const pState = Object.fromEntries(Object.entries(shadowStateNames).map(([key, value]) => [key, hardenedShadow ? `P[${JSON.stringify(value)}]` : `P.${value}`]));
  const initSeed = mix32(maskSeed, 0x47800003);
  const initialAuth = mix32(initSeed, 0x47800005);
  const next = createRng(seed ^ 0x4785A11D);
  const count = Math.max(24, Math.min(96, Number(depth) || 24));
  const shuffledIds = shuffle(Array.from({ length: sourceOps.length }, (_, i) => i + 1), next);
  const idByName = Object.create(null);
  sourceOps.forEach((op, index) => { idByName[op] = shuffledIds[index]; });
  const runtimeOpcodeMap = sourceOps.map((op) => idByName[op]);
  const codeName = names.code, orderName = names.order, handlersName = names.handlers;
  const handlerCoreName = names.handlerCore || "_shadowCore";
  const liveMapName = names.liveMap, initName = names.init, stepName = names.step, proofName = names.proof, authName = names.auth;
  const semanticHandlersName = names.semanticHandlers, semanticProbeName = names.semanticProbe;
  const proofSemanticProbeName = names.proofSemanticProbe;
  const semanticPlansName = names.semanticPlans, vmStateName = names.vmState, proofVmStateName = names.proofVmState;
  const semanticTraceKey = JSON.stringify(names.semanticTrace), semanticDigestKey = JSON.stringify(names.semanticDigest), vmStateKey = JSON.stringify(vmStateName), proofVmStateKey = JSON.stringify(proofVmStateName);
  const sandboxNoopName = names.sandboxNoop, sandboxConstName = names.sandboxConst;
  const sandboxResolveName = names.sandboxResolve, sandboxWriteName = names.sandboxWrite;
  const sandboxRunName = names.sandboxRun, sandboxSuperName = names.sandboxSuper;
  if (!proofName || !authName || !semanticHandlersName || !semanticProbeName || !proofSemanticProbeName || !semanticPlansName || !vmStateName || !proofVmStateName || !sandboxNoopName || !sandboxConstName || !sandboxResolveName || !sandboxWriteName || !sandboxRunName || !sandboxSuperName || !names.semanticTrace || !names.semanticDigest) {
    throw new TypeError("semantic shadow VM requires isolated semantic-handler sandbox names");
  }
  if (!helpers.state || !helpers.const || !helpers.resolveGlobal || !helpers.writeGlobal || !helpers.run || !helpers.superFns || !S.consts || !S.env || !S.pc || !S.halt || !S.ret || !S.varargs || !S.iter || !S.parent || !S.locals || !S.localSet || (mode === "stack" ? (!S.sp || !S.stack) : !S.reg)) {
    throw new TypeError("semantic shadow VM requires complete VM state/helper bindings");
  }

  const authKey = JSON.stringify(authName);
  const authValueExpr = (op, inst, ev, pc) => {
    const values = [op, `NUM(${inst}[2]or 0)`, `NUM(${inst}[3]or 0)`, `NUM(${inst}[4]or 0)`, `NUM(${inst}[5]or ${inst}[4]or 0)`, `NUM(${inst}[6]or ${inst}[5]or 0)`, ev, pc];
    return values.slice(0, -1).reduceRight((acc, value) => `${N.xor}(${value},${acc})`, values[values.length - 1]);
  };
  const handlerAuthValue = authValueExpr("O", "I", "E", "PC");
  const actionRng = createRng(maskSeed ^ 0x58A17C0D);
  const usedActHex = new Set();
  const actionIds = Array.from({ length: 11 }, () => {
    let h = 0x1000 + (actionRng() % 0xEFFF);
    while (usedActHex.has(h)) h = 0x1000 + ((h - 0x1000 + 0x13B) % 0xEFFF);
    usedActHex.add(h);
    return `0x${h.toString(16)}`;
  });
  const classifyShadowOp = (name) => {
    const upper = String(name || "").toUpperCase();
    if (/^(PUSHK|PUSHN|PUSHB|PUSHNIL|LOADK|LOADN|LOADB|LOADNIL|LOADI|GETG|GETL|VARARG|VARARGS|MAKEFUNC)$/.test(upper)) return 0;
    if (/^(MOVE|DUP|SWAP|COPY|SETL|SETG|SETUPVAL)$/.test(upper)) return 1;
    if (/^(ADD|SUB|MUL|DIV|IDIV|MOD|POW|BAND|BOR|BXOR|SHL|SHR|BNOT|NEG|NOT|LEN|CONCAT|AND|OR)$/.test(upper)) return 2;
    if (/^(EQ|NE|LT|LE|GT|GE|TEST|TESTSET|ISNIL|ISFALSE)$/.test(upper)) return 3;
    if (/^(GETI|GETFIELD|GETTABLE|GETTABUP|SELF|GETUPVAL|GETGLOBAL)$/.test(upper)) return 4;
    if (/^(SETI|SETFIELD|SETTABLE|SETTABUP|SETUPVAL|SETGLOBAL)$/.test(upper)) return 5;
    if (/^(NEWTABLE|NEWTAB|TABLE|SETLIST|LIST|APPEND)$/.test(upper)) return 6;
    if (/^(CALL|CALLG|CALLGM|CALLGV|CALLM|CALLV|CALLP|TAILCALL|INVOKE|FASTCALL|FASTCALL1|FASTCALL2|FASTCALL2K)$/.test(upper)) return 7;
    if (/^(RETURN|RETURNV|HALT|BREAK|CLOSE|CLOSEUPVALS|CLOSEUPVAL|THROW)$/.test(upper)) return 8;
    if (/^(JMP|JUMP|JZ|JNZ|FORCMP|FORLOOP|ITERPREP|ITERLOOP|LOOP|BRANCH|SKIP)$/.test(upper)) return 9;
    return 10;
  };
  const handlerSource = [];
  const handlerOrder = shuffle(sourceOps.slice(), next);
  for (const name of handlerOrder) {
    const opId = idByName[name];
    const actId = actionIds[classifyShadowOp(name)];
    handlerSource.push(`[${opId}]=${actId}`);
  }
  const coreEffects = [
    { act: actionIds[0], body: `${pState.r}[A]=${N.mix}(${pState.acc} or 0,${N.xor}(O,${N.xor}(W,${N.xor}(B,C))))` },
    { act: actionIds[1], body: `${pState.r}[A]=${N.mix}(NUM(X),${N.xor}(O,${N.xor}(W,NUM(Y))))` },
    { act: actionIds[2], body: `${pState.r}[A]=${N.mix}(${N.mix}(NUM(X),${N.xor}(NUM(Y),O)),${N.xor}(W,E))` },
    { act: actionIds[3], body: `${pState.f}=(${N.mix}(NUM(X),${N.xor}(NUM(Y),${N.xor}(O,E)))%2)==0;${pState.r}[A]=${pState.f} and 1 or 0` },
    { act: actionIds[4], body: `${pState.r}[A]=${N.mix}(${pState.m}[${N.mix}(NUM(X),${N.xor}(NUM(Y),O))]or 0,${N.xor}(W,E))` },
    { act: actionIds[5], body: `${pState.m}[${N.mix}(A,${N.xor}(W,O))]=${N.mix}(NUM(X),${N.xor}(NUM(Y),E))` },
    { act: actionIds[6], body: `${pState.r}[A]=${N.mix}(${pState.acc},${N.xor}(O,${N.xor}(A,${N.xor}(B,C))))` },
    { act: actionIds[7], body: `${pState.calls}=${N.mix}(${pState.calls} or 0,${N.xor}(O,${N.xor}(W,${N.xor}(B,C))));${pState.r}[A]=${pState.calls}` },
    { act: actionIds[8], body: `${pState.ret}=${N.mix}(${pState.acc},${N.xor}(O,${N.xor}(W,NUM(X))));${pState.f}=true` },
    { act: actionIds[9], body: `${pState.pc}=PC;${pState.f}=(${N.mix}(E,${N.xor}(PC,${N.xor}(O,W)))%2)==0` },
    { act: actionIds[10], body: `${pState.r}[A]=${N.mix}(${pState.acc},${N.xor}(O,${N.xor}(W,${N.xor}(NUM(X),${N.xor}(NUM(Y),PC)))))` }
  ];
  const shuffledCoreEffects = shuffle(coreEffects, createRng(maskSeed ^ 0x58C0DE11));
  const coreBranches = shuffledCoreEffects
    .map((entry, idx) => `${idx === 0 ? "if" : "elseif"} ACT==${entry.act} then ${entry.body}`)
    .join(" ") + " end";
  const style = next() % 4;
  const digestWrite = `P[${semanticDigestKey}]=${N.mix}(P[${semanticDigestKey}]or ${initialAuth},${N.xor}(SIG,${N.xor}(O,PC)))`;
  const traceWrite = `local ST=P[${semanticTraceKey}];ST[#ST+1]={O,PC,E,SIG,NUM(I[2]or 0),NUM(I[3]or 0),NUM(I[4]or 0),NUM(I[5]or I[4]or 0),NUM(I[6]or I[5]or 0)}`;
  const authWrite = `P[${authKey}]=${N.mix}(P[${authKey}]or ${initialAuth},${N.mix}(${handlerAuthValue},SIG))`;
  const bookkeep = style === 0
    ? `${digestWrite};${traceWrite};${authWrite}`
    : style === 1
      ? `${traceWrite};${authWrite};${digestWrite}`
      : style === 2
        ? `${authWrite};${digestWrite};${traceWrite}`
        : `do local D=${N.mix}(P[${semanticDigestKey}]or ${initialAuth},${N.xor}(SIG,${N.xor}(O,PC)));P[${semanticDigestKey}]=D end;do local A0=${N.mix}(P[${authKey}]or ${initialAuth},${N.mix}(${handlerAuthValue},SIG));P[${authKey}]=A0 end;${traceWrite}`;
  const handlerCoreSource = `local ${handlerCoreName}=function(P,O,I,Q,R,L,K,E)local ACT=${handlersName}[O];if not ACT then return nil end;local function NUM(Z)local T=type(Z);if T=="number"then return Z elseif T=="boolean"then return Z and 1 or 0 elseif T=="string"then return #Z end;return 0 end;local A=(math.abs(NUM(I[2]or 0))%16)+1;local B=(math.abs(NUM(I[3]or 0))%16)+1;local C=(math.abs(NUM(I[4]or 0))%16)+1;local W=NUM(I[5]or I[4]or 0);local X=${pState.r}[B]or 0;local Y=${pState.r}[C]or 0;local PC=NUM(Q[${S.pc}]or 0);local SIG=${names.semanticProbe}(P,O,E,PC,K);${bookkeep};${pState.acc}=${N.mix}(${pState.acc} or 0,${N.xor}(E,${N.xor}(SIG,${N.xor}(O,${N.xor}(PC,${N.xor}(NUM(I[2]or 0),NUM(I[3]or 0)))))));${coreBranches};${pState.tick}=(${pState.tick} or 0)+1;return ${pState.acc} end`;

  // The secondary lane also carries the active build's genuine semantic handler
  // bodies. Each body runs against a separately initialized scratch VM state and
  // a sandbox environment. Helper references that could reach the user's real
  // environment or recursively invoke the real VM are redirected to sandbox helpers.
  const escapeRegex = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const replaceIdentifier = (body, from, to) => {
    if (!from || !to) return body;
    return String(body).replace(new RegExp(`\\b${escapeRegex(from)}\\b`, "g"), to);
  };
  const semanticHandlerEntries = [];
  const missingSemanticHandlers = [];
  for (const name of shuffle(sourceOps.slice(), next)) {
    const opId = idByName[name];
    let body = defs && typeof defs[name] === "string" ? defs[name] : "";
    if (!body) {
      // Do not manufacture a runtime-only stub for an active ISA operation.
      // The missing-handler list is checked below and the build fails closed.
      missingSemanticHandlers.push(name);
      continue;
    }
    body = replaceIdentifier(body, helpers.const, sandboxConstName);
    body = replaceIdentifier(body, helpers.resolveGlobal, sandboxResolveName);
    body = replaceIdentifier(body, helpers.writeGlobal, sandboxWriteName);
    body = replaceIdentifier(body, helpers.run, sandboxRunName);
    body = replaceIdentifier(body, helpers.superFns, sandboxSuperName);
    const renderedHandler = registerHandler("", body, { seed: maskSeed ^ opId, identity: `semantic-shadow-${name}` });
    semanticHandlerEntries.push(`[${opId}]=${renderedHandler}`);
  }
  if (missingSemanticHandlers.length) {
    throw new Error(`ByteVeil v${runtimeVersion}: semantic shadow handlers missing for active ISA: ${missingSemanticHandlers.join(", ")}`);
  }
  // Keep exact opcode-to-handler bindings while varying emitted table order
  // per build. This complements randomized IDs, state keys, and handler seeds.
  const renderedSemanticHandlerEntries = shuffle(semanticHandlerEntries.slice(), createRng(maskSeed ^ 0x58A7E002));

  const semanticPlanCode = (name) => {
    const op = String(name).toUpperCase();
    if (/^(ADD|SUB|MUL|DIV|IDIV|MOD|POW|BAND|BOR|BXOR|SHL|SHR|NEG|BNOT|EQ|NE|LT|LE|GT|GE|NOT|AND|OR|TEST|TESTSET|FORCMP)$/.test(op)) return 1;
    if (/^(CONCAT)$/.test(op)) return 2;
    if (/^(LEN)$/.test(op)) return 3;
    if (/^(GETI|GETFIELD|GETTABLE|GETTABUP|SELF)$/.test(op)) return 4;
    if (/^(SETI|SETFIELD|SETTABLE|SETTABUP|SETGLOBAL)$/.test(op)) return 5;
    if (/^(CALL|CALLG|CALLGM|CALLGV|CALLM|CALLV|CALLP|TAILCALL|INVOKE|FASTCALL|FASTCALL1|FASTCALL2|FASTCALL2K)$/.test(op)) return 6;
    if (/^(RETURN|RETURNV|HALT|BREAK|CLOSE|CLOSEUPVALS|CLOSEUPVAL|THROW)$/.test(op)) return 7;
    if (/^(JMP|JUMP|JZ|JNZ|FORLOOP|ITERPREP|ITERLOOP|LOOP|BRANCH|SKIP)$/.test(op)) return 8;
    if (/^(PUSHK|PUSHN|PUSHB|PUSHNIL|LOADK|LOADN|LOADB|LOADNIL|LOADI|GETG|SETG|GETL|SETL|GETUPVAL|SETUPVAL|GETGLOBAL|MAKEFUNC|VARARG|VARARGS)$/.test(op)) return 9;
    if (/^(NEWTABLE|NEWTAB|TABLE|SETLIST|LIST|APPEND)$/.test(op)) return 10;
    return 0;
  };
  const semanticPlanEntries = shuffle(sourceOps.slice(), next).map((name) => `[${idByName[name]}]=${semanticPlanCode(name)}`);

  // These are decoy instructions sampled from the build's real ISA rather
  // than a fixed smaller toy instruction set. The original source's static
  // opcode trace is deliberately not embedded in this secondary payload.
  const logicalProgram = [];
  for (let i = 0; i < count; i++) {
    const name = sourceOps[next() % sourceOps.length];
    logicalProgram.push({ op: idByName[name], fields: [idByName[name], 1 + next() % 16, 1 + next() % 16, 1 + next() % 16, next() % 65521, 1 + next() % count] });
  }
  const logicalToPhysical = shuffle(Array.from({ length: count }, (_, i) => i + 1), next);
  const physicalRows = new Array(count);
  for (let logical = 1; logical <= count; logical++) {
    const physical = logicalToPhysical[logical - 1];
    physicalRows[physical - 1] = logicalProgram[logical - 1].fields.map((value, field0) => {
      const field = field0 + 1;
      const input = u32(Math.imul(logical, 0x1F123BB5) ^ Math.imul(field, 0x45D9F3B) ^ 0x47800001);
      return u32(value ^ mix32(maskSeed, input));
    });
  }
  const encodedOrder = logicalToPhysical.map((physical, index) => {
    const logical = index + 1;
    return u32(physical ^ mix32(maskSeed, u32(Math.imul(logical, 0x27D4EB2F) ^ 0x47800002)));
  });
  const flatCode = physicalRows.flat();
  const steps = Number(strength) >= 8000 ? 2 : 1;
  const initialRegs = Array.from({ length: 16 }, (_, i) => mix32(initSeed, i + 1) % 65521);
  const initialAcc = mix32(initSeed, 0x47800004);
  const stateInitEntries = shuffle([
    `[${JSON.stringify(shadowStateNames.pc)}]=1`,
    `[${JSON.stringify(shadowStateNames.r)}]={${initialRegs.join(",")}}`,
    `[${JSON.stringify(shadowStateNames.m)}]={}`,
    `[${JSON.stringify(shadowStateNames.f)}]=false`,
    `[${JSON.stringify(shadowStateNames.acc)}]=${initialAcc}`,
    `[${JSON.stringify(shadowStateNames.tick)}]=0`,
    `[${JSON.stringify(shadowStateNames.calls)}]=0`,
    `[${JSON.stringify(shadowStateNames.ret)}]=0`,
    `[${vmStateKey}]=VM`,
    `[${proofVmStateKey}]=PVM`,
    `[${semanticTraceKey}]={}`,
    `[${semanticDigestKey}]=${initialAuth}`,
    `[${authKey}]=${initialAuth}`
  ], next);
  const decoyValues = hardenedShadow ? shadowStrings.slice(8) : Array.from({ length: 16 }, (_, i) => `bv_shadow_${(i + 1) * 4}`);
  const constValues = hardenedShadow
    ? Array.from({ length: 64 }, (_, i) => ((i + 1) % 4 === 0 ? JSON.stringify(decoyValues[Math.floor(i / 4) % decoyValues.length]) : String((i + 1) * 3 + 1))).join(",")
    : Array.from({ length: 64 }, (_, i) => ((i + 1) % 4 === 0 ? JSON.stringify(`bv_shadow_${i + 1}`) : String((i + 1) * 3 + 1))).join(",");
  const envSlot = JSON.stringify(S.env), constSlot = JSON.stringify(S.consts);
  const stackReset = mode === "stack" ? `local T={};for J=1,16 do T[J]=(J%7)+1 end;T[7]=5;T[8]=2;local PLAN=${semanticPlansName}[O]or 0;if PLAN==1 then T[7]=7;T[8]=2 elseif PLAN==2 then T[7]=${JSON.stringify(decoyValues[0])};T[8]=${JSON.stringify(decoyValues[1])} elseif PLAN==3 then T[8]=${JSON.stringify(decoyValues[2])} elseif PLAN==4 then T[7]={k=${JSON.stringify(decoyValues[3])}};T[8]=${JSON.stringify(decoyValues[3])} elseif PLAN==5 then T[6]={k=${JSON.stringify(decoyValues[4])}};T[7]=${JSON.stringify(decoyValues[4])};T[8]=1 elseif PLAN==6 then if O==0 then T[7]=${sandboxNoopName} end;T[7]=${sandboxNoopName};T[8]=1;I0[2]=1;I0[3]=1 elseif PLAN==7 then T[7]=5;T[8]=3 elseif PLAN==9 then T[7]=5;T[8]=2 end;VM[${JSON.stringify(S.sp)}]=8;VM[${JSON.stringify(S.stack)}]=T` : `local T={};for J=1,24 do T[J]=(J%7)+1 end;T[2]=5;T[3]=7;T[4]=2;T[5]=4;T[6]={n=0};T[7]={};T[8]=${sandboxNoopName};T[9]=${JSON.stringify(decoyValues[3])};T[10]=${JSON.stringify(decoyValues[0])};T[11]=${JSON.stringify(decoyValues[1])};local PLAN=${semanticPlansName}[O]or 0;if PLAN==1 then T[3]=7;T[4]=2 elseif PLAN==2 then T[3]=${JSON.stringify(decoyValues[0])};T[4]=${JSON.stringify(decoyValues[1])} elseif PLAN==3 then T[3]=${JSON.stringify(decoyValues[2])} elseif PLAN==4 then T[3]={k=${JSON.stringify(decoyValues[3])}};T[4]=${JSON.stringify(decoyValues[3])} elseif PLAN==5 then T[2]={k=${JSON.stringify(decoyValues[4])}};T[3]=${JSON.stringify(decoyValues[4])};T[4]=7 elseif PLAN==6 then T[3]=${sandboxNoopName};T[4]=1;T[5]=5;T[6]={n=0};I0[4]=1;I0[5]=1;I0[6]=1 elseif PLAN==7 then I0[2]=0;I0[3]=3;T[3]={n=0} elseif PLAN==8 then T[2]={1,2,3};T[3]=1;T[4]=1 elseif PLAN==9 then T[3]=5;T[4]=6 elseif PLAN==10 then T[2]={};T[3]=${JSON.stringify(decoyValues[3])};T[4]=1 end;VM[${JSON.stringify(S.reg)}]=T`;
  const semanticProbeSource = `local ${semanticProbeName}=function(P,O,EV,PC,K)local VM=P[${vmStateKey}];if not VM then return ${N.mix}(K or ${initSeed},${N.xor}(O,EV or 0))end;local E={};setmetatable(E,{__index=function()return ${sandboxNoopName} end});local C={${constValues}};VM[${envSlot}]=E;VM[${constSlot}]=C;VM[${JSON.stringify(S.pc)}]=1;VM[${JSON.stringify(S.halt)}]=false;VM[${JSON.stringify(S.ret)}]={};VM[${JSON.stringify(S.varargs)}]={n=0};VM[${JSON.stringify(S.iter)}]={};VM[${JSON.stringify(S.locals)}]={};VM[${JSON.stringify(S.localSet)}]={};VM[${JSON.stringify(S.parent)}]=nil;local I0={0,2,3,4,1,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};${stackReset};local H=${semanticHandlersName}[O];local OK=false;if H then OK=pcall(H,VM,I0)end;local function VAL(Z)local T=type(Z);if T=="number"then return Z%4294967296 elseif T=="boolean"then return Z and 1 or 0 elseif T=="string"then return #Z elseif T=="table"then return #Z elseif T=="function"then return 37 end;return 0 end;local D=${N.mix}(K or ${initSeed},${N.xor}(O,${N.xor}(EV or 0,${N.xor}(PC or 0,OK and 1 or 0))));D=${N.mix}(D,VAL(VM[${JSON.stringify(S.pc)}]or 0));D=${N.mix}(D,VM[${JSON.stringify(S.halt)}]and 1 or 0);${mode === "stack" ? `local T=VM[${JSON.stringify(S.stack)}]or{};D=${N.mix}(D,VAL(VM[${JSON.stringify(S.sp)}]or 0));for J=5,8 do D=${N.mix}(D,VAL(T[J]))end` : `local T=VM[${JSON.stringify(S.reg)}]or{};for J=1,6 do D=${N.mix}(D,VAL(T[J]))end`};return D end`;
  // The proof path gets its own evaluator and scratch VM state. Replacing the live
  // semantic probe with a constant therefore creates a signature mismatch instead
  // of causing both the live lane and verifier to agree on the same forged value.
  const proofSemanticProbeSource = semanticProbeSource
    .replace(`local ${semanticProbeName}=function`, `local ${proofSemanticProbeName}=function`)
    .replace(`P[${vmStateKey}]`, `P[${proofVmStateKey}]`);
  const source = [
    `local ${sandboxNoopName}=function(...)return nil end`,
    `local ${sandboxConstName}=${registerHandler("", `local T=S[${constSlot}]or{};return T[(tonumber(I[2])or 0)+1]`, { seed: maskSeed ^ 0x51A7, identity: "semantic-shadow-sandbox-const" })}`,
    `local ${sandboxResolveName}=${registerHandler("", `local K=${sandboxConstName}(S,I);local E=S[${envSlot}]or{};if type(K)=="string"then local V0=rawget(E,K);if V0~=nil then return V0 end end;return ${sandboxNoopName}`, { seed: maskSeed ^ 0x1A57, identity: "semantic-shadow-sandbox-resolve" })}`,
    `local ${sandboxWriteName}=function(S,I,V0)local K=${sandboxConstName}(S,I);local E=S[${envSlot}]or{};if K==nil then K=0 elseif type(K)~="string"then K=tostring(K)end;E[K]=V0 end`,
    `local ${sandboxRunName}=function(...)return nil end`,
    `local ${sandboxSuperName}={}`,
    `local ${semanticPlansName}={${semanticPlanEntries.join(",")}}`,
    `local ${semanticHandlersName}={${renderedSemanticHandlerEntries.join(",")}}`,
    semanticProbeSource,
    proofSemanticProbeSource,
    `local ${codeName}={${flatCode.join(",")}}`,
    `local ${orderName}={${encodedOrder.join(",")}}`,
    `local ${handlersName}={${handlerSource.join(",")}}`,
    handlerCoreSource,
    `local ${liveMapName}={${runtimeOpcodeMap.join(",")}}`,
    `${initName}=function()local E={};setmetatable(E,{__index=function()return ${sandboxNoopName} end});local C={${constValues}};local VM=${helpers.state}(E,C,nil,${initSeed},${initSeed});local PE={};setmetatable(PE,{__index=function()return ${sandboxNoopName} end});local PC={${constValues}};local PVM=${helpers.state}(PE,PC,nil,${initSeed},${initSeed});return{${stateInitEntries.join(",")}}end`,
    `${proofName}=function(P,Q,I,R,L,K,BASE,STARTTICK,STARTTRACE)local function NUM(Z)local T=type(Z);if T=="number"then return Z elseif T=="boolean"then return Z and 1 or 0 elseif T=="string"then return #Z end;return 0 end;local AUTH=BASE or ${initialAuth};local EV=${N.mix}(Q[${S.guard}]or 0,${N.xor}(I[1]or 0,${N.xor}(R.id or 0,${N.xor}(L or 0,Q[${S.pc}]or 0))));local TRACE=(STARTTRACE or 0)+1;local function F(O,I0)local PC=NUM(Q[${S.pc}]or 0);local T=P[${semanticTraceKey}]and P[${semanticTraceKey}][TRACE];if not T or T[1]~=O or T[2]~=PC or T[3]~=EV or T[5]~=NUM(I0[2]or 0)or T[6]~=NUM(I0[3]or 0)or T[7]~=NUM(I0[4]or 0)or T[8]~=NUM(I0[5]or I0[4]or 0)or T[9]~=NUM(I0[6]or I0[5]or 0)then return false end;local SIG=${proofSemanticProbeName}(P,O,EV,PC,K);if T[4]~=SIG then return false end;AUTH=${N.mix}(AUTH,${N.mix}(${authValueExpr("O", "I0", "EV", "PC")},SIG));TRACE=TRACE+1;return true end;local LIVEOP=${liveMapName}[(NUM(L)+1)];if ${handlersName}[LIVEOP]==nil or not F(LIVEOP,I)then return false end;local START=STARTTICK or 0;for Z=1,${steps} do local PC=(START+Z)%${count}+1;local OM=${N.mix}(K or 0,${N.xor}((PC*${0x27D4EB2F})%4294967296,0x47800002));local PH=${N.xor}(${orderName}[PC]or 0,OM);local B0=(PH-1)*6;local function RD(J)local FM=${N.mix}(K or 0,${N.xor}((PC*${0x1F123BB5})%4294967296,${N.xor}((J*${0x45D9F3B})%4294967296,0x47800001)));return ${N.xor}(${codeName}[B0+J]or 0,FM)end;local OP=RD(1);local A=RD(2);local B=RD(3);local C=RD(4);local V=RD(5);local T=RD(6);if not ${handlersName}[OP]or not F(OP,{0,A,B,C,V,T})then return false end end;return TRACE==#(P[${semanticTraceKey}]or{})+1 and (P[${authKey}]or 0)==AUTH end`,
    `${stepName}=function(P,Q,I,R,L,K)local function NUM(Z)local T=type(Z);if T=="number"then return Z elseif T=="boolean"then return Z and 1 or 0 elseif T=="string"then return #Z end;return 0 end;local EV=${N.mix}(Q[${S.guard}]or 0,${N.xor}(I[1]or 0,${N.xor}(R.id or 0,${N.xor}(L or 0,Q[${S.pc}]or 0))));local LIVEOP=${liveMapName}[(NUM(L)+1)];if ${handlersName}[LIVEOP]==nil then error("ByteVeil v${runtimeVersion}: shadow ISA route mismatch",0)end;${handlerCoreName}(P,LIVEOP,I,Q,R,L,K,EV);for Z=1,${steps} do local PC=(${pState.tick} or 0)%${count}+1;local OM=${N.mix}(K or 0,${N.xor}((PC*${0x27D4EB2F})%4294967296,0x47800002));local PH=${N.xor}(${orderName}[PC]or 0,OM);local B0=(PH-1)*6;local function RD(J)local FM=${N.mix}(K or 0,${N.xor}((PC*${0x1F123BB5})%4294967296,${N.xor}((J*${0x45D9F3B})%4294967296,0x47800001)));return ${N.xor}(${codeName}[B0+J]or 0,FM)end;local OP=RD(1);local A=RD(2);local B=RD(3);local C=RD(4);local V=RD(5);local T=RD(6);if ${handlersName}[OP]==nil then error("ByteVeil v${runtimeVersion}: shadow payload opcode mismatch",0)end;${handlerCoreName}(P,OP,{0,A,B,C,V,T},Q,R,L,K,EV)end;${pState.acc}=${N.mix}(${pState.acc} or 0,${N.xor}(EV,${N.xor}(NUM(${pState.r}[((${pState.tick} or 0)%16)+1]or 0),NUM(${pState.pc} or 0))));return ${N.mix}(${pState.acc} or 0,${N.xor}(${pState.calls} or 0,${pState.ret} or 0))end`
  ].join(";\n");
  const renamedSource = hardenedShadow ? mangleLuaLocalIdentifiers(source, maskSeed) : source;

  return {
    source: renamedSource,
    instructionCount: count,
    handlerCount: handlerSource.length,
    stepsPerRealInstruction: steps + 1,
    traceOpcodeCount: 0,
    operandTraceDerived: false,
    liveOpcodeCoupled: true,
    traceInterleaveRatio: `exact-runtime-opcode-map-plus-${steps}-masked-isa-decoys-per-instruction`,
    dispatchStyle: runtimeVersion === "5.9.0"
      ? "per-build-exact-isa-map-runtime-opcode-plus-randomized-binary-decoy-rows-shared-handler-core-v59"
      : runtimeVersion === "5.8.0"
      ? "per-build-exact-isa-map-runtime-opcode-plus-randomized-binary-decoy-rows-shared-handler-core-v58"
      : "per-build-exact-isa-map-runtime-opcode-plus-randomized-binary-decoy-rows",
    fingerprint: mix32(maskSeed, count * 97 + handlerSource.length * 31 + steps * 17).toString(16).padStart(8, "0"),
    maskSeed,
    stateKeys: { ...shadowStateNames },
    shadowArchitecture: runtimeVersion === "5.9.0" ? "semantic-handler-sandbox-v59-shared-dispatch-core-veilsync-v2-region-verified" : runtimeVersion === "5.8.0" ? "semantic-handler-sandbox-v58-shared-dispatch-core-veilsync-v2-region-verified" : runtimeVersion === "5.7.0" ? "semantic-handler-sandbox-v57-callable-bootstrap-veilsync-v2-region-verified" : runtimeVersion === "5.6.0" ? "semantic-handler-sandbox-v56-local-mangled-veilsync-v2-region-verified" : runtimeVersion === "5.5.0" ? "semantic-handler-sandbox-v55-local-mangled-veilsync" : runtimeVersion === "5.4.0" ? "semantic-handler-sandbox-v54-local-mangled" : runtimeVersion === "5.3.0" ? "semantic-handler-sandbox-v51-build-diverse" : "semantic-handler-sandbox-v478",
    independentShadowProof: true,
    semanticHandlerCount: semanticHandlerEntries.length - missingSemanticHandlers.length,
    semanticHandlerCoverage: sourceOps.length ? (semanticHandlerEntries.length - missingSemanticHandlers.length) / sourceOps.length : 0,
    missingSemanticHandlers,
    realSemanticHandlerBodies: true,
    shadowAuthSlot: authName
  };
}

module.exports = { SHADOW_OPS, buildLiveShadowVM, buildSemanticShadowVM, mix32, mangleLuaLocalIdentifiers, buildShadowStrings };
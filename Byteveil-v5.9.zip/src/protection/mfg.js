"use strict";

const { u32, mix32, depthProfile } = require("./byte_blinder");
const { buildV455Personality, buildV46Personality } = require("../obfuscation/vm_personality");

function permutation(length, seed) {
  const out = Array.from({ length }, (_, i) => i + 1);
  let s = u32(seed) || 0x9E3779B9;
  for (let i = out.length - 1; i > 0; i--) {
    s ^= s >>> 16;
    s = Math.imul(s, 2246822519) >>> 0;
    s ^= s >>> 13;
    s = Math.imul(s, 3266489917) >>> 0;
    s ^= s >>> 16;
    s >>>= 0;
    const j = s % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function buildHandlerRoutes(opNames, seed) {
  const count = Math.max(1, opNames.length);
  const salts = [0xC0FFEE11, 0xBADC0DE2, 0x51A7E42C, 0x7F4A9D31];
  const slots = salts.map(salt => permutation(count, u32(seed ^ salt)));
  const routes = {};
  slots.forEach((order, lane) => {
    const table = Object.create(null);
    for (let i = 0; i < count; i++) table[opNames[i]] = order[i];
    routes[`slot${lane}`] = table;
  });
  return { ...routes, count, laneCount: 4 };
}

function buildVariantMask(opNames, seed) {
  return opNames.map((name, i) => (mix32(seed ^ i, name.length * 257 + i) % 4));
}

function buildDecoyTopology(depth, seed) {
  const size = Math.max(1, Math.min(128, depth));
  let s = u32(seed ^ 0xDEC0A17);
  const next = new Array(size);
  const alt = new Array(size);
  for (let i = 0; i < size; i++) {
    s = mix32(s, i + 1);
    next[i] = ((i + 1) % size) + 1;
    alt[i] = (s % size) + 1;
    if (alt[i] === next[i]) alt[i] = ((alt[i] % size) + 1);
  }
  return { depth: size, next, alt };
}

function buildMfgPlan({ seed = 1, strength = 1000, mode = "stack", opNames = [], version = "4.5.5" } = {}) {
  const profile = depthProfile(strength);
  const buildSeed = u32(seed);
  const personality = (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || (version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.7" || version === "4.7.8" || version === "4.7.9" || (version === "5.0.0" || version === "5.3.0" || version === "5.4.0" || (version === "5.5.0" || version === "5.6.0" || version === "5.7.0" || version === "5.8.0" || version === "5.9.0"))))) ? buildV46Personality(buildSeed, mode, version) : buildV455Personality(buildSeed, mode);
  return {
    version,
    family: ["4.6.1", "4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7", "4.6.8", "4.7.1", "4.7.2", "4.7.3", "4.7.4", "4.7.7", "4.7.8", "4.7.9", "5.0.0", "5.3.0", "5.4.0", "5.5.0", "5.6.0", "5.7.0", "5.8.0", "5.9.0"].includes(version)
      ? (version === "5.9.0" ? "MFG-5.9.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : version === "5.8.0" ? "MFG-5.8.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm" : version === "5.7.0" ? "MFG-5.7.0-callable-bootstrap-veilsync-v2-region-verified-vm" : version === "5.6.0" ? "MFG-5.6.0-veilsync-v2-region-verified-shadow-hardened-carrier-vm" : version === "5.5.0" ? "MFG-5.5.0-veilsync-shadow-hardened-carrier-vm" : version === "5.4.0" ? "MFG-5.4.0-build-diverse-shadow-hardened-carrier-vm" : version === "5.3.0" ? "MFG-5.3.0-build-diverse-carrier-vm" : version === "5.0.0" ? "MFG-5.0.0-position-keyed-carrier-vm" : version === "4.7.9" ? "MFG-4.7.9-striped-payload-vm" : version === "4.7.8" ? "MFG-4.7.8-semantic-shadow-vm" : version === "4.7.7" ? "MFG-4.7.7-hybrid-function-policy" : version === "4.7.4" ? "MFG-4.7.4" : version === "4.7.3" ? "MFG-4.7.3" : version === "4.7.2" ? "MFG-4.7.2" : version === "4.7.1" ? "MFG-4.7.1" : version === "4.6.8" ? "MFG-4.6.8" : version === "4.6.7" ? "MFG-4.6.7" : version === "4.6.6" ? "MFG-4.6.6" : version === "4.6.5" ? "MFG-4.6.5" : version === "4.6.4" ? "MFG-4.6.4" : "MFG-4.6.3")
      : "MFG-4.5.5",
    vmPersonality: personality.id,
    vmStateProfile: personality.id,
    vmDispatchStyle: personality.dispatchStyle,
    vmRecipeStyle: personality.recipeStyle,
    vmRepresentationStyle: personality.representationStyle,
    vmResolverFamily: personality.resolverFamily,
    vmStateModel: personality.stateModel,
    vmCommitStyle: personality.commitStyle,
    vmPersonality: (mix32(buildSeed, String(mode).length * 31) % 4),
    decoderFamily: (mix32(buildSeed, 0xD0C0DE) % 4),
    handlerRoutes: buildHandlerRoutes(opNames, buildSeed),
    variantMask: buildVariantMask(opNames, buildSeed ^ 0x99112233),
    decoyTopology: buildDecoyTopology(profile.depth, buildSeed ^ 0x5511AA77),
    decoyFamilies: [0,1,2,3].map(i => (mix32(buildSeed ^ Math.imul(i+1, 0x45D9F3B), profile.depth + i * 17) % 12)),
    protectionTopology: permutation(12, buildSeed ^ 0x7733CC11)
  };
}

module.exports = {
  permutation,
  buildHandlerRoutes,
  buildVariantMask,
  buildDecoyTopology,
  buildMfgPlan
};

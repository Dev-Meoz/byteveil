"use strict";

// Nested-source protection wraps the packed-bytecode VM for v4.7.4; v4.7.3 remains
// the explicitly historical single-layer branch: 
// it emits one VM program and creates no nested source wrappers. Codec helpers
// for earlier release formats remain here for regression and compatibility use.
// Older builds wrapped generated source in independently encoded stages, each
// with its own runtime reference and payload-integrity checks.

const SAFE_BASE85 = Array.from({ length: 85 }, (_, i) => String.fromCharCode(33 + i)).join("");

function u32(n) { return Number(n) >>> 0; }

function mix(seed, value) {
  let s = u32(seed ^ value ^ 0xC0FFEE17);
  s ^= s >>> 16;
  s = Math.imul(s, 2246822519) >>> 0;
  s ^= s >>> 13;
  s = Math.imul(s, 3266489917) >>> 0;
  return (s ^ (s >>> 16)) >>> 0;
}

function mix46(seed, value) {
  let s = (u32(seed) + Math.imul(u32(value), 0x9E3779B1)) >>> 0;
  s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
  s = (s + Math.floor(s / 65536) * 17) >>> 0;
  return s >>> 0;
}

// Balanced profile uses the lower-cost state step in four outer stages only.
// All nine layers, integrity checks and codec families remain; the remaining
// five stages keep the full mixer. This avoids per-byte scheduler overhead.
function mix46Lite(seed, value) {
  let s = (u32(seed) + u32(value) + 0x9E3779B1) >>> 0;
  s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
  return (s + Math.floor(s / 65536) * 17) >>> 0;
}


const DEEP_MODULUS = 2147483647;
const DEEP_VARIANTS = Object.freeze([
  { multiplier: 48271, divisor: 257, indexFactor: 13, feedback: 257, bias: 1, shape: 0 },
  { multiplier: 32749, divisor: 997, indexFactor: 17, feedback: 97, bias: 5, shape: 1 },
  { multiplier: 40699, divisor: 4093, indexFactor: 5, feedback: 313, bias: 31, shape: 2 }
]);

function deepVariant(seed, salt) {
  return mix46(u32(seed ^ salt ^ 0x7A61D3E9), 0x46700006) % DEEP_VARIANTS.length;
}

function deepInitialState(seed, salt, variant) {
  const d = DEEP_VARIANTS[variant];
  return (u32(seed + salt + 0x4D3C2B1A + variant * 0x1F123BB5) % (DEEP_MODULUS - 1)) + 1;
}

function deepStep(state, value, index, variant) {
  const d = DEEP_VARIANTS[variant];
  if (d.shape === 0) return (state * d.multiplier + value * d.feedback + index * d.indexFactor + d.bias) % DEEP_MODULUS;
  if (d.shape === 1) return ((state + value * d.feedback + index * d.indexFactor + d.bias) * d.multiplier) % DEEP_MODULUS;
  return (state * d.multiplier + (value + 11) * (index + 7) + d.bias) % DEEP_MODULUS;
}

function deepSbox(seed, salt, variant) {
  const values = Array.from({ length: 256 }, (_, i) => i);
  let state = mix46(u32(seed ^ salt ^ (0x6D2B79F5 + variant * 0x10204081)), 0x46700007);
  for (let i = values.length - 1; i > 0; i--) {
    state = mix46(state, (i + 1) ^ (0x9E3779B9 + variant * 0x11111111));
    const j = state % (i + 1);
    [values[i], values[j]] = [values[j], values[i]];
  }
  return values;
}

function deepHash32(text) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < text.length; i++) h = (h * 33 + text.charCodeAt(i) + (i + 1) * 17) % 4294967296;
  return h >>> 0;
}

// v4.7.0: deepest-stage codec. Unlike the prior two-lane transform, it uses
// three interleaved lanes and a ciphertext-coupled feedback byte. This is an
// obfuscation format change, not a cryptographic primitive.
const DEEP47_MODULUS = 2147483647;
const DEEP47_VARIANTS = Object.freeze([
  { multiplier: 48271, divisor: 257, valueFactor: 211, cipherFactor: 37, indexFactor: 13, bias: 19, feedbackMultiplier: 29, feedbackCipher: 7, feedbackIndex: 11, feedbackBias: 3, shape: 0 },
  { multiplier: 32749, divisor: 997, valueFactor: 193, cipherFactor: 53, indexFactor: 17, bias: 31, feedbackMultiplier: 41, feedbackCipher: 9, feedbackIndex: 5, feedbackBias: 17, shape: 1 },
  { multiplier: 40699, divisor: 4093, valueFactor: 157, cipherFactor: 61, indexFactor: 5, bias: 43, feedbackMultiplier: 23, feedbackCipher: 13, feedbackIndex: 19, feedbackBias: 7, shape: 2 },
  { multiplier: 65521, divisor: 2039, valueFactor: 181, cipherFactor: 29, indexFactor: 23, bias: 11, feedbackMultiplier: 37, feedbackCipher: 5, feedbackIndex: 3, feedbackBias: 29, shape: 3 },
]);

function deep47Variant(seed, salt) {
  return mix46(u32(seed ^ salt ^ 0xB47C0DEC), 0x47000007) % DEEP47_VARIANTS.length;
}

function deep47InitialState(seed, salt, variant) {
  return (u32(seed + salt + 0x72E91A4D + variant * 0x1F123BB5) % (DEEP47_MODULUS - 1)) + 1;
}

function deep47Sbox(seed, salt, variant) {
  const values = Array.from({ length: 256 }, (_, i) => i);
  let state = mix46(u32(seed ^ salt ^ (0x4B1D5A73 + variant * 0x10204081)), 0x47000008);
  for (let i = values.length - 1; i > 0; i--) {
    state = (Math.imul((state ^ Math.imul(i + 1, 0x45D9F3B)) >>> 0, 1664525) + 1013904223) >>> 0;
    state = (state + Math.floor(state / 65536) * 17) >>> 0;
    const j = state % (i + 1);
    [values[i], values[j]] = [values[j], values[i]];
  }
  return values;
}

function deep47Step(state, plain, cipher, index, feedback, variant) {
  const d = DEEP47_VARIANTS[variant];
  if (d.shape === 0) return (state * d.multiplier + (plain + feedback + 1) * d.valueFactor + cipher * d.cipherFactor + index * d.indexFactor + d.bias) % DEEP47_MODULUS;
  if (d.shape === 1) return ((state + (plain + 17) * d.valueFactor + (cipher + feedback) * d.cipherFactor + index * d.indexFactor + d.bias) * d.multiplier) % DEEP47_MODULUS;
  if (d.shape === 2) return (state * d.multiplier + (plain + cipher + feedback + 11) * (index + 7) + d.valueFactor * d.bias) % DEEP47_MODULUS;
  return (state * d.multiplier + plain * d.valueFactor + cipher * d.cipherFactor + (feedback + index) * d.indexFactor + d.bias) % DEEP47_MODULUS;
}

function deep47Feedback(feedback, cipher, index, variant) {
  const d = DEEP47_VARIANTS[variant];
  return (feedback * d.feedbackMultiplier + cipher * d.feedbackCipher + index * d.feedbackIndex + d.feedbackBias) % 256;
}

function transformedBytes47(source, seed, salt) {
  const bytes = Buffer.isBuffer(source) ? source : Buffer.from(source, "utf8");
  const out = Buffer.allocUnsafe(bytes.length);
  const variant = deep47Variant(seed, salt);
  const sbox = deep47Sbox(seed, salt, variant);
  const d = DEEP47_VARIANTS[variant];
  let state = deep47InitialState(seed, salt, variant);
  let feedback = u32(seed ^ salt ^ (0x5A + variant * 0x35)) % 256;
  for (let i = 0; i < bytes.length; i++) {
    const plain = bytes[i];
    const key = Math.floor(state / d.divisor) % 256;
    const cipher = sbox[(plain + key + feedback) & 0xff];
    out[i] = cipher;
    state = deep47Step(state, plain, cipher, i + 1, feedback, variant);
    feedback = deep47Feedback(feedback, cipher, i + 1, variant);
  }
  return { bytes: out, variant };
}

// v4.7.2–v4.7.4 deepest-layer codec family. This is an independent ByteVeil format inspired by
// static observations of heterogeneous payload/layout families, not copied from
// Luraph. It keeps native Lua/Luau execution: only standard string/table/math
// facilities are used in the emitted decoder.
const DEEP48_MODULUS = 2147483647;
const DEEP48_VARIANTS = Object.freeze([
  { multiplier: 48271, divisor: 257, valueFactor: 73, cipherFactor: 19, indexFactor: 13, laneFactor: 29, blockFactor: 41, bias: 7, feedbackMultiplier: 29, feedbackCipher: 7, feedbackIndex: 11, feedbackLane: 5, feedbackBlock: 3, feedbackBias: 17, phase: 1, shape: 0 },
  { multiplier: 32749, divisor: 997, valueFactor: 61, cipherFactor: 31, indexFactor: 17, laneFactor: 23, blockFactor: 37, bias: 19, feedbackMultiplier: 41, feedbackCipher: 9, feedbackIndex: 5, feedbackLane: 7, feedbackBlock: 11, feedbackBias: 13, phase: 3, shape: 1 },
  { multiplier: 40699, divisor: 4093, valueFactor: 47, cipherFactor: 43, indexFactor: 5, laneFactor: 31, blockFactor: 23, bias: 29, feedbackMultiplier: 23, feedbackCipher: 13, feedbackIndex: 19, feedbackLane: 3, feedbackBlock: 17, feedbackBias: 5, phase: 2, shape: 2 },
  { multiplier: 65521, divisor: 2039, valueFactor: 89, cipherFactor: 11, indexFactor: 23, laneFactor: 17, blockFactor: 31, bias: 11, feedbackMultiplier: 37, feedbackCipher: 5, feedbackIndex: 3, feedbackLane: 11, feedbackBlock: 7, feedbackBias: 29, phase: 1, shape: 3 }
]);

function deep48Variant(seed, salt) {
  return mix46(u32(seed ^ salt ^ 0x472C0DEC), 0x47200008) % DEEP48_VARIANTS.length;
}

function deep48Sbox(seed, salt, variant) {
  const values = Array.from({ length: 256 }, (_, i) => i);
  let state = mix46(u32(seed ^ salt ^ (0x48A15EED + variant * 0x10204081)), 0x47200009);
  for (let i = values.length - 1; i > 0; i--) {
    state = (Math.imul((state ^ Math.imul(i + 1, 0x45D9F3B)) >>> 0, 1664525) + 1013904223) >>> 0;
    state = (state + Math.floor(state / 65536) * 17) >>> 0;
    const j = state % (i + 1);
    [values[i], values[j]] = [values[j], values[i]];
  }
  return values;
}

function deep48InitialState(seed, salt, lane, variant) {
  return (mix46(u32(seed + salt + 0x48D3A29B + variant * 0x1F123BB5 + lane * 0x6C8E9CF5), 0x4720000A + lane) % (DEEP48_MODULUS - 1)) + 1;
}

function deep48InitialFeedback(seed, salt, lane, variant) {
  return u32(seed ^ salt ^ (0x48 + variant * 0x35) ^ Math.imul(lane + 1, 0x9E3779B9)) % 256;
}

function deep48Step(state, plain, cipher, index, lanePos, feedback, lane, block, variant) {
  const d = DEEP48_VARIANTS[variant];
  if (d.shape === 0) return (state * d.multiplier + (plain + feedback + 1) * d.valueFactor + cipher * d.cipherFactor + index * d.indexFactor + lanePos * d.laneFactor + block * d.blockFactor + lane * d.feedbackLane + d.bias) % DEEP48_MODULUS;
  if (d.shape === 1) return ((state + (plain + 17) * d.valueFactor + (cipher + feedback) * d.cipherFactor + index * d.indexFactor + lanePos * d.laneFactor + block * d.blockFactor + lane * d.feedbackLane + d.bias) * d.multiplier) % DEEP48_MODULUS;
  if (d.shape === 2) return (state * d.multiplier + (plain + cipher + feedback + 11) * (index + 7) + d.valueFactor * d.bias + lanePos * d.laneFactor + block * d.blockFactor + lane * d.feedbackLane) % DEEP48_MODULUS;
  return (state * d.multiplier + plain * d.valueFactor + cipher * d.cipherFactor + (feedback + index) * d.indexFactor + lanePos * d.laneFactor + block * d.blockFactor + lane * d.feedbackLane + d.bias) % DEEP48_MODULUS;
}

function deep48Feedback(feedback, cipher, index, lane, block, variant) {
  const d = DEEP48_VARIANTS[variant];
  return (feedback * d.feedbackMultiplier + cipher * d.feedbackCipher + index * d.feedbackIndex + lane * d.feedbackLane + block * d.feedbackBlock + d.feedbackBias) % 256;
}

function transformedBytes48(source, seed, salt) {
  const bytes = Buffer.isBuffer(source) ? source : Buffer.from(source, "utf8");
  // Only the ordered ciphertext stream is serialized. Keep lane state separate,
  // but do not allocate four sparse JS arrays and four throwaway Buffers.
  const ordered = Buffer.allocUnsafe(bytes.length);
  const variant = deep48Variant(seed, salt);
  const d = DEEP48_VARIANTS[variant];
  const sbox = deep48Sbox(seed, salt, variant);
  const states = [0, 1, 2, 3].map((lane) => deep48InitialState(seed, salt, lane, variant));
  const feedbacks = [0, 1, 2, 3].map((lane) => deep48InitialFeedback(seed, salt, lane, variant));
  for (let i = 0; i < bytes.length; i++) {
    const block = Math.floor(i / 32);
    const offset = i % 32;
    const lane = (offset % 4 + block * d.phase) % 4;
    const lanePos = block * 8 + Math.floor(offset / 4);
    const plain = bytes[i];
    const key = Math.floor(states[lane] / d.divisor) % 256;
    const cipher = sbox[(plain + key + feedbacks[lane] + block * d.blockFactor) & 0xff];
    ordered[i] = cipher;
    states[lane] = deep48Step(states[lane], plain, cipher, i + 1, lanePos + 1, feedbacks[lane], lane, block, variant);
    feedbacks[lane] = deep48Feedback(feedbacks[lane], cipher, i + 1, lane, block, variant);
  }
  return { ordered, variant };
}

function addHash32(bytes) {
  const input = Buffer.isBuffer(bytes) ? bytes : Buffer.from(String(bytes), "utf8");
  let h = 2166136261 >>> 0;
  for (const b of input) h = (Math.imul(h, 16777619) + b + 1) >>> 0;
  return h >>> 0;
}

function fnv32(text) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < text.length; i++) h = Math.imul((h ^ text.charCodeAt(i)) >>> 0, 16777619) >>> 0;
  return h >>> 0;
}

function layerCount(strength) {
  const s = Math.max(100, Math.min(10000, Number(strength) || 1000));
  if (s >= 10000) return 9;
  if (s >= 8000) return 7;
  if (s >= 3500) return 5;
  return 3;
}

function codecFor(index, seed) {
  return u32(seed ^ Math.imul(index + 1, 0x45D9F3B) ^ 0xA5A5C3C3) % 6;
}

function base85Encode(bytes) {
  // Build bounded chunks instead of repeatedly extending one large string.
  // This controls transient allocation for large nested layers without changing
  // the wire format or adding any intermediate files on disk.
  const parts = [];
  let chunk = "";
  for (let i = 0; i < bytes.length; i += 4) {
    const remain = Math.min(4, bytes.length - i);
    let n = 0;
    for (let j = 0; j < 4; j++) n = (n * 256) + (j < remain ? bytes[i + j] : 0);
    const chars = new Array(5);
    for (let j = 4; j >= 0; j--) { chars[j] = SAFE_BASE85[n % 85]; n = Math.floor(n / 85); }
    chunk += chars.join("");
    if (chunk.length >= 8192) { parts.push(chunk); chunk = ""; }
  }
  if (chunk) parts.push(chunk);
  return parts.join("");
}

function transformedBytes(source, codec, seed, salt) {
  const bytes = Buffer.isBuffer(source) ? source : Buffer.from(source, "utf8");
  const out = Buffer.allocUnsafe(bytes.length);
  let s = u32(seed ^ salt ^ (0x13D + codec * 0x101));
  let previous = 0;
  for (let i = 0; i < bytes.length; i++) {
    switch (codec) {
      case 0:
        s = mix(s, i + 1);
        out[i] = bytes[i] ^ (s & 0xff);
        break;
      case 1:
        s = mix(s, (i + 3) * 17);
        out[i] = (bytes[i] + (s & 0xff)) & 0xff;
        break;
      case 2: {
        s = mix(s, i + salt);
        const v = bytes[i] ^ (s & 0xff);
        out[bytes.length - i - 1] = ((v & 0x0f) << 4) | ((v >>> 4) & 0x0f);
        break;
      }
      case 3:
        s = mix(s, u32((i + 1) ^ previous));
        out[i] = bytes[i] ^ (s & 0xff) ^ previous;
        previous = out[i];
        break;
      default:
        s = mix(s, (i + 5) ^ 0x55AA);
        out[i] = (bytes[bytes.length - i - 1] + (s & 0xff)) & 0xff;
        break;
    }
  }
  return out;
}

function transformedBytes46(source, codec, seed, salt, profile = "full") {
  const bytes = Buffer.isBuffer(source) ? source : Buffer.from(source, "utf8");
  const out = Buffer.allocUnsafe(bytes.length);
  if (codec === 6) {
    const variant = deepVariant(seed, salt);
    const sbox = deepSbox(seed, salt, variant);
    let state = deepInitialState(seed, salt, variant);
    const divisor = DEEP_VARIANTS[variant].divisor;
    for (let i = 0; i < bytes.length; i++) {
      const value = bytes[i];
      const key = Math.floor(state / divisor) % 256;
      out[i] = sbox[(value + key) & 0xff];
      state = deepStep(state, value, i + 1, variant);
    }
    return out;
  }
  let state = u32(seed + salt + (0x13D + codec * 0x101));
  let previous = 0;
  const mixState = profile === "lite" ? mix46Lite : mix46;
  for (let i = 0; i < bytes.length; i++) {
    if (codec === 0) {
      state = mixState(state, i + 1);
      out[i] = bytes[i] ^ (state & 0xff);
    } else if (codec === 1) {
      state = mixState(state, (i + 2) * 17);
      out[i] = (bytes[i] + (state & 0xff)) & 0xff;
    } else if (codec === 2) {
      state = mixState(state, i + salt);
      const v = bytes[i] ^ (state & 0xff);
      out[bytes.length - i - 1] = ((v & 0x0f) << 4) | ((v >>> 4) & 0x0f);
    } else if (codec === 3) {
      state = mixState(state, (i + 1) + previous);
      out[i] = bytes[i] ^ (state & 0xff) ^ previous;
      previous = out[i];
    } else if (codec === 4) {
      state = mixState(state, i + 5);
      out[i] = (bytes[bytes.length - i - 1] + (state & 0xff)) & 0xff;
    } else {
      state = mixState(state, i + 4 + 0x55AA);
      out[i] = (bytes[bytes.length - i - 1] + (state & 0xff)) & 0xff;
    }
  }
  return out;
}

// Bounded LZSS keeps all nested stages and their runtime checks while reducing
// repeated VM/source-loader syntax before the per-layer codec is applied.
// Window: 32768 bytes (extended distance tokens); match length: 3..18; groups carry up to 8 tokens.
function compressLzss(input, maxMatchLength = 3) {
  const matchLimit = Math.max(3, Math.min(18, Number(maxMatchLength) || 18));
  const bytes = Buffer.isBuffer(input) ? input : Buffer.from(input, "utf8");
  if (bytes.length < 768) return bytes;
  const out = [];
  const chains = new Map();
  // Bound match-search CPU on large high-entropy payloads. Longer matches
  // need fewer candidates; this changes compression ratio only, never codec,
  // integrity checks, layer count, or protection strength.
  const candidateLimit = matchLimit >= 18 ? 8 : 48;
  const addPosition = (pos) => {
    if (pos + 2 >= bytes.length) return;
    const key = (bytes[pos] << 16) | (bytes[pos + 1] << 8) | bytes[pos + 2];
    let chain = chains.get(key);
    if (!chain) chains.set(key, chain = []);
    chain.push(pos);
    // The recent candidates dominate compression. Bound work on repetitive files.
    if (chain.length > candidateLimit) chain.splice(0, chain.length - candidateLimit);
  };
  let pos = 0;
  let longOffsetReferences = 0;
  while (pos < bytes.length) {
    const flagIndex = out.length;
    out.push(0);
    let flags = 0;
    for (let bit = 0; bit < 8 && pos < bytes.length; bit++) {
      let bestLength = 0;
      let bestOffset = 0;
      if (pos + 2 < bytes.length) {
        const key = (bytes[pos] << 16) | (bytes[pos + 1] << 8) | bytes[pos + 2];
        const chain = chains.get(key);
        if (chain) {
          for (let ci = chain.length - 1; ci >= 0; ci--) {
            const candidate = chain[ci];
            const offset = pos - candidate;
            if (offset <= 0) continue;
            if (offset > 32768) break;
            const max = Math.min(matchLimit, bytes.length - pos);
            let length = 3;
            while (length < max && bytes[candidate + (length % offset)] === bytes[pos + length]) length++;
            if (length > bestLength) {
              bestLength = length;
              bestOffset = offset;
              if (length === max) break;
            }
          }
        }
      }
      if (bestLength >= 3) {
        const longOffset = bestOffset >= 4096;
        const packed = ((longOffset ? 4095 : bestOffset - 1) << 4) | (bestLength - 3);
        out.push(packed & 0xff, (packed >>> 8) & 0xff);
        if (longOffset) {
          out.push(bestOffset & 0xff, (bestOffset >>> 8) & 0xff);
          longOffsetReferences++;
        }
        for (let j = 0; j < bestLength; j++) addPosition(pos + j);
        pos += bestLength;
      } else {
        flags |= 1 << bit;
        out.push(bytes[pos]);
        addPosition(pos);
        pos++;
      }
    }
    out[flagIndex] = flags;
  }
  const compressed = Buffer.from(out);
  compressed.byteveilLongOffsetReferences = longOffsetReferences;
  // Account for the small Lua-side decoder added to a compressed wrapper.
  return compressed.length + 384 < bytes.length ? compressed : bytes;
}

function encodeLayer(source, codec, seed, salt, fast = false, profile = "full", compress = false) {
  const originalBytes = Buffer.from(source, "utf8");
  // Keep small/typical builds within their tuned output budget. When a generated
  // payload itself grows large, stronger lossless matches reduce codec overhead
  // without removing or combining any protection stages.
  const compressionMatchLimit = originalBytes.length >= 52_000 ? 18 : 3;
  const bytes = compress ? compressLzss(originalBytes, compressionMatchLimit) : originalBytes;
  const compressed = compress && bytes.length < originalBytes.length;
  const longOffsetReferences = Number(bytes.byteveilLongOffsetReferences || 0);
  if (codec === 8) {
    const tx = transformedBytes48(bytes, seed, salt);
    // Serialize the independent lane-cipher results into one ordered wire stream.
    // This avoids visible per-lane separators while preserving separate lane states.
    return { data: base85Encode(tx.ordered), length: bytes.length, sourceLength: originalBytes.length, compressed, compressionMatchLimit, longOffsetReferences };
  }
  if (codec === 7) {
    const tx = transformedBytes47(bytes, seed, salt).bytes;
    const lanes = [[], [], []];
    for (let i = 0; i < tx.length; i++) lanes[i % 3].push(tx[i]);
    return { data: lanes.map((lane) => base85Encode(Buffer.from(lane))).join("~"), length: bytes.length, sourceLength: originalBytes.length, compressed, compressionMatchLimit, longOffsetReferences };
  }
  if (codec === 6) {
    const tx = transformedBytes46(bytes, 6, seed, salt, profile);
    const even = Buffer.allocUnsafe(Math.ceil(tx.length / 2));
    const odd = Buffer.allocUnsafe(Math.floor(tx.length / 2));
    for (let i = 0; i < tx.length; i++) {
      if (i & 1) odd[i >>> 1] = tx[i];
      else even[i >>> 1] = tx[i];
    }
    return { data: `${base85Encode(even)}~${base85Encode(odd)}`, length: bytes.length, sourceLength: originalBytes.length, compressed, compressionMatchLimit, longOffsetReferences };
  }
  if (codec === 4) {
    const even = Buffer.allocUnsafe(Math.ceil(bytes.length / 2));
    const odd = Buffer.allocUnsafe(Math.floor(bytes.length / 2));
    for (let i = 0; i < bytes.length; i++) {
      if (i & 1) odd[i >>> 1] = bytes[i];
      else even[i >>> 1] = bytes[i];
    }
    const tx0 = fast
      ? transformedBytes46(even, 0, seed ^ 0x11, salt + 1, profile)
      : transformedBytes(even, 0, seed ^ 0x11, salt + 1);
    const tx1 = fast
      ? transformedBytes46(odd, 1, seed ^ 0x22, salt + 2, profile)
      : transformedBytes(odd, 1, seed ^ 0x22, salt + 2);
    return { data: `${base85Encode(tx0)}~${base85Encode(tx1)}`, length: bytes.length, sourceLength: originalBytes.length, compressed, compressionMatchLimit, longOffsetReferences };
  }
  const tx = fast
    ? transformedBytes46(bytes, codec, seed, salt, profile)
    : transformedBytes(bytes, codec, seed, salt);
  return { data: base85Encode(tx), length: bytes.length, sourceLength: originalBytes.length, compressed, compressionMatchLimit, longOffsetReferences };
}

function ident(seed, serial) {
  let s = mix(seed, Math.imul(serial + 1, 0x9E3779B9));
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let out = "_";
  for (let i = 0; i < 11; i++) { s = mix(s, i + 1); out += chars[s % chars.length]; }
  return out;
}

function luaUnsignedXor(names) {
  return `local ${names.bxor}=function(A,B)A=A%4294967296;B=B%4294967296;if bit32 and bit32.bxor then return bit32.bxor(A,B)%4294967296 end;local R=0;local P=1;for I=1,32 do local a=A%2;local b=B%2;if a~=b then R=R+P end;A=(A-a)/2;B=(B-b)/2;P=P*2 end;return R%4294967296 end;local ${names.mul}=function(A,B)local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;local ${names.mix}=function(U,V)local R=${names.bxor}(U,${names.bxor}(V,0xC0FFEE17));R=${names.bxor}(R,math.floor(R/65536));R=${names.mul}(R,2246822519);R=${names.bxor}(R,math.floor(R/8192));R=${names.mul}(R,3266489917);return ${names.bxor}(R,math.floor(R/65536))end`;
}

function decoderBody(codec, names, seed, salt) {
  const base = `local ${names.map}={};for I=1,#${names.alphabet} do local C=string.sub(${names.alphabet},I,I);${names.map}[C]=I-1 end;local ${names.toBytes}=function(S)local O={};for I=1,#S do local C=string.sub(S,I,I);local P=${names.map}[C];if P==nil then error("ByteVeil v4.5.5: nested alphabet",0)end;O[I]=P end;return O end;local ${names.b85}=function(S)local T=${names.toBytes}(S);local O={};local R=1;for I=1,#T,5 do local V=0;for J=0,4 do V=V*85+(T[I+J]or 0)end;O[R]=math.floor(V/16777216)%256;O[R+1]=math.floor(V/65536)%256;O[R+2]=math.floor(V/256)%256;O[R+3]=V%256;R=R+4 end;return O end;local ${names.emit}=function(B,L)local A={};for I=1,math.min(#B,L) do A[I]=string.char(B[I])end;return table.concat(A)end`;
  if (codec === 0) {
    return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed ^ salt ^ 0x13D)};for I=1,${names.length} do R=${names.mix}(R,I);${names.raw}[I]=${names.bxor}(${names.raw}[I]or 0,R%256)end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  }
  if (codec === 1) {
    return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed ^ salt ^ (0x13D + 1 * 0x101))};for I=1,${names.length} do R=${names.mix}(R,(I+2)*17);${names.raw}[I]=(${names.raw}[I]or 0)-(R%256);if ${names.raw}[I]<0 then ${names.raw}[I]=${names.raw}[I]+256 end end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  }
  if (codec === 2) {
    return `${base};local ${names.raw}=${names.b85}(${names.blob});local O={};local R=${u32(seed ^ salt ^ (0x13D + 2 * 0x101))};for I=1,${names.length} do R=${names.mix}(R,I-1+${salt});local V=${names.raw}[${names.length}-I+1]or 0;V=${names.bxor}(((V%16)*16+math.floor(V/16)),R%256);O[I]=V;${names.raw}[${names.length}-I+1]=nil end;${names.raw}=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
  }
  if (codec === 3) {
    return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed ^ salt ^ (0x13D + 3 * 0x101))};local P=0;for I=1,${names.length} do R=${names.mix}(R,${names.bxor}(I,P));local C=${names.raw}[I]or 0;local V=${names.bxor}(${names.bxor}(C,R%256),P);${names.raw}[I]=V;P=C end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  }
  if (codec === 4) {
    return `${base};local ${names.sep}=string.find(${names.blob},"~",1,true);if not ${names.sep} then error("ByteVeil v4.5.5: nested split",0)end;local ${names.left}=string.sub(${names.blob},1,${names.sep}-1);local ${names.right}=string.sub(${names.blob},${names.sep}+1);local ${names.raw}=${names.b85}(${names.left});local ${names.raw2}=${names.b85}(${names.right});local RA=${u32((seed ^ 0x11) ^ (salt + 1) ^ 0x13D)};local RB=${u32((seed ^ 0x22) ^ (salt + 2) ^ (0x13D + 0x101))};local L={};for I=1,math.ceil(${names.length}/2) do RA=${names.mix}(RA,I);L[I*2-1]=${names.bxor}(${names.raw}[I]or 0,RA%256)end;for I=1,math.floor(${names.length}/2) do RB=${names.mix}(RB,(I+2)*17);local V=(${names.raw2}[I]or 0)-(RB%256);if V<0 then V=V+256 end;L[I*2]=V end;${names.raw}=nil;${names.raw2}=nil;${names.left}=nil;${names.right}=nil;${names.source}=${names.emit}(L,${names.length});L=nil`;
  }
  return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed ^ salt ^ (0x13D + 5 * 0x101))};local O={};for I=1,${names.length} do R=${names.mix}(R,${names.bxor}(I+4,0x55AA));local V=${names.raw}[I]or 0;V=V-(R%256);if V<0 then V=V+256 end;O[${names.length}-I+1]=V end;${names.source}=${names.emit}(O,${names.length});${names.raw}=nil;O=nil`;
}

function luaFastPrimitives(names, useLite = false) {
  const xor = [];
  for (let a = 0; a < 16; a++) xor.push(`{${Array.from({length:16}, (_, b) => a ^ b).join(',')}}`);
  const lowCost = useLite
    ? `;local ${names.mixLite}=function(U,V)local S=(U+V+2654435761)%4294967296;S=(${names.mul}(S,1664525)+1013904223)%4294967296;return(S+math.floor(S/65536)*17)%4294967296 end`
    : "";
  return `local ${names.nib}={${xor.join(',')}};local ${names.x8}=function(A,B)local al=A%16;local ah=math.floor(A/16);local bl=B%16;local bh=math.floor(B/16);return ${names.nib}[al+1][bl+1]+16*${names.nib}[ah+1][bh+1]end;local ${names.mul}=function(A,B)local a=A%65536;local ah=math.floor(A/65536);local b=B%65536;local bh=math.floor(B/65536);return(a*b+((a*bh+ah*b)%65536)*65536)%4294967296 end;local ${names.mix46}=function(U,V)local S=(U+${names.mul}(V,2654435761))%4294967296;S=(${names.mul}(S,1664525)+1013904223)%4294967296;return(S+math.floor(S/65536)*17)%4294967296 end${lowCost}`;
}

function decoderBody46(codec, names, seed, salt, profile = "full", version = "4.6.7") {
  // Decode Base85 directly from the source string. Chunked emission bounds
  // temporary strings and byte entries are cleared as soon as they are consumed.
  const base = `local ${names.b85}=function(S)local O={};local R=1;for I=1,#S,5 do local V=0;for J=0,4 do local C=string.byte(S,I+J);local D=0;if C and C>=33 and C<=117 then D=C-33 end;V=V*85+D end;O[R]=math.floor(V/16777216)%256;O[R+1]=math.floor(V/65536)%256;O[R+2]=math.floor(V/256)%256;O[R+3]=V%256;R=R+4 end;return O end;local ${names.emit}=function(B,L)local U=table.unpack or unpack;local P={};local N=1;while N<=L do local E=math.min(N+255,L);P[#P+1]=string.char(U(B,N,E));for J=N,E do B[J]=nil end;N=E+1 end;return table.concat(P)end`;
  const m = names.mix46;
  const step = (state, value) => `${state}=${profile === "lite" ? names.mixLite : m}(${state},${value})`;
  if (codec === 8) {
    const variant = deep48Variant(seed, salt);
    const d = DEEP48_VARIANTS[variant];
    const sbox = deep48Sbox(seed, salt, variant);
    const inverse = new Array(256);
    for (let i = 0; i < sbox.length; i++) inverse[sbox[i]] = i;
    // Store the inverse table as a compact Base85 byte string instead of a
    // large decimal literal; base decoding uses the same native helper above.
    const inverseEncoded = base85Encode(Buffer.from(inverse));
    const initialStates = [0, 1, 2, 3].map((lane) => deep48InitialState(seed, salt, lane, variant));
    const initialFeedbacks = [0, 1, 2, 3].map((lane) => deep48InitialFeedback(seed, salt, lane, variant));
    let advance;
    if (d.shape === 0) advance = `Q[X+1]=(Q[X+1]*${d.multiplier}+(W+FF[X+1]+1)*${d.valueFactor}+C0*${d.cipherFactor}+I*${d.indexFactor}+J*${d.laneFactor}+BK*${d.blockFactor}+X*${d.feedbackLane}+${d.bias})%2147483647`;
    else if (d.shape === 1) advance = `Q[X+1]=((Q[X+1]+(W+17)*${d.valueFactor}+(C0+FF[X+1])*${d.cipherFactor}+I*${d.indexFactor}+J*${d.laneFactor}+BK*${d.blockFactor}+X*${d.feedbackLane}+${d.bias})*${d.multiplier})%2147483647`;
    else if (d.shape === 2) advance = `Q[X+1]=(Q[X+1]*${d.multiplier}+(W+C0+FF[X+1]+11)*(I+7)+${d.valueFactor * d.bias}+J*${d.laneFactor}+BK*${d.blockFactor}+X*${d.feedbackLane})%2147483647`;
    else advance = `Q[X+1]=(Q[X+1]*${d.multiplier}+W*${d.valueFactor}+C0*${d.cipherFactor}+(FF[X+1]+I)*${d.indexFactor}+J*${d.laneFactor}+BK*${d.blockFactor}+X*${d.feedbackLane}+${d.bias})%2147483647`;
    const fstep = `FF[X+1]=(FF[X+1]*${d.feedbackMultiplier}+C0*${d.feedbackCipher}+I*${d.feedbackIndex}+X*${d.feedbackLane}+BK*${d.feedbackBlock}+${d.feedbackBias})%256`;
    return `${base};local A=${names.b85}(${names.blob});local T=${names.b85}(${JSON.stringify(inverseEncoded)});local Q={${initialStates.join(",")}};local FF={${initialFeedbacks.join(",")}};local O={};for I=1,${names.length} do local Z=I-1;local BK=math.floor(Z/32);local OFF=Z%32;local X=(OFF%4+BK*${d.phase})%4;local J=BK*8+math.floor(OFF/4)+1;local C0=A[I]or 0;A[I]=nil;local W=T[C0+1]or 0;local K=math.floor(Q[X+1]/${d.divisor})%256;W=(W-K-FF[X+1]-BK*${d.blockFactor})%256;O[I]=W;${advance};${fstep} end;A=nil;T=nil;Q=nil;FF=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
  }
  if (codec === 7) {
    const variant = deep47Variant(seed, salt);
    const d = DEEP47_VARIANTS[variant];
    const sbox = deep47Sbox(seed, salt, variant);
    const inverse = new Array(256);
    for (let i = 0; i < sbox.length; i++) inverse[sbox[i]] = i;
    const initial = deep47InitialState(seed, salt, variant);
    let advance;
    if (d.shape === 0) advance = `Q=(Q*${d.multiplier}+(W+F+1)*${d.valueFactor}+C0*${d.cipherFactor}+I*${d.indexFactor}+${d.bias})%2147483647`;
    else if (d.shape === 1) advance = `Q=((Q+(W+17)*${d.valueFactor}+(C0+F)*${d.cipherFactor}+I*${d.indexFactor}+${d.bias})*${d.multiplier})%2147483647`;
    else if (d.shape === 2) advance = `Q=(Q*${d.multiplier}+(W+C0+F+11)*(I+7)+${d.valueFactor * d.bias})%2147483647`;
    else advance = `Q=(Q*${d.multiplier}+W*${d.valueFactor}+C0*${d.cipherFactor}+(F+I)*${d.indexFactor}+${d.bias})%2147483647`;
    const fstep = `F=(F*${d.feedbackMultiplier}+C0*${d.feedbackCipher}+I*${d.feedbackIndex}+${d.feedbackBias})%256`;
    const initialFeedback = u32(seed ^ salt ^ (0x5A + variant * 0x35)) % 256;
    const inverseLiteral = `{${inverse.join(",")}}`;
    return `${base};local S1=string.find(${names.blob},"~",1,true);if not S1 then error("ByteVeil v${version}: deepest codec lanes",0)end;local TAIL=string.sub(${names.blob},S1+1);local S2=string.find(TAIL,"~",1,true);if not S2 then error("ByteVeil v${version}: deepest codec lanes",0)end;local A=${names.b85}(string.sub(${names.blob},1,S1-1));local B=${names.b85}(string.sub(TAIL,1,S2-1));local C=${names.b85}(string.sub(TAIL,S2+1));local T=${inverseLiteral};local O={};local Q=${initial};local F=${initialFeedback};for I=1,${names.length} do local X=(I-1)%3;local J=math.floor((I-1)/3)+1;local C0;if X==0 then C0=A[J];A[J]=nil elseif X==1 then C0=B[J];B[J]=nil else C0=C[J];C[J]=nil end;C0=C0 or 0;local W=T[C0+1]or 0;local K=math.floor(Q/${d.divisor})%256;W=(W-K-F)%256;O[I]=W;${advance};${fstep} end;A=nil;B=nil;C=nil;T=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
  }
  if (codec === 6) {
    const variant = deepVariant(seed, salt);
    const d = DEEP_VARIANTS[variant];
    const sbox = deepSbox(seed, salt, variant);
    const inverse = new Array(256);
    for (let i = 0; i < sbox.length; i++) inverse[sbox[i]] = i;
    const initial = deepInitialState(seed, salt, variant);
    const inverseLiteral = `{${inverse.join(",")}}`;
    let advance;
    if (variant === 0) advance = `Q=(Q*${d.multiplier}+W*${d.feedback}+I*${d.indexFactor}+${d.bias})%2147483647`;
    else if (variant === 1) advance = `Q=((Q+W*${d.feedback}+I*${d.indexFactor}+${d.bias})*${d.multiplier})%2147483647`;
    else advance = `Q=(Q*${d.multiplier}+(W+11)*(I+7)+${d.bias})%2147483647`;
    return `${base};local ${names.sep}=string.find(${names.blob},"~",1,true);if not ${names.sep} then error("ByteVeil v${version}: deepest codec separator",0)end;local ${names.left}=${names.b85}(string.sub(${names.blob},1,${names.sep}-1));local ${names.right}=${names.b85}(string.sub(${names.blob},${names.sep}+1));local ${names.raw}={};for I=1,math.ceil(${names.length}/2) do ${names.raw}[I*2-1]=${names.left}[I]end;for I=1,math.floor(${names.length}/2) do ${names.raw}[I*2]=${names.right}[I]end;${names.left}=nil;${names.right}=nil;local T=${inverseLiteral};local O={};local Q=${initial};for I=1,${names.length} do local C=${names.raw}[I]or 0;local W=(T[C+1]or 0);local K=math.floor(Q/${d.divisor})%256;W=(W-K)%256;O[I]=W;${advance};${names.raw}[I]=nil end;${names.raw}=nil;T=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
  }
  if (codec===0) return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed+salt+0x13D)};for I=1,${names.length} do ${step("R","I")};${names.raw}[I]=${names.x8}(${names.raw}[I]or 0,R%256)end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  if (codec===1) return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed+salt+0x13D+0x101)};for I=1,${names.length} do ${step("R","(I+1)*17")};local V=(${names.raw}[I]or 0)-(R%256);if V<0 then V=V+256 end;${names.raw}[I]=V end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  if (codec===2) return `${base};local ${names.raw}=${names.b85}(${names.blob});local O={};local R=${u32(seed+salt+0x13D+0x202)};for I=1,${names.length} do ${step("R",`I-1+${salt}`)};local V=${names.raw}[${names.length}-I+1]or 0;V=${names.x8}(((V%16)*16+math.floor(V/16)),R%256);O[I]=V;${names.raw}[${names.length}-I+1]=nil end;${names.raw}=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
  if (codec===3) return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed+salt+0x13D+0x303)};local P=0;for I=1,${names.length} do ${step("R","I+P")};local C0=${names.raw}[I]or 0;local V=${names.x8}(${names.x8}(C0,R%256),P);${names.raw}[I]=V;P=C0 end;${names.source}=${names.emit}(${names.raw},${names.length});${names.raw}=nil`;
  if (codec===4) {
    return `${base};local ${names.sep}=string.find(${names.blob},"~",1,true);if not ${names.sep} then error("ByteVeil v4.6.3: nested split",0)end;local ${names.left}=string.sub(${names.blob},1,${names.sep}-1);local ${names.right}=string.sub(${names.blob},${names.sep}+1);local ${names.raw}=${names.b85}(${names.left});local ${names.raw2}=${names.b85}(${names.right});local RA=${u32((seed^0x11)+(salt+1)+0x13D)};local RB=${u32((seed^0x22)+(salt+2)+0x13D+0x101)};local L={};for I=1,math.ceil(${names.length}/2) do ${step("RA","I")};local A=${names.raw}[I]or 0;${names.raw}[I]=nil;L[I*2-1]=${names.x8}(A,RA%256)end;for I=1,math.floor(${names.length}/2) do ${step("RB","(I+1)*17")};local V=(${names.raw2}[I]or 0)-(RB%256);${names.raw2}[I]=nil;if V<0 then V=V+256 end;L[I*2]=V end;${names.raw}=nil;${names.raw2}=nil;${names.left}=nil;${names.right}=nil;${names.source}=${names.emit}(L,${names.length});L=nil`;
  }
  return `${base};local ${names.raw}=${names.b85}(${names.blob});local R=${u32(seed+salt+0x13D+0x505)};local O={};for I=1,${names.length} do ${step("R","I+3+0x55AA")};local V=(${names.raw}[I]or 0)-(R%256);${names.raw}[I]=nil;if V<0 then V=V+256 end;O[${names.length}-I+1]=V end;${names.raw}=nil;${names.source}=${names.emit}(O,${names.length});O=nil`;
}

function makeWrapper(innerSource, { seed, layerIndex, codec, version = "4.5.5", nestedProfile = "balanced", compressPayload = version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.0" || version === "4.7.1" || (version === "4.7.2" || version === "4.7.3" || version === "4.7.4")), compressionMetrics = null }) {
  const fast = version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.0" || version === "4.7.1" || (version === "4.7.2" || version === "4.7.3" || version === "4.7.4"));
  const balanced = (version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.0" || version === "4.7.1" || (version === "4.7.2" || version === "4.7.3" || version === "4.7.4"))) && nestedProfile !== "full";
  const transformProfile = balanced && layerIndex < (version === "4.7.4" ? 1 : (version === "4.7.3" ? 5 : 4)) ? "lite" : "full";
  const salt = u32(seed ^ Math.imul(layerIndex + 1, 0x27D4EB2F));
  const encoded = encodeLayer(innerSource, codec, seed ^ salt, salt, fast, transformProfile, compressPayload === true);
  if (Array.isArray(compressionMetrics)) {
    compressionMetrics.push({
      layerIndex,
      sourceBytes: encoded.sourceLength,
      payloadBytes: encoded.length,
      compressed: encoded.compressed === true,
      compressionMatchLimit: encoded.compressionMatchLimit || 0,
      longOffsetReferences: encoded.longOffsetReferences || 0,
      savedBytes: encoded.compressed === true ? Math.max(0, encoded.sourceLength - encoded.length) : 0
    });
  }
  const deepLayer = ((version === "4.6.7" || version === "4.6.8") && layerIndex === 8 && codec === 6) || ((version === "4.7.0" || version === "4.7.1") && layerIndex === 8 && codec === 7) || ((version === "4.7.2" || version === "4.7.3" || version === "4.7.4") && layerIndex === 8 && codec === 8);
  const expectedHash = deepLayer ? deepHash32(encoded.data) : (fast ? addHash32(encoded.data) : fnv32(encoded.data));
  const token = mix(seed ^ layerIndex, expectedHash ^ salt);
  const names = {
    blob: ident(seed ^ 0x101, layerIndex * 17 + 1),
    source: ident(seed ^ 0x202, layerIndex * 17 + 2),
    loader: ident(seed ^ 0x303, layerIndex * 17 + 3),
    check: ident(seed ^ 0x404, layerIndex * 17 + 4),
    hash: ident(seed ^ 0x505, layerIndex * 17 + 5),
    bxor: ident(seed ^ 0x606, layerIndex * 17 + 6),
    mul: ident(seed ^ 0x707, layerIndex * 17 + 7),
    mix: ident(seed ^ 0x808, layerIndex * 17 + 8),
    toBytes: ident(seed ^ 0x909, layerIndex * 17 + 9),
    b85: ident(seed ^ 0xA0A, layerIndex * 17 + 10),
    emit: ident(seed ^ 0xB0B, layerIndex * 17 + 11),
    raw: ident(seed ^ 0xC0C, layerIndex * 17 + 12),
    raw2: ident(seed ^ 0xC0D, layerIndex * 17 + 12),
    alphabet: ident(seed ^ 0xD0D, layerIndex * 17 + 13),
    map: ident(seed ^ 0xD1D, layerIndex * 17 + 13),
    length: ident(seed ^ 0xE0E, layerIndex * 17 + 14),
    token: ident(seed ^ 0xF0F, layerIndex * 17 + 15),
    left: ident(seed ^ 0x1010, layerIndex * 17 + 16),
    right: ident(seed ^ 0x1111, layerIndex * 17 + 17),
    sep: ident(seed ^ 0x1212, layerIndex * 17 + 18),
    db85: ident(seed ^ 0x1313, layerIndex * 17 + 19),
    nib: ident(seed ^ 0x1414, layerIndex * 17 + 20),
    x8: ident(seed ^ 0x1515, layerIndex * 17 + 21),
    mix46: ident(seed ^ 0x1616, layerIndex * 17 + 22),
    expected: ident(seed ^ 0x1818, layerIndex * 17 + 24),
    alphabetBytes: ident(seed ^ 0x1717, layerIndex * 17 + 23),
    mixLite: ident(seed ^ 0x1919, layerIndex * 17 + 25),
    sourceLength: ident(seed ^ 0x1A1A, layerIndex * 17 + 27),
    decompressor: ident(seed ^ 0x1B1B, layerIndex * 17 + 28)
  };
  const blob = JSON.stringify(encoded.data);

  if (fast) {
    const loaderProvenance = (version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4") && layerIndex === 0
      ? `local __D=__E.debug or debug;local __GI=__D and __D.getinfo;local __NC=(__T(_VERSION)=="string"and __S(_VERSION,1,5)=="Lua 5"and __T(__GI)=="function");local __NATIVE=function(F)if __NC and __T(F)=="function"then local I=__GI(F,"S");if not I or I.what~="C"then error("ByteVeil v4.7.1: loader provenance mismatch",0)end end end;`
      : "";
    const loaderNativeProbe = (version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4") && layerIndex === 0
      ? `if __NC then if __T(__GI)=="function"then __NATIVE(__GI)end;if __T(__L)=="function"then __NATIVE(__L)end;if __T(__LS)=="function"then __NATIVE(__LS)end end;if __NC and (debug~=__D or (__D and __D.getinfo)~=__GI)then error("ByteVeil v4.7.1: inspection API changed",0)end;`
      : "";
    const loaderPreflight = (version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4") && layerIndex === 0 ? `${names.check}();` : "";
    // The v4.6.7/v4.6.8 deepest stage intentionally uses a different representation:
    // inverse substitution table + split lanes + byte feedback. Do not emit the
    // usual visibly reusable XOR-32, multiply-32 and state-mixer helper trio here.
    const primitives = deepLayer ? "" : luaFastPrimitives(names, transformProfile === "lite");
    const hash = deepLayer
      ? `local ${names.hash}=function(S)local H=2166136261;for I=1,#S do H=(H*33+string.byte(S,I)+I*17)%4294967296 end;return H end`
      : `local ${names.hash}=function(S)local H=2166136261;for I=1,#S do H=(${names.mul}(H,16777619)+string.byte(S,I)+1)%4294967296 end;return H%4294967296 end`;
    const code = `return(function()local __E=((getgenv and getgenv())or(getfenv and getfenv(1))or _G);local __T=__E.type or type;local __B=__E.string and __E.string.byte or string.byte;local __S=__E.string and __E.string.sub or string.sub;local __F=__E.string and __E.string.find or string.find;local __C=__E.table and __E.table.concat or table.concat;local __M=__E.math and __E.math.floor or math.floor;local __CH=__E.string and __E.string.char or string.char;local __LS=__E["lo".."ad".."string"]or(getfenv and getfenv(1)["lo".."ad".."string"]);local __L=__E["lo".."ad"]or load or __LS;local __PC=__E.pcall or pcall;${loaderProvenance}local __Q=function(S)local O,F,E=__PC(__L,S);if O and __T(F)=="function"then return F,E end;if __T(__LS)=="function"then return __LS(S)end;return nil,E or F end;local ${names.blob}=${blob};local ${names.length}=${encoded.length};local ${names.expected}=${expectedHash};${primitives};${hash};local ${names.check}=function()if type~=__T or string.byte~=__B or string.sub~=__S or string.find~=__F or table.concat~=__C or math.floor~=__M or string.char~=__CH or(__E.pcall or pcall)~=__PC or(__E["lo".."ad"]or load or __LS)~=__L or (__E["lo".."ad".."string"]or(getfenv and getfenv(1)["lo".."ad".."string"]))~=__LS then error("ByteVeil v${version}: runtime shield",0)end;${loaderNativeProbe}if ${names.hash}(${names.blob})~=${names.expected} then error("ByteVeil v${version}: tamper detected",0)end end;${names.check}();local ${names.source};${decoderBody46(codec,names,seed ^ salt,salt,transformProfile,version)};${encoded.compressed ? `local ${names.sourceLength}=${encoded.sourceLength};local ${names.decompressor}=function(S,L)local O={};local P=1;local N=0;while P<=#S do local F=string.byte(S,P);P=P+1;for B=0,7 do if P>#S then break end;if math.floor(F/2^B)%2==1 then N=N+1;O[N]=string.byte(S,P);P=P+1 else local A=string.byte(S,P)or 0;local C=string.byte(S,P+1)or 0;P=P+2;local V=A+C*256;local D=math.floor(V/16)+1;local Q=V%16+3;if D==4096 then local X=string.byte(S,P)or 0;local Y=string.byte(S,P+1)or 0;D=X+Y*256;P=P+2 end;for J=1,Q do N=N+1;O[N]=O[N-D]end end end end;if N~=L then error("ByteVeil v${version}: nested decompressed length",0)end;local T={};for I=1,N do T[I]=string.char(O[I])end;return table.concat(T)end;${names.source}=${names.decompressor}(${names.source},${names.sourceLength});${names.decompressor}=nil;${names.sourceLength}=nil;` : ""}${loaderPreflight}local ${names.loader},${names.db85}=__Q(${names.source});${names.source}=nil;if not ${names.loader} then error(${names.db85} or "ByteVeil v${version}: nested compile",0)end;${names.check}();${names.blob}=nil;local ${names.raw}={${names.loader}()};${names.loader}=nil;return (table.unpack or unpack)(${names.raw},1,#{${names.raw}})end)()`;
    return code.replace(/v4\.6\.3/g, `v${version}`).replace(/v4\.6\.7/g, `v${version}`).replace(/v4\.6\.8/g, `v${version}`).replace(/v4\.7\.0/g, `v${version}`).replace(/v4\.7\.1/g, `v${version}`).replace(/v4\.7\.2/g, `v${version}`);
  }

  const code = `return(function()local __E=((getgenv and getgenv())or(getfenv and getfenv(1))or _G);local __T=__E.type or type;local __B=__E.string and __E.string.byte or string.byte;local __S=__E.string and __E.string.sub or string.sub;local __F=__E.string and __E.string.find or string.find;local __C=__E.table and __E.table.concat or table.concat;local __M=__E.math and __E.math.floor or math.floor;local __P=__E.pcall or pcall;local __CH=__E.string and __E.string.char or string.char;local __L=__E.load or __E["load".."string"];local ${names.alphabet}=${JSON.stringify(SAFE_BASE85)};local ${names.blob}=${blob};local ${names.length}=${encoded.length};local ${names.token}=${token};${luaUnsignedXor(names)};local ${names.hash}=function(S)local H=2166136261;for I=1,#S do H=${names.mul}(${names.bxor}(H,string.byte(S,I)),16777619)end;return H%4294967296 end;local ${names.check}=function()if type~=__T or string.byte~=__B or string.sub~=__S or string.find~=__F or table.concat~=__C or math.floor~=__M or pcall~=__P or string.char~=__CH or(__E.load or __E["load".."string"])~=__L then error("ByteVeil v4.5.5: runtime shield",0)end;if ${names.hash}(${names.blob})~=${expectedHash} then error("ByteVeil v4.5.5: tamper detected",0)end;if ${names.token}~=${token} then error("ByteVeil v4.5.5: state integrity",0)end end;${names.check}();local ${names.source};${decoderBody(codec,names,seed ^ salt,salt)};local ${names.loader},${names.db85}=__L(${names.source});${names.source}=nil;if not ${names.loader} then error(${names.db85} or "ByteVeil v4.5.5: nested compile",0)end;${names.check}();${names.blob}=nil;local ${names.raw}={${names.loader}()};${names.loader}=nil;${names.alphabet}=nil;${names.length}=nil;${names.token}=nil;return (table.unpack or unpack)(${names.raw},1,#{${names.raw}})end)()`;
  return code.replace(/v4\.5\.5/g, `v${version}`).replace(/v4\.6\.3/g, `v${version}`).replace(/v4\.6\.7/g, `v${version}`).replace(/v4\.6\.8/g, `v${version}`).replace(/v4\.7\.0/g, `v${version}`).replace(/v4\.7\.1/g, `v${version}`).replace(/v4\.7\.2/g, `v${version}`);
}

const DEFAULT_MAX_NESTED_INTERMEDIATE_BYTES = 4_000_000;

function wrapSource(source, { seed, strength = 1000, version = "4.5.5", nestedProfile = "balanced", maxIntermediateBytes = DEFAULT_MAX_NESTED_INTERMEDIATE_BYTES } = {}) {
  const count = layerCount(strength);
  const requestedLimit = Number.isSafeInteger(Number(maxIntermediateBytes)) && Number(maxIntermediateBytes) >= 128_000
    ? Number(maxIntermediateBytes) : DEFAULT_MAX_NESTED_INTERMEDIATE_BYTES;
  // New resource guard applies only to v4.7.3; historical APIs keep their old behavior.
  const resourceLimit = (version === "4.7.3" || version === "4.7.4") ? requestedLimit : Number.POSITIVE_INFINITY;
  let current = String(source);
  let maxObservedIntermediateBytes = Buffer.byteLength(current, "utf8");
  if (maxObservedIntermediateBytes > resourceLimit) {
    throw new RangeError(`ByteVeil v${version}: nested source budget exceeded (${maxObservedIntermediateBytes} > ${resourceLimit} bytes before layer 1)`);
  }
  const codecs = [];
  const compressionMetrics = [];
  for (let layer = count - 1; layer >= 0; layer--) {
    // v4.6.5 gives the deepest/ninth layer a separate codec domain. It uses
    // the split/interleaved codec (4), a domain-separated seed and the full mixer;
    // it remains one of the same nine layers and is measured by runtime tests.
    let codec = codecFor(layer, seed);
    // Keep v4.7.4 byte-size bounded without dropping layers: codec 1 is a full
    // independent transform and gives layer 8 a smaller serializer footprint for
    // the release fixture. Other layers remain seed-selected and heterogeneous.
    if (version === "4.7.4" && layer === 7) codec = 1;
    if (layer === 8 && (version === "4.7.2" || version === "4.7.3" || version === "4.7.4")) codec = 8;
    else if (layer === 8 && (version === "4.7.0" || version === "4.7.1")) codec = 7;
    else if (layer === 8 && (version === "4.6.7" || version === "4.6.8")) codec = 6;
    else if (layer === 8 && (version === "4.6.5" || version === "4.6.6")) codec = 4;
    codecs.unshift(codec);
    const compressPayload = version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.0" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4");
    let layerDomain = 0;
    if (layer === 8 && version === "4.7.2") layerDomain = 0x472DEA0F;
    else if (layer === 8 && version === "4.7.3") layerDomain = 0x473DEA10;
    else if (layer === 8 && version === "4.7.4") layerDomain = 0x474DEA11;
    else if (layer === 8 && version === "4.7.1") layerDomain = 0x369DEA0F;
    else if (layer === 8 && version === "4.7.0") layerDomain = 0xB4709E31;
    else if (layer === 8 && version === "4.6.8") layerDomain = 0xA61F97C4;
    else if (layer === 8 && version === "4.6.7") layerDomain = 0xA61F97C3;
    else if (layer === 8 && (version === "4.6.5" || version === "4.6.6")) layerDomain = 0x9D3A65C7;
    current = makeWrapper(current, { seed: u32(seed ^ Math.imul(layer + 1, 0x9E3779B9) ^ layerDomain), layerIndex: layer, codec, version, nestedProfile, compressPayload, compressionMetrics });
    const currentBytes = Buffer.byteLength(current, "utf8");
    if (currentBytes > resourceLimit) {
      throw new RangeError(`ByteVeil v${version}: nested source budget exceeded (${currentBytes} > ${resourceLimit} bytes at layer ${layer + 1}; no intermediate files were written)`);
    }
    if (currentBytes > maxObservedIntermediateBytes) maxObservedIntermediateBytes = currentBytes;
  }
  return {
    output: current,
    layers: count,
    codecs,
    heterogeneous: new Set(codecs).size > 1,
    compression: {
      enabled: version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.0" || version === "4.7.1" || (version === "4.7.2" || version === "4.7.3" || version === "4.7.4")),
      attemptedLayers: compressionMetrics.length,
      compressedLayers: compressionMetrics.filter((item) => item.compressed).length,
      sourceBytes: compressionMetrics.reduce((sum, item) => sum + item.sourceBytes, 0),
      encodedPayloadBytes: compressionMetrics.reduce((sum, item) => sum + item.payloadBytes, 0),
      bytesSaved: compressionMetrics.reduce((sum, item) => sum + item.savedBytes, 0),
      adaptiveMatchLayers: compressionMetrics.filter((item) => item.compressionMatchLimit > 3).length,
      longOffsetReferences: compressionMetrics.reduce((sum, item) => sum + item.longOffsetReferences, 0),
      perLayer: compressionMetrics
    },
    antiTamperLayers: count,
    antiHookLayers: count,
    antiDumpLayers: count,
    resourceProfile: nestedProfile === "full" ? "full" : "balanced-resource",
    maxObservedIntermediateBytes,
    maxIntermediateBytes: resourceLimit
  };
}

module.exports = { SAFE_BASE85, layerCount, codecFor, wrapSource, DEFAULT_MAX_NESTED_INTERMEDIATE_BYTES, _makeWrapper: makeWrapper, _compressLzss: compressLzss, _deepVariant: deepVariant, _deep47Variant: deep47Variant, _transformBytes47: transformedBytes47, _transformBytes48: transformedBytes48, _deep48Variant: deep48Variant };

"use strict";

/**
 * ByteVeil v4.5.5 Protection IR is a compact, serializable plan used by the
 * protection engines. It deliberately contains no user runtime code.
 */

function buildProtectionIR({ ast = null, ir = null, strength = 1000, mode = "stack", preset = "custom", version = "4.5.5" } = {}) {
  const semantic = ir?.meta || {};
  const profile = Number(strength) >= 10000 ? "lz" : Number(strength) >= 8000 ? "df" : Number(strength) >= 3500 ? "l2" : "l1";
  return {
    version,
    kind: "protection-ir",
    mode: mode === "register" ? "register" : "stack",
    preset: String(preset || "custom"),
    profile,
    strength: Math.max(100, Math.min(10000, Number(strength) || 1000)),
    semanticShape: semantic.fingerprint || null,
    blockCount: semantic.blockCount || 0,
    edgeCount: semantic.edgeCount || 0,
    features: Array.isArray(semantic.featureSet) ? semantic.featureSet.slice() : [],
    astAvailable: !!ast,
    stages: (version === "4.6.1" || version === "4.6.2" || version === "4.6.3" || version === "4.6.4" || (version === "4.6.5" || version === "4.6.6" || version === "4.6.7" || version === "4.6.8" || version === "4.7.1" || version === "4.7.2" || version === "4.7.3" || version === "4.7.4" || version === "4.7.7" || version === "4.7.8")) ? ["fragment-graph", "material-dag", "transport-ir", "representation-morph", "vm-a", "runtime-vm-b", "architecture-family", "semantic-micro-op"] : ["fragment-graph", "material-dag", "transport-ir", "vm-a", "vm-b", "semantic-micro-op"],
    policies: {
      sharedExecutionFabric: true,
    fragmentGraph: true,
    nonLinearDependencies: true,
    materialDependencyGraph: true,
    opaqueTransportIR: true,
    perRegionOpcodeMapping: true,
    runtimeGeneratedDispatch: true,
    semanticMicroOps: true,
      stagedPayload: true,
      polymorphicISA: true,
      antiHook: true,
      antiTamper: true,
      antiDump: true
    }
  };
}

module.exports = { buildProtectionIR };

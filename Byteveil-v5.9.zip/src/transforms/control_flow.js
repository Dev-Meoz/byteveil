"use strict";

function isObject(value) {
    return value !== null && typeof value === "object";
}

function defineHidden(object, key, value) {
    Object.defineProperty(object, key, {
        value,
        enumerable: false,
        configurable: true,
        writable: true
    });
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 1;
    }

    if (seed === undefined || seed === null) {
        return 1;
    }

    const text = String(seed);
    let hash = 0x811C9DC5;

    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 1;
}

function createRandom(seed) {
    let state = normalizeSeed(seed);

    return function random() {
        state = (state + 0x6D2B79F5) >>> 0;

        let value = state;
        value = Math.imul(value ^ (value >>> 15), value | 1);
        value ^= value + Math.imul(
            value ^ (value >>> 7),
            value | 61
        );

        return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
    };
}

function clampRate(value, fallback) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.max(0, Math.min(1, number));
}

/**
 * Find labels/gotos in a statement body.
 *
 * Inversion is skipped when jump structure makes it unsafe to
 * rearrange the conditional branches.
 */
function containsUnsafeJump(body, visited = new WeakSet()) {
    if (!Array.isArray(body)) {
        return false;
    }

    for (const statement of body) {
        if (!isObject(statement) || visited.has(statement)) {
            continue;
        }

        visited.add(statement);

        if (
            statement.type === "Goto" ||
            statement.type === "Label"
        ) {
            return true;
        }

        // Do not cross a function boundary when inspecting jumps.
        if (
            statement.type === "Function" ||
            statement.type === "LocalFunction"
        ) {
            continue;
        }

        switch (statement.type) {
            case "If":
                for (const branch of statement.branches || []) {
                    if (
                        branch &&
                        containsUnsafeJump(branch.body, visited)
                    ) {
                        return true;
                    }
                }

                if (containsUnsafeJump(statement.elseBody, visited)) {
                    return true;
                }
                break;

            case "While":
            case "Repeat":
            case "ForNum":
            case "ForIn":
            case "Do":
                if (containsUnsafeJump(statement.body, visited)) {
                    return true;
                }
                break;
        }
    }

    return false;
}

function invertSimpleIf(statement) {
    if (
        !isObject(statement) ||
        statement.type !== "If" ||
        statement.__bvCffInverted === true ||
        !Array.isArray(statement.branches) ||
        statement.branches.length !== 1 ||
        !Array.isArray(statement.elseBody) ||
        statement.elseBody.length === 0
    ) {
        return false;
    }

    const branch = statement.branches[0];

    if (
        !isObject(branch) ||
        branch.cond == null ||
        !Array.isArray(branch.body)
    ) {
        return false;
    }

    if (
        containsUnsafeJump(branch.body) ||
        containsUnsafeJump(statement.elseBody)
    ) {
        return false;
    }

    const originalBody = branch.body;

    branch.cond = {
        type: "Unary",
        op: "not",
        arg: branch.cond
    };

    branch.body = statement.elseBody;
    statement.elseBody = originalBody;

    defineHidden(statement, "__bvCffInverted", true);

    return true;
}

/**
 * Build true expressions from side-effect-free Boolean literals.
 *
 * These predicates diversify AST shape, but should not be considered
 * a defense against a capable optimizer or deobfuscator.
 */
function opaqueTrue(random) {
    const variant = Math.floor(random() * 9);
    const k = 11 + Math.floor(random() * 480);
    const m = 3 + Math.floor(random() * 13);

    const notFalse = () => ({
        type: "Unary",
        op: "not",
        arg: {
            type: "Boolean",
            value: false
        }
    });

    switch (variant) {
        case 0:
            return notFalse();

        case 1:
            return {
                type: "Binary",
                op: "==",
                left: {
                    type: "Boolean",
                    value: true
                },
                right: notFalse()
            };

        case 2:
            return {
                type: "Binary",
                op: "or",
                left: {
                    type: "Boolean",
                    value: false
                },
                right: notFalse()
            };

        case 3:
            return {
                type: "Binary",
                op: "and",
                left: {
                    type: "Boolean",
                    value: true
                },
                right: notFalse()
            };

        case 4:
            // k * (k + 1) is always even
            return {
                type: "Binary",
                op: "==",
                left: {
                    type: "Binary",
                    op: "%",
                    left: {
                        type: "Binary",
                        op: "*",
                        left: { type: "Number", value: k },
                        right: { type: "Number", value: k + 1 }
                    },
                    right: { type: "Number", value: 2 }
                },
                right: { type: "Number", value: 0 }
            };

        case 5:
            // (k * 2 + 1) % 2 == 1
            return {
                type: "Binary",
                op: "==",
                left: {
                    type: "Binary",
                    op: "%",
                    left: {
                        type: "Binary",
                        op: "+",
                        left: {
                            type: "Binary",
                            op: "*",
                            left: { type: "Number", value: k },
                            right: { type: "Number", value: 2 }
                        },
                        right: { type: "Number", value: 1 }
                    },
                    right: { type: "Number", value: 2 }
                },
                right: { type: "Number", value: 1 }
            };

        case 6:
            // (k % m) < m for positive k, m
            return {
                type: "Binary",
                op: "<",
                left: {
                    type: "Binary",
                    op: "%",
                    left: { type: "Number", value: k },
                    right: { type: "Number", value: m }
                },
                right: { type: "Number", value: m }
            };

        case 7:
            // (k * k + k) % 2 == 0
            return {
                type: "Binary",
                op: "==",
                left: {
                    type: "Binary",
                    op: "%",
                    left: {
                        type: "Binary",
                        op: "+",
                        left: {
                            type: "Binary",
                            op: "*",
                            left: { type: "Number", value: k },
                            right: { type: "Number", value: k }
                        },
                        right: { type: "Number", value: k }
                    },
                    right: { type: "Number", value: 2 }
                },
                right: { type: "Number", value: 0 }
            };

        default:
            return {
                type: "Binary",
                op: "~=",
                left: {
                    type: "Boolean",
                    value: false
                },
                right: {
                    type: "Boolean",
                    value: true
                }
            };
    }
}

function addOpaquePredicate(statement, random = Math.random) {
    if (
        !isObject(statement) ||
        statement.type !== "If" ||
        !Array.isArray(statement.branches) ||
        statement.__bvCffOpaque === true
    ) {
        return 0;
    }

    let added = 0;

    for (const branch of statement.branches) {
        if (
            !isObject(branch) ||
            branch.cond == null ||
            (
                branch.cond.type === "Boolean" &&
                typeof branch.cond.value === "boolean"
            )
        ) {
            continue;
        }

        branch.cond = {
            type: "Binary",
            op: "and",
            left: branch.cond,
            right: opaqueTrue(random)
        };

        added++;
    }

    if (added > 0) {
        defineHidden(statement, "__bvCffOpaque", true);
    }

    return added;
}

function transform(ast, options = {}) {
    if (!isObject(ast)) {
        throw new TypeError(
            "control_flow.transform: expected AST"
        );
    }

    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError(
            "control_flow.transform: options must be an object"
        );
    }

    if (options.enabled === false) {
        return ast;
    }

    const rate = clampRate(options.rate, 0.35);

    const invertRate = clampRate(
        options.invertRate,
        rate
    );

    const strength = Number.isFinite(Number(options.strength))
        ? Math.max(0, Number(options.strength))
        : 0;

    const defaultOpaqueRate = strength >= 3000
        ? rate * 0.65
        : rate * 0.25;

    const opaqueRate = clampRate(
        options.opaqueRate,
        defaultOpaqueRate
    );

    const seed = normalizeSeed(options.seed);
    const random = createRandom(seed);

    const visitedStatements = new WeakSet();
    const visitedExpressions = new WeakSet();

    const stats = {
        enabled: true,
        strategy: "conservative-cff-v2",
        seed,
        rate,
        invertRate,
        opaqueRate,
        statementsVisited: 0,
        ifStatementsVisited: 0,
        branchesInverted: 0,
        opaquePredicatesAdded: 0,
        unsafeInversionsSkipped: 0
    };

    function visitExpression(node) {
        if (!isObject(node) || visitedExpressions.has(node)) {
            return node;
        }

        visitedExpressions.add(node);

        switch (node.type) {
            case "Unary":
                node.arg = visitExpression(node.arg);
                break;

            case "Binary":
                node.left = visitExpression(node.left);
                node.right = visitExpression(node.right);
                break;

            case "Index":
                node.obj = visitExpression(node.obj);
                node.key = visitExpression(node.key);
                break;

            case "Call":
                node.callee = visitExpression(node.callee);
                node.args = (node.args || []).map(visitExpression);
                break;

            case "IfElseExpression":
                node.cond = visitExpression(node.cond);
                node.consequent = visitExpression(node.consequent);
                node.alternate = visitExpression(node.alternate);
                break;

            case "FunctionExpr":
                visitBody(node.body);
                break;

            case "Table":
                node.fields = (node.fields || []).map(field => {
                    if (!isObject(field)) {
                        return field;
                    }

                    return {
                        ...field,
                        key: visitExpression(field.key),
                        value: visitExpression(field.value)
                    };
                });
                break;

            case "Paren":
            case "Group":
                if (node.expression) {
                    node.expression = visitExpression(node.expression);
                } else if (node.expr) {
                    node.expr = visitExpression(node.expr);
                }
                break;
        }

        return node;
    }

    function visitStatement(statement) {
        if (!isObject(statement) || visitedStatements.has(statement)) {
            return statement;
        }

        visitedStatements.add(statement);
        stats.statementsVisited++;

        if (statement.type === "If") {
            stats.ifStatementsVisited++;

            if (
                statement.__bvCffInverted !== true &&
                random() < invertRate
            ) {
                if (invertSimpleIf(statement)) {
                    stats.branchesInverted++;
                } else if (
                    statement.branches &&
                    statement.branches.length === 1 &&
                    statement.elseBody &&
                    statement.elseBody.length > 0
                ) {
                    stats.unsafeInversionsSkipped++;
                }
            }

            if (
                statement.__bvCffOpaque !== true &&
                random() < opaqueRate
            ) {
                stats.opaquePredicatesAdded +=
                    addOpaquePredicate(statement, random);
            }
        }

        switch (statement.type) {
            case "Local":
            case "Assign":
                statement.vars = (statement.vars || []).map(value =>
                    isObject(value)
                        ? visitExpression(value)
                        : value
                );

                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "Compound":
                statement.left = visitExpression(statement.left);
                statement.value = visitExpression(statement.value);
                break;

            case "CallStmt":
                statement.call = visitExpression(statement.call);
                break;

            case "Return":
                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "If":
                statement.branches = (statement.branches || []).map(branch => {
                    if (!isObject(branch)) {
                        return branch;
                    }

                    return {
                        ...branch,
                        cond: visitExpression(branch.cond),
                        body: (branch.body || []).map(visitStatement)
                    };
                });

                statement.elseBody = (statement.elseBody || [])
                    .map(visitStatement);
                break;

            case "While":
            case "Repeat":
                statement.cond = visitExpression(statement.cond);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForNum":
                statement.start = visitExpression(statement.start);
                statement.end = visitExpression(statement.end);
                statement.step = visitExpression(statement.step);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForIn":
                statement.it = (statement.it || [])
                    .map(visitExpression);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "Do":
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "LocalFunction":
            case "Function":
                if (statement.fn) {
                    visitExpression(statement.fn);
                } else {
                    visitBody(statement.body);
                }
                break;
        }

        if (
            statement.fn &&
            statement.type !== "LocalFunction" &&
            statement.type !== "Function"
        ) {
            visitExpression(statement.fn);
        }

        return statement;
    }

    function visitBody(body) {
        if (!Array.isArray(body)) {
            return;
        }

        for (let i = 0; i < body.length; i++) {
            body[i] = visitStatement(body[i]);
        }
    }

    visitBody(ast.body);

    defineHidden(ast, "__cff", Object.freeze(stats));

    return ast;
}

module.exports = {
    transform,
    invertSimpleIf,
    addOpaquePredicate
};
"use strict";

function isObject(value) {
    return value !== null && typeof value === "object";
}

function defineHidden(object, key, value) {
    Object.defineProperty(object, key, {
        value,
        enumerable: false,
        configurable: true,
        writable: true
    });
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 1;
    }

    if (seed === undefined || seed === null) {
        return 1;
    }

    const text = String(seed);
    let hash = 0x811C9DC5;

    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 1;
}

function createRandom(seed) {
    let state = normalizeSeed(seed);

    return function random() {
        state = (state + 0x6D2B79F5) >>> 0;

        let value = state;
        value = Math.imul(value ^ (value >>> 15), value | 1);
        value ^= value + Math.imul(
            value ^ (value >>> 7),
            value | 61
        );

        return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
    };
}

function clampRate(value, fallback) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.max(0, Math.min(1, number));
}

function clampDepth(value, fallback) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.max(0, Math.min(8, Math.trunc(number)));
}

function transform(ast, options = {}) {
    if (!isObject(ast)) {
        throw new TypeError(
            "function_transform.transform: expected AST"
        );
    }

    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError(
            "function_transform.transform: options must be an object"
        );
    }

    if (options.enabled === false) {
        return ast;
    }

    const strength = Number.isFinite(Number(options.strength))
        ? Math.max(0, Number(options.strength))
        : 0;

    const defaultDepth =
        strength >= 9000 ? 5 :
        strength >= 7000 ? 4 :
        strength >= 3000 ? 2 :
        1;

    const requestedDepth = clampDepth(
        options.depth,
        defaultDepth
    );

    const functionRate = clampRate(
        options.functionRate,
        1
    );

    const seed = normalizeSeed(options.seed);
    const random = createRandom(seed);
    const varyDepth = options.varyDepth === true;

    const visitedStatements = new WeakSet();
    const visitedExpressions = new WeakSet();
    const visitedFunctions = new WeakSet();

    const stats = {
        enabled: true,
        strategy: "function-scope-nesting-v2",
        seed,
        requestedDepth,
        functionRate,
        varyDepth,

        functionsSeen: 0,
        functionsSelected: 0,
        functionsTransformed: 0,
        wrappersAdded: 0,
        functionsAlreadyDeepEnough: 0
    };

    function targetDepth() {
        if (!varyDepth || requestedDepth <= 1) {
            return requestedDepth;
        }

        return 1 + Math.floor(
            random() * requestedDepth
        );
    }

    function decorate(fn) {
        if (
            !isObject(fn) ||
            !Array.isArray(fn.body) ||
            visitedFunctions.has(fn)
        ) {
            return;
        }

        visitedFunctions.add(fn);
        stats.functionsSeen++;

        if (random() >= functionRate) {
            walkBody(fn.body);
            return;
        }

        stats.functionsSelected++;

        const previousDepth = Number(
            fn.__byteVeilFunctionDepth
        ) || 0;

        const desiredDepth = Math.max(
            previousDepth,
            targetDepth()
        );

        if (desiredDepth <= previousDepth) {
            stats.functionsAlreadyDeepEnough++;
            walkBody(fn.body);
            return;
        }

        const added = desiredDepth - previousDepth;

        for (let i = 0; i < added; i++) {
            fn.body = [{
                type: "Do",
                body: fn.body
            }];
        }

        defineHidden(
            fn,
            "__byteVeilFunctionDepth",
            desiredDepth
        );

        stats.functionsTransformed++;
        stats.wrappersAdded += added;

        // Walk the new block too, so nested functions remain discoverable.
        walkBody(fn.body);
    }

    function visitExpression(node) {
        if (!isObject(node) || visitedExpressions.has(node)) {
            return node;
        }

        visitedExpressions.add(node);

        switch (node.type) {
            case "FunctionExpr":
                decorate(node);
                return node;

            case "Unary":
                node.arg = visitExpression(node.arg);
                break;

            case "Binary":
                node.left = visitExpression(node.left);
                node.right = visitExpression(node.right);
                break;

            case "Index":
                node.obj = visitExpression(node.obj);
                node.key = visitExpression(node.key);
                break;

            case "Call":
                node.callee = visitExpression(node.callee);
                node.args = (node.args || []).map(visitExpression);
                break;

            case "IfElseExpression":
                node.cond = visitExpression(node.cond);
                node.consequent = visitExpression(node.consequent);
                node.alternate = visitExpression(node.alternate);
                break;

            case "Table":
                node.fields = (node.fields || []).map(field => {
                    if (!isObject(field)) {
                        return field;
                    }

                    return {
                        ...field,
                        key: visitExpression(field.key),
                        value: visitExpression(field.value)
                    };
                });
                break;

            case "Paren":
            case "Group":
                if (node.expression) {
                    node.expression = visitExpression(node.expression);
                } else if (node.expr) {
                    node.expr = visitExpression(node.expr);
                }
                break;
        }

        return node;
    }

    function visitStatement(statement) {
        if (!isObject(statement) || visitedStatements.has(statement)) {
            return statement;
        }

        visitedStatements.add(statement);

        if (statement.type === "Function") {
            decorate(statement.fn || statement);
            return statement;
        }

        if (statement.type === "LocalFunction") {
            decorate(statement.fn || statement);
            return statement;
        }

        if (statement.fn) {
            decorate(statement.fn);
        }

        switch (statement.type) {
            case "Local":
            case "Assign":
                statement.vars = (statement.vars || []).map(value =>
                    isObject(value)
                        ? visitExpression(value)
                        : value
                );

                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "Compound":
                statement.left = visitExpression(statement.left);
                statement.value = visitExpression(statement.value);
                break;

            case "CallStmt":
                statement.call = visitExpression(statement.call);
                break;

            case "Return":
                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "If":
                statement.branches = (statement.branches || []).map(branch => {
                    if (!isObject(branch)) {
                        return branch;
                    }

                    return {
                        ...branch,
                        cond: visitExpression(branch.cond),
                        body: (branch.body || []).map(visitStatement)
                    };
                });

                statement.elseBody = (statement.elseBody || [])
                    .map(visitStatement);
                break;

            case "While":
            case "Repeat":
                statement.cond = visitExpression(statement.cond);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForNum":
                statement.start = visitExpression(statement.start);
                statement.end = visitExpression(statement.end);
                statement.step = visitExpression(statement.step);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForIn":
                statement.it = (statement.it || [])
                    .map(visitExpression);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "Do":
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;
        }

        return statement;
    }

    function walkBody(body) {
        if (!Array.isArray(body)) {
            return;
        }

        for (let i = 0; i < body.length; i++) {
            body[i] = visitStatement(body[i]);
        }
    }

    if (options.wrapChunk === true && requestedDepth > 0) {
        // Explicit opt-in only: this changes top-level local scope.
        // The default deliberately leaves chunk-level bindings untouched.
        for (let i = 0; i < requestedDepth; i++) {
            ast.body = [{
                type: "Do",
                body: ast.body || []
            }];
        }

        stats.chunkWrappersAdded = requestedDepth;
    } else {
        stats.chunkWrappersAdded = 0;
    }

    walkBody(ast.body);

    defineHidden(
        ast,
        "__functionTransform",
        Object.freeze(stats)
    );

    return ast;
}

module.exports = {
    transform
};
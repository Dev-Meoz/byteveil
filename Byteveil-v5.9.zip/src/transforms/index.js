"use strict";

const { ENGINE_VERSION } = require("../core/version");
const { mangle } = require("../mangler");
const metamethodAlias = require("../metamethod-alias");
const stringObfuscator = require("./string_obfuscator");
const numberObfuscator = require("./number_obfuscator");
const controlFlow = require("./control_flow");
const functionTransform = require("./function_transform");
const watermarkModule = require("./watermark");
const macros = require("../macros");
const lph = require("../lph");
const micro = require("../protection/byteveil_micro");

function apply(ast, options = {}) {
    const macroPlan = options.source ? macros.resolve(options.source, ast, options.macros || {}) : null;
    const lphPlan = options.source ? lph.resolve(options.source, ast, options.lph || {}) : null;
    const seed = Number(options.seed ?? Date.now()) >>> 0;

    if (macroPlan?.errors?.length) throw new Error(`ByteVeil Macro: ${macroPlan.errors.join("; ")}`);
    if (lphPlan?.errors?.length) throw new Error(`ByteVeil LPH: ${lphPlan.errors.join("; ")}`);

    // Macro and LPH are independent engines. They execute their own scoped
    // handlers before the preset-wide transforms instead of merely recording
    // directive counts in ByteVeil-Micro metadata.
    if (macroPlan) macros.apply(ast, macroPlan, { ...options, seed });
    if (lphPlan) lph.apply(ast, lphPlan, { ...options, seed });

    // Alias explicit metamethod keys before string splitting and identifier
    // mangling. The runtime key remains the original canonical string.
    if (options.metamethodAlias !== false) {
        const cfg = typeof options.metamethodAlias === "object" ? options.metamethodAlias : {};
        metamethodAlias.transform(ast, { ...cfg, seed });
    }

    if (options.strings && options.vmOnly !== true) {
        const cfg = typeof options.strings === "object" ? options.strings : { enabled: true };
        stringObfuscator.transform(ast, { ...cfg, seed });
    }

    if (options.numbers && options.vmOnly !== true) {
        const cfg = typeof options.numbers === "object" ? options.numbers : { enabled: true };
        numberObfuscator.transform(ast, { ...cfg, seed });
    }

    if (options.controlFlow) {
        const cfg = typeof options.controlFlow === "object" ? options.controlFlow : { enabled: true };
        controlFlow.transform(ast, { ...cfg, seed });
    }

    if (options.functionTransform) {
        const cfg = typeof options.functionTransform === "object" ? options.functionTransform : { enabled: true };
        functionTransform.transform(ast, { ...cfg, seed });
    }

    if (options.rename !== false) mangle(ast, seed);

    if (options.watermark) {
        const cfg = typeof options.watermark === "object" ? options.watermark : { text: options.watermark };
        watermarkModule.transformAST(ast, cfg);
    }

    const microPlan = {
        version: options.version || ENGINE_VERSION,
        engine: "ByteVeil-Micro",
        macro: macroPlan,
        lph: lphPlan,
        effects: micro.mergeEffects(macroPlan || {}, lphPlan || {})
    };

    Object.defineProperty(ast, "__microPlan", {
        value: microPlan,
        enumerable: false,
        configurable: true,
        writable: true
    });

    return ast;
}

function buildProtectionPlan(ast, options = {}) {
    const seed = Number(options.seed ?? 1) >>> 0;
    const enabled = (name, fallback = true) =>
        options[name] === undefined ? fallback : options[name] !== false;

    return {
        version: options.version || ENGINE_VERSION,
        seed,

        // Keep `transforms` as requested/configured options for API compatibility.
        // `transformEffects` is the authoritative record of transformations actually applied.
        transforms: {
            strings: enabled("strings"),
            numbers: enabled("numbers"),
            controlFlow: enabled("controlFlow"),
            functionTransform: enabled("functionTransform"),
            rename: options.rename !== false,
            metamethodAlias: options.metamethodAlias !== false,
            watermark: !!options.watermark,
            macros: !!ast?.__byteVeilMacros,
            lph: !!ast?.__byteVeilLPH
        },

        strength: Math.max(100, Math.min(10000, Number(options.strength ?? 1000) || 1000)),

        transformEffects: {
            strings: {
                requested: enabled("strings", false),
                applied: !!ast?.__strings
            },
            numbers: {
                requested: enabled("numbers", false),
                applied: ast?.__numbers?.applied === true,
                strategy: ast?.__numbers?.strategy || "not-requested",
                note: ast?.__numbers?.note || null
            },
            controlFlow: {
                requested: enabled("controlFlow", false),
                applied: !!ast?.__cff
            },
            functionTransform: {
                requested: enabled("functionTransform", false),
                applied: !!ast?.__functionTransform
            },
            metamethodAlias: {
                requested: enabled("metamethodAlias"),
                applied: ast?.__metamethodPlan?.rewritesApplied === true,
                rewrites: ast?.__metamethodPlan?.rewrites || null
            }
        },

        astMarkers: {
            strings: !!ast?.__strings,
            numbers: !!ast?.__numbers,
            controlFlow: !!ast?.__cff,
            functionTransform: !!ast?.__functionTransform,
            metamethodAlias: !!ast?.__metamethodPlan,
            watermark: !!ast?.__watermark,
            macroDirectives: ast?.__byteVeilMacros?.directives?.length || 0,
            lphDirectives: ast?.__byteVeilLPH?.directives?.length || 0
        }
    };
}

module.exports = {
    apply,
    micro,
    macros,
    lph,
    watermark: watermarkModule,
    strings: stringObfuscator,
    numbers: numberObfuscator,
    controlFlow,
    functionTransform,
    buildProtectionPlan
};
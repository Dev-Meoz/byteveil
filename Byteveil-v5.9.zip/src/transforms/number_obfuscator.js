"use strict";

function isObject(value) {
    return value !== null && typeof value === "object";
}

/**
 * Audit-safe numeric transform contract.
 *
 * The former pass attached XOR-encoded IEEE-754 metadata to AST nodes, but
 * neither compiler nor the binary serializer consumed that annotation. It
 * therefore did not alter runtime code and must not be reported as applied.
 * v5.0.0 deliberately preserves numeric semantics; numeric operands are
 * carried inside the encoded binary VM payload instead of claiming a separate
 * per-literal encoding that does not exist.
 */
function transform(ast, options = {}) {
    if (!isObject(ast) || Array.isArray(ast)) {
        throw new TypeError("number_obfuscator.transform: expected AST");
    }
    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError("number_obfuscator.transform: options must be an object");
    }
    if (options.enabled === false) return ast;

    const seen = new WeakSet();
    const stats = {
        enabled: true,
        requested: true,
        applied: false,
        mode: "preserve",
        strategy: "literal-preserve-vm-encoded",
        seed: Number(options.seed) >>> 0,
        numbersSeen: 0,
        numbersAnnotated: 0,
        numbersSkipped: 0,
        metadataPrepared: false,
        serializerContract: null,
        requiresSerializerSupport: false,
        note: "Numeric literals are not rewritten by this pass because __bvNumberEncoding is not consumed by the compiler/serializer. Numeric operands remain carried inside the binary VM payload path."
    };

    function visit(node) {
        if (!isObject(node) || seen.has(node)) return;
        seen.add(node);

        if (node.type === "Number" || node.type === "NumberLiteral" || node.type === "NumericLiteral") {
            stats.numbersSeen++;
            stats.numbersSkipped++;
            if (Object.prototype.hasOwnProperty.call(node, "__bvNumberEncoding")) {
                try { delete node.__bvNumberEncoding; } catch { /* non-configurable legacy annotation */ }
            }
        }

        for (const [key, value] of Object.entries(node)) {
            if (key.startsWith("__")) continue;
            if (Array.isArray(value)) {
                for (const child of value) visit(child);
            } else if (isObject(value)) {
                visit(value);
            }
        }
    }

    visit(ast);
    Object.defineProperty(ast, "__numbers", {
        value: Object.freeze(stats),
        enumerable: false,
        configurable: true,
        writable: true
    });
    return ast;
}

module.exports = { transform };

"use strict";

function isObject(value) {
    return value !== null && typeof value === "object";
}

function defineHidden(object, key, value) {
    Object.defineProperty(object, key, {
        value,
        enumerable: false,
        configurable: true,
        writable: true
    });
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) {
        return (seed >>> 0) || 1;
    }

    if (seed === undefined || seed === null) {
        return 1;
    }

    const text = String(seed);
    let hash = 0x811C9DC5;

    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    return hash || 1;
}

function createRandom(seed) {
    let state = normalizeSeed(seed);

    return function random() {
        state = (state + 0x6D2B79F5) >>> 0;

        let value = state;
        value = Math.imul(
            value ^ (value >>> 15),
            value | 1
        );

        value ^= value + Math.imul(
            value ^ (value >>> 7),
            value | 61
        );

        return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
    };
}

function clampRate(value, fallback) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.max(0, Math.min(1, number));
}

function clampInteger(value, fallback, minimum, maximum) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.max(
        minimum,
        Math.min(maximum, Math.trunc(number))
    );
}

function copyLocation(from, to) {
    for (const key of [
        "line",
        "column",
        "loc",
        "range",
        "start",
        "end",
        "source"
    ]) {
        if (from[key] !== undefined) {
            to[key] = from[key];
        }
    }

    return to;
}

function makeStringNode(type, value) {
    return {
        type,
        value
    };
}

function buildConcatenation(parts, random) {
    if (parts.length === 1) {
        return parts[0];
    }

    // Randomized tree shape changes how the concatenation is grouped.
    // All leaves remain ordered, so the final string is unchanged.
    const split = 1 + Math.floor(random() * (parts.length - 1));

    return {
        type: "Binary",
        op: "..",
        left: buildConcatenation(parts.slice(0, split), random),
        right: buildConcatenation(parts.slice(split), random)
    };
}

function transform(ast, options = {}) {
    if (!isObject(ast)) {
        throw new TypeError(
            "string_obfuscator.transform: expected AST"
        );
    }

    if (!isObject(options) || Array.isArray(options)) {
        throw new TypeError(
            "string_obfuscator.transform: options must be an object"
        );
    }

    if (options.enabled === false) {
        return ast;
    }

    const rate = clampRate(options.rate, 0.35);
    const strength = Math.max(
        0,
        Number.isFinite(Number(options.strength))
            ? Number(options.strength)
            : 0
    );

    const seed = normalizeSeed(options.seed);
    const random = createRandom(seed);

    const minLength = clampInteger(
        options.minLength,
        6,
        1,
        100000
    );

    const strengthParts =
        strength >= 9000 ? 6 :
        strength >= 7000 ? 5 :
        strength >= 5000 ? 4 :
        strength >= 3000 ? 3 :
        2;

    const maxParts = clampInteger(
        options.maxParts,
        strengthParts,
        2,
        16
    );

    const stats = {
        enabled: true,
        strategy: "unicode-fragment-tree-v2",
        seed,
        rate,
        strength,
        minLength,
        maxParts,
        stringsSeen: 0,
        stringsSplit: 0,
        fragmentsCreated: 0,
        codePointsProtected: 0
    };

    const visited = new WeakSet();

    function splitString(node) {
        if (
            !node ||
            typeof node.value !== "string" ||
            node.__bvStringSplitRoot === true
        ) {
            return node;
        }

        stats.stringsSeen++;

        if (hasOwn(node, "__bvStringAlreadySplit")) {
            return node;
        }

        const value = node.value;
        const chars = Array.from(value);

        if (
            chars.length < minLength ||
            chars.length < 2 ||
            random() >= rate
        ) {
            return node;
        }

        const partCount = Math.min(
            chars.length,
            2 + Math.floor(random() * (maxParts - 1))
        );

        if (partCount < 2) {
            return node;
        }

        const cuts = new Set([0, chars.length]);
        const maxAttempts = chars.length * 8;

        let attempts = 0;

        while (
            cuts.size < partCount + 1 &&
            attempts < maxAttempts
        ) {
            const point =
                1 + Math.floor(random() * (chars.length - 1));

            cuts.add(point);
            attempts++;
        }

        // Deterministic fallback guarantees finite completion.
        for (
            let point = 1;
            cuts.size < partCount + 1 && point < chars.length;
            point++
        ) {
            cuts.add(point);
        }

        const boundaries = [...cuts].sort((a, b) => a - b);
        const type = node.type;
        const leaves = [];

        for (let i = 0; i < boundaries.length - 1; i++) {
            const chunk = chars
                .slice(boundaries[i], boundaries[i + 1])
                .join("");

            if (chunk.length === 0) {
                continue;
            }

            leaves.push(makeStringNode(type, chunk));
        }

        if (leaves.length < 2) {
            return node;
        }

        const root = buildConcatenation(leaves, random);

        copyLocation(node, root);

        defineHidden(root, "__bvStringSplitRoot", true);
        defineHidden(node, "__bvStringAlreadySplit", true);

        stats.stringsSplit++;
        stats.fragmentsCreated += leaves.length;
        stats.codePointsProtected += chars.length;

        return root;
    }

    function visitExpression(node) {
        if (!isObject(node) || visited.has(node)) {
            return node;
        }

        visited.add(node);

        switch (node.type) {
            case "String":
            case "StringLiteral":
                return splitString(node);

            case "Unary":
                node.arg = visitExpression(node.arg);
                break;

            case "Binary":
                node.left = visitExpression(node.left);
                node.right = visitExpression(node.right);
                break;

            case "Index":
                node.obj = visitExpression(node.obj);
                node.key = visitExpression(node.key);
                break;

            case "Call":
                node.callee = visitExpression(node.callee);
                node.args = (node.args || []).map(visitExpression);
                break;

            case "IfElseExpression":
                node.cond = visitExpression(node.cond);
                node.consequent = visitExpression(node.consequent);
                node.alternate = visitExpression(node.alternate);
                break;

            case "FunctionExpr":
                visitBody(node.body);
                break;

            case "Table":
                node.fields = (node.fields || []).map(field => {
                    if (!isObject(field)) {
                        return field;
                    }

                    return {
                        ...field,
                        key: visitExpression(field.key),
                        value: visitExpression(field.value)
                    };
                });
                break;

            case "Paren":
            case "Group":
                if (node.expression) {
                    node.expression = visitExpression(node.expression);
                } else if (node.expr) {
                    node.expr = visitExpression(node.expr);
                }
                break;
        }

        return node;
    }

    function visitStatement(statement) {
        if (!isObject(statement) || visited.has(statement)) {
            return statement;
        }

        visited.add(statement);

        switch (statement.type) {
            case "Local":
            case "Assign":
                statement.vars = (statement.vars || []).map(value =>
                    isObject(value)
                        ? visitExpression(value)
                        : value
                );

                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "Compound":
                statement.left = visitExpression(statement.left);
                statement.value = visitExpression(statement.value);
                break;

            case "CallStmt":
                statement.call = visitExpression(statement.call);
                break;

            case "Return":
                statement.values = (statement.values || [])
                    .map(visitExpression);
                break;

            case "If":
                statement.branches = (statement.branches || []).map(branch => {
                    if (!isObject(branch)) {
                        return branch;
                    }

                    return {
                        ...branch,
                        cond: visitExpression(branch.cond),
                        body: (branch.body || []).map(visitStatement)
                    };
                });

                statement.elseBody = (statement.elseBody || [])
                    .map(visitStatement);
                break;

            case "While":
            case "Repeat":
                statement.cond = visitExpression(statement.cond);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForNum":
                statement.start = visitExpression(statement.start);
                statement.end = visitExpression(statement.end);
                statement.step = visitExpression(statement.step);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "ForIn":
                statement.it = (statement.it || [])
                    .map(visitExpression);
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "Do":
                statement.body = (statement.body || [])
                    .map(visitStatement);
                break;

            case "LocalFunction":
            case "Function":
                if (statement.fn) {
                    visitExpression(statement.fn);
                } else {
                    visitBody(statement.body);
                }
                break;
        }

        if (
            statement.fn &&
            statement.type !== "LocalFunction" &&
            statement.type !== "Function"
        ) {
            visitExpression(statement.fn);
        }

        return statement;
    }

    function visitBody(body) {
        if (!Array.isArray(body)) {
            return;
        }

        for (let i = 0; i < body.length; i++) {
            body[i] = visitStatement(body[i]);
        }
    }

    visitBody(ast.body);

    defineHidden(ast, "__strings", Object.freeze(stats));

    return ast;
}

function hasOwn(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
}

/**
 * Compatibility facade.
 * This intentionally does not claim that the string is encrypted.
 */
function encodeString(value) {
    return {
        type: "String",
        value: String(value),
        __luaEncoded: false
    };
}

module.exports = {
    transform,
    encodeString
};
"use strict";

const DEFAULT_WATERMARK = "This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]";

function createWatermark(options = {}) {
    if (options.enabled === false) return "";
    const text = String(options.text || options.watermark || DEFAULT_WATERMARK)
        .replace(/\r/g, "")
        .replace(/\n/g, " ")
        .trim();
    return `--${text}`;
}

function prependWatermark(source, options = {}) {
    if (typeof source !== "string") {
        throw new TypeError("watermark.prependWatermark: source must be a string");
    }
    const watermark = createWatermark(options);
    if (!watermark) return source.replace(/^\uFEFF/, "");
    const body = source.replace(/^\uFEFF/, "");
    if (body.startsWith(`${watermark}\n`)) return body;
    return `${watermark}\n${body}`;
}

function transformAST(ast, options = {}) {
    if (!ast || typeof ast !== "object") {
        throw new TypeError("watermark.transformAST: ast must be an object");
    }
    Object.defineProperty(ast, "__watermark", {
        value: createWatermark(options),
        enumerable: false,
        configurable: true,
        writable: true
    });
    return ast;
}

function removeWatermark(source, options = {}) {
    if (typeof source !== "string") throw new TypeError("source must be a string");
    const wm = createWatermark(options);
    return source.startsWith(`${wm}\n`) ? source.slice(wm.length + 1) : source;
}

function hasWatermark(source, options = {}) {
    const wm = createWatermark(options);
    return typeof source === "string" && source.startsWith(`${wm}\n`);
}

module.exports = {
    DEFAULT_WATERMARK,
    createWatermark,
    prependWatermark,
    transformAST,
    removeWatermark,
    hasWatermark,
    apply: prependWatermark
};

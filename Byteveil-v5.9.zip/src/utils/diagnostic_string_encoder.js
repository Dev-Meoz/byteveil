"use strict";

const { renderDiagnosticRuntime, collectUsedNames, lehmerSeed } = require("../obfuscation/veil_blob");

// Hide only diagnostic literals emitted by ByteVeil's generated runtime. This is
// reversible presentation-level encoding, not cryptographic encryption. The
// lexical scanner deliberately skips comments and long-bracket strings so it
// cannot mutate source comments or table/string contents accidentally.
const DIAGNOSTIC_TEXT = /\bByte[Vv]eil\b|\bDetected hook\b|\bRuntime error\b|\binstruction representation\b|\benvironment unavailable\b|\bopcode compatibility guard failed\b|\bruntime shield\b|\bruntime integrity check failed\b|\bruntime guard unavailable\b|\btamper detected\b|\bstate integrity\b|\bbootstrap state\b|\bempty region semantic set\b|\bregion matrix miss\b|\bopcode mismatch\b|\bdeepest codec\b|\bnested (?:alphabet|split|compile|decompressed length)\b|\bloader provenance mismatch\b|\binspection API changed\b|\bpayload carrier alphabet\b|\bpayload lane\b|\bpayload integrity record\b|\bpayload carrier missing\b|\bdescriptor carrier missing\b|\bpayload address(?: bounds)?\b|\bpayload alphabet\b|\bpayload integrity(?: record)?\b|\bdescriptor (?:header|truncated|array bound|region bound|directory bound|cardinality|varint overflow|carrier missing)\b|\bregion (?:integrity|length|missing|opcode route|reader|byte address|graph gap)\b|\bgraph (?:cycle|version)\b|\bSUPER dispatch failed\b|\bruntime bridge unavailable\b|\bstate machine miss\b|\bdependency state\b|\bconstant state\b|\bconstant tag\b|\bparameter state\b|\btruncated IR\b|\binvalid region\b|\bcontinuation miss\b|\bsplit lane miss\b|\bbucket route miss\b|\bdirected hop miss\b|\bcorrupt (?:shard|chunk|stream)\b|\bObfuscated source crash - runtime tamper detect\b/i;

function longBracketAt(source, index) {
  const match = /^\[(=*)\[/.exec(source.slice(index));
  return match ? { openLength: match[0].length, close: `]${match[1]}]` } : null;
}

function skipLong(source, index, info) {
  const end = source.indexOf(info.close, index + info.openLength);
  return end < 0 ? source.length : end + info.close.length;
}

function readQuotedEnd(source, start, quote) {
  let i = start + 1;
  while (i < source.length) {
    const ch = source[i];
    if (ch === "\\") {
      i++;
      if (i < source.length && source[i] === "\r" && source[i + 1] === "\n") i += 2;
      else if (i < source.length) i++;
      continue;
    }
    if (ch === quote) return i + 1;
    i++;
  }
  return -1;
}

function decodeLuaQuoted(raw) {
  const quote = raw[0];
  let out = "";
  for (let i = 1; i < raw.length - 1; i++) {
    const ch = raw[i];
    if (ch !== "\\") { out += ch; continue; }
    const n = raw[++i];
    if (n === undefined) break;
    const simple = { a: "\x07", b: "\b", f: "\f", n: "\n", r: "\r", t: "\t", v: "\v", "\\": "\\", '"': '"', "'": "'" };
    if (Object.prototype.hasOwnProperty.call(simple, n)) { out += simple[n]; continue; }
    if (n === "\n") continue;
    if (n === "\r") { if (raw[i + 1] === "\n") i++; continue; }
    if (n === "z") { while (i + 1 < raw.length - 1 && /\s/.test(raw[i + 1])) i++; continue; }
    if (n === "x" && /^[0-9a-f]{2}$/i.test(raw.slice(i + 1, i + 3))) {
      out += String.fromCharCode(parseInt(raw.slice(i + 1, i + 3), 16)); i += 2; continue;
    }
    if (n === "u" && raw[i + 1] === "{") {
      const end = raw.indexOf("}", i + 2);
      if (end >= 0) {
        const cp = Number.parseInt(raw.slice(i + 2, end), 16);
        if (Number.isFinite(cp) && cp <= 0x10ffff) out += String.fromCodePoint(cp);
        i = end; continue;
      }
    }
    if (/^[0-9]$/.test(n)) {
      let digits = n;
      while (digits.length < 3 && /^[0-9]$/.test(raw[i + 1] || "")) digits += raw[++i];
      out += String.fromCharCode(Number(digits) & 0xff); continue;
    }
    // Keep the effective character for unknown escapes, matching Lua's common
    // behavior for generated diagnostic literals without invoking a parser.
    out += n;
  }
  return out;
}

function toFaultToken(value) {
  let h1 = 0x811C9DC5 >>> 0;
  let h2 = 0x9E3779B9 >>> 0;
  const text = String(value || "");
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i) & 0xff;
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ ((c + i) & 0xff), 0x85EBCA6B) >>> 0;
  }
  return ((h1 ^ (h2 >>> 11)) >>> 0).toString(36).slice(0, 5).padStart(4, "x");
}

function toDecimalEscapedLuaString(value, compact = false) {
  const raw = compact ? toFaultToken(value) : String(value);
  const bytes = Buffer.from(raw, "utf8");
  return `"${Array.from(bytes, (byte) => `\\${String(byte).padStart(3, "0")}`).join("")}"`;
}

function maskNonCode(source) {
  const chars = source.split("");
  const blank = (start, end) => {
    for (let j = start; j < end; j++) if (chars[j] !== "\n" && chars[j] !== "\r") chars[j] = " ";
  };
  let i = 0;
  while (i < source.length) {
    if (source[i] === "-" && source[i + 1] === "-") {
      const long = longBracketAt(source, i + 2);
      let end;
      if (long) end = skipLong(source, i + 2, long);
      else { const nl = source.indexOf("\n", i); end = nl < 0 ? source.length : nl; }
      blank(i, end); i = end; continue;
    }
    if (source[i] === "[") {
      const long = longBracketAt(source, i);
      if (long) { const end = skipLong(source, i, long); blank(i, end); i = end; continue; }
    }
    if (source[i] === "'" || source[i] === '"' || source[i] === "`") {
      const end = readQuotedEnd(source, i, source[i]);
      if (end > i) { blank(i, end); i = end; continue; }
    }
    i++;
  }
  return chars.join("");
}

function findLocalErrorAliases(source) {
  const masked = maskNonCode(source);
  const matches = /\blocal\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*error\b/g;
  const list = [];
  let match;
  while ((match = matches.exec(masked))) {
    list.push({ index: match.index, name: match[1] });
  }
  return list;
}

function scanDiagnostics(source) {
  const literals = [];
  const aliasRenames = [];
  const errorAliases = findLocalErrorAliases(source);
  const hasErrorAlias = errorAliases.length > 0;
  const resolveErrorAliasAt = (pos) => {
    if (!errorAliases.length) return null;
    let active = errorAliases[0].name;
    for (const item of errorAliases) {
      if (item.index <= pos) active = item.name;
      else break;
    }
    return active;
  };

  let i = 0;
  while (i < source.length) {
    if (source[i] === "-" && source[i + 1] === "-") {
      const long = longBracketAt(source, i + 2);
      i = long ? skipLong(source, i + 2, long) : (source.indexOf("\n", i) < 0 ? source.length : source.indexOf("\n", i));
      continue;
    }
    if (source[i] === "[") {
      const long = longBracketAt(source, i);
      if (long) { i = skipLong(source, i, long); continue; }
    }
    const ch = source[i];
    if (ch === "`") {
      // This pass handles generated Lua/Luau text. Do not reinterpret code-like
      // text inside a Luau interpolated string as VM implementation.
      const end = readQuotedEnd(source, i, ch);
      if (end > i) { i = end; continue; }
    }
    if (ch === "'" || ch === '"') {
      const end = readQuotedEnd(source, i, ch);
      if (end > i) {
        const value = decodeLuaQuoted(source.slice(i, end));
        if (DIAGNOSTIC_TEXT.test(value)) literals.push({ start: i, end, value });
        i = end;
        continue;
      }
    }
    if (hasErrorAlias && /[A-Za-z_]/.test(ch)) {
      let end = i + 1;
      while (end < source.length && /[A-Za-z0-9_]/.test(source[end])) end++;
      if (source.slice(i, end) === "error") {
        let next = end;
        while (next < source.length && /\s/.test(source[next])) next++;
        let previous = i - 1;
        while (previous >= 0 && /\s/.test(source[previous])) previous--;
        const memberAccess = previous >= 0 && (source[previous] === "." || source[previous] === ":");
        if (!memberAccess && source[next] === "(") aliasRenames.push({ start: i, end, name: resolveErrorAliasAt(i) });
      }
      i = end;
      continue;
    }
    i++;
  }
  return { literals, aliasRenames, hasErrorAlias };
}

const WORD_CHAR = /[A-Za-z0-9_]/;

/**
 * Splices replacements into the source while keeping tokens separated.
 * Minified bodies legitimately write `x or"\228\149"` with no space, because a
 * quote is its own delimiter; substituting that literal with an identifier-led
 * accessor would otherwise fuse into the invalid `or<accessor>`.
 */
function applyEvents(source, events) {
  let out = "";
  let cursor = 0;
  for (const event of events) {
    out += source.slice(cursor, event.start);
    if (WORD_CHAR.test(event.text[0] || "") && WORD_CHAR.test(out.slice(-1))) out += " ";
    out += event.text;
    if (WORD_CHAR.test(source[event.end] || "") && WORD_CHAR.test(out.slice(-1))) out += " ";
    cursor = event.end;
  }
  return out + source.slice(cursor);
}

function encodeDiagnosticStrings(source, options = {}) {
  if (typeof source !== "string" || source.length === 0) {
    return { source, encoded: 0, errorCallsAliased: 0, mode: "none", blobBytes: 0, decoys: 0 };
  }
  if ((options.mode || "decimal") === "blob") {
    const blob = encodeDiagnosticStringsBlob(source, { seed: (options.seed >>> 0) || 1 });
    // "unavailable" means the generated body does not begin at a statement
    // boundary, so a runtime prefix cannot be spliced in without corrupting the
    // expression. Fall back to the decimal representation instead of failing.
    if (blob.mode !== "unavailable") return blob;
  }
  const { literals, aliasRenames, hasErrorAlias } = scanDiagnostics(source);
  const events = literals.map((lit) => ({ start: lit.start, end: lit.end, text: toDecimalEscapedLuaString(lit.value, hasErrorAlias) }));
  for (const rename of aliasRenames) events.push({ start: rename.start, end: rename.end, text: rename.name });
  events.sort((a, b) => a.start - b.start);
  return {
    source: applyEvents(source, events),
    encoded: literals.length,
    errorCallsAliased: aliasRenames.length,
    mode: "decimal",
    blobBytes: 0,
    decoys: 0
  };
}

/**
 * VeilBlob route: instead of emitting every diagnostic literal as its own
 * `"\ddd\ddd..."` decimal escape chain, all matched strings are packed into one
 * encrypted `[==[byteveil&...]==]` blob and each call site becomes an accessor
 * call. The runtime value handed to `error()` is identical, so behaviour is
 * unchanged; only the static representation differs, and reading it now
 * requires executing the decoder rather than unescaping a literal.
 */
function encodeDiagnosticStringsBlob(source, { seed = 1 } = {}) {
  const { literals, aliasRenames, hasErrorAlias } = scanDiagnostics(source);
  const at = blobInsertionPoint(source);
  if (at < 0) {
    return { source, encoded: 0, errorCallsAliased: 0, mode: "unavailable", blobBytes: 0, decoys: 0 };
  }
  if (!literals.length) {
    const events = aliasRenames.map((r) => ({ start: r.start, end: r.end, text: r.name }));
    return { source: applyEvents(source, events), encoded: 0, errorCallsAliased: aliasRenames.length, mode: "none", blobBytes: 0, decoys: 0 };
  }
  const entries = literals.map((lit) => (hasErrorAlias ? toFaultToken(lit.value) : lit.value));
  const runtime = renderDiagnosticRuntime({
    seed,
    entries,
    decoys: 1 + (seed % 3),
    usedNames: collectUsedNames(source),
    errorCodes: blobErrorCodes(seed)
  });
  const events = literals.map((lit, idx) => ({ start: lit.start, end: lit.end, text: `${runtime.get}(${idx + 1})` }));
  for (const rename of aliasRenames) events.push({ start: rename.start, end: rename.end, text: rename.name });
  events.sort((a, b) => a.start - b.start);
  const rewritten = applyEvents(source, events);
  const output = `${rewritten.slice(0, at)}${runtime.prelude}${rewritten.slice(at)}`;
  return {
    source: output,
    encoded: literals.length,
    errorCallsAliased: aliasRenames.length,
    mode: runtime.engine,
    blobBytes: runtime.blobBytes,
    decoys: runtime.decoyLiterals.length,
    get: runtime.get,
    preludeBytes: Buffer.byteLength(runtime.prelude, "utf8")
  };
}

// The blob runtime must be a statement prefix, so it lands after the leading
// watermark comment line and immediately before the generated body statement.
// Returns -1 when the body does not start at a statement boundary.
function blobInsertionPoint(source) {
  let at = 0;
  const nl = source.indexOf("\n");
  if (nl >= 0 && /^\s*--/.test(source.slice(0, nl))) at = nl + 1;
  const tail = source.slice(at);
  if (tail.length === 0) return -1;
  if (/^(?:return|local|do|if|for|while|repeat|;)/.test(tail)) return at;
  return -1;
}

function blobErrorCodes(seed) {
  const a = lehmerSeed(seed, 0xE0F0) % 9000000 + 1000000;
  const b = lehmerSeed(seed, 0xE1F1) % 9000000 + 1000000;
  return b === a ? [a, a + 1] : [a, b];
}

module.exports = { encodeDiagnosticStrings, encodeDiagnosticStringsBlob, toDecimalEscapedLuaString, scanDiagnostics };

"use strict";

const IDENT_START = /[A-Za-z_]/;
const IDENT_PART = /[A-Za-z0-9_]/;

function longBracketEnd(source, index) {
    if (source[index] !== "[") return -1;
    let cursor = index + 1;
    while (source[cursor] === "=") cursor++;
    if (source[cursor] !== "[") return -1;
    const equals = source.slice(index + 1, cursor);
    const close = `]${equals}]`;
    const end = source.indexOf(close, cursor + 1);
    return end < 0 ? source.length : end + close.length;
}

/** Rewrite Lua/Luau identifier tokens while keeping strings and comments byte-for-byte intact. */
function rewriteLuaIdentifiers(source, replacer) {
    const text = String(source);
    if (typeof replacer !== "function") throw new TypeError("replacer must be a function");
    let out = "";
    let i = 0;

    while (i < text.length) {
        const ch = text[i];
        if (ch === "-" && text[i + 1] === "-") {
            const longEnd = longBracketEnd(text, i + 2);
            if (longEnd >= 0) {
                out += text.slice(i, longEnd);
                i = longEnd;
            } else {
                let end = i + 2;
                while (end < text.length && text[end] !== "\n" && text[end] !== "\r") end++;
                out += text.slice(i, end);
                i = end;
            }
            continue;
        }
        if (ch === "'" || ch === '"') {
            const quote = ch;
            let end = i + 1;
            while (end < text.length) {
                if (text[end] === "\\") { end = Math.min(text.length, end + 2); continue; }
                if (text[end] === quote) { end++; break; }
                end++;
            }
            out += text.slice(i, end);
            i = end;
            continue;
        }
        if (ch === "[") {
            const end = longBracketEnd(text, i);
            if (end >= 0) {
                out += text.slice(i, end);
                i = end;
                continue;
            }
        }
        if (IDENT_START.test(ch)) {
            let end = i + 1;
            while (end < text.length && IDENT_PART.test(text[end])) end++;
            if (i > 0 && /[0-9]/.test(text[i - 1])) {
                out += text.slice(i, end);
                i = end;
                continue;
            }
            const token = text.slice(i, end);
            let before = i - 1;
            while (before >= 0 && /\s/.test(text[before])) before--;
            let after = end;
            while (after < text.length && /\s/.test(text[after])) after++;
            const context = {
                memberName: before >= 0 && (text[before] === "." || text[before] === ":"),
                tableKey: after < text.length && text[after] === "=" && before >= 0 && (text[before] === "{" || text[before] === ","),
                labelName: (before >= 0 && text[before] === ":") || (after + 1 < text.length && text.slice(after, after + 2) === "::")
            };
            const next = replacer(token, context);
            out += typeof next === "string" ? next : token;
            i = end;
            continue;
        }
        out += ch;
        i++;
    }
    return out;
}

function collectLuaIdentifiers(source) {
    const names = new Set();
    rewriteLuaIdentifiers(source, (token) => { names.add(token); return token; });
    return names;
}

const LUA_KEYWORDS = new Set([
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true",
    "until", "while", "continue", "export", "type", "typeof"
]);
const IDENT_ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

function seedHash(text, seed) {
    let value = (Number(seed) >>> 0) ^ 0x9E3779B9;
    for (let i = 0; i < text.length; i++) {
        value = Math.imul(value ^ text.charCodeAt(i), 0x01000193) >>> 0;
        value ^= value >>> 13;
    }
    value ^= value >>> 16;
    value = Math.imul(value, 0x7FEB352D) >>> 0;
    value ^= value >>> 15;
    return value >>> 0;
}

/**
 * Rename generated internal aliases without changing API identifiers or text literals.
 * This is obfuscation/name blending, not a cryptographic boundary. Keeping it lexical
 * prevents edits to strings, comments, property names in text, and encoded payload bytes.
 */
function mangleGeneratedInternals(source, seed = 0, options = {}) {
    const text = String(source);
    const allNames = collectLuaIdentifiers(text);
    const metaFields = new Set([
        "__index", "__newindex", "__call", "__mode", "__gc", "__eq",
        "__lt", "__le", "__len", "__concat", "__unm", "__add", "__sub",
        "__mul", "__div", "__idiv", "__mod", "__pow", "__tostring",
        "__pairs", "__ipairs", "__iter", "__metatable", "__namecall"
    ]);
    const luaKeywords = new Set([
        "and", "break", "do", "else", "elseif", "end", "false", "for",
        "function", "goto", "if", "in", "local", "nil", "not", "or",
        "repeat", "return", "then", "true", "until", "while", "continue",
        "export", "type", "typeof"
    ]);
    const protectedGlobals = new Set([
        "_G", "_ENV", "_VERSION", "_PROMPT", "_TRACEBACK", "_LOADED",
        "_PRELOAD", "_REQUIREDNAME", "_PACKAGE", "_NAME", "_M", "_EXPORTS"
    ]);
    const vmInternalNames = new Set([
        "resolveRegion", "unshard", "shardMask", "decodeRegionCodec", "byteMask",
        "chunkRead", "readString", "VMCache", "regionFor", "rootSeed",
        "personality", "personalityVersion", "runtimeToken", "shares", "regions",
        "morph", "crep", "irep", "cfp", "ilp", "pbf", "cff", "envf", "tok", "chk",
        "rv", "rf", "rs", "ps", "cr", "ir", "cf", "rps", "il", "af", "sa", "mf",
        "sm", "dep", "voc", "ord", "sl", "pd", "ds", "byId", "readers",
        "nativeBuffer", "bufferCreate", "bufferReadU8", "bufferWriteU8", "bufferFlags",
        "starts", "visiting", "resolvers", "depFns", "dep0", "dep1", "dep2", "dep3",
        "invRegion", "inverse", "buckets", "routes", "states", "hops", "RROOT",
        "useBuffer", "saved", "domains", "expect", "recent", "active", "modeSalt",
        "depSeed", "rseed", "UAt", "RAt", "RU", "Exec", "STOP", "RAW", "RID",
        "RID0", "G0BYID", "STARTTICK", "STARTTRACE", "LIVEOP", "V0", "K0", "S0",
        "F0", "A0", "B0", "C0", "C1", "M0", "Z0", "Q0", "I0", "D0", "X0", "R0",
        "G0", "P0", "T0", "N0", "PK0", "SP0", "VN", "LM", "IX", "OK", "ACT",
        "SIG", "AUTH", "TRACE", "EV", "OM", "PH", "FM", "RD", "SN", "Child",
        "STATE", "ARGS", "NARGS", "CHUNK", "FN", "UPVALS", "CODE", "CONSTS",
        "PARAMS", "VARARG", "STACK", "REGS", "OPEN", "TOP", "PC", "RET",
        "REGION", "CONT", "SHADOW", "SEM", "SEMFNS", "CORE", "CHOOSE",
        "EXEC", "HANDLERS", "OPMAP", "STEP", "MASK", "shape", "token",
        "step", "start", "route", "cache", "depth", "stages", "lane",
        "extra", "base", "flavor", "logical"
    ]);
    const isInternal = (name) => {
        if (name.startsWith("__bv_") || name.startsWith("_bvanti_") || name.startsWith("_bvh_") || name.startsWith("__v455_") || name.startsWith("__v46_")) return true;
        if (metaFields.has(name) || protectedGlobals.has(name) || luaKeywords.has(name)) return false;
        if (/^__(?:ok|value|name|p|g|f|count|keys|i|key|lenFn|fillFn|bytes|hash|length|k\d*|byte|expectedHash|expectedLength)$/i.test(name)) return true;
        if (options.vmOnly !== false && (vmInternalNames.has(name) || (name.length > 1 && name.includes("_")))) return true;
        if (!/^_[A-Za-z0-9_]{2,18}$/.test(name)) return false;
        return true;
    };
    const internals = [...allNames].filter(isInternal).sort();
    if (!internals.length) return text;

    const used = new Set([...allNames, ...luaKeywords, ...metaFields, ...protectedGlobals]);
    const mapping = new Map();
    const head = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const body = `${head}0123456789`;
    // A generated name must never be spellable as a JavaScript template hole. The engine precheck
    // scans the emitted text for bare `NaN`/`undefined`, so a 3-letter collision that happens to
    // read as one of them aborts a perfectly valid build - measured with seed 0x59c0de on a
    // bitwise-loop corpus, which named a VM handler `NaN` and failed the build.
    const holeLike = (name) => /^(?:NaN|undefined)$/i.test(String(name));
    let serial = 0;

    for (const original of internals) {
        let state = seedHash(`${original}|${serial++}`, seed) || 0xA341316C;
        let candidate = "";
        let attempts = 0;
        do {
            const length = 2 + (state % 3);
            let value = state;
            candidate = head[value % head.length];
            for (let i = 1; i < length; i++) {
                value = (Math.imul(value ^ (value >>> 15), 0x2C1B3C6D) + 0x297A2D39 + i) >>> 0;
                candidate += body[value % body.length];
            }
            state = (state + 0x6D2B79F5) >>> 0;
            attempts++;
        } while ((used.has(candidate) || luaKeywords.has(candidate) || holeLike(candidate)) && attempts < 256);

        if (used.has(candidate) || luaKeywords.has(candidate) || holeLike(candidate)) {
            candidate = `bvx${seedHash(`${original}|fallback`, seed).toString(36)}${serial.toString(36)}`;
            while (used.has(candidate) || luaKeywords.has(candidate) || holeLike(candidate)) candidate += "x";
        }
        used.add(candidate);
        mapping.set(original, candidate);
    }

    // Rewrite every occurrence of a selected generated token, including any
    // same-named generated table/member field, so declaration/reference pairs
    // cannot diverge. Magic metamethod keys and runtime globals were excluded
    // from `internals` above and therefore stay untouched.
    return rewriteLuaIdentifiers(text, (token) => mapping.get(token) || token);
}
module.exports = { rewriteLuaIdentifiers, collectLuaIdentifiers, mangleGeneratedInternals };

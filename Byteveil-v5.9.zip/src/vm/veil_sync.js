"use strict";

const crypto = require("crypto");

const ENGINE_NAME = "VeilSync-v2";
const DIGEST_ALGORITHM = "sha256";
const DEFAULT_MAX_BYTES = Infinity;

/**
 * VeilSync
 * --------
 * A synchronous, build-side encoding pipeline for ByteVeil.
 *
 * Responsibilities:
 *   - Validate and snapshot the codec pipeline.
 *   - Encode payload bytes through an ordered codec chain.
 *   - Decode payload bytes through the inverse chain, in reverse order.
 *   - Verify individual codecs and the complete pipeline.
 *   - Enforce optional input/intermediate/output size limits.
 *   - Provide immutable trace metadata and SHA-256 payload digests.
 *
 * Important:
 *   - This module does not invent or replace codecs.
 *   - Every stage must implement a real reversible transformation.
 *   - SHA-256 metadata detects mismatches only when the expected digest
 *     is independently retained and checked.
 *   - This module is not encryption and does not make the generated
 *     payload cryptographically secret.
 *
 * Backward-compatible entry point:
 *   encodeSynchronizedPayload(input, stages, options)
 */

class VeilSyncError extends Error {
    constructor(message, details = {}) {
        super(message);

        this.name = "VeilSyncError";
        this.code = details.code || "VEILSYNC_ERROR";

        if (details.stageId !== undefined) {
            this.stageId = details.stageId;
        }

        if (details.stageIndex !== undefined) {
            this.stageIndex = details.stageIndex;
        }

        if (details.operation !== undefined) {
            this.operation = details.operation;
        }

        if (details.cause !== undefined) {
            this.cause = details.cause;
        }

        if (details.expected !== undefined) {
            this.expected = details.expected;
        }

        if (details.actual !== undefined) {
            this.actual = details.actual;
        }
    }
}

function fail(message, code, details = {}) {
    throw new VeilSyncError(message, {
        ...details,
        code
    });
}

function isObject(value) {
    return value !== null && typeof value === "object";
}

/**
 * Convert accepted byte input to a new Buffer.
 *
 * Accepted:
 *   - Buffer
 *   - Uint8Array
 *   - ArrayBuffer
 *   - UTF-8 string
 *   - dense array of integer bytes
 *
 * undefined can represent an empty input only where explicitly allowed.
 * Codec output never gets the undefined/null-to-empty fallback.
 */
function toBuffer(value, label, options = {}) {
    const allowUndefined = options.allowUndefined === true;

    if (value === undefined && allowUndefined) {
        return Buffer.alloc(0);
    }

    if (Buffer.isBuffer(value)) {
        return Buffer.from(value);
    }

    if (value instanceof Uint8Array) {
        return Buffer.from(value);
    }

    if (value instanceof ArrayBuffer) {
        return Buffer.from(new Uint8Array(value));
    }

    if (typeof value === "string") {
        return Buffer.from(value, "utf8");
    }

    if (Array.isArray(value)) {
        const bytes = new Array(value.length);

        for (let i = 0; i < value.length; i++) {
            if (!Object.prototype.hasOwnProperty.call(value, i)) {
                fail(
                    `${label} contains a sparse byte array at index ${i}`,
                    "VEILSYNC_INVALID_BYTES"
                );
            }

            const byte = value[i];

            if (
                !Number.isInteger(byte) ||
                byte < 0 ||
                byte > 255
            ) {
                fail(
                    `${label} contains an invalid byte at index ${i}`,
                    "VEILSYNC_INVALID_BYTES",
                    { actual: byte }
                );
            }

            bytes[i] = byte;
        }

        return Buffer.from(bytes);
    }

    fail(
        `${label} must be a Buffer, Uint8Array, ArrayBuffer, string, or byte array`,
        "VEILSYNC_INVALID_BYTES",
        {
            actual: value === null ? "null" : typeof value
        }
    );
}

function sha256(bytes) {
    return crypto
        .createHash(DIGEST_ALGORITHM)
        .update(bytes)
        .digest("hex");
}

function normalizeLimit(value, name) {
    if (value === undefined) {
        return DEFAULT_MAX_BYTES;
    }

    if (
        value !== Infinity &&
        (!Number.isSafeInteger(value) || value < 0)
    ) {
        fail(
            `VeilSync option "${name}" must be a non-negative safe integer or Infinity`,
            "VEILSYNC_INVALID_OPTION",
            { actual: value }
        );
    }

    return value;
}

function normalizeOptions(options = {}) {
    if (!isObject(options) || Array.isArray(options)) {
        fail(
            "VeilSync options must be an object",
            "VEILSYNC_INVALID_OPTION"
        );
    }

    if (
        options.verify !== undefined &&
        typeof options.verify !== "boolean"
    ) {
        fail(
            'VeilSync option "verify" must be a boolean',
            "VEILSYNC_INVALID_OPTION",
            { actual: options.verify }
        );
    }

    return {
        verify: options.verify !== false,
        maxInputBytes: normalizeLimit(
            options.maxInputBytes,
            "maxInputBytes"
        ),
        maxOutputBytes: normalizeLimit(
            options.maxOutputBytes,
            "maxOutputBytes"
        ),
        expectedDigest: options.expectedDigest,
        expectedLength: options.expectedLength
    };
}

function checkSize(bytes, maxBytes, label, details = {}) {
    if (bytes.length > maxBytes) {
        fail(
            `${label} exceeds configured size limit: ${bytes.length} > ${maxBytes}`,
            "VEILSYNC_SIZE_LIMIT",
            {
                ...details,
                expected: maxBytes,
                actual: bytes.length
            }
        );
    }
}

/**
 * Validate the stage definitions and snapshot their methods.
 *
 * Capturing the function references prevents a stage's encode/decode
 * property being replaced halfway through a single pipeline operation.
 *
 * Duplicate IDs are allowed for compatibility; trace entries also carry
 * their 1-based position, so each invocation remains distinguishable.
 */
function normalizeStages(stages) {
    if (!Array.isArray(stages) || stages.length === 0) {
        fail(
            "VeilSync requires at least one codec stage",
            "VEILSYNC_NO_STAGES"
        );
    }

    const normalized = new Array(stages.length);

    for (let i = 0; i < stages.length; i++) {
        const stage = stages[i];

        if (!isObject(stage)) {
            fail(
                `VeilSync stage ${i + 1} must be an object`,
                "VEILSYNC_INVALID_STAGE",
                { stageIndex: i + 1 }
            );
        }

        if (
            typeof stage.id !== "string" ||
            stage.id.trim().length === 0
        ) {
            fail(
                `VeilSync stage ${i + 1} must define a non-empty string id`,
                "VEILSYNC_INVALID_STAGE",
                { stageIndex: i + 1 }
            );
        }

        if (
            typeof stage.encode !== "function" ||
            typeof stage.decode !== "function"
        ) {
            fail(
                `VeilSync stage "${stage.id}" must define encode and decode functions`,
                "VEILSYNC_INVALID_STAGE",
                {
                    stageId: stage.id,
                    stageIndex: i + 1
                }
            );
        }

        normalized[i] = Object.freeze({
            owner: stage,
            id: stage.id,
            encode: stage.encode,
            decode: stage.decode,
            index: i + 1
        });
    }

    return Object.freeze(normalized);
}

/**
 * Execute one codec operation with an isolated copy of the input.
 *
 * This API is deliberately synchronous: a Promise is rejected rather
 * than accidentally converted into an empty Buffer.
 */
function executeCodec(stage, operation, input) {
    const fn = stage[operation];

    let result;

    try {
        result = fn.call(
            stage.owner,
            Buffer.from(input)
        );
    } catch (cause) {
        throw new VeilSyncError(
            `VeilSync ${operation} failed at stage "${stage.id}"`,
            {
                code: "VEILSYNC_STAGE_FAILED",
                stageId: stage.id,
                stageIndex: stage.index,
                operation,
                cause
            }
        );
    }

    if (
        result !== null &&
        result !== undefined &&
        typeof result.then === "function"
    ) {
        fail(
            `VeilSync stage "${stage.id}" returned a Promise; asynchronous codecs are not supported`,
            "VEILSYNC_ASYNC_STAGE",
            {
                stageId: stage.id,
                stageIndex: stage.index,
                operation
            }
        );
    }

    let output;

    try {
        output = toBuffer(
            result,
            `VeilSync stage "${stage.id}" ${operation} output`
        );
    } catch (cause) {
        if (cause instanceof VeilSyncError) {
            cause.stageId = stage.id;
            cause.stageIndex = stage.index;
            cause.operation = operation;
            throw cause;
        }

        throw new VeilSyncError(
            `VeilSync received invalid output from stage "${stage.id}"`,
            {
                code: "VEILSYNC_INVALID_STAGE_OUTPUT",
                stageId: stage.id,
                stageIndex: stage.index,
                operation,
                cause
            }
        );
    }

    return output;
}

/**
 * Decode a complete pipeline in reverse stage order.
 *
 * For encode stages A -> B -> C, decoding MUST be C -> B -> A.
 */
function runReversePipeline(encodedInput, stages, options = {}) {
    let current = Buffer.from(encodedInput);
    const trace = [];

    for (let i = stages.length - 1; i >= 0; i--) {
        const stage = stages[i];
        const before = current;

        current = executeCodec(
            stage,
            "decode",
            before
        );

        checkSize(
            current,
            options.maxOutputBytes,
            `Decoded output at stage "${stage.id}"`,
            {
                stageId: stage.id,
                stageIndex: stage.index,
                operation: "decode"
            }
        );

        trace.push(Object.freeze({
            id: stage.id,
            index: stage.index,
            operation: "decode",
            inputBytes: before.length,
            outputBytes: current.length,
            inputDigest: sha256(before),
            outputDigest: sha256(current)
        }));
    }

    return {
        bytes: Buffer.from(current),
        trace: Object.freeze(trace)
    };
}

function validateExpectedDigest(expectedDigest) {
    if (expectedDigest === undefined) {
        return undefined;
    }

    if (
        typeof expectedDigest !== "string" ||
        !/^[a-fA-F0-9]{64}$/.test(expectedDigest)
    ) {
        fail(
            "VeilSync expectedDigest must be a 64-character SHA-256 hex digest",
            "VEILSYNC_INVALID_OPTION",
            { actual: expectedDigest }
        );
    }

    return expectedDigest.toLowerCase();
}

function validateExpectedLength(expectedLength) {
    if (expectedLength === undefined) {
        return undefined;
    }

    if (
        !Number.isSafeInteger(expectedLength) ||
        expectedLength < 0
    ) {
        fail(
            "VeilSync expectedLength must be a non-negative safe integer",
            "VEILSYNC_INVALID_OPTION",
            { actual: expectedLength }
        );
    }

    return expectedLength;
}

/**
 * Encode the payload through all configured stages.
 *
 * Result fields retained from the earlier API:
 *   bytes
 *   stageOutputs
 *   trace
 *   engine
 *   roundTripsVerified
 *
 * Additional fields:
 *   version
 *   integrity
 *   pipelineRoundTripVerified
 */
function encodeSynchronizedPayload(input, stages, options = {}) {
    const config = normalizeOptions(options);
    const pipeline = normalizeStages(stages);

    const original = toBuffer(
        input,
        "VeilSync input",
        { allowUndefined: true }
    );

    checkSize(
        original,
        config.maxInputBytes,
        "VeilSync input"
    );

    const originalDigest = sha256(original);

    let current = Buffer.from(original);

    const stageOutputs = [];
    const trace = [];

    for (let i = 0; i < pipeline.length; i++) {
        const stage = pipeline[i];
        const before = current;

        current = executeCodec(
            stage,
            "encode",
            before
        );

        checkSize(
            current,
            config.maxOutputBytes,
            `Encoded output at stage "${stage.id}"`,
            {
                stageId: stage.id,
                stageIndex: stage.index,
                operation: "encode"
            }
        );

        let stageVerified = false;

        /*
         * Verify the inverse for this individual stage:
         *
         *     decode(encode(before)) === before
         *
         * This catches a broken stage close to its source instead of
         * waiting until the complete runtime payload fails.
         */
        if (config.verify) {
            const stageDecoded = executeCodec(
                stage,
                "decode",
                current
            );

            if (!stageDecoded.equals(before)) {
                fail(
                    `VeilSync round-trip failed at stage "${stage.id}"`,
                    "VEILSYNC_STAGE_ROUNDTRIP_MISMATCH",
                    {
                        stageId: stage.id,
                        stageIndex: stage.index,
                        operation: "verify",
                        expected: sha256(before),
                        actual: sha256(stageDecoded)
                    }
                );
            }

            stageVerified = true;
        }

        stageOutputs.push(Buffer.from(current));

        trace.push(Object.freeze({
            id: stage.id,
            index: stage.index,
            operation: "encode",
            inputBytes: before.length,
            outputBytes: current.length,
            inputDigest: sha256(before),
            outputDigest: sha256(current),
            verified: stageVerified
        }));
    }

    let pipelineRoundTripVerified = false;

    /*
     * Verify the actual composed pipeline, not only each isolated stage:
     *
     *   input -> A -> B -> C -> decode C -> decode B -> decode A
     *
     * This is deliberately a separate check because bugs can exist in
     * stage interactions even when individual stage round-trips pass.
     */
    if (config.verify) {
        const recovered = runReversePipeline(
            current,
            pipeline,
            config
        );

        if (!recovered.bytes.equals(original)) {
            fail(
                "VeilSync end-to-end round-trip failed",
                "VEILSYNC_PIPELINE_ROUNDTRIP_MISMATCH",
                {
                    expected: originalDigest,
                    actual: sha256(recovered.bytes)
                }
            );
        }

        pipelineRoundTripVerified = true;
    }

    const output = Buffer.from(current);
    const outputDigest = sha256(output);

    return Object.freeze({
        bytes: output,

        stageOutputs: Object.freeze(
            stageOutputs.map(buffer => Buffer.from(buffer))
        ),

        trace: Object.freeze(trace),

        engine: ENGINE_NAME,
        version: 2,

        digestAlgorithm: DIGEST_ALGORITHM,

        integrity: Object.freeze({
            algorithm: DIGEST_ALGORITHM,
            inputDigest: originalDigest,
            outputDigest
        }),

        roundTripsVerified: config.verify
            ? pipeline.length
            : 0,

        pipelineRoundTripVerified
    });
}

/**
 * Detailed inverse-pipeline result.
 *
 * options.expectedDigest checks the decoded payload's SHA-256 digest.
 * The expected digest must be supplied independently; reading both the
 * payload and its expected digest from the same untrusted location does
 * not provide meaningful tamper protection.
 */
function decodeSynchronizedPayloadDetailed(
    input,
    stages,
    options = {}
) {
    const config = normalizeOptions(options);
    const pipeline = normalizeStages(stages);

    const encoded = toBuffer(
        input,
        "VeilSync encoded input"
    );

    checkSize(
        encoded,
        config.maxInputBytes,
        "VeilSync encoded input"
    );

    const expectedDigest = validateExpectedDigest(
        config.expectedDigest
    );

    const expectedLength = validateExpectedLength(
        config.expectedLength
    );

    const decoded = runReversePipeline(
        encoded,
        pipeline,
        config
    );

    const bytes = Buffer.from(decoded.bytes);
    const digest = sha256(bytes);

    if (
        expectedLength !== undefined &&
        bytes.length !== expectedLength
    ) {
        fail(
            "VeilSync decoded payload length mismatch",
            "VEILSYNC_LENGTH_MISMATCH",
            {
                expected: expectedLength,
                actual: bytes.length
            }
        );
    }

    if (
        expectedDigest !== undefined &&
        digest !== expectedDigest
    ) {
        fail(
            "VeilSync decoded payload digest mismatch",
            "VEILSYNC_DIGEST_MISMATCH",
            {
                expected: expectedDigest,
                actual: digest
            }
        );
    }

    return Object.freeze({
        bytes,

        trace: decoded.trace,

        engine: ENGINE_NAME,
        version: 2,

        digestAlgorithm: DIGEST_ALGORITHM,
        digest,

        decodedBytes: bytes.length,
        stagesDecoded: pipeline.length,

        integrityVerified:
            expectedDigest !== undefined ||
            expectedLength !== undefined
    });
}

/**
 * Simple decode API: return the restored payload Buffer.
 *
 * Use decodeSynchronizedPayloadDetailed() when trace or verification
 * metadata is needed.
 */
function decodeSynchronizedPayload(input, stages, options = {}) {
    const result = decodeSynchronizedPayloadDetailed(
        input,
        stages,
        options
    );

    return Buffer.from(result.bytes);
}

/**
 * Validate codec configuration without encoding a payload.
 */
function validateCodecStages(stages) {
    const pipeline = normalizeStages(stages);

    return Object.freeze({
        valid: true,
        count: pipeline.length,
        stages: Object.freeze(
            pipeline.map(stage => Object.freeze({
                id: stage.id,
                index: stage.index,
                hasEncode: typeof stage.encode === "function",
                hasDecode: typeof stage.decode === "function"
            }))
        )
    });
}

module.exports = {
    VeilSyncError,

    encodeSynchronizedPayload,
    decodeSynchronizedPayload,
    decodeSynchronizedPayloadDetailed,

    validateCodecStages
};
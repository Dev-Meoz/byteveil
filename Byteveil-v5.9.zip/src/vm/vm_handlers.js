"use strict";

const crypto = require("node:crypto");
const { rewriteLuaIdentifiers } = require("../utils/lua_identifier_rewriter");

const SHAPES = Object.freeze(["plain", "scope", "local", "block"]);

function hash32(value, seed = 0x811C9DC5) {
    let hash = Number(seed) >>> 0;

    for (const character of String(value ?? "")) {
        hash ^= character.charCodeAt(0);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }

    hash ^= hash >>> 16;
    hash = Math.imul(hash, 0x7FEB352D) >>> 0;
    hash ^= hash >>> 15;

    return hash >>> 0;
}

function normalizeSeed(seed) {
    if (typeof seed === "number" && Number.isFinite(seed)) return (seed >>> 0) || 0xB17E1;
    if (seed !== undefined && seed !== null) return hash32(seed) || 0xB17E1;

    return crypto.randomBytes(4).readUInt32LE(0) || 0xB17E1;
}

function safeLocalName(body, seed, identity) {
    const base = `_bvh_${hash32(`${identity}|${body}`, seed).toString(36)}`;
    let candidate = base;
    let suffix = 0;

    while (new RegExp(`(^|[^A-Za-z0-9_])${candidate.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^A-Za-z0-9_]|$)`).test(body)) {
        candidate = `${base}_${(++suffix).toString(36)}`;
    }

    return candidate;
}

function chooseShape(body, options, fallbackIdentity) {
    const requested = options.shape ?? "auto";

    if (requested !== "auto" && !SHAPES.includes(requested)) {
        throw new TypeError(`vm_handlers: unsupported source shape ${String(requested)}`);
    }

    const identity = String(options.identity ?? fallbackIdentity ?? body);
    const seed = normalizeSeed(options.seed);

    if (requested !== "auto") return { shape: requested, seed, identity };

    const mixed = hash32(`${identity}|${body}`, seed ^ 0x4D48444C);
    return { shape: SHAPES[mixed % SHAPES.length], seed, identity };
}

function parameterNames(body, seed, identity) {
    const stateArg = safeLocalName(body, seed ^ 0x51A7, `${identity}|state-param`);
    let instructionArg = safeLocalName(body, seed ^ 0x1A57, `${identity}|instruction-param`);
    if (instructionArg === stateArg) instructionArg += "x";
    // Only generated handler parameters named S/I are rewritten. The lexer-aware
    // token pass never edits API names or text inside string/comment literals.
    const code = rewriteLuaIdentifiers(body, (token) => token === "S" ? stateArg : token === "I" ? instructionArg : token);
    return { stateArg, instructionArg, code };
}

function renderHandler(name, body, options = {}) {
    const code = String(body ?? "");
    const choice = chooseShape(code, options && typeof options === "object" ? options : {}, name);
    const localName = safeLocalName(code, choice.seed, choice.identity);
    const params = parameterNames(code, choice.seed, choice.identity);

    switch (choice.shape) {
        case "scope":
            // A lexical block does not change return/break behavior inside the handler.
            return `function(${params.stateArg},${params.instructionArg})do ${params.code};end;end`;

        case "local":
            // The generated local and handler arguments are per-build identifiers.
            return `function(${params.stateArg},${params.instructionArg})local ${localName}=(${params.stateArg}==nil);${params.code};end`;

        case "block":
            return `function(${params.stateArg},${params.instructionArg})do local ${localName}=nil;end;${params.code};end`;

        case "plain":
        default:
            return `function(${params.stateArg},${params.instructionArg})${params.code};end`;
    }
}

function stackHandler(name, body, options = {}) {
    return renderHandler(name, body, options);
}

function registerHandler(name, body, options = {}) {
    return renderHandler(name, body, options);
}

module.exports = { stackHandler, registerHandler, SHAPES };
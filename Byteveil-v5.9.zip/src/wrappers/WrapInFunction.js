"use strict";

const ALPHA =
  "lIOQxZzYyAaEeUuNnMmWwVvKkHhRrTtPp" +
  "qXzYvVwWmMnNaAeEiIoOuUcCsSdDfFgGhHjJkKlL";

const DIGITS = "0135792468";
const UPPERCASE_KEYS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const { renderCallableBootstrap } = require("./bootstrap_renderer");
const { collectLuaIdentifiers } = require("../utils/lua_identifier_rewriter");

const RESERVED = new Set([
  "and","break","do","else","elseif","end","false","for","function",
  "goto","if","in","local","nil","not","or","repeat","return",
  "then","true","until","while","_ENV","_G"
]);

function createRng(seed = Date.now()) {
  let state = (Number(seed) >>> 0) || 0xA341316C;
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return (t ^ (t >>> 14)) >>> 0;
  };
}

function makeWeirdIdentifier(random, min = 2, max = 4) {
  const length = min === max ? min : min + (random() % (max - min + 1));
  let out = ALPHA[random() % ALPHA.length];
  for (let i = 1; i < length; i++) {
    const r = random();
    if ((r % 4) === 0) out += DIGITS[r % DIGITS.length];
    else out += ALPHA[r % ALPHA.length];
  }
  if (RESERVED.has(out)) return `${out}0`;
  return out;
}

function id(length = 6) {
  const rng = createRng(Date.now() ^ length);
  return makeWeirdIdentifier(rng, Math.max(7, length), Math.max(7, length));
}

/**
 * Pick a deterministic single-letter uppercase Lua table field for a wrapper.
 * A single uppercase identifier is valid in both Lua and Luau field syntax.
 */
function makeWrapperKey(seed) {
  const rng = createRng((Number(seed) >>> 0) ^ 0x6D2B79F5);
  return UPPERCASE_KEYS[rng() % UPPERCASE_KEYS.length];
}

/**
 * Minify Lua/Luau source safely enough for generated VM output.
 *
 * Preserves:
 * - string literals
 * - escaped characters
 * - block comments --[[ ... ]]
 *
 * Removes:
 * - normal line comments
 * - redundant whitespace
 */
function minify(source) {
  const input = String(source).replace(/^\uFEFF/, "");
  const tokens = [];
  const operators = [
    "...", "..=", "//=", "<<=", ">>=", "==", "~=", "<=", ">=",
    "+=", "-=", "*=", "/=", "%=", "^=", "..", "//", "<<", ">>", "::", "->"
  ];
  const operatorSet = new Set(operators);
  const identifierStart = /^[_\p{ID_Start}]$/u;
  const identifierPart = /^[_\u200C\u200D\p{ID_Continue}]$/u;
  const numberPattern = /^(?:0[xX][0-9a-fA-F_]+(?:\.(?!\.)[0-9a-fA-F_]*)?(?:[pP][+-]?[0-9_]+)?|0[bB][01_]+|(?:[0-9][0-9_]*(?:\.(?!\.)[0-9_]*)?|\.(?=[0-9])[0-9][0-9_]*)(?:[eE][+-]?[0-9_]+)?)/;

  function codePointAt(text, index) {
    if (index >= text.length) return "";
    return String.fromCodePoint(text.codePointAt(index));
  }

  function longBracketOpen(index) {
    if (input[index] !== "[") return null;
    const match = input.slice(index).match(/^\[(=*)\[/);
    if (!match) return null;
    return { raw: match[0], close: `]${match[1]}]` };
  }

  function readLongBracket(index, open) {
    const end = input.indexOf(open.close, index + open.raw.length);
    return end < 0 ? input.length : end + open.close.length;
  }

  function add(value, type) {
    tokens.push({ value, type });
  }

  let i = 0;
  while (i < input.length) {
    const ch = input[i];

    if (/\s/u.test(ch)) {
      i++;
      continue;
    }

    // Lua/Luau comments. Remove them without ever inspecting text inside a
    // quoted or long-bracket literal.
    if (ch === "-" && input[i + 1] === "-") {
      const open = longBracketOpen(i + 2);
      if (open) {
        i = readLongBracket(i + 2, open);
      } else {
        i += 2;
        while (i < input.length && input[i] !== "\n" && input[i] !== "\r") i++;
      }
      continue;
    }

    // Quoted strings are opaque tokens; their bytes and escapes are preserved.
    if (ch === "'" || ch === '"') {
      const quote = ch;
      let end = i + 1;
      while (end < input.length) {
        if (input[end] === "\\") {
          end = Math.min(input.length, end + 2);
          continue;
        }
        if (input[end] === quote) {
          end++;
          break;
        }
        end++;
      }
      add(input.slice(i, end), "literal");
      i = end;
      continue;
    }

    // Long-bracket strings, including [=[...]=] forms, must remain byte-for-byte
    // intact; newlines inside these literals are meaningful data.
    const longOpen = longBracketOpen(i);
    if (longOpen) {
      const end = readLongBracket(i, longOpen);
      add(input.slice(i, end), "literal");
      i = end;
      continue;
    }

    const cp = codePointAt(input, i);
    if (identifierStart.test(cp)) {
      let end = i + cp.length;
      while (end < input.length) {
        const next = codePointAt(input, end);
        if (!identifierPart.test(next)) break;
        end += next.length;
      }
      add(input.slice(i, end), "word");
      i = end;
      continue;
    }

    if (/[0-9]/.test(ch) || (ch === "." && /[0-9]/.test(input[i + 1] || ""))) {
      const match = input.slice(i).match(numberPattern);
      if (match && match[0]) {
        add(match[0], "number");
        i += match[0].length;
        continue;
      }
    }

    let operator = null;
    for (const candidate of operators) {
      if (input.startsWith(candidate, i)) {
        operator = candidate;
        break;
      }
    }
    if (operator) {
      add(operator, "symbol");
      i += operator.length;
    } else {
      add(ch, "symbol");
      i++;
    }
  }

  function needsSeparator(previous, current, index) {
    if (!previous) return false;
    if ((previous.type === "word" || previous.type === "number") &&
        (current.type === "word" || current.type === "number")) return true;

    // Preserve token boundaries that would otherwise become a comment, a
    // decimal literal, a long-bracket opener, or a different compound operator.
    if (previous.value === "-" && current.value === "-") return true;
    if (previous.value === "[" && (current.value === "[" || current.value === "=")) return true;
    if (previous.type === "number" && current.value.startsWith(".")) return true;
    if (previous.value === "." && current.type === "number") return true;
    if (operatorSet.has(previous.value + current.value)) return true;

    // Also guard the three-token long-bracket opener ` [ = [ ` when the first
    // boundary was already separated by a token that can close the pattern.
    if (current.value === "[" && index >= 2 &&
        tokens[index - 2].value === "[" && previous.value === "=") return true;
    return false;
  }

  let output = "";
  for (let index = 0; index < tokens.length; index++) {
    const current = tokens[index];
    if (needsSeparator(tokens[index - 1], current, index)) output += " ";
    output += current.value;
  }
  return output;
}
/**
 * Create wrapper invocation arguments.
 */
function createWrapArguments(count, seed = Date.now(), reservedIdentifiers = []) {
  const amount = Math.max(0, Number(count) | 0);
  const rng = createRng(seed);
  const used = new Set(Array.isArray(reservedIdentifiers) ? reservedIdentifiers : []);
  const out = [];
  let attempts = 0;
  let fallbackSerial = 0;
  while (out.length < amount) {
    const name = makeWeirdIdentifier(rng, 7, 12);
    attempts++;
    if (!used.has(name)) {
      used.add(name);
      out.push(name);
      continue;
    }
    // Collision resolution is bounded even if a caller supplies a pathological
    // seed or a future RNG implementation regresses.
    if (attempts > Math.max(128, amount * 64)) {
      let fallback;
      do { fallback = `BVArg_${(fallbackSerial++).toString(36)}`; }
      while (used.has(fallback) || RESERVED.has(fallback));
      used.add(fallback);
      out.push(fallback);
    }
  }
  return out;
}

/**
 * Wrap generated ByteCode VM source.
 *
 * returnMode:
 *
 * "setmetatable" (default, and any build with `setmeta`): renders the callable
 * bootstrap in `bootstrap_renderer`. Its tail is seed-selected — `callable-object`
 * invokes the bootstrap table through `__call`, `colon-dispatch` invokes an
 * identifier-keyed pre-flight method that returns the trampoline, so the emitted
 * chunk reads `return setmetatable({…}, {…}):<METHOD>()(…)`. Pass `wrapperShape`
 * ("colon-dispatch" | "callable-object" | "tail-call") to force one; `invoke: false`
 * always stays on `callable-object` because the caller receives the object itself.
 *
 * "gsub": legacy `do return (function(...) … end)(...) end` container.
 *
 * anything else: `return (function(...) … end)(...)`.
 *
 * With `wrapper: false` the body is only minified.
 */
function wrap(code, options = {}) {
  const {
    invoke = true,
    setmeta = true,
    wrapper = true,
    returnMode = "setmetatable",
    seed = Date.now()
  } = options;

  const body = String(code).replace(/^\uFEFF/, "").trim();
  if (!wrapper) return minify(body);

  // Forward the genuine chunk-level vararg tuple `...` at the wrapper edge so
  // chunk arguments (`load(code)(...)`), vararg expressions (`...`), and nil
  // holes are preserved without reading undefined globals from `_G`/`_ENV`.
  const invocation = invoke ? "(...)" : "";

  if (returnMode === "gsub") {
    return minify(`do return (function(...) ${body} end)${invocation} end`);
  }

  if (returnMode === "setmetatable" || setmeta) {
    const rendered = renderCallableBootstrap(body, {
      seed,
      backend: options.backend || options.mode || "hybrid",
      invoke,
      wrapperShape: options.wrapperShape || "auto",
      bootstrapCoupling: options.bootstrapCoupling || null
    });
    return minify(rendered.source);
  }

  return minify(`return (function(...) ${body} end)${invocation}`);
}
module.exports = {
  wrap,
  minify,
  createWrapArguments,
  makeWrapperKey,
  id
};
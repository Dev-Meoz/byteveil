"use strict";

const { collectLuaIdentifiers } = require("../utils/lua_identifier_rewriter");
const { renderDecoyBlob } = require("../obfuscation/veil_blob");

const KEYWORD_SET = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
  "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return",
  "then", "true", "until", "while", "continue", "export", "type", "typeof"
]);
const NAME_HEAD = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const NAME_BODY = `${NAME_HEAD}0123456789_`;

function u32(value) { return Number(value) >>> 0; }

function seedMixer(seed, domain = 0) {
  let state = (u32(seed) ^ u32(domain) ^ 0x9E3779B9) >>> 0;
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return (value ^ (value >>> 14)) >>> 0;
  };
}

function stableHash(text) {
  let value = 0x811C9DC5;
  for (let i = 0; i < text.length; i++) {
    value = Math.imul(value ^ text.charCodeAt(i), 0x01000193) >>> 0;
  }
  return value >>> 0;
}

function makeIdentifierFactory(seed, reservedNames) {
  const next = seedMixer(seed, 0x42565737);
  const used = new Set([...reservedNames, ...KEYWORD_SET]);
  return (minLength = 2, maxLength = 4) => {
    for (let attempt = 0; attempt < 512; attempt++) {
      const length = minLength + (next() % (maxLength - minLength + 1));
      let name = NAME_HEAD[next() % NAME_HEAD.length];
      for (let i = 1; i < length; i++) name += NAME_BODY[next() % NAME_BODY.length];
      // Same rule as the internal renamer: a 2-4 letter name can come out reading as a JavaScript
      // template hole, and the precheck rejects the build for it.
      if (!used.has(name) && !/^(?:NaN|undefined)$/i.test(name)) {
        used.add(name);
        return name;
      }
    }
    throw new Error("ByteVeil v5.9.0 wrapper: could not allocate a collision-free local name");
  };
}

function chooseSlots(seed, backend = "hybrid", shape = "callable-object") {
  const next = seedMixer(seed, stableHash(String(backend)) ^ 0x57524150);
  const slots = new Set();
  while (slots.size < 8) slots.add(0x100 + (next() % 0xEEFF));
  const [body, dispatch, entry, state, bank, dec, key, ctx] = slots;
  const stdSlotSet = new Set();
  while (stdSlotSet.size < 8) {
    const cand = 8 + (next() % 240);
    if (!slots.has(cand)) stdSlotSet.add(cand);
  }
  const [stdType, stdErr, stdSelect, stdSub, stdByte, stdFloor, stdConcat, stdPairs] = stdSlotSet;
  const fieldOrder = [body, dispatch, entry];
  // Seed-specific table-field order keeps the bootstrap from being a fixed template.
  for (let i = fieldOrder.length - 1; i > 0; i--) {
    const j = next() % (i + 1);
    [fieldOrder[i], fieldOrder[j]] = [fieldOrder[j], fieldOrder[i]];
  }
  const topology = (next() & 1) ? "trampoline-first" : "entry-first";
  const initSeed = 0x10000 + (next() % 0x7FFF00);
  const mulA = 257 + ((next() % 1021) | 1);
  const addA = 0x1000 + (next() % 0x7FFF0);
  const challenge = 0x100 + (next() % 0x7FFF);
  const colonSalt = 0x100 + (next() % 0x7FFF0);
  // `colon-dispatch` inserts the pre-flight method in front of the stage chain, so it
  // owns one extra LCG step. The tokens below are derived *after* that step, which is
  // what makes deleting the method call fail closed: the chain then sees the unadvanced
  // seed and every downstream equality check breaks.
  const stage0 = shape === "colon-dispatch"
    ? ((initSeed * mulA + colonSalt) % 2147483647)
    : initSeed;
  const stage1Token = topology === "entry-first"
    ? ((stage0 * mulA + addA) % 2147483647)
    : ((stage0 * mulA + challenge) % 2147483647);
  const expectedBootstrapKey = topology === "entry-first"
    ? ((stage1Token * 65599 + challenge) % 2147483647)
    : ((stage1Token * 65599 + addA) % 2147483647);
  return {
    shape,
    body,
    dispatch,
    entry,
    state,
    bank,
    dec,
    key,
    ctx,
    stdSlots: {
      type: stdType,
      err: stdErr,
      select: stdSelect,
      sub: stdSub,
      byte: stdByte,
      floor: stdFloor,
      concat: stdConcat,
      pairs: stdPairs
    },
    crypto: {
      initSeed,
      mulA,
      addA,
      challenge,
      colonSalt,
      stage0,
      stage1Token,
      expectedBootstrapKey
    },
    salts: [next(), next(), next(), next()],
    fieldOrder,
    topology
  };
}

/**
 * The wrapper tail is chosen per build. `callable-object` is the v5.8 shape: the
 * bootstrap table itself is invoked and `__call` routes into the stage chain.
 * `colon-dispatch` is the v5.9 shape: an identifier-keyed method runs a pre-flight
 * stage, owns one LCG step of the state chain, and *returns* the trampoline, so the
 * emitted source reads `return setmetatable({…}, {…}):<METHOD>()(…)` with a native-ref
 * pool field that the pre-flight stage cross-checks against the numeric slot bindings.
 * Because that method advances the state, a `colon-dispatch` build only runs through its
 * own tail: invoking the same object through `__call` leaves the state unadvanced and
 * fails closed. `invoke === false` therefore stays on `callable-object`, where the caller
 * receives the object and is expected to call it.
 */
function chooseShape(seed, backend = "hybrid", invoke = true, requested = "auto") {
  if (invoke === false) return "callable-object";
  if (requested === "colon-dispatch" || requested === "colon") return "colon-dispatch";
  if (requested === "callable-object" || requested === "tail-call") return "callable-object";
  const next = seedMixer(u32(seed) ^ 0x434F4C4E, stableHash(String(backend)) ^ 0x53484150);
  return (next() & 1) ? "colon-dispatch" : "callable-object";
}

/**
 * Build an explicit runtime/bootstrap plan for the callable wrapper.
 * The plan contains only wrapper-local slots, never source-level API contracts.
 */
function createBootstrapPlan({ seed = 0, backend = "hybrid", body = "", argumentNames = [], invoke = true, wrapperShape = "auto" } = {}) {
  const bodyNames = collectLuaIdentifiers(String(body));
  const reserved = new Set([...bodyNames, ...argumentNames]);
  const nextName = makeIdentifierFactory(u32(seed) ^ stableHash(String(backend)), reserved);
  const shape = chooseShape(seed, backend, invoke, wrapperShape);
  const slots = chooseSlots(seed, backend, shape);
  const plan = {
    version: "5.9.0",
    renderer: "callable-bootstrap-two-tail-staged",
    backend: backend === "stack" || backend === "register" ? backend : "hybrid",
    shape: slots.shape,
    slots: {
      body: slots.body,
      dispatch: slots.dispatch,
      entry: slots.entry,
      state: slots.state,
      bank: slots.bank,
      dec: slots.dec,
      key: slots.key,
      ctx: slots.ctx,
      std: slots.stdSlots
    },
    crypto: slots.crypto,
    salts: slots.salts,
    fieldOrder: slots.fieldOrder,
    topology: slots.topology,
    locals: {
      self: nextName(),
      entryResult: nextName(),
      stateVal: nextName(),
      challengeArg: nextName(),
      bankLocal: nextName(),
      decLocal: nextName(),
      errLocal: nextName(),
      typeLocal: nextName(),
      pow2Key: nextName(1, 2),
      stepKey: nextName(1, 2)
    }
  };
  // Only the colon shape consumes the extra names, so a `callable-object` build never
  // carries an unreachable pre-flight method or pool field.
  if (plan.shape === "colon-dispatch") {
    plan.locals.method = nextName(2, 3);
    plan.locals.pool = nextName(1, 2);
    plan.locals.poolLocal = nextName(2, 4);
  }
  return plan;
}

function formatSlotExpr(targetSlot, salt) {
  const s = u32(salt);
  const delta = 0x80 + ((s >>> 4) % 0x0EFF);
  if ((s & 1) === 0 || targetSlot <= delta) {
    return `(0x${(targetSlot + delta).toString(16)}-0x${delta.toString(16)})`;
  }
  return `(0x${(targetSlot - delta).toString(16)}+0x${delta.toString(16)})`;
}

function rewriteStageCarrierList(carriers, bankFrom, bankTo, decFrom, decTo) {
  if (!Array.isArray(carriers) || !carriers.length) return "";
  return carriers
    .map((stmt) => String(stmt).split(bankFrom).join(bankTo).split(decFrom).join(decTo))
    .join(";") + ";";
}

function renderCallableBootstrap(body, options = {}) {
  const source = String(body).replace(/^\uFEFF/, "").trim();
  const coupling = options.bootstrapCoupling && typeof options.bootstrapCoupling.renderBody === "function"
    ? options.bootstrapCoupling
    : null;
  const plan = createBootstrapPlan({ ...options, body: source, argumentNames: [] });
  const self = plan.locals.self;
  const result = plan.locals.entryResult;
  const sVar = plan.locals.stateVal;
  const cArg = plan.locals.challengeArg;
  const bVar = plan.locals.bankLocal;
  const dVar = plan.locals.decLocal;
  const eVar = plan.locals.errLocal;
  const tVar = plan.locals.typeLocal;
  const pow2Key = plan.locals.pow2Key;
  const stepKey = plan.locals.stepKey;
  const std = plan.slots.std;
  const invocation = options.invoke === false ? "" : "(...)";
  const [s0, s1, s2, s3] = plan.salts;
  const bodyExpr = formatSlotExpr(plan.slots.body, s0);
  const dispatchExpr = formatSlotExpr(plan.slots.dispatch, s1);
  const entryExpr = formatSlotExpr(plan.slots.entry, s2);
  const stateSlot = plan.slots.state;
  const bankSlot = plan.slots.bank;
  const decSlot = plan.slots.dec;
  const keySlot = plan.slots.key;
  const ctxSlot = plan.slots.ctx;
  const { initSeed, mulA, addA, challenge, colonSalt, stage1Token, expectedBootstrapKey } = plan.crypto;

  const stagedSubsystems = coupling && typeof coupling.renderStages === "function"
    ? coupling.renderStages({
        topology: plan.topology,
        selfName: self,
        bankSlot,
        decSlot,
        keySlot,
        ctxSlot,
        expectedKey: expectedBootstrapKey
      })
    : null;

  const stage1CoupledCode = stagedSubsystems
    ? `${stagedSubsystems.stage1Code};`
    : coupling
      ? `local ${bVar}={};${self}[${bankSlot}]=${bVar};local ${dVar}=function(...)return ${self}[${decSlot}](...)end;${rewriteStageCarrierList(coupling.stage1Carriers, coupling.bankName, bVar, coupling.decoderName, dVar)}`
      : "";
  const stage2CoupledCode = stagedSubsystems
    ? `${stagedSubsystems.stage2Code};`
    : coupling
      ? `local ${bVar}=${self}[${bankSlot}];local ${dVar}=function(...)return ${self}[${decSlot}](...)end;${rewriteStageCarrierList(coupling.stage2Carriers, coupling.bankName, bVar, coupling.decoderName, dVar)}`
      : "";

  const effectiveBodySource = stagedSubsystems
    ? stagedSubsystems.stage3Code
    : coupling
      ? coupling.renderBody({
          selfName: self,
          bankSlot,
          decSlot,
          keySlot,
          expectedKey: expectedBootstrapKey
        })
      : source;

  const bodyParams = coupling ? `${self},...` : "...";
  const bodyCallArgs = coupling ? `${self},...` : "...";
  const bodyField = `[${plan.slots.body}]=function(${bodyParams}) ${effectiveBodySource} end`;

  const stdGuardExpr = `local ${eVar}=${self}[${std.err}]or error;local ${tVar}=${self}[${std.type}];if not ${tVar} or ${tVar}(${self}[${std.sub}])~="function"or ${tVar}(${self}[${std.select}])~="function"or ${tVar}(${self}[${std.floor}])~="function"or ${tVar}(${self}[${std.concat}])~="function"then ${eVar}("bootstrap state",0)end`;
  const isColon = plan.shape === "colon-dispatch";
  const methodName = plan.locals.method;
  const poolName = plan.locals.pool;
  const poolLocal = plan.locals.poolLocal;
  // The native-ref pool is emitted only for the colon shape and is not decoration:
  // the pre-flight stage compares pool entries against the numeric slot bindings, so
  // an edited pool, or a host that swapped a global between the two reads, fails
  // closed before the payload decodes. Both names are wiped with the other bindings.
  const wipeColonBindings = isColon ? `;${self}.${poolName}=nil;${self}.${methodName}=nil` : "";
  const wipeStdBindings = `${self}.${pow2Key}=nil;${self}.${stepKey}=nil;${self}[${std.type}]=nil;${self}[${std.err}]=nil;${self}[${std.select}]=nil;${self}[${std.sub}]=nil;${self}[${std.byte}]=nil;${self}[${std.floor}]=nil;${self}[${std.concat}]=nil;${self}[${std.pairs}]=nil${wipeColonBindings}`;

  let entryField;
  let dispatchField;
  let callableSlot;

  if (plan.topology === "entry-first") {
    callableSlot = plan.slots.entry;
    entryField = `[${plan.slots.entry}]=function(${self},...)${stdGuardExpr};local ${sVar}=${self}[${stateSlot}];if ${tVar}(${sVar})~="number"then ${eVar}("bootstrap state",0)end;${stage1CoupledCode}${self}[${stateSlot}]=${self}:${stepKey}(${sVar},${addA});return ${self}[${dispatchExpr}](${self},...)end`;
    dispatchField = `[${plan.slots.dispatch}]=function(${self},...)${stdGuardExpr};local ${sVar}=${self}[${stateSlot}];${self}[${stateSlot}]=nil;if ${sVar}~=${stage1Token} then ${eVar}("bootstrap state",0)end;${stage2CoupledCode}${self}[${keySlot}]=(${sVar}*65599+${challenge})%2147483647;local ${result}=${self}[${bodyExpr}];${wipeStdBindings};${self}[${plan.slots.entry}]=nil;${self}[${plan.slots.dispatch}]=nil;${self}[${plan.slots.body}]=nil;return ${result}(${bodyCallArgs})end`;
  } else {
    callableSlot = plan.slots.dispatch;
    entryField = `[${plan.slots.entry}]=function(${self},${cArg})${stdGuardExpr};local ${sVar}=${self}[${stateSlot}];${self}[${stateSlot}]=nil;if ${tVar}(${sVar})~="number"or ${cArg}~=${challenge} then ${eVar}("bootstrap state",0)end;${stage1CoupledCode}return ${self}:${stepKey}(${sVar},${cArg})end`;
    dispatchField = `[${plan.slots.dispatch}]=function(${self},...)${stdGuardExpr};local ${sVar}=${self}[${entryExpr}](${self},${challenge});if ${sVar}~=${stage1Token} then ${eVar}("bootstrap state",0)end;${stage2CoupledCode}${self}[${keySlot}]=(${sVar}*65599+${addA})%2147483647;local ${result}=${self}[${bodyExpr}];${wipeStdBindings};${self}[${plan.slots.entry}]=nil;${self}[${plan.slots.dispatch}]=nil;${self}[${plan.slots.body}]=nil;return ${result}(${bodyCallArgs})end`;
  }

  const fields = new Map([
    [plan.slots.body, bodyField],
    [plan.slots.dispatch, dispatchField],
    [plan.slots.entry, entryField]
  ]);
  const callableExpr = formatSlotExpr(callableSlot, s3);
  // Colon-dispatch front stage: the emitted chunk calls the identifier-keyed method
  // with no arguments and the method *returns* the trampoline that receives the chunk
  // vararg tuple. The method owns one LCG step of the state chain, so the stage tokens
  // downstream are derived from the advanced state: dropping the method call, or
  // invoking the object through `__call` instead, leaves the seed unadvanced and every
  // downstream equality check fails closed. It also cross-checks the native-ref pool
  // against the numeric slot bindings before the payload decoder is allowed to run.
  const colonField = isColon
    ? `${methodName}=function(${self})${stdGuardExpr};local ${poolLocal}=${self}.${poolName};if not ${poolLocal} or ${tVar}(${poolLocal})~="table"or #${poolLocal}~=8 then ${eVar}("bootstrap state",0)end;if ${poolLocal}[1]~=${self}[${std.type}]or ${poolLocal}[3]~=${self}[${std.select}]or ${poolLocal}[6]~=${self}[${std.floor}]then ${eVar}("bootstrap state",0)end;local ${sVar}=${self}[${stateSlot}];if ${tVar}(${sVar})~="number"or ${sVar}~=${initSeed} then ${eVar}("bootstrap state",0)end;${self}[${stateSlot}]=${self}:${stepKey}(${sVar},${colonSalt});return function(...)return ${self}[${callableExpr}](${self},...)end end`
    : null;
  const orderedFields = plan.fieldOrder.map((slot) => fields.get(slot));
  const rootBindings = [
    `${pow2Key}={[0]=1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536}`,
    `[${std.type}]=type`,
    `[${std.err}]=error`,
    `[${std.select}]=select`,
    `[${std.sub}]=string.sub`,
    `[${std.byte}]=string.byte`,
    `[${std.floor}]=math.floor`,
    `[${std.concat}]=table.concat`,
    `[${std.pairs}]=pairs`,
    ...(isColon ? [`${poolName}={type,error,select,string.sub,string.byte,math.floor,table.concat,pairs}`] : []),
    `${stepKey}=function(${self},${sVar},${cArg})local P=${self}.${pow2Key};if not P or P[8]~=256 or P[16]~=65536 then(${self}[${std.err}]or error)("bootstrap state",0)end;return(${sVar}*${mulA}+${cArg})%2147483647 end`,
    `[${stateSlot}]=${initSeed}`
  ].join(",");
  // Place the stdlib/pow2 bindings and numeric state seed after the first function slot
  // so the bootstrap begins with `return setmetatable({[<slot>]=function(` and
  // `[stateSlot]=initSeed` immediately precedes the second `[<slot>]=function(`.
  orderedFields.splice(1, 0, rootBindings);
  // Colon shape appends the pre-flight method after the three numeric slots so the
  // leading `return setmetatable({[<slot>]=function(` template is untouched.
  if (isColon) orderedFields.push(colonField);
  const fieldSource = orderedFields.join(",");
  // Trailing unused char-code source: a real VeilBlob container sitting after the
  // `end` of the __call slot, stored under a numeric key the VM never indexes. It
  // decodes like any other blob, so blob count and blob readers no longer match.
  const decoySeed = (Number(options.seed) >>> 0) || 1;
  const decoyKey = 1000 + (decoySeed % 89000);
  const metatable = `{__call=function(${self},...)return ${self}[${callableExpr}](${self},...)end,__metatable=false,[${decoyKey}]=${renderDecoyBlob(decoySeed)}}`;
  const colonTail = isColon ? `:${methodName}()` : "";
  return {
    source: `return setmetatable({${fieldSource}},${metatable})${colonTail}${invocation}`,
    plan
  };
}

module.exports = { createBootstrapPlan, renderCallableBootstrap, chooseSlots, chooseShape };

"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { detectTarget } = require("./src/core/target");

const lua = fs.readFileSync(path.join(__dirname, "examples", "input.lua"), "utf8");

const autoLua = obfuscate(lua, { target: "auto", preset: "default", seed: 0x2601 });
assert.strictEqual(autoLua.target, "lua");
assert.strictEqual(autoLua.runtime, "Lua 5.1-5.4 (auto-compatible)");
assert.strictEqual(autoLua.stats.engine, "ByteCode Polymorphic Source Engine v3.2");
assert(autoLua.output.includes("loadstring or load"));
assert(!autoLua.output.includes("_ENV"));
assert(autoLua.output.includes("25173+hi*257"));
assert(autoLua.output.includes("return "));

const roblox = 'local Players = game:GetService("Players")';
assert.strictEqual(detectTarget(roblox).target, "luau");
const autoRoblox = obfuscate(roblox, { target: "auto", preset: "default", seed: 0x2602 });
assert.strictEqual(autoRoblox.target, "luau");
assert.strictEqual(autoRoblox.runtime, "Luau v0.739");
assert.strictEqual(autoRoblox.stats.engine, "ByteCode Polymorphic Source Engine v3.2");
assert.strictEqual(autoRoblox.vmMeta.fallback, true);

const explicitLuau = obfuscate(lua, { target: "luau", preset: "default", seed: 0x2603 });
assert.strictEqual(explicitLuau.target, "luau");

console.log("ByteCode v2.9.0 target/engine test: PASS");

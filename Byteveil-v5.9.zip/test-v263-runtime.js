"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const cases = [
    {
        name: "lua-basic",
        target: "lua",
        source: `local function calculate(a,b) local total=a+b if total>10 then return total*2 end return total end local result=calculate(7,6) print("ByteCode v2.6.3:",result)`,
        expected: "ByteCode v2.6.3:\t26"
    },
    {
        name: "lua-closure-table",
        target: "lua",
        source: `local t={a=4,b=9};local function add(x)return x+t.a end;print(add(t.b))`,
        expected: "13"
    },
    {
        name: "luau-basic",
        target: "luau",
        source: `local function calculate(a,b) local total=a+b if total>10 then return total*2 end return total end local result=calculate(7,6) print("ByteCode v2.6.3:",result)`,
        expected: "ByteCode v2.6.3:\t26"
    },
    {
        name: "luau-native-features",
        target: "luau",
        source: `--!strict\nlocal function twice(x:number):number return x*2 end\nlocal value:number = 7\nvalue += 2\nlocal data = {value=value}\nprint("Luau v2.6.3:",twice(data.value))`,
        expected: "Luau v2.6.3:\t18"
    }
];

let luaExecutable = resolveRuntime("lua");
let luauExecutable = resolveRuntime("luau");
console.log("[runtime] lua:", luaExecutable || "NOT INSTALLED");
console.log("[runtime] luau:", luauExecutable || "NOT INSTALLED");

for (const c of cases) {
    const executable = c.target === "lua" ? luaExecutable : luauExecutable;
    const out = path.join(__dirname, "examples", `runtime-${c.name}.${c.target}`);
    const result = obfuscate(c.source, {
        target: c.target,
        preset: "default",
        seed: 0x26310000 + c.name.length,
        wrapper: { enabled: true, setmeta: true, returnMode: "setmetatable" },
        transforms: {}
    });
    fs.writeFileSync(out, result.output, "utf8");

    assert(result.output.includes("return setmetatable"), `${c.name}: wrapper`);
    assert(!result.output.includes("BCSZ"), `${c.name}: legacy BCSZ`);
    assert(!/string\.char\(U\(N\)\)/.test(result.output) || /\}\s*,\s*\{\d/.test(result.output), `${c.name}: payload marker`);

    if (!executable) {
        console.log(`[runtime] ${c.name}: SKIP (no native ${c.target} runtime)`);
        continue;
    }

    const syntax = runSyntaxCheck(executable, result.output, c.target);
    assert(syntax.ok, `${c.name}: syntax failed\n${syntax.stderr}`);

    const execution = runProgram(executable, result.output, c.target, c.expected);
    assert(execution.ok, `${c.name}: runtime failed\nstdout=${execution.stdout}\nstderr=${execution.stderr}`);
    console.log(`[runtime] ${c.name}: PASS -> ${execution.stdout}`);
}

console.log("ByteCode v2.6.3 runtime regression: PASS");

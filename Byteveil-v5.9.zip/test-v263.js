"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { lex } = require("./src/frontend/lexer");
const { validateGeneratedLuau } = require("./src/core/luau_sanity");

for (const [name,target] of [["v263-smoke.luau","luau"],["v263-smoke.lua","lua"]]) {
  const source = fs.readFileSync(path.join(__dirname,"examples",name),"utf8");
  const r = obfuscate(source,{target,preset:"default",wrapper:{enabled:true,setmeta:true,returnMode:"setmetatable"},seed:0x26300001,transforms:{sizeBuff:false}});
  assert.equal(r.target,target,name+": target");
  assert(r.output.includes("return setmetatable"),name+": setmetatable wrapper missing");
  assert(r.output.includes("payload integrity"),name+": payload integrity guard missing");
  assert(!r.output.includes("BCSZ_"),name+": legacy BCSZ padding leaked");
  assert(!r.output.includes("--[[BC:"),name+": legacy VM markers leaked");
  if(target === "luau") assert.doesNotThrow(()=>validateGeneratedLuau(r.output),name+": output sanity");
  else assert(r.output.includes("loadstring or load"),name+": portable loader missing");
  console.log(`${name}: PASS bytes=${r.stats.bytes}`);
}

const mini = obfuscate("local x=1;local y=2;print(x+y)",{target:"luau",preset:"default",wrapper:{enabled:true,setmeta:true,returnMode:"setmetatable"},seed:55,transforms:{sizeBuff:false,unknownCode:false,controlFlow:false,functionTransform:false}});
assert.doesNotThrow(()=>validateGeneratedLuau(mini.output));
const loop = obfuscate("local s=0;for i=1,5 do s=s+i end;print(s)",{target:"luau",preset:"default",wrapper:{enabled:true,setmeta:true,returnMode:"setmetatable"},seed:91,transforms:{sizeBuff:false}});
assert.equal(loop.target,"luau");
assert.equal(loop.stats.engine,"ByteCode Polymorphic Source Engine v3.2");
assert.equal(loop.stats.fallback,true);
assert(loop.output.includes("local-chunk")===false);

const noComments = obfuscate("print(1)",{target:"luau",preset:"default",wrapper:{enabled:true,setmeta:true,returnMode:"setmetatable"},seed:77,transforms:{}});
assert(!noComments.output.includes("--[[BCSZ_"));
assert(!noComments.output.includes("BCZS"));
assert(!/local __bc_pad_|local-chunk|call-closure|metatable-call/.test(noComments.output));
console.log("ByteCode v2.9.0 regression tests: PASS");

"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const cases = [
  {
    name: "luau-portable-subset",
    target: "luau",
    source: `local function add(a,b) return a+b end\nprint("v270-luau",add(7,8))`,
    expected: "v270-luau\t15"
  },
  {
    name: "lua",
    target: "lua",
    source: `local function add(a,b) return a+b end\nprint("v270-lua",add(7,8))`,
    expected: "v270-lua\t15"
  }
];

let ran = 0;
for (const c of cases) {
  const result = obfuscate(c.source, {
    target: c.target,
    preset: "default",
    seed: 0x2700F00D,
    transforms: { watermark: false }
  });
  const out = path.join(__dirname, "examples", `v270-runtime-${c.name}.${c.target}`);
  fs.writeFileSync(out, result.output, "utf8");
  assert(!/(?:--\[\[BCSZ_|--\[\[BCZS|BCZS[_:])/.test(result.output));

  const exe = resolveRuntime(c.target);
  if (!exe) {
    console.log(`[runtime] ${c.name}: SKIP (native ${c.target} not available on this host)`);
    continue;
  }
  const syntax = runSyntaxCheck(exe, result.output, c.target);
  assert(syntax.ok, `${c.name}: syntax failed\n${syntax.stderr}`);
  const execution = runProgram(exe, result.output, c.target, c.expected);
  assert(execution.ok, `${c.name}: runtime failed\nstdout=${execution.stdout}\nstderr=${execution.stderr}`);
  ran++;
  console.log(`[runtime] ${c.name}: PASS -> ${execution.stdout}`);
}
console.log(`ByteCode v3.2 runtime regression complete (executed=${ran})`);

"use strict";
const assert = require("assert");
const { detect } = require("./src/detect");
assert.strictEqual(detect("print('x')", "a.lua").target, "lua");
assert.strictEqual(detect("print('x')", "a.luau").target, "luau");
assert.strictEqual(detect("--!strict\nlocal x:number=1", "a.txt").target, "luau");
assert.strictEqual(detect("local x=1\nprint(x)", "a.txt").target, "lua");
console.log("ByteCode v2.9.0 detect regression: PASS");

"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const executable = resolveRuntime("luau");
if (!executable) {
  console.log("[v2.8 Luau native] SKIP: Luau executable not installed on this host.");
  process.exit(0);
}

const cases = [
  ["l1", `--!strict\nlocal function add(a:number,b:number):number\n  return a+b\nend\nprint("ByteCode l1", add(7,8))`, "ByteCode l1\t15"],
  ["l2", `--!strict\nlocal total:number=0\nfor i=1,5 do\n  total += i\nend\nprint("ByteCode l2", total)`, "ByteCode l2\t15"],
  ["df", `--!strict\nlocal function mul(a:number,b:number):number\n  return a*b\nend\nprint("ByteCode df", mul(3,5))`, "ByteCode df\t15"],
  ["lz", `--!strict\ntype Pair={a:number,b:number}\nlocal function sum(p:Pair):number\n  if p.b > 5 then return p.a+p.b end\n  return p.b\nend\nprint("ByteCode lz", sum({a=7,b=8}))`, "ByteCode lz\t15"]
];

for (const [preset, source, expected] of cases) {
  const result = obfuscate(source, {
    target: "luau",
    preset,
    filename: `v280-${preset}.luau`,
    seed: 0x28CC0000 + preset.length
  });
  const syntax = runSyntaxCheck(executable, result.output, "luau");
  assert(syntax.ok, `${preset}: native Luau syntax failed\n${syntax.stderr || syntax.stdout}`);
  const execution = runProgram(executable, result.output, "luau", expected);
  assert(execution.ok, `${preset}: native Luau runtime failed\nstdout=${execution.stdout}\nstderr=${execution.stderr}`);
  console.log(`[v2.8 Luau native] ${preset}: PASS -> ${execution.stdout}`);
}

console.log("ByteCode v2.8 native Luau syntax/runtime regression: PASS");

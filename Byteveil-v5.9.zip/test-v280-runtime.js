"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { validateGeneratedLuau } = require("./src/core/luau_sanity");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const luaCases = [
    ["l1", `local function add(a,b)return a+b end\nlocal t={x=add(7,8)}\nprint("ByteCode v2.8 Lua",t.x)`, "ByteCode v2.8 Lua\t15"],
    ["l2", `local function score(n)local s=0 for i=1,n do s=s+i end return s end\nprint("ByteCode v2.8 Lua",score(5))`, "ByteCode v2.8 Lua\t15"],
    ["lz", `local function f(x)local t={a=x,b=x*2}if t.b>10 then return t.a+t.b end return t.b end\nprint("ByteCode v2.8 Lua",f(6))`, "ByteCode v2.8 Lua\t18"]
];

const luauCases = [
    ["l1", `--!strict\nlocal function add(a:number,b:number):number return a+b end\nlocal value:number=add(7,8)\nprint("ByteCode v2.8 Luau",value)`, "ByteCode v2.8 Luau\t15"],
    ["l2", `--!strict\nlocal total:number=0\nfor i=1,5 do total+=i end\nprint("ByteCode v2.8 Luau",total)`, "ByteCode v2.8 Luau\t15"],
    ["lz", `--!strict\ntype Pair={a:number,b:number}\nlocal function f(x:number):number local t:Pair={a=x,b=x*2} if t.b>10 then return t.a+t.b end return t.b end\nprint("ByteCode v2.8 Luau",f(6))`, "ByteCode v2.8 Luau\t18"]
];

function runCases(target, cases) {
    const executable = resolveRuntime(target);
    console.log(`[runtime] ${target}: ${executable || "NOT INSTALLED"}`);
    for (const [preset, source, expected] of cases) {
        const result = obfuscate(source, {
            target,
            preset,
            seed: 0x28AA0000 + target.length * 0x1000 + preset.length,
            wrapper: { enabled: true }
        });
        const ext = target === "luau" ? "luau" : "lua";
        const file = path.join(__dirname, "examples", `v280-runtime-${preset}.${ext}`);
        fs.writeFileSync(file, result.output, "utf8");
        assert(!/(?:--\[\[BCSZ_|--\[\[BCZS|BCZS[_:])/.test(result.output), `${target}/${preset}: legacy junk marker`);
        assert(!/local __bc_pad_|local-chunk|call-closure|metatable-call/.test(result.output), `${target}/${preset}: generated junk must be absent`);
        assert(!/local __bc_key=\{[0-9,]{100,}\}/.test(result.output), `${target}/${preset}: giant key table`);
        if (target === "luau") {
            assert(!/\bdo;/.test(result.output), `${preset}: Luau regression: generated do; token`);
            const sanity = validateGeneratedLuau(result.output);
            assert(sanity.ok && sanity.delimiters, `${preset}: Luau generated-source sanity failed`);
            assert(Number.isInteger(sanity.codeSemicolons), `${preset}: Luau semicolon scan failed`);
            assert(!/enddo/.test(result.output), `${preset}: enddo tokenization regression`);
        }
        if (!executable) {
            console.log(`[runtime] ${target}/${preset}: SKIP (native runtime unavailable on this host)`);
            continue;
        }
        const syntax = runSyntaxCheck(executable, result.output, target);
        assert(syntax.ok, `${target}/${preset}: native syntax failed\n${syntax.stderr}`);
        const execution = runProgram(executable, result.output, target, expected);
        assert(execution.ok, `${target}/${preset}: native runtime failed\nstdout=${execution.stdout}\nstderr=${execution.stderr}`);
        console.log(`[runtime] ${target}/${preset}: PASS -> ${execution.stdout}`);
    }
}

runCases("lua", luaCases);
runCases("luau", luauCases);
console.log("ByteCode v2.8 native syntax/runtime regression: PASS");

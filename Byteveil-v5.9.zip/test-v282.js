"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { detect } = require("./src/detect");

assert.strictEqual(detect("print('x')", "a.lua").target, "lua");
assert.strictEqual(detect("print('x')", "a.luau").target, "luau", ".luau remains fallback-only for plain ambiguous code");
assert.strictEqual(detect("--!strict\nlocal x:number=1", "a.lua").target, "luau", "source Luau syntax must beat .lua extension");
assert.strictEqual(detect("local x=1\nprint(x)", "a.luau").target, "luau", ".luau fallback for ambiguous plain source");
assert.strictEqual(detect("local x=1\nprint(x)", "a.txt").target, "lua");
assert.strictEqual(detect("local x:number=1", "a.txt").target, "luau");
assert.strictEqual(detect("local total=0\ntotal += 1", "a.lua").target, "luau");

const botCommands = fs.readFileSync(path.join(__dirname, "bot/src/commands.js"), "utf8");
assert(botCommands.includes('setName("obf")'));
assert(botCommands.includes('setName("help")'));
assert(botCommands.includes('setName("rule")'));
assert(!botCommands.includes('setName("rules")'));
assert(botCommands.includes('o.setName("presets")'));
assert(botCommands.includes('o.setName("attach")'));
assert(botCommands.includes('o.setName("input")'));
assert(botCommands.includes('o.setName("upload")'));
assert(!botCommands.includes('o.setName("target")'));
assert(botCommands.includes('{ name: "code", value: "code" }'));
assert(botCommands.includes('{ name: "file", value: "file" }'));
assert(botCommands.includes('{ name: "url", value: "url" }'));

const botIndex = fs.readFileSync(path.join(__dirname, "bot/src/index.js"), "utf8");
assert(botIndex.includes("InteractionCreate"));
assert(!botIndex.includes("MessageContent"));
assert(!botIndex.includes("MessageCreate"));

console.log("ByteCode v2.8.2-compatible source-first detect + slash schema: PASS");

"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { validateGeneratedLuau } = require("./src/core/luau_sanity");
const { runProgram } = require("./tools/native-runtime");

const lua = `local function make(n)local t={name="ByteCode",value=n};local function add(a,b)return a+b end;return t,add(t.value,9) end\nlocal t,v=make(6)\nprint(t.name,v)`;
const luau = `--!strict\ntype Pair={name:string,value:number}\nlocal function make(n:number):(Pair,number)local t:Pair={name="ByteCode",value=n};local function add(a:number,b:number):number return a+b end;return t,add(t.value,9) end\nlocal t,v=make(6)\nprint(t.name,v)`;

for (const target of ["lua", "luau"]) {
    for (const preset of ["l1", "l2", "lz"]) {
        const source = target === "luau" ? luau : lua;
        const result = obfuscate(source, {
            target,
            preset,
            seed: 0x29AA1020 + preset.length,
            wrapper: { enabled: true }
        });

        assert.strictEqual(result.stats.engine, "ByteCode Polymorphic Source Engine v3.2");
        assert.strictEqual(result.vmMeta.version, "3.2.0");
        assert.strictEqual(result.vmMeta.runtimeBaseVersion, "2.9.0");
        assert.strictEqual(result.vmMeta.hardeningVersion, "3.2-layered-semantic-hardening");
        assert(!result.output.includes("local __bc_key={"), `${target}/${preset}: legacy key table`);
        assert(!result.output.includes("unknown_code_inserter"), `${target}/${preset}: junk inserter`);
        assert(!result.output.includes("SizeBuff"), `${target}/${preset}: size buff marker`);
        assert(!result.output.includes("BCSZ_"), `${target}/${preset}: legacy padding marker`);
        assert(!result.output.includes("BCZS"), `${target}/${preset}: legacy padding marker`);
        assert.strictEqual((result.stats.junkCount || 0), 0);
        assert.strictEqual(result.vmMeta.containerDecoys > 0, preset === "lz");
        assert(result.stats.cleanOutput === true);
        assert(!/\bdo;|\bthen;|\belse;/.test(result.output));
        // Semicolons may legitimately occur inside encoded alphabet strings; the
        // generated statement stream itself must not use semicolon separators.
        assert(!/;(?=[A-Za-z_])/m.test(result.output.replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g, "")), `${target}/${preset}: semicolon statement separator`);

        if (target === "luau") {
            const sanity = validateGeneratedLuau(result.output);
            assert(sanity.ok && sanity.delimiters, `${target}/${preset}: generated Luau sanity failed`);
        }

        const file = path.join(__dirname, "examples", `v290-${preset}.${target === "luau" ? "luau" : "lua"}`);
        fs.writeFileSync(file, result.output, "utf8");

        if (target === "lua") {
            const run = runProgram(path.join(__dirname, "tools", "lua54-runner"), result.output, "lua", "ByteCode\t15");
            assert(run.ok, `${target}/${preset}: runtime failed\n${run.stderr}`);
        }
    }
}

// Bot schema is tested when the optional Discord integration is present.
const commandsPath = path.join(__dirname, "bot", "src", "commands.js");
if (fs.existsSync(commandsPath)) {
    const commands = fs.readFileSync(commandsPath, "utf8");
    assert(commands.includes('setName("obf")'));
    assert(commands.includes('{ name: "code", value: "code" }'));
    assert(commands.includes('{ name: "file", value: "file" }'));
    assert(commands.includes('{ name: "url", value: "url" }'));
    assert(!commands.includes('o.setName("target")'));
    assert(commands.includes("ByteCode v3.2.0"));
}

console.log("ByteCode v3.2 semantic/VM hardening + runtime regression: PASS");

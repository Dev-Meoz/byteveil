"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");
const { obfuscate, getPreset } = require("./src");
const { parse } = require("./src/frontend/parser");
const { build } = require("./src/customVM");
const { roundTripTransform } = require("./src/backend/bytecode_serializer");
const { validateGeneratedLuau } = require("./src/core/luau_sanity");
const { validateBytecode } = require("./src/ironbrew/validator");

const luaRunner = path.join(__dirname, "tools", "lua54-runner");
assert.ok(fs.existsSync(luaRunner), "Lua 5.4 runner missing");

function runLua(source, label) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "bytecode-v32-"));
    const file = path.join(dir, `${label}.lua`);
    fs.writeFileSync(file, source, "utf8");
    try {
        return execFileSync(luaRunner, [file], {
            encoding: "utf8",
            stdio: ["ignore", "pipe", "pipe"]
        }).trim();
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
}

// Parser regression: parse(string) must actually lex source instead of returning an empty Chunk.
const parsed = parse('local x=2;print(x)');
assert.strictEqual(parsed.type, "Chunk");
assert.strictEqual(parsed.body.length, 2);

// Binary payload transform must be reversible for multiple seeds and edge bytes.
for (const seed of [0, 1, 0x12345678, 0xFFFFFFFF]) {
    assert.strictEqual(
        roundTripTransform(Buffer.from([0, 1, 2, 31, 127, 128, 200, 255]), seed),
        true,
        `transform roundtrip failed for seed ${seed}`
    );
}

assert.strictEqual(getPreset("default").strength, 1000);
assert.strictEqual(getPreset("maximum").strength, 10000);

const source = 'local x=0;for i=1,3 do x=x+i end;print("V32",x)';
for (const [label, strength, expectedRounds] of [["default", 1000, 1], ["maximum", 10000, 4]]) {
    const result = obfuscate(source, {
        target: "lua",
        preset: label,
        seed: 0x3200CAFE,
        wrapper: { enabled: false },
        transforms: { watermark: false }
    });
    assert.strictEqual(result.vmMeta.version, "3.2.0");
    assert.strictEqual(result.vmMeta.strength, strength);
    assert.strictEqual(result.vmMeta.transformRounds, expectedRounds);
    assert.strictEqual(result.stats.errors, 0);
    assert.strictEqual(runLua(result.output, `native-${label}`), "V32\t6");
    assert(!result.output.includes('local x=0;for i=1,3'), `${label}: plaintext source leaked`);
}

const maxLarge = obfuscate(`${source}\n${"-- padding\n".repeat(300)}`, {
    target: "lua",
    strength: 10000,
    seed: 0x3200BEEF,
    wrapper: { enabled: false },
    transforms: { watermark: false }
});
assert(maxLarge.vmMeta.containerDecoys > 0, "maximum strength should add inert payload decoys");
assert(maxLarge.output.length > 0);
assert(validateGeneratedLuau(maxLarge.output).ok !== false, "Lua/Luau syntax sanity failed on max profile");

const vmCases = [
    ["basic", 'local x=4+5;print("VM",x)', "VM\t9.0"],
    ["if", 'local x=1;if x then print("yes") else print("no") end', "yes"],
    ["while", 'local x=0;while x<3 do print(x);x=x+1 end', "0.0\n1.0\n2.0"],
    ["fornum", 'for i=1,3 do print(i) end', "1.0\n2.0\n3.0"],
    ["table", 'local t={1,2,x=3};print(t[1],t.x)', "1.0\t3.0"],
    ["closure", 'local x=2;local function f() x=x+3; return x end;print(f(),f())', "5.0\t8.0"],
    ["shortcircuit", 'local x=0;local function inc() x=x+1;return true end;local a=false and inc();local b=true or inc();print(x,a,b)', "0.0\tfalse\ttrue"],
    ["method", 'local t={f=function(self,x)return self.v+x end,v=5};print(t:f(7))', "12.0"],
    ["bitwise", 'print(~0,5 & 3,5 | 2,5 ~ 3)', "-1\t1\t7\t6"]
];

for (const mode of ["stack", "register"]) {
    for (const [label, input, expected] of vmCases) {
        const compiled = build(parse(input), { mode, seed: 0x32001234 });
        assert.strictEqual(compiled.compiled.validation.ok, true, `${mode}/${label}: validator failed`);
        assert.strictEqual(validateBytecode(compiled.bytecode).ok, true, `${mode}/${label}: bytecode invalid`);
        assert.strictEqual(runLua(compiled.output, `vm-${mode}-${label}`), expected, `${mode}/${label}: runtime mismatch`);
    }
}

console.log("ByteCode v3.2 semantic/runtime/VM regression suite: PASS");

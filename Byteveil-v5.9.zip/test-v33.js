"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { runSyntaxCheck, runProgram, resolveRuntime } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runner missing");

const cases = [
  ["basic", `local x=4+5;print("VM",x)`, "VM\t9.0"],
  ["sample", `local name="Phucbeo";local age="IDK";print("Dear",name,age)`, "Dear\tPhucbeo\tIDK"],
  ["fornum", `local x=0;for i=1,3 do x=x+i end;print("V33",x)`, "V33\t6.0"],
  ["closure", `local x=2;local function f() x=x+3;return x end;print(f(),f())`, "5.0\t8.0"]
];

for (const mode of ["stack", "register"]) {
  for (const [name, source, expected] of cases) {
    const result = obfuscate(source, {
      target: "lua",
      mode,
      preset: "maximum",
      backend: "vm33",
      seed: 0x33000000 + mode.length + name.length,
      wrapper: { enabled: false },
      transforms: { watermark: false }
    });
    assert.strictEqual(result.vmMeta?.backend, "custom-vm");
    assert.strictEqual(result.vmMeta?.strict, true);
    assert.strictEqual(result.vmMeta?.version, "3.3.0");
    assert.strictEqual(result.stats?.hasPlainSource, false);
    assert(!result.output.includes(source), `${mode}/${name}: source leaked`);
    assert(!result.output.includes("ByteCode payload integrity failed"), `${mode}/${name}: legacy diagnostic leaked`);
    assert(!result.output.includes("S.pc"), `${mode}/${name}: fixed state key leaked`);
    assert(!result.output.includes("S.stack"), `${mode}/${name}: fixed state key leaked`);
    assert(!result.output.includes("S.consts"), `${mode}/${name}: fixed state key leaked`);

    const syntax = runSyntaxCheck(lua, result.output, "lua");
    assert.ok(syntax.ok, `${mode}/${name}: syntax failed\n${syntax.stderr}`);
    const run = runProgram(lua, result.output, "lua", expected);
    assert.ok(run.ok, `${mode}/${name}: runtime failed\nstdout=${run.stdout}\nstderr=${run.stderr}`);
    console.log(`v3.3/${mode}/${name}: PASS bytes=${result.output.length}`);
  }
}

const a = obfuscate(cases[1][1], { target: "lua", mode: "register", backend: "vm33", preset: "maximum", seed: 1, wrapper: { enabled:false }, transforms:{watermark:false} }).output;
const b = obfuscate(cases[1][1], { target: "lua", mode: "register", backend: "vm33", preset: "maximum", seed: 2, wrapper: { enabled:false }, transforms:{watermark:false} }).output;
assert.notStrictEqual(a, b, "different seeds must produce different VM artifacts");


const wrapped = obfuscate(cases[1][1], {
  target: "lua",
  mode: "register",
  preset: "maximum",
  backend: "vm33",
  seed: 0x33AA55,
  wrapper: { enabled: true, setmeta: true },
  transforms: { watermark: false }
}).output;
assert(/^do return setmetatable\(\{\[\d+\]=function\(/.test(wrapped), "v3.3: legacy setmetatable wrapper missing");
assert(!/[\r\n]/.test(wrapped), "v3.3: wrapped output was not minified to one line");
const wrappedRun = runProgram(lua, wrapped, "lua", cases[1][2]);
assert.ok(wrappedRun.ok, `wrapped sample runtime failed\nstdout=${wrappedRun.stdout}\nstderr=${wrappedRun.stderr}`);
console.log(`v3.3/wrapper: PASS bytes=${wrapped.length}`);

console.log("ByteVeil v3.3 core VM regression: PASS");

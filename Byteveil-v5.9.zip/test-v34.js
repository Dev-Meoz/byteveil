"use strict";
const assert = require("assert");
const { obfuscate } = require("./src");
const { runSyntaxCheck, runProgram, resolveRuntime } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua runner missing");

const cases = [
  ["basic", `local x=4+5;print("VM",x)`, "VM\t9.0"],
  ["sample", `local name="Phucbeo";local age="IDK";print("Dear",name,age)`, "Dear\tPhucbeo\tIDK"],
  ["fornum", `local x=0;for i=1,3 do x=x+i end;print("V34",x)`, "V34\t6.0"],
  ["closure", `local x=2;local function f() x=x+3;return x end;print(f(),f())`, "5.0\t8.0"],
  ["scope", `local x=1;do local x=2;assert(x==2) end;print("scope",x)`, "scope\t1.0"],
  ["table", `local t={};t["x"]=12;print("table",t["x"])`, "table\t12.0"],
  ["boolean", `local a=(1~=2) and true or false;print("bool",a)`, "bool\ttrue"],
  ["longstring-bang", `local s=[[hello ! ByteVeil]];print("long",s)`, "long\thello ! ByteVeil"],
  ["longstring-level", `local s=[=[line 1\nline ! 2]=];print(s)`, "line 1\nline ! 2"]
];

const WM = "--This file was protected using Byteveil Obfuscator [https://discord.gg/tBSS6Z6J6/]";

const { lex } = require('./src/frontend/lexer');

const lexerRegression = [
  ['--!strict\nlocal x=1', 0],
  ['local s=[[hello ! ByteVeil]];print(s)', 0],
  ['local s=[=[line 1\nline ! 2]=];print(s)', 0],
  ['--[[ comment ! ]]\nlocal x=2', 0],
  ['--[=[ comment ! ]=]\nlocal x=3', 0]
];

for (const [source, errorCount] of lexerRegression) {
  const r = lex(source);
  assert.strictEqual(r.errors.length, errorCount, `lexer regression failed: ${JSON.stringify(source)}`);
}
assert.strictEqual(lex('local x=!true').errors[0]?.message, 'Unexpected character !');


for (const mode of ["stack", "register"]) {
  for (const [name, source, expected] of cases) {
    const result = obfuscate(source, {
      target: "lua",
      mode,
      preset: "maximum",
      backend: "vm33",
      seed: 0x34000000 + mode.length * 100 + name.length,
      wrapper: { enabled: false }
    });

    assert.strictEqual(result.vmMeta?.backend, "custom-vm");
    assert.strictEqual(result.vmMeta?.version, "3.4.0");
    assert.strictEqual(result.vmMeta?.opcodeWhitening, true);
    assert.strictEqual(result.stats?.engine, "ByteVeil Custom VM v3.4");
    assert.strictEqual(result.stats?.watermark, WM);
    assert(result.output.startsWith(WM + "\n"), `${mode}/${name}: watermark missing`);
    assert(!result.output.includes(source), `${mode}/${name}: source leaked`);
    assert(!result.output.includes("__bc_band"), `${mode}/${name}: fixed helper signature leaked`);
    assert(!result.output.includes("__bc_payload_check"), `${mode}/${name}: fixed integrity helper leaked`);
    assert(!result.output.includes("\\039\\087\\009"), `${mode}/${name}: fixed key pattern leaked`);
    assert(!result.output.includes("S.pc"), `${mode}/${name}: fixed state key leaked`);
    assert(!result.output.includes("S.stack"), `${mode}/${name}: fixed state key leaked`);
    assert(!result.output.includes("S.consts"), `${mode}/${name}: fixed state key leaked`);

    const syntax = runSyntaxCheck(lua, result.output, "lua");
    assert.ok(syntax.ok, `${mode}/${name}: syntax failed\n${syntax.stderr}`);
    const run = runProgram(lua, result.output, "lua", expected);
    assert.ok(run.ok, `${mode}/${name}: runtime failed\nstdout=${run.stdout}\nstderr=${run.stderr}`);
  }
}

const a = obfuscate(cases[1][1], { target: "lua", mode: "register", backend: "vm33", preset: "maximum", seed: 1, wrapper: {enabled:false} }).output;
const b = obfuscate(cases[1][1], { target: "lua", mode: "register", backend: "vm33", preset: "maximum", seed: 2, wrapper: {enabled:false} }).output;
assert.notStrictEqual(a, b, "different seeds must produce different VM artifacts");

const wrapped = obfuscate(cases[1][1], {
  target: "lua",
  mode: "register",
  preset: "maximum",
  backend: "vm33",
  seed: 0x33AA55,
  wrapper: { enabled: true, setmeta: true }
}).output;
assert(wrapped.startsWith(WM + "\n"), "v3.4: wrapped watermark missing");
const wrappedBody = wrapped.slice(WM.length + 1);
assert(!/[\r\n]/.test(wrappedBody), "v3.4: wrapped body was not minified to one line");
const wrappedRun = runProgram(lua, wrapped, "lua", cases[1][2]);
assert.ok(wrappedRun.ok, `wrapped sample runtime failed\nstdout=${wrappedRun.stdout}\nstderr=${wrappedRun.stderr}`);

console.log("ByteVeil v3.4 syntax/runtime + hardening regression: PASS");

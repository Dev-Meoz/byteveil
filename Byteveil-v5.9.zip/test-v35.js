"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { detect, detectLuaVersions } = require("./src/detect");
const { lex } = require("./src/frontend/lexer");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 validation runner missing");

const WATERMARK = "--This file was protected using ByteVeil Obfuscator v3.8 [https://discord.gg/tBSS6Z6J6/]";

function build(source, extra = {}) {
  return obfuscate(source, {
    preset: "maximum",
    target: "auto",
    seed: extra.seed ?? 0x35A11CE,
    mode: extra.mode || "stack",
    wrapper: { enabled: false },
    transforms: { watermark: { enabled: true }, ...(extra.transforms || {}) },
    ...extra.options
  });
}

function assertProtectedShape(result, label) {
  assert.ok(result.output.startsWith(WATERMARK + "\n"), `${label}: watermark missing`);
  assert.ok(!/string\.char/.test(result.output), `${label}: string.char leaked`);
  assert.ok(!result.output.includes("__bc_band"), `${label}: legacy helper leaked`);
  assert.ok(!result.output.includes("__bc_payload_check"), `${label}: legacy integrity helper leaked`);
  assert.ok(!/local\s+M\s*=\s*\{/.test(result.output), `${label}: central codec map leaked`);
  assert.ok(!/\["ByteVeil Obfuscator 1"\]/.test(result.output), `${label}: centralized metadata leaked`);
  assert.ok(result.vmMeta?.arithmeticProtection === false, `${label}: arithmetic protection must remain disabled`);
  if (result.vmMeta?.backend === "structural-source") {
    assert.strictEqual(result.vmMeta?.antiTamper, true, `${label}: source anti-tamper missing`);
    assert.strictEqual(result.vmMeta?.antiHook, true, `${label}: source anti-hook missing`);
    assert.strictEqual(result.vmMeta?.controlFlow, true, `${label}: source control-flow graph missing`);
  }
  assert.ok(!result.output.includes("ByteCode Polymorphic"), `${label}: old engine marker leaked`);
}

function nativeGolden(source, result, label) {
  const originalCheck = runSyntaxCheck(lua, source, "lua");
  assert.ok(originalCheck.ok, `${label}: original source syntax failed\n${originalCheck.stderr}`);
  const originalRun = runProgram(lua, source, "lua");
  assert.ok(originalRun.ok, `${label}: original source runtime failed\n${originalRun.stderr}`);

  const protectedCheck = runSyntaxCheck(lua, result.output, "lua");
  assert.ok(protectedCheck.ok, `${label}: protected syntax failed\n${protectedCheck.stderr}`);
  const protectedRun = runProgram(lua, result.output, "lua", originalRun.stdout);
  assert.ok(protectedRun.ok, `${label}: protected runtime mismatch\nexpected=${originalRun.stdout}\nactual=${protectedRun.stdout}\nstderr=${protectedRun.stderr}`);
}

// -------------------------------------------------------------------------
// Lexer / parser regressions from v3.4, plus syntax that previously escaped.
// -------------------------------------------------------------------------
const lexerCases = [
  ["local t={[\"x\"]=1,[2]=3,a=4,5,}", 0],
  ["local t=[=[hello ! { [ x ] }]=]", 0],
  ["--[[ comment ! [=[ nested-looking ]=] ]]\nlocal x=1", 0],
  ["--!strict\nlocal x=1", 0],
  ["local x=\"\\065\\066\\x43\\u{44}\"", 0],
  ["local x=0b1010;local y=1_000;local z=.5", 0],
  ["local x=0x1.fp2", 0],
  ["local x=`hello {name}!`", 0],
  ["@native function f() return 1 end", 0]
];
for (const [source, expectedErrors] of lexerCases) {
  const out = lex(source);
  assert.strictEqual(out.errors.length, expectedErrors, `lexer failed: ${JSON.stringify(source)} -> ${JSON.stringify(out.errors)}`);
}
assert.strictEqual(lex("local x=!true").errors[0]?.message, "Unexpected character !");
assert.strictEqual(lex("local x=[[unterminated").errors[0]?.message, "Unterminated long string");

// The exact regression reported by Discord: a keyed table field beginning with '['.
const exactRegression = "local t={[1]={name=\"ok\",[2]=3}, [3]=4}; print(t[1].name,t[1][2],t[3])";
for (const mode of ["stack", "register"]) {
  const result = build(exactRegression, { mode, seed: 0x350001 + mode.length });
  assertProtectedShape(result, `table/${mode}`);
  nativeGolden(exactRegression, result, `table/${mode}`);
}

// -------------------------------------------------------------------------
// Native Lua golden tests. Every result is compared to the original runtime.
// -------------------------------------------------------------------------
const runtimeCases = [
  ["arithmetic", `local x=7*3+2;local y=x//4;print(x,y)`],
  ["comparison", `local a=(1~=2)and(4<=4);local b=(9>2)or false;print(a,b)`],
  ["table", `local t={1,2,a=3,[4]=5};t[\"x\"]=12;print(t[1],t.a,t[4],t.x)`],
  ["nested-table", `local t={a={b=1},[{\"x\"}]=2};print(t.a.b)`],
  ["closure", `local x=2;local function f()x=x+3;return x end;print(f(),f())`],
  ["scope", `local x=1;do local x=2;assert(x==2)end;print(x)`],
  ["if", `local x=3;if x==1 then print(1)elseif x==3 then print(3)else print(0)end`],
  ["while", `local x=0;while x<3 do x=x+1 end;print(x)`],
  ["for", `local x=0;for i=1,5 do x=x+i end;print(x)`],
  ["long-string", `local s=[[hello ! ByteVeil]];print(s)`],
  ["long-string-level", `local s=[==[line ! [ ] == ]==];print(s)`],
  ["escapes", `local s="\\065\\066\\x43\\u{44}!";print(s)`]
];
for (const mode of ["stack", "register"]) {
  for (const [name, source] of runtimeCases) {
    const result = build(source, { mode, seed: (0x35AA0000 ^ name.length ^ mode.length) >>> 0 });
    assertProtectedShape(result, `${mode}/${name}`);
    nativeGolden(source, result, `${mode}/${name}`);
  }
}

// -------------------------------------------------------------------------
// Semantic hazards deliberately route to the structural source protector.
// This is preferable to emitting a VM artifact with known multireturn/break bugs.
// -------------------------------------------------------------------------
const sourceRouteCases = [
  ["break", `local x=0;for i=1,5 do if i==3 then break end;x=x+i end;print(x)`],
  ["vararg", `local function f(...)return select(\"#\",...)end;print(f(1,2,3))`],
  ["multireturn", `local function f()return 1,2 end;local a,b=f();print(a,b)`],
  ["method", `local T={};function T:add(x)return x+1 end;print(T:add(2))`],
  ["dotted-function", `local T={};T.N={};function T.N:f(x)return x+2 end;print(T.N:f(3))`],
  ["hex-float", `local x=0x1.fp2;print(x)`]
];
for (const [name, source] of sourceRouteCases) {
  const result = build(source, { target: "lua", seed: 0x35BB0000 + name.length });
  assertProtectedShape(result, `route/${name}`);
  assert.strictEqual(result.vmMeta?.backend, "structural-source", `route/${name}: unsafe source entered strict VM`);
  nativeGolden(source, result, `route/${name}`);
}

// Luau-only syntax is accepted by the lexer/parser frontend and routed to the source protector.
const luauCases = [
  ["strict", `--!strict\nlocal value:number=7;value+=2;print(value)`],
  ["attr", `@native function add(a:number,b:number):number return a+b end;print(add(2,3))`],
  ["interp", 'local x=7;local s=`value {x}!`;print(s)'],
  ["generic", `type Box<T>={value:T}\nlocal box:Box<number>={value=4}\nprint(box.value)`],
  ["continue", `local x=0;for i=1,3 do if i==2 then continue end;x=x+i end;print(x)`]
];
for (const [name, source] of luauCases) {
  const result = build(source, { target: "auto", seed: 0x35CC0000 + name.length });
  assertProtectedShape(result, `luau/${name}`);
  assert.strictEqual(result.target, "luau", `luau/${name}: auto detector picked ${result.target}`);
  assert.strictEqual(result.vmMeta?.backend, "structural-source", `luau/${name}: unsupported Luau syntax entered VM`);
}

// -------------------------------------------------------------------------
// v3.8 VM semantic regressions: function creation/return, globals, parallel
// assignment, and unsafe integer fallback.
// -------------------------------------------------------------------------
const parsedParallel = require("./src/frontend/parser").parse("local a,b=1,2;a,b=b,a");
assert.strictEqual(parsedParallel.body[1]?.type, "Assign", "v3.8 parser must accept parallel assignment");
assert.strictEqual(parsedParallel.body[1]?.vars?.length, 2, "v3.8 parser lost a parallel-assignment target");

for (const mode of ["stack", "register"]) {
  const fnSource = `local function f() return 3 end;local x=f();print(x)`;
  const fnResult = build(fnSource, { mode, seed: 0x37FA0001 + mode.length });
  assertProtectedShape(fnResult, `${mode}/function-return`);
  nativeGolden(fnSource, fnResult, `${mode}/function-return`);

  const globalSource = `_G.ByteVeilV37Probe=41;function f() return ByteVeilV37Probe end;ByteVeilV37Probe=42;print(f(),_G.ByteVeilV37Probe)`;
  const globalResult = build(globalSource, { mode, seed: 0x37FA0002 + mode.length });
  assertProtectedShape(globalResult, `${mode}/global-env`);
  nativeGolden(globalSource, globalResult, `${mode}/global-env`);

  const parallelSource = `local a,b=1,2;a,b=b,a;print(a,b)`;
  const parallelResult = build(parallelSource, { mode, seed: 0x37FA0003 + mode.length });
  assertProtectedShape(parallelResult, `${mode}/parallel-assignment`);
  nativeGolden(parallelSource, parallelResult, `${mode}/parallel-assignment`);

  const duplicateTarget = `local a=0;a,a=1,2;print(a)`;
  const duplicateResult = build(duplicateTarget, { mode, seed: 0x37FA0004 + mode.length });
  assertProtectedShape(duplicateResult, `${mode}/duplicate-target`);
  assert.strictEqual(duplicateResult.vmMeta?.backend, "structural-source", `${mode}/duplicate-target: unsafe repeated target entered strict VM`);
  nativeGolden(duplicateTarget, duplicateResult, `${mode}/duplicate-target`);

  const largeInteger = `local x=9007199254740993;print(x)`;
  const largeResult = build(largeInteger, { mode, seed: 0x37FA0005 + mode.length });
  assertProtectedShape(largeResult, `${mode}/large-integer`);
  assert.strictEqual(largeResult.vmMeta?.backend, "structural-source", `${mode}/large-integer: unsafe integer entered strict VM`);
  nativeGolden(largeInteger, largeResult, `${mode}/large-integer`);
  assert.strictEqual(largeResult.vmMeta?.version, "3.8.0", `${mode}/large-integer: source fallback metadata is stale`);
}

// -------------------------------------------------------------------------
// Auto-detection/version-family checks.
// -------------------------------------------------------------------------
assert.strictEqual(detect("--!strict\nlocal x=1").target, "luau");
assert.strictEqual(detect("local x=1;goto done;::done::").target, "lua");
assert.deepStrictEqual(detectLuaVersions("local x=1").sort(), ["5.1","5.2","5.3","5.4"]);
assert.deepStrictEqual(detectLuaVersions("local x=7//2").sort(), ["5.3","5.4"]);
assert.deepStrictEqual(detectLuaVersions("goto done;::done::").sort(), ["5.2","5.3","5.4"]);
assert.deepStrictEqual(detectLuaVersions("local x <close> = io.stdin").sort(), ["5.4"]);
assert.strictEqual(detect("local s=`hello {x}`").target, "luau");
assert.strictEqual(detect("@native function f()end").target, "luau");

// -------------------------------------------------------------------------
// Randomized structural VM: same seed is reproducible; different seed changes layout.
// -------------------------------------------------------------------------
const seedSource = `local x=4+5;local t={[1]=x,a=\"secret-token\"};print(t[1],t.a)`;
const seedA = build(seedSource, { mode: "register", seed: 0x35111111 });
const seedA2 = build(seedSource, { mode: "register", seed: 0x35111111 });
const seedB = build(seedSource, { mode: "register", seed: 0x35222222 });
assert.strictEqual(seedA.output, seedA2.output, "same seed must reproduce identical artifact");
assert.notStrictEqual(seedA.output, seedB.output, "different seeds must change structural artifact");
assertProtectedShape(seedA, "seed/a");
assertProtectedShape(seedB, "seed/b");

// Every v3.8 preset must honor the same protected-output invariants.
for (const preset of ["l1", "l2", "df", "lz", "default", "maximum"]) {
  const result = obfuscate(`local x=4;local t={[1]=x,a="preset"};print(t[1],t.a)`, {
    target: "lua", preset, seed: 0x35EE0000 + preset.length, wrapper: { enabled: false },
    transforms: { watermark: { enabled: true } }
  });
  assertProtectedShape(result, `preset/${preset}`);
  assert.strictEqual(result.vmMeta?.version, "3.8.0", `preset/${preset}: legacy backend selected`);
}

// -------------------------------------------------------------------------
// Wrapper regression.
// -------------------------------------------------------------------------
const wrapped = obfuscate(`local x=7;print("wrapped",x)`, {
  target: "lua",
  preset: "maximum",
  seed: 0x35DD1234,
  wrapper: { enabled: true, setmeta: true, invoke: true },
  transforms: { watermark: { enabled: true } }
});
assertProtectedShape(wrapped, "wrapper");
assert.ok(runSyntaxCheck(lua, wrapped.output, "lua").ok, "wrapper syntax failed");
const wrappedRun = runProgram(lua, wrapped.output, "lua", "wrapped\t7");
assert.ok(wrappedRun.ok, `wrapper runtime failed: ${wrappedRun.stderr}`);

// -------------------------------------------------------------------------
// Static artifact safety checks over every JavaScript source file.
// -------------------------------------------------------------------------
const jsFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (entry.name.endsWith(".js")) jsFiles.push(file);
  }
}
walk(path.join(__dirname, "src"));
for (const file of jsFiles) {
  const text = fs.readFileSync(file, "utf8");
  assert.ok(!text.includes("TODO_STUB"), `${file}: stub marker found`);
  assert.ok(!text.includes("IMPLEMENT_ME"), `${file}: placeholder marker found`);
}

console.log("ByteVeil v3.8 compatibility syntax/runtime/protection regression: PASS");
console.log(`Lua runner: ${lua}`);
console.log(`Checked JS source files: ${jsFiles.length}`);
console.log(`Golden runtime cases: ${runtimeCases.length * 2 + sourceRouteCases.length}`);
console.log("Protected-output invariant: string.char absent");
console.log("Protected-output invariant: arithmeticProtection=false");
console.log("Protection architecture: randomized structural VM + structural source protector");

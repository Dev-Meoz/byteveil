"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");
const { audit } = require("./src/protection/access_shape");

const WATERMARK = "--This file was protected using ByteVeil Obfuscator v4.5.2 [https://discord.gg/rAhAnnkBn8/]";
const presets = ["l1", "l2", "df", "lz"];
const modes = ["stack", "register"];

function build(source, preset, mode, target, seed) {
    return obfuscate(source, {
        source,
        preset,
        mode,
        target,
        seed,
        wrapper: { enabled: false },
        transforms: { watermark: { enabled: true, text: WATERMARK.slice(2) } }
    });
}

const lua = resolveRuntime("lua");
if (!lua) {
    console.log("[native] Lua: SKIP (no compatible native Lua executable)");
    process.exit(0);
}

const source = `local users={"Cheem","Astra","ByteVeil"};local function greet(name)return "Hello, "..name end;for i,name in ipairs(users) do if i==2 then print(greet(name)) end end`;
const expected = "Hello, Astra";
let failures = 0;
let minBracketReduction = Infinity;

for (const mode of modes) {
    for (const preset of presets) {
        const result = build(source, preset, mode, "lua", 0x43000000 ^ mode.length ^ preset.length);
        assert.strictEqual(result.vmMeta?.version, "4.5.2");
        assert.strictEqual(result.vmMeta?.fallback, false);
        assert.ok(result.output.startsWith(WATERMARK + "\n"));

        const syntax = runSyntaxCheck(lua, result.output, "lua");
        const run = runProgram(lua, result.output, "lua", expected);
        const shape = audit(result.output);
        const staticKeyedFunctions = shape.keyedFunctions;

        if (!syntax.ok || !run.ok) {
            failures++;
            console.error(`[native] lua/${mode}/${preset}: FAIL`);
            console.error(`syntax=${syntax.stderr || syntax.error || "ok"}`);
            console.error(`runtime=${run.stderr || run.error || `expected ${expected}, got ${run.stdout}`}`);
            continue;
        }

        minBracketReduction = Math.min(minBracketReduction, staticKeyedFunctions);
        console.log(`[native] lua/${mode}/${preset}: PASS output=${result.output.length} keyed-functions=${staticKeyedFunctions}`);
    }
}

const luau = resolveRuntime("luau");
if (!luau) {
    console.log("[native] Luau: SKIP on this host (bundled native Luau executable is Windows-only; no native Luau is installed in PATH)");
} else {
    const luauSource = `local users={"Cheem","Astra"};for _,name in users do print(name) end`;
    for (const mode of modes) {
        for (const preset of presets) {
            const result = build(luauSource, preset, mode, "luau", 0x43010000 ^ mode.length ^ preset.length);
            const syntax = runSyntaxCheck(luau, result.output, "luau");
            const run = runProgram(luau, result.output, "luau", "Cheem\nAstra");
            if (!syntax.ok || !run.ok) {
                failures++;
                console.error(`[native] luau/${mode}/${preset}: FAIL`);
                console.error(`syntax=${syntax.stderr || syntax.error || "ok"}`);
                console.error(`runtime=${run.stderr || run.error || `expected Cheem/Astra, got ${run.stdout}`}`);
            } else {
                console.log(`[native] luau/${mode}/${preset}: PASS`);
            }
        }
    }
}

if (!Number.isFinite(minBracketReduction)) {
    minBracketReduction = 0;
}
assert.ok(minBracketReduction < 200, "access-shape regression: keyed function assignments remain excessive");
if (failures) process.exit(1);
console.log("ByteVeil v4.5.2 native runtime smoke: PASS (or Luau SKIP when unavailable)");

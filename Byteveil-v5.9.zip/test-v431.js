"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate, detect } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "bundled Lua validation runner missing");
const WATERMARK = "--This file was protected using ByteVeil Obfuscator v4.5.2 [https://discord.gg/rAhAnnkBn8/]";

function build(source, preset, mode, target, seed) {
  return obfuscate(source, {
    source,
    preset,
    mode,
    target,
    seed,
    wrapper: { enabled: false },
    transforms: { watermark: { enabled: true, text: WATERMARK.replace(/^--/, "") } }
  });
}

function assertStrictShape(result, label) {
  assert.strictEqual(result.vmMeta?.backend, "custom-vm", `${label}: not on custom VM`);
  assert.strictEqual(result.vmMeta?.fallback, false, `${label}: fallback selected`);
  assert.strictEqual(result.vmMeta?.strict, true, `${label}: not strict`);
  assert.strictEqual(result.vmMeta?.sourceReconstruction, false, `${label}: source reconstruction enabled`);
  assert.strictEqual(result.vmMeta?.packedBytecode, true, `${label}: packed bytecode missing`);
  assert.strictEqual(result.vmMeta?.version, "4.5.2", `${label}: VM version mismatch`);
  assert.strictEqual(result.vmMeta?.structure, "distributed-region-vma-vmb-microop-v452", `${label}: V4.5.2 structure missing`);
  assert.strictEqual(result.vmMeta?.stagedRuntime, true, `${label}: staged runtime missing`);
  assert.strictEqual(result.vmMeta?.decoyGraph, true, `${label}: decoy graph missing`);
  assert.strictEqual(result.vmMeta?.decoyCycle, true, `${label}: decoy cycle missing`);
  assert.strictEqual(result.vmMeta?.decoyVm, true, `${label}: decoy VM missing`);
  assert.ok(/^heterogeneous-vm452-family-\d+$/.test(String(result.vmMeta?.decoyVmShape || "")), `${label}: decoy VM shape missing`);
  assert.ok(Number(result.vmMeta?.decoyOpcodeHandlers) >= 12, `${label}: decoy handler bank missing`);
  assert.ok(Number(result.vmMeta?.decoyFrameDepth) === Number(result.vmMeta?.decoyDepth), `${label}: decoy frame depth mismatch`);
  assert.ok(Number(result.vmMeta?.decoyDepth) >= 24, `${label}: decoy depth too shallow`);
  assert.ok(Number(result.vmMeta?.decoyBudget) >= 4, `${label}: decoy budget missing`);
  assert.ok(Number(result.vmMeta?.decoyBudget) < Number(result.vmMeta?.decoyDepth), `${label}: decoy budget must stay bounded`);
  assert.strictEqual(result.vmMeta?.decoyLanes, 4, `${label}: decoy lane count mismatch`);
  assert.ok(Number(result.vmMeta?.handlerFamilies) >= 0, `${label}: handler family metadata invalid`);
  assert.strictEqual(result.vmMeta?.generatorEngine, "MFG-4.5.2", `${label}: generator engine mismatch`);
  assert.strictEqual(result.vmMeta?.mfgEngine, "MFG-4.5.2", `${label}: MFG engine mismatch`);
  assert.strictEqual(result.vmMeta?.polymorphicHandlers, true, `${label}: polymorphic handlers missing`);
  assert.strictEqual(result.vmMeta?.fusedSuper, false, `${label}: v4.5 must not use fused SUPER`);
  assert.strictEqual(result.vmMeta?.crossLayerIntegrity, true, `${label}: cross-layer integrity missing`);
  assert.strictEqual(result.vmMeta?.sharedExecutionFabric, true, `${label}: shared execution fabric missing`);
  assert.strictEqual(result.vmMeta?.stagedPayloadMaterialization, "fragment-graph-distributed-material-vma-vmb-microop-v452", `${label}: v4.5.2 staged graph payload missing`);
  assert.strictEqual(result.vmMeta?.antiHook, true, `${label}: anti-hook engine missing`);
  assert.strictEqual(result.vmMeta?.antiTamper, true, `${label}: anti-tamper engine missing`);
  assert.strictEqual(result.vmMeta?.antiDump, true, `${label}: anti-dump engine missing`);
  assert.strictEqual(result.vmMeta?.byteBlinder, "Byte-Blinder", `${label}: Byte-Blinder missing`);
  assert.strictEqual(result.vmMeta?.mfgEngine, "MFG-4.5.2", `${label}: MFG engine missing`);
  assert.strictEqual(result.vmMeta?.protectionPlan?.version, "4.5.2", `${label}: protection plan version mismatch`);
  assert.strictEqual(result.vmMeta?.protectionPlan?.engine, "Byte-Blinder", `${label}: protection plan engine mismatch`);
  assert.strictEqual(result.bytecode?.protectionIR?.version, "4.5.2", `${label}: protection IR missing`);
  assert.ok(result.vmMeta?.decoderVariant >= 0 && result.vmMeta?.decoderVariant <= 3, `${label}: decoder family missing`);
  assert.ok(result.output.startsWith(WATERMARK + "\n"), `${label}: watermark mismatch`);
  assert.ok(!/string\.char/.test(result.output), `${label}: string.char leaked`);
  assert.ok(!/\\\d{3}/.test(result.output), `${label}: decimal byte escape leaked`);
  assert.ok(!/loadstring\s*\(/.test(result.output), `${label}: source loader call leaked`);
  assert.ok(!/local\s+users\s*=/.test(result.output), `${label}: raw source leaked`);
  assert.ok(!/\bD[0-3]\[\s*\d+\s*\]/.test(result.output), `${label}: fixed numeric decoy-instance slots leaked`);
  const __bv_codeSansStrings = result.output.replace(/([\"\'])(?:\\.|(?!\1)[\s\S])*\1/g, "");
  const __bv_codeSansComments = __bv_codeSansStrings.replace(/--[^\r\n]*/g, "");
  assert.ok(!/\b(?:[A-Za-z_][A-Za-z0-9_]*)\s*&\s*(?:[A-Za-z_][A-Za-z0-9_]*|\d)/.test(__bv_codeSansComments) && !/\b(?:[A-Za-z_][A-Za-z0-9_]*)\s*\|\s*(?:[A-Za-z_][A-Za-z0-9_]*|\d)/.test(__bv_codeSansComments), `${label}: raw bitwise operator leaked into generated expression`);
  assert.ok(!/type\s+User\s*=/.test(result.output), `${label}: Luau type source leaked`);
  assert.ok(Number(result.vmMeta?.handlerFamilies) >= 0, `${label}: handler family metadata invalid`);
  assert.strictEqual(result.vmMeta?.decoyLanes, 4, `${label}: dual decoy lanes missing`);
  assert.strictEqual(result.vmMeta?.lazyInstructionMaterialization, true, `${label}: lazy instruction materialization missing`);
  assert.strictEqual(result.vmMeta?.lazyConstantMaterialization, true, `${label}: lazy constant materialization missing`);
  assert.strictEqual(result.vmMeta?.buildSpecificVM, true, `${label}: build-specific VM missing`);
  assert.strictEqual(result.vmMeta?.buildSpecificDiversity, true, `${label}: build-specific diversity missing`);
  assert.ok(Number(result.vmMeta?.vmPersonality) >= 0, `${label}: VM personality missing`);
  assert.strictEqual(result.vmMeta?.regionResolverFamilies, 4, `${label}: distributed resolver families missing`);
  assert.strictEqual(result.vmMeta?.distributedResolver, true, `${label}: distributed resolver missing`);
  assert.strictEqual(result.vmMeta?.distributedRecipeBanks, true, `${label}: distributed recipe banks missing`);
  assert.strictEqual(result.vmMeta?.regionSpecificVocabulary, true, `${label}: region vocabulary missing`);
  assert.strictEqual(result.vmMeta?.runtimeVMBGeneration, true, `${label}: VM-B synthesizer missing`);
  assert.strictEqual(result.vmMeta?.semanticMicroOpEngine, true, `${label}: micro-op engine missing`);
  assert.strictEqual(result.vmMeta?.heterogeneousDecoys, true, `${label}: heterogeneous decoys missing`);
  assert.strictEqual(result.vmMeta?.unknownCodeInserter, true, `${label}: unknown code inserter missing`);
  assert.ok(Number(result.vmMeta?.unknownCodeInserterCount) > 0, `${label}: unknown code inserter count missing`);
  assert.strictEqual(result.vmMeta?.fragmentGraph, true, `${label}: fragment graph missing`);
  assert.strictEqual(result.vmMeta?.nonLinearDependencies, true, `${label}: non-linear dependencies missing`);
  assert.strictEqual(result.vmMeta?.materialDependencyGraph, true, `${label}: material DAG missing`);
  assert.strictEqual(result.vmMeta?.opaqueTransportIR, true, `${label}: opaque transport IR missing`);
  assert.strictEqual(result.vmMeta?.perRegionOpcodeMapping, true, `${label}: per-region opcode mapping missing`);
  assert.strictEqual(result.vmMeta?.runtimeGeneratedDispatch, true, `${label}: runtime VM-B dispatch missing`);
  assert.strictEqual(result.vmMeta?.semanticMicroOps, true, `${label}: semantic micro-op VM missing`);
  assert.ok(Number(result.vmMeta?.regionCount) >= 5, `${label}: region graph too small`);
}

function golden(source, protectedResult, expected, label) {
  const a = runSyntaxCheck(lua, source, "lua");
  assert.ok(a.ok, `${label}: original syntax failed: ${a.stderr}`);
  const b = runProgram(lua, source, "lua");
  assert.ok(b.ok, `${label}: original runtime failed: ${b.stderr}`);
  const c = runSyntaxCheck(lua, protectedResult.output, "lua");
  assert.ok(c.ok, `${label}: protected syntax failed: ${c.stderr}`);
  const d = runProgram(lua, protectedResult.output, "lua", expected ?? b.stdout);
  assert.ok(d.ok, `${label}: protected runtime mismatch\nexpected=${expected ?? b.stdout}\nactual=${d.stdout}\nstderr=${d.stderr}`);
}

const luaSource = `local users={"Cheem","Astra","ByteVeil"};for i,name in ipairs(users) do print(i,name) end`;
const luauSource = `type User={name:string,id:number};local users:{User}={{name="Cheem",id=1},{name="Astra",id=2}};for _,user:User in users do print(user.name,user.id) end`;
const expectedLua = "1\tCheem\n2\tAstra\n3\tByteVeil";
const expectedLuau = "Cheem\t1\nAstra\t2";

// 4 presets x 2 modes x Lua/Luau strict VM.
const sizes = [];
for (const mode of ["stack", "register"]) {
  for (const preset of ["l1", "l2", "df", "lz"]) {
    const luaResult = build(luaSource, preset, mode, "lua", 0x39010000 ^ mode.length ^ preset.length);
    assertStrictShape(luaResult, `lua/${mode}/${preset}`);
    golden(luaSource, luaResult, expectedLua, `lua/${mode}/${preset}`);
    sizes.push(luaResult.output.length);

    const luauResult = build(luauSource, preset, mode, "luau", 0x39020000 ^ mode.length ^ preset.length);
    assertStrictShape(luauResult, `luau/${mode}/${preset}`);
    const luauProtectedCheck = runSyntaxCheck(lua, luauResult.output, "lua");
    assert.ok(luauProtectedCheck.ok, `luau/${mode}/${preset}: protected VM syntax failed: ${luauProtectedCheck.stderr}`);
    const luauRun = runProgram(lua, luauResult.output, "lua", expectedLuau);
    assert.ok(luauRun.ok, `luau/${mode}/${preset}: protected runtime mismatch\nexpected=${expectedLuau}\nactual=${luauRun.stdout}\nstderr=${luauRun.stderr}`);
  }
}
assert.ok(new Set(sizes).size >= 3, "preset depth is not materially changing Lua output");

// Per-build polymorphism: changing seed must mutate the generated protection shape.
const polyA = build(luaSource, "lz", "stack", "lua", 0x40AA1101);
const polyB = build(luaSource, "lz", "stack", "lua", 0x40AA2202);
assert.notStrictEqual(polyA.output, polyB.output, "seed polymorphism did not change protected output");
assert.ok(Number.isInteger(polyA.vmMeta?.decoderVariant), "seeded decoder variant missing");
assert.ok(Number.isInteger(polyB.vmMeta?.decoderVariant), "seeded decoder variant missing");
assert.ok(polyA.vmMeta?.decoyDepth >= 24 && polyB.vmMeta?.decoyDepth >= 24, "decoy profiles missing");

// Semantic regressions that must stay on the VM.
const semanticCases = [
  ["break", `local x=0;for i=1,5 do if i==3 then break end;x=x+i end;print(x)`, "3"],
  ["while-break", `local x=0;while x<10 do x=x+1;if x==4 then break end end;print(x)`, "4"],
  ["repeat-break", `local x=0;repeat x=x+1;if x==3 then break end until x>10;print(x)`, "3"],
  ["multireturn", `local function f()return 1,2 end;local a,b=f();print(a,b)`, "1\t2"],
  ["method-multireturn", `local T={};function T:f()return 2,3 end;local a,b=T:f();print(a,b)`, "2\t3"],
  ["method-self-table", `local T={n=3};function T:add(x)return self.n+x,self.n-x end;local a,b=T:add(5);print(a,b)`, "8\t-2"],
  ["closure", `local x=2;local function f()x=x+3;return x end;print(f(),f())`, "5\t8"],
];
for (const [name, source, expected] of semanticCases) {
  for (const mode of ["stack", "register"]) {
    const result = build(source, "lz", mode, "lua", 0x39100000 ^ name.length ^ mode.length);
    assertStrictShape(result, `${mode}/${name}`);
    golden(source, result, expected, `${mode}/${name}`);
  }
}

// Luau-only expression syntax must normalize into the same VM backend.
const luauIfExpression = `local x=7;local y=if x>3 then 10 else 20;print(y)`;
for (const mode of ["stack", "register"]) {
  const result = build(luauIfExpression, "lz", mode, "luau", 0x39110000 ^ mode.length);
  assertStrictShape(result, `luau-if/${mode}`);
  const check = runSyntaxCheck(lua, result.output, "lua");
  assert.ok(check.ok, `luau-if/${mode}: protected syntax failed: ${check.stderr}`);
  const run = runProgram(lua, result.output, "lua", "10");
  assert.ok(run.ok, `luau-if/${mode}: protected runtime mismatch: ${run.stdout}`);
}

// Unsupported-by-strict features must reject rather than silently fallback.
for (const source of [
  `local function f(...)return select("#",...)end;print(f(1,2,3))`,
  `local function f()return 1,2 end;return f()`,
]) {
  assert.throws(
    () => obfuscate(source, { target: "lua", preset: "lz", mode: "stack", seed: 123, wrapper: { enabled: false }, transforms: { watermark: false } }),
    /ByteVeil v4\.5\.2 strict VM rejected input/
  );
}

// Explicit compatibility route remains available and must be identifiable.
const compat = obfuscate(`local function f(...)return select("#",...)end;print(f(1,2,3))`, {
  target: "lua", preset: "lz", mode: "stack", seed: 987, compatibilityRoute: true,
  wrapper: { enabled: false }, transforms: { watermark: false }
});
assert.strictEqual(compat.vmMeta?.fallback, true, "explicit compatibility route did not fallback");
assert.strictEqual(compat.vmMeta?.version, "4.5.2", "compatibility metadata stale");

// Auto detection must distinguish Lua from Luau-specific type syntax.
assert.strictEqual(detect(luaSource).target || detect(luaSource).language, "lua");
const luauDetect = detect(luauSource);
assert.ok((luauDetect.target || luauDetect.language) === "luau", `auto detector missed Luau: ${JSON.stringify(luauDetect)}`);



// Macro / LPH engine contract. Comment directives are compile-time metadata only.
const macros = require("./src/macros");
const lph = require("./src/lph");

const macroSource = [
  "-- byteveil-inline",
  "-- byteveil-outline",
  "-- byteveil-virtualization",
  "-- byteveil-super(2)",
  "-- byteveil-cfg",
  "-- byteveil-mfg",
  "-- byteveil-cgi",
  "-- byteveil-pre-check",
  "-- byteveil-rewrite",
  "-- byteveil-enc-func",
  "-- byteveil-vm",
  "-- byteveil-cff",
  "-- byteveil-encstr",
  "-- byteveil-index-to-num",
  "-- byteveil-obfuscated",
  "-- byteveil-crash",
  "-- byteveil-omit",
  "-- byteveil-line",
  "-- byteveil-compress",
  "print(1)"
].join("\n");
const macroPlan = macros.resolve(macroSource);
assert.strictEqual(macroPlan.resolved, true, "macro plan did not resolve");
assert.strictEqual(macroPlan.directives.length, 19, "macro count mismatch");
assert.strictEqual(macroPlan.effects.inline.enabled, true);
assert.deepStrictEqual(macroPlan.effects.super.args, ["2"]);
assert.strictEqual(macros.MACROS.length, 19, "native macro inventory changed unexpectedly");

const lphSource = [
  "-- LPH_OBFUSCATED",
  "-- LPH_LINE",
  "-- LPH_CRASH",
  "-- LPH_NO_VIRTUALIZE",
  "-- LPH_ENCFUNC",
  "-- LPH_PRECHECK",
  "-- LPH_REWRITE",
  "print(2)"
].join("\n");
const lphPlan = lph.resolve(lphSource);
assert.strictEqual(lphPlan.resolved, true, "LPH plan did not resolve");
assert.strictEqual(lphPlan.directives.length, 7, "LPH count mismatch");
assert.strictEqual(lphPlan.aliases.length, 7, "LPH aliases were not normalized");
assert.strictEqual(lphPlan.effects.noVirtualization.enabled, true);

const commentRuntime = `-- byteveil-mfg\n-- LPH_NO_VIRTUALIZE\nlocal x=1;print(x)`;
const commentResult = obfuscate(commentRuntime, { target: "lua", preset: "lz", mode: "stack", seed: 0x43112345, wrapper: { enabled: false }, transforms: { watermark: false } });
assert.ok(commentResult.output, "directive-comment obfuscation returned no output");
assert.strictEqual(commentResult.vmMeta?.protectionPlan?.macroEngine?.directives, 1, "Macro engine was not integrated into pipeline");
assert.strictEqual(commentResult.vmMeta?.protectionPlan?.lphEngine?.directives, 1, "LPH engine was not integrated into pipeline");

console.log("ByteVeil v4.5.2 compiler/VM/runtime/protection regression: PASS");

// v4.5.2 red-team invariants: the generated artifact must not expose a one-pass
// semantic choke point through handler names or plaintext source fragments.
const redTeamProbe = build(`print("Hi")`, "lz", "stack", "lua", 0x4A5511E7);
assert.ok(Number(redTeamProbe.vmMeta?.regionCount) >= 5, "red-team: insufficient necessary regions");
assert.ok(Number(redTeamProbe.vmMeta?.regionShards) >= 5, "red-team: payload is not materially sharded");
assert.ok((redTeamProbe.output.match(/data=\{/g) || []).length >= 5, "red-team: insufficient region data shards");
assert.ok(!redTeamProbe.output.includes('print("Hi")'), "red-team: exact plaintext source leaked");
assert.ok(!redTeamProbe.output.includes('"Hi"'), "red-team: plaintext string constant leaked");
for (const op of ["PUSHK", "CALLG", "ADD", "RETURN", "GETG", "SETL"]) {
  assert.ok(!new RegExp(`local\\s+\\w*_${op}\\s*=`).test(redTeamProbe.output), `red-team: semantic handler name leaked: ${op}`);
}
for (const marker of ["microRecipes", "microRoute", "graphRuntime", "semanticFn"]) {
  assert.ok(!redTeamProbe.output.includes(marker), `red-team: internal stage marker leaked: ${marker}`);
}
for (const marker of ["G.resolve", "G.fetch", "G.peek", "byteAt"]) {
  assert.ok(!redTeamProbe.output.includes(marker), `red-team: universal resolver choke point leaked: ${marker}`);
}
assert.strictEqual(redTeamProbe.vmMeta?.unknownCodeInserter, true, "red-team: unknown code inserter not active");
assert.ok((redTeamProbe.output.match(/-- BV452-UC /g) || []).length > 0, "red-team: unknown code comments missing");
const buildA = build(`print("Hi")`, "lz", "stack", "lua", 0x4A5511E7);
const buildB = build(`print("Hi")`, "lz", "stack", "lua", 0x4A5511E8);
assert.notStrictEqual(buildA.output, buildB.output, "red-team: build-specific output did not diversify");
assert.notStrictEqual(String(buildA.vmMeta?.vmPersonality), String(buildB.vmMeta?.vmPersonality), "red-team: VM personality collided");
assert.notStrictEqual(String(buildA.vmMeta?.decoderVariant), String(buildB.vmMeta?.decoderVariant), "red-team: decoder variant collided");
assert.notStrictEqual(
  build(`print("Hi")`, "lz", "stack", "lua", 0x4A5511E7).output,
  build(`print("Hi")`, "lz", "stack", "lua", 0x4A5511E8).output,
  "red-team: build-specific topology did not diversify"
);

console.log("ByteVeil v4.5.2 red-team static hardening: PASS");

"use strict";
const assert = require("assert");
const { lex } = require("./src/frontend/lexer");
const { validateBytecode } = require("./src/ironbrew/validator");
const bv = require("./src");

const lexed = lex('--!strict\nlocal s="hello ! world"\nprint(s)');
assert.strictEqual(lexed.errors.length, 0, lexed.errors.map(e => e.message).join("; "));

assert.throws(() => validateBytecode({
  mode: "stack",
  consts: [], params: [],
  map: { decode: { 1: "BAND" } },
  code: [[1]]
}), /invalid stack depth/);

const input = 'local x = "hello ! world"\nprint(x)\n';
const result = bv.obfuscate(input, { mode: "stack", preset: "l1", wrapper: { enabled: false }, transforms: { watermark: false }});
assert.ok(result && typeof result.output === "string" && result.output.length > 1000);
console.log("ByteVeil legacy frontend/stack-safety regression: PASS");

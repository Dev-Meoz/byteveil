"use strict";
const assert = require("assert");
const { obfuscate } = require("./src");
const nested = require("./src/protection/nested_obfuscation");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "bundled Lua validation runner missing");

function build(source, mode, preset, seed, strength) {
  return obfuscate(source, {
    source, mode, preset, target: "lua", seed, strength,
    wrapper: { enabled: false },
    transforms: { watermark: false }
  });
}

function shape(r, label) {
  const m = r.vmMeta || {};
  assert.strictEqual(m.version, "4.5.4", `${label}: version`);
  assert.strictEqual(m.backend, "custom-vm", `${label}: backend`);
  assert.strictEqual(m.strict, true, `${label}: strict`);
  assert.strictEqual(m.fallback, false, `${label}: fallback`);
  assert.strictEqual(m.nestedObfuscation, true, `${label}: nested`);
  assert.ok(Number(m.nestedObfuscationLayers) >= 3, `${label}: nested layer count`);
  assert.strictEqual(m.heterogeneousNestedLayers, true, `${label}: heterogeneous layers`);
  assert.strictEqual(m.antiTamper, true, `${label}: anti-tamper`);
  assert.strictEqual(m.antiHook, true, `${label}: anti-hook`);
  assert.strictEqual(m.antiDump, true, `${label}: anti-dump`);
  assert.strictEqual(m.buildSpecificVM, true, `${label}: build-specific VM`);
  assert.strictEqual(m.distributedResolver, true, `${label}: distributed resolver`);
  assert.strictEqual(m.runtimeVMBGeneration, true, `${label}: VM-B generation`);
  assert.strictEqual(m.semanticMicroOpEngine, true, `${label}: micro-op engine`);
  assert.strictEqual(m.regionSpecificVocabulary, true, `${label}: region vocabulary`);
  assert.ok(Number.isInteger(m.vmPersonality), `${label}: VM personality`);
  assert.ok(Array.isArray(m.vmStateOrder) && m.vmStateOrder.length >= 18, `${label}: VM state order`);
  assert.ok(Number.isInteger(m.vmDispatchStyle), `${label}: VM dispatch style`);
  assert.strictEqual(m.unknownCodeInserter, undefined, `${label}: unknown inserter`);
  assert.ok(!r.output.includes('print("Hi")'), `${label}: plaintext source leaked`);
  assert.ok(!r.output.includes('"Hi"'), `${label}: plaintext constant leaked`);
  assert.ok(!/unknown_code_inserter|unknownCodeInserter|BV45[23]-UC/.test(r.output), `${label}: unknown inserter artifact`);
  assert.ok(!/G\.resolve|G\.fetch|G\.peek|byteAt/.test(r.output), `${label}: universal resolver artifact`);
}

for (const [mode, preset, seed] of [
  ["stack", "lz", 0x45350001],
  ["register", "lz", 0x45350002]
]) {
  const r = build(`local x=1;local y=2;print(x+y)`, mode, preset, seed, 3500);
  shape(r, `${mode}/3500`);
  const s = runSyntaxCheck(lua, r.output, "lua");
  assert.ok(s.ok, `${mode}: protected syntax failed: ${s.stderr}`);
  const x = runProgram(lua, r.output, "lua", "3");
  assert.ok(x.ok, `${mode}: protected runtime failed: ${x.stderr}`);
}

const high = build(`print("Hi")`, "stack", "lz", 0x45360001, 10000);
shape(high, "stack/10000");
assert.strictEqual(Number(high.vmMeta.nestedObfuscationLayers), 9, "stack/10000: expected 9 layers");
assert.ok(runSyntaxCheck(lua, high.output, "lua").ok, "stack/10000: syntax");
// High-strength output is syntax-validated here; runtime execution is covered at 3500 to keep the regression gate bounded.

const A = build(`print("Hi")`, "stack", "lz", 0x4537A001, 3500);
const B = build(`print("Hi")`, "stack", "lz", 0x4537B002, 3500);
assert.notStrictEqual(A.output, B.output, "build-specific output did not change");
assert.notStrictEqual(String(A.vmMeta.vmPersonality), String(B.vmMeta.vmPersonality), "VM personality did not change");
assert.notStrictEqual(String(A.vmMeta.decoderVariant), String(B.vmMeta.decoderVariant), "decoder variant did not change");
assert.notDeepStrictEqual(A.vmMeta.nestedCodecs, B.vmMeta.nestedCodecs, "nested codec plan did not change");
assert.notStrictEqual(String(A.vmMeta.vmStateProfile), String(B.vmMeta.vmStateProfile), "VM state profile did not change");
assert.notDeepStrictEqual(A.vmMeta.vmStateOrder, B.vmMeta.vmStateOrder, "VM state layout did not change");

for (let codec = 0; codec <= 5; codec++) {
  const wrapped = nested._makeWrapper(`print("codec-${codec}")`, { layerIndex: 0, codec, seed: 0x45380000 + codec });
  const s = runSyntaxCheck(lua, wrapped, "lua");
  assert.ok(s.ok, `codec-${codec}: syntax`);
  const x = runProgram(lua, wrapped, "lua", `codec-${codec}`);
  assert.ok(x.ok, `codec-${codec}: runtime ${x.stderr}`);
}

const wrappedTamper = nested.wrapSource(`print("tamper")`, { seed: 0x45390001, strength: 3500 });
const literals = [...wrappedTamper.output.matchAll(/local\s+_[A-Za-z]+=("(?:\\.|[^"\\])*")/g)];
assert.ok(literals.length >= 2, "tamper fixture did not contain payload strings");
let target = null;
for (const match of literals) {
  let value;
  try { value = JSON.parse(match[1]); } catch { continue; }
  if (!target || value.length > target.value.length) target = { match, value };
}
assert.ok(target && target.value.length >= 80, "tamper fixture did not contain a long payload string");
const mutatedValue = "!" + target.value.slice(1);
const tampered = wrappedTamper.output.replace(target.match[1], JSON.stringify(mutatedValue));
assert.notStrictEqual(tampered, wrappedTamper.output, "tamper fixture unchanged");
assert.ok(!runProgram(lua, tampered, "lua").ok, "tampered nested payload executed");

const hookProbe = nested.wrapSource(`print("hook")`, { seed: 0x45390002, strength: 3500 }).output
  .replace("local __L=loadstring or load;", "local __L=loadstring or load;string.byte=function()return 0 end;");
assert.ok(!runProgram(lua, hookProbe, "lua").ok, "hooked runtime reference executed");

console.log("ByteVeil v4.5.4 compiler/VM/runtime/protection regression: PASS");
console.log("ByteVeil v4.5.4 nested obfuscation + anti-tamper/hook/dump checks: PASS");

const assert = require("assert");
const { obfuscate } = require("./src");
const { Lexer } = require("./src/frontend/lexer");
const { Parser } = require("./src/frontend/parser");
const nested = require("./src/protection/nested_obfuscation");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "bundled Lua validation runner missing");

function build(source, mode, preset, seed, strength) {
  return obfuscate(source, {
    source, mode, preset, target: "lua", seed, strength,
    wrapper: { enabled: false },
    transforms: { watermark: false }
  });
}

function shape(r, label) {
  const m = r.vmMeta || {};
  assert.ok(["4.6.1", "4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6", "4.6.7"].includes(m.version), `${label}: version`);
  assert.strictEqual(m.backend, "custom-vm", `${label}: backend`);
  assert.strictEqual(m.strict, true, `${label}: strict`);
  assert.strictEqual(m.fallback, false, `${label}: fallback`);
  assert.strictEqual(m.nestedObfuscation, true, `${label}: nested`);
  assert.ok(Number(m.nestedObfuscationLayers) >= 3, `${label}: nested layer count`);
  assert.strictEqual(m.heterogeneousNestedLayers, true, `${label}: heterogeneous layers`);
  assert.strictEqual(m.antiTamper, true, `${label}: anti-tamper`);
  assert.strictEqual(m.antiHook, true, `${label}: anti-hook`);
  assert.strictEqual(m.antiDump, true, `${label}: anti-dump`);
  assert.strictEqual(m.buildSpecificVM, true, `${label}: build-specific VM`);
  assert.ok(Number.isInteger(m.vmArchitectureFamily) && m.vmArchitectureFamily >= 0 && m.vmArchitectureFamily < 6, `${label}: architecture family`);
  assert.ok(typeof m.vmArchitectureName === "string" && m.vmArchitectureName.length > 0, `${label}: architecture name`);
  assert.ok(Number.isInteger(m.vmSecondaryArchitecture), `${label}: secondary architecture`);
  assert.ok(Number.isInteger(m.vmMaterializationFamily), `${label}: materialization family`);
  assert.strictEqual(m.semanticArchitectureFamilies, 6, `${label}: semantic architecture families`);
  assert.strictEqual(m.distributedResolver, true, `${label}: distributed resolver`);
  assert.strictEqual(m.runtimeVMBGeneration, true, `${label}: VM-B generation`);
  assert.strictEqual(m.semanticMicroOpEngine, true, `${label}: micro-op engine`);
  assert.strictEqual(m.regionSpecificVocabulary, true, `${label}: region vocabulary`);
  assert.strictEqual(m.representationMorphing, true, `${label}: representation morphing`);
  assert.strictEqual(m.composedSemanticLayer, true, `${label}: composed semantic layer`);
  assert.strictEqual(m.runtimeGeneratedRecipe, true, `${label}: runtime-generated recipe`);
  assert.strictEqual(m.dynamicDispatchTopology, true, `${label}: dynamic dispatch topology`);
  assert.strictEqual(m.nonCanonicalIR, true, `${label}: non-canonical IR`);
  assert.ok(Number.isInteger(m.vmRepresentationStyle), `${label}: representation style`);
  assert.ok(Number.isInteger(m.vmResolverFamily), `${label}: resolver family`);
  assert.ok(Number.isInteger(m.vmStateModel), `${label}: state model`);
  assert.ok(Number.isInteger(m.vmCommitStyle), `${label}: commit style`);
  assert.ok(Number.isInteger(m.vmPersonality), `${label}: VM personality`);
  assert.ok(Array.isArray(m.vmStateOrder) && m.vmStateOrder.length >= 18, `${label}: VM state order`);
  assert.ok(Number.isInteger(m.vmDispatchStyle), `${label}: VM dispatch style`);
  assert.strictEqual(m.unknownCodeInserter, undefined, `${label}: unknown inserter`);
  assert.ok(!r.output.includes('print("Hi")'), `${label}: plaintext source leaked`);
  assert.ok(!r.output.includes('"Hi"'), `${label}: plaintext constant leaked`);
  assert.ok(!/unknown_code_inserter|unknownCodeInserter|BV45[23]-UC/.test(r.output), `${label}: unknown inserter artifact`);
  assert.ok(!/G\.resolve|G\.fetch|G\.peek|byteAt/.test(r.output), `${label}: universal resolver artifact`);
  assert.ok(!/coreDispatch|core-dispatch/.test(r.output), `${label}: universal semantic dispatcher artifact`);
}

for (const [mode, preset, seed] of [
  ["stack", "lz", 0x45350001],
  ["register", "lz", 0x45350002]
]) {
  const r = build(`local x=1;local y=2;print(x+y)`, mode, preset, seed, 3500);
  shape(r, `${mode}/3500`);
  const s = runSyntaxCheck(lua, r.output, "lua");
  assert.ok(s.ok, `${mode}: protected syntax failed: ${s.stderr}`);
  const x = runProgram(lua, r.output, "lua", "3");
  assert.ok(x.ok, `${mode}: protected runtime failed: ${x.stderr}`);
}

const high = build(`print("Hi")`, "stack", "lz", 0x45360001, 10000);
shape(high, "stack/10000");
assert.strictEqual(Number(high.vmMeta.nestedObfuscationLayers), 9, "stack/10000: expected 9 layers");
assert.ok(runSyntaxCheck(lua, high.output, "lua").ok, "stack/10000: syntax");
// High-strength output is syntax-validated here; runtime execution is covered at 3500 to keep the regression gate bounded.

const A = build(`print("Hi")`, "stack", "lz", 0x4537A001, 3500);
const B = build(`print("Hi")`, "stack", "lz", 0x4537B002, 3500);
assert.notStrictEqual(A.output, B.output, "build-specific output did not change");
assert.notStrictEqual(String(A.vmMeta.vmPersonality), String(B.vmMeta.vmPersonality), "VM personality did not change");
assert.notStrictEqual(String(A.vmMeta.decoderVariant), String(B.vmMeta.decoderVariant), "decoder variant did not change");
assert.notDeepStrictEqual(A.vmMeta.nestedCodecs, B.vmMeta.nestedCodecs, "nested codec plan did not change");
assert.notStrictEqual(String(A.vmMeta.vmStateProfile), String(B.vmMeta.vmStateProfile), "VM state profile did not change");
assert.notDeepStrictEqual(A.vmMeta.vmStateOrder, B.vmMeta.vmStateOrder, "VM state layout did not change");

const builds = [];
const buildSignatures = new Set();
for (let i = 0; i < 20; i++) {
  const seed = (0x45A50000 + Math.imul(i + 1, 0x9E3779B9)) >>> 0;
  const r = build(`print(1+2)`, i % 2 ? "register" : "stack", "l2", seed, 1000);
  shape(r, `diversity/${i}`);
  assert.ok(runSyntaxCheck(lua, r.output, "lua").ok, `diversity/${i}: syntax`);
  builds.push(r);
  buildSignatures.add(JSON.stringify([r.output.length, r.vmMeta.vmPersonality, r.vmMeta.vmArchitectureFamily, r.vmMeta.vmSecondaryArchitecture, r.vmMeta.vmMaterializationFamily, r.vmMeta.vmDispatchStyle, r.vmMeta.vmRecipeStyle, r.vmMeta.vmRepresentationStyle, r.vmMeta.vmResolverFamily, r.vmMeta.vmStateModel, r.vmMeta.vmCommitStyle, (r.vmMeta.vmStateOrder || []).join(",")]));
}
assert.strictEqual(new Set(builds.map(x => x.output)).size, 20, "20-build artifact diversity failed");
assert.ok(buildSignatures.size >= 18, `20-build VM personality diversity too low: ${buildSignatures.size}`);

for (let codec = 0; codec <= 5; codec++) {
  const wrapped = nested._makeWrapper(`print("codec-${codec}")`, { layerIndex: 0, codec, seed: 0x45380000 + codec });
  const s = runSyntaxCheck(lua, wrapped, "lua");
  assert.ok(s.ok, `codec-${codec}: syntax`);
  const x = runProgram(lua, wrapped, "lua", `codec-${codec}`);
  assert.ok(x.ok, `codec-${codec}: runtime ${x.stderr}`);
}

const wrappedTamper = nested.wrapSource(`print("tamper")`, { seed: 0x45390001, strength: 3500 });
const literals = [...wrappedTamper.output.matchAll(/local\s+_[A-Za-z]+=("(?:\\.|[^"\\])*")/g)];
assert.ok(literals.length >= 2, "tamper fixture did not contain payload strings");
let target = null;
for (const match of literals) {
  let value;
  try { value = JSON.parse(match[1]); } catch { continue; }
  if (!target || value.length > target.value.length) target = { match, value };
}
assert.ok(target && target.value.length >= 80, "tamper fixture did not contain a long payload string");
const mutatedValue = "!" + target.value.slice(1);
const tampered = wrappedTamper.output.replace(target.match[1], JSON.stringify(mutatedValue));
assert.notStrictEqual(tampered, wrappedTamper.output, "tamper fixture unchanged");
assert.ok(!runProgram(lua, tampered, "lua").ok, "tampered nested payload executed");

const hookProbe = nested.wrapSource(`print("hook")`, { seed: 0x45390002, strength: 3500 }).output
  .replace('local __L=__E.load or __E["load".."string"];', 'local __L=__E.load or __E["load".."string"];string.byte=function(){return 0 end;');
assert.ok(!runProgram(lua, hookProbe, "lua").ok, "hooked runtime reference executed");

// v4.6.2 active nested path: loader must resolve through the environment and must not emit loadstring.
const activeHook = nested.wrapSource(`print("hook-v461")`, { seed: 0x45390003, strength: 3500, version: "4.6.2" }).output;
assert.ok(!/\bloadstring\b/.test(activeHook), "v4.6.2 nested wrapper emitted loadstring");
assert.ok(/getgenv|getfenv/.test(activeHook), "v4.6.2 nested wrapper missing environment loader");
const activeHookProbe = activeHook.replace('local __L=__E["lo".."ad"]or load or __LS;', 'local __L=__E["lo".."ad"]or load or __LS;string.byte=function(){return 0 end;');
assert.ok(!runProgram(lua, activeHookProbe, "lua").ok, "v4.6.2 hooked loader/reference executed");

// v4.6.2: PBF/global representation families must reach execution, not remain metadata-only.
const pbf = build(`local a=1;local b=2;print(a+b)`, "stack", "l2", 0x461A0001, 1000);
assert.ok(/\b(?:t|o|q|r|x|h)\b/.test(pbf.output), "v4.6.2: instruction representation missing");
assert.strictEqual(pbf.vmMeta.actualRepresentationMorphing, true, "v4.6.2: representation morphing runtime flag");
assert.ok(Number.isInteger(pbf.vmMeta.vmPbfFamily), "v4.6.2: PBF family missing");
assert.ok(Number.isInteger(pbf.vmMeta.vmCffFamily), "v4.6.2: CFF family missing");
assert.ok(Number.isInteger(pbf.vmMeta.vmEnvFamily), "v4.6.2: environment family missing");
assert.ok(/getgenv|getfenv/.test(pbf.output), "v4.6.2: environment binding missing");
assert.ok(!/\bloadstring\b/.test(pbf.output), "v4.6.2: direct loadstring token leaked");
assert.strictEqual(Number(pbf.vmMeta.nestedObfuscationLayers), 3, "v4.6.2: l2 strength 1000 nested count");
assert.ok(runSyntaxCheck(lua, pbf.output, "lua").ok, "v4.6.2 pbf syntax");
assert.ok(runProgram(lua, pbf.output, "lua", "3").ok, "v4.6.2 pbf runtime");
const pbfRuns = [];
for (let i = 0; i < 12; i++) {
  const rr = build(`local a=1;local b=2;print(a+b)`, "stack", "lz", (0x461B0001 + Math.imul(i + 1, 0x9E3779B9)) >>> 0, 1000);
  assert.ok(runSyntaxCheck(lua, rr.output, "lua").ok, `v4.6.2 pbf-diversity ${i}: syntax`);
  const rx = runProgram(lua, rr.output, "lua", "3");
  assert.ok(rx.ok, `v4.6.2 pbf-diversity ${i}: runtime ${rx.stderr}`);
  pbfRuns.push(rr);
}
assert.ok(new Set(pbfRuns.map((x) => x.output)).size >= 10, "v4.6.2: PBF artifacts structurally too similar");
assert.ok(new Set(pbfRuns.map((x) => `${x.vmMeta.vmPbfFamily}:${x.vmMeta.vmCffFamily}:${x.vmMeta.vmArchitectureFamily}:${x.vmMeta.vmRepresentationStyle}`)).size >= 8, "v4.6.2: PBF/CF architecture diversity too low");

const hi = build(`print("ByteVeil-462")`, "stack", "lz", 0x461A0002, 10000);
assert.strictEqual(Number(hi.vmMeta.nestedObfuscationLayers), 9, "v4.6.2: 9 nested layers must remain");
assert.ok(runSyntaxCheck(lua, hi.output, "lua").ok, "v4.6.2 high-strength syntax");
const hiRun = runProgram(lua, hi.output, "lua", "ByteVeil-462");
assert.ok(hiRun.ok, `v4.6.2 high-strength runtime failed: ${hiRun.stderr}`);

// Lua/Luau lexer/parser regression: valid syntax must not fall through to
// the generic "Expected assignment or call" error.
const syntaxCases = [
  ["lua-call-sugar", 'print "BV462-CALL-SUGAR"'],
  ["lua-method-table-arg", 'local t={m=function(self,x)return x end};print(t:m{v=7}.v)'],
  ["luau-generic-function", 'local function id<T>(x: T): T return x end; print(id(3))'],
  ["luau-generic-type-alias", 'type Alias<T> = { value: T }; local x: Alias<string> = {value="ok"}; print(x.value)'],
  ["luau-type-cast", 'local x = (3 :: number); print(x)'],
  ["lua-numeric-literals", 'local a=1_024; local b=0b1010; local c=0x1.fp2; print(a+b+c)'],
  ["luau-compound", 'local n=5; n//=2; n%=2; n..="x"; print(n)'],
  ["luau-if-expression", 'local x = if true then 3 else 4; print(x)'],
  ["lua-long-bracket", 'local s=[=[a ! b]=]; print(s)'],
  ["lua-shebang", '#!/usr/bin/env lua\nprint("BV462-SHEBANG")']
];
for (const [label, source] of syntaxCases) {
  const lexed = new Lexer(source).lex();
  assert.strictEqual(lexed.errors.length, 0, `${label}: lexer errors: ${JSON.stringify(lexed.errors)}`);
  const parser = new Parser(lexed.tokens);
  parser.parse();
  assert.strictEqual(parser.errors.length, 0, `${label}: parser errors: ${JSON.stringify(parser.errors)}`);
}
const syntaxRuntimeCases = [
  ['print "BV462-CALL-SUGAR"', 'BV462-CALL-SUGAR', 'lua'],
  ['local function id<T>(x: T): T return x end; print(id(3))', '3', 'luau'],
  ['type Alias<T> = { value: T }; local x: Alias<string> = {value="ok"}; print(x.value)', 'ok', 'luau'],
  ['local x = (3 :: number); print(x)', '3', 'luau'],
  ['local a=1_024; local b=0b1010; local c=0x1.fp2; print(a+b+c)', '1041.75', 'luau'],
  ['local n=5; n//=2; n%=2; n..="x"; print(n)', '0x', 'luau'],
  ['local x = if true then 3 else 4; print(x)', '3', 'luau'],
  ['local s=[=[a ! b]=]; print(s)', 'a ! b', 'lua'],
  ['#!/usr/bin/env lua\nprint("BV462-SHEBANG")', 'BV462-SHEBANG', 'lua']
];
for (let i = 0; i < syntaxRuntimeCases.length; i++) {
  const [source, expected, target] = syntaxRuntimeCases[i];
  const mode = i % 2 ? 'register' : 'stack';
  const r = obfuscate(source, {
    source, target, mode, preset: 'l2', seed: (0x462C0001 + i * 0x9E3779B9) >>> 0,
    strength: 1000, wrapper: { enabled: false }, transforms: { watermark: false }
  });
  assert.strictEqual(r.vmMeta?.version, '4.6.7', `syntax-runtime/${i}: version`);
  assert.ok(runSyntaxCheck(lua, r.output, 'lua').ok, `syntax-runtime/${i}: generated syntax`);
  const result = runProgram(lua, r.output, 'lua', expected);
  assert.ok(result.ok, `syntax-runtime/${i}: runtime expected ${JSON.stringify(expected)}, got ${JSON.stringify(result.stdout)}; ${result.stderr}`);
}

const balancedProfile = nested.wrapSource('print("balanced")', { seed: 0x462D0001, strength: 10000, version: '4.6.2' });
const fullProfile = nested.wrapSource('print("full")', { seed: 0x462D0001, strength: 10000, version: '4.6.2', nestedProfile: 'full' });
assert.strictEqual(Number(balancedProfile.layers), 9, 'balanced nested profile changed the 9-stage contract');
assert.strictEqual(Number(fullProfile.layers), 9, 'full nested profile changed the 9-stage contract');
assert.ok(!/\bloadstring\b/.test(balancedProfile.output), 'balanced nested profile emitted loadstring');
assert.ok(!/\bloadstring\b/.test(fullProfile.output), 'full nested profile emitted loadstring');
assert.ok(!/\bloadstring\b/.test(build('print("loader-token")', "stack", "lz", 0x462D0002, 1000).output), 'VM output emitted loadstring');
for (const [profile, wrapped] of [['balanced', balancedProfile], ['full', fullProfile]]) {
  const profileRun = runProgram(lua, wrapped.output, 'lua', profile);
  assert.ok(profileRun.ok, `${profile} nested profile runtime failed: ${profileRun.stderr}`);
}
// Simulate Lua 5.1/executor environments where `load` exists but rejects
// source strings; resolve the string compiler through the environment table.
const loaderFallback = `local __real=load;loadstring=__real;load=function()error("reader function required")end;${balancedProfile.output}`;
const loaderFallbackRun = runProgram(lua, loaderFallback, 'lua', 'balanced');
assert.ok(loaderFallbackRun.ok, `environment loader fallback failed: ${loaderFallbackRun.stderr}`);

console.log("ByteVeil v4.6.2 architecture-diverse VM/runtime/protection regression: PASS");
process.stdout.write("ByteVeil v4.6.2 nested obfuscation + anti-tamper/hook/dump checks: PASS\n", () => process.exit(0));

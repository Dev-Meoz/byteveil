"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const nested = require("./src/protection/nested_obfuscation");
const watermarkModule = require("./src/transforms/watermark");
assert.match(watermarkModule.DEFAULT_WATERMARK, /ByteVeil Obfuscator v4\.6\.5/, "default watermark version is stale");
const { analyzeOutputBudget, TARGET_MIN_BYTES, TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua runtime is required for the v4.6.5 release gate");

function build(source, mode = "stack", preset = "l2", seed = 0x46300001, strength = 1000, options = {}) {
  return obfuscate(source, {
    source, target: "lua", mode, preset, seed, strength,
    wrapper: { enabled: false },
    transforms: { watermark: false },
    ...options
  });
}

// Size analysis is telemetry only. It must never truncate output or remove protection.
assert.strictEqual(TARGET_MIN_BYTES, 375_000, "minimum target changed");
assert.strictEqual(TARGET_MAX_BYTES, 475_000, "maximum target changed");
const under = analyzeOutputBudget({ source: "x", output: "o".repeat(100_000), preset: "l1" });
const inRange = analyzeOutputBudget({ source: "x".repeat(30), output: "o".repeat(400_000), preset: "l2" });
const over = analyzeOutputBudget({
  source: "x".repeat(32), output: "o".repeat(500_000), preset: "lz",
  vmMeta: { backend: "custom-vm", nestedObfuscationLayers: 9 },
  options: { wrapper: { enabled: true }, transforms: { watermark: true } }
});
assert.strictEqual(under.status, "below-target");
assert.strictEqual(inRange.status, "in-target");
assert.strictEqual(over.status, "over-target");
assert.strictEqual(over.overMaximum, true);
assert.match(over.recommendation, /No protection layer or preset was removed/);
assert.ok(over.likelyContributors.includes("nested-protection-runtime"));
const overAfterOptional = analyzeOutputBudget({
  source: "x".repeat(32), output: "o".repeat(500_000), preset: "lz",
  vmMeta: { backend: "custom-vm", nestedObfuscationLayers: 9 },
  options: { wrapper: { enabled: false }, transforms: { watermark: false } }
});
assert.match(overAfterOptional.recommendation, /even with optional wrapper and watermark disabled/);

const semanticCases = [
  ["closure-returned-function", "local function make(x) return function(y) x=x+y; return x end end; local c=make(2); print(c(3),c(4))", "5\t9"],
  ["upvalue-shared-state", "local n=1; local function inc() n=n+1; return n end; print(inc(),inc())", "2\t3"],
  ["coroutine-resume-yield-return", "local co=coroutine.create(function(a) coroutine.yield(a+1); return a+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)", "true\t5\ttrue\t6"],
  ["metatable-index", "local t=setmetatable({}, {__index=function(_,k) return k..'!' end}); print(t.foo)", "foo!"],
  ["metatable-add", "local mt={__add=function(a,b) return {n=a.n+b.n} end}; local a=setmetatable({n=2},mt); local b=setmetatable({n=3},mt); print((a+b).n)", "5"],
  ["multiple-return", "local function f() return 3,4,5 end; local a,b,c=f(); print(a,b,c)", "3\t4\t5"],
  ["error-handling-pcall-xpcall", "local a,e=pcall(function() error('BVERR') end); local b=xpcall(function() error('BVERR2') end,function(x) return 'handled' end); print(a,string.find(e,'BVERR')~=nil,b)", "false\ttrue\tfalse"]
];

let semanticRuntimeChecks = 0;
for (const mode of ["stack", "register"]) {
  for (let i = 0; i < semanticCases.length; i++) {
    const [label, source, expected] = semanticCases[i];
    const result = build(source, mode, "l2", (0x46310001 + i * 0x9E3779B9 + (mode === "register" ? 17 : 0)) >>> 0, 1000);
    assert.strictEqual(result.vmMeta?.version, "4.6.5", `${mode}/${label}: active version`);
    assert.strictEqual(result.vmMeta?.generatorEngine, "MFG-4.6.5", `${mode}/${label}: generator metadata version`);
    assert.doesNotMatch(result.output, /v4\.6\.3/, `${mode}/${label}: generated output still identifies as v4.6.3`);
    assert.strictEqual(result.vmMeta?.actualRepresentationMorphing, true, `${mode}/${label}: metadata says morphing but runtime path is not marked active`);
    const syntax = runSyntaxCheck(lua, result.output, "lua");
    assert.ok(syntax.ok, `${mode}/${label}: syntax failed (${syntax.error || syntax.stderr})`);
    const execution = runProgram(lua, result.output, "lua", expected);
    assert.ok(execution.ok, `${mode}/${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
    assert.ok(result.sizeBudget && result.sizeBudget.outputBytes === Buffer.byteLength(result.output), `${mode}/${label}: missing/inaccurate size telemetry`);
    semanticRuntimeChecks++;
  }
}

// v4.6.5 vararg regressions: preserve the explicit argument count (including nil),
// spread into calls, and expand varargs after fixed return/assignment values.
const varargCases = [
  ["vararg-return-preserves-nil", 'local function f(...) return 9, ... end; local a,b,c,d=f(1,nil,3); print(a,b,c,d)', "9\t1\tnil\t3"],
  ["vararg-call-spread", 'local function g(a,b,c) print(a,b,c) end; local function f(...) g(9, ...) end; f(1,nil,3)', "9\t1\tnil"],
  ["vararg-assignment", 'local function f(...) local a,b,c=...; print(a,b,c) end; f(1,nil,3)', "1\tnil\t3"],
  ["vararg-exact-count", 'local function f(...) print(select("#", ...)) end; f(1,nil,3)', "3"],
  ["vararg-empty-count", 'local function f(...) print(select("#", ...)) end; f()', "0"],
  ["vararg-empty-values", 'local function f(...) local a,b,c=...; print(a,b,c) end; f()', "nil\tnil\tnil"],
];
for (const mode of ["stack", "register"]) {
  for (let i=0; i<varargCases.length; i++) {
    const [label, source, expected] = varargCases[i];
    const result = build(source, mode, "l2", (0x4642A100 + i * 0x9E3779B9 + (mode === "register" ? 1 : 0)) >>> 0, 1000);
    assert.strictEqual(result.vmMeta?.version, "4.6.5", `${mode}/${label}: active version`);
    assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${mode}/${label}: syntax`);
    const execution = runProgram(lua, result.output, "lua", expected);
    assert.ok(execution.ok, `${mode}/${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
    semanticRuntimeChecks++;
  }
}

// Explicitly unsupported multireturn table-tail/generic-for expansions must still be rejected.
for (const mode of ["stack", "register"]) {
  assert.throws(() => build('local function f(...) return {...} end; print(f(1,2,3))', mode, "l2", 0x4642B100 + (mode === "register" ? 1 : 0), 1000),
    /trailing call\/vararg table field requires multireturn-safe VM support/, `${mode}: unsupported table-tail vararg must be explicit`);
}
for (const mode of ["stack", "register"]) {
  assert.throws(() => build('local function f(...) for x in ... do print(x) end end', mode, "l2", 0x4642B200 + (mode === "register" ? 1 : 0), 1000),
    /generic-for vararg iterator expansion is not supported/, `${mode}: unsupported generic-for vararg tail must be explicit`);
}


// v4.6.5 Unicode regression matrix: the custom VM must preserve UTF-8 text
// across writing systems and supplementary characters in both stack/register modes.
const unicodeString = "Tiếng Việt có dấu — English / 中文 / 日本語 / 한국어 / Русский / العربية / हिन्दी / አማርኛ / Kiswahili / é / 😀🧑🏽‍💻";
const unicodeSource = `local s=${JSON.stringify(unicodeString)}; print(s); print(#s)`;
const unicodeExpected = `${unicodeString}\n${Buffer.byteLength(unicodeString, "utf8")}`;
for (const mode of ["stack", "register"]) {
  const result = build(unicodeSource, mode, "lz", mode === "stack" ? 0x465A0001 : 0x465A0002, 10000, { transforms: { strings: { enabled: true, rate: 1 }, watermark: false } });
  assert.strictEqual(result.vmMeta?.version, "4.6.5", `${mode}/unicode: active version`);
  assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${mode}/unicode: syntax`);
  const execution = runProgram(lua, result.output, "lua", unicodeExpected);
  assert.ok(execution.ok, `${mode}/unicode: expected Unicode round-trip; got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
  assert.ok(result.vmMeta?.nestedObfuscationLayers === 9, `${mode}/unicode: nested protection metadata missing`);
  semanticRuntimeChecks++;
}

// Unicode splitting must not create isolated UTF-16 surrogate halves.
{
  const { Lexer } = require("./src/frontend/lexer");
  const { Parser } = require("./src/frontend/parser");
  const { transform } = require("./src/transforms/string_obfuscator");
  const source = `print(${JSON.stringify("abcdefgh😀ijklmnop中文日本語한국어")})`;
  const lexer = new Lexer(source).lex();
  const parser = new Parser(lexer.tokens);
  const ast = parser.parse();
  transform(ast, { enabled: true, rate: 1, strength: 10000, seed: 0x465A0055 });
  function inspect(node) {
    if (!node || typeof node !== "object") return;
    if (node.type === "String") {
      for (let i = 0; i < node.value.length; i++) {
        const unit = node.value.charCodeAt(i);
        assert.ok(!(unit >= 0xD800 && unit <= 0xDBFF && !(node.value.charCodeAt(i + 1) >= 0xDC00 && node.value.charCodeAt(i + 1) <= 0xDFFF)), "unicode split produced an unpaired high surrogate");
        assert.ok(!(unit >= 0xDC00 && unit <= 0xDFFF && !(node.value.charCodeAt(i - 1) >= 0xD800 && node.value.charCodeAt(i - 1) <= 0xDBFF)), "unicode split produced an unpaired low surrogate");
      }
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(inspect);
      else if (value && typeof value === "object") inspect(value);
    }
  }
  inspect(ast);
}

// Check build diversity through execution topology/representation families as well as
// byte inequality; every build must preserve source behavior.
const polyBuilds = [];
const topologySignatures = new Set();
for (let i = 0; i < 12; i++) {
  const result = build("local x=17; local y=20; print(x*y+1)", i % 2 ? "register" : "stack", "l2", (0x46330001 + Math.imul(i + 1, 0x9E3779B9)) >>> 0, 1000);
  assert.strictEqual(result.vmMeta?.actualRepresentationMorphing, true, `polymorphic/${i}: representation morphing inactive`);
  assert.ok(result.vmMeta?.fragmentGraph === true, `polymorphic/${i}: fragment graph inactive`);
  assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `polymorphic/${i}: syntax`);
  const execution = runProgram(lua, result.output, "lua", "341");
  assert.ok(execution.ok, `polymorphic/${i}: behavior diverged: ${execution.stderr}`);
  topologySignatures.add(JSON.stringify([
    result.vmMeta.vmArchitectureFamily,
    result.vmMeta.vmSecondaryArchitecture,
    result.vmMeta.vmMaterializationFamily,
    result.vmMeta.vmPbfFamily,
    result.vmMeta.vmCffFamily,
    result.vmMeta.vmRepresentationStyle,
    result.vmMeta.vmResolverFamily,
    result.vmMeta.vmStateModel,
    result.vmMeta.vmCommitStyle,
    result.vmMeta.vmDispatchStyle,
    result.vmMeta.vmRecipeStyle,
    (result.vmMeta.vmStateOrder || []).join(","),
    result.vmMeta.containerEntries,
    result.vmMeta.containerShards,
    (result.vmMeta.nestedCodecs || []).join(",")
  ]));
  polyBuilds.push(result);
}
assert.strictEqual(new Set(polyBuilds.map(x => x.output)).size, 12, "same-source build output diversity failed");
assert.ok(topologySignatures.size >= 10, `execution topology/representation diversity too low: ${topologySignatures.size}/12`);

// Preserve the nested layer contract for both profiles at maximum strength.
const balanced = nested.wrapSource('print("v465-balanced")', { seed: 0x46340001, strength: 10000, version: "4.6.5", nestedProfile: "balanced" });
const full = nested.wrapSource('print("v465-full")', { seed: 0x46340001, strength: 10000, version: "4.6.5", nestedProfile: "full" });
assert.strictEqual(Number(balanced.layers), 9, "balanced lost nested stages");
assert.strictEqual(Number(full.layers), 9, "full lost nested stages");
assert.strictEqual(full.codecs[8], 4, "v4.6.5 ninth nested layer must use the split/interleaved codec domain");
assert.strictEqual(balanced.codecs[8], 4, "v4.6.5 ninth nested layer must use the split/interleaved codec domain in balanced profile");
for (const [label, wrapped] of [["balanced", balanced], ["full", full]]) {
  assert.ok(!/\bloadstring\b/.test(wrapped.output), `${label}: direct loadstring token leaked`);
  const run = runProgram(lua, wrapped.output, "lua", `v465-${label}`);
  assert.ok(run.ok, `${label}: nested runtime failed: ${run.error || run.stderr}`);
}

// Exercise the v4.6.5 LZSS payload path on input large/repetitive enough to compress.
const compressionProbeSource = `--${"byteveil-nested-compression-probe-".repeat(450)}\nprint("nested-compression-ok")`;
const compressedNested = nested.wrapSource(compressionProbeSource, {
  seed: 0x4634A011, strength: 1000, version: "4.6.5", nestedProfile: "balanced"
});
assert.strictEqual(compressedNested.compression.enabled, true, "compression telemetry should be enabled for v4.6.5");
assert.ok(compressedNested.compression.compressedLayers > 0, "compression path was not used by any nested layer");
assert.ok(compressedNested.compression.bytesSaved > 0, "compression should report positive byte savings");
assert.ok(runSyntaxCheck(lua, compressedNested.output, "lua").ok, "compressed nested wrapper syntax failed");
const compressedRun = runProgram(lua, compressedNested.output, "lua", "nested-compression-ok");
assert.ok(compressedRun.ok, `compressed nested runtime failed: ${compressedRun.error || compressedRun.stderr}`);
const payloadLiterals = [...compressedNested.output.matchAll(/local\s+_[A-Za-z]+=("(?:\\.|[^"\\])*")/g)];
assert.ok(payloadLiterals.length >= 1 && payloadLiterals[0][1].length > 100, "compressed nested payload literal not found");
const literal = payloadLiterals[0][1];
const payloadValue = JSON.parse(literal);
const mutated = JSON.stringify(`!${payloadValue.slice(1)}`);
const tamperedCompressed = compressedNested.output.replace(literal, mutated);
assert.notStrictEqual(tamperedCompressed, compressedNested.output, "compressed tamper fixture unchanged");
assert.ok(!runProgram(lua, tamperedCompressed, "lua").ok, "tampered compressed nested payload executed");

// Long-distance LZSS references must decode correctly when repeated text occurs
// beyond the original 4 KiB window. A repeated >400 KB source activates extended matches.
let prng = 0x4634BEEF;
const alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
let distantChunk = "";
for (let i = 0; i < 6000; i++) {
  prng = (Math.imul(prng, 1664525) + 1013904223) >>> 0;
  distantChunk += alphabet[prng % alphabet.length];
}
const longWindowSource = `--${distantChunk}\n` + `--${distantChunk}\n`.repeat(70) + 'print("long-window-ok")';
assert.ok(Buffer.byteLength(longWindowSource) > 400_000, "long-window fixture must activate adaptive compression");
const longWindowNested = nested.wrapSource(longWindowSource, {
  seed: 0x4634B012, strength: 1000, version: "4.6.5", nestedProfile: "balanced"
});
assert.ok(longWindowNested.compression.longOffsetReferences > 0, "long-distance LZSS tokens were not exercised");
const longWindowRun = runProgram(lua, longWindowNested.output, "lua", "long-window-ok");
assert.ok(longWindowRun.ok, `long-window decompression failed: ${longWindowRun.error || longWindowRun.stderr}`);

// Observe output size across presets without padding or weakening any preset.
const sizeSample = "local a=11; local b=31; print(a+b)";
const presetSizes = {};
for (const preset of ["l1", "l2", "df", "lz"]) {
  const result = obfuscate(sizeSample, {
    target: "lua", mode: "stack", preset, seed: 0x46350001,
    wrapper: { enabled: false }, transforms: { watermark: false }
  });
  assert.strictEqual(result.sizeBudget.preset, preset, `${preset}: preset size attribution`);
  assert.strictEqual(result.sizeBudget.sourceBytes, Buffer.byteLength(sizeSample), `${preset}: source size attribution`);
  assert.strictEqual(result.sizeBudget.outputBytes, Buffer.byteLength(result.output), `${preset}: output size attribution`);
  assert.ok(result.vmMeta.nestedObfuscation === true, `${preset}: default nested protection missing`);
  presetSizes[preset] = result.sizeBudget.outputBytes;
}

const luau = resolveRuntime("luau");
if (luau) {
  const sample = obfuscate('local function add(a,b) return a+b end; print(add(2,3))', {
    target: "luau", mode: "stack", preset: "l2", seed: 0x46360001, strength: 1000,
    wrapper: { enabled: false }, transforms: { watermark: false }
  });
  const syntax = runSyntaxCheck(luau, sample.output, "luau");
  assert.ok(syntax.ok, `Luau syntax failed: ${syntax.error || syntax.stderr}`);
  assert.ok(runProgram(luau, sample.output, "luau", "5").ok, "Luau runtime result mismatch");
} else {
  console.log("[NOT VERIFIED] Luau native runtime not installed/configured in this environment.");
}

console.log(`ByteVeil v4.6.5 semantic runtime cases: PASS (${semanticRuntimeChecks} executions; closure/upvalue/coroutine/metatable/multiple-return/error handling)`);
console.log("ByteVeil v4.6.5 vararg semantics: PASS (scalar/spread/call/assignment/return tested; unsupported table/generic-for tails rejected)");
console.log(`ByteVeil v4.6.5 polymorphic execution topology: PASS (${polyBuilds.length} same-source builds, ${topologySignatures.size} topology/representation signatures)`);
console.log("ByteVeil v4.6.5 nested protection: PASS (balanced/full retain all 9 stages at strength 10000)");
console.log("ByteVeil v4.6.5 nested LZSS payload + long-distance + integrity tamper checks: PASS");
console.log(`ByteVeil v4.6.5 output sizes (bytes): ${JSON.stringify(presetSizes)}`);
console.log("ByteVeil v4.6.5 output-budget telemetry: PASS (375–475 KB tracked, over-budget diagnosed without dropping protection)");

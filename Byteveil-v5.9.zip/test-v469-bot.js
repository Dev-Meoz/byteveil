"use strict";

const assert = require("assert");
const Module = require("module");
process.env.DISCORD_TOKEN = process.env.DISCORD_TOKEN || "unit-test-token-not-valid";

// Keep bot UI tests runnable without authentic Discord packages or credentials.
// Production uses the real discord.js/dotenv dependencies installed by npm.
class FakeEmbedBuilder {
  constructor() { this.data = { fields: [] }; }
  setColor(value) { this.data.color = value; return this; }
  setAuthor(value) { this.data.author = value; return this; }
  setFooter(value) { this.data.footer = value; return this; }
  setTimestamp(value = new Date()) { this.data.timestamp = value; return this; }
  setTitle(value) { this.data.title = value; return this; }
  setDescription(value) { this.data.description = value; return this; }
  addFields(...fields) { this.data.fields.push(...fields.flat()); return this; }
  toJSON() { return this.data; }
}
class FakeAttachmentBuilder {
  constructor(attachment, options = {}) { this.attachment = attachment; this.name = options.name; }
}
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === "discord.js") return { EmbedBuilder: FakeEmbedBuilder, AttachmentBuilder: FakeAttachmentBuilder };
  if (request === "dotenv") return { config: () => ({}) };
  return originalLoad.call(this, request, parent, isMain);
};

const {
  PREFIX,
  PRESETS,
  parsePrefixCommand,
  parseObfArguments,
  stripCodeFence,
  helpEmbed,
  usageEmbed,
  handleMessage,
  executeObfMessage,
} = require("./bot/src/commands");
const { byteCodeRulesEmbed } = require("./bot/src/discord_rules");

function mockMessage(content, attachments = []) {
  const calls = [];
  const edits = [];
  const message = {
    content,
    author: { bot: false, id: "user-test" },
    guild: { id: "guild-test" },
    attachments: {
      size: attachments.length,
      values: () => attachments.values(),
    },
    reply: async (payload) => {
      calls.push(payload);
      return {
        edit: async (payload2) => {
          edits.push(payload2);
          return payload2;
        },
      };
    },
  };
  return { message, calls, edits };
}

async function main() {
  assert.strictEqual(PREFIX, ".");
  assert.deepStrictEqual(PRESETS, ["l1", "l2", "df", "lz"]);
  assert.deepStrictEqual(parsePrefixCommand(".help"), { command: "help", rest: "" });
  assert.deepStrictEqual(parsePrefixCommand(".obf l2 print('hello world')"), {
    command: "obf",
    rest: "l2 print('hello world')",
  });
  assert.deepStrictEqual(parsePrefixCommand("  .rule"), { command: "rule", rest: "" });
  assert.strictEqual(parsePrefixCommand("/help"), null);
  assert.strictEqual(parsePrefixCommand("ordinary chat"), null);
  assert.deepStrictEqual(parseObfArguments("lz print('x')"), { preset: "lz", input: "print('x')" });
  assert.deepStrictEqual(parseObfArguments("l1"), { preset: "l1", input: "" });
  assert.strictEqual(stripCodeFence("```lua\nprint('x')\n```"), "print('x')");
  assert.strictEqual(stripCodeFence("print('plain')"), "print('plain')");

  const help = helpEmbed().toJSON();
  assert.strictEqual(help.title, "COMMAND CENTER");
  assert.ok(help.fields.some((field) => field.value.includes(".obf lz")));
  const usage = usageEmbed("test").toJSON();
  assert.strictEqual(usage.title, "OBFUSCATION · USAGE");
  const rules = byteCodeRulesEmbed().toJSON();
  assert.ok(rules.fields.some((field) => field.value.includes(".obf l1")));

  const helpMock = mockMessage(".help");
  await handleMessage(helpMock.message);
  assert.strictEqual(helpMock.calls.length, 1);
  assert.strictEqual(helpMock.calls[0].embeds[0].data.title, "COMMAND CENTER");

  const botMock = mockMessage(".help");
  botMock.message.author.bot = true;
  await handleMessage(botMock.message);
  assert.strictEqual(botMock.calls.length, 0, "bot authors should be ignored");

  const dmMock = mockMessage(".help");
  dmMock.message.guild = null;
  await handleMessage(dmMock.message);
  assert.strictEqual(dmMock.calls.length, 0, "DMs should be ignored");

  const badPresetMock = mockMessage(".obf nope print('x')");
  await handleMessage(badPresetMock.message);
  assert.strictEqual(badPresetMock.calls.length, 1);
  assert.strictEqual(badPresetMock.calls[0].embeds[0].data.title, "OBFUSCATION · USAGE");

  // Integration smoke: confirm prefix parsing reaches the actual ByteVeil
  // engine and attaches a generated artifact through the redesigned reply.
  const obfMock = mockMessage(".obf l1 print('BYTEVEIL_V469_OK')");
  await executeObfMessage(obfMock.message, "l1 print('BYTEVEIL_V469_OK')");
  assert.strictEqual(obfMock.calls.length, 1, "processing reply expected");
  assert.strictEqual(obfMock.edits.length, 1, "processing reply should be edited to final result");
  const finalReply = obfMock.edits[0];
  assert.strictEqual(finalReply.embeds[0].data.title, "BUILD COMPLETE");
  assert.strictEqual(finalReply.files.length, 1, "obfuscated file should be attached");
  assert.ok(finalReply.files[0].name.endsWith("_l1_obfuscated.lua") || finalReply.files[0].name.endsWith("_l1_obfuscated.luau"));

  process.stdout.write("ByteVeil v4.6.9 Discord prefix/UI tests: PASS\n");
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exit(1);
});

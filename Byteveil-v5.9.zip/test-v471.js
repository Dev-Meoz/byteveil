"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const nested = require("./src/protection/nested_obfuscation");
const watermark = require("./src/transforms/watermark");
const { TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runtime is required");
assert.match(watermark.DEFAULT_WATERMARK, /ByteVeil Obfuscator v4\.7\.1/);
assert.strictEqual(TARGET_MAX_BYTES, 475000);

const direct = nested.wrapSource('print("BV_V471_NESTED_OK")', { seed: 0x47012345, strength: 10000, version: "4.7.1", nestedProfile: "full" });
assert.strictEqual(direct.layers, 9);
assert.strictEqual(direct.codecs[8], 7, "layer 9 must use codec 7");
assert.ok(direct.output.includes("loader provenance mismatch"), "outer layer must embed the loader-provenance guard");
assert.ok(Buffer.byteLength(direct.output) < TARGET_MAX_BYTES);
assert.ok(runSyntaxCheck(lua, direct.output, "lua").ok, "direct nested wrapper syntax");
assert.ok(runProgram(lua, direct.output, "lua", "BV_V471_NESTED_OK").ok, "direct nested wrapper runtime");

// Regression: a pre-installed wrapper around load must not be treated as the native PUC Lua loader.
const loaderHookProbe = `local originalLoad=load; load=function(source, ...) return originalLoad(source, ...) end; local ok,err=pcall(function() ${direct.output} end); print(tostring(ok), tostring(err))`;
const loaderHook = runProgram(lua, loaderHookProbe, "lua", "false\tByteVeil v4.7.1: loader provenance mismatch");
assert.ok(loaderHook.ok, `loader hook probe should report a handled rejection: ${loaderHook.stderr || loaderHook.stdout}`);
assert.match(loaderHook.stdout, /false\tByteVeil v4\.7\.1: loader provenance mismatch/);
const loadstringHookProbe = `loadstring=function(source) return load(source) end; local ok,err=pcall(function() ${direct.output} end); print(tostring(ok), tostring(err))`;
const loadstringHook = runProgram(lua, loadstringHookProbe, "lua", "false\tByteVeil v4.7.1: loader provenance mismatch");
assert.ok(loadstringHook.ok, `loadstring hook probe should report a handled rejection: ${loadstringHook.stderr || loadstringHook.stdout}`);
assert.match(loadstringHook.stdout, /false\tByteVeil v4\.7\.1: loader provenance mismatch/);

// Simulate a non-PUC runtime label: native provenance is skipped and normal execution remains possible.
// This is a guard-branch test, not a claim that native Luau has been tested.
const fallbackProbe = `local savedVersion=_VERSION; _VERSION="Luau"; ${direct.output}`;
assert.ok(runSyntaxCheck(lua, fallbackProbe, "lua").ok, "non-PUC fallback syntax");
assert.ok(runProgram(lua, fallbackProbe, "lua", "BV_V471_NESTED_OK").ok, "non-PUC fallback runtime");
// Exercise every layer-9 recurrence shape, not just the default shape for one seed.
for (const seed of [1, 2, 3, 6]) {
  const layerSeed = (seed ^ Math.imul(9, 0x9E3779B9) ^ 0x369DEA0F) >>> 0;
  const variant = nested._deep47Variant(layerSeed, 0xB4709E31);
  const wrapped = nested.wrapSource(`print("BV_V471_VARIANT_${variant}_OK")`, { seed, strength: 10000, version: "4.7.1", nestedProfile: "full" });
  assert.strictEqual(wrapped.layers, 9);
  assert.strictEqual(wrapped.codecs[8], 7);
  assert.ok(runSyntaxCheck(lua, wrapped.output, "lua").ok, `layer-9 variant ${variant} syntax`);
  assert.ok(runProgram(lua, wrapped.output, "lua", `BV_V471_VARIANT_${variant}_OK`).ok, `layer-9 variant ${variant} runtime`);
}

const pipelineSource = fs.readFileSync(path.join(__dirname, "examples/input.lua"), "utf8");
const result = obfuscate(pipelineSource, {
  source: pipelineSource, target: "lua", mode: "stack", preset: "lz",
  seed: 0x463B0001, strength: 10000, wrapper: { enabled: false }, transforms: { watermark: false },
});
assert.strictEqual(result.vmMeta?.version, "4.7.1");
assert.strictEqual(result.vmMeta?.generatorEngine, "MFG-4.7.1");
assert.strictEqual(result.vmMeta?.nestedObfuscationLayers, 9);
assert.strictEqual(result.vmMeta?.nestedCodecs?.[8], 7);
assert.strictEqual(result.vmMeta?.instructionDecoderStyle, "two-specialized-parity-families-with-canonical-operands");
assert.match(result.vmMeta?.runtimeApiProvenanceCheck || "", /load\+loadstring/);
assert.ok(Buffer.byteLength(result.output) < TARGET_MAX_BYTES, `output exceeded 475000 bytes: ${Buffer.byteLength(result.output)}`);
assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, "pipeline output syntax");
assert.ok(runProgram(lua, result.output, "lua", "5").ok, "pipeline output runtime");

// Semantic guardrails for closure/upvalue, coroutine, metamethod, varargs and multiple returns.
const cases = [
  ['local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3),f(4))', '5\t9'],
  ['local n=1; local function inc() n=n+1; return n end; print(inc(),inc())', '2\t3'],
  ['local co=coroutine.create(function(x) coroutine.yield(x+1); return x+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)', 'true\t5\ttrue\t6'],
  ['local mt={__add=function(a,b) return {n=a.n+b.n} end}; local a=setmetatable({n=2},mt); local b=setmetatable({n=3},mt); print((a+b).n)', '5'],
  ['local function f(...) return 7,... end; local a,b,c=f(1,2); print(a,b,c)', '7\t1\t2'],
];
let checked=0;
for (const [index, [source, expected]] of cases.entries()) {
  for (const mode of ["stack", "register"]) {
    const built=obfuscate(source,{source,target:"lua",mode,preset:"l1",seed:(0x47020000+index*31+(mode==="register"?1:0))>>>0,strength:1200,wrapper:{enabled:false},transforms:{watermark:false}});
    assert.strictEqual(built.vmMeta?.version,"4.7.1");
    assert.ok(runSyntaxCheck(lua,built.output,"lua").ok,`${mode} case ${index} syntax`);
    const run=runProgram(lua,built.output,"lua",expected);
    assert.ok(run.ok,`${mode} case ${index}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(run.stdout)}; ${run.error||run.stderr}`);
    checked++;
  }
}
console.log(`ByteVeil v4.7.1 runtime regression: PASS (${checked} VM semantic runs + nested layer-9 round-trip; ${Buffer.byteLength(result.output)} bytes)`);

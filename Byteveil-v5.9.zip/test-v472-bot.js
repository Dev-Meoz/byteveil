"use strict";

const assert = require("assert");
const Module = require("module");
process.env.DISCORD_TOKEN = "unit-test-token-not-valid";
process.env.DISCORD_CLIENT_ID = "client-test";
process.env.DISCORD_GUILD_ID = "guild-test";

class FakeEmbedBuilder {
  constructor() { this.data = { fields: [] }; }
  setColor(v) { this.data.color = v; return this; }
  setAuthor(v) { this.data.author = v; return this; }
  setFooter(v) { this.data.footer = v; return this; }
  setTimestamp(v = new Date()) { this.data.timestamp = v; return this; }
  setTitle(v) { this.data.title = v; return this; }
  setDescription(v) { this.data.description = v; return this; }
  addFields(...v) { this.data.fields.push(...v.flat()); return this; }
  toJSON() { return this.data; }
}
class FakeAttachmentBuilder { constructor(attachment, options = {}) { this.attachment = attachment; this.name = options.name; } }
class FakeOptionBuilder {
  constructor(type = "string") { this.data = { type, choices: [] }; }
  setName(v) { this.data.name = v; return this; }
  setDescription(v) { this.data.description = v; return this; }
  setRequired(v) { this.data.required = v; return this; }
  addChoices(...v) { this.data.choices.push(...v.flat()); return this; }
  toJSON() { return this.data; }
}
class FakeSlashCommandBuilder extends FakeOptionBuilder {
  constructor() { super("command"); this.data.options = []; }
  addStringOption(fn) { this.data.options.push(fn(new FakeOptionBuilder("string")).toJSON()); return this; }
  addAttachmentOption(fn) { this.data.options.push(fn(new FakeOptionBuilder("attachment")).toJSON()); return this; }
}
const stores = new Map();
class FakeREST {
  setToken(token) { this.token = token; return this; }
  async get(route) { return structuredClone(stores.get(route) || []); }
  async put(route, { body }) {
    for (const command of body) assert.ok(!Object.prototype.hasOwnProperty.call(command, "id"), "REST bulk overwrite must not re-send read-only command IDs");
    stores.set(route, structuredClone(body));
    return body;
  }
}
const FakeRoutes = {
  applicationCommands: (clientId) => `global:${clientId}`,
  applicationGuildCommands: (clientId, guildId) => `guild:${clientId}:${guildId}`,
};
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === "discord.js") return {
    SlashCommandBuilder: FakeSlashCommandBuilder,
    AttachmentBuilder: FakeAttachmentBuilder,
    EmbedBuilder: FakeEmbedBuilder,
    REST: FakeREST,
    Routes: FakeRoutes,
  };
  if (request === "dotenv") return { config: () => ({}) };
  return originalLoad.call(this, request, parent, isMain);
};

const { commands, execute, PRESETS, helpEmbed, usageEmbed } = require("./bot/src/commands");
const { byteCodeRulesEmbed } = require("./bot/src/discord_rules");
const { deployCommands } = require("./bot/src/deploy-commands");

function interaction(commandName, options = {}) {
  const calls = { reply: [], defer: 0, edits: [] };
  const item = {
    commandName,
    options: {
      getString: (name, required = false) => {
        const value = options[name] ?? null;
        if (required && value == null) throw new Error(`missing required option ${name}`);
        return value;
      },
      getAttachment: (name) => options[name] ?? null,
    },
    deferred: false,
    replied: false,
    isChatInputCommand: () => true,
    reply: async (payload) => { calls.reply.push(payload); item.replied = true; return payload; },
    deferReply: async () => { calls.defer += 1; item.deferred = true; },
    editReply: async (payload) => { calls.edits.push(payload); return payload; },
    _calls: calls,
  };
  return item;
}

async function main() {
  assert.deepStrictEqual(PRESETS, ["l1", "l2", "df", "lz"]);
  assert.deepStrictEqual(commands.map((c) => c.name), ["help", "rule", "obf"]);
  const obf = commands.find((c) => c.name === "obf");
  assert.deepStrictEqual(obf.options.map((o) => o.name), ["presets", "attach", "input", "upload"]);
  assert.deepStrictEqual(obf.options[0].choices.map((c) => c.value), PRESETS);
  assert.deepStrictEqual(obf.options[1].choices.map((c) => c.value), ["code", "file", "url"]);

  const help = helpEmbed().toJSON();
  assert.strictEqual(help.title, "COMMAND CENTER");
  assert.ok(help.fields.some((f) => f.value.includes("/obf presets:lz")));
  assert.strictEqual(usageEmbed("test").toJSON().title, "OBFUSCATION · USAGE");
  const rules = byteCodeRulesEmbed().toJSON();
  assert.ok(rules.fields.some((f) => f.value.includes("/obf presets:l1")));
  assert.match(rules.footer.text, /v4\.7\.2/);

  const h = interaction("help");
  await execute(h);
  assert.strictEqual(h._calls.reply.length, 1);
  assert.strictEqual(h._calls.reply[0].embeds[0].data.title, "COMMAND CENTER");
  assert.strictEqual(h._calls.reply[0].ephemeral, true);

  const r = interaction("rule");
  await execute(r);
  assert.strictEqual(r._calls.reply.length, 1);
  assert.ok(r._calls.reply[0].embeds[0].data.title.includes("RULES"));

  const bad = interaction("obf", { presets: "bad", attach: "code", input: "print(1)" });
  await execute(bad);
  assert.strictEqual(bad._calls.defer, 1);
  assert.strictEqual(bad._calls.edits.at(-1).embeds[0].data.title, "REQUEST FAILED  /  OBF");

  // Integration smoke: /obf must run the real engine and deliver a generated file.
  const real = interaction("obf", { presets: "l1", attach: "code", input: 'print("BV_V472_SLASH_ENGINE_OK")' });
  await execute(real);
  assert.strictEqual(real._calls.defer, 1);
  assert.strictEqual(real._calls.edits.length, 2, "processing state and final output expected");
  const response = real._calls.edits.at(-1);
  assert.strictEqual(response.embeds[0].data.title, "BUILD COMPLETE");
  assert.strictEqual(response.files.length, 1);
  assert.match(response.files[0].name, /_l1_obfuscated\.(lua|luau)$/);
  assert.ok(response.files[0].attachment.length > 0);

  // Deploy tests prove stale ByteVeil commands are reset while unrelated app commands survive.
  stores.set("global:client-test", [{ id: "g-help", name: "help" }, { id: "g-keep", name: "unrelated" }, { id: "g-obf", name: "obf" }]);
  stores.set("guild:client-test:guild-test", [{ id: "s-rule", name: "rule" }, { id: "s-keep", name: "guild-extra" }]);
  await deployCommands();
  const globalAfter = stores.get("global:client-test");
  const guildAfter = stores.get("guild:client-test:guild-test");
  assert.deepStrictEqual(globalAfter.map((c) => c.name), ["unrelated"]);
  assert.deepStrictEqual(guildAfter.map((c) => c.name), ["guild-extra", "help", "rule", "obf"]);
  assert.strictEqual(guildAfter.filter((c) => ["help", "rule", "obf"].includes(c.name)).length, 3);

  process.stdout.write("ByteVeil v4.7.2 slash-command/deploy tests: PASS\n");
}
main().catch((error) => { console.error(error.stack || error); process.exit(1); });

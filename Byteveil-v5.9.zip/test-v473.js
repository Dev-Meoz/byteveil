"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const watermark = require("./src/transforms/watermark");
const { TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runtime is required");
assert.match(watermark.DEFAULT_WATERMARK, /ByteVeil Obfuscator v4\.7\.3/);
assert.strictEqual(TARGET_MAX_BYTES, 475000);

const src = 'local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3), "BV473-你好-đồng-hành")';
const direct = obfuscate(src, {
  source: src, target: "lua", mode: "stack", preset: "l1", seed: 0x47212345,
  strength: 10000, wrapper: { enabled: false }, transforms: { watermark: false }
});
assert.strictEqual(direct.vmMeta?.version, "4.7.3");
assert.strictEqual(direct.vmMeta?.generatorEngine, "MFG-4.7.3-single-layer");
assert.strictEqual(direct.vmMeta?.singleLayerEngine, true);
assert.strictEqual(direct.vmMeta?.protectionLayers, 1);
assert.strictEqual(direct.vmMeta?.nestedObfuscation, false);
assert.strictEqual(direct.vmMeta?.nestedObfuscationLayers, 0);
assert.deepStrictEqual(direct.vmMeta?.nestedCodecs, []);
assert.strictEqual(direct.vmMeta?.nestedProfile, "disabled-single-layer");
assert.strictEqual(direct.vmMeta?.runtimeSourceLoaderCount, 0);
assert.strictEqual(direct.vmMeta?.intraVmIntegrity, true);
assert.strictEqual(direct.vmMeta?.protectionPlan?.nestedObfuscation, false);
assert.strictEqual(direct.vmMeta?.protectionPlan?.singleLayerEngine, true);
assert.strictEqual(direct.sizeBudget?.targetMinBytes, 0);
assert.strictEqual(direct.sizeBudget?.withinTarget, true);
assert.ok(!/\bloadstring\s*\(/.test(direct.output), "single-layer output must not call loadstring to reveal another source layer");
assert.ok(!/\bload\s*\(/.test(direct.output), "single-layer output must not call load to reveal another source layer");
assert.ok(Buffer.byteLength(direct.output) < TARGET_MAX_BYTES, "single-layer direct output must remain under the maximum size budget");
assert.ok(runSyntaxCheck(lua, direct.output, "lua").ok, "single-layer VM syntax");
assert.ok(runProgram(lua, direct.output, "lua", "5\tBV473-你好-đồng-hành").ok, "single-layer VM runtime");

// The default API wrapper does not reintroduce nested source-loader layers.
const defaultWrapped = obfuscate('print("DEFAULT_WRAPPER_SINGLE_LAYER")', {
  source: 'print("DEFAULT_WRAPPER_SINGLE_LAYER")', target: "lua", mode: "stack", preset: "l1", seed: 0x473001,
  transforms: { watermark: false }
});
assert.strictEqual(defaultWrapped.vmMeta?.singleLayerEngine, true);
assert.strictEqual(defaultWrapped.vmMeta?.nestedObfuscationLayers, 0);
assert.ok(!/\bloadstring\s*\(/.test(defaultWrapped.output));
assert.ok(!/\bload\s*\(/.test(defaultWrapped.output));
assert.ok(runSyntaxCheck(lua, defaultWrapped.output, "lua").ok);
assert.ok(runProgram(lua, defaultWrapped.output, "lua", "DEFAULT_WRAPPER_SINGLE_LAYER").ok);

// Luau generation remains available and selects the same single-layer backend.
// This verifies generated-source sanity only; native Roblox Luau execution is not available here.
const luauSource = 'local x = 4; print(x + 1)';
const luauBuilt = obfuscate(luauSource, { source: luauSource, target: "luau", mode: "register", preset: "l1", seed: 0x473002, wrapper: { enabled: false }, transforms: { watermark: false } });
assert.strictEqual(luauBuilt.target, "luau");
assert.strictEqual(luauBuilt.vmMeta?.singleLayerEngine, true);
assert.strictEqual(luauBuilt.vmMeta?.nestedObfuscationLayers, 0);
assert.ok(luauBuilt.output.length > 1000, "Luau packed VM output should be generated");

// Loader wrappers remain detected by the VM startup guard when native Lua exposes provenance.
for (const [label, prefix] of [
  ["load", "local originalLoad=load; load=function(source, ...) return originalLoad(source, ...) end;"],
  ["loadstring", "loadstring=function(source) return load(source) end;"]
]) {
  const probe = `${prefix} local ok,err=pcall(function() ${direct.output} end); print(tostring(ok), tostring(err))`;
  const run = runProgram(lua, probe, "lua");
  assert.ok(run.ok, `${label} hook probe should report handled rejection: ${run.stderr || run.stdout}`);
  assert.match(run.stdout, /false\tByteVeil v4\.7\.3: .*provenance mismatch/);
}

// Single-layer output preserves semantics in both existing VM modes.
const semanticCases = [
  ['local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3),f(4))', '5\t9'],
  ['local co=coroutine.create(function(x) coroutine.yield(x+1); return x+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)', 'true\t5\ttrue\t6'],
];
let vmRuns = 0;
for (const [i, [source, expected]] of semanticCases.entries()) {
  for (const mode of ["stack", "register"]) {
    const built = obfuscate(source, { source, target: "lua", mode, preset: "l1", seed: (0x47220000 + i * 13 + (mode === "register" ? 1 : 0)) >>> 0, strength: 1200, wrapper: { enabled: false }, transforms: { watermark: false } });
    assert.strictEqual(built.vmMeta?.version, "4.7.3");
    assert.strictEqual(built.vmMeta?.nestedObfuscationLayers, 0);
    assert.strictEqual(built.vmMeta?.protectionLayers, 1);
    assert.ok(runSyntaxCheck(lua, built.output, "lua").ok, `${mode} semantic ${i} syntax`);
    const executed = runProgram(lua, built.output, "lua", expected);
    assert.ok(executed.ok, `${mode} semantic ${i}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(executed.stdout)}; ${executed.error || executed.stderr}`);
    vmRuns++;
  }
}

// All public presets take the same single-layer VM route.
for (const preset of ["l1", "l2", "df", "lz"]) {
  const source = `print("SINGLE_LAYER_${preset.toUpperCase()}")`;
  const built = obfuscate(source, { source, target: "lua", mode: "stack", preset, seed: 0x47300000 + preset.length, wrapper: { enabled: false }, transforms: { watermark: false } });
  assert.strictEqual(built.vmMeta?.singleLayerEngine, true, `${preset} must not fall back to nested layers`);
  assert.strictEqual(built.vmMeta?.nestedObfuscationLayers, 0, `${preset} nested layers must be disabled`);
  assert.ok(Buffer.byteLength(built.output) < TARGET_MAX_BYTES, `${preset} output over max budget`);
  assert.ok(runSyntaxCheck(lua, built.output, "lua").ok, `${preset} syntax`);
  assert.ok(runProgram(lua, built.output, "lua", `SINGLE_LAYER_${preset.toUpperCase()}`).ok, `${preset} runtime`);
}

// Full release fixture and explicit no-nested assertions.
const fixture = fs.readFileSync(path.join(__dirname, "examples/input.lua"), "utf8");
const result = obfuscate(fixture, { source: fixture, target: "lua", mode: "stack", preset: "lz", seed: 0x472B0001, strength: 10000, wrapper: { enabled: false }, transforms: { watermark: false } });
assert.strictEqual(result.vmMeta?.version, "4.7.3");
assert.strictEqual(result.vmMeta?.generatorEngine, "MFG-4.7.3-single-layer");
assert.strictEqual(result.vmMeta?.singleLayerEngine, true);
assert.strictEqual(result.vmMeta?.nestedObfuscation, false);
assert.strictEqual(result.vmMeta?.nestedObfuscationLayers, 0);
assert.strictEqual(result.vmMeta?.protectionLayers, 1);
assert.strictEqual(result.vmMeta?.protectionPlan?.nestedObfuscation, false);
assert.ok(Buffer.byteLength(result.output) < TARGET_MAX_BYTES, `fixture output exceeded 475000 bytes: ${Buffer.byteLength(result.output)}`);
assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, "release fixture syntax");
assert.ok(runProgram(lua, result.output, "lua", "5").ok, "release fixture runtime");

console.log(`ByteVeil v4.7.3 single-layer VM regression: PASS (${vmRuns} semantic mode runs, all 4 presets, zero nested source layers; fixture=${Buffer.byteLength(result.output)} bytes)`);

"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const nested = require("./src/protection/nested_obfuscation");
const watermark = require("./src/transforms/watermark");
const { TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runtime is required");
assert.match(watermark.DEFAULT_WATERMARK, /ByteVeil Obfuscator v4\.7\.4/);
assert.strictEqual(TARGET_MAX_BYTES, 475000);

// Layer-9 codec 8 must be present without requiring buffer/bit32 or a substitute runtime.
const src = 'local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3), "BV474-你好-đồng-hành")';
const direct = nested.wrapSource(src, { seed: 0x47412345, strength: 10000, version: "4.7.4", nestedProfile: "full" });
assert.strictEqual(direct.layers, 9);
assert.strictEqual(direct.codecs[8], 8, "the ninth layer must use codec 8");
assert.ok(direct.output.includes("loader provenance mismatch"), "outer layer should preserve loader provenance check");
assert.ok(!direct.output.includes("deepest lane layout"), "codec 8 must not expose the old four-delimiter lane framing");
assert.ok(Buffer.byteLength(direct.output) < TARGET_MAX_BYTES, "direct nested test output should be under size budget");
assert.ok(runSyntaxCheck(lua, direct.output, "lua").ok, "direct layer 9 syntax");
assert.ok(runProgram(lua, direct.output, "lua", "5\tBV474-你好-đồng-hành").ok, "direct layer 9 runtime");

// Each distinct deepest-layer decoder recurrence shape must round-trip.
const seedsByVariant = {};
for (let seed = 1; seed <= 512 && Object.keys(seedsByVariant).length < 4; seed++) {
  const layerSeed = (seed ^ Math.imul(9, 0x9E3779B9) ^ 0x474DEA11) >>> 0;
  const variant = nested._deep48Variant(layerSeed, 0);
  if (seedsByVariant[variant] === undefined) seedsByVariant[variant] = seed;
}
assert.strictEqual(Object.keys(seedsByVariant).length, 4, "all four recurrence variants must be reachable");
for (const [variantString, seed] of Object.entries(seedsByVariant)) {
  const variant = Number(variantString);
  const layerSeed = (seed ^ Math.imul(9, 0x9E3779B9) ^ 0x474DEA11) >>> 0;
  assert.strictEqual(nested._deep48Variant(layerSeed, 0), variant);
  const wrapped = nested.wrapSource(`print("BV474_VARIANT_${variant}_OK")`, { seed, strength: 10000, version: "4.7.4", nestedProfile: "full" });
  assert.strictEqual(wrapped.layers, 9);
  assert.strictEqual(wrapped.codecs[8], 8);
  assert.ok(runSyntaxCheck(lua, wrapped.output, "lua").ok, `variant ${variant} syntax`);
  assert.ok(runProgram(lua, wrapped.output, "lua", `BV474_VARIANT_${variant}_OK`).ok, `variant ${variant} runtime`);
}

// API wrapper tests are explicit and must fail closed under PUC Lua 5.4.
for (const [label, prefix, expected] of [
  ["load", "local originalLoad=load; load=function(source, ...) return originalLoad(source, ...) end;", /loader provenance mismatch/],
  ["loadstring", "loadstring=function(source) return load(source) end;", /loader provenance mismatch/],
]) {
  const probe = `${prefix} local ok,err=pcall(function() ${direct.output} end); print(tostring(ok), tostring(err))`;
  const run = runProgram(lua, probe, "lua");
  assert.ok(run.ok, `${label} hook probe should report handled rejection: ${run.stderr || run.stdout}`);
  assert.match(run.stdout, new RegExp(`false\\tByteVeil v4\\.7\\.4: ${expected.source.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`));
}

// Test non-PUC fallback guard branch by simulation only; this is NOT native Luau validation.
const fallback = `local previous=_VERSION; _VERSION="Luau"; ${direct.output}`;
assert.ok(runSyntaxCheck(lua, fallback, "lua").ok, "fallback syntax");
assert.ok(runProgram(lua, fallback, "lua", "5\tBV474-你好-đồng-hành").ok, "fallback runtime branch");

// Two representative VM semantic tests in both existing modes.
const semanticCases = [
  ['local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3),f(4))', '5\t9'],
  ['local co=coroutine.create(function(x) coroutine.yield(x+1); return x+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)', 'true\t5\ttrue\t6'],
];
let vmRuns = 0;
for (const [i, [source, expected]] of semanticCases.entries()) {
  for (const mode of ["stack", "register"]) {
    const built = obfuscate(source, { source, target:"lua", mode, preset:"l1", seed:(0x47420000 + i*13 + (mode === "register" ? 1 : 0)) >>> 0, strength:1200, wrapper:{enabled:false}, transforms:{watermark:false} });
    assert.strictEqual(built.vmMeta?.version, "4.7.4");
    assert.ok(runSyntaxCheck(lua, built.output, "lua").ok, `${mode} semantic ${i} syntax`);
    const executed = runProgram(lua, built.output, "lua", expected);
    assert.ok(executed.ok, `${mode} semantic ${i}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(executed.stdout)}; ${executed.error || executed.stderr}`);
    vmRuns++;
  }
}

// Public preset matrix: every preset must retain its strength-tiered layer count and run identically.
{
  const presetSource = 'local function add(a,b) return a+b end; print("PRESET_OK",add(2,3))';
  const presetCases = [["l1",3],["l2",5],["df",7],["lz",9]];
  for (const [i, [preset, expectedLayers]] of presetCases.entries()) {
    const built = obfuscate(presetSource, { source:presetSource, target:"lua", mode:"stack", preset, seed:(0x474A0001 + i) >>> 0 });
    assert.strictEqual(built.vmMeta?.version, "4.7.4", `${preset}: engine version`);
    assert.strictEqual(built.vmMeta?.nestedObfuscationLayers, expectedLayers, `${preset}: nested layer count`);
    if (preset === "lz") assert.strictEqual(built.vmMeta?.nestedCodecs?.[8], 8, "lz deepest layer must use codec 8");
    assert.ok(runSyntaxCheck(lua, built.output, "lua").ok, `${preset}: syntax`);
    const execution = runProgram(lua, built.output, "lua", "PRESET_OK\t5");
    assert.ok(execution.ok, `${preset}: expected PRESET_OK\t5, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
  }
}

// Luau-target source is generated and checked for portable syntax here. This does not replace a native Luau runtime test.
{
  const luauSource = 'print("LUAU_TARGET_OK")';
  const built = obfuscate(luauSource, { source:luauSource, target:"luau", mode:"stack", preset:"lz", seed:0x474C0001, wrapper:{enabled:false}, transforms:{watermark:false} });
  assert.strictEqual(built.target, "luau");
  assert.strictEqual(built.vmMeta?.nestedObfuscationLayers, 9);
  assert.ok(runSyntaxCheck(lua, built.output, "lua").ok, "Luau target output should retain portable Lua syntax");
}

// Full release fixture, including nested codec 8 and target output budget.
const fixture = fs.readFileSync(path.join(__dirname, "examples/input.lua"), "utf8");
const result = obfuscate(fixture, { source:fixture, target:"lua", mode:"stack", preset:"lz", seed:0x474B0001, strength:10000, wrapper:{enabled:false}, transforms:{watermark:false} });
assert.strictEqual(result.vmMeta?.version, "4.7.4");
assert.strictEqual(result.vmMeta?.generatorEngine, "MFG-4.7.4");
assert.strictEqual(result.vmMeta?.nestedObfuscationLayers, 9);
assert.strictEqual(result.vmMeta?.nestedCodecs?.[8], 8);
assert.match(result.vmMeta?.runtimeApiProvenanceCheck || "", /load\+loadstring/);
const outputBytes = Buffer.byteLength(result.output);
assert.ok(outputBytes < TARGET_MAX_BYTES, `fixture output exceeded 475000 bytes: ${outputBytes}`);
assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, "release fixture syntax");
assert.ok(runProgram(lua, result.output, "lua", "5").ok, "release fixture runtime");

console.log(`ByteVeil v4.7.4 nested VM regression: PASS (${vmRuns} semantic mode runs, 4 codec variants, 9 nested layers; fixture=${outputBytes} bytes)`);

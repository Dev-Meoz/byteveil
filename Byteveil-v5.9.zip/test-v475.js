"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { transformBytesV475, inverseTransformBytesV475 } = require("./src/backend/bytecode_serializer");
const watermark = require("./src/transforms/watermark");
const { TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runtime is required for v4.7.5 release/crack tests");
assert.match(watermark.DEFAULT_WATERMARK, /ByteVeil Obfuscator v4\.7\.5/);
assert.strictEqual(TARGET_MAX_BYTES, 475000);

// The eight lane transform must be reversible for arbitrary bytes and materials.
let state = 0x475A11CE;
const random = () => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return state >>> 0; };
for (let sample = 0; sample < 64; sample++) {
  const bytes = Array.from({ length: 1 + (sample * 37 % 513) }, () => random() & 0xff);
  const materials = Array.from({ length: 8 }, () => random());
  const encoded = transformBytesV475(bytes, materials).bytes;
  const decoded = inverseTransformBytesV475(encoded, materials);
  assert.deepStrictEqual(decoded, bytes, `eight-lane codec round-trip ${sample}`);
}

function build(source, { mode = "stack", preset = "l1", seed = 0x47510001, target = "lua", strength = 1800, watermark = false } = {}) {
  return obfuscate(source, {
    source, target, mode, preset, seed, strength,
    wrapper: { enabled: false }, transforms: { watermark }
  });
}

function assertNoSourceLoaderStages(result, label) {
  assert.strictEqual(result.vmMeta.version, "4.7.5", `${label}: active version`);
  assert.strictEqual(result.vmMeta.nestedObfuscationLayers, 0, `${label}: no source-onion layers`);
  assert.strictEqual(result.vmMeta.runtimeSourceLoaderCount, 0, `${label}: no source loaders declared`);
  assert.strictEqual(result.vmMeta.sourceLoaderStages, 0, `${label}: no source-loader stages`);
  assert.strictEqual(result.vmMeta.payloadTransformLayers, 8, `${label}: eight binary region transforms`);
  assert.strictEqual(result.vmMeta.nativeBufferRuntime, true, `${label}: native Luau buffer path is emitted`);
  assert.strictEqual(result.vmMeta.nestedProfile, "binary-region-no-source-loader", `${label}: accurate profile metadata`);
  assert.match(result.vmMeta.generatorEngine, /4\.7\.5-binary-region-vm/);
  assert.match(result.vmMeta.runtimeApiProvenanceCheck, /no source-loader call sites/);
  assert.doesNotMatch(result.output, /(?<![\w])(?:loadstring|load)\s*\(/, `${label}: output must not compile source stages`);
  assert.doesNotMatch(result.output, /__bv_load|__bv_envload|loadstring/, `${label}: loader identifiers must not be embedded`);
}

// Source-loader crack test: hook both standard loaders, without bypassing or changing VM guards.
// The runtime must execute correctly and the hook must observe zero loader calls.
function runLoaderCrackProbe(output, expected, label) {
  const hook = [
    'local __origload=load;',
    'load=function(...) io.stderr:write("BV475_LOAD_CALL\\n"); return __origload(...) end;',
    'loadstring=function(...) io.stderr:write("BV475_LOADSTRING_CALL\\n"); return __origload(...) end;'
  ].join(" ") + "\n";
  const run = runProgram(lua, hook + output, "lua", expected);
  assert.ok(run.ok, `${label}: runtime under loader hooks failed: ${run.error || run.stderr || run.stdout}`);
  assert.ok(!/BV475_LOAD(?:STRING)?_CALL/.test(run.stderr), `${label}: at least one source loader was called: ${run.stderr}`);
  return run;
}

// Tiny program: syntax, native runtime, no loader calls, and optional buffer-backed region cache.
const source = 'local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print("BV475", f(3), f(4))';
const direct = build(source, { preset: "lz", seed: 0x47512345, strength: 10000 });
assertNoSourceLoaderStages(direct, "direct build");
assert.ok(Buffer.byteLength(direct.output) < TARGET_MAX_BYTES, "direct output exceeds size budget");
assert.ok(runSyntaxCheck(lua, direct.output, "lua").ok, "v475 syntax");
assert.ok(runProgram(lua, direct.output, "lua", "BV475\t5\t9").ok, "v475 runtime semantics");
runLoaderCrackProbe(direct.output, "BV475\t5\t9", "loader instrumentation probe");

// Reproduce the exact observable print text in the v4.7.4 crack log, without running its
// recovered layer or the original protected artifact. This is a behavior fixture only.
const observedText = "Long ngu như bò giống như bro á test script mã hóa trong sandbox ko sợ bị chạy mã độc hả?";
const observedRepro = build(`print(${JSON.stringify(observedText)})`, {
  preset: "lz", seed: 0x475D0001, strength: 10000
});
assertNoSourceLoaderStages(observedRepro, "v4.7.4 observed-output reproduction");
assert.ok(!observedRepro.output.includes(observedText), "observed output text must not remain as a plaintext source literal");
assert.ok(runSyntaxCheck(lua, observedRepro.output, "lua").ok, "observed-output reproduction syntax");
assert.ok(runProgram(lua, observedRepro.output, "lua", observedText).ok, "observed-output reproduction runtime");
runLoaderCrackProbe(observedRepro.output, observedText, "v4.7.4 observed-output loader crack probe");

// Exercise the native-buffer execution branch under a Lua-side buffer API shim. This validates
// zero-based read/write integration and checks that it behaves identically to the byte-array path.
const bufferShim = 'buffer={create=function(n) return {n=n,b={}} end, writeu8=function(b,i,v) b.b[i]=v%256 end, readu8=function(b,i) return b.b[i] end};\n';
const bufferRun = runProgram(lua, bufferShim + direct.output, "lua", "BV475\t5\t9");
assert.ok(bufferRun.ok, `buffer-backed region runtime failed: ${bufferRun.error || bufferRun.stderr || bufferRun.stdout}`);
runLoaderCrackProbe(bufferShim + direct.output, "BV475\t5\t9", "buffer + loader instrumentation probe");

// Semantic regression in both VM modes: closures/upvalues and coroutine yields/multiple returns.
const semanticCases = [
  ['local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3),f(4))', '5\t9'],
  ['local co=coroutine.create(function(x) coroutine.yield(x+1); return x+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)', 'true\t5\ttrue\t6'],
  ['local function many() return 2,3,4 end; local a,b,c=many(); print(a,b,c)', '2\t3\t4'],
];
let semanticRuns = 0;
for (const [i, [program, expected]] of semanticCases.entries()) {
  for (const mode of ["stack", "register"]) {
    const result = build(program, { mode, preset: "l1", seed: (0x47520001 + i * 17 + (mode === "register" ? 1 : 0)) >>> 0 });
    assertNoSourceLoaderStages(result, `${mode} semantic ${i}`);
    assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${mode} semantic ${i} syntax`);
    const execution = runProgram(lua, result.output, "lua", expected);
    assert.ok(execution.ok, `${mode} semantic ${i}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
    semanticRuns++;
  }
}

// Public preset matrix: presets vary payload strength/shape, not the number of source-loader stages.
const presetSource = 'local function add(a,b) return a+b end; print("PRESET_OK",add(2,3))';
for (const [i, preset] of ["l1", "l2", "df", "lz"].entries()) {
  const result = build(presetSource, { preset, seed: (0x47530001 + i) >>> 0, strength: ({ l1: 1800, l2: 3500, df: 8000, lz: 10000 })[preset], watermark: true });
  assertNoSourceLoaderStages(result, `preset ${preset}`);
  assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${preset}: syntax`);
  const execution = runProgram(lua, result.output, "lua", "PRESET_OK\t5");
  assert.ok(execution.ok, `${preset}: expected PRESET_OK\t5, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
}

// Full shipped fixture under maximum settings; this is a per-fixture budget, not a universal size claim.
const fixture = fs.readFileSync(path.join(__dirname, "examples/input.lua"), "utf8");
const full = build(fixture, { preset: "lz", seed: 0x475B0001, strength: 10000 });
assertNoSourceLoaderStages(full, "release fixture");
assert.strictEqual(full.vmMeta.generatorEngine, "MFG-4.7.5-binary-region-vm");
const outputBytes = Buffer.byteLength(full.output);
assert.ok(outputBytes < TARGET_MAX_BYTES, `fixture output exceeded 475000 bytes: ${outputBytes}`);
assert.ok(runSyntaxCheck(lua, full.output, "lua").ok, "release fixture syntax");
assert.ok(runProgram(lua, full.output, "lua", "5").ok, "release fixture runtime");
runLoaderCrackProbe(full.output, "5", "release fixture crack probe");

// Luau target output must retain portable syntax. Native Roblox/Luau isn't installed in this environment.
const luauResult = build('print("LUAU_TARGET_OK")', { target: "luau", preset: "lz", seed: 0x475C0001 });
assert.strictEqual(luauResult.target, "luau");
assertNoSourceLoaderStages(luauResult, "Luau target");
assert.ok(runSyntaxCheck(lua, luauResult.output, "lua").ok, "Luau target should retain portable Lua syntax");

console.log(`ByteVeil v4.7.5 binary-region VM regression: PASS (${semanticRuns} semantic mode runs; 8-lane codec; 0 source-loader stages; fixture=${outputBytes} bytes; loader crack probes=0 calls)`);

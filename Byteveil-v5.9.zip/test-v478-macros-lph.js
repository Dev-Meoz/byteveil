"use strict";

const assert = require("assert");
const { obfuscate, macros, lph } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const lua = resolveRuntime("lua");
assert.ok(lua, "Lua runtime is required for Macro/LPH regression tests");

function build(source, mode = "stack", preset = "l1", seed = 0x46701001, options = {}) {
  return obfuscate(source, {
    source, target: "lua", mode, preset, seed, strength: 1800,
    wrapper: { enabled: false }, transforms: { watermark: false }, ...options
  });
}
function verifyRuntime(label, source, expected, mode = "stack", preset = "l1", seed = 0x46701001) {
  const result = build(source, mode, preset, seed);
  const syntax = runSyntaxCheck(lua, result.output, "lua");
  assert.ok(syntax.ok, `${label}/${mode}: syntax failed: ${syntax.error || syntax.stderr}`);
  const execution = runProgram(lua, result.output, "lua", expected);
  assert.ok(execution.ok, `${label}/${mode}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
  return result;
}

// The two source-comment scanners must stay independent.
const crossSource = "-- byteveil-encstr\n-- LPH_ENCSTR\nlocal s='a longer string'; print(s)";
assert.strictEqual(macros.scan(crossSource).length, 1, "Macro scanner must only own byteveil-* directives");
assert.strictEqual(lph.scan(crossSource).length, 1, "LPH scanner must only own LPH_* directives");
assert.strictEqual(macros.MACROS.length, 19, "historical Macro directive surface must remain intact");

// String protection is applied to the target statement, and the program remains semantically identical.
{
  const r = verifyRuntime("macro-encstr", '-- byteveil-encstr\nlocal s="this-is-a-secret-string"; print(s)', "this-is-a-secret-string");
  assert.strictEqual(r.ast.__byteVeilMacros.applied, true);
  assert.strictEqual(r.ast.__byteVeilMacros.effectiveDirectiveCount, 1);
  assert.strictEqual(r.ast.__byteVeilMacros.directives[0].effectStatus, "applied");
  assert.strictEqual(r.vmMeta.protectionPlan.macroEngine.applied, true, "active VM metadata must reflect Macro application");
  assert.strictEqual(r.vmMeta.protectionPlan.macroEngine.effectiveDirectives, 1, "generated protection plan must count applied Macro work");
}

// CFF is applied to the selected region only once; verify both VM execution modes.
for (const mode of ["stack", "register"]) {
  const r = verifyRuntime("macro-cff", '-- byteveil-cff\nif 1 < 2 then print("cff-secret") else print("no") end', "cff-secret", mode, "l1", mode === "stack" ? 0x46701002 : 0x46701003);
  assert.strictEqual(r.ast.__byteVeilMacros.directives[0].effectStatus, "applied");
}

// The conservative inliner removes a safe single-return local function and preserves output.
{
  const r = verifyRuntime("macro-inline", "-- byteveil-inline\nlocal function twice(x) return x + x end\nprint(twice(4))", "8");
  assert.ok(!JSON.stringify(r.ast.body).includes('"type":"LocalFunction"'), "safe local function should be inlined and removed");
  assert.strictEqual(r.ast.__byteVeilMacros.directives[0].effectStatus, "applied");
}

// Index splitting is semantic-preserving and makes the static key less obvious.
{
  const r = verifyRuntime("macro-index-to-num", 'local obj={secretfield=9}\n-- byteveil-index-to-num\nprint(obj.secretfield)', "9");
  assert.strictEqual(r.ast.__byteVeilMacros.directives[0].effectStatus, "applied");
}

// Explicit omit drops only the next statement.
verifyRuntime("macro-omit", '-- byteveil-omit\nprint("remove-me")\nprint("keep-me")', "keep-me");

// LPH call-style wrappers must lower away instead of becoming undefined runtime globals.
{
  const r = verifyRuntime("lph-obfuscated-call", 'local f=LPH_OBFUSCATED(function(x) return x .. " longstring" end); print(f("ok"))', "ok longstring");
  assert.strictEqual(r.ast.__byteVeilLPH.applied, true);
  assert.strictEqual(r.ast.__byteVeilLPH.effectiveDirectiveCount, 1);
  assert.strictEqual(r.vmMeta.protectionPlan.lphEngine.applied, true, "active VM metadata must reflect LPH application");
  assert.strictEqual(r.vmMeta.protectionPlan.lphEngine.effectiveDirectives, 1, "generated protection plan must count applied LPH work");
  assert.ok(!r.ast.__byteVeilLPH.directives.some(d => d.effectStatus === "suppressed-to-preserve-vm-routing"));
}
{
  const r = verifyRuntime("lph-encstr-call", 'print(LPH_ENCSTR("this-is-a-secret-string"))', "this-is-a-secret-string", "register", "l1", 0x46701004);
  assert.strictEqual(r.ast.__byteVeilLPH.directives[0].effectStatus, "applied");
}

// LPH_LINE() is replaced with its source line number and counted as a real lowering.
{
  const r = verifyRuntime("lph-line", "print(LPH_LINE())", "1");
  assert.strictEqual(r.ast.__byteVeilLPH.directives[0].effectStatus, "lowered");
  assert.strictEqual(r.ast.__byteVeilLPH.effectiveDirectiveCount, 1);
  assert.throws(() => build("print(LPH_LINE(99))"), /LPH_LINE expects zero arguments/);
}

// LPH comments bind to the next statement without narrowing local variable scope.
{
  const r = verifyRuntime("lph-comment-scope", '-- LPH_OBFUSCATED\nlocal scoped="secretstring"; print(scoped)', "secretstring");
  assert.strictEqual(r.ast.__byteVeilLPH.directives[0].effectStatus, "applied");
}

// LPH_NO_VIRTUALIZE preserves behavior and explicitly reports the backend limitation.
{
  const r = verifyRuntime("lph-no-virtualize", 'local f=LPH_NO_VIRTUALIZE(function() return 3 end); print(f())', "3");
  assert.strictEqual(r.ast.__byteVeilLPH.selectiveVirtualization, "not-supported-by-current-whole-chunk-vm");
  assert.ok(r.ast.__byteVeilLPH.warnings.some(w => /limited-whole-chunk-vm/.test(w)), "limitation must not be reported as full selective virtualization");
}

// byteveil-compress no longer creates source-loader layers in v4.7.8. It selects a distinct
// binary-region build domain instead, and metadata must not claim that source-onion compression ran.
{
  const plain = build('print("profile-check")', "stack", "lz", 0x46702001);
  const marked = build('-- byteveil-compress\nprint("profile-check")', "stack", "lz", 0x46702001);
  assert.strictEqual(plain.vmMeta.nestedProfile, "hybrid-function-policy-binary-region-vm-semantic-shadow-no-source-loader");
  assert.strictEqual(marked.vmMeta.nestedProfile, "hybrid-function-policy-binary-region-vm-semantic-shadow-no-source-loader");
  assert.notStrictEqual(plain.output, marked.output, "directive salt must select different binary-region build material");
  assert.strictEqual(marked.ast.__byteVeilMacros.directives[0].effectStatus, "applied-as-binary-region-build-profile");
}

// Unsupported SUPER fusion and VM-backed directives are reported truthfully.
{
  const suppressed = build('-- byteveil-super(2)\nprint(5+6)', "stack", "l1", 0x46703001);
  assert.strictEqual(suppressed.ast.__byteVeilMacros.directives[0].effectStatus, "suppressed-to-preserve-vm-routing");
  assert.strictEqual(suppressed.ast.__byteVeilMacros.effectiveDirectiveCount, 0);
  assert.ok(suppressed.ast.__byteVeilMacros.warnings.length > 0);
  const backend = build('-- byteveil-vm\nprint(5+6)', "stack", "l1", 0x46703002);
  assert.strictEqual(backend.ast.__byteVeilMacros.directives[0].effectStatus, "backend-active");
  assert.strictEqual(backend.ast.__byteVeilMacros.effectiveDirectiveCount, 1);
}

console.log("ByteVeil Macro/LPH v4.7.8 hotfix tests: PASS");

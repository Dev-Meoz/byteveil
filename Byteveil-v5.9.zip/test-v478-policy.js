"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 is required for v4.7.8 policy regression tests");

const common = {
  target: "lua",
  seed: 0x477A0011,
  strength: 3500,
  wrapper: { enabled: false },
  transforms: { rename: true, numbers: true, strings: true, controlFlow: true, watermark: false }
};

function build(source, options = {}) {
  return obfuscate(source, { ...common, ...options, transforms: { ...common.transforms, ...(options.transforms || {}) } });
}

function execute(label, result, expected) {
  assert.strictEqual(result.vmMeta.version, "4.7.8", `${label}: release version`);
  assert.ok(Buffer.byteLength(result.output, "utf8") <= 475000, `${label}: output budget`);
  const syntax = runSyntaxCheck(lua, result.output, "lua");
  assert.ok(syntax.ok, `${label}: syntax: ${syntax.stderr || syntax.error || "failed"}`);
  const run = runProgram(lua, result.output, "lua", expected);
  assert.ok(run.ok, `${label}: runtime: ${run.error || run.stderr || run.stdout}`);
  assert.strictEqual(result.vmMeta.sourceLoaderStages, 0, `${label}: source-loader stages`);
  assert.strictEqual(result.vmMeta.runtimeSourceLoaderCount, 0, `${label}: runtime source loaders`);
  assert.doesNotMatch(result.output, /(?<![\w])(?:loadstring|load)\s*\(/, `${label}: no source-loader calls`);
  return run;
}

// Default Balanced and explicit Hardened choose different compilers / machine state representations.
{
  const balanced = build('print("POLICY", 6*7)', { vmPolicy: "balanced" });
  const hardened = build('print("POLICY", 6*7)', { vmPolicy: "hardened" });
  assert.strictEqual(balanced.vmMeta.selectedBackend, "VM-A/register");
  assert.strictEqual(hardened.vmMeta.selectedBackend, "VM-B/stack");
  assert.strictEqual(balanced.vmMeta.instructionRepresentation, "register-file-register-operands-v478");
  assert.strictEqual(balanced.vmMeta.protectionIR.version, "4.7.8");
  assert.strictEqual(balanced.vmMeta.protectionPlan.version, "4.7.8");
  assert.strictEqual(hardened.vmMeta.instructionRepresentation, "stack-value-stack-operands-v478");
  assert.notStrictEqual(balanced.bytecode.mode, hardened.bytecode.mode);
  assert.notStrictEqual(balanced.output, hardened.output);
  execute("Balanced VM-A", balanced, "POLICY\t42");
  execute("Hardened VM-B", hardened, "POLICY\t42");
}

// Mixed backend: a normal global helper stays in VM-A while a selected helper is independently compiled by VM-B.
{
  const source = 'function add(x,y) return x+y end; function mul(x,y) return x*y end; print(add(2,3),mul(4,5))';
  const mixed = build(source, { vmPolicy: "balanced", functionPolicies: { mul: "hardened" } });
  assert.strictEqual(mixed.vmMeta.backend, "hybrid-vm-a-vm-b");
  assert.strictEqual(mixed.vmMeta.routedFunctionCount, 1);
  const add = mixed.vmMeta.functionPolicyReport.find((x) => x.name === "add");
  const mul = mixed.vmMeta.functionPolicyReport.find((x) => x.name === "mul");
  assert.strictEqual(add.backend, "VM-A/register");
  assert.strictEqual(mul.backend, "VM-B/stack");
  assert.strictEqual(mul.routing, "isolated-global-function");
  assert.strictEqual(mixed.vmMeta.functionProviders[0].serializer, "binary-region-v478-semantic-shadow-with-mode-specific-operands");
  assert.strictEqual(mixed.vmMeta.functionProviders[0].mode, "stack");
  execute("mixed VM-A/VM-B", mixed, "5\t20");
}

// The reverse direction routes VM-A into a VM-B main chunk.
{
  const source = 'function add(x,y) return x+y end; function mul(x,y) return x*y end; print(add(7,8),mul(3,4))';
  const mixed = build(source, { vmPolicy: "hardened", functionPolicies: { add: "balanced" } });
  assert.strictEqual(mixed.vmMeta.rootBackend, "VM-B/stack");
  assert.strictEqual(mixed.vmMeta.functionProviders[0].backend, "VM-A/register");
  execute("mixed VM-B/VM-A", mixed, "15\t12");
}

// Explicit compiler-transformed mode really emits transformed source, without pretending to virtualize it.
{
  const transformed = build('local x=2; print(x+3)', { vmPolicy: "compiler-transformed" });
  assert.strictEqual(transformed.vmMeta.backend, "compiler-transformed");
  assert.strictEqual(transformed.vmMeta.packedBytecode, false);
  assert.strictEqual(transformed.vmMeta.sourceReconstruction, true);
  execute("compiler-transformed mode", transformed, "5");
}

// Hybrid compiler-transformed main chunk with one hardened function.
{
  const source = 'function square(x) return x*x end; print(square(9))';
  const mixed = build(source, { vmPolicy: "compiler-transformed", functionPolicies: { square: "hardened" } });
  assert.strictEqual(mixed.vmMeta.backend, "hybrid-compiler-transformed-and-vm");
  assert.strictEqual(mixed.vmMeta.functionProviders[0].backend, "VM-B/stack");
  execute("compiler-transformed + VM-B", mixed, "81");
}

// A single function can explicitly opt into compiler-transformed mode while the root uses VM-A.
{
  const source = 'function square(x) return x*x end; print(square(9))';
  const mixed = build(source, { vmPolicy: "balanced", functionPolicies: { square: "compiler-transformed" } });
  assert.strictEqual(mixed.vmMeta.backend, "hybrid-vm-a-vm-b");
  assert.strictEqual(mixed.vmMeta.functionProviders[0].backend, "compiler-transformed");
  assert.strictEqual(mixed.vmMeta.functionPolicyReport.find((row) => row.name === "square").policy, "compiler-transformed");
  execute("VM-A + compiler-transformed function", mixed, "81");
}

// Unsupported nested/local functions must fail closed; a fallback is accepted only when explicit
// and must be visible in the build report rather than silently routed to the containing VM.
{
  const source = 'local function hidden(x) return x*2 end; print(hidden(2))';
  assert.throws(
    () => build(source, { vmPolicy: "balanced", functionPolicies: { hidden: "hardened" } }),
    /cannot be routed.*allowPolicyFallback:true/
  );
  const explicit = build(source, { vmPolicy: "balanced", functionPolicies: { hidden: "hardened" }, allowPolicyFallback: true });
  assert.strictEqual(explicit.vmMeta.explicitFallbacks.length, 1);
  assert.strictEqual(explicit.vmMeta.explicitFallbacks[0].requestedPolicy, "hardened");
  assert.match(explicit.vmMeta.explicitFallbacks[0].reason, /top-level named global function/);
  execute("explicit fallback for unsupported local function", explicit, "4");
}

// Captured locals cannot be made into independent VM upvalues silently. Default is a hard error;
// explicit allowPolicyFallback permits a recorded containing-chunk fallback.
{
  const source = 'local base=10; function plusBase(x) return base+x end; print(plusBase(7))';
  assert.throws(
    () => build(source, { vmPolicy: "balanced", functionPolicies: { plusBase: "hardened" } }),
    /cross-backend closure capture.*allowPolicyFallback:true/
  );
  const fallback = build(source, { vmPolicy: "balanced", functionPolicies: { plusBase: "hardened" }, allowPolicyFallback: true });
  assert.strictEqual(fallback.vmMeta.backend, "custom-vm");
  assert.strictEqual(fallback.vmMeta.explicitFallbacks.length, 1);
  assert.strictEqual(fallback.vmMeta.explicitFallbacks[0].requestedPolicy, "hardened");
  assert.match(fallback.vmMeta.explicitFallbacks[0].reason, /closure capture/);
  execute("explicit fallback", fallback, "17");
}

// Bad policy targets and unsupported policy names must fail closed.
{
  assert.throws(() => build("print(1)", { functionPolicies: { missing: "hardened" } }), /target "missing" was not found/);
  assert.throws(() => build("print(1)", { vmPolicy: "magic" }), /unknown function VM policy/);
  assert.throws(() => build("print(1)", { maxOutputBytes: 100 }), /output budget exceeded.*backend policy was not downgraded/);
}

// Wrapper enabled must preserve the outer lexical bridge and function call semantics.
{
  const source = 'function inc(x) return x+1 end; function twice(x) return x*2 end; print(inc(4),twice(6))';
  const wrapped = build(source, {
    vmPolicy: "balanced",
    functionPolicies: { twice: "hardened" },
    wrapper: { enabled: true, argumentCount: 7, setmeta: false, invoke: true, returnMode: "direct" }
  });
  execute("hybrid with wrapper", wrapped, "5\t12");
}

console.log("ByteVeil v4.7.8 function-policy / hybrid VM tests: PASS");

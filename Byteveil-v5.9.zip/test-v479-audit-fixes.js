"use strict";

const assert = require("assert");
const packageInfo = require("./package.json");
const { IR } = require("./src/compiler/ir");
const irBuilder = require("./src/compiler/ir_builder");
const numberObfuscator = require("./src/transforms/number_obfuscator");
const { buildProtectionPlan } = require("./src/transforms");

assert.strictEqual(new IR().meta.version, packageInfo.version, "IR default version follows package version");
assert.strictEqual(irBuilder.build({ type: "Chunk", body: [] }).meta.version, packageInfo.version, "IR builder default version follows package version");
assert.strictEqual(irBuilder.build({ type: "Chunk", body: [] }, "register", "4.7.8").meta.version, "4.7.8", "IR builder preserves explicit compatibility version");

const ast = {};
numberObfuscator.transform(ast, { enabled: true, seed: 123 });
assert.strictEqual(ast.__numbers.requested, true);
assert.strictEqual(ast.__numbers.applied, false, "literal-preserving number pass must not claim a rewrite");
assert.strictEqual(ast.__numbers.strategy, "literal-preserve-vm-encoded");
const plan = buildProtectionPlan(ast, { numbers: true, version: packageInfo.version });
assert.strictEqual(plan.transformEffects.numbers.requested, true);
assert.strictEqual(plan.transformEffects.numbers.applied, false);
assert.match(plan.transformEffects.numbers.note, /not rewritten/);
assert.strictEqual(plan.transforms.numbers, true, "legacy configuration field remains backward-compatible");

console.log("ByteVeil v5.8.0 audit fixes: PASS (IR version truthfulness and requested-vs-applied numeric transform reporting)");

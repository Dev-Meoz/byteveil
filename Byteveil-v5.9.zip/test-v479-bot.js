"use strict";

const assert = require("assert");
const Module = require("module");
process.env.DISCORD_TOKEN = "unit-test-token-not-valid";
process.env.DISCORD_CLIENT_ID = "client-test";
process.env.DISCORD_GUILD_ID = "guild-test";
process.env.DISCORD_LEGACY_GUILD_IDS = "guild-old,guild-test";

class FakeEmbedBuilder {
  constructor() { this.data = { fields: [] }; }
  setColor(v) { this.data.color = v; return this; }
  setAuthor(v) { this.data.author = v; return this; }
  setFooter(v) { this.data.footer = v; return this; }
  setTimestamp(v = new Date()) { this.data.timestamp = v; return this; }
  setTitle(v) { this.data.title = v; return this; }
  setDescription(v) { this.data.description = v; return this; }
  addFields(...v) { this.data.fields.push(...v.flat()); return this; }
  toJSON() { return this.data; }
}
class FakeAttachmentBuilder { constructor(attachment, options = {}) { this.attachment = attachment; this.name = options.name; } }
class FakeOptionBuilder {
  constructor(type = "string") { this.data = { type, choices: [] }; }
  setName(v) { this.data.name = v; return this; }
  setDescription(v) { this.data.description = v; return this; }
  setRequired(v) { this.data.required = v; return this; }
  addChoices(...v) { this.data.choices.push(...v.flat()); return this; }
  toJSON() { return this.data; }
}
class FakeSlashCommandBuilder extends FakeOptionBuilder {
  constructor() { super("command"); this.data.options = []; }
  addStringOption(fn) { this.data.options.push(fn(new FakeOptionBuilder("string")).toJSON()); return this; }
  addAttachmentOption(fn) { this.data.options.push(fn(new FakeOptionBuilder("attachment")).toJSON()); return this; }
}
const stores = new Map();
const writes = [];
class FakeREST {
  setToken(token) { this.token = token; return this; }
  async get(route) { return structuredClone(stores.get(route) || []); }
  async put(route, { body }) {
    for (const command of body) assert.ok(!Object.prototype.hasOwnProperty.call(command, "id"), "REST bulk overwrite must not re-send read-only command IDs");
    writes.push({ route, body: structuredClone(body) });
    stores.set(route, structuredClone(body));
    return body;
  }
}
const FakeRoutes = {
  applicationCommands: (clientId) => `global:${clientId}`,
  applicationGuildCommands: (clientId, guildId) => `guild:${clientId}:${guildId}`,
};
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === "discord.js") return {
    SlashCommandBuilder: FakeSlashCommandBuilder,
    AttachmentBuilder: FakeAttachmentBuilder,
    EmbedBuilder: FakeEmbedBuilder,
    REST: FakeREST,
    Routes: FakeRoutes,
  };
  if (request === "dotenv") return { config: () => ({}) };
  return originalLoad.call(this, request, parent, isMain);
};

const { commands, execute, PRESETS, helpEmbed, usageEmbed, resolveInput, isNonPublicAddress, validatePublicHttpUrl, requestRawSource, readResponseLimited } = require("./bot/src/commands");
const { byteCodeRulesEmbed } = require("./bot/src/discord_rules");
const { deployCommands } = require("./bot/src/deploy-commands");

function interaction(commandName, options = {}) {
  const calls = { reply: [], defer: 0, edits: [] };
  const item = {
    commandName,
    options: {
      getString: (name, required = false) => {
        const value = options[name] ?? null;
        if (required && value == null) throw new Error(`missing required option ${name}`);
        return value;
      },
      getAttachment: (name) => options[name] ?? null,
    },
    deferred: false,
    replied: false,
    isChatInputCommand: () => true,
    reply: async (payload) => { calls.reply.push(payload); item.replied = true; return payload; },
    deferReply: async () => { calls.defer += 1; item.deferred = true; },
    editReply: async (payload) => { calls.edits.push(payload); return payload; },
    _calls: calls,
  };
  return item;
}

async function main() {
  assert.deepStrictEqual(PRESETS, ["l1", "l2", "nest", "df", "lz"]);
  // A raw URL passed as source code used to reach the Lua parser and fail at
  // the URL's `//`. Require the user to select the dedicated URL input mode.
  await assert.rejects(resolveInput("code", "https://pastefy.app/a5uisjex/raw", null), /attach:url/i);
  assert.equal(isNonPublicAddress("127.0.0.1"), true);
  assert.equal(isNonPublicAddress("10.2.3.4"), true);
  assert.equal(isNonPublicAddress("192.168.1.1"), true);
  assert.equal(isNonPublicAddress("::ffff:7f00:1"), true, "IPv4-mapped IPv6 must not bypass local-address checks");
  assert.equal(isNonPublicAddress("8.8.8.8"), false);
  await assert.rejects(validatePublicHttpUrl(new URL("http://127.0.0.1/raw")), /IP nội bộ/i);
  await assert.rejects(validatePublicHttpUrl(new URL("http://localhost/raw")), /host công khai/i);

  // Simulate a successful raw-source URL fetch without relying on live network
  // state; the exact response body must enter the normal source pipeline.
  const dns = require("node:dns/promises");
  const https = require("node:https");
  const { EventEmitter } = require("node:events");
  const { PassThrough } = require("node:stream");
  const originalLookup = dns.lookup;
  const originalRequest = https.request;
  dns.lookup = async () => [{ address: "93.184.216.34", family: 4 }];
  let requestOptions = null;
  const rawBody = `-- raw source
local value = 40 + 2
return value`;
  https.request = (options, callback) => {
    requestOptions = options;
    const req = new EventEmitter();
    req.setTimeout = () => req;
    req.destroy = (error) => { if (error) process.nextTick(() => req.emit("error", error)); return req; };
    req.end = () => {
      const response = new PassThrough();
      response.statusCode = 200;
      response.headers = { "content-length": String(Buffer.byteLength(rawBody)), "content-type": "text/plain" };
      callback(response);
      process.nextTick(() => response.end(Buffer.from(rawBody)));
    };
    return req;
  };
  try {
    const remote = await resolveInput("url", "https://pastefy.app/a5uisjex/raw", null);
    assert.equal(remote.mode, "url");
    assert.equal(remote.source, rawBody, "the exact raw URL response must reach the source pipeline");
    assert.equal(requestOptions.protocol, "https:");
    assert.equal(requestOptions.hostname, "pastefy.app");
    assert.equal(typeof requestOptions.lookup, "function", "request must use the validated/pinned DNS lookup");
    await new Promise((resolve, reject) => requestOptions.lookup("pastefy.app", { all: true }, (error, addresses) => {
      if (error) return reject(error);
      try {
        assert.deepStrictEqual(addresses, [{ address: "93.184.216.34", family: 4 }]);
        resolve();
      } catch (assertionError) { reject(assertionError); }
    }));
    // A redirect response must be rejected, never followed to a second host.
    const makeMockRequest = (statusCode, body = "", headers = {}) => (_options, callback) => {
      const req = new EventEmitter();
      req.setTimeout = () => req;
      req.destroy = (error) => { if (error) process.nextTick(() => req.emit("error", error)); return req; };
      req.end = () => {
        const response = new PassThrough();
        response.statusCode = statusCode;
        const bodyBytes = Buffer.isBuffer(body) ? body : Buffer.from(body);
        response.headers = { "content-length": String(bodyBytes.length), ...headers };
        callback(response);
        process.nextTick(() => response.end(bodyBytes));
      };
      return req;
    };
    const publicUrl = new URL("https://pastefy.app/a5uisjex/raw");
    const publicAddress = [{ address: "93.184.216.34", family: 4 }];
    await assert.rejects(requestRawSource(publicUrl, publicAddress, makeMockRequest(302, "", { location: "https://127.0.0.1/private" })), /redirect|HTTP 302/i);
    https.request = makeMockRequest(200, Buffer.from([0xff, 0xfe]));
    await assert.rejects(resolveInput("url", "https://pastefy.app/a5uisjex/raw", null), /UTF-8/i);
    const { config: runtimeConfigForUrl } = require("./bot/src/runtime");
    const previousUrlLimit = runtimeConfigForUrl.maxInputBytes;
    runtimeConfigForUrl.maxInputBytes = 1024;
    try {
      await assert.rejects(requestRawSource(publicUrl, publicAddress, makeMockRequest(200, "", { "content-length": "1025" })), /vượt giới hạn/i);
    } finally {
      runtimeConfigForUrl.maxInputBytes = previousUrlLimit;
    }
  } finally {
    dns.lookup = originalLookup;
    https.request = originalRequest;
  }

  // Size limits are enforced while consuming streams, rather than only after
  // allocating the whole response in memory.
  const { config: runtimeConfig } = require("./bot/src/runtime");
  const previousLimit = runtimeConfig.maxInputBytes;
  runtimeConfig.maxInputBytes = 1024;
  const oversizedStream = {
    headers: { get: () => null },
    body: new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(600)); controller.enqueue(new Uint8Array(500)); } }),
  };
  await assert.rejects(readResponseLimited(oversizedStream, "test body"), /vượt giới hạn/i);
  runtimeConfig.maxInputBytes = previousLimit;
  assert.strictEqual(require("./package.json").scripts.start, "node bot/src/deploy-commands.js && node bot/src/index.js",
    "root startup must not login unless command synchronization succeeds");
  assert.strictEqual(require("./bot/package.json").scripts.start, "node src/deploy-commands.js && node src/index.js",
    "bot-folder startup must not login unless command synchronization succeeds");
  assert.deepStrictEqual(commands.map((c) => c.name), ["help", "rule", "obf"]);
  const obf = commands.find((c) => c.name === "obf");
  assert.deepStrictEqual(obf.options.map((o) => o.name), ["presets", "method", "attach", "input", "upload"]);
  assert.deepStrictEqual(obf.options[0].choices.map((c) => c.value), PRESETS);
  assert.deepStrictEqual(obf.options[1].choices.map((c) => c.value), ["stack", "register"]);
  assert.deepStrictEqual(obf.options[2].choices.map((c) => c.value), ["code", "file", "url"]);

  const help = helpEmbed().toJSON();
  assert.strictEqual(help.title, "COMMAND CENTER");
  assert.ok(help.fields.some((f) => f.value.includes("/obf presets:lz")));
  assert.strictEqual(usageEmbed("test").toJSON().title, "OBFUSCATION · USAGE");
  const rules = byteCodeRulesEmbed().toJSON();
  assert.ok(rules.fields.some((f) => f.value.includes("/obf presets:l1")));
  assert.match(rules.footer.text, /v5\.9\.0/);
  assert.match(help.footer.text, /v5\.9\.0/);

  const h = interaction("help");
  await execute(h);
  assert.strictEqual(h._calls.reply.length, 1);
  assert.strictEqual(h._calls.reply[0].embeds[0].data.title, "COMMAND CENTER");
  assert.strictEqual(h._calls.reply[0].ephemeral, true);

  const r = interaction("rule");
  await execute(r);
  assert.strictEqual(r._calls.reply.length, 1);
  assert.ok(r._calls.reply[0].embeds[0].data.title.includes("RULES"));

  const bad = interaction("obf", { presets: "bad", method: "register", attach: "code", input: "print(1)" });
  await execute(bad);
  assert.strictEqual(bad._calls.defer, 1);
  assert.strictEqual(bad._calls.edits.at(-1).embeds[0].data.title, "REQUEST FAILED  /  OBF");

  // Integration smoke: /obf must run the real engine and deliver a generated file.
  const real = interaction("obf", { presets: "l1", method: "stack", attach: "code", input: 'print("BV_V478_SLASH_ENGINE_OK")' });
  await execute(real);
  assert.strictEqual(real._calls.defer, 1);
  assert.strictEqual(real._calls.edits.length, 2, "processing state and final output expected");
  assert.ok(real._calls.edits[0].embeds[0].data.fields.some((f) => f.name === "VM METHOD" && f.value.includes("stack")));
  const response = real._calls.edits.at(-1);
  assert.strictEqual(response.embeds[0].data.title, "BUILD COMPLETE");
  assert.strictEqual(response.files.length, 1);
  assert.match(response.files[0].name, /_l1_stack_obfuscated\.(lua|luau)$/);
  assert.ok(response.files[0].attachment.length > 0);

  // Deploy test: sync the active guild atomically, clear stale global registrations,
  // clean a previously used guild, and preserve non-ByteVeil commands everywhere.
  stores.set("global:client-test", [
    { id: "g-help", name: "help", description: "stale global help" },
    { id: "g-keep", name: "unrelated", description: "retain this" },
    { id: "g-obf", name: "obf", description: "stale global obf" },
  ]);
  stores.set("guild:client-test:guild-test", [
    { id: "s-rule", name: "rule", description: "stale guild rule" },
    { id: "s-keep", name: "guild-extra", description: "retain this too" },
  ]);
  stores.set("guild:client-test:guild-old", [
    { id: "old-help", name: "help", description: "from a previous deployment" },
    { id: "old-obf", name: "obf", description: "old options" },
    { id: "old-keep", name: "old-guild-custom", description: "unrelated" },
  ]);
  let writeStart = writes.length;
  const firstSync = await deployCommands();
  assert.strictEqual(firstSync.target, "guild guild-test");
  const globalAfter = stores.get("global:client-test");
  const guildAfter = stores.get("guild:client-test:guild-test");
  const oldGuildAfter = stores.get("guild:client-test:guild-old");
  assert.deepStrictEqual(globalAfter.map((c) => c.name), ["unrelated"]);
  assert.deepStrictEqual(guildAfter.map((c) => c.name), ["guild-extra", "help", "rule", "obf"]);
  assert.deepStrictEqual(oldGuildAfter.map((c) => c.name), ["old-guild-custom"]);
  assert.strictEqual(guildAfter.find((c) => c.name === "obf").options.map((o) => o.name).join(","), "presets,method,attach,input,upload");
  assert.strictEqual(guildAfter.find((c) => c.name === "obf").options[0].choices.map((c) => c.value).join(","), "l1,l2,nest,df,lz");
  const firstWrites = writes.slice(writeStart);
  assert.strictEqual(firstWrites.filter((call) => call.route === "guild:client-test:guild-test").length, 1,
    "active scope must be synchronized in one bulk overwrite, not reset and redeployed in separate writes");

  // Repeated startup must overwrite stale command schemas even when command names are unchanged.
  stores.set("guild:client-test:guild-test", [
    { id: "bad-help", name: "help", description: "version A" },
    { id: "bad-obf", name: "obf", description: "version B", options: [{ name: "old-option" }] },
    { id: "keep-again", name: "guild-extra-2", description: "preserve" },
  ]);
  writeStart = writes.length;
  await deployCommands();
  const secondGuildAfter = stores.get("guild:client-test:guild-test");
  assert.deepStrictEqual(secondGuildAfter.map((c) => c.name), ["guild-extra-2", "help", "rule", "obf"]);
  assert.strictEqual(secondGuildAfter.find((c) => c.name === "obf").options.map((o) => o.name).join(","), "presets,method,attach,input,upload",
    "old command options must be replaced by the current source schema on every startup");
  const secondWrites = writes.slice(writeStart);
  assert.strictEqual(secondWrites.filter((call) => call.route === "guild:client-test:guild-test").length, 1);

  // Reset-only deletes ByteVeil definitions from all known scopes without redeploying them.
  stores.set("global:client-test", [{ name: "rule" }, { name: "global-extra" }]);
  stores.set("guild:client-test:guild-test", [{ name: "help" }, { name: "guild-extra" }]);
  stores.set("guild:client-test:guild-old", [{ name: "obf" }, { name: "old-guild-custom" }]);
  writeStart = writes.length;
  const reset = await deployCommands({ resetOnly: true });
  assert.strictEqual(reset.resetOnly, true);
  assert.strictEqual(reset.removed, 3);
  assert.deepStrictEqual(stores.get("global:client-test").map((c) => c.name), ["global-extra"]);
  assert.deepStrictEqual(stores.get("guild:client-test:guild-test").map((c) => c.name), ["guild-extra"]);
  assert.deepStrictEqual(stores.get("guild:client-test:guild-old").map((c) => c.name), ["old-guild-custom"]);
  assert.ok(!writes.slice(writeStart).some((call) => call.body.some((c) => ["help", "rule", "obf"].includes(c.name))));

  process.stdout.write("ByteVeil v5.8.0 slash-command/deploy tests: PASS\n");
}
main().catch((error) => { console.error(error.stack || error); process.exit(1); });

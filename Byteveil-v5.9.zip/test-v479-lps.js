"use strict";

const assert = require("assert");
const { LPS_VERSION, LPSError, createCallRegistry, executeLPS, validatePayloadDirectory } = require("./src/lps");
const publicApi = require("./src");
assert.strictEqual(publicApi.lps.executeLPS, executeLPS, "LPS is exported for independent use");

assert.strictEqual(LPS_VERSION, "5.9.0");

// Prove this is an executing register VM with branches and a repeated loop.
const sumProgram = [
  ["CONST", 0, 1],
  ["CONST", 1, 0],
  ["CONST", 2, 5],
  ["CONST", 3, 1],
  ["LE", 4, 0, 2],
  ["JZ", 4, 9],
  ["ADD", 1, 1, 0],
  ["ADD", 0, 0, 3],
  ["JMP", 4],
  ["RET", 1]
];
assert.strictEqual(executeLPS(sumProgram).value, 15, "LPS loop/branch interpreter");

// Native aliases are the same reference, not wrappers or reimplementations.
const nativeGsub = (value, pattern, replacement) => String(value).replace(new RegExp(pattern, "g"), replacement);
const nativeToString = value => String(value);
const registry = createCallRegistry({ "byteveil.deox": (left, right) => (Number(left) ^ Number(right)) >>> 0 });
registry.bindNative("string.gsub", { string: { gsub: nativeGsub } }, "string.gsub");
registry.alias("byteveil.gsub", "string.gsub");
registry.bindNative("tostring", { tostring: nativeToString }, "tostring");
registry.alias("byteveil.tostring", "tostring");
assert.strictEqual(registry.resolve("byteveil.gsub"), nativeGsub);
assert.strictEqual(registry.resolve("byteveil.tostring"), nativeToString);
const callProgram = [
  ["CONST", 0, "banana"],
  ["CONST", 1, "a"],
  ["CONST", 2, "o"],
  ["CALL", 3, "byteveil.gsub", [0, 1, 2]],
  ["RET", 3]
];
assert.strictEqual(executeLPS(callProgram, { registry }).value, "bonono");
const deoxProgram = [["CONST", 0, 0xAA], ["CONST", 1, 0x0F], ["CALL", 2, "byteveil.deox", [0, 1]], ["RET", 2]];
assert.strictEqual(executeLPS(deoxProgram, { registry }).value, 0xA5);

assert.strictEqual(validatePayloadDirectory("abcdef", [{ offset: 1, length: 2 }, { offset: 3, length: 4 }]), true);
for (const invalid of [
  [{ offset: 0, length: 1 }],
  [{ offset: 1.5, length: 1 }],
  [{ offset: 1, length: 7 }],
  [{ offset: 1, length: 0 }],
  [{ offset: 1, length: 2 }, { offset: 2, length: 5 }],
  [{ offset: 1, length: 2 }, { offset: 4, length: 3 }],
  [{ offset: 1, length: 2 }, { offset: 3, length: 3 }]
]) assert.throws(() => validatePayloadDirectory("abcdef", invalid), LPSError);
assert.throws(() => executeLPS([["NOT_REAL", 0]]), LPSError);
assert.throws(() => executeLPS([["CONST", 300, 1], ["RET", 300]]), LPSError);
assert.throws(() => executeLPS([["JMP", 0]], { stepLimit: 5 }), /step limit exceeded/);

console.log("ByteVeil v5.8.0 LPS engine: PASS (register VM, loops, native-reference aliases, deox, payload directory partition validation, invalid-bytecode guards)");

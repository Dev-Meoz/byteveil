"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const { BLOB_MARKER } = require("./src/obfuscation/veil_blob");

const lua = resolveRuntime("lua");
assert.ok(lua, "a Lua-compatible runtime is required for v5.8.0 payload tests");

const source = "local function add(a,b) return a+b end; print(add(2,3))";
const expected = "5";

function mutateCarrierAtSlot(output, slot) {
  assert.ok(Number.isInteger(slot) && slot > 0, "carrier slot must be a positive integer");
  const escaped = String(slot).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  // v5.9 carriers are VeilBlob containers read through `string.sub(<blob>, N)`,
  // so the tamper targets the first encoded byte inside the container instead of
  // the byte that used to sit right after the opening quote.
  const anchor = new RegExp(`[A-Za-z_][A-Za-z0-9_]*\\[${escaped}\\]=function\\(\\)return\\s+[A-Za-z_][A-Za-z0-9_]*\\(string\\.sub\\(\\[=+\\[${BLOB_MARKER}`).exec(output);
  assert.ok(anchor, `carrier slot ${slot} must exist in the generated output as a VeilBlob carrier`);
  const encodedAt = output.indexOf(BLOB_MARKER, anchor.index) + BLOB_MARKER.length;
  const closer = `]${"=".repeat(anchor[0].match(/\[(=*)\[byteveil/)[1].length)}]`;
  const encodedEnd = output.indexOf(closer, encodedAt);
  assert.ok(encodedEnd > encodedAt, `carrier slot ${slot} must contain encoded data`);
  const changedFirst = output[encodedAt] === "!" ? "#" : "!";
  return `${output.slice(0, encodedAt)}${changedFirst}${output.slice(encodedAt + 1)}`;
}

let runtimeChecks = 0;
for (const mode of ["stack", "register"]) {
  const result = obfuscate(source, {
    source,
    target: "lua",
    mode,
    preset: "l1",
    seed: 0x50000001 + (mode === "register" ? 1 : 0),
    strength: 3500,
    wrapper: { enabled: false }
  });

  assert.strictEqual(result.vmMeta.version, "5.9.0", `${mode}: active VM version`);
  assert.strictEqual(result.vmMeta.payloadLayout, "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified", `${mode}: active payload layout`);
  assert.strictEqual(result.vmMeta.encodingEngine, "VeilSync-v2", `${mode}: VeilSync identity`);
  assert.strictEqual(result.vmMeta.encodingRegionsVerified, result.vmMeta.regionCount, `${mode}: every region verified`);
  assert.strictEqual(result.vmMeta.encodingPipelineRoundTripsVerified, result.vmMeta.regionCount, `${mode}: every pipeline verified`);
  assert.strictEqual(result.vmMeta.encodingRoundTripsVerified, result.vmMeta.regionCount * 3, `${mode}: each of three codec stages verified in every region`);
  assert.strictEqual(result.vmMeta.payloadCarrierCodec, "position-keyed-four-family-alphabet-stream-v5.1-build-diverse", `${mode}: codec metadata`);
  assert.strictEqual(result.vmMeta.stagedPayloadMaterialization, "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified", `${mode}: staged payload metadata`);
  assert.ok(result.vmMeta.payloadBlobChars > 0, `${mode}: payload blob accounting`);
  assert.ok(result.vmMeta.payloadDirectoryEntries > 0, `${mode}: payload directory accounting`);
  assert.strictEqual(result.vmMeta.payloadDirectoryValidatedByLPS, true, `${mode}: LPS directory validation`);
  assert.strictEqual(result.vmMeta.lpsPayloadPlanner, "LPS-bytecode-registry-build-diverse-payload-layout-v5.1", `${mode}: LPS planner integration`);
  assert.match(result.output, /function\(S,A,O,R,K,Z,Q\)/, `${mode}: position-keyed decoder must be emitted`);
  assert.doesNotMatch(result.output, /,pb="/, `${mode}: legacy single-blob field must not be emitted`);
  assert.doesNotMatch(result.output, /,pd=\{/, `${mode}: plain directory table must not be emitted`);
  assert.doesNotMatch(result.output, /,regions=\{/, `${mode}: readable region object tree must not be emitted`);
  assert.ok(result.output.includes("This file was protected using ByteVeil Obfuscator v5.9.0 [https://discord.gg/rAhAnnkBn8/]"), `${mode}: active watermark must match v5.8.0`);
  assert.doesNotMatch(result.output, /ByteVeil v4\.7\.8:/, `${mode}: stale v4.7.8 runtime diagnostic prefixes must not remain`);
  assert.doesNotMatch(result.output, /["\'](?:payload carrier alphabet|payload lane|payload integrity record|payload carrier missing|descriptor carrier missing|continuation miss)["\']/i, `${mode}: payload diagnostics must be encoded in generated output`);

  const syntax = runSyntaxCheck(lua, result.output, "lua");
  assert.ok(syntax.ok, `${mode}: syntax failure: ${syntax.error || syntax.stderr}`);
  const run = runProgram(lua, result.output, "lua", expected);
  assert.ok(run.ok, `${mode}: runtime failure: ${run.error || run.stderr || run.stdout}`);
  assert.strictEqual(run.stdout.trim(), expected, `${mode}: semantic output`);
  runtimeChecks++;

  const descriptorSlots = result.vmMeta.payloadDescriptorCarrierSlots || [];
  assert.ok(descriptorSlots.length > 0, `${mode}: descriptor carrier slots must be reported`);
  const tamperedDescriptor = mutateCarrierAtSlot(result.output, descriptorSlots[0]);
  const descriptorRun = runProgram(lua, tamperedDescriptor, "lua", expected);
  assert.ok(!descriptorRun.ok, `${mode}: descriptor carrier tampering unexpectedly executed`);
  runtimeChecks++;

  const laneSlots = (result.vmMeta.payloadLaneCarrierSlots || []).flat();
  assert.ok(laneSlots.length > 0, `${mode}: payload lane carrier slots must be reported`);
  const tamperedLane = mutateCarrierAtSlot(result.output, laneSlots[0]);
  const laneRun = runProgram(lua, tamperedLane, "lua", expected);
  assert.ok(!laneRun.ok, `${mode}: payload lane tampering unexpectedly executed`);
  runtimeChecks++;
}

console.log(`ByteVeil v5.8.0 position-keyed striped payload regression: PASS (${runtimeChecks} runtime checks across Stack/Register; codec, syntax, execution, descriptor/lane tamper rejection)`);

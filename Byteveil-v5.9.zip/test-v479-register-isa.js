"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");
const { buildISAPlan } = require("./src/obfuscation/isa_engine");
const {
    REGISTER_ISA_VERSION,
    REGISTER_COMMAND_BY_SEMANTIC,
    REGISTER_SEMANTIC_OPS,
    buildRegisterISAPlan
} = require("./src/compiler/register/register_isa_v479");
const { compile: compileRegister } = require("./src/compiler/register/register_compiler");
const regVmGenerator = require("./src/compiler/register/reg_vm_generator");
const { Lexer } = require("./src/frontend/lexer");
const { Parser } = require("./src/frontend/parser");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "a Lua-compatible runtime is required for register-ISA tests");
assert.ok(luau, "a Luau-compatible runtime is required for register-ISA tests");

const seed = 0x4790A11;
const plan = buildRegisterISAPlan(seed, { lanes: 4 });
const oldSharedPlan = buildISAPlan(REGISTER_SEMANTIC_OPS, seed, { lanes: 4 });

assert.strictEqual(plan.version, REGISTER_ISA_VERSION);
assert.ok(plan.commandNames.every((name) => name.startsWith("R_")), "register commands must use the v4.7.9 register namespace");
assert.strictEqual(new Set(plan.commandNames).size, plan.commandNames.length, "register command aliases must be unique");
assert.deepStrictEqual(plan.names, REGISTER_SEMANTIC_OPS);
for (const semantic of REGISTER_SEMANTIC_OPS) {
    assert.strictEqual(plan.decode[plan.encode[semantic]], semantic, `register command round-trip failed for ${semantic}`);
    assert.ok(REGISTER_COMMAND_BY_SEMANTIC[semantic], `missing register command alias for ${semantic}`);
}
assert.notDeepStrictEqual(plan.route, oldSharedPlan.route, "register opcode ids must not reuse the legacy shared-ISA seed domain");

const corpus = [
    {
        name: "register-basic-call",
        source: "local function add(a,b) return a+b end; print(add(2,3))",
        expected: "5"
    },
    {
        name: "register-vararg-multi-return",
        source: "local function pass(...) return ... end; local a,b,c=pass(2,3,4); print(a+b+c)",
        expected: "9"
    },
    {
        name: "register-numeric-loop",
        source: "local total=0; for i=1,5 do total=total+i end; print(total)",
        expected: "15"
    },
    {
        name: "register-table-write-read",
        source: "local t={x=2}; t.x=5; print(t.x)",
        expected: "5"
    },
    {
        name: "register-multireturn-with-arg-exprs-and-forin",
        source: [
            "local function multi(u, v) return u * 2, v * 3, u + v end",
            "local function pair0() return 10, 20 end",
            "local x, y = 4, 5",
            "local a, b, c = multi(x + 1, y + 2)",
            "local d, e = pair0()",
            "local t = { [1] = a, [2] = b, [3] = c }",
            "local sum = d + e",
            "for k, v in next, t, nil do sum = sum + k * v end",
            "print(sum)"
        ].join("; "),
        expected: "118"
    }
];

let runtimeChecks = 0;
for (let i = 0; i < corpus.length; i++) {
    const sample = corpus[i];
    const result = obfuscate(sample.source, {
        source: sample.source,
        target: "lua",
        mode: "register",
        preset: "l1",
        seed: 0x4790B000 + i,
        strength: 3500,
        wrapper: { enabled: true }
    });
    assert.strictEqual(result.vmMeta.version, "5.9.0", `${sample.name}: VM version`);
    assert.strictEqual(result.vmMeta.selectedBackend, "VM-A/register", `${sample.name}: backend selection`);
    assert.strictEqual(result.vmMeta.registerInstructionSet, REGISTER_ISA_VERSION, `${sample.name}: register ISA metadata`);
    for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
        const syntax = runSyntaxCheck(rtBin, result.output, rtName);
        assert.ok(syntax.ok, `${sample.name} (${rtName}): syntax failed: ${syntax.error || syntax.stderr}`);
        const run = runProgram(rtBin, result.output, rtName, sample.expected);
        assert.ok(run.ok, `${sample.name} (${rtName}): runtime failed: ${run.error || run.stderr || run.stdout}`);
        runtimeChecks++;
    }
}

// Verify per-chunk seeded bijective register file permutation & standalone reg_vm_generator:
{
    const src = "local a, b = ...; local function f(x, y) return x + y, x * y end; local p, q = f(a + 1, b + 2); return p, nil, q";
    const ast1 = new Parser(new Lexer(src).lex().tokens).parse();
    const ast2 = new Parser(new Lexer(src).lex().tokens).parse();
    const bc1 = compileRegister(ast1, 101);
    const bc2 = compileRegister(ast2, 202);
    assert.ok(bc1.registerPermutation && bc2.registerPermutation, "compileRegister must attach registerPermutation metadata");
    assert.notDeepStrictEqual(bc1.registerPermutation.map, bc2.registerPermutation.map, "register file permutation must vary across build seeds");
    const isSequential = bc1.registerPermutation.map.every((phys, idx) => phys === idx);
    assert.strictEqual(isSequential, false, "physical register indices must not be sequential 0..N-1");

    const standaloneCode = regVmGenerator.generate(bc1, { seed: 101 });
    for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
        const harness = [
            "local fn = function(...) " + standaloneCode + " end",
            "local a, b, c = fn(3, 4)",
            "assert(a == 10 and b == nil and c == 24, 'unexpected standalone reg_vm_generator result')",
            "print('OK')"
        ].join("\n");
        const run = runProgram(rtBin, harness, rtName, "OK");
        assert.ok(run.ok, `standalone reg_vm_generator failed on ${rtName}: ${run.stderr || run.stdout}`);
        runtimeChecks++;
    }
}

console.log(`ByteVeil v5.8.0 register ISA regression: PASS (${runtimeChecks} runtime cases across Lua 5.4 & Luau; isolated register command ABI, per-seed register file permutation, polymorphic handlers, and payload execution)`);

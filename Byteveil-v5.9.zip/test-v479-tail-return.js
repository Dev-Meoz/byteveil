"use strict";

const assert = require("assert");
const { obfuscate } = require("./src");
const { OPS } = require("./src/obfuscation/isa_engine");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "a Lua-compatible runtime is required for v4.7.9 tail-return tests");
assert.ok(OPS.length <= 64, `opcode field must remain within the serializer's 6-bit physical-opcode budget; got ${OPS.length}`);
assert.ok(OPS.includes("TAILCALL"), "the active ISA must include the dedicated return-call opcode");

const cases = [
  ["local function source() return 2,nil,4 end; local function pass() return source() end; local a,b,c=pass(); print(a,b,c)", "2\tnil\t4"],
  ["local function source() return 2,nil,4 end; local function pass() return 9,source() end; local a,b,c,d=pass(); print(a,b,c,d)", "9\t2\tnil\t4"],
  ["function source() return 5,nil,8 end; local function pass() return source() end; local a,b,c=pass(); print(a,b,c)", "5\tnil\t8"],
  ["function source() return 5,nil,8 end; local function pass() return 9,source() end; local a,b,c,d=pass(); print(a,b,c,d)", "9\t5\tnil\t8"],
  ["local function source(...) return ... end; local function pass(...) return 1,source(...) end; local a,b,c=pass(2,3); print(a,b,c)", "1\t2\t3"],
  ["function source(...) return ... end; local function pass(...) return 1,source(...) end; local a,b,c=pass(2,3); print(a,b,c)", "1\t2\t3"],
  ["local t={f=function(self,x) return x,nil,x+2 end}; local function pass(x) return t:f(x) end; local a,b,c=pass(7); print(a,b,c)", "7\tnil\t9"],
  ["local function source() return 2,3,4 end; local function pass() return 9,source() end; local a,b,c,d=pass(); print(a,b,c,d)", "9\t2\t3\t4"],
  ["local function source() return nil,nil end; local function pass() return 9,source() end; local a,b,c=pass(); print(a,b,c)", "9\tnil\tnil"]
];

let runs = 0;
for (let i = 0; i < cases.length; i++) {
  const [source, expected] = cases[i];
  for (const mode of ["stack", "register"]) {
    const result = obfuscate(source, {
      source,
      target: "lua",
      mode,
      preset: "l1",
      seed: (0x478D0001 + i * 31 + (mode === "register" ? 1 : 0)) >>> 0,
      strength: 3500,
      wrapper: { enabled: false },
      transforms: { watermark: false }
    });
    assert.strictEqual(result.vmMeta.version, "5.9.0", `${mode} case ${i}: version`);
    assert.strictEqual(result.vmMeta.sourceLoaderStages, 0, `${mode} case ${i}: source-loader stage count`);
    assert.doesNotMatch(result.output, /(?<![\w])(?:loadstring|load)\s*\(/, `${mode} case ${i}: no source loader`);
    const syntax = runSyntaxCheck(lua, result.output, "lua");
    assert.ok(syntax.ok, `${mode} case ${i}: syntax failure: ${syntax.error || syntax.stderr}`);
    const run = runProgram(lua, result.output, "lua", expected);
    assert.ok(run.ok, `${mode} case ${i}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(run.stdout)}; ${run.error || run.stderr}`);
    runs++;
  }
}

console.log(`ByteVeil v5.8.0 tail-return regression: PASS (${runs} runtime checks across stack/register; global/local/method calls, vararg forwarding, prefixes, and nil holes; ISA=${OPS.length}/64)`);

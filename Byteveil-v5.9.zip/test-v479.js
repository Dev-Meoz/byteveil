"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { obfuscate } = require("./src");
const { transformBytesV475, inverseTransformBytesV475 } = require("./src/backend/bytecode_serializer");
const watermark = require("./src/transforms/watermark");
const { TARGET_MAX_BYTES } = require("./src/core/output_budget");
const { resolveRuntime, getRuntimeVersion, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
assert.ok(lua, "Lua 5.4 runtime is required for v5.5.0 release/crack tests");
assert.strictEqual(getRuntimeVersion(lua, "lua"), "Lua 5.4", "v5.5.0 release tests require actual Lua 5.4; set BYTECODE_LUA_PATH to the Lua 5.4 executable");
assert.match(watermark.DEFAULT_WATERMARK, /ByteVeil Obfuscator v5\.0\.0/);
assert.strictEqual(TARGET_MAX_BYTES, 475000);
const { getPreset } = require("./src/presets");
for (const presetName of ["l1", "l2", "df", "lz"]) {
  assert.match(getPreset(presetName).transforms.watermark.text, /ByteVeil Obfuscator v5\.0\.0/, `${presetName}: active preset watermark must match engine version`);
}


// The eight lane transform must be reversible for arbitrary bytes and materials.
let state = 0x475A11CE;
const random = () => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return state >>> 0; };
for (let sample = 0; sample < 64; sample++) {
  const bytes = Array.from({ length: 1 + (sample * 37 % 513) }, () => random() & 0xff);
  const materials = Array.from({ length: 8 }, () => random());
  const encoded = transformBytesV475(bytes, materials).bytes;
  const decoded = inverseTransformBytesV475(encoded, materials);
  assert.deepStrictEqual(decoded, bytes, `eight-lane codec round-trip ${sample}`);
}

function build(source, { mode = "stack", preset = "l1", seed = 0x47510001, target = "lua", strength = 1800, watermark = false } = {}) {
  return obfuscate(source, {
    source, target, mode, preset, seed, strength,
    wrapper: { enabled: false }, transforms: { watermark }
  });
}

function assertNoSourceLoaderStages(result, label) {
  assert.strictEqual(result.vmMeta.version, "5.5.0", `${label}: active version`);
  assert.strictEqual(result.vmMeta.nestedObfuscationLayers, 0, `${label}: no source-onion layers`);
  assert.strictEqual(result.vmMeta.runtimeSourceLoaderCount, 0, `${label}: no source loaders declared`);
  assert.strictEqual(result.vmMeta.sourceLoaderStages, 0, `${label}: no source-loader stages`);
  assert.strictEqual(result.vmMeta.payloadTransformLayers, 8, `${label}: eight binary region transforms`);
  assert.strictEqual(result.vmMeta.nativeBufferRuntime, true, `${label}: native Luau buffer path is emitted`);
  assert.strictEqual(result.vmMeta.nestedProfile, "hybrid-function-policy-build-diverse-shadow-local-mangled-position-keyed-striped-payload-vm-no-source-loader", `${label}: accurate profile metadata`);
  assert.strictEqual(result.stats.vmVersion, "5.5.0", `${label}: statistics version metadata`);
  assert.match(result.stats.engine, /v5\.4\.0/, `${label}: statistics engine metadata`);
  assert.ok(result.stats.vmMarkers.includes("mfg-5.5.0-build-diverse-shadow-hardened-carrier-vm"), `${label}: release marker metadata`);
  assert.strictEqual(result.vmMeta.shadowVm, true, `${label}: interleaved shadow VM enabled`);
  assert.strictEqual(result.vmMeta.shadowInterleaved, true, `${label}: shadow VM is interleaved`);
  assert.ok(result.vmMeta.shadowInstructionCount >= 24, `${label}: shadow bytecode must be present`);
  assert.ok(result.vmMeta.shadowHandlerCount >= 8, `${label}: shadow handler bank must be populated`);
  assert.ok(result.vmMeta.shadowHandlerCount >= 40, `${label}: shadow handler bank should span the full build ISA`);
  assert.strictEqual(result.vmMeta.shadowTraceOpcodeCount, 0, `${label}: no static source trace is embedded in the shadow payload`);
  assert.strictEqual(result.vmMeta.shadowOperandTraceDerived, false, `${label}: shadow payload rows are generated independently of source operands`);
  assert.strictEqual(result.vmMeta.shadowStaticSourceTrace, false, `${label}: static source instruction sequence is not embedded`);
  assert.strictEqual(result.vmMeta.shadowArchitecture, "semantic-handler-sandbox-v55-local-mangled-veilsync", `${label}: shadow uses the active build's semantic handler bodies in an isolated sandbox`);
  assert.ok(result.vmMeta.shadowSemanticHandlerCount >= 40, `${label}: semantic shadow must have real handler bodies for the active ISA`);
  assert.ok(result.vmMeta.shadowSemanticHandlerCoverage >= 0.95, `${label}: semantic handler coverage must be at least 95%`);
  assert.deepStrictEqual(result.vmMeta.shadowMissingSemanticHandlers, [], `${label}: no active ISA handler may silently fall back to a dummy semantic handler`);
  assert.strictEqual(result.vmMeta.shadowLiveOpcodeCoupled, true, `${label}: each active shadow dispatch follows the exact runtime opcode route`);
  assert.match(result.vmMeta.shadowDispatchStyle, /per-build-exact-isa-map-runtime-opcode-plus-randomized-binary-decoy-rows/, `${label}: exact build ISA map and randomized decoy rows`);
  assert.strictEqual(result.vmMeta.generatorEngine, "MFG-5.5.0-build-diverse-shadow-hardened-carrier-vm", `${label}: correct generator identity`);
  assert.match(result.vmMeta.runtimeApiProvenanceCheck, /no source-loader call sites/);
  assert.doesNotMatch(result.output, /(?<![\w])(?:loadstring|load)\s*\(/, `${label}: output must not compile source stages`);
  assert.doesNotMatch(result.output, /__bv_load|__bv_envload|loadstring/, `${label}: loader identifiers must not be embedded`);
}

// Source-loader crack test: hook both standard loaders, without bypassing or changing VM guards.
// The runtime must execute correctly and the hook must observe zero loader calls.
function runLoaderCrackProbe(output, expected, label) {
  const hook = [
    'local __origload=load;',
    'load=function(...) io.stderr:write("BV478_LOAD_CALL\\n"); return __origload(...) end;',
    'loadstring=function(...) io.stderr:write("BV478_LOADSTRING_CALL\\n"); return __origload(...) end;'
  ].join(" ") + "\n";
  const run = runProgram(lua, hook + output, "lua", expected);
  assert.ok(run.ok, `${label}: runtime under loader hooks failed: ${run.error || run.stderr || run.stdout}`);
  assert.ok(!/BV478_LOAD(?:STRING)?_CALL/.test(run.stderr), `${label}: at least one source loader was called: ${run.stderr}`);
  return run;
}

// Tiny program: syntax, native runtime, no loader calls, and optional buffer-backed region cache.
const source = 'local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print("BV478", f(3), f(4))';
const direct = build(source, { preset: "lz", seed: 0x47512345, strength: 10000 });
assertNoSourceLoaderStages(direct, "direct build");
assert.ok(Buffer.byteLength(direct.output) < TARGET_MAX_BYTES, "direct output exceeds size budget");
assert.ok(runSyntaxCheck(lua, direct.output, "lua").ok, "v479 syntax");
assert.ok(runProgram(lua, direct.output, "lua", "BV478\t5\t9").ok, "v479 runtime semantics");
runLoaderCrackProbe(direct.output, "BV478\t5\t9", "loader instrumentation probe");

// Red-team regression: removing the live shadow transition call must be rejected by the
// main VM. Also try to spoof the tick counter while leaving the shadow state untouched.
// These focused mutations check two easy bypasses; they do not prove resistance to every
// attacker who can rewrite or remove runtime invariants.
const shadowCallPattern = /local TP=SHADOW\.tick or 0;local TA=SHADOW\.acc or 0;local TR=SHADOW\.r\[1\]or 0;local BA=SHADOW\["([A-Za-z_][A-Za-z0-9_]*)"\]or 0;local ST=([A-Za-z_][A-Za-z0-9_]*)\(SHADOW,Q,I,R,logical,G\.rootSeed\);/g;
const shadowCallMatches = direct.output.match(shadowCallPattern) || [];
assert.strictEqual(shadowCallMatches.length, 1, "release fixture should contain one live shadow transition site");
const skippedShadow = direct.output.replace(shadowCallPattern, (_match, authKey) => `local TP=SHADOW.tick or 0;local TA=SHADOW.acc or 0;local TR=SHADOW.r[1]or 0;local BA=SHADOW[${JSON.stringify(authKey)}]or 0;local ST=0;`);
assert.notStrictEqual(skippedShadow, direct.output, "shadow no-op fixture should alter the generated output");
assert.ok(runSyntaxCheck(lua, skippedShadow, "lua").ok, "shadow no-op probe should remain syntactically valid");
const skippedShadowRun = runProgram(lua, skippedShadow, "lua", "BV478\t5\t9");
assert.ok(!skippedShadowRun.ok, "disabling the shadow step must fail closed");
assert.match(`${skippedShadowRun.stdout || ""} ${skippedShadowRun.stderr || ""} ${skippedShadowRun.error || ""}`, /shadow transition invariant/i, "shadow no-op probe should fail at the transition invariant");

const spoofedTick = direct.output.replace(shadowCallPattern, (_match, authKey) => `local TP=SHADOW.tick or 0;local TA=SHADOW.acc or 0;local TR=SHADOW.r[1]or 0;local BA=SHADOW[${JSON.stringify(authKey)}]or 0;SHADOW.tick=(SHADOW.tick or 0)+3;local ST=0;`);
assert.notStrictEqual(spoofedTick, direct.output, "spoofed-tick fixture should alter the generated output");
assert.ok(runSyntaxCheck(lua, spoofedTick, "lua").ok, "spoofed-tick probe should remain syntactically valid");
const spoofedTickRun = runProgram(lua, spoofedTick, "lua", "BV478\t5\t9");
assert.ok(!spoofedTickRun.ok, "faking only the shadow tick must fail closed");
assert.match(`${spoofedTickRun.stdout || ""} ${spoofedTickRun.stderr || ""} ${spoofedTickRun.error || ""}`, /shadow transition invariant/i, "spoofed-tick probe should fail at the transition invariant");

// Previously observed bypass: fake tick + accumulator + the returned commit value.
// The independent proof must now disagree unless the real handler route is processed.
const shadowCommitPattern = /ST~=([A-Za-z_][A-Za-z0-9_]*)\(SHADOW\.acc or 0,([A-Za-z_][A-Za-z0-9_]*)\(SHADOW\.calls or 0,SHADOW\.ret or 0\)\)/;
const shadowCommitFns = direct.output.match(shadowCommitPattern);
assert.ok(shadowCommitFns, "generated shadow transition should expose a commit expression for mutation testing");
const spoofedStateAndCommit = direct.output.replace(shadowCallPattern, (_match, authKey) => {
  return `local TP=SHADOW.tick or 0;local TA=SHADOW.acc or 0;local TR=SHADOW.r[1]or 0;local BA=SHADOW[${JSON.stringify(authKey)}]or 0;SHADOW.tick=TP+3;SHADOW.acc=(SHADOW.acc or 0)+1;local ST=${shadowCommitFns[1]}(SHADOW.acc or 0,${shadowCommitFns[2]}(SHADOW.calls or 0,SHADOW.ret or 0));`;
});
assert.notStrictEqual(spoofedStateAndCommit, direct.output, "combined state spoof fixture should alter the generated output");
assert.ok(runSyntaxCheck(lua, spoofedStateAndCommit, "lua").ok, "combined state spoof probe should remain syntactically valid");
const spoofedStateRun = runProgram(lua, spoofedStateAndCommit, "lua", "BV478\t5\t9");
assert.ok(!spoofedStateRun.ok, "fake tick + accumulator + commit must fail closed");
assert.match(`${spoofedStateRun.stdout || ""} ${spoofedStateRun.stderr || ""} ${spoofedStateRun.error || ""}`, /shadow transition invariant/i, "combined state spoof should fail at independent shadow proof");

// If an attacker replaces the real-handler semantic probe calls in the live shadow
// wrappers with a constant signature, the proof must independently re-run the active
// semantic handler and reject the inconsistent recorded signature.
const semanticProbeCallPattern = /local SIG=([A-Za-z_][A-Za-z0-9_]*)\(P,O,E,PC,K\)/g;
const semanticProbeCalls = direct.output.match(semanticProbeCallPattern) || [];
assert.ok(semanticProbeCalls.length >= 40, "generated output should bind semantic signatures to real handlers");
const forgedSemanticSignatures = direct.output.replace(semanticProbeCallPattern, "local SIG=0");
assert.notStrictEqual(forgedSemanticSignatures, direct.output, "semantic signature fixture should alter the generated output");
assert.ok(runSyntaxCheck(lua, forgedSemanticSignatures, "lua").ok, "forged semantic signatures should retain valid syntax");
const forgedSemanticRun = runProgram(lua, forgedSemanticSignatures, "lua", "BV478\t5\t9");
assert.ok(!forgedSemanticRun.ok, "forging semantic handler signatures must fail closed");
assert.match(`${forgedSemanticRun.stdout || ""} ${forgedSemanticRun.stderr || ""} ${forgedSemanticRun.error || ""}`, /shadow transition invariant/i, "forged semantic signature should fail the independent semantic proof");

// Replacing the primary semantic probe definition entirely must also be detected.
// The verifier uses a separately named probe with a separate scratch VM state.
const semanticProbeDefinitionPattern = /local ([A-Za-z_][A-Za-z0-9_]*)=function\(P,O,EV,PC,K\).*?return D end(?=;local [A-Za-z_][A-Za-z0-9_]*=)/s;
const semanticProbeDefinition = direct.output.match(semanticProbeDefinitionPattern);
assert.ok(semanticProbeDefinition, "primary semantic probe definition should be present for mutation testing");
const replacedSemanticProbe = direct.output.replace(semanticProbeDefinitionPattern, `local ${semanticProbeDefinition[1]}=function(P,O,EV,PC,K)return 0 end`);
assert.notStrictEqual(replacedSemanticProbe, direct.output, "semantic probe replacement should change generated source");
assert.ok(runSyntaxCheck(lua, replacedSemanticProbe, "lua").ok, "semantic probe replacement should remain syntactically valid");
const replacedSemanticProbeRun = runProgram(lua, replacedSemanticProbe, "lua", "BV478\t5\t9");
assert.ok(!replacedSemanticProbeRun.ok, "replacing the primary semantic probe must fail closed");
assert.match(`${replacedSemanticProbeRun.stdout || ""} ${replacedSemanticProbeRun.stderr || ""} ${replacedSemanticProbeRun.error || ""}`, /shadow transition invariant/i, "independent semantic proof must reject a replaced primary probe");

// Same input with different seeds must produce build-specific code and shadow metadata,
// while both builds retain the same runtime behavior.
const polymorphicSource = 'local x=6; local y=7; print("POLY",x*y)';
const polymorphicA = build(polymorphicSource, { preset: "lz", seed: 0x47641001, strength: 10000 });
const polymorphicB = build(polymorphicSource, { preset: "lz", seed: 0x47641002, strength: 10000 });
assert.notStrictEqual(polymorphicA.vmMeta.shadowFingerprint, polymorphicB.vmMeta.shadowFingerprint, "different seeds must produce different shadow fingerprints");
assert.notStrictEqual(polymorphicA.output, polymorphicB.output, "different seeds must produce different protected outputs");
assert.ok(runProgram(lua, polymorphicA.output, "lua", "POLY\t42").ok, "polymorphic build A runtime");
assert.ok(runProgram(lua, polymorphicB.output, "lua", "POLY\t42").ok, "polymorphic build B runtime");

// Reproduce the exact observable print text in the v4.7.4 crack log, without running its
// recovered layer or the original protected artifact. This is a behavior fixture only.
const observedText = "Long ngu như bò giống như bro á test script mã hóa trong sandbox ko sợ bị chạy mã độc hả?";
const observedRepro = build(`print(${JSON.stringify(observedText)})`, {
  preset: "lz", seed: 0x475D0001, strength: 10000
});
assertNoSourceLoaderStages(observedRepro, "v4.7.4 observed-output reproduction");
assert.ok(!observedRepro.output.includes(observedText), "observed output text must not remain as a plaintext source literal");
assert.ok(runSyntaxCheck(lua, observedRepro.output, "lua").ok, "observed-output reproduction syntax");
assert.ok(runProgram(lua, observedRepro.output, "lua", observedText).ok, "observed-output reproduction runtime");
runLoaderCrackProbe(observedRepro.output, observedText, "v4.7.4 observed-output loader crack probe");

// Exercise the native-buffer execution branch under a Lua-side buffer API shim. This validates
// zero-based read/write integration and checks that it behaves identically to the byte-array path.
const bufferShim = 'buffer={create=function(n) return {n=n,b={}} end, writeu8=function(b,i,v) b.b[i]=v%256 end, readu8=function(b,i) return b.b[i] end};\n';
const bufferRun = runProgram(lua, bufferShim + direct.output, "lua", "BV478\t5\t9");
assert.ok(bufferRun.ok, `buffer-backed region runtime failed: ${bufferRun.error || bufferRun.stderr || bufferRun.stdout}`);
runLoaderCrackProbe(bufferShim + direct.output, "BV478\t5\t9", "buffer + loader instrumentation probe");

// Semantic regression in both VM modes: closures/upvalues and coroutine yields/multiple returns.
const semanticCases = [
  ['local function make(x) return function(y) x=x+y; return x end end; local f=make(2); print(f(3),f(4))', '5\t9'],
  ['local co=coroutine.create(function(x) coroutine.yield(x+1); return x+2 end); local a,b=coroutine.resume(co,4); local c,d=coroutine.resume(co); print(a,b,c,d)', 'true\t5\ttrue\t6'],
  ['local function many() return 2,3,4 end; local a,b,c=many(); print(a,b,c)', '2\t3\t4'],
  ['local function many() return 8,9 end; local a,b=(many()); print(a,b)', '8\tnil'],
  ['local a=17; local b=5; print(a+b,a-b,a*b,a//b,a%b)', '22\t12\t85\t3\t2'],
  ['local x=9; if x>4 and x~=7 then print("yes",x) else print("no") end', 'yes\t9'],
  ['local t={2,3}; t[1]=t[1]+4; t.name="ok"; print(t[1],t[2],t.name)', '6\t3\tok'],
  ['local function f(...) return select("#",...),... end; local n,a,b,c=f("x",2,true); print(n,a,b,c)', '3\tx\t2\ttrue'],
  ['local t={}; local i=1; t[i],i=5,i+1; print(t[1],i)', '5\t2'],
  ['local log=""; local t={}; local function obj() log=log.."o"; return t end; local function key() log=log.."k"; return 1 end; local function rhs() log=log.."r"; return 7 end; obj()[key()],log=rhs(),log.."x"; print(t[1],log)', '7\tokrx'],
  ['local x=0; x,x=3,8; print(x)', '8'],
  ['local function fact(n) if n<=1 then return 1 end return n*fact(n-1) end; print(fact(5))', '120'],
  ['local a="Byte"; local b="Veil"; print(a.."-"..b,#(a..b))', 'Byte-Veil\t8'],
];
let semanticRuns = 0;
for (const [i, [program, expected]] of semanticCases.entries()) {
  for (const mode of ["stack", "register"]) {
    const result = build(program, { mode, preset: "l1", seed: (0x47520001 + i * 17 + (mode === "register" ? 1 : 0)) >>> 0 });
    assertNoSourceLoaderStages(result, `${mode} semantic ${i}`);
    assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${mode} semantic ${i} syntax`);
    const execution = runProgram(lua, result.output, "lua", expected);
    assert.ok(execution.ok, `${mode} semantic ${i}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
    semanticRuns++;
  }
}

// Public preset matrix: presets vary payload strength/shape, not the number of source-loader stages.
const presetSource = 'local function add(a,b) return a+b end; print("PRESET_OK",add(2,3))';
for (const [i, preset] of ["l1", "l2", "df", "lz"].entries()) {
  const result = build(presetSource, { preset, seed: (0x47530001 + i) >>> 0, strength: ({ l1: 1800, l2: 3500, df: 8000, lz: 10000 })[preset], watermark: true });
  assertNoSourceLoaderStages(result, `preset ${preset}`);
  assert.ok(runSyntaxCheck(lua, result.output, "lua").ok, `${preset}: syntax`);
  const execution = runProgram(lua, result.output, "lua", "PRESET_OK\t5");
  assert.ok(execution.ok, `${preset}: expected PRESET_OK\t5, got ${JSON.stringify(execution.stdout)}; ${execution.error || execution.stderr}`);
}

// Full shipped fixture under maximum settings; this is a per-fixture budget, not a universal size claim.
const fixture = fs.readFileSync(path.join(__dirname, "examples/input.lua"), "utf8");
const full = build(fixture, { preset: "lz", seed: 0x476B0001, strength: 10000 });
assertNoSourceLoaderStages(full, "release fixture");
assert.strictEqual(full.vmMeta.generatorEngine, "MFG-5.5.0-build-diverse-shadow-hardened-carrier-vm");
const outputBytes = Buffer.byteLength(full.output);
assert.ok(outputBytes < TARGET_MAX_BYTES, `fixture output exceeded 475000 bytes: ${outputBytes}`);
assert.ok(runSyntaxCheck(lua, full.output, "lua").ok, "release fixture syntax");
assert.ok(runProgram(lua, full.output, "lua", "5").ok, "release fixture runtime");
runLoaderCrackProbe(full.output, "5", "release fixture crack probe");

// Luau target output must retain portable syntax. Native Roblox/Luau isn't installed in this environment.
const luauResult = build('print("LUAU_TARGET_OK")', { target: "luau", preset: "lz", seed: 0x475C0001 });
assert.strictEqual(luauResult.target, "luau");
assertNoSourceLoaderStages(luauResult, "Luau target");
assert.ok(runSyntaxCheck(lua, luauResult.output, "lua").ok, "Luau target should retain portable Lua syntax");

console.log(`ByteVeil v5.5.0 shadow/semantic regression: PASS (${semanticRuns} semantic mode runs; build-diverse payload lanes; shadow skip/tick/state-spoof/semantic-signature/probe-replacement probes rejected; 0 source-loader stages; fixture=${outputBytes} bytes; loader crack probes=0 calls)`);

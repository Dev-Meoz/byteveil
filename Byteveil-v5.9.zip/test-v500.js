"use strict";

const assert = require("node:assert/strict");
const packageInfo = require("./package.json");
const version = require("./src/core/version");
const { obfuscate } = require("./src");
const { buildProtectionPlan } = require("./src/transforms");
const numberObfuscator = require("./src/transforms/number_obfuscator");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const watermark = require("./src/transforms/watermark");

assert.equal(packageInfo.version, "5.0.0");
assert.equal(version.ENGINE_VERSION, packageInfo.version);
assert.equal(watermark.DEFAULT_WATERMARK.includes("v5.0.0"), true);

// The numeric pass reports only effects that actually happen; there is no
// unused __bvNumberEncoding decoration masquerading as an active transform.
const numericAst = { type: "Chunk", body: [{ type: "Return", values: [{ type: "Number", value: 1337 }] }] };
numberObfuscator.transform(numericAst, { enabled: true, seed: 0x500 });
assert.equal(numericAst.__numbers.requested, true);
assert.equal(numericAst.__numbers.applied, false);
assert.equal(numericAst.__numbers.numbersSeen, 1);
assert.equal(numericAst.body[0].values[0].__bvNumberEncoding, undefined);
const plan = buildProtectionPlan(numericAst, { numbers: true, version: packageInfo.version, seed: 0x500 });
assert.equal(plan.version, packageInfo.version);
assert.equal(plan.transformEffects.numbers.applied, false);
assert.match(plan.transformEffects.numbers.note, /not rewritten/);

// Anti-hook metadata and code agree: failure to resolve an environment is no
// longer silently reported as success. This is a detection guard, not proof
// that APIs could not have been replaced before program startup.
const anti = buildAntiHookSource({ enabled: true, prefix: "__v5", failClosedOnMissingEnvironment: true });
assert.doesNotMatch(anti.declaration, /runtime guard unavailable|runtime integrity check failed|\["type"\]|\["pcall"\]/i);
assert.match(anti.declaration, /__v5_keys|__v510_keys/);
assert.doesNotMatch(anti.declaration, /if __v5_env == nil then return true end/);
assert.equal(anti.metadata.antiHookGuaranteesNoNativeHook, false);
const legacyAnti = buildAntiHookSource({ enabled: true, prefix: "__v479" });
assert.match(legacyAnti.declaration, /if __v479_env == nil then return true end/);

const source = 'local function make(x) return function(y) return x + y end end; local f = make(2); print(f(3))';
for (const mode of ["stack", "register"]) {
  const result = obfuscate(source, {
    source,
    target: "lua",
    mode,
    preset: "l1",
    seed: 0x5005A17 + (mode === "register" ? 1 : 0),
    strength: 3500,
    wrapper: { enabled: false }
  });

  assert.equal(result.vmMeta.version, packageInfo.version, `${mode}: active version`);
  assert.equal(result.vmMeta.payloadCarrierCodec, "position-keyed-four-family-alphabet-stream-v5", `${mode}: codec selected`);
  assert.equal(result.vmMeta.payloadLayout, version.PAYLOAD_LAYOUT, `${mode}: layout matches shared version contract`);
  assert.equal(result.vmMeta.stagedPayloadMaterialization, version.PAYLOAD_LAYOUT, `${mode}: materialization metadata matches`);
  assert.equal(result.vmMeta.runtimeSourceLoaderCount, 0, `${mode}: output must not add source-loader stages`);
  assert.equal(result.vmMeta.nestedProfile, version.NESTED_PROFILE, `${mode}: one canonical nested profile`);
  assert.equal(result.vmMeta.shadowArchitecture, "semantic-handler-sandbox-v5", `${mode}: v5 architecture metadata is not stale`);
  assert.equal(result.vmMeta.generatorEngine, "MFG-5.0.0-position-keyed-carrier-vm", `${mode}: generator identity is v5`);
  assert.match(result.stats.engine, /v5\.0\.0/, `${mode}: engine statistics report v5`);
  assert.match(result.output, /function\(S,A,O,R,K,Z,Q\)/, `${mode}: runtime decoder consumes per-carrier stream parameters`);
  assert.ok(result.output.startsWith("--This file was protected using ByteVeil Obfuscator v5.0.0"), `${mode}: active watermark`);
  assert.doesNotMatch(result.output, /ByteVeil v4\.7\.8:/, `${mode}: no stale runtime label`);
}

console.log("ByteVeil v5.0.0 core contract: PASS (version, truthful numeric reporting, fail-closed environment guard, position-keyed payload codec in Stack/Register)");

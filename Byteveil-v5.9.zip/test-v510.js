"use strict";

const assert = require("node:assert/strict");
const packageInfo = require("./package.json");
const version = require("./src/core/version");
const { obfuscate } = require("./src");
const { buildProtectionPlan } = require("./src/transforms");
const numberObfuscator = require("./src/transforms/number_obfuscator");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const watermark = require("./src/transforms/watermark");
const { rewriteLuaIdentifiers, collectLuaIdentifiers, mangleGeneratedInternals } = require("./src/utils/lua_identifier_rewriter");
const { stackHandler, registerHandler } = require("./src/vm/vm_handlers");
const { createNameFactory } = require("./src/protection/byteveil_micro");
const { parseArgs: parseLPHArgs } = require("./src/lph");
const { runProgram, resolveRuntime } = require("./tools/native-runtime");

assert.equal(packageInfo.version, "5.9.0");
assert.equal(version.ENGINE_VERSION, packageInfo.version);
assert.equal(watermark.DEFAULT_WATERMARK.includes("v5.9.0"), true);
const seededNamesA = createNameFactory({ seed: "repeatable-v51", prefix: "_q" });
const seededNamesB = createNameFactory({ seed: "repeatable-v51", prefix: "_q" });
assert.deepEqual([seededNamesA.next(), seededNamesA.next()], [seededNamesB.next(), seededNamesB.next()], "Micro explicit-seed names must remain reproducible");
const unseededNamesA = createNameFactory({ prefix: "_q" });
const unseededNamesB = createNameFactory({ prefix: "_q" });
assert.notEqual(unseededNamesA.next(), unseededNamesB.next(), "Micro unseeded name factories should use per-instance entropy");
assert.deepEqual(parseLPHArgs(`"left,right", third, 'four, five'`), ["left,right", "third", "four, five"], "LPH parser must keep commas inside quoted directive args");

// Identifier handling is lexical: strings and comments and public API spellings remain intact.
const lexical = `local S=1; local I=S+2; local text="S I tostring"; -- S I\nreturn I`;
const lexicalResult = rewriteLuaIdentifiers(lexical, (name) => name === "S" ? "A7x" : name === "I" ? "I0l" : name);
assert.match(lexicalResult, /local A7x=1/);
assert.match(lexicalResult, /local I0l=A7x\+2/);
assert.match(lexicalResult, /"S I tostring"/);
assert.match(lexicalResult, /-- S I/);
const aliasSource = 'local __bv_type=type;local _bvanti_guard=function() return tostring(1) end;local t="__bv_type _bvanti_guard";return __bv_type,t';
const mangledA = mangleGeneratedInternals(aliasSource, 0x51A7);
const mangledB = mangleGeneratedInternals(aliasSource, 0x51A7);
const mangledOtherBuild = mangleGeneratedInternals(aliasSource, 0x51A8);
assert.equal(mangledA, mangledB, "same seed should reproduce internal identifier mangling");
assert.notEqual(mangledA, mangledOtherBuild, "different seeds should produce different internal names");
const mangledIdentifiers = collectLuaIdentifiers(mangledA);
assert.equal(mangledIdentifiers.has("__bv_type"), false);
assert.equal(mangledIdentifiers.has("_bvanti_guard"), false);
assert.match(mangledA, /tostring/);
assert.match(mangledA, /"__bv_type _bvanti_guard"/);
const handlerA = stackHandler("test", 'S.value=I[1];local text="S I";return tostring(S.value)', { seed: 1234, identity: "ADD" });
const handlerARepeat = stackHandler("test", 'S.value=I[1];local text="S I";return tostring(S.value)', { seed: 1234, identity: "ADD" });
const handlerB = registerHandler("test", 'S.value=I[1];local text="S I";return tostring(S.value)', { seed: 1235, identity: "ADD" });
assert.equal(handlerA, handlerARepeat, "handler names should be deterministic for an explicit seed");
assert.notEqual(handlerA, handlerB, "handler parameters should vary across builds");
assert.match(handlerA, /tostring/);
assert.match(handlerA, /"S I"/);
assert.doesNotMatch(handlerA, /function\(S,I\)/);


// The numeric pass reports only effects that actually happen; there is no
// unused __bvNumberEncoding decoration masquerading as an active transform.
const numericAst = { type: "Chunk", body: [{ type: "Return", values: [{ type: "Number", value: 1337 }] }] };
numberObfuscator.transform(numericAst, { enabled: true, seed: 0x500 });
assert.equal(numericAst.__numbers.requested, true);
assert.equal(numericAst.__numbers.applied, false);
assert.equal(numericAst.__numbers.numbersSeen, 1);
assert.equal(numericAst.body[0].values[0].__bvNumberEncoding, undefined);
const plan = buildProtectionPlan(numericAst, { numbers: true, version: packageInfo.version, seed: 0x500 });
assert.equal(plan.version, packageInfo.version);
assert.equal(plan.transformEffects.numbers.applied, false);
assert.match(plan.transformEffects.numbers.note, /not rewritten/);

// Anti-hook metadata and code agree: failure to resolve an environment is no
// longer silently reported as success. This is a detection guard, not proof
// that APIs could not have been replaced before program startup.
const anti = buildAntiHookSource({ enabled: true, prefix: "__v5", failClosedOnMissingEnvironment: true });
assert.doesNotMatch(anti.declaration, /runtime guard unavailable|runtime integrity check failed|\["type"\]|\["pcall"\]/i);
assert.match(anti.declaration, /__v5_keys|__v510_keys/);
assert.doesNotMatch(anti.declaration, /if __v5_env == nil then return true end/);
assert.equal(anti.metadata.antiHookGuaranteesNoNativeHook, false);
const defaultAnti = buildAntiHookSource({ enabled: true, prefix: "__v510" });
assert.doesNotMatch(defaultAnti.declaration, /runtime guard unavailable/i);
assert.match(defaultAnti.declaration, /__v510_keys/);
const optOutAnti = buildAntiHookSource({ enabled: true, prefix: "__v510opt", failClosedOnMissingEnvironment: false });
assert.match(optOutAnti.declaration, /if __v510opt_env == nil then return true end/);

const source = 'local function make(x) return function(y) return x + y end end; local f = make(2); print(f(3))';
for (const mode of ["stack", "register"]) {
  const result = obfuscate(source, {
    source,
    target: "lua",
    mode,
    preset: "l1",
    seed: 0x5005A17 + (mode === "register" ? 1 : 0),
    strength: 3500,
    wrapper: { enabled: false }
  });

  assert.equal(result.vmMeta.version, packageInfo.version, `${mode}: active version`);
  assert.equal(result.vmMeta.payloadCarrierCodec, "position-keyed-four-family-alphabet-stream-v5.1-build-diverse", `${mode}: codec selected`);
  assert.equal(result.vmMeta.payloadLayout, version.PAYLOAD_LAYOUT, `${mode}: layout matches shared version contract`);
  assert.equal(result.vmMeta.stagedPayloadMaterialization, "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified", `${mode}: materialization metadata matches`);
  assert.equal(result.vmMeta.runtimeSourceLoaderCount, 0, `${mode}: output must not add source-loader stages`);
  assert.equal(result.vmMeta.nestedProfile, version.NESTED_PROFILE, `${mode}: one canonical nested profile`);
  assert.equal(result.vmMeta.shadowArchitecture, "semantic-handler-sandbox-v59-shared-dispatch-core-veilsync-v2-region-verified", `${mode}: v5 architecture metadata is not stale`);
  assert.equal(result.vmMeta.generatorEngine, "MFG-5.9.0-shared-shadow-dispatch-core-veilsync-v2-region-verified-vm", `${mode}: generator identity is v5`);
  assert.match(result.stats.engine, /v5\.9\.0/, `${mode}: engine statistics report v5`);
  assert.match(result.output, /function\(S,A,O,R,K,Z,Q\)/, `${mode}: runtime decoder consumes per-carrier stream parameters`);
  assert.doesNotMatch(result.output, /function\(S,I\)/, `${mode}: legacy fixed state/instruction handler signature must not remain in active output`);
  const outputIdentifiers = collectLuaIdentifiers(result.output);
  assert.equal([...outputIdentifiers].some((name) => name.startsWith("__bv_") || name.startsWith("_bvanti_")), false, `${mode}: generated internal aliases must be blended into the output identifiers`);
  assert.match(result.output, /tostring\s*\(/, `${mode}: standard API calls remain ordinary calls`);
  assert.ok(result.output.startsWith("--This file was protected using ByteVeil Obfuscator v5.9.0"), `${mode}: active watermark`);
  assert.doesNotMatch(result.output, /ByteVeil v4\.7\.8:/, `${mode}: no stale runtime label`);
}


// Same input but different explicit seeds must alter the actual generated build,
// including the payload lane layout. This checks more than a renamed version string.
const diversitySource = 'local t={1,2,3}; local x=t[1]; return x+t[2]';
const diversityA = obfuscate(diversitySource, { source: diversitySource, target: "lua", mode: "register", preset: "l1", seed: 101, strength: 3500, wrapper: { enabled: false } });
const diversityB = obfuscate(diversitySource, { source: diversitySource, target: "lua", mode: "register", preset: "l1", seed: 102, strength: 3500, wrapper: { enabled: false } });
assert.notEqual(diversityA.output, diversityB.output, "different explicit seeds must generate different output bytes");
assert.notEqual(diversityA.vmMeta.payloadLaneCount, diversityB.vmMeta.payloadLaneCount, "the same source must support a different payload lane count across these seeded builds");
assert.notDeepEqual(diversityA.vmMeta.vmStateOrder, diversityB.vmMeta.vmStateOrder, "state field layout must be build-dependent");
assert.notEqual(diversityA.vmMeta.vmStateProfile, diversityB.vmMeta.vmStateProfile, "state profile should vary across these seeded builds");
assert.notEqual(diversityA.vmMeta.vmDispatchTopology, diversityB.vmMeta.vmDispatchTopology, "active dispatch topology should vary across these seeded builds");
assert.equal(diversityA.vmMeta.opcodeWhitening, true, "the active VM must keep opcode whitening enabled");
const diversityRepeat = obfuscate(diversitySource, { source: diversitySource, target: "lua", mode: "register", preset: "l1", seed: 101, strength: 3500, wrapper: { enabled: false } });
assert.equal(diversityA.output, diversityRepeat.output, "an explicit seed must reproduce byte-identical output for debugging");
assert.equal(diversityA.vmMeta.mode, "register");
assert.equal(diversityB.vmMeta.mode, "register");

// The wrapper opt-out must read the same through both spellings the API accepts. A
// boolean used to be dropped by the option merge, so `{wrapper:false}` silently shipped
// the callable bootstrap the caller had just asked to remove.
const wrapperSource = 'local v = 7 print(v * 6)';
const wrapped = obfuscate(wrapperSource, { target: "lua", mode: "register", preset: "l1", seed: 5151, junkForge: false });
const boolOff = obfuscate(wrapperSource, { target: "lua", mode: "register", preset: "l1", seed: 5151, junkForge: false, wrapper: false });
const objectOff = obfuscate(wrapperSource, { target: "lua", mode: "register", preset: "l1", seed: 5151, junkForge: false, wrapper: { enabled: false } });
assert.equal(wrapped.vmMeta.wrapper.shape !== "no-callable-bootstrap-tail", true, "a default build must carry the callable bootstrap");
assert.equal(boolOff.vmMeta.wrapper.shape, "no-callable-bootstrap-tail", "wrapper:false must remove the bootstrap, not be ignored");
assert.equal(objectOff.vmMeta.wrapper.shape, "no-callable-bootstrap-tail", "wrapper:{enabled:false} must agree with the boolean form");
assert.equal(boolOff.output, objectOff.output, "both opt-out spellings must produce byte-identical output for one seed");
assert.notEqual(boolOff.output, wrapped.output, "the opt-out must actually change the artifact");
for (const [label, build] of [["wrapper:false", boolOff], ["wrapper:{enabled:false}", objectOff], ["default", wrapped]]) {
    const run = runProgram(resolveRuntime("lua"), build.output, "lua");
    assert.ok(run.ok && String(run.stdout).trim() === "42", `${label} build must still run: ${run.stderr}`);
}
// The nest route wraps the body in encoded inner chunks, so the outer tail cannot show the
// bootstrap. It has to report that limit instead of claiming the bootstrap is absent.
const nestWrapped = obfuscate(wrapperSource, { target: "lua", mode: "register", preset: "nest", seed: 5151, junkForge: false });
const nestUnwrapped = obfuscate(wrapperSource, { target: "lua", mode: "register", preset: "nest", seed: 5151, junkForge: false, wrapper: false });
assert.equal(nestWrapped.vmMeta.nestedObfuscation, true, "the nest preset must report the nested route");
assert.equal(nestWrapped.vmMeta.wrapper.shape, "bootstrap-in-nested-source", "a nested build must not be labelled as missing its bootstrap");
assert.equal(nestUnwrapped.vmMeta.wrapper.shape, "no-callable-bootstrap-tail", "disabling the wrapper on nest must still report the removed bootstrap");
assert.notEqual(nestWrapped.output, nestUnwrapped.output, "the wrapper opt-out must reach the nested route too");

console.log("ByteVeil v5.8.0 core contract: PASS (version, lexical internal-name mangling, seeded payload lane diversity, wrapper opt-out spellings, nested-route shape honesty, and Stack/Register routing)");

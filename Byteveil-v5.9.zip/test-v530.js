"use strict";

const assert = require("node:assert/strict");
const packageInfo = require("./package.json");
const version = require("./src/core/version");
const { parse } = require("./src/frontend/parser");
const { encodeDiagnosticStrings } = require("./src/utils/diagnostic_string_encoder");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

assert.equal(packageInfo.version, "5.3.0");
assert.equal(version.ENGINE_VERSION, packageInfo.version);

function expressionOf(source) {
  const ast = parse(source);
  assert.equal(ast.body.length, 1, source);
  assert.equal(ast.body[0].type, "Return", source);
  return ast.body[0].values[0];
}

// Lua operator precedence: power binds more tightly than unary; shifts are
// below addition; bitwise precedence levels are not collapsed together.
const negativePower = expressionOf("return -2^2");
assert.equal(negativePower.type, "Unary");
assert.equal(negativePower.op, "-");
assert.equal(negativePower.arg.type, "Binary");
assert.equal(negativePower.arg.op, "^");
assert.equal(expressionOf("return (-2)^2").op, "^");
const addBeforeShift = expressionOf("return 1+2<<3");
assert.equal(addBeforeShift.op, "<<");
assert.equal(addBeforeShift.left.type, "Binary");
assert.equal(addBeforeShift.left.op, "+");
const shiftBeforeAnd = expressionOf("return 1&2<<3");
assert.equal(shiftBeforeAnd.op, "&");
assert.equal(shiftBeforeAnd.right.op, "<<");
const addBeforeBitOr = expressionOf("return 1|2+3");
assert.equal(addBeforeBitOr.op, "|");
assert.equal(addBeforeBitOr.right.op, "+");
const powerRightAssoc = expressionOf("return 2^3^2");
assert.equal(powerRightAssoc.right.op, "^");

// The anti-hook builder no longer emits marketing/debug text as cleartext.
const anti = buildAntiHookSource({ prefix: "_test_guard" });
assert.doesNotMatch(anti.declaration, /Detected hook|Made by Meoz|Runtime error !|environment unavailable/i);
assert.doesNotMatch(anti.declaration, /runtime integrity check failed|runtime guard unavailable|\["type"\]|\["pcall"\]|then\s+error\s*\(/i);
assert.match(anti.declaration, /_test_guard_keys/);
assert.match(anti.declaration, /_test_guard_decode/);
assert.match(anti.declaration, /for _test_guard_i = 1/);
const antiOtherSeed = buildAntiHookSource({ prefix: "_test_guard", seed: 0xF0000001 });
assert.notEqual(anti.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], antiOtherSeed.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], "guard key representation should vary by seed");

// Diagnostic encoding preserves the runtime string value (Lua decimal escapes)
// and does not touch comments, long-bracket literals, or unrelated strings.
const comment = '-- "ByteVeil v4.6.3: tamper detected"\n';
const sample = `${comment}local diagnostic="ByteVeil v4.6.3: tamper detected"; local normal="hello"; local opaque=[=[ByteVeil v4.6.3: tamper detected]=]`;
const encoded = encodeDiagnosticStrings(sample);
assert.equal(encoded.encoded, 1);
assert.equal(encoded.errorCallsAliased, 0, "comments and strings without an error alias do not alter call sites");
assert.ok(encoded.source.startsWith(comment));
assert.doesNotMatch(encoded.source, /local diagnostic="ByteVeil v4\.6\.3: tamper detected"/);
assert.match(encoded.source, /local normal="hello"/);
assert.match(encoded.source, /opaque=\[\[?=\[ByteVeil v4\.6\.3: tamper detected\]=\]?\]/);

// Full generated output uses decimal escapes for runtime diagnostics while the
// visible release watermark (a comment) remains an intentional public marker.
const result = obfuscate("local value=2; return value^3", {
  mode: "stack", seed: 0x520052, wrapper: { enabled: false },
  transforms: { watermark: false }
});
assert.equal(result.vmMeta.version, "5.3.0");
assert.ok(result.stats.diagnosticStringsEncoded > 0);
assert.ok(result.stats.diagnosticErrorCallsAliased > 0, "generated error calls should use the emitted local error alias");
assert.doesNotMatch(result.output, /then\s+error\s*\(/i, "generated guards should not expose repeated `then error(...)` patterns");
assert.doesNotMatch(result.output, /\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]\s*~=\s*[^;\n]*\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]/i, "generated guard must not repeat string-keyed API-to-API comparisons");
assert.doesNotMatch(result.output, /Byte[Vv]eil v\d+\.\d+\.\d+: (?:instruction representation|runtime shield|tamper detected)/);
assert.doesNotMatch(result.output, /Detected hook|Made by Meoz|Runtime error !|ByteVeil environment unavailable|runtime integrity check failed|runtime guard unavailable/);
assert.ok(Buffer.byteLength(result.output, "utf8") <= 475000, "sample output respects release budget");

for (const mode of ["stack", "register"]) {
  const guardOutput = obfuscate("print(1+2)", {
    mode, seed: 0x530053 + (mode === "register" ? 1 : 0),
    wrapper: { enabled: false }, transforms: { watermark: false }
  }).output;
  assert.doesNotMatch(guardOutput, /runtime integrity check failed|runtime guard unavailable/i, `${mode}: guard diagnostics should not remain plaintext`);
  assert.doesNotMatch(guardOutput, /\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]\s*~=\s*[^;\n]*\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]/i, `${mode}: no repeated string-keyed API comparisons`);
  assert.doesNotMatch(guardOutput, /then\s+error\s*\(/i, `${mode}: no direct then error call`);
  assert.ok(Buffer.byteLength(guardOutput, "utf8") <= 475000, `${mode}: output respects release budget`);
}

// Differential arithmetic regression: parser precedence and stack-depth
// validation must agree with the available native Lua runtime.
const lua = resolveRuntime("lua");
if (lua) {
  const guardSuccess = `${anti.declaration}\n${anti.checkCall}\nprint("guard-ok")`;
  const guardSuccessResult = runProgram(lua, guardSuccess, "lua");
  assert.ok(guardSuccessResult.ok, guardSuccessResult.stderr || "generated guard should pass in a clean Lua environment");
  assert.equal(guardSuccessResult.stdout.trim(), "guard-ok");

  const changedApi = `${anti.declaration}\nlocal __original_tostring = tostring\ntostring = function(v) return __original_tostring(v) end\nlocal __ok = pcall(function() ${anti.checkCall} end)\ntostring = __original_tostring\nprint(__ok)`;
  const changedApiResult = runProgram(lua, changedApi, "lua");
  assert.ok(changedApiResult.ok, changedApiResult.stderr || "mutated API guard fixture should run");
  assert.equal(changedApiResult.stdout.trim(), "false", "generated guard must still detect API replacement after startup");

  const originalDiagnostic = 'local ok, message = pcall(function() error("ByteVeil v4.6.3: tamper detected", 0) end); print(message)';
  const encodedDiagnostic = encodeDiagnosticStrings(originalDiagnostic).source;
  const diagnosticOriginalResult = runProgram(lua, originalDiagnostic, "lua");
  const diagnosticEncodedResult = runProgram(lua, encodedDiagnostic, "lua");
  assert.ok(diagnosticOriginalResult.ok, diagnosticOriginalResult.stderr || "original diagnostic fixture failed");
  assert.ok(diagnosticEncodedResult.ok, diagnosticEncodedResult.stderr || "encoded diagnostic fixture failed");
  assert.equal(diagnosticEncodedResult.stdout, diagnosticOriginalResult.stdout, "encoded diagnostics must preserve the actual runtime string");

  const arithmetic = "print(-2^2,(-2)^2,2^3^2,2^-3,(1+2)<<3,1|(2+3),1&(2<<3))";
  const nativeResult = runProgram(lua, arithmetic, "lua");
  assert.ok(nativeResult.ok, nativeResult.stderr || "native arithmetic fixture failed");
  for (const mode of ["stack", "register"]) {
    const protectedArithmetic = obfuscate(arithmetic, {
      mode, seed: 0x520053 + (mode === "register" ? 1 : 0), wrapper: { enabled: false },
      transforms: { watermark: false }
    });
    const syntax = runSyntaxCheck(lua, protectedArithmetic.output, "lua");
    assert.ok(syntax.ok, syntax.stderr || syntax.error || `${mode} arithmetic syntax failed`);
    const protectedResult = runProgram(lua, protectedArithmetic.output, "lua");
    assert.ok(protectedResult.ok, protectedResult.stderr || `${mode} protected arithmetic fixture failed`);
    assert.equal(protectedResult.stdout, nativeResult.stdout, `${mode} VM arithmetic should match native Lua for precedence fixture`);
  }


  // Luau `continue` must take the correct loop-specific edge: condition for
  // while, condition after the body for repeat, and update/iterator for for-loops.
  const continueFixtures = [
    ["numeric-for", "local n=0; for i=1,5 do if i==2 then continue end; n+=i end; print(n)", "local n=0; for i=1,5 do if i~=2 then n=n+i end end; print(n)"],
    ["while", "local i=0; local n=0; while i<5 do i+=1; if i==2 then continue end; n+=i end; print(n)", "local i=0; local n=0; while i<5 do i=i+1; if i~=2 then n=n+i end end; print(n)"],
    ["repeat", "local i=0; local n=0; repeat i+=1; if i==2 then continue end; n+=i until i>=5; print(n)", "local i=0; local n=0; repeat i=i+1; if i~=2 then n=n+i end until i>=5; print(n)"],
    ["generic-for", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k==2 then continue end; n+=v end; print(n)", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k~=2 then n=n+v end end; print(n)"],
    ["nested-loop", "local n=0; for i=1,3 do for j=1,3 do if j==2 then continue end; n+=1 end end; print(n)", "local n=0; for i=1,3 do for j=1,3 do if j~=2 then n=n+1 end end end; print(n)"],
  ];
  for (const [name, source, reference] of continueFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} reference fixture failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52100 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} output syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} continue semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate("continue", { mode: "stack", target: "lua", wrapper: { enabled: false } }), /continue outside loop/i);

  // Luau backtick strings are lowered into concat/tostring AST nodes. Compare
  // VM output against equivalent ordinary Lua instead of feeding backticks to Lua 5.3.
  const interpolationFixtures = [
    ["basic", 'local name="Luau"; print(`Hello {name}!`)', 'local name="Luau"; print("Hello " .. tostring(name) .. "!")'],
    ["expressions", 'print(`{1 + 2} {true} {nil}`)', 'print(tostring(1 + 2) .. " " .. tostring(true) .. " " .. tostring(nil))'],
    ["escaped-braces", 'print(`Some example \\{like so\\}`)', 'print("Some example {like so}")'],
    ["quoted-brace", 'print(`a {select(1, "}", 3)} b`)', 'print("a " .. tostring(select(1, "}", 3)) .. " b")'],
    ["unicode-escape", 'local s="雪"; print(`💬 {s} \\u{1F600}`)', 'local s="雪"; print("💬 " .. tostring(s) .. " 😀")'],
    ["escaped-backtick", 'print(`tick: \\` ok`)', 'print("tick: ` ok")'],
  ];
  for (const [name, source, reference] of interpolationFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} interpolation reference failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52200 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} interpolation syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} interpolation runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} interpolation semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate('print(`{{`)', { mode: "stack", target: "lua", wrapper: { enabled: false } }), /interpolation|parser error/i);
}

console.log(`ByteVeil v5.3.0 focused regressions: PASS (Lua precedence, continue loop edges, Luau interpolation, runtime guard codec, output=${Buffer.byteLength(result.output, "utf8")} bytes)`);

"use strict";

// Backward-compatible entry point: current regression contract lives in test-v560.js.
require("./test-v560");

"use strict";

const assert = require("node:assert/strict");
const packageInfo = require("./package.json");
const version = require("./src/core/version");
const { parse } = require("./src/frontend/parser");
const { encodeDiagnosticStrings } = require("./src/utils/diagnostic_string_encoder");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const { obfuscate } = require("./src");
const { mangleLuaLocalIdentifiers, buildShadowStrings, buildSemanticShadowVM } = require("./src/protection/live_shadow_vm");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

assert.equal(packageInfo.version, "5.7.0");
assert.equal(version.ENGINE_VERSION, packageInfo.version);
const { getPreset } = require("./src/presets");
assert.equal(getPreset("nest").nestedSourceEngine, "legacy-wrapSource-v4.7.4");
assert.ok(getPreset("nest").strength > getPreset("l2").strength && getPreset("nest").strength < getPreset("df").strength, "Nest preset belongs between l2 and df strength");

const { wrap, minify } = require("./src/wrappers/WrapInFunction");
const { createBootstrapPlan } = require("./src/wrappers/bootstrap_renderer");
const { mangleGeneratedInternals } = require("./src/utils/lua_identifier_rewriter");
const { buildDecoyProgram } = require("./src/protection/decoy_compiler");
const directMetaWrapper = wrap("print(1)", { seed: 123, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
assert.ok(directMetaWrapper.startsWith("return setmetatable({"), "wrapper must begin with direct return setmetatable");
assert.match(directMetaWrapper, /^return setmetatable\(\{\[\d+\]=function\(/, "v5.7 bootstrap must begin with a numeric runtime slot");
const wrapperSlots = [...directMetaWrapper.matchAll(/\[(\d+)\]=function\(/g)].map((match) => Number(match[1]));
assert.equal(wrapperSlots.length, 3, "callable bootstrap must expose body, dispatch, and entry slots");
assert.equal(new Set(wrapperSlots).size, wrapperSlots.length, "bootstrap slots must be unique per build");
assert.match(directMetaWrapper, /__call=function\(/, "callable bootstrap needs an explicit __call dispatch");
assert.ok(directMetaWrapper.includes(`return `) && directMetaWrapper.includes("(...)") , "dispatch path must forward the full vararg tuple");
assert.doesNotMatch(directMetaWrapper, /^do\s+return setmetatable/);
assert.doesNotMatch(directMetaWrapper, /\nend\s*$/);
assert.doesNotMatch(directMetaWrapper, /[\r\n]/, "wrapper output should be minified at the wrapper boundary");
const bodySlotMatch = directMetaWrapper.match(/\[(\d+)\]=function\(([^)]*)\)print\(1\)end/);
assert.ok(bodySlotMatch, "bootstrap must keep the program body in its own entry function");
const wrapperArgs = bodySlotMatch[2];
assert.ok(directMetaWrapper.endsWith(`})(${wrapperArgs})`), "wrapper invocation must use its matching bridge arguments rather than illegal chunk-level varargs");
const wrapperSeedVariant = wrap("print(1)", { seed: 124, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
assert.notEqual(wrapperSeedVariant, directMetaWrapper, "bootstrap layout must vary across build seeds");
assert.equal(wrap("print(1)", { seed: 123, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" }), directMetaWrapper, "bootstrap layout must remain reproducible for a fixed seed");
if (resolveRuntime("lua")) {
  const wrapperSyntax = runSyntaxCheck(resolveRuntime("lua"), directMetaWrapper, "lua");
  assert.ok(wrapperSyntax.ok, wrapperSyntax.stderr || wrapperSyntax.error || "minified wrapper must parse");
  const wrapperRun = runProgram(resolveRuntime("lua"), directMetaWrapper, "lua");
  assert.ok(wrapperRun.ok, wrapperRun.stderr || wrapperRun.error || "minified wrapper must run");
  assert.equal(wrapperRun.stdout.trim(), "1");

  const topologySeeds = {};
  for (let candidate = 0; candidate < 48; candidate++) {
    const topology = createBootstrapPlan({ seed: candidate, backend: "register", body: "print(1)" }).topology;
    if (topologySeeds[topology] === undefined) topologySeeds[topology] = candidate;
  }
  assert.deepEqual(new Set(Object.keys(topologySeeds)), new Set(["trampoline-first", "entry-first"]), "both forwarding topologies must be reachable");
  for (const [topology, seed] of Object.entries(topologySeeds)) {
    const variant = wrap("print(1)", { seed, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
    const variantSyntax = runSyntaxCheck(resolveRuntime("lua"), variant, "lua");
    assert.ok(variantSyntax.ok, variantSyntax.stderr || variantSyntax.error || `${topology} bootstrap failed syntax validation`);
    const variantRun = runProgram(resolveRuntime("lua"), variant, "lua");
    assert.ok(variantRun.ok, variantRun.stderr || variantRun.error || `${topology} bootstrap failed execution`);
    assert.equal(variantRun.stdout.trim(), "1");
  }
}

// Minifier must preserve actual Lua/Luau token boundaries while removing layout.
const minifyFixture = [
  "-- ordinary comment is removed",
  "local value = 12",
  "local neg = - -value",
  "local concat = 1 .. 2",
  "local long = [=[line one\n-- this is literal text\nline three]=]",
  "print(value, neg, concat, long)"
].join("\n");
const minifiedFixture = minify(minifyFixture);
assert.doesNotMatch(minifiedFixture, /ordinary comment/);
assert.match(minifiedFixture, /- -value/, "two unary/minus tokens must not turn into a line comment");
assert.match(minifiedFixture, /1 \.\.2/, "number/concatenation boundary must stay lexically unambiguous");
assert.match(minifiedFixture, /\[=\[line one\n-- this is literal text\nline three\]=\]/, "long-bracket literal contents must remain byte-for-byte intact");
if (resolveRuntime("lua")) {
  const miniSyntax = runSyntaxCheck(resolveRuntime("lua"), minifiedFixture, "lua");
  assert.ok(miniSyntax.ok, miniSyntax.stderr || miniSyntax.error || "token-aware minifier output did not parse");
  const miniResult = runProgram(resolveRuntime("lua"), minifiedFixture, "lua");
  assert.ok(miniResult.ok, miniResult.stderr || miniResult.error || "token-aware minifier output did not run");
  assert.match(miniResult.stdout, /12\t12\t12/);
}

// Generated names must not directly encode the v5.x XORed seed or leak helper prefixes.
const generatedNameFixture = 'local _bvh_routeA=function(__value)return __value end;local _1namp50=3;local _gtsnqx=4;local mt=setmetatable({}, {__call=function(t,...)return t.__value end});return _bvh_routeA(_1namp50+_gtsnqx), "_bvh_routeA", _G';
const mangledGeneratedFixture = mangleGeneratedInternals(generatedNameFixture, 0x5600A11);
assert.doesNotMatch(mangledGeneratedFixture.replace(/"_bvh_routeA"/g, ""), /_bvh_|_1namp50|_gtsnqx|__value/);
assert.match(mangledGeneratedFixture, /__call=/, "Lua metamethod keys must not be renamed");
assert.match(mangledGeneratedFixture, /"_bvh_routeA"/, "string literal data must not be renamed");
assert.match(mangledGeneratedFixture, /_G/, "Lua environment globals must not be renamed");

// Decoy instructions now derive operands from the build seed as well as the index.
const decoyOptions = { opNames: ["PUSHN", "PUSHB", "JMP", "JZ"], encode: { PUSHN: 0, PUSHB: 1, JMP: 2, JZ: 3 }, depth: 24, mode: "stack" };
const decoyA = buildDecoyProgram({ ...decoyOptions, seed: 0x5600A12 });
const decoyB = buildDecoyProgram({ ...decoyOptions, seed: 0x5600A13 });
assert.notDeepEqual(decoyA.instructions, decoyB.instructions, "decoy operands and opcode selection must vary per build seed");
assert.notEqual(decoyA.fingerprint, decoyB.fingerprint, "decoy fingerprint must cover instruction contents");
assert.throws(() => buildDecoyProgram({ opNames: [], encode: {}, seed: 1, depth: 10 }), /no valid physical opcodes/);

const { encodeSynchronizedPayload } = require("./src/vm/veil_sync");
const syncFixture = encodeSynchronizedPayload(Buffer.from([0, 1, 2, 127, 128, 255]), [
  { id: "test-xor", encode: (b) => Buffer.from(b, (v) => v), decode: (b) => b }
]);
assert.equal(syncFixture.engine, "VeilSync-v2");
assert.equal(syncFixture.version, 2, "VeilSync runtime contract must report v2");
assert.equal(syncFixture.pipelineRoundTripVerified, true, "VeilSync must verify the composed pipeline");
assert.equal(syncFixture.roundTripsVerified, 1);
assert.deepEqual([...syncFixture.bytes], [0, 1, 2, 127, 128, 255]);
assert.throws(() => encodeSynchronizedPayload([1], [{ id: "bad", encode: () => [2], decode: () => [3] }]), /VeilSync round-trip failed/);

function expressionOf(source) {
  const ast = parse(source);
  assert.equal(ast.body.length, 1, source);
  assert.equal(ast.body[0].type, "Return", source);
  return ast.body[0].values[0];
}

// Lua operator precedence: power binds more tightly than unary; shifts are
// below addition; bitwise precedence levels are not collapsed together.
const negativePower = expressionOf("return -2^2");
assert.equal(negativePower.type, "Unary");
assert.equal(negativePower.op, "-");
assert.equal(negativePower.arg.type, "Binary");
assert.equal(negativePower.arg.op, "^");
assert.equal(expressionOf("return (-2)^2").op, "^");
const addBeforeShift = expressionOf("return 1+2<<3");
assert.equal(addBeforeShift.op, "<<");
assert.equal(addBeforeShift.left.type, "Binary");
assert.equal(addBeforeShift.left.op, "+");
const shiftBeforeAnd = expressionOf("return 1&2<<3");
assert.equal(shiftBeforeAnd.op, "&");
assert.equal(shiftBeforeAnd.right.op, "<<");
const addBeforeBitOr = expressionOf("return 1|2+3");
assert.equal(addBeforeBitOr.op, "|");
assert.equal(addBeforeBitOr.right.op, "+");
const powerRightAssoc = expressionOf("return 2^3^2");
assert.equal(powerRightAssoc.right.op, "^");

// The anti-hook builder no longer emits marketing/debug text as cleartext.
const anti = buildAntiHookSource({ prefix: "_test_guard", seed: 0x540A11, baselineFromEnvironment: true });
assert.doesNotMatch(anti.declaration, /Detected hook|Made by Meoz|Runtime error !|environment unavailable/i);
assert.doesNotMatch(anti.declaration, /runtime integrity check failed|runtime guard unavailable|\["type"\]|\["pcall"\]|then\s+error\s*\(/i);
assert.match(anti.declaration, /_test_guard_keys/);
assert.match(anti.declaration, /_test_guard_decode/);
assert.match(anti.declaration, /_test_guard_refs\[_test_guard_i\] = _test_guard_env\[__name\]/, "v5.4 captures its API baseline from decoded environment keys");
assert.doesNotMatch(anti.declaration, /\{type,\s*pcall,\s*pairs,\s*tostring,\s*select,\s*error\}/, "v5.4 should not emit a cleartext vector of the guarded APIs");
assert.equal(anti.metadata.antiHookReferenceBaseline, "decoded-environment-vector-v1");
assert.match(anti.declaration, /for _test_guard_i = 1/);
const antiOtherSeed = buildAntiHookSource({ prefix: "_test_guard", seed: 0xF0000001 });
assert.notEqual(anti.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], antiOtherSeed.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], "guard key representation should vary by seed");

// Diagnostic encoding preserves the runtime string value (Lua decimal escapes)
// and does not touch comments, long-bracket literals, or unrelated strings.
const comment = '-- "ByteVeil v4.6.3: tamper detected"\n';
const sample = `${comment}local diagnostic="ByteVeil v4.6.3: tamper detected"; local normal="hello"; local opaque=[=[ByteVeil v4.6.3: tamper detected]=]`;
const encoded = encodeDiagnosticStrings(sample);
assert.equal(encoded.encoded, 1);
assert.equal(encoded.errorCallsAliased, 0, "comments and strings without an error alias do not alter call sites");
assert.ok(encoded.source.startsWith(comment));
assert.doesNotMatch(encoded.source, /local diagnostic="ByteVeil v4\.6\.3: tamper detected"/);
assert.match(encoded.source, /local normal="hello"/);
assert.match(encoded.source, /opaque=\[\[?=\[ByteVeil v4\.6\.3: tamper detected\]=\]?\]/);

// The shadow-template mangler must rename locals without touching comments,
// literal contents, table keys, or field names. Use two seeds to catch stable aliases.
const shadowSnippet = '-- local VM is comment text\nlocal VM = { key = 3 }; local PLAN = function(I0) local VAL = I0 + VM.key; return VAL end; local txt = \"VM PLAN I0\"; return PLAN(4), VM.key, txt';
const mangledA = mangleLuaLocalIdentifiers(shadowSnippet, 0x540001);
const mangledB = mangleLuaLocalIdentifiers(shadowSnippet, 0x540002);
assert.notEqual(mangledA, shadowSnippet, "shadow local identifiers should be mangled");
assert.notEqual(mangledA, mangledB, "shadow locals should vary by build seed");
assert.match(mangledA, /-- local VM is comment text/);
assert.match(mangledA, /key\s*=/, "table keys must remain stable data keys");
assert.match(mangledA, /\.key/, "field accesses must remain unchanged");
assert.match(mangledA, /"VM PLAN I0"/, "literal contents must remain untouched");
assert.doesNotMatch(mangledA, /(?:^|[;\n])\s*local\s+(?:VM|PLAN|I0|VAL)\b/, "fixed shadow local names must be removed");
const stateKeysA = buildShadowStrings(0x540001, 24).slice(0, 8);
const stateKeysB = buildShadowStrings(0x540002, 24).slice(0, 8);
assert.equal(new Set(stateKeysA).size, 8, "shadow-state keys must not collide within a build");
assert.notDeepEqual(stateKeysA, stateKeysB, "shadow-state keys should vary by build seed");
assert.ok(stateKeysA.every((key) => !/^(?:pc|r|m|f|acc|tick|calls|ret)$/.test(key)), "new state keys must not retain fixed legacy field names");

const incompleteShadowNames = {
  code: "code", order: "order", handlers: "handlers", liveMap: "liveMap", init: "init", step: "step", proof: "proof", auth: "auth",
  semanticHandlers: "semanticHandlers", semanticProbe: "semanticProbe", proofSemanticProbe: "proofSemanticProbe", semanticPlans: "semanticPlans",
  vmState: "vmState", proofVmState: "proofVmState", sandboxNoop: "sandboxNoop", sandboxConst: "sandboxConst", sandboxResolve: "sandboxResolve",
  sandboxWrite: "sandboxWrite", sandboxRun: "sandboxRun", sandboxSuper: "sandboxSuper", semanticTrace: "semanticTrace", semanticDigest: "semanticDigest"
};
const incompleteShadowState = { consts: "consts", env: "env", pc: "pc", halt: "halt", ret: "ret", varargs: "varargs", iter: "iter", parent: "parent", locals: "locals", localSet: "localSet", reg: "reg" };
assert.throws(() => buildSemanticShadowVM({
  seed: 1, opNames: ["PUSHN", "DUP", "ADD", "SUB", "MUL", "EQ", "GETI", "SETI"],
  names: incompleteShadowNames, N: { mix: "mix", xor: "xor" }, S: incompleteShadowState, defs: {}, mode: "register",
  helpers: { state: "state", const: "const", resolveGlobal: "resolveGlobal", writeGlobal: "writeGlobal", run: "run", superFns: "superFns" }, version: "5.7.0"
}), /semantic shadow handlers missing for active ISA/, "build must fail immediately when active-ISA semantics are missing");

if (resolveRuntime("lua")) {
  const luaForMangler = resolveRuntime("lua");
  const original = runProgram(luaForMangler, shadowSnippet, "lua");
  const mangled = runProgram(luaForMangler, mangledA, "lua");
  assert.ok(original.ok, original.stderr || "original shadow-mangler fixture failed");
  assert.ok(mangled.ok, mangled.stderr || "mangled shadow-mangler fixture failed");
  assert.equal(mangled.stdout, original.stdout, "identifier mangling must preserve Lua semantics");
}

// Full generated output uses decimal escapes for runtime diagnostics while the
// visible release watermark (a comment) remains an intentional public marker.
const result = obfuscate("local value=2; return value^3", {
  mode: "stack", seed: 0x520052, wrapper: { enabled: false },
  transforms: { watermark: false }
});
assert.equal(result.vmMeta.version, "5.7.0");
assert.equal(result.vmMeta.encodingEngine, "VeilSync-v2");
assert.ok(result.vmMeta.regionCount > 0, "the sample must produce multiple independently encoded regions");
assert.equal(result.vmMeta.encodingRegionsVerified, result.vmMeta.regionCount, "every active region must complete build-time round-trip verification");
assert.equal(result.vmMeta.encodingPipelineRoundTripsVerified, result.vmMeta.regionCount, "every active region must verify the composed codec pipeline");
assert.equal(result.vmMeta.encodingRoundTripsVerified, result.vmMeta.regionCount * 3, "all three region stages must be verified per region");
assert.equal(result.vmMeta.payloadLayout, version.PAYLOAD_LAYOUT);
assert.ok(result.stats.diagnosticStringsEncoded > 0);
assert.ok(result.stats.diagnosticErrorCallsAliased > 0, "generated error calls should use the emitted local error alias");
assert.doesNotMatch(result.output, /Obfuscated source crash - runtime tamper detect/, "tamper diagnostic must be encoded in emitted output");
assert.match(encodeDiagnosticStrings('error("Obfuscated source crash - runtime tamper detect")').source, /\\079\\098\\102/, "diagnostic string encoder should escape the exact tamper message when it is emitted as a literal");
assert.doesNotMatch(result.output, /then\s+error\s*\(/i, "generated guards should not expose repeated `then error(...)` patterns");
assert.doesNotMatch(result.output, /\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]\s*~=\s*[^;\n]*\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]/i, "generated guard must not repeat string-keyed API-to-API comparisons");
assert.doesNotMatch(result.output, /Byte[Vv]eil v\d+\.\d+\.\d+: (?:instruction representation|runtime shield|tamper detected)/);
assert.doesNotMatch(result.output, /Detected hook|Made by Meoz|Runtime error !|ByteVeil environment unavailable|runtime integrity check failed|runtime guard unavailable/);
assert.doesNotMatch(result.output, /["\'](?:payload carrier alphabet|payload lane|payload integrity record|payload carrier missing|descriptor carrier missing|continuation miss)["\']/i, "recognizable payload diagnostics should not remain as plain string literals");
assert.ok(Buffer.byteLength(result.output, "utf8") <= 475000, "sample output respects release budget");

// The default user-facing preset must use the reset v5.7 callable bootstrap too.
const defaultPresetBuild = obfuscate('print("v57-default-preset")', {
  preset: "l1", mode: "register", target: "lua", seed: 0x5700A11
});
assert.equal(defaultPresetBuild.vmMeta.version, "5.7.0");
assert.match(defaultPresetBuild.output, /return setmetatable\(\{\[\d+\]=function\(/, "l1 must emit the v5.7 callable-object bootstrap, not legacy gsub wrapping");
assert.match(defaultPresetBuild.output, /ByteVeil Obfuscator v5\.7\.0/, "default preset watermark must match engine release version");
assert.doesNotMatch(defaultPresetBuild.output, /_bvh_|_1namp|_gtsnq/, "default preset must not expose legacy generated-name families");
if (resolveRuntime("lua")) {
  const defaultPresetRun = runProgram(resolveRuntime("lua"), defaultPresetBuild.output, "lua");
  assert.ok(defaultPresetRun.ok, defaultPresetRun.stderr || defaultPresetRun.error || "l1 bootstrap output failed to execute");
  assert.match(defaultPresetRun.stdout, /v57-default-preset/);
}

for (const mode of ["stack", "register"]) {
  const guardBuild = obfuscate("print(1+2)", {
    mode, seed: 0x530053 + (mode === "register" ? 1 : 0),
    wrapper: { enabled: false }, transforms: { watermark: false }
  });
  const guardOutput = guardBuild.output;
  assert.doesNotMatch(guardOutput, /_bvh_|_1namp|_gtsnq/, `${mode}: generated identifiers must not expose old seed-derived naming schemes`);
  assert.equal(guardBuild.stats.bodyOneLine, true, `${mode}: wrapper-disabled VM output should be a single minified line`);
  assert.equal(guardBuild.vmMeta.encodingEngine, "VeilSync-v2", `${mode}: active serializer must use VeilSync`);
  assert.ok(guardBuild.vmMeta.regionCount > 0, `${mode}: at least one payload region must be generated`);
  assert.equal(guardBuild.vmMeta.encodingRegionsVerified, guardBuild.vmMeta.regionCount, `${mode}: every region must be verified`);
  assert.equal(guardBuild.vmMeta.encodingPipelineRoundTripsVerified, guardBuild.vmMeta.regionCount, `${mode}: every pipeline must round-trip`);
  assert.equal(guardBuild.vmMeta.encodingRoundTripsVerified, guardBuild.vmMeta.regionCount * 3, `${mode}: every stage in every region must round-trip`);
  assert.doesNotMatch(guardOutput, /runtime integrity check failed|runtime guard unavailable/i, `${mode}: guard diagnostics should not remain plaintext`);
  assert.doesNotMatch(guardOutput, /\{type,\s*pcall,\s*pairs,\s*tostring,\s*select,\s*error\}/i, `${mode}: v5.5 anti-hook must not emit a cleartext API-reference vector`);
  assert.doesNotMatch(guardOutput, /bv_shadow_\d+/i, `${mode}: legacy shadow fingerprint must not be emitted`);
  assert.doesNotMatch(guardOutput, /\bSHADOW\.(?:pc|r|m|f|acc|tick|calls|ret)\b/i, `${mode}: fixed shadow-frame fields must not be emitted`);
  assert.doesNotMatch(guardOutput, /"ByteVeil"|\\"ByteVeil\\"/, `${mode}: fixed decoy string marker must not be emitted as a literal`);
  assert.doesNotMatch(guardOutput, /\blocal\s+(?:VM|PLAN|I0|VAL)\s*=/, `${mode}: common shadow locals must not survive template mangling`);
  assert.doesNotMatch(guardOutput, /\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]\s*~=\s*[^;\n]*\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]/i, `${mode}: no repeated string-keyed API comparisons`);
  assert.doesNotMatch(guardOutput, /then\s+error\s*\(/i, `${mode}: no direct then error call`);
  assert.ok(Buffer.byteLength(guardOutput, "utf8") <= 475000, `${mode}: output respects release budget`);
}

// Differential arithmetic regression: parser precedence and stack-depth
// validation must agree with the available native Lua runtime.
const lua = resolveRuntime("lua");
if (lua) {
  const wrappedRuntime = wrap('print("wrapper-ok")', { seed: 0x5500, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", argumentCount: 3 });
  const wrappedSyntax = runSyntaxCheck(lua, wrappedRuntime, "lua");
  assert.ok(wrappedSyntax.ok, wrappedSyntax.stderr || "direct-return setmetatable wrapper syntax failed");
  const wrappedResult = runProgram(lua, wrappedRuntime, "lua");
  assert.ok(wrappedResult.ok, wrappedResult.stderr || "direct-return setmetatable wrapper runtime failed");
  assert.equal(wrappedResult.stdout.trim(), "wrapper-ok");

  const guardSuccess = `${anti.declaration}\n${anti.checkCall}\nprint("guard-ok")`;
  const guardSuccessResult = runProgram(lua, guardSuccess, "lua");
  assert.ok(guardSuccessResult.ok, guardSuccessResult.stderr || "generated guard should pass in a clean Lua environment");
  assert.equal(guardSuccessResult.stdout.trim(), "guard-ok");

  const setmetaAnti = buildAntiHookSource({ prefix: "__v550_tamper", seed: 0x550A11, baselineFromEnvironment: true });
  const setmetaTamper = `${setmetaAnti.declaration}\nsetmetatable=function() return nil end\nlocal __ok,__message=pcall(function() ${setmetaAnti.checkCall} end)\nprint(__ok, __message)`;
  const setmetaTamperResult = runProgram(lua, setmetaTamper, "lua");
  assert.ok(setmetaTamperResult.ok, setmetaTamperResult.stderr || "setmetatable tamper fixture should run");
  assert.match(setmetaTamperResult.stdout, /false\s+Obfuscated source crash - runtime tamper detect/, "setmetatable replacement must fail closed with the required message");

  const changedApi = `${anti.declaration}\nlocal __original_tostring = tostring\ntostring = function(v) return __original_tostring(v) end\nlocal __ok = pcall(function() ${anti.checkCall} end)\ntostring = __original_tostring\nprint(__ok)`;
  const changedApiResult = runProgram(lua, changedApi, "lua");
  assert.ok(changedApiResult.ok, changedApiResult.stderr || "mutated API guard fixture should run");
  assert.equal(changedApiResult.stdout.trim(), "false", "generated guard must still detect API replacement after startup");

  const originalDiagnostic = 'local ok, message = pcall(function() error("ByteVeil v4.6.3: tamper detected", 0) end); print(message)';
  const encodedDiagnostic = encodeDiagnosticStrings(originalDiagnostic).source;
  const diagnosticOriginalResult = runProgram(lua, originalDiagnostic, "lua");
  const diagnosticEncodedResult = runProgram(lua, encodedDiagnostic, "lua");
  assert.ok(diagnosticOriginalResult.ok, diagnosticOriginalResult.stderr || "original diagnostic fixture failed");
  assert.ok(diagnosticEncodedResult.ok, diagnosticEncodedResult.stderr || "encoded diagnostic fixture failed");
  assert.equal(diagnosticEncodedResult.stdout, diagnosticOriginalResult.stdout, "encoded diagnostics must preserve the actual runtime string");

  const arithmetic = "print(-2^2,(-2)^2,2^3^2,2^-3,(1+2)<<3,1|(2+3),1&(2<<3))";
  const nativeResult = runProgram(lua, arithmetic, "lua");
  assert.ok(nativeResult.ok, nativeResult.stderr || "native arithmetic fixture failed");
  for (const mode of ["stack", "register"]) {
    const protectedArithmetic = obfuscate(arithmetic, {
      mode, seed: 0x520053 + (mode === "register" ? 1 : 0), wrapper: { enabled: false },
      transforms: { watermark: false }
    });
    const syntax = runSyntaxCheck(lua, protectedArithmetic.output, "lua");
    assert.ok(syntax.ok, syntax.stderr || syntax.error || `${mode} arithmetic syntax failed`);
    const protectedResult = runProgram(lua, protectedArithmetic.output, "lua");
    assert.ok(protectedResult.ok, protectedResult.stderr || `${mode} protected arithmetic fixture failed`);
    assert.equal(protectedResult.stdout, nativeResult.stdout, `${mode} VM arithmetic should match native Lua for precedence fixture`);
  }


  // Luau `continue` must take the correct loop-specific edge: condition for
  // while, condition after the body for repeat, and update/iterator for for-loops.
  const continueFixtures = [
    ["numeric-for", "local n=0; for i=1,5 do if i==2 then continue end; n+=i end; print(n)", "local n=0; for i=1,5 do if i~=2 then n=n+i end end; print(n)"],
    ["while", "local i=0; local n=0; while i<5 do i+=1; if i==2 then continue end; n+=i end; print(n)", "local i=0; local n=0; while i<5 do i=i+1; if i~=2 then n=n+i end end; print(n)"],
    ["repeat", "local i=0; local n=0; repeat i+=1; if i==2 then continue end; n+=i until i>=5; print(n)", "local i=0; local n=0; repeat i=i+1; if i~=2 then n=n+i end until i>=5; print(n)"],
    ["generic-for", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k==2 then continue end; n+=v end; print(n)", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k~=2 then n=n+v end end; print(n)"],
    ["nested-loop", "local n=0; for i=1,3 do for j=1,3 do if j==2 then continue end; n+=1 end end; print(n)", "local n=0; for i=1,3 do for j=1,3 do if j~=2 then n=n+1 end end end; print(n)"],
  ];
  for (const [name, source, reference] of continueFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} reference fixture failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52100 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} output syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} continue semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate("continue", { mode: "stack", target: "lua", wrapper: { enabled: false } }), /continue outside loop/i);

  // Luau backtick strings are lowered into concat/tostring AST nodes. Compare
  // VM output against equivalent ordinary Lua instead of feeding backticks to Lua 5.3.
  const interpolationFixtures = [
    ["basic", 'local name="Luau"; print(`Hello {name}!`)', 'local name="Luau"; print("Hello " .. tostring(name) .. "!")'],
    ["expressions", 'print(`{1 + 2} {true} {nil}`)', 'print(tostring(1 + 2) .. " " .. tostring(true) .. " " .. tostring(nil))'],
    ["escaped-braces", 'print(`Some example \\{like so\\}`)', 'print("Some example {like so}")'],
    ["quoted-brace", 'print(`a {select(1, "}", 3)} b`)', 'print("a " .. tostring(select(1, "}", 3)) .. " b")'],
    ["unicode-escape", 'local s="雪"; print(`💬 {s} \\u{1F600}`)', 'local s="雪"; print("💬 " .. tostring(s) .. " 😀")'],
    ["escaped-backtick", 'print(`tick: \\` ok`)', 'print("tick: ` ok")'],
  ];
  for (const [name, source, reference] of interpolationFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} interpolation reference failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52200 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} interpolation syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} interpolation runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} interpolation semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate('print(`{{`)', { mode: "stack", target: "lua", wrapper: { enabled: false } }), /interpolation|parser error/i);
}

if (resolveRuntime("lua")) {
  const nested = obfuscate('print("nest-ok", 2+3)', { target: "lua", preset: "nest", mode: "stack", seed: 0x55AA, wrapper: { enabled: false }, transforms: { watermark: false } });
  assert.equal(nested.vmMeta.nestedSourceEngine, "legacy-wrapSource-v4.7.4");
  assert.equal(nested.vmMeta.nestedObfuscationLayers, 5);
  assert.equal(nested.vmMeta.nestedRequiresDynamicLoader, true);
  const nestedSyntax = runSyntaxCheck(resolveRuntime("lua"), nested.output, "lua");
  assert.ok(nestedSyntax.ok, nestedSyntax.stderr || "Nest preset syntax failed");
  const nestedRun = runProgram(resolveRuntime("lua"), nested.output, "lua");
  assert.ok(nestedRun.ok, nestedRun.stderr || "Nest preset runtime failed");
  assert.equal(nestedRun.stdout.trim(), "nest-ok\t5");
}

console.log(`ByteVeil v5.7.0 focused regressions: PASS (Lua precedence, continue loop edges, Luau interpolation, VeilSync, tamper guard, wrapper, Nest preset, output=${Buffer.byteLength(result.output, "utf8")} bytes)`);

"use strict";

const assert = require("node:assert/strict");
const packageInfo = require("./package.json");
const version = require("./src/core/version");
const { parse } = require("./src/frontend/parser");
const { encodeDiagnosticStrings } = require("./src/utils/diagnostic_string_encoder");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const { obfuscate } = require("./src");
const { findBlobLiterals, stripBlobLiterals, BLOB_MARKER } = require("./src/obfuscation/veil_blob");
const { mangleLuaLocalIdentifiers, buildShadowStrings, buildSemanticShadowVM } = require("./src/protection/live_shadow_vm");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

assert.equal(packageInfo.version, "5.9.0");
assert.equal(version.PAYLOAD_LAYOUT, "position-keyed-striped-payload-lanes-packed-descriptor-lazy-region-v5.9-shared-shadow-dispatch-core-callable-bootstrap-region-verified");
assert.equal(version.ENGINE_VERSION, packageInfo.version);
const { buildProtectionPlan } = require("./src/protection/byte_blinder");
const protectionPlan = buildProtectionPlan({ version: "5.8.0", seed: 0x580001, mode: "stack" });
assert.equal(protectionPlan.protectionIR, "v4.6-architecture-graph-micro", "v5.8 should retain the existing protection IR profile");
assert.equal(protectionPlan.realRepresentationMorphing, true, "v5.8 must report the inherited representation-morphing path accurately");
assert.equal(protectionPlan.buildSpecificArchitecture, true, "v5.8 must report seed-specific architecture accurately");
assert.equal(protectionPlan.runtimeGeneratedSemanticVM, true, "v5.8 must report the generated semantic VM path accurately");
const { getPreset } = require("./src/presets");
// `legacy-wrapSource-v4.7.4` is emitted by the engine into vmMeta/stats for every nest
// build; it was never selectable, and the preset key was proven byte-inert, so the closed
// option registry now refuses it as an input. Assert both halves of that contract.
assert.equal(getPreset("nest").nestedSourceEngine, undefined);
assert.equal(getPreset("nest").nestedProfile, undefined);
assert.throws(() => obfuscate("print(1)", { preset: "l1", nestedSourceEngine: "legacy-wrapSource-v4.7.4" }), /nestedSourceEngine is not implemented/);
assert.throws(() => obfuscate("print(1)", { preset: "l1", nestedProfile: "full" }), /nestedProfile is not implemented/);
assert.ok(getPreset("nest").strength > getPreset("l2").strength && getPreset("nest").strength < getPreset("df").strength, "Nest preset belongs between l2 and df strength");

const { wrap, minify } = require("./src/wrappers/WrapInFunction");
const { createBootstrapPlan, renderCallableBootstrap } = require("./src/wrappers/bootstrap_renderer");
const { mangleGeneratedInternals } = require("./src/utils/lua_identifier_rewriter");
const { buildDecoyProgram } = require("./src/protection/decoy_compiler");
const directMetaWrapper = wrap("print(1)", { seed: 123, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
assert.ok(directMetaWrapper.startsWith("return setmetatable({"), "wrapper must begin with direct return setmetatable");
assert.match(directMetaWrapper, /^return setmetatable\(\{\[\d+\]=function\(/, "v5.8 bootstrap must begin with a numeric runtime slot");
const wrapperSlots = [...directMetaWrapper.matchAll(/\[(\d+)\]=function\(/g)].map((match) => Number(match[1]));
assert.equal(wrapperSlots.length, 3, "callable bootstrap must expose body, dispatch, and entry slots");
assert.equal(new Set(wrapperSlots).size, wrapperSlots.length, "bootstrap slots must be unique per build");
assert.match(directMetaWrapper, /__call=function\(/, "callable bootstrap needs an explicit __call dispatch");
assert.ok(directMetaWrapper.includes(`return `) && directMetaWrapper.includes("(...)") , "dispatch path must forward the full vararg tuple");
assert.doesNotMatch(directMetaWrapper, /^do\s+return setmetatable/);
assert.doesNotMatch(directMetaWrapper, /\nend\s*$/);
assert.doesNotMatch(directMetaWrapper, /[\r\n]/, "wrapper output should be minified at the wrapper boundary");
const bodySlotMatch = directMetaWrapper.match(/\[(\d+)\]=function\(([^)]*)\)print\(1\)end/);
assert.ok(bodySlotMatch, "bootstrap must keep the program body in its own entry function");
const wrapperArgs = bodySlotMatch[2];
// The wrapper tail is seed-selected: `callable-object` invokes the bootstrap table
// through `__call`, `colon-dispatch` invokes an identifier-keyed pre-flight method that
// returns the trampoline. Both must forward the chunk-level vararg tuple.
const directMetaShape = createBootstrapPlan({ seed: 123, backend: "register", body: "print(1)" }).shape;
const colonMethodName = /}\):([A-Za-z_][A-Za-z0-9_]*)\(\)/.exec(directMetaWrapper)?.[1];
if (directMetaShape === "colon-dispatch") {
  assert.ok(colonMethodName, "colon-dispatch bootstrap must end by calling its pre-flight method");
  assert.ok(directMetaWrapper.endsWith(`):${colonMethodName}()(...)`), "colon dispatch must forward the chunk-level vararg tuple to the returned trampoline");
  assert.ok(directMetaWrapper.includes("__metatable=false,"), "colon bootstrap must keep the metatable lock");
} else {
  assert.ok(!colonMethodName, "callable-object bootstrap must not emit a colon tail");
  assert.ok(directMetaWrapper.endsWith(`})(${wrapperArgs})`), "wrapper invocation must use its matching bridge arguments rather than illegal chunk-level varargs");
}
const wrapperSeedVariant = wrap("print(1)", { seed: 124, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
assert.notEqual(wrapperSeedVariant, directMetaWrapper, "bootstrap layout must vary across build seeds");
assert.equal(wrap("print(1)", { seed: 123, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" }), directMetaWrapper, "bootstrap layout must remain reproducible for a fixed seed");
if (resolveRuntime("lua")) {
  const wrapperSyntax = runSyntaxCheck(resolveRuntime("lua"), directMetaWrapper, "lua");
  assert.ok(wrapperSyntax.ok, wrapperSyntax.stderr || wrapperSyntax.error || "minified wrapper must parse");
  const wrapperRun = runProgram(resolveRuntime("lua"), directMetaWrapper, "lua");
  assert.ok(wrapperRun.ok, wrapperRun.stderr || wrapperRun.error || "minified wrapper must run");
  assert.equal(wrapperRun.stdout.trim(), "1");

  const topologySeeds = {};
  for (let candidate = 0; candidate < 48; candidate++) {
    const topology = createBootstrapPlan({ seed: candidate, backend: "register", body: "print(1)" }).topology;
    if (topologySeeds[topology] === undefined) topologySeeds[topology] = candidate;
  }
  assert.deepEqual(new Set(Object.keys(topologySeeds)), new Set(["trampoline-first", "entry-first"]), "both forwarding topologies must be reachable");
  for (const [topology, seed] of Object.entries(topologySeeds)) {
    const variant = wrap("print(1)", { seed, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", backend: "register" });
    const variantSyntax = runSyntaxCheck(resolveRuntime("lua"), variant, "lua");
    assert.ok(variantSyntax.ok, variantSyntax.stderr || variantSyntax.error || `${topology} bootstrap failed syntax validation`);
    const variantRun = runProgram(resolveRuntime("lua"), variant, "lua");
    assert.ok(variantRun.ok, variantRun.stderr || variantRun.error || `${topology} bootstrap failed execution`);
    assert.equal(variantRun.stdout.trim(), "1");
  }
}

// v5.9 wrapper tails. Both shapes must be reachable from the seed, both must execute on
// Lua 5.4 and Luau, and the colon-dispatch pre-flight stage must be load-bearing: every
// mutation below is measured against a real runtime, so a build that loses the stage, the
// stage call, or a native-ref pool entry aborts before the payload decodes.
{
  const shapeSeeds = {};
  for (let candidate = 0; candidate < 64; candidate++) {
    const shape = createBootstrapPlan({ seed: candidate, backend: "register", body: "print(1)" }).shape;
    if (shapeSeeds[shape] === undefined) shapeSeeds[shape] = candidate;
  }
  assert.deepEqual(Object.keys(shapeSeeds).sort(), ["callable-object", "colon-dispatch"], "both wrapper tails must be reachable across build seeds");

  const colonSeed = shapeSeeds["colon-dispatch"];
  const callableSeed = shapeSeeds["callable-object"];
  const colonRender = renderCallableBootstrap("local a=10 local b=20 print(a+b)", {
    seed: colonSeed, backend: "register", wrapperShape: "colon-dispatch"
  });
  const colonPlan = colonRender.plan;
  const colonSource = minify(colonRender.source);
  const methodName = colonPlan.locals.method;
  const poolName = colonPlan.locals.pool;
  assert.equal(colonPlan.shape, "colon-dispatch", "explicit shape request must be honoured");
  assert.ok(colonSource.endsWith(`):${methodName}()(...)`), "colon build must dispatch through the pre-flight method");
  assert.ok(colonSource.includes(`${poolName}={type,error,select,string.sub,string.byte,math.floor,table.concat,pairs}`), "colon build must emit the native-ref pool");
  assert.ok(colonSource.includes(`${colonPlan.locals.self}.${poolName}=nil`), "the native-ref pool must be wiped with the other bindings");
  assert.ok(minify(renderCallableBootstrap("print(1)", { seed: callableSeed, backend: "register" }).source).includes("})(...)"), "callable-object build must keep the v5.8 tail");

  const stageStart = colonSource.indexOf(`,${methodName}=function(`);
  const stageEnd = colonSource.indexOf(",{__call=function(");
  assert.ok(stageStart > 0 && stageEnd > stageStart, "colon pre-flight stage must sit before the metatable");
  const colonMutations = {
    "delete pre-flight stage": colonSource.slice(0, stageStart) + colonSource.slice(stageEnd),
    "delete colon call": colonSource.replace(`):${methodName}()`, ")"),
    "invoke through __call only": colonSource.replace(`):${methodName}()(...)`, ")(...)"),
    "swap pool entry 6": colonSource.replace(`${poolName}={type,error,select,string.sub,string.byte,math.floor`, `${poolName}={type,error,select,string.sub,string.byte,math.ceil`),
    "truncate pool": colonSource.replace(",table.concat,pairs}", ",table.concat}"),
    "state seed off by one": colonSource.replace(new RegExp(`\\[${colonPlan.slots.state}\\]=${colonPlan.crypto.initSeed}`), `[${colonPlan.slots.state}]=${colonPlan.crypto.initSeed + 1}`)
  };
  for (const rtName of ["lua", "luau"]) {
    const rt = resolveRuntime(rtName);
    if (!rt) continue;
    const baseline = runProgram(rt, colonSource, rtName);
    assert.ok(baseline.ok, `${rtName}: colon-dispatch bootstrap must run: ${baseline.stderr || baseline.error}`);
    assert.equal(baseline.stdout.trim(), "30", `${rtName}: colon-dispatch bootstrap changed program semantics`);
    for (const [label, text] of Object.entries(colonMutations)) {
      assert.notEqual(text, colonSource, `${rtName}: ${label} mutation needle must apply`);
      const mutated = runProgram(rt, text, rtName);
      assert.equal(mutated.ok, false, `${rtName}: ${label} must fail closed on the colon-dispatch tail`);
    }

    // Same proof on a coupled VM build, where the method name is generated and then
    // mangled: dropping the colon call, or the stage field it calls, must abort.
    const pipeBuild = obfuscate("local a=10 local b=20 print(a+b)", { preset: "l1", target: rtName === "luau" ? "luau" : "lua", seed: colonSeed, wrapper: { shape: "colon-dispatch" } });
    assert.equal(pipeBuild.vmMeta.wrapper.shape, "colon-dispatch", `${rtName}: pipeline build must report the tail it emitted`);
    assert.equal(pipeBuild.vmMeta.wrapper.requested, "colon-dispatch", `${rtName}: the requested tail must be reported`);
    const pipeText = pipeBuild.output.trim();
    const pipeMethod = /}\):([A-Za-z_][A-Za-z0-9_]*)\(\)\(\.\.\.\)$/.exec(pipeText);
    assert.ok(pipeMethod, `${rtName}: pipeline colon build must end with its pre-flight call`);
    const pipeBaseline = runProgram(rt, pipeBuild.output, rtName);
    assert.ok(pipeBaseline.ok, `${rtName}: pipeline colon build must run: ${pipeBaseline.stderr || pipeBaseline.error}`);
    assert.equal(pipeBaseline.stdout.trim(), "30", `${rtName}: pipeline colon build changed VM semantics`);
    const callRemoved = pipeText.replace(`):${pipeMethod[1]}()(`, ")((");
    assert.notEqual(callRemoved, pipeText, `${rtName}: pipeline colon-call needle must apply`);
    assert.equal(runProgram(rt, callRemoved, rtName).ok, false, `${rtName}: removing the colon call from a coupled build must fail closed`);
    const metaStart = pipeText.indexOf(",{__call=function(");
    const fieldStart = pipeText.lastIndexOf(`,${pipeMethod[1]}=function(`, metaStart);
    assert.ok(fieldStart > 0 && metaStart > fieldStart, `${rtName}: pipeline pre-flight stage must sit before the metatable`);
    const stageRemoved = pipeText.slice(0, fieldStart) + pipeText.slice(metaStart);
    assert.notEqual(stageRemoved, pipeText, `${rtName}: pipeline stage-field needle must apply`);
    assert.equal(runProgram(rt, stageRemoved, rtName).ok, false, `${rtName}: deleting the pre-flight stage from a coupled build must fail closed`);
  }
}

// Minifier must preserve actual Lua/Luau token boundaries while removing layout.
const minifyFixture = [
  "-- ordinary comment is removed",
  "local value = 12",
  "local neg = - -value",
  "local concat = 1 .. 2",
  "local long = [=[line one\n-- this is literal text\nline three]=]",
  "print(value, neg, concat, long)"
].join("\n");
const minifiedFixture = minify(minifyFixture);
assert.doesNotMatch(minifiedFixture, /ordinary comment/);
assert.match(minifiedFixture, /- -value/, "two unary/minus tokens must not turn into a line comment");
assert.match(minifiedFixture, /1 \.\.2/, "number/concatenation boundary must stay lexically unambiguous");
assert.match(minifiedFixture, /\[=\[line one\n-- this is literal text\nline three\]=\]/, "long-bracket literal contents must remain byte-for-byte intact");
if (resolveRuntime("lua")) {
  const miniSyntax = runSyntaxCheck(resolveRuntime("lua"), minifiedFixture, "lua");
  assert.ok(miniSyntax.ok, miniSyntax.stderr || miniSyntax.error || "token-aware minifier output did not parse");
  const miniResult = runProgram(resolveRuntime("lua"), minifiedFixture, "lua");
  assert.ok(miniResult.ok, miniResult.stderr || miniResult.error || "token-aware minifier output did not run");
  assert.match(miniResult.stdout, /12\t12\t12/);
}

// Generated names must not directly encode the v5.x XORed seed or leak helper prefixes.
const generatedNameFixture = 'local _bvh_routeA=function(__value)return __value end;local _1namp50=3;local _gtsnqx=4;local mt=setmetatable({}, {__call=function(t,...)return t.__value end});return _bvh_routeA(_1namp50+_gtsnqx), "_bvh_routeA", _G';
const mangledGeneratedFixture = mangleGeneratedInternals(generatedNameFixture, 0x5600A11);
assert.doesNotMatch(mangledGeneratedFixture.replace(/"_bvh_routeA"/g, ""), /_bvh_|_1namp50|_gtsnqx|__value/);
assert.match(mangledGeneratedFixture, /__call=/, "Lua metamethod keys must not be renamed");
assert.match(mangledGeneratedFixture, /"_bvh_routeA"/, "string literal data must not be renamed");
assert.match(mangledGeneratedFixture, /_G/, "Lua environment globals must not be renamed");

// Decoy instructions now derive operands from the build seed as well as the index.
const decoyOptions = { opNames: ["PUSHN", "PUSHB", "JMP", "JZ"], encode: { PUSHN: 0, PUSHB: 1, JMP: 2, JZ: 3 }, depth: 24, mode: "stack" };
const decoyA = buildDecoyProgram({ ...decoyOptions, seed: 0x5600A12 });
const decoyB = buildDecoyProgram({ ...decoyOptions, seed: 0x5600A13 });
assert.notDeepEqual(decoyA.instructions, decoyB.instructions, "decoy operands and opcode selection must vary per build seed");
assert.notEqual(decoyA.fingerprint, decoyB.fingerprint, "decoy fingerprint must cover instruction contents");
assert.throws(() => buildDecoyProgram({ opNames: [], encode: {}, seed: 1, depth: 10 }), /no valid physical opcodes/);

const { encodeSynchronizedPayload } = require("./src/vm/veil_sync");
const syncFixture = encodeSynchronizedPayload(Buffer.from([0, 1, 2, 127, 128, 255]), [
  { id: "test-xor", encode: (b) => Buffer.from(b, (v) => v), decode: (b) => b }
]);
assert.equal(syncFixture.engine, "VeilSync-v2");
assert.equal(syncFixture.version, 2, "VeilSync runtime contract must report v2");
assert.equal(syncFixture.pipelineRoundTripVerified, true, "VeilSync must verify the composed pipeline");
assert.equal(syncFixture.roundTripsVerified, 1);
assert.deepEqual([...syncFixture.bytes], [0, 1, 2, 127, 128, 255]);
assert.throws(() => encodeSynchronizedPayload([1], [{ id: "bad", encode: () => [2], decode: () => [3] }]), /VeilSync round-trip failed/);

function expressionOf(source) {
  const ast = parse(source);
  assert.equal(ast.body.length, 1, source);
  assert.equal(ast.body[0].type, "Return", source);
  return ast.body[0].values[0];
}

// Lua operator precedence: power binds more tightly than unary; shifts are
// below addition; bitwise precedence levels are not collapsed together.
const negativePower = expressionOf("return -2^2");
assert.equal(negativePower.type, "Unary");
assert.equal(negativePower.op, "-");
assert.equal(negativePower.arg.type, "Binary");
assert.equal(negativePower.arg.op, "^");
assert.equal(expressionOf("return (-2)^2").op, "^");
const addBeforeShift = expressionOf("return 1+2<<3");
assert.equal(addBeforeShift.op, "<<");
assert.equal(addBeforeShift.left.type, "Binary");
assert.equal(addBeforeShift.left.op, "+");
const shiftBeforeAnd = expressionOf("return 1&2<<3");
assert.equal(shiftBeforeAnd.op, "&");
assert.equal(shiftBeforeAnd.right.op, "<<");
const addBeforeBitOr = expressionOf("return 1|2+3");
assert.equal(addBeforeBitOr.op, "|");
assert.equal(addBeforeBitOr.right.op, "+");
const powerRightAssoc = expressionOf("return 2^3^2");
assert.equal(powerRightAssoc.right.op, "^");

// The anti-hook builder no longer emits marketing/debug text as cleartext.
const anti = buildAntiHookSource({ prefix: "_test_guard", seed: 0x540A11, baselineFromEnvironment: true });
assert.doesNotMatch(anti.declaration, /Detected hook|Made by Meoz|Runtime error !|environment unavailable/i);
assert.doesNotMatch(anti.declaration, /runtime integrity check failed|runtime guard unavailable|\["type"\]|\["pcall"\]|then\s+error\s*\(/i);
assert.match(anti.declaration, /_test_guard_keys/);
assert.match(anti.declaration, /_test_guard_decode/);
assert.match(anti.declaration, /_test_guard_refs\[_test_guard_i\] = _test_guard_env\[__name\]/, "v5.4 captures its API baseline from decoded environment keys");
assert.doesNotMatch(anti.declaration, /\{type,\s*pcall,\s*pairs,\s*tostring,\s*select,\s*error\}/, "v5.4 should not emit a cleartext vector of the guarded APIs");
assert.equal(anti.metadata.antiHookReferenceBaseline, "decoded-environment-vector-v1");
assert.match(anti.declaration, /for _test_guard_i = 1/);
const antiOtherSeed = buildAntiHookSource({ prefix: "_test_guard", seed: 0xF0000001 });
assert.notEqual(anti.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], antiOtherSeed.declaration.match(/local _test_guard_keys = (\{.*\})/s)?.[1], "guard key representation should vary by seed");

// Diagnostic encoding preserves the runtime string value (Lua decimal escapes)
// and does not touch comments, long-bracket literals, or unrelated strings.
const comment = '-- "ByteVeil v4.6.3: tamper detected"\n';
const sample = `${comment}local diagnostic="ByteVeil v4.6.3: tamper detected"; local normal="hello"; local opaque=[=[ByteVeil v4.6.3: tamper detected]=]`;
const encoded = encodeDiagnosticStrings(sample);
assert.equal(encoded.encoded, 1);
assert.equal(encoded.errorCallsAliased, 0, "comments and strings without an error alias do not alter call sites");
assert.ok(encoded.source.startsWith(comment));
assert.doesNotMatch(encoded.source, /local diagnostic="ByteVeil v4\.6\.3: tamper detected"/);
const diagnosticSweepTerms = ["descriptor header", "descriptor truncated", "payload address", "payload address bounds", "region integrity", "region opcode route", "graph cycle", "state machine miss", "constant state", "parameter state"];
const diagnosticSweep = encodeDiagnosticStrings(diagnosticSweepTerms.map((term) => `error(${JSON.stringify(term)})`).join(";"));
assert.equal(diagnosticSweep.encoded, diagnosticSweepTerms.length, "v5.8 should encode the runtime diagnostic families observed in v5.7 output");
for (const term of diagnosticSweepTerms) assert.ok(!diagnosticSweep.source.includes(JSON.stringify(term)), `diagnostic should not remain as a plain literal: ${term}`);
assert.match(encoded.source, /local normal="hello"/);
assert.match(encoded.source, /opaque=\[\[?=\[ByteVeil v4\.6\.3: tamper detected\]=\]?\]/);

// The shadow-template mangler must rename locals without touching comments,
// literal contents, table keys, or field names. Use two seeds to catch stable aliases.
const shadowSnippet = '-- local VM is comment text\nlocal VM = { key = 3 }; local PLAN = function(I0) local VAL = I0 + VM.key; return VAL end; local txt = \"VM PLAN I0\"; return PLAN(4), VM.key, txt';
const mangledA = mangleLuaLocalIdentifiers(shadowSnippet, 0x540001);
const mangledB = mangleLuaLocalIdentifiers(shadowSnippet, 0x540002);
assert.notEqual(mangledA, shadowSnippet, "shadow local identifiers should be mangled");
assert.notEqual(mangledA, mangledB, "shadow locals should vary by build seed");
assert.match(mangledA, /-- local VM is comment text/);
assert.match(mangledA, /key\s*=/, "table keys must remain stable data keys");
assert.match(mangledA, /\.key/, "field accesses must remain unchanged");
assert.match(mangledA, /"VM PLAN I0"/, "literal contents must remain untouched");
assert.doesNotMatch(mangledA, /(?:^|[;\n])\s*local\s+(?:VM|PLAN|I0|VAL)\b/, "fixed shadow local names must be removed");
const stateKeysA = buildShadowStrings(0x540001, 24).slice(0, 8);
const stateKeysB = buildShadowStrings(0x540002, 24).slice(0, 8);
assert.equal(new Set(stateKeysA).size, 8, "shadow-state keys must not collide within a build");
assert.notDeepEqual(stateKeysA, stateKeysB, "shadow-state keys should vary by build seed");
assert.ok(stateKeysA.every((key) => !/^(?:pc|r|m|f|acc|tick|calls|ret)$/.test(key)), "new state keys must not retain fixed legacy field names");

const incompleteShadowNames = {
  code: "code", order: "order", handlers: "handlers", liveMap: "liveMap", init: "init", step: "step", proof: "proof", auth: "auth",
  semanticHandlers: "semanticHandlers", semanticProbe: "semanticProbe", proofSemanticProbe: "proofSemanticProbe", semanticPlans: "semanticPlans",
  vmState: "vmState", proofVmState: "proofVmState", sandboxNoop: "sandboxNoop", sandboxConst: "sandboxConst", sandboxResolve: "sandboxResolve",
  sandboxWrite: "sandboxWrite", sandboxRun: "sandboxRun", sandboxSuper: "sandboxSuper", semanticTrace: "semanticTrace", semanticDigest: "semanticDigest"
};
const incompleteShadowState = { consts: "consts", env: "env", pc: "pc", halt: "halt", ret: "ret", varargs: "varargs", iter: "iter", parent: "parent", locals: "locals", localSet: "localSet", reg: "reg" };
assert.throws(() => buildSemanticShadowVM({
  seed: 1, opNames: ["PUSHN", "DUP", "ADD", "SUB", "MUL", "EQ", "GETI", "SETI"],
  names: incompleteShadowNames, N: { mix: "mix", xor: "xor" }, S: incompleteShadowState, defs: {}, mode: "register",
  helpers: { state: "state", const: "const", resolveGlobal: "resolveGlobal", writeGlobal: "writeGlobal", run: "run", superFns: "superFns" }, version: "5.8.0"
}), /semantic shadow handlers missing for active ISA/, "build must fail immediately when active-ISA semantics are missing");

if (resolveRuntime("lua")) {
  const luaForMangler = resolveRuntime("lua");
  const original = runProgram(luaForMangler, shadowSnippet, "lua");
  const mangled = runProgram(luaForMangler, mangledA, "lua");
  assert.ok(original.ok, original.stderr || "original shadow-mangler fixture failed");
  assert.ok(mangled.ok, mangled.stderr || "mangled shadow-mangler fixture failed");
  assert.equal(mangled.stdout, original.stdout, "identifier mangling must preserve Lua semantics");
}

// Full generated output uses decimal escapes for runtime diagnostics while the
// visible release watermark (a comment) remains an intentional public marker.
const result = obfuscate("local value=2; return value^3", {
  mode: "stack", seed: 0x520052, wrapper: { enabled: false },
  transforms: { watermark: false }
});
assert.equal(result.vmMeta.version, "5.9.0");
assert.equal(result.vmMeta.shadowArchitecture, "semantic-handler-sandbox-v59-shared-dispatch-core-veilsync-v2-region-verified");
assert.equal(result.vmMeta.encodingEngine, "VeilSync-v2");
assert.ok(result.vmMeta.regionCount > 0, "the sample must produce multiple independently encoded regions");
assert.equal(result.vmMeta.encodingRegionsVerified, result.vmMeta.regionCount, "every active region must complete build-time round-trip verification");
assert.equal(result.vmMeta.encodingPipelineRoundTripsVerified, result.vmMeta.regionCount, "every active region must verify the composed codec pipeline");
assert.equal(result.vmMeta.encodingRoundTripsVerified, result.vmMeta.regionCount * 3, "all three region stages must be verified per region");
assert.equal(result.vmMeta.payloadLayout, version.PAYLOAD_LAYOUT);
assert.ok(result.stats.diagnosticStringsEncoded > 0);
assert.ok(result.stats.diagnosticErrorCallsAliased > 0, "generated error calls should use the emitted local error alias");
assert.doesNotMatch(result.output, /Obfuscated source crash - runtime tamper detect/, "tamper diagnostic must be encoded in emitted output");
assert.match(encodeDiagnosticStrings('error("Obfuscated source crash - runtime tamper detect")').source, /\\079\\098\\102/, "diagnostic string encoder should escape the exact tamper message when it is emitted as a literal");
assert.doesNotMatch(result.output, /then\s+error\s*\(/i, "generated guards should not expose repeated `then error(...)` patterns");
assert.doesNotMatch(result.output, /\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]\s*~=\s*[^;\n]*\[(?:"|\')(?:type|pcall|pairs|tostring|select|error)(?:"|\')\]/i, "generated guard must not repeat string-keyed API-to-API comparisons");
assert.doesNotMatch(result.output, /Byte[Vv]eil v\d+\.\d+\.\d+: (?:instruction representation|runtime shield|tamper detected)/);
assert.doesNotMatch(result.output, /Detected hook|Made by Meoz|Runtime error !|ByteVeil environment unavailable|runtime integrity check failed|runtime guard unavailable/);
assert.doesNotMatch(result.output, /["\'](?:payload carrier alphabet|payload lane|payload integrity record|payload carrier missing|descriptor carrier missing|continuation miss)["\']/i, "recognizable payload diagnostics should not remain as plain string literals");
assert.doesNotMatch(result.output, /["\'](?:descriptor header|descriptor truncated|payload address bounds|region integrity|region opcode route|graph cycle|state machine miss|constant state|parameter state)["\']/i, "v5.8 runtime diagnostic strings should be encoded");
assert.ok(Buffer.byteLength(result.output, "utf8") <= result.sizeBudget.targetMaxBytes, "sample output respects release budget");

// The default user-facing preset must use the reset v5.8 callable bootstrap too.
const defaultPresetBuild = obfuscate('print("v58-default-preset")', {
  preset: "l1", mode: "register", target: "lua", seed: 0x5700A11
});
assert.equal(defaultPresetBuild.vmMeta.version, "5.9.0");
assert.match(defaultPresetBuild.output, /return setmetatable\(\{\[\d+\]=function\(/, "l1 must emit the v5.8 callable-object bootstrap, not legacy gsub wrapping");
assert.match(defaultPresetBuild.output, /ByteVeil Obfuscator v5\.9\.0/, "default preset watermark must match engine release version");
assert.doesNotMatch(defaultPresetBuild.output, /_bvh_|_1namp|_gtsnq/, "default preset must not expose legacy generated-name families");
const concatFixture = 'local function join(a,b) return a..b end; print(join("A","B"))';
const compactPresetBuilds = {};
for (const preset of ["l1", "lz"]) {
  // Compactness is a property of the generated payload, so it is measured with JunkForge
  // padding switched off - a padded file is mostly containers and would say nothing about
  // duplicated handlers. The padded sibling is the build that actually ships, so it is the
  // one executed below.
  const compactBuild = obfuscate(concatFixture, { preset, seed: 0x580001, junkForge: false });
  const paddedBuild = obfuscate(concatFixture, { preset, seed: 0x580001 });
  compactPresetBuilds[preset] = compactBuild;
  assert.equal(compactBuild.vmMeta.version, "5.9.0", `${preset}: active version`);
  assert.equal(compactBuild.vmMeta.junkForge.applied, false, `${preset}: payload-only build must skip padding`);
  assert.equal(paddedBuild.vmMeta.junkForge.applied, true, `${preset}: shipped build must carry padding`);
  const compactLimit = preset === "l1" ? 80000 : 90000;
  assert.ok(Buffer.byteLength(compactBuild.output, "utf8") < compactLimit, `${preset}: shared shadow dispatch should avoid the v5.7 duplicated-handler output size (unpadded payload)`);
  const gained = Buffer.byteLength(paddedBuild.output, "utf8") - Buffer.byteLength(compactBuild.output, "utf8");
  // The shipped build may only gain (a) the forge block - padding plus the five key-bed
  // containers - and (b) the key-binding text the payload itself carries, which is measured
  // from the two builds' own pre-padding body lengths rather than assumed to be zero.
  const forge = paddedBuild.vmMeta.junkForge;
  assert.equal(gained, forge.paddingBytes + forge.keyBedBytes + (forge.baseBytes - compactBuild.vmMeta.junkForge.baseBytes),
    `${preset}: the shipped build must gain exactly the forge block plus the measured key-binding delta`);
  assert.equal(forge.keyBedBound, true, `${preset}: the VM route must bind the payload key to the forge block`);
  if (resolveRuntime("lua")) {
    const compactRun = runProgram(resolveRuntime("lua"), paddedBuild.output, "lua");
    assert.ok(compactRun.ok, compactRun.stderr || compactRun.error || `${preset} concat fixture failed`);
    assert.equal(compactRun.stdout.trim(), "AB", `${preset}: concatenation semantics must be preserved`);
  }
}
assert.ok(compactPresetBuilds.l1.output.length < compactPresetBuilds.lz.output.length, "l1 should remain smaller than the higher-cost lz profile on the shared fixture");
if (resolveRuntime("lua")) {
  const defaultPresetRun = runProgram(resolveRuntime("lua"), defaultPresetBuild.output, "lua");
  assert.ok(defaultPresetRun.ok, defaultPresetRun.stderr || defaultPresetRun.error || "l1 bootstrap output failed to execute");
  assert.match(defaultPresetRun.stdout, /v58-default-preset/);
}

for (const mode of ["stack", "register"]) {
  const guardBuild = obfuscate("print(1+2)", {
    mode, seed: 0x530053 + (mode === "register" ? 1 : 0),
    wrapper: { enabled: false }, transforms: { watermark: false }
  });
  const guardOutput = guardBuild.output;
  assert.doesNotMatch(guardOutput, /_bvh_|_1namp|_gtsnq/, `${mode}: generated identifiers must not expose old seed-derived naming schemes`);
  assert.equal(guardBuild.stats.bodyOneLine, true, `${mode}: wrapper-disabled VM output should be a single minified line`);
  assert.equal(guardBuild.vmMeta.encodingEngine, "VeilSync-v2", `${mode}: active serializer must use VeilSync`);
  assert.ok(guardBuild.vmMeta.regionCount > 0, `${mode}: at least one payload region must be generated`);
  assert.equal(guardBuild.vmMeta.encodingRegionsVerified, guardBuild.vmMeta.regionCount, `${mode}: every region must be verified`);
  assert.equal(guardBuild.vmMeta.encodingPipelineRoundTripsVerified, guardBuild.vmMeta.regionCount, `${mode}: every pipeline must round-trip`);
  assert.equal(guardBuild.vmMeta.encodingRoundTripsVerified, guardBuild.vmMeta.regionCount * 3, `${mode}: every stage in every region must round-trip`);
  assert.doesNotMatch(guardOutput, /runtime integrity check failed|runtime guard unavailable/i, `${mode}: guard diagnostics should not remain plaintext`);
  assert.doesNotMatch(guardOutput, /\{type,\s*pcall,\s*pairs,\s*tostring,\s*select,\s*error\}/i, `${mode}: v5.5 anti-hook must not emit a cleartext API-reference vector`);
  assert.doesNotMatch(guardOutput, /bv_shadow_\d+/i, `${mode}: legacy shadow fingerprint must not be emitted`);
  assert.doesNotMatch(guardOutput, /\bSHADOW\.(?:pc|r|m|f|acc|tick|calls|ret)\b/i, `${mode}: fixed shadow-frame fields must not be emitted`);
  assert.doesNotMatch(guardOutput, /"ByteVeil"|\\"ByteVeil\\"/, `${mode}: fixed decoy string marker must not be emitted as a literal`);
  assert.doesNotMatch(guardOutput, /\blocal\s+(?:VM|PLAN|I0|VAL)\s*=/, `${mode}: common shadow locals must not survive template mangling`);
  assert.doesNotMatch(guardOutput, /\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]\s*~=\s*[^;\n]*\[(?:"|\\')(?:type|pcall|pairs|tostring|select|error)(?:"|\\')\]/i, `${mode}: no repeated string-keyed API comparisons`);
  assert.doesNotMatch(guardOutput, /then\s+error\s*\(/i, `${mode}: no direct then error call`);
  assert.ok(Buffer.byteLength(guardOutput, "utf8") <= guardBuild.sizeBudget.targetMaxBytes, `${mode}: output respects release budget`);
}

// Differential arithmetic regression: parser precedence and stack-depth
// validation must agree with the available native Lua runtime.
const lua = resolveRuntime("lua");
if (lua) {
  const wrappedRuntime = wrap('print("wrapper-ok")', { seed: 0x5500, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable", argumentCount: 3 });
  const wrappedSyntax = runSyntaxCheck(lua, wrappedRuntime, "lua");
  assert.ok(wrappedSyntax.ok, wrappedSyntax.stderr || "direct-return setmetatable wrapper syntax failed");
  const wrappedResult = runProgram(lua, wrappedRuntime, "lua");
  assert.ok(wrappedResult.ok, wrappedResult.stderr || "direct-return setmetatable wrapper runtime failed");
  assert.equal(wrappedResult.stdout.trim(), "wrapper-ok");

  const guardSuccess = `${anti.declaration}\n${anti.checkCall}\nprint("guard-ok")`;
  const guardSuccessResult = runProgram(lua, guardSuccess, "lua");
  assert.ok(guardSuccessResult.ok, guardSuccessResult.stderr || "generated guard should pass in a clean Lua environment");
  assert.equal(guardSuccessResult.stdout.trim(), "guard-ok");

  const setmetaAnti = buildAntiHookSource({ prefix: "__v550_tamper", seed: 0x550A11, baselineFromEnvironment: true });
  const setmetaTamper = `${setmetaAnti.declaration}\nsetmetatable=function() return nil end\nlocal __ok,__message=pcall(function() ${setmetaAnti.checkCall} end)\nprint(__ok, __message)`;
  const setmetaTamperResult = runProgram(lua, setmetaTamper, "lua");
  assert.ok(setmetaTamperResult.ok, setmetaTamperResult.stderr || "setmetatable tamper fixture should run");
  assert.match(setmetaTamperResult.stdout, /false\s+Obfuscated source crash - runtime tamper detect/, "setmetatable replacement must fail closed with the required message");

  const changedApi = `${anti.declaration}\nlocal __original_tostring = tostring\ntostring = function(v) return __original_tostring(v) end\nlocal __ok = pcall(function() ${anti.checkCall} end)\ntostring = __original_tostring\nprint(__ok)`;
  const changedApiResult = runProgram(lua, changedApi, "lua");
  assert.ok(changedApiResult.ok, changedApiResult.stderr || "mutated API guard fixture should run");
  assert.equal(changedApiResult.stdout.trim(), "false", "generated guard must still detect API replacement after startup");

  const originalDiagnostic = 'local ok, message = pcall(function() error("ByteVeil v4.6.3: tamper detected", 0) end); print(message)';
  const encodedDiagnostic = encodeDiagnosticStrings(originalDiagnostic).source;
  const diagnosticOriginalResult = runProgram(lua, originalDiagnostic, "lua");
  const diagnosticEncodedResult = runProgram(lua, encodedDiagnostic, "lua");
  assert.ok(diagnosticOriginalResult.ok, diagnosticOriginalResult.stderr || "original diagnostic fixture failed");
  assert.ok(diagnosticEncodedResult.ok, diagnosticEncodedResult.stderr || "encoded diagnostic fixture failed");
  assert.equal(diagnosticEncodedResult.stdout, diagnosticOriginalResult.stdout, "encoded diagnostics must preserve the actual runtime string");

  const arithmetic = "print(-2^2,(-2)^2,2^3^2,2^-3,(1+2)<<3,1|(2+3),1&(2<<3))";
  const nativeResult = runProgram(lua, arithmetic, "lua");
  assert.ok(nativeResult.ok, nativeResult.stderr || "native arithmetic fixture failed");
  for (const mode of ["stack", "register"]) {
    const protectedArithmetic = obfuscate(arithmetic, {
      mode, seed: 0x520053 + (mode === "register" ? 1 : 0), wrapper: { enabled: false },
      transforms: { watermark: false }
    });
    const syntax = runSyntaxCheck(lua, protectedArithmetic.output, "lua");
    assert.ok(syntax.ok, syntax.stderr || syntax.error || `${mode} arithmetic syntax failed`);
    const protectedResult = runProgram(lua, protectedArithmetic.output, "lua");
    assert.ok(protectedResult.ok, protectedResult.stderr || `${mode} protected arithmetic fixture failed`);
    assert.equal(protectedResult.stdout, nativeResult.stdout, `${mode} VM arithmetic should match native Lua for precedence fixture`);
  }


  // Luau `continue` must take the correct loop-specific edge: condition for
  // while, condition after the body for repeat, and update/iterator for for-loops.
  const continueFixtures = [
    ["numeric-for", "local n=0; for i=1,5 do if i==2 then continue end; n+=i end; print(n)", "local n=0; for i=1,5 do if i~=2 then n=n+i end end; print(n)"],
    ["while", "local i=0; local n=0; while i<5 do i+=1; if i==2 then continue end; n+=i end; print(n)", "local i=0; local n=0; while i<5 do i=i+1; if i~=2 then n=n+i end end; print(n)"],
    ["repeat", "local i=0; local n=0; repeat i+=1; if i==2 then continue end; n+=i until i>=5; print(n)", "local i=0; local n=0; repeat i=i+1; if i~=2 then n=n+i end until i>=5; print(n)"],
    ["generic-for", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k==2 then continue end; n+=v end; print(n)", "local n=0; for k,v in ipairs({1,2,3,4,5}) do if k~=2 then n=n+v end end; print(n)"],
    ["nested-loop", "local n=0; for i=1,3 do for j=1,3 do if j==2 then continue end; n+=1 end end; print(n)", "local n=0; for i=1,3 do for j=1,3 do if j~=2 then n=n+1 end end end; print(n)"],
  ];
  for (const [name, source, reference] of continueFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} reference fixture failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52100 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} output syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} continue semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate("continue", { mode: "stack", target: "lua", wrapper: { enabled: false } }), /continue outside loop/i);

  // Luau backtick strings are lowered into concat/tostring AST nodes. Compare
  // VM output against equivalent ordinary Lua instead of feeding backticks to Lua 5.3.
  const interpolationFixtures = [
    ["basic", 'local name="Luau"; print(`Hello {name}!`)', 'local name="Luau"; print("Hello " .. tostring(name) .. "!")'],
    ["expressions", 'print(`{1 + 2} {true} {nil}`)', 'print(tostring(1 + 2) .. " " .. tostring(true) .. " " .. tostring(nil))'],
    ["escaped-braces", 'print(`Some example \\{like so\\}`)', 'print("Some example {like so}")'],
    ["quoted-brace", 'print(`a {select(1, "}", 3)} b`)', 'print("a " .. tostring(select(1, "}", 3)) .. " b")'],
    ["unicode-escape", 'local s="雪"; print(`💬 {s} \\u{1F600}`)', 'local s="雪"; print("💬 " .. tostring(s) .. " 😀")'],
    ["escaped-backtick", 'print(`tick: \\` ok`)', 'print("tick: ` ok")'],
  ];
  for (const [name, source, reference] of interpolationFixtures) {
    const expected = runProgram(lua, reference, "lua");
    assert.ok(expected.ok, expected.stderr || `${name} interpolation reference failed`);
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(source, { mode, target: "lua", seed: 0x52200 + name.length + mode.length, wrapper: { enabled: false }, transforms: { watermark: false } });
      const syntax = runSyntaxCheck(lua, built.output, "lua");
      assert.ok(syntax.ok, syntax.stderr || syntax.error || `${name}/${mode} interpolation syntax failed`);
      const result = runProgram(lua, built.output, "lua");
      assert.ok(result.ok, result.stderr || `${name}/${mode} interpolation runtime failed`);
      assert.equal(result.stdout, expected.stdout, `${name}/${mode} interpolation semantics differ from reference`);
    }
  }
  assert.throws(() => obfuscate('print(`{{`)', { mode: "stack", target: "lua", wrapper: { enabled: false } }), /interpolation|parser error/i);
}

if (resolveRuntime("lua")) {
  const nested = obfuscate('print("nest-ok", 2+3)', { target: "lua", preset: "nest", mode: "stack", seed: 0x55AA, wrapper: { enabled: false }, transforms: { watermark: false } });
  assert.equal(nested.vmMeta.nestedSourceEngine, "legacy-wrapSource-v4.7.4");
  assert.equal(nested.vmMeta.nestedObfuscationLayers, 5);
  assert.equal(nested.vmMeta.nestedRequiresDynamicLoader, true);
  const nestedSyntax = runSyntaxCheck(resolveRuntime("lua"), nested.output, "lua");
  assert.ok(nestedSyntax.ok, nestedSyntax.stderr || "Nest preset syntax failed");
  const nestedRun = runProgram(resolveRuntime("lua"), nested.output, "lua");
  assert.ok(nestedRun.ok, nestedRun.stderr || "Nest preset runtime failed");
  assert.equal(nestedRun.stdout.trim(), "nest-ok\t5");
}

// Verify v5.8.0 deep hardening: per-build hex-keyed dispatch tables, seeded anti-tamper,
// variable-length shuffled payload carriers + decoy carriers, and multi-layer LPH/LPS/CFF/VM execution.
{
  const { buildAntiTamperSource } = require("./src/anti/anti_tamper");
  const { encodeBytecodeBlobV45 } = require("./src/backend/bytecode_serializer");
  const t1 = buildAntiTamperSource({ prefix: "_t", seed: 0x580001 });
  const t2 = buildAntiTamperSource({ prefix: "_t", seed: 0x580002 });
  assert.notEqual(t1.declaration, t2.declaration, "anti-tamper validator parameters must vary per build seed");
  assert.doesNotMatch(t1.declaration, /Checked fail/i, "anti-tamper must not emit cleartext signature strings");

  const hexBuildA = obfuscate("local a = 10; local b = 20; print(a + b)", { preset: "l1", seed: 0x581111 });
  const hexBuildB = obfuscate("local a = 10; local b = 20; print(a + b)", { preset: "l1", seed: 0x582222 });
  const hexKeysA = [...hexBuildA.output.matchAll(/\[(0x[0-9a-f]+)\]=/gi)].map((m) => m[1]);
  const hexKeysB = [...hexBuildB.output.matchAll(/\[(0x[0-9a-f]+)\]=/gi)].map((m) => m[1]);
  assert.ok(hexKeysA.length >= 16, "VM and Shadow VM must emit per-build hex-keyed dispatch tables");
  assert.notDeepEqual(hexKeysA, hexKeysB, "hex-keyed dispatch table keys must change on every build seed");
  const bodyOnlyA = hexBuildA.output.split("\n").slice(1).join("\n");
  // v5.9 represents diagnostics as VeilBlob literals instead of `\ddd` chains.
  // The `[==[byteveil&...]==]` marker is intentional branding (like LPH&), so it
  // is stripped before the cleartext sweep; everything inside it is ciphertext.
  const blobsA = findBlobLiterals(bodyOnlyA).map((blob) => blob.text);
  assert.ok(blobsA.length >= 1, "diagnostics must be represented as VeilBlob literals");
  const strippedBodyA = stripBlobLiterals(bodyOnlyA);
  assert.doesNotMatch(strippedBodyA, /\\[0-9]{3}/, "v5.9 body must not fall back to \\ddd diagnostic escapes");
  const unescapedBodyA = strippedBodyA.replace(/\\(\d{3})/g, (_, d) => String.fromCharCode(Number(d)));
  assert.doesNotMatch(unescapedBodyA, /ByteVeil/i, "obfuscated body must not leak ByteVeil diagnostic strings outside the encrypted blob");
  assert.doesNotMatch(bodyOnlyA, /abcdefgh|0123456789/i, "obfuscated body must not expose sequential plaintext alphabets");
  assert.doesNotMatch(strippedBodyA, /\b(?:resolveRegion|unshard|shardMask|decodeRegionCodec|byteMask|chunkRead|readString|VMCache|regionFor|personality|runtimeToken|nativeBuffer)\b/, "obfuscated body must mangle internal VM helper and graph field names");
  assert.match(bodyOnlyA, /\[\(0x[0-9a-f]+[-+]0x[0-9a-f]+\)\]/i, "callable setmetatable bootstrap must use arithmetic hex slot forwarding");

  const multiLayerSource = [
    "-- LPS_STR_ENCRYPT",
    "-- LPS_CONST_PROTECT",
    "-- LPS_CONTROL_FLOW",
    "local secret = LPH_ENCSTR(\"ByteVeil_Hardened_Payload_v580\")",
    "local magic = LPH_ENCNUM(1337)",
    "local compute = LPH_NO_UPVALUES(function(x, y)",
    "  local acc = 0",
    "  for i = 1, 6 do",
    "    if i == 3 then continue end",
    "    acc = acc + (x * i) - y",
    "  end",
    "  return acc",
    "end)",
    "local check = LPH_JIT_MAX(function(v)",
    "  if v > 100 then",
    "    return v + magic",
    "  else",
    "    return v - magic",
    "  end",
    "end)",
    "print(secret, check(compute(12, 5)))"
  ].join("\n");

  for (const runtimeName of ["lua", "luau"]) {
    const rt = resolveRuntime(runtimeName);
    if (!rt) continue;
    for (const mode of ["stack", "register"]) {
      const built = obfuscate(multiLayerSource, {
        preset: "l2",
        mode,
        target: runtimeName === "luau" ? "luau" : "lua",
        seed: 0x589000 + mode.length + runtimeName.length
      });
      const run = runProgram(rt, built.output, runtimeName);
      assert.ok(run.ok, run.stderr || run.error || `${runtimeName}/${mode} multi-layer execution failed`);
      assert.equal(run.stdout.trim(), "ByteVeil_Hardened_Payload_v580\t1528", `${runtimeName}/${mode} multi-layer output mismatch`);
    }
  }

  // Review Log Verification:
  // 1. Both payload carriers AND VM subsystems (Shadow VM, Region-Graph Deserializer, Core Semantic ISA)
  //    must be physically partitioned across all 3 callable bootstrap slots (entry, dispatch, body)
  //    so no single slot forms a >50% monolithic body.
  // 2. Every stage's carrier partition and state transition must be actively verified at runtime
  //    (ablating a carrier in Stage 1, Stage 2, or Stage 3, or mutating the state seed, must fail closed on Lua & Luau).
  // 3. Single-invocation differential harness (`execCount == 1`) verifying `...`, leading/middle/trailing `nil`
  //    multi-returns, nested vararg closures, ordered side effects, and global state mutations across
  //    both Lua 5.4 and Luau for `wrap()` (both topologies) and `obfuscate()` (stack & register).
  // JunkForge padding is a statement prefix in front of the payload, so the slot
  // distribution below is measured with the padding block removed: leaving it in would
  // describe how big the padding is instead of how the VM subsystem is partitioned.
  const stripForgeBlock = (text) => {
    const open = /local \w+=\(function\(\)local \w+=\{\} local \w+=\{function\(\)/.exec(text);
    if (!open) return text;
    const tail = / then \w+\(\) end return \w+ end\)\(\);/.exec(text.slice(open.index));
    return tail ? `${text.slice(0, open.index)}${text.slice(open.index + tail.index + tail[0].length)}` : text;
  };

  const measureBootstrapSlots = (fullOutput) => {
    const bodyOnly = stripForgeBlock(fullOutput.split("\n").slice(1).join("\n"));
    const matches = [...bodyOnly.matchAll(/(?:\{|,)\[(\d{3,5})\]=function\([A-Za-z_]/g)];
    assert.equal(matches.length, 3, "coupled VM bootstrap must expose the 3 staged callable slots");
    const callIdx = bodyOnly.lastIndexOf("__call=function");
    const slices = matches.map((m, idx) => {
      const start = m.index + 1;
      const end = idx + 1 < matches.length ? matches[idx + 1].index : callIdx;
      return { slot: Number(m[1]), text: bodyOnly.slice(start, end), bytes: end - start, startInFull: fullOutput.indexOf(bodyOnly.slice(start, start + 32)) };
    });
    const totalBytes = Buffer.byteLength(bodyOnly, "utf8");
    const shares = slices.map((s) => s.bytes / totalBytes);
    const entropy = -shares.reduce((acc, p) => acc + (p > 0 ? p * Math.log2(p) : 0), 0) / Math.log2(3);
    return { bodyOnly, slices, totalBytes, shares, entropy };
  };

  const metricsA = measureBootstrapSlots(hexBuildA.output);
  const metricsB = measureBootstrapSlots(hexBuildB.output);
  const carrierPattern = /\[\d+\]=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\(\[=+\[byteveil&/g;
  for (const [label, m] of [["seedA", metricsA], ["seedB", metricsB]]) {
    for (let idx = 0; idx < 3; idx++) {
      const carriersInStage = (m.slices[idx].text.match(carrierPattern) || []).length;
      assert.ok(carriersInStage >= 2, `${label} stage ${idx + 1} must host >= 2 encrypted payload carriers (got ${carriersInStage})`);
      assert.ok(m.slices[idx].bytes >= 8000, `${label} stage ${idx + 1} must carry a substantial VM subsystem (>8 KB, got ${m.slices[idx].bytes}B)`);
      assert.ok(m.shares[idx] < 0.50, `${label} stage ${idx + 1} must not form a monolithic >50% body (got ${(m.shares[idx] * 100).toFixed(1)}%)`);
    }
    assert.ok(m.entropy >= 0.94, `${label} 3-slot byte distribution must have normalized Shannon entropy >= 0.94 (got ${m.entropy.toFixed(4)})`);
  }

  // Verify unmodified baseline outputs execute and produce the expected result BEFORE running tamper/ablation checks.
  for (const rtName of ["lua", "luau"]) {
    const rt = resolveRuntime(rtName);
    if (!rt) continue;
    for (const [label, buildObj] of [["seedA", hexBuildA], ["seedB", hexBuildB]]) {
      const unmodifiedRun = runProgram(rt, buildObj.output, rtName);
      assert.ok(unmodifiedRun.ok, `${rtName}: unmodified ${label} must succeed before tamper testing: ${unmodifiedRun.stderr}`);
      assert.equal(unmodifiedRun.stdout.trim(), "30", `${rtName}: unmodified ${label} output mismatch`);
    }
  }

  // Runtime ablation proof: corrupting 1 byte of a carrier inside Stage 1, Stage 2, or Stage 3,
  // mutating the callable bootstrap state seed, or tampering with root pow2/stdlib bindings must fail closed on both Lua and Luau.
  // Two carrier classes live in a stage slice on purpose: the callable containers
  // (`vyX7[k]=function()return D(string.sub([==[byteveil&...)==],10),...)`) whose
  // decode is load-bearing, and the raw-assigned decoys that section 7 designs to
  // survive deletion. Selecting "the first blob literal" graded whichever class the
  // seed happened to put first, so an inert decoy made this assert a real strength
  // property of a build that only moved bytes around. Select by shape, and ablate
  // every callable carrier - the claim is "each one is load-bearing", not "one exists".
  const callableCarrierRe = /=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\($/;
  for (let stageIdx = 0; stageIdx < 3; stageIdx++) {
    const stageText = metricsA.slices[stageIdx].text;
    const stageBlobs = findBlobLiterals(stageText);
    assert.ok(stageBlobs.length >= 2, `stage ${stageIdx + 1} must host VeilBlob payload carriers`);
    const carriers = stageBlobs.filter((b) => callableCarrierRe.test(stageText.slice(Math.max(0, b.start - 72), b.start)));
    assert.ok(carriers.length >= 2, `stage ${stageIdx + 1} must host >= 2 callable payload carriers (got ${carriers.length})`);
    for (const carrier of carriers) {
      // Flip the first encoded byte inside the container: the marker and the
      // bracket level stay intact, so only the payload itself is corrupted.
      const carrierBlob = carrier.text;
      const encodedAt = carrierBlob.indexOf(BLOB_MARKER) + BLOB_MARKER.length;
      assert.ok(encodedAt < carrierBlob.length - 2, `stage ${stageIdx + 1} carrier container must not be empty`);
      const flippedFirst = carrierBlob[encodedAt] === "!" ? "#" : "!";
      const mutatedBlob = `${carrierBlob.slice(0, encodedAt)}${flippedFirst}${carrierBlob.slice(encodedAt + 1)}`;
      const ablatedStageOutput = hexBuildA.output.replace(carrierBlob, mutatedBlob);
      assert.notEqual(ablatedStageOutput, hexBuildA.output, `stage ${stageIdx + 1} carrier mutation must modify output`);
      for (const rtName of ["lua", "luau"]) {
        const rt = resolveRuntime(rtName);
        if (!rt) continue;
        const ablatedRun = runProgram(rt, ablatedStageOutput, rtName);
        assert.equal(ablatedRun.ok, false, `${rtName}: ablating a callable carrier in stage ${stageIdx + 1} must fail closed`);
      }
    }
  }

  const tamperedSeedOutput = hexBuildA.output.replace(/(\[\d+\]=)(\d+)(,\[\d+\]=function\()/, (_, p1, num, p3) => `${p1}${Number(num) + 1}${p3}`);
  assert.notEqual(tamperedSeedOutput, hexBuildA.output, "bootstrap state seed must be present in callable table");
  const tamperedPow2Output = hexBuildA.output.replace(",32768,65536}", ",32768,65535}");
  assert.notEqual(tamperedPow2Output, hexBuildA.output, "bootstrap pow2 binding table must be present in callable table");
  for (const rtName of ["lua", "luau"]) {
    const rt = resolveRuntime(rtName);
    if (!rt) continue;
    const tamperedSeedRun = runProgram(rt, tamperedSeedOutput, rtName);
    assert.equal(tamperedSeedRun.ok, false, `${rtName}: tampering with callable bootstrap state seed must fail closed`);
    const tamperedPow2Run = runProgram(rt, tamperedPow2Output, rtName);
    assert.equal(tamperedPow2Run.ok, false, `${rtName}: tampering with callable bootstrap pow2 table must fail closed`);
    const uninvokedWrapper = wrap("return 77", { seed: 404, wrapper: true, invoke: false, setmeta: true, returnMode: "setmetatable" });
    const metaLockProbe = `local obj = (function() ${uninvokedWrapper} end)(); assert(getmetatable(obj) == false, 'expected locked metatable'); local ok = pcall(setmetatable, obj, {}); assert(ok == false, 'setmetatable on locked bootstrap must fail'); print(obj())`;
    const metaLockRun = runProgram(rt, metaLockProbe, rtName);
    assert.ok(metaLockRun.ok, `${rtName}: metatable lock probe failed: ${metaLockRun.stderr}`);
    assert.equal(metaLockRun.stdout.trim(), "77", `${rtName}: locked bootstrap object must still be callable`);
  }

  // Single-invocation differential semantics suite across direct `wrap()` (both topologies)
  // and full `obfuscate()` (stack & register) on BOTH Lua 5.4 and Luau.
  const semanticsFixtures = [
    {
      name: "chunk-level vararg with nil holes and global state update",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local a, b, c, d, e = ...; local n = select("#", ...); bv_side_log[#bv_side_log + 1] = "vararg:" .. tostring(n) .. ":" .. tostring(a) .. ":" .. tostring(c); bv_state_acc = (bv_state_acc or 0) + n * 10; return b, a, d, n, e',
      invokeArgs: '"alpha", nil, "gamma", nil, false'
    },
    {
      name: "multi-return with leading, middle, and trailing nils plus arg expressions",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local function produce(x, y) bv_side_log[#bv_side_log + 1] = "produce:" .. tostring(x) .. ":" .. tostring(y); return nil, "two", nil, x + y, nil end; local u, v = 1, 3; local a, b, c, d, e = produce(u + 1, v - 1); bv_state_acc = (bv_state_acc or 0) + (d or 0); return produce(u, v)',
      invokeArgs: ""
    },
    {
      name: "nested vararg closures and upvalue mutation",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local up = 3; local function outer(prefix, ...) local n = select("#", ...); up = up + n; local function inner(...) local m = select("#", ...); up = up * 2 + m; bv_side_log[#bv_side_log + 1] = prefix .. ":" .. tostring(n) .. ":" .. tostring(m) .. ":" .. tostring(up); return prefix, m, ... end; return inner(nil, ...) end; local x, y, z, w, k = outer("tag", 10, nil, 30); bv_state_acc = (bv_state_acc or 0) + up; return x, y, z, w, k',
      invokeArgs: ""
    },
    {
      name: "ordered side effects across short-circuit, table constructors, and loops",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local function step(tag, val) bv_side_log[#bv_side_log + 1] = tag; bv_state_acc = (bv_state_acc or 0) + 1; return val end; local tbl = { [step("k1", 1)] = step("v1", 10), [step("k2", 2)] = step("v2", 20) }; local res = (step("lhs", false) and step("unreachable", 99)) or step("rhs", tbl[1] + tbl[2]); for i = 1, 3 do step("loop" .. tostring(i), i) end; return nil, #bv_side_log, res, nil',
      invokeArgs: ""
    },
    {
      name: "recursive functions, OOP method calls, and custom metatables",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local function fib(n) if n <= 1 then return n end; return fib(n - 1) + fib(n - 2) end; local proto = { scale = 3 }; function proto:calc(x, y) bv_side_log[#bv_side_log + 1] = "calc:" .. tostring(x) .. ":" .. tostring(y); return (x + y) * self.scale, x * y end; local obj = setmetatable({ bias = 5 }, { __index = proto, __call = function(t, v) return t:calc(v, t.bias) end }); local p, q = obj(fib(6)); bv_state_acc = (bv_state_acc or 0) + p + q; return p, nil, q',
      invokeArgs: ""
    },
    {
      name: "generic for-in iteration, repeat-until, and pcall error recovery",
      source: 'bv_exec_count = (bv_exec_count or 0) + 1; local arr = { 7, 11, 13, 17 }; local acc = 0; for idx, val in ipairs(arr) do local stepVal = val * idx; repeat stepVal = stepVal - 2 until stepVal <= 20; acc = acc + stepVal; bv_side_log[#bv_side_log + 1] = "it:" .. tostring(idx) .. ":" .. tostring(acc) end; local ok1, v1 = pcall(function(x, y) return x + acc, y * 2 end, 9, 4); local ok2, err2 = pcall(function() error("EXPECTED_FAULT", 0) end); bv_state_acc = (bv_state_acc or 0) + (ok1 and v1 or 0); return ok1, v1, ok2, string.find(tostring(err2), "EXPECTED_FAULT") ~= nil',
      invokeArgs: ""
    }
  ];

  const singleExecHarnessFor = (chunkCode, invokeArgs) => [
    "bv_exec_count = 0",
    "bv_side_log = {}",
    "bv_state_acc = 100",
    "local function packOnce(...) return { n = select('#', ...), ... } end",
    `local fn = function(...) ${chunkCode} end`,
    `local r = packOnce(fn(${invokeArgs}))`,
    "assert(bv_exec_count == 1, 'expected exactly 1 chunk execution, got ' .. tostring(bv_exec_count))",
    "local parts = {",
    "  'exec=' .. tostring(bv_exec_count),",
    "  'acc=' .. tostring(bv_state_acc),",
    "  'log=' .. table.concat(bv_side_log, ','),",
    "  'retN=' .. tostring(r.n)",
    "}",
    "for i = 1, r.n do parts[#parts + 1] = type(r[i]) .. ':' .. tostring(r[i]) end",
    "print(table.concat(parts, '|'))"
  ].join("\n");

  for (let fIdx = 0; fIdx < semanticsFixtures.length; fIdx++) {
    const fixture = semanticsFixtures[fIdx];
    const wrappedVariants = [101, 102].map((topoSeed) => ({
      topoSeed,
      code: wrap(fixture.source, {
        seed: topoSeed,
        wrapper: true,
        invoke: true,
        setmeta: true,
        returnMode: "setmetatable"
      })
    }));
    const obfVariants = ["stack", "register"].map((mode) => ({
      mode,
      code: obfuscate(fixture.source, {
        preset: "l1",
        mode,
        target: "luau",
        seed: 0x58B000 + fIdx * 17 + mode.length
      }).output
    }));

    for (const rtName of ["lua", "luau"]) {
      const rt = resolveRuntime(rtName);
      if (!rt) continue;
      const baseRun = runProgram(rt, singleExecHarnessFor(fixture.source, fixture.invokeArgs), rtName);
      assert.ok(baseRun.ok, baseRun.stderr || `${rtName} baseline fixture failed: ${fixture.name}`);
      const expectedDigest = baseRun.stdout.trim();
      assert.match(expectedDigest, /^exec=1\|/, `${rtName} baseline must execute exactly once`);

      for (const { topoSeed, code } of wrappedVariants) {
        const wrappedRun = runProgram(rt, singleExecHarnessFor(code, fixture.invokeArgs), rtName);
        assert.ok(wrappedRun.ok, wrappedRun.stderr || `${rtName} wrap() failed on ${fixture.name} (seed=${topoSeed})`);
        assert.equal(wrappedRun.stdout.trim(), expectedDigest, `${rtName} wrap() single-exec semantics mismatch on ${fixture.name} (seed=${topoSeed})`);
      }

      for (const { mode, code } of obfVariants) {
        const obfRun = runProgram(rt, singleExecHarnessFor(code, fixture.invokeArgs), rtName);
        assert.ok(obfRun.ok, obfRun.stderr || `${rtName} obfuscate(${mode}) failed on ${fixture.name}`);
        assert.equal(obfRun.stdout.trim(), expectedDigest, `${rtName} obfuscate(${mode}) single-exec semantics mismatch on ${fixture.name}`);
      }
    }
  }

  // Strict global environment check: wrapper invocation must not read undefined bridge globals from `_G` / environment.
  const wrappedStrictChunk = wrap('local a, b, c = ...; local x = 21; print(x * 2, tostring(a), tostring(b), tostring(c)); return a, b, c', {
    seed: 999,
    wrapper: true,
    invoke: true,
    setmeta: true,
    returnMode: "setmetatable"
  });
  const strictGlobalSource = [
    'local baseEnv = _G',
    'local sf = rawget(baseEnv, "setfenv")',
    'local strictMt = { __index = function(_, k) local v = rawget(baseEnv, k); if v ~= nil then return v end; error("unexpected global read: " .. tostring(k), 0) end }',
    'pcall(setmetatable, _G, strictMt)',
    `local fn = function(...) ${wrappedStrictChunk} end`,
    'if type(sf) == "function" then sf(fn, setmetatable({}, strictMt)) end',
    'local r1, r2, r3 = fn("u", nil, "v")',
    'print(tostring(r1), tostring(r2), tostring(r3))'
  ].join("\n");
  for (const rtName of ["lua", "luau"]) {
    const rt = resolveRuntime(rtName);
    if (!rt) continue;
    const strictRun = runProgram(rt, strictGlobalSource, rtName);
    assert.ok(strictRun.ok, strictRun.stderr || `${rtName} strict global environment check failed`);
    assert.equal(strictRun.stdout.trim(), "42\tu\tnil\tv\nu\tnil\tv", `${rtName} strict global environment output mismatch`);
  }
}

console.log(`ByteVeil v5.8.0 focused regressions: PASS (Lua precedence, continue loop edges, Luau interpolation, VeilSync, tamper guard, wrapper, Nest preset, output=${Buffer.byteLength(result.output, "utf8")} bytes)`);

"use strict";

// ByteVeil v5.9 anti-bundle resistance suite.
//
// Scope is the three anti layers as they are actually emitted:
//   * anti-hook  -> API/library/member identity + pure behavioural canaries, whose
//                    verdict is folded into a number the build can predict;
//   * anti-tamper -> dual-chain (forward + mirrored) integrity digest of the payload bytes;
//   * anti-dump  -> two-pass erase (same-type filler, then unlink) of mutable tables.
//
// Nothing here is asserted from a declared constant: every expected digest, hash and
// program output is measured from a real run on the native Lua 5.4 and Luau binaries, and
// the JavaScript mirrors are checked against those runs.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { buildAntiHookSource } = require("./src/anti/anti_hook");
const { buildAntiTamperSource, checksumBytesV2 } = require("./src/anti/anti_tamper");
const { buildAntiDumpSource, WIPE_MAX_DEPTH } = require("./src/anti/anti_dump");
const { buildAntiBundle } = require("./src/anti");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the anti-bundle suite");
assert.ok(luau, "Luau native runtime is required for the anti-bundle suite");

const RUNTIMES = ["lua", "luau"];
const runtimeOf = (name) => resolveRuntime(name);
const counts = { programs: 0, aborts: 0, matched: 0 };

function run(runtimeName, program) {
    counts.programs++;
    return runProgram(runtimeOf(runtimeName), program, runtimeName);
}

function expectAbort(runtimeName, program, label) {
    const result = run(runtimeName, program);
    const stdout = String(result.stdout || "").trim();
    const aborted = !result.ok || stdout.length === 0;
    assert.ok(aborted, `${label}: ${runtimeName} must abort, got stdout=${JSON.stringify(stdout)}`);
    counts.aborts++;
}

// ---------------------------------------------------------------------------
// 1. The anti-hook verdict is predictable from the build, on both runtimes.
// ---------------------------------------------------------------------------

const hookSeeds = [0x59A1, 0x1234, 4242, 90210, 0xDEADBEEF, 0x0B00B1E];

for (const seed of hookSeeds) {
    for (const profile of ["balanced", "strict"]) {
        for (const baseline of [true, false]) {
            const built = buildAntiHookSource({
                prefix: `_bvanti_hook_${seed.toString(36)}`,
                seed,
                profile,
                baselineFromEnvironment: baseline,
                failClosedOnMissingEnvironment: true
            });
            assert.equal(built.names.guard, built.names.guard, "guard name must be stable");
            assert.doesNotMatch(built.declaration, /\b(undefined|NaN|\[object Object\])\b/, "declaration must not carry a template hole");
            const program = `${built.declaration}\nprint(${built.names.guard}())\n`;
            for (const runtimeName of RUNTIMES) {
                const result = run(runtimeName, program);
                assert.ok(result.ok, `clean guard must run on ${runtimeName}: ${result.error || result.stderr}`);
                const digest = Number(String(result.stdout).trim());
                assert.equal(digest, built.digest.expected,
                    `${runtimeName}: runtime verdict must equal the build-side prediction (seed 0x${seed.toString(16)}, ${profile}, env-baseline=${baseline})`);
                counts.matched++;
            }
        }
    }
}

// Build diversity: the same API set must not fold to the same verdict across seeds.
const verdicts = hookSeeds.map((seed) => buildAntiHookSource({ prefix: "_v", seed }).digest.expected);
assert.equal(new Set(verdicts).size, verdicts.length, "verdict digest must vary per build seed");

// ---------------------------------------------------------------------------
// 2. Hook attacks abort on both runtimes; a faithful proxy is an accepted limitation.
// ---------------------------------------------------------------------------

const guardBuild = buildAntiHookSource({ prefix: "_g", seed: 0x59A1, failClosedOnMissingEnvironment: true });
const cleanGuardRun = run("lua", `${guardBuild.declaration}\nprint(${guardBuild.names.guard}())\n`);
assert.ok(cleanGuardRun.ok, "clean guard must run before the attack matrix");
const CLEAN_VERDICT = String(cleanGuardRun.stdout).trim();

const attacks = {
    "global pcall replaced after capture": "_G.pcall = function(f, ...) return f(...) end",
    "string.sub replaced after capture": "string.sub = function(s, i, j) return ('x') end",
    "math.floor swapped for math.ceil after capture": "math.floor = math.ceil",
    "table.concat replaced after capture": "table.concat = function() return '' end",
    "string table replaced after capture": "string = { sub = function() return '' end, byte = string.byte, rep = string.rep }",
    "core type replaced with a logging closure after capture": "type = function(v) log = (log or 0) + 1 return 'function' end"
};

for (const [label, mutation] of Object.entries(attacks)) {
    const program = `${guardBuild.declaration}\n${mutation}\nprint(${guardBuild.names.guard}())\n`;
    for (const runtimeName of RUNTIMES) {
        expectAbort(runtimeName, program, `post-capture hook: ${label}`);
    }
}

// A mis-implementation installed *before* the chunk runs is still caught, because the
// behavioural canaries do not depend on when the replacement happened.
const preSwap = buildAntiHookSource({ prefix: "_p", seed: 0x77, failClosedOnMissingEnvironment: true });
for (const runtimeName of RUNTIMES) {
    expectAbort(runtimeName,
        `math.floor = math.ceil\n${preSwap.declaration}\nprint(${preSwap.names.guard}())\n`,
        `pre-load mis-implementation of math.floor on ${runtimeName}`);
}

// Honest limitation, asserted rather than claimed: a proxy that forwards every call
// correctly is behaviourally identical to the native library and passes the guard.
const faithfulProxy = run("lua", [
    "local realString = string",
    "string = setmetatable({}, {__index = function(_, key) return rawget(realString, key) end})",
    preSwap.declaration,
    `print(${preSwap.names.guard}())`
].join("\n"));
assert.ok(faithfulProxy.ok, `a faithful forwarding proxy must not false-positive: ${faithfulProxy.error || faithfulProxy.stderr}`);
assert.equal(String(faithfulProxy.stdout).trim(), String(preSwap.digest.expected),
    "a faithful forwarding proxy must reach the same verdict (documented limitation)");

// ---------------------------------------------------------------------------
// 3. Anti-tamper: the dual-chain digest matches the build-side mirror, and a
//    rewritten walk order is caught by the second chain.
// ---------------------------------------------------------------------------

const tamperInputs = [
    { label: "ascii-lane", bytes: Buffer.from("ByteVeil lane payload 0123456789abcdef", "ascii"), seed: 0x59A1 },
    { label: "three-bytes", bytes: Buffer.from([1, 2, 3]), seed: 0x59A1 },
    { label: "long-descriptor", bytes: Buffer.from(Array.from({ length: 777 }, (_, i) => (i * 37) % 256)), seed: 0xBEEF },
    { label: "unseeded", bytes: Buffer.from("no seed path", "ascii"), seed: undefined }
];

for (const input of tamperInputs) {
    const built = buildAntiTamperSource({ prefix: `_t${input.label.replace(/[^a-z]/g, "")}`, seed: input.seed });
    assert.doesNotMatch(built.declaration, /Checked fail|tamper detected/i, "anti-tamper must not emit cleartext diagnostics");
    assert.doesNotMatch(built.declaration, /\b(undefined|NaN)\b/, "anti-tamper declaration must not carry a template hole");
    const digest = checksumBytesV2(input.bytes, input.seed);
    assert.equal(digest.length, input.bytes.length, "record length must match the bytes hashed");
    const tableLiteral = `{${Array.from(input.bytes, (byte) => byte).join(",")}}`;
    const checkArgs = `${digest.hash}, ${digest.length}, ${digest.mirror}`;
    const cleanProgram = `${built.declaration}\nprint(${built.names.check}(${tableLiteral}, ${checkArgs}))\n`;

    const cleanResults = RUNTIMES.map((runtimeName) => {
        const result = run(runtimeName, cleanProgram);
        assert.ok(result.ok, `intact payload must verify on ${runtimeName} (${input.label}): ${result.error || result.stderr}`);
        assert.equal(Number(String(result.stdout).trim()), digest.hash,
            `${runtimeName}: validator must return the forward digest the build predicted (${input.label})`);
        counts.matched++;
        return result;
    });
    assert.equal(cleanResults.length, 2);

    const mutations = {
        "one-byte edit": () => {
            const flipped = Buffer.from(input.bytes);
            const index = Math.floor(flipped.length / 2);
            flipped[index] = (flipped[index] + 1) % 256;
            return `${built.declaration}\nprint(${built.names.check}({${Array.from(flipped, (b) => b).join(",")}}, ${checkArgs}))\n`;
        },
        "truncation": () => `${built.declaration}\nprint(${built.names.check}({${Array.from(input.bytes.subarray(0, input.bytes.length - 1), (b) => b).join(",")}}, ${checkArgs}))\n`,
        "mirror loop rewritten to read forward": () => {
            const mutated = built.declaration.replace("__bytes[__count - __i + 1]", "__bytes[__i]");
            assert.notEqual(mutated, built.declaration, "mirror-chain mutation needle must apply");
            return `${mutated}\nprint(${built.names.check}(${tableLiteral}, ${checkArgs}))\n`;
        },
        "forward loop kept, mirror accumulator dropped": () => {
            const mutated = built.declaration.replace(
                `        __mirror = (__mirror * ${checksumBytesV2(input.bytes, input.seed).params.mirrorMult}`,
                `        __mirror = (0 * ${checksumBytesV2(input.bytes, input.seed).params.mirrorMult}`
            );
            assert.notEqual(mutated, built.declaration, "mirror-accumulator mutation needle must apply");
            return `${mutated}\nprint(${built.names.check}(${tableLiteral}, ${checkArgs}))\n`;
        }
    };

    for (const [label, makeProgram] of Object.entries(mutations)) {
        if (input.label === "three-bytes" && label === "truncation") continue;
        for (const runtimeName of RUNTIMES) {
            expectAbort(runtimeName, makeProgram(), `tamper ${input.label} / ${label}`);
        }
    }
}

// ---------------------------------------------------------------------------
// 4. Anti-dump: two-pass erase leaves nothing readable through the table.
// ---------------------------------------------------------------------------

const dumpBuild = buildAntiDumpSource({ prefix: "_d", enabled: true });
assert.doesNotMatch(dumpBuild.declaration, /\b(undefined|NaN)\b/, "anti-dump declaration must not carry a template hole");
const wipeProgram = `${dumpBuild.declaration}
local inner = { secret = "PLAINTEXT-LANE", 1, 2, 3 }
local outer = { lane = "ABCDEF", count = 12, nested = inner, flag = true }
setmetatable(outer, { __index = function() return "meta-leak" end })
local wiped = ${dumpBuild.names.wipe}(outer)
print(wiped, next(outer) == nil, next(inner) == nil, getmetatable(outer) == nil, outer.lane == nil)
`;
for (const runtimeName of RUNTIMES) {
    const result = run(runtimeName, wipeProgram);
    assert.ok(result.ok, `wipe must run on ${runtimeName}: ${result.error || result.stderr}`);
    assert.deepEqual(String(result.stdout).trim().split(/\s+/), ["true", "true", "true", "true", "true"],
        `${runtimeName}: wipe must empty the table, its nested table, and clear the metatable`);
}

// Depth is a documented bound, not an assumption. The walk wipes WIPE_MAX_DEPTH tables
// counting the one handed to it, then only unlinks the reference to the next one, so a
// table past the limit keeps its own contents for anyone holding a separate reference.
assert.ok(dumpBuild.declaration.includes(`__depth = ${WIPE_MAX_DEPTH}`), "emitted wipe must use the module depth bound");
const deepProgram = `${dumpBuild.declaration}
local level4 = { x = "DEEP" }
local level3 = { level4 = level4 }
local level2 = { level3 = level3 }
local level1 = { level2 = level2 }
local root = { level1 = level1 }
${dumpBuild.names.wipe}(root)
print(next(root) == nil, next(level1) == nil, next(level2) == nil, level3.level4 == level4, level4.x)
`;
const deepResult = run("lua", deepProgram);
assert.ok(deepResult.ok, `deep wipe must still run: ${deepResult.error || deepResult.stderr}`);
assert.equal(String(deepResult.stdout).trim().split(/\s+/).join(" "), "true true true true DEEP",
    `the wipe is documented to descend ${WIPE_MAX_DEPTH} tables and stop; a change here must update LIMITATIONS`);

// The Luau buffer branch cannot be exercised here, and the suite records that instead of
// pretending it was covered: `luau.exe` 0.739 does not expose `buffer` at all.
const bufferProbe = run("luau", "print(type(buffer), buffer and type(buffer.new) or 'nil')\n");
assert.ok(bufferProbe.ok, `buffer probe must run: ${bufferProbe.error || bufferProbe.stderr}`);
const bufferShape = String(bufferProbe.stdout).trim().split(/\s+/);
assert.equal(bufferShape[1], "nil",
    `this Luau binary unexpectedly does expose buffer (${JSON.stringify(bufferShape)}): the wipe buffer branch must then be executed here`);
assert.equal(dumpBuild.declaration.includes(`${dumpBuild.names.bufferLib} ~= nil`), true,
    "the buffer branch must stay behind a presence check so a buffer-less host is not broken");

// ---------------------------------------------------------------------------
// 5. The bundle is wired into real builds and the protected program still runs.
// ---------------------------------------------------------------------------

const SAMPLE = `
local NAME = "veil"
function bv_probe(a, b) return a * b + 1 end
bv_public = bv_probe
local total = 0
for i = 1, 4 do total = total + bv_probe(i, i) end
print(NAME, total, bv_public(6, 7))
`;
const sampleBaseline = run("lua", SAMPLE);
assert.ok(sampleBaseline.ok, `unprotected sample must run: ${sampleBaseline.error || sampleBaseline.stderr}`);
const EXPECTED_SAMPLE = String(sampleBaseline.stdout).trim();

const bundle = buildAntiBundle({ seed: 0x59A1, prefix: "_bvanti", mode: "balanced", failClosedOnMissingEnvironment: true, baselineFromEnvironment: true });
assert.ok(bundle.declarations.includes(bundle.helpers.hook.names.probe), "bundle declarations must carry the verdict probe");
assert.equal(bundle.checkpoints.beforeDecode, bundle.helpers.hook.checkCall, "beforeDecode must call the guard");
assert.equal(bundle.metadata.antiHookVerdictDigest, "pure-canary-fold-v59", "verdict digest must be reported");
assert.equal(bundle.metadata.antiHookGuaranteesNoNativeHook, false, "the guard must not claim more than it proves");
assert.equal(bundle.metadata.antiDumpOverwritesSlotsBeforeUnlink, true);
assert.equal(bundle.metadata.antiTamperMirrorChain, true);

let buildsChecked = 0;
for (const preset of ["l1", "lz"]) {
    for (const mode of ["stack", "register"]) {
        for (const seed of [0x59A1, 0xC0FFEE]) {
            const built = obfuscate(SAMPLE, { target: "lua", mode, preset, seed, wrapper: { enabled: false } });
            assert.ok(built.output.length > 100, "build must emit output");
            assert.equal(built.vmMeta.antiHook, true, `${preset}/${mode}/${seed}: hook layer must be active`);
            assert.equal(built.vmMeta.antiHookLayers >= 1, true, "hook layers must be counted");
            const verdict = built.vmMeta.antiHookVerdict;
            assert.ok(verdict, `${preset}/${mode}/${seed}: the build must report the verdict probe wiring`);
            assert.equal(verdict.algorithm, "pure-canary-fold-v59", `${preset}/${mode}/${seed}: verdict algorithm must be reported`);
            // The generator counts the probe on its own source, before the pipeline renames
            // the bundle locals, so this is the emitted code rather than a config echo.
            assert.ok(verdict.probeReferences >= 2, `${preset}/${mode}/${seed}: verdict probe must be declared and called`);
            assert.ok(Number.isInteger(verdict.expectedDigest) && verdict.expectedDigest > 0,
                `${preset}/${mode}/${seed}: the emitted guard must carry a predicted digest`);
            assert.ok(verdict.canaryCount >= 1, `${preset}/${mode}/${seed}: verdict must fold behavioural canaries`);
            assert.equal(built.vmMeta.antiTamperChecksum, "mod65599-dual-chain-lane-and-descriptor",
                `${preset}/${mode}/${seed}: tamper checksum must be the dual-chain record`);
            const result = run("lua", built.output);
            assert.ok(result.ok, `${preset}/${mode}/${seed}: protected sample must run: ${result.error || result.stderr}`);
            assert.equal(String(result.stdout).trim(), EXPECTED_SAMPLE, `${preset}/${mode}/${seed}: semantics changed by the anti bundle`);
            buildsChecked++;
        }
    }
}

for (const target of ["lua", "luau"]) {
    const built = obfuscate(SAMPLE, { target, preset: "lz", mode: "hybrid", seed: 0x59F0ED1 });
    const result = run(target === "lua" ? "lua" : "luau", built.output);
    assert.ok(result.ok, `${target}: junk-forge + anti bundle build must run: ${result.error || result.stderr}`);
    assert.equal(String(result.stdout).trim(), EXPECTED_SAMPLE, `${target}: anti bundle changed program semantics`);
    buildsChecked++;
}

// ---------------------------------------------------------------------------
// 6. The verdict is payload key material: the region root reads it, so a build
//    that drops the addend or fakes the digest loses the ability to decode.
// ---------------------------------------------------------------------------

let bindingsChecked = 0;
const bindingCases = [
    { mode: "stack", seed: 0x59A1, wrapper: false },
    { mode: "register", seed: 0x59A1, wrapper: false },
    { mode: "stack", seed: 0xC0FFEE, wrapper: false },
    { mode: "register", seed: 0xC0FFEE, wrapper: false },
    // The shipped default keeps the callable bootstrap, which re-partitions the chunk, so
    // the verdict holder has to travel inside the runtime function that reads it.
    { mode: "hybrid", seed: 0x59A1, wrapper: true },
    { mode: "register", seed: 0x59F0ED1, wrapper: true }
];
for (const testCase of bindingCases) {
    const label = `${testCase.mode}/0x${testCase.seed.toString(16)}/wrap=${testCase.wrapper}`;
    const built = obfuscate(SAMPLE, {
        target: "lua",
        preset: "l1",
        mode: testCase.mode,
        seed: testCase.seed,
        wrapper: { enabled: testCase.wrapper }
    });
    const binding = built.vmMeta.antiGuardKey;
    assert.equal(built.vmMeta.guardKeyBound, true, `${label}: the verdict must be bound into the payload key`);
    assert.equal(binding.bound, true, `${label}: the generator must report the binding`);
    assert.ok(binding.reads >= 1, `${label}: the emitted holder must be read`);
    assert.ok(Number.isInteger(binding.value) && binding.value > 0, `${label}: the bound addend must be a real number`);

    // The bound expression is anchored by the JunkForge holder, which is created
    // after mangling and therefore keeps its planned name in the shipped body.
    const boundExpression = new RegExp(`\\+${binding.forgeAddend}\\+([A-Za-z_]\\w*)\\)%4294967296`);
    const matches = built.output.match(new RegExp(boundExpression.source, "g")) || [];
    assert.equal(matches.length, 1, `${label}: the shipped body must read the verdict exactly once in the region root`);
    const shippedHolder = /([A-Za-z_]\w*)\)/.exec(matches[0])[1];

    // Attack 1: strip the verdict addend. The key-bed block is untouched, so a check
    // that only proved "the guard ran" would still pass; the payload must not decode.
    const unbound = built.output.replace(boundExpression, `+${binding.forgeAddend})%4294967296`);
    assert.notEqual(unbound, built.output, `${label}: addend-removal mutation needle must apply`);
    expectAbort("lua", unbound, `${label}: region root without the verdict`);

    // Attack 2: retarget the guard's expectation, which is the same as making the
    // guard return a number the serializer never used.
    const forgedLiteral = new RegExp(`~=${binding.value}\\b`);
    assert.ok(forgedLiteral.test(built.output), `${label}: the guard must compare against the bound verdict`);
    const forged = built.output.replace(forgedLiteral, `~=${binding.value + 1}`);
    assert.notEqual(forged, built.output, `${label}: digest-forgery mutation needle must apply`);
    expectAbort("lua", forged, `${label}: guard expectation forged`);

    // Attack 3: keep the guard and its check intact, but never call it - the holder is
    // the only thing the key reads, so pre-loading it with any other number must cost
    // the payload its decode key rather than only skipping a check.
    const holderCall = new RegExp(`local ${shippedHolder}=\\w+\\(\\)`);
    assert.ok(holderCall.test(built.output), `${label}: the holder must be assigned from the guard call`);
    const stubbed = built.output.replace(holderCall, `local ${shippedHolder}=0`);
    assert.notEqual(stubbed, built.output, `${label}: holder-stub mutation needle must apply`);
    expectAbort("lua", stubbed, `${label}: verdict holder stubbed`);

    bindingsChecked++;
}

// A route that cannot keep the holder and the read in one chunk must say so instead of
// shipping a key the runtime can never rebuild.
const nestedBinding = obfuscate(SAMPLE, { target: "lua", mode: "stack", preset: "nest", seed: 0x59A1, wrapper: { enabled: false } });
assert.equal(nestedBinding.vmMeta.guardKeyBound, false, "the nest route must report an unbound verdict key");

console.log(`ByteVeil v5.9 anti-bundle tests: PASS (${buildsChecked} pipeline builds, ${bindingsChecked} verdict-key bindings, ${counts.programs} programs executed, ${counts.matched} build/runtime digest matches, ${counts.aborts} attacks aborted)`);

"use strict";

// ByteVeil v5.9 bitwise-operator suite.
//
// The shipped handlers for BAND/BOR used to write
// `bit32 and bit32.band and bit32.band(A,B) or (function() ...32 rounds... end)(A,B)`. That has two
// defects, and this suite pins both:
//   1. correctness - where bit32 exists (Luau, Roblox, FiveM with bit32) it is called raw, and raw
//      bit32 truncates toward zero: bit32.band(-0.5, 1) is 0. Where it does not exist (plain Lua
//      5.4) the floor loop answered 1, and Lua 5.4's own `-0.5 & 1` raises outright. So the same
//      artifact gave three different answers depending on host. Every bitwise handler now runs on
//      the one avouched xor primitive, whose four rungs are each verified against the floor-first
//      32-bit oracle on the real host before one of them is selected.
//   2. cost - the fallback built a fresh closure and ran 32 modulo/division rounds per execution.
//      Deriving a&b = (a+b-(a^b))/2 and a|b = a+b-(a&b) removes both; the identity is checked
//      exhaustively in scratch/probe_bit_derive.js, and the /2 is floored because Lua 5.4 renders
//      2/1 as "2.0".
//
// Three separate claims, none asserted on the generator's own bookkeeping:
//   A. structural - the emitted chunk carries no 32-round loop and no raw bit32.band/bor call.
//   B. semantics - stack and register builds print the floor-first oracle on lua54 and luau, and
//      all four cells agree with each other (the cross-host agreement is the regression).
//   C. counterfactual - on the real Luau binary, raw bit32.band/bor disagree with that oracle, and
//      native Lua 5.4 errors on the same operands, which proves B is not vacuous.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the bitwise suite");
assert.ok(luau, "Luau native runtime is required for the bitwise suite");

const MOD = 4294967296;
// The contract every rung of the xor chooser is avouched against: floor the operands, wrap into
// [0, 2^32), then operate. Not "whatever the host's bit ops happen to do".
const u32 = (v) => {
    const f = Math.floor(v);
    return ((f % MOD) + MOD) % MOD;
};
// JavaScript's own bitwise operators return a *signed* int32, so `4294967295 | 1` is -1 there.
// The Lua side of this contract is unsigned, hence every expectation goes through and().
const and = (a, b) => (u32(a) & u32(b)) >>> 0;
const or = (a, b) => (u32(a) | u32(b)) >>> 0;
const xor = (a, b) => (u32(a) ^ u32(b)) >>> 0;

// Fractional and negative operands are the point of this list: integers agree under truncate and
// floor alike, so an integer-only corpus would pass on the broken route too.
const CASES = [
    ["6 & 3", and(6, 3)], ["6 | 3", or(6, 3)], ["6 ~ 3", xor(6, 3)],
    ["255 & 15", and(255, 15)], ["255 | 15", or(255, 15)],
    ["4294967295 & 1", and(4294967295, 1)], ["4294967295 | 1", or(4294967295, 1)],
    ["2147483648 & 2147483647", and(2147483648, 2147483647)],
    ["2147483648 | 2147483647", or(2147483648, 2147483647)],
    ["65536 & 65537", and(65536, 65537)], ["65536 | 65537", or(65536, 65537)],
    ["12345 & 54321", and(12345, 54321)], ["12345 | 54321", or(12345, 54321)],
    ["3.7 & 1.2", and(3.7, 1.2)], ["3.7 | 1.2", or(3.7, 1.2)],
    ["-0.5 & 1", and(-0.5, 1)], ["-0.5 | 1", or(-0.5, 1)],
    ["-1 & 255", and(-1, 255)], ["-1 | 0", or(-1, 0)],
    ["-4294967297 & 255", and(-4294967297, 255)],
    ["4294967296 & 1", and(4294967296, 1)], ["4294967296 | 1", or(4294967296, 1)],
    ["4294967295 ~ 1", xor(4294967295, 1)],
];

// Repeated through a loop, so the assertion covers the handler under re-execution rather than only
// a single evaluation at materialise time.
const LOOP_SOURCE = `local acc = 0
for i = 1, 200 do
  acc = ((acc + i) & 65535) | (i & 255)
end
print(acc)
`;
let loopAcc = 0;
for (let i = 1; i <= 200; i++) loopAcc = or(and(loopAcc + i, 65535), and(i, 255));

const oracleSource = CASES.map(([expr]) => `print(${expr})`).join("\n") + "\n";
const oracleWant = CASES.map(([, w]) => String(w)).join("\n");

// A runtime-safe container target("luau") never reaches these handlers, so both hosts execute the
// same custom-VM artifact compiled once per mode. That is what makes the cross-host comparison
// meaningful: identical bytes, different host.
const builds = {};
for (const mode of ["stack", "register"]) {
    builds[mode] = {
        oracle: obfuscate(oracleSource, { mode, preset: "default", target: "lua", seed: 0x59c0de, wrapper: { enabled: true } }).output,
        loop: obfuscate(LOOP_SOURCE, { mode, preset: "default", target: "lua", seed: 0x59c0de, wrapper: { enabled: true } }).output
    };
}

// --- A. structural: the two defects are gone from the emitted chunk, not just from the JS defs ---
for (const [mode, built] of Object.entries(builds)) {
    const text = built.oracle;
    assert.ok(!/for _=1,32/.test(text), `${mode}: the 32-round band/bor loop must not be emitted`);
    assert.ok(!/bit32\.band\s*\(/.test(text), `${mode}: raw bit32.band must not be emitted`);
    assert.ok(!/bit32\.bor\s*\(/.test(text), `${mode}: raw bit32.bor must not be emitted`);
    // The xor primitive the handlers derive from must actually be present, otherwise "no loop"
    // would only mean the bitwise code was dropped. The chooser binds bit32.bxor to a local before
    // calling it, so the rung is matched by name rather than by a call site.
    assert.ok(/bit32\.bxor/.test(text), `${mode}: the avouched xor chooser (bit32.bxor rung) is missing`);
    assert.ok(/\/2\)/.test(text), `${mode}: the derived a&b = (a+b-(a^b))/2 body is missing`);
}

// --- B. semantics: floor-first oracle, four cells, all agreeing ---
const cell = {};
for (const mode of ["stack", "register"]) {
    for (const [name, bin] of [["lua", lua], ["luau", luau]]) {
        const got = runProgram(bin, builds[mode].oracle, name);
        const printed = String(got.stdout || "").trim().replace(/\r/g, "");
        assert.equal(got.status, 0, `${mode}/${name}: artifact exited ${got.status} - ${String(got.stderr).split("\n")[0]}`);
        assert.equal(printed, oracleWant, `${mode}/${name}: bitwise output differs from the floor-first oracle`);
        const loop = runProgram(bin, builds[mode].loop, name);
        const loopPrinted = String(loop.stdout || "").trim().replace(/\r/g, "");
        assert.equal(loop.status, 0, `${mode}/${name}: loop artifact failed - ${String(loop.stderr).split("\n")[0]}`);
        assert.equal(loopPrinted, String(loopAcc), `${mode}/${name}: looped BAND/BOR disagree with the oracle`);
        cell[`${mode}/${name}`] = `${printed}|${loopPrinted}`;
    }
}
const answers = new Set(Object.values(cell));
assert.equal(answers.size, 1, `all four mode/host cells must print the same answer, got ${Object.keys(cell).map((k) => `${k}=${cell[k].split("|")[1]}`).join(" ")}`);

// --- C. counterfactual: the old route really did disagree, on the real binaries ---
// Raw bit32 on Luau truncates, so the pre-fix handler answered 0 where the oracle says 1.
const raw = runProgram(luau, `print(bit32.band(-0.5, 1), bit32.bor(-0.5, 1))`, "luau");
assert.equal(raw.status, 0, `Luau raw bit32 probe must run: ${String(raw.stderr).split("\n")[0]}`);
const rawPair = String(raw.stdout).trim().replace(/\r/g, "");
assert.notEqual(rawPair, `${and(-0.5, 1)} ${or(-0.5, 1)}`,
    "raw bit32.band/bor agreeing with the floor oracle would mean the divergence being fixed is imaginary");

// Native Lua 5.4 refuses the same operand at all, so "just use the host operator" is not an option
// on a floor-first contract; the artifact still has to answer.
const native = runProgram(lua, `print((-0.5) & 1)`, "lua");
assert.notEqual(native.status, 0, "Lua 5.4 was expected to reject & on a fractional operand");

console.log("ByteVeil v5.9 bitwise-operator suite: PASS");
console.log(`  structural: no 32-round loop and no raw bit32.band/bor in either emitted chunk, xor chooser present`);
console.log(`  semantics: ${Object.keys(cell).length} mode/host cells, ${CASES.length} + 1 looped expressions, single shared answer ${JSON.stringify([...answers][0].split("|")[1])}`);
console.log(`  counterfactual: Luau raw bit32.band/bor on (-0.5, 1) prints ${rawPair} where the artifact prints ${and(-0.5, 1)}/${or(-0.5, 1)}; Lua 5.4 native & on the same operand exits ${native.status}`);

"use strict";

// v5.9 VeilBlob-v1 suite: the long-bracket character-code engine that replaced
// the `\ddd` diagnostic escape representation.
//
// Every claim below is execution evidence, not a structural metric: the emitted
// decoder is run under the real Lua 5.4 and Luau binaries and the decoded bytes
// are compared, and tampered blobs must fail closed at runtime.

const assert = require("node:assert/strict");
const {
  BLOB_CHARSET,
  BLOB_MARKER,
  BLOB_BASE,
  createBlobCodec,
  findBlobLiterals,
  stripBlobLiterals,
  renderDiagnosticRuntime
} = require("./src/obfuscation/veil_blob");
const { encodeDiagnosticStrings, encodeDiagnosticStringsBlob, scanDiagnostics } = require("./src/utils/diagnostic_string_encoder");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, runSyntaxCheck } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the VeilBlob suite");
assert.ok(luau, "Luau native runtime is required for the VeilBlob suite");
const RUNTIMES = [["lua", lua], ["luau", luau]];

// --- 1. One unified alphabet for every container class ------------------------
{
  const { UNIFIED_ALPHABET, UNIFIED_BASE } = require("./src/obfuscation/blob_alphabet");
  const { ALPHABET: PAYLOAD_ALPHABET } = require("./src/obfuscation/payload_container_v29");
  assert.equal(BLOB_CHARSET, UNIFIED_ALPHABET, "blob charset must be the shared unified alphabet");
  assert.equal(PAYLOAD_ALPHABET, UNIFIED_ALPHABET, "carrier charset must be the shared unified alphabet");
  assert.equal(BLOB_CHARSET.length, UNIFIED_BASE, "charset is the shared printable range (33..126 without backslash)");
  assert.equal(BLOB_BASE, 93);
  assert.equal(new Set(BLOB_CHARSET).size, 93, "charset must contain no duplicate symbols");
  assert.ok([...BLOB_CHARSET].every((c) => c.codePointAt(0) >= 33 && c.codePointAt(0) <= 126), "charset must stay printable ASCII so long-bracket packing stays byte-exact");
  assert.ok(!/[ \t\r\n]/.test(BLOB_CHARSET), "charset must not contain whitespace");
  // The old split fingerprint: carriers used an alphabet with digits, blobs one
  // without. Both classes must now be able to produce every printable character.
  assert.ok("0123456789".split("").every((digit) => BLOB_CHARSET.includes(digit)), "digits must be part of the blob alphabet");
  const carrierDigits = [...PAYLOAD_ALPHABET].filter((c) => c >= "0" && c <= "9").length;
  assert.ok(carrierDigits > 0 && carrierDigits < PAYLOAD_ALPHABET.length, "carrier alphabet must include digits without being digit-only");
}

// --- 2. Codec roundtrip over every base93 tail residue class ------------------
{
  const payloads = ["", "A", "AB", "ABC", "ABCD", "ByteVeil v4.6.3: tamper detected", "x".repeat(1001), Buffer.from([0, 255, 128, 1, 0, 127, 128])];
  for (const seed of [1, 7, 0xDEADBEEF, 0x581111]) {
    const codec = createBlobCodec(seed);
    for (const payload of payloads) {
      const expected = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), "utf8");
      assert.deepStrictEqual(codec.decodeFromText(codec.encodeToText(payload)), expected, `roundtrip seed=${seed} len=${expected.length}`);
      const rendered = codec.renderBlob(payload);
      assert.match(rendered, /^\[(=*)\[byteveil&/, "blob opens at the requested bracket level or deeper");
      assert.ok(rendered.includes(BLOB_MARKER), "blob carries the container marker");
    }
  }
}

// --- 2b. A container must never close on its own terminator ------------------
// A blob whose text ends in `]==` and the level-2 terminator `]==]` concatenate into
// `]==]==]`. Lua finds a closer three characters before the real one, ends the literal
// inside the ciphertext, and the leftovers (`==]`) are a syntax error in the shipped file.
// This is not hypothetical: a 99 KB source at `df` emitted exactly that artifact and Lua 5.4
// refused to load it (scratch/probe_99kb_df.js) - testing only for a closer *inside* the text
// misses an overlap that only exists across the boundary.
{
  const { renderLongBracket, pickBracketLevel } = require("./src/obfuscation/veil_blob");
  const tails = ["abc", "x]==", "a]==]", "ok]==", "==]==]".repeat(3), `${"q".repeat(200)}]==`, `${BLOB_MARKER}payload]==`];
  for (const text of tails) {
    const label = JSON.stringify(text.slice(0, 14));
    const lit = renderLongBracket(text);
    const eq = /^\[(=*)\[/.exec(lit)[1];
    const closer = `]${eq}]`;
    assert.ok(eq.length >= 2, `${label}: the level must stay at or above the requested minimum`);
    const body = lit.slice(eq.length + 2, lit.length - closer.length);
    assert.equal(body, text, `${label}: literal must carry exactly its text`);
    assert.equal(`${body}${closer}`.indexOf(closer), body.length,
      `${label}: the closer is found ${`${body}${closer}`.indexOf(closer)} B before the terminator, so Lua closes the literal inside the ciphertext`);
    assert.equal(pickBracketLevel(text), eq.length, `${label}: reported level must match the emitted literal`);
    for (const [name, binary] of RUNTIMES) {
      const r = runProgram(binary, `local value=${lit}\nprint(#value)\n`, name);
      assert.ok(r.ok && String(r.stdout).trim() === String(Buffer.byteLength(text, "utf8")),
        `${name}: escalated container must load and keep its bytes (${r.error || r.stderr || r.stdout})`);
    }
  }
  // The shipping path too: no seed and payload length may produce a container whose
  // terminator can be matched early.
  for (const seed of [1, 7, 0x59F0ED1, 0xDEADBEEF]) {
    const codec = createBlobCodec(seed);
    for (let length = 0; length < 48; length++) {
      for (const filler of [0x5d, 0x3d, 0x5b]) {
        const lit = codec.renderBlob(Buffer.alloc(length, filler));
        const eq = /^\[(=*)\[/.exec(lit)[1];
        const closer = `]${eq}]`;
        const body = lit.slice(eq.length + 2, lit.length - closer.length);
        assert.equal(`${body}${closer}`.indexOf(closer), body.length,
          `seed=${seed} len=${length} filler=${filler}: container terminator is matchable before the real one`);
        assert.deepStrictEqual(codec.decodeFromText(body.slice(BLOB_MARKER.length)), Buffer.alloc(length, filler),
          `seed=${seed} len=${length} filler=${filler}: escalated container must still decode byte-exactly`);
      }
    }
  }
}

// --- 3. Emitted runtime decodes byte-exactly under Lua 5.4 and Luau -----------
function byteDumpProgram(getName, count) {
  const parts = [];
  for (let i = 1; i <= count; i++) parts.push(`(function()local s=${getName}(${i})local t={}for j=1,#s do t[j]=string.byte(s,j)end return table.concat(t,",")end)()`);
  return `print(table.concat({${parts.join(",")}},"|"))`;
}

{
  const entries = [
    "ByteVeil v4.6.3: tamper detected",
    "payload lane missing",
    "a\u0000b\u0000c",
    "\u00e9\u2212\ufffd high bytes",
    "",
    "x".repeat(300)
  ];
  // Accessor indices are permuted per build, so the assertion is that the set of
  // decoded values is exactly the entry set, byte for byte, on every runtime.
  const expected = entries.map((e) => [...Buffer.from(e, "utf8")].join(",")).sort();
  for (const seed of [0xB16B00B5, 0x590001, 0x590002]) {
    const runtime = renderDiagnosticRuntime({ seed, entries, decoys: 2, usedNames: [], errorCodes: [4400111, 4400222] });
    assert.doesNotMatch(runtime.prelude, /[\r\n]/, "blob prelude must stay on one line so bodyOneLine holds");
    const program = `${runtime.prelude}${byteDumpProgram(runtime.get, entries.length)}`;
    for (const [rtName, rt] of RUNTIMES) {
      const syntax = runSyntaxCheck(rt, program, rtName);
      assert.ok(syntax.ok, `${rtName}: prelude must parse: ${syntax.stderr || syntax.error}`);
      const run = runProgram(rt, program, rtName);
      assert.ok(run.ok, `${rtName} seed=${seed} decoder run failed: ${run.stderr || run.error}`);
      const decoded = run.stdout.trim().split("|").sort();
      assert.equal(decoded.length, expected.length, `${rtName} seed=${seed}: every accessor index must yield a string`);
      assert.deepEqual(decoded, expected, `${rtName} seed=${seed} decoded bytes mismatch`);
    }
  }
}

// --- 4. Out-of-range access and tampering must fail closed at runtime --------
{
  const entries = ["descriptor header", "graph cycle", "region integrity"];
  const runtime = renderDiagnosticRuntime({ seed: 0x590101, entries, decoys: 1, usedNames: [], errorCodes: [4410111, 4410222] });
  for (const [rtName, rt] of RUNTIMES) {
    const oob = runProgram(rt, `${runtime.prelude}print(${runtime.get}(99))`, rtName);
    assert.equal(oob.ok, false, `${rtName}: out-of-range diagnostic index must fail closed`);

    const blobStart = runtime.prelude.indexOf(BLOB_MARKER) + BLOB_MARKER.length;
    const original = runtime.prelude[blobStart];
    const mutatedChar = original === "Q" ? "z" : "Q";
    const mutated = `${runtime.prelude.slice(0, blobStart)}${mutatedChar}${runtime.prelude.slice(blobStart + 1)}`;
    assert.notEqual(mutated, runtime.prelude, "mutation must change the blob");
    const tamperedRun = runProgram(rt, `${mutated}${byteDumpProgram(runtime.get, entries.length)}`, rtName);
    assert.equal(tamperedRun.ok, false, `${rtName}: single-character blob tamper must fail closed`);

    // Corrupting an alphabet fragment must also fail closed: the reverse map
    // would otherwise silently decode the whole manifest into different bytes.
    const fragStart = runtime.prelude.indexOf("[") ;
    const fragOpenEnd = runtime.prelude.indexOf("[", fragStart + 1) + 1;
    const fragChar = runtime.prelude[fragOpenEnd];
    const fragMutated = `${runtime.prelude.slice(0, fragOpenEnd)}${fragChar === "Q" ? "z" : "Q"}${runtime.prelude.slice(fragOpenEnd + 1)}`;
    const fragRun = runProgram(rt, `${fragMutated}${byteDumpProgram(runtime.get, entries.length)}`, rtName);
    assert.equal(fragRun.ok, false, `${rtName}: alphabet fragment tamper must fail closed`);
  }
}

// --- 5. Representation parity: the runtime string must not change -------------
{
  const fixture = 'local marker = "ByteVeil v4.6.3: tamper detected"; print(#marker); error("payload lane missing", 0)';
  const baseline = runProgram(lua, fixture, "lua");
  assert.ok(!baseline.ok, "fixture is expected to raise the diagnostic error");
  const decimal = encodeDiagnosticStrings(fixture, { mode: "decimal" });
  const blob = encodeDiagnosticStrings(fixture, { mode: "blob", seed: 0x590202 });
  assert.equal(decimal.mode, "decimal");
  assert.equal(blob.mode, "VeilBlob-v1");
  assert.equal(blob.encoded, decimal.encoded);
  assert.ok(blob.encoded >= 2, "fixture must contain recognizable diagnostics");
  assert.match(blob.source, /\[[=]+\[byteveil&/, "blob route must emit the container literal");
  assert.doesNotMatch(blob.source, /\\[0-9]{3}/, "blob route must not leave decimal escapes");
  assert.ok(!blob.source.includes('"payload lane missing"'), "diagnostic must not remain a plain literal");
  for (const [label, program] of [["decimal", decimal.source], ["blob", blob.source]]) {
    const syntax = runSyntaxCheck(lua, program, "lua");
    assert.ok(syntax.ok, `${label} fixture must parse: ${syntax.stderr}`);
    const run = runProgram(lua, program, "lua");
    assert.equal(run.stdout.trim(), baseline.stdout.trim(), `${label}: string byte length must survive encoding`);
    assert.ok(String(run.stderr).includes("payload lane missing"), `${label}: runtime error text must be identical to the original`);
  }
}

// --- 6. Pipeline integration --------------------------------------------------
{
  const source = "local a = 10; local b = 20; print(a + b)";
  for (const [preset, seed] of [["l1", 0x590301], ["l2", 0x590302], ["df", 0x590303]]) {
    const built = obfuscate(source, { preset, seed });
    assert.equal(built.stats.diagnosticEncodingMode, "VeilBlob-v1", `${preset}: diagnostics must use the blob engine`);
    assert.ok(built.stats.diagnosticStringsEncoded >= 1, `${preset}: expected encoded diagnostics`);
    assert.ok(built.vmMeta.diagnosticEncoding.blobBytes > 0, `${preset}: blob size must be reported`);
    const body = built.output.split("\n").slice(1).join("\n");
    assert.doesNotMatch(body, /\\[0-9]{3}/, `${preset}: \\ddd diagnostic escapes must be gone`);
    assert.doesNotMatch(body, /then\s+error\s*\(/i, `${preset}: blob runtime must not expose a then error(...) guard signature`);
    assert.match(body, /\[[=]+\[byteveil&/, `${preset}: VeilBlob container must be present`);
    assert.ok(!/[\r\n]/.test(built.output.split("\n").slice(1).join("")), `${preset}: body stays a single line`);
    for (const [rtName, rt] of RUNTIMES) {
      const run = runProgram(rt, built.output, rtName);
      assert.ok(run.ok, `${preset}/${rtName}: blob build failed to run: ${run.stderr || run.error}`);
      assert.equal(run.stdout.trim(), "30", `${preset}/${rtName}: blob build output mismatch`);
    }
  }
}

// --- 7. Per-build variation and determinism ----------------------------------
{
  const source = "local a = 10; local b = 20; print(a + b)";
  const a1 = obfuscate(source, { preset: "l1", seed: 0x590401 });
  const a2 = obfuscate(source, { preset: "l1", seed: 0x590401 });
  const b1 = obfuscate(source, { preset: "l1", seed: 0x590402 });
  assert.equal(a1.output, a2.output, "a fixed seed must reproduce the blob build byte-for-byte");
  assert.notEqual(a1.output, b1.output, "the blob alphabet, key and names must change with the build seed");
  const blobOf = (out) => findBlobLiterals(out).map((b) => b.text);
  assert.ok(blobOf(a1.output).length >= 2, "payload blob plus at least one decoy must be emitted");
  // Blob length tracks manifest size, so two builds of the same program can share
  // it; the ciphertext itself must still differ (alphabet and key are per seed).
  assert.notDeepEqual(blobOf(a1.output), blobOf(b1.output), "per-build blob ciphertext must differ");
  assert.deepEqual(blobOf(a1.output), blobOf(a2.output), "fixed seed must reproduce identical ciphertext");
}

// --- 8. Decoys are real blobs that no code reads ------------------------------
{
  const entries = ["runtime bridge unavailable", "state machine miss"];
  // The VM's own short constants (I1/I3/O1/A1) and any per-build display label
  // spilling into generated identifiers must never be shadowed by the blob
  // runtime: a collision silently rewrites instruction semantics.
  const reservedIdentifiers = ["print", "state", "G", "I1", "I2", "I3", "I4", "O1", "A1", "i30", "i3_0", "i3o", "Veil", "veil"];
  const runtime = renderDiagnosticRuntime({ seed: 0x590501, entries, decoys: 3, usedNames: reservedIdentifiers, errorCodes: [4450111, 4450222] });
  assert.equal(runtime.decoyLiterals.length, 3, "requested decoy count must be emitted");
  const codec = createBlobCodec(0x590501);
  for (const decoy of runtime.decoyLiterals) {
    assert.match(decoy, new RegExp(`^\\[=+\\[${BLOB_MARKER}`), "decoy must be structurally identical to a payload blob");
    const text = decoy.replace(/^\[=+\[/, "").replace(/\]=+\]$/, "").slice(BLOB_MARKER.length);
    // A decoy decodes as a valid frame, so a scraper cannot separate it from the
    // real manifest without running the decoder and reading the accessor table.
    assert.ok(codec.decodeFromText(text).length > 0, "decoy must decode like a genuine blob");
  }
  const referenced = runtime.prelude.split(runtime.get).length - 1;
  assert.equal(referenced, 1, "only the accessor declaration may carry the public runtime name");
  const generatedNames = [...runtime.names.frag, runtime.names.alpha, runtime.names.map, runtime.names.dec, runtime.names.manifest,
    runtime.names.table, runtime.names.cursor, runtime.names.perm, runtime.names.raise, runtime.names.get];
  assert.equal(new Set(generatedNames).size, generatedNames.length, "blob runtime names must be mutually distinct");
  for (const banned of reservedIdentifiers) {
    assert.ok(!generatedNames.includes(banned), `generated names must not reuse the existing identifier ${banned}`);
    assert.ok(!runtime.prelude.includes(`local ${banned}=`), `generated names must avoid the reserved identifier ${banned}`);
  }
}

// --- 9. Substitution must stay token-safe ------------------------------------
{
  // Minified VM bodies legally write `x or"payload lane missing"` with no gap,
  // because a quote is self-delimiting. Swapping that literal for an
  // identifier-led accessor must not fuse it into the invalid `or<accessor>`.
  const abutting = 'local function f(g)return g or"payload lane missing"end;print(f(false))';
  const blobbed = encodeDiagnosticStringsBlob(abutting, { seed: 0x590601 });
  assert.equal(blobbed.mode, "VeilBlob-v1", "abutted literal must still take the blob route");
  // Ciphertext is base93, so keyword adjacency is only judged on the code left
  // outside the blobs.
  const codeOnly = stripBlobLiterals(blobbed.source);
  assert.match(codeOnly, /\bor [A-Za-z_][A-Za-z0-9_]*\(/, "accessor after `or` must keep its separator");
  for (const [rtName, rt] of RUNTIMES) {
    const check = runSyntaxCheck(rt, blobbed.source, rtName);
    assert.ok(check.ok, `${rtName}: token-safe substitution produced invalid syntax: ${check.stderr || check.error}`);
    const run = runProgram(rt, blobbed.source, rtName);
    assert.ok(run.ok, `${rtName}: abutted-literal blob build failed to run: ${run.stderr || run.error}`);
    assert.equal(run.stdout.trim(), "payload lane missing", `${rtName}: abutted-literal build changed the runtime string`);
  }

  // The nest preset emits no watermark, so the runtime is spliced at offset 0 in
  // front of a single minified statement; that path must still execute.
  const nested = obfuscate('print("nest-ok", 2+3)', { target: "lua", preset: "nest", mode: "stack", seed: 0x55AA, wrapper: { enabled: false }, transforms: { watermark: false } });
  assert.equal(nested.stats.diagnosticEncodingMode, "VeilBlob-v1", "watermark-free builds must still use the blob engine");
  // Nest keeps its own legacy `\ddd` byte escapes inside the wrapped carrier
  // string, so the honest claim is that no diagnostic *literal* survives: the
  // same scanner the encoder uses must find nothing readable left.
  assert.equal(scanDiagnostics(stripBlobLiterals(nested.output)).literals.length, 0, "nest diagnostics must not survive as cleartext literals");
  assert.ok(findBlobLiterals(nested.output).length >= 2, "nest must emit a manifest blob plus a decoy");
  for (const [rtName, rt] of RUNTIMES) {
    const run = runProgram(rt, nested.output, rtName);
    assert.ok(run.ok, `${rtName}: nest preset blob build failed to run: ${run.stderr || run.error}`);
    assert.equal(run.stdout.trim(), "nest-ok\t5", `${rtName}: nest preset blob build output mismatch`);
  }
}

// --- 10. Payload carriers travel as VeilBlob containers -----------------------
{
  const { ALPHABET: PAYLOAD_ALPHABET } = require("./src/obfuscation/payload_container_v29");
  const carrierRe = /\[\d+\]=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\(/g;
  const quotedCarrierRe = /\[\d+\]=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\("/g;
  for (const seed of [0x590701, 0x590702]) {
    const built = obfuscate("local function add(a,b) return a+b end; print(add(2,3))", { preset: "l1", seed });
    const blobCarriers = [...built.output.matchAll(carrierRe)];
    assert.ok(blobCarriers.length >= 8, `seed=${seed}: carriers must be read from VeilBlob containers (got ${blobCarriers.length})`);
    assert.equal(built.output.match(quotedCarrierRe), null, `seed=${seed}: no carrier may keep the legacy quoted form`);
    // Carrier containers must hold only payload-alphabet bytes after the marker,
    // and the marker can never occur inside a carrier (the payload alphabet has no
    // `y`), so each container boundary is unambiguous. Anchoring on the carrier
    // call itself matters: the diagnostic manifest is also read through
    // `string.sub(`, so a prefix-only filter would silently count it as a carrier.
    const carrierBlobs = [];
    for (const carrier of blobCarriers) {
      const literalAt = carrier.index + carrier[0].length;
      const blob = findBlobLiterals(built.output).find((b) => b.start === literalAt);
      assert.ok(blob, `seed=${seed}: carrier call must open its container immediately`);
      carrierBlobs.push(blob);
    }
    assert.equal(carrierBlobs.length, blobCarriers.length, `seed=${seed}: every carrier must open a VeilBlob container`);
    for (const blob of carrierBlobs) {
      const closer = blob.text.match(/\](=+)\]$/)[1];
      const body = blob.text.slice(blob.text.indexOf(BLOB_MARKER) + BLOB_MARKER.length, blob.text.length - closer.length - 2);
      assert.ok(body.length > 0, `seed=${seed}: carrier container must not be empty`);
      assert.ok([...body].every((ch) => PAYLOAD_ALPHABET.includes(ch)), `seed=${seed}: carrier body must stay inside the payload alphabet`);
    }
    for (const [rtName, rt] of RUNTIMES) {
      const run = runProgram(rt, built.output, rtName);
      assert.ok(run.ok, `${rtName}: seed=${seed} carrier-blob build failed to run: ${run.stderr || run.error}`);
      assert.equal(run.stdout.trim(), "5", `${rtName}: seed=${seed} carrier-blob build changed semantics`);
    }
    // Ablation still fails closed now that the literal is a container.
    const target = carrierBlobs[0].text;
    const at = target.indexOf(BLOB_MARKER) + BLOB_MARKER.length;
    const mutated = built.output.replace(target, `${target.slice(0, at)}${target[at] === "!" ? "#" : "!"}${target.slice(at + 1)}`);
    assert.notEqual(mutated, built.output, "carrier byte flip must modify the output");
    for (const [rtName, rt] of RUNTIMES) {
      assert.equal(runProgram(rt, mutated, rtName).ok, false, `${rtName}: flipped carrier byte must fail closed`);
    }
  }
}

// --- 11. Unused char-code source sits at the tail and is provably dead --------
{
  // Luraph 15.1 model (`1.txt`, `z=[=[LPH...]=]` / `x=[==[LPH...]==]`): blob-shaped
  // char-code containers bound to locals nothing reads. ByteVeil emits the same
  // shape as the *last* field of the bootstrap metatable, i.e. after the `end` of
  // the `__call` slot, under a numeric key the VM never indexes.
  const source = "local a = 10; local b = 20; print(a + b)";
  const built = obfuscate(source, { preset: "l1", seed: 0x591001 });
  const tailAnchor = built.output.indexOf("__metatable=false,");
  assert.ok(tailAnchor > 0, "bootstrap metatable tail must be present");
  const decoyAnchor = tailAnchor + "__metatable=false,".length;
  // `findBlobLiterals` resolves the closer by bracket level; a lazy `]=+]` regex
  // would stop at an `]=]` sequence that is merely payload inside a `[==[...]==]`.
  const decoyBlob = findBlobLiterals(built.output).find((blob) => blob.start > decoyAnchor);
  assert.ok(decoyBlob, "a VeilBlob decoy container must follow `__metatable=false`");
  const decoyKey = /^\[(\d+)\]=$/.exec(built.output.slice(decoyAnchor, decoyBlob.start))[1];
  const decoyLiteral = decoyBlob.text;
  assert.ok(decoyLiteral.length > 30, "decoy must carry a real-length container, not a stub");

  // Structurally indistinguishable from a payload container: marker, escalating
  // bracket level, base93-only body, and a group layout the codec can pack.
  const body = decoyLiteral.replace(/^\[=+\[/, "").replace(/\]=+\]$/, "").slice(BLOB_MARKER.length);
  assert.ok([...body].every((ch) => BLOB_CHARSET.includes(ch)), "decoy body must stay inside the unified charset");
  assert.notEqual(body.length % 4, 1, "decoy body must be a valid base93 group layout");

  // Dead: the key occurs exactly once in the whole output.
  const keyUses = (built.output.match(new RegExp(`\\[${decoyKey}\\]`, "g")) || []).length;
  assert.equal(keyUses, 1, "decoy key must be declared once and never read");

  // Execution proof that it is unused: dropping the field changes nothing.
  const withoutDecoy = built.output.replace(`,[${decoyKey}]=${decoyLiteral}`, "");
  assert.notEqual(withoutDecoy, built.output, "decoy field must be removable");
  for (const [rtName, rt] of RUNTIMES) {
    const run = runProgram(rt, withoutDecoy, rtName);
    assert.ok(run.ok, `${rtName}: build without the decoy failed: ${run.stderr || run.error}`);
    assert.equal(run.stdout.trim(), "30", `${rtName}: decoy removal changed semantics`);
  }

  // Per-build variation, reproducible per seed.
  const sameSeed = obfuscate(source, { preset: "l1", seed: 0x591001 });
  assert.equal(sameSeed.output, built.output, "fixed seed must reproduce the decoy");
  const otherSeed = obfuscate(source, { preset: "l1", seed: 0x591002 });
  assert.notEqual(otherSeed.output.slice(tailAnchor), built.output.slice(tailAnchor), "decoy key and ciphertext must vary per seed");
}

// --- 12. Unused char-code sources scattered among the live carriers ------------
{
  // Sample parity: in `1.txt` the `LPH` containers are bound to names interleaved
  // between the `function()...end` fields, so blob count and reader count disagree.
  // ByteVeil splices the same shape into the carrier bed, under bank slots that
  // neither the lane map nor the descriptor map names.
  const source = "local a = 10; local b = 20; print(a + b)";
  const assignmentRe = /([A-Za-z_][A-Za-z0-9_]*)\[(\d+)\]=$/;
  const liveCarrierRe = /\[\d+\]=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\(/g;
  for (const seed of [0x591201, 0x591202]) {
    const built = obfuscate(source, { preset: "l1", seed });
    const dead = [];
    for (const blob of findBlobLiterals(built.output)) {
      // A decoy is a container the code assigns raw; live carriers wrap theirs in
      // `string.sub(...)`, so nothing precedes a decoy but the bank's `[slot]=`.
      const lhs = built.output.slice(Math.max(0, blob.start - 40), blob.start).match(assignmentRe);
      if (lhs) dead.push({ bank: lhs[1], slot: lhs[2], text: blob.text });
    }
    assert.ok(dead.length >= 2, `seed=${seed}: the carrier bed must hold unused containers (got ${dead.length})`);
    const liveCarriers = (built.output.match(liveCarrierRe) || []).length;
    assert.ok(dead.length < liveCarriers, `seed=${seed}: decoys must stay a minority of the carrier bed`);

    // Slot keys are written once and never read. The count runs on the stripped
    // body because a `[123]` sequence can occur inside another container's payload.
    const code = stripBlobLiterals(built.output);
    for (const entry of dead) {
      assert.equal((code.match(new RegExp(`\\[${entry.slot}\\]`, "g")) || []).length, 1,
        `seed=${seed}: decoy slot ${entry.slot} must be declared once and never read`);
      const body = entry.text.replace(/^\[=+\[/, "").replace(/\]=+\]$/, "").slice(BLOB_MARKER.length);
      assert.ok(body.length > 16, `seed=${seed}: decoy container must carry a real-length body`);
      assert.ok([...body].every((ch) => BLOB_CHARSET.includes(ch)), `seed=${seed}: decoy body must stay inside the unified charset`);
      assert.notEqual(body.length % 4, 1, `seed=${seed}: decoy body must be a valid base93 group layout`);
    }

    // Execution proof of deadness: every scattered container can be replaced by a
    // constant and the program still runs with identical output. The padding space
    // matters: the minifier omits separators after a long-bracket string because it
    // is self-delimiting, so a bare digit would fuse into `1local`.
    let withoutDecoys = built.output;
    for (const entry of dead) {
      const field = `${entry.bank}[${entry.slot}]=${entry.text}`;
      assert.ok(withoutDecoys.includes(field), `seed=${seed}: decoy assignment must be a standalone statement`);
      withoutDecoys = withoutDecoys.replace(field, `${entry.bank}[${entry.slot}]=1 `);
    }
    assert.notEqual(withoutDecoys, built.output, `seed=${seed}: decoys must be removable`);
    for (const [rtName, rt] of RUNTIMES) {
      const run = runProgram(rt, withoutDecoys, rtName);
      assert.ok(run.ok, `${rtName}: seed=${seed} build without scattered decoys failed: ${run.stderr || run.error}`);
      assert.equal(run.stdout.trim(), "30", `${rtName}: decoy removal changed semantics`);
    }

    const sameSeed = obfuscate(source, { preset: "l1", seed });
    assert.equal(sameSeed.output, built.output, `seed=${seed}: fixed seed must reproduce the decoy set`);
  }
  const a = obfuscate(source, { preset: "l1", seed: 0x591201 }).output;
  const b = obfuscate(source, { preset: "l1", seed: 0x591202 }).output;
  assert.notEqual(a, b, "decoy slots and ciphertext must vary per seed");
}

console.log("v5.9 VeilBlob-v1 suite: PASS (charset, codec roundtrip, Lua+Luau decode parity, tamper fail-closed, pipeline integration, token-safe substitution, carrier containers, trailing unused blob, scattered carrier-bed decoys)");

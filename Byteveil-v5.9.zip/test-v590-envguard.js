"use strict";

// ByteVeil v5.9 environment-logger resistance suite.
//
// The attack modelled here is the one a "dump the environment" helper uses: install a
// logging layer over the global table *before* the protected chunk runs, so every name
// the VM reads or writes is recorded. The defence is the runtime guard's provenance
// check on the environment metatable: a genuine host environment forwards to native
// library implementations, an instrumented one is a Lua closure.
//
// Everything asserted below is execution evidence: the mutated host is run under the
// real Lua 5.4 binary (and Luau where the platform allows the attack at all).

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram, getRuntimeVersion } = require("./tools/native-runtime");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the environment-guard suite");
assert.ok(luau, "Luau native runtime is required for the environment-guard suite");

const SAMPLE = `
local NAME = "veil"
function bv_probe(a, b) return a * b + 1 end
bv_public = bv_probe
local total = 0
for i = 1, 4 do total = total + bv_probe(i, i) end
print(total)
`;

// The reference output is measured from the unprotected sample, never assumed.
const baseline = runProgram(lua, SAMPLE, "lua");
assert.ok(baseline.ok, `unprotected sample must run: ${baseline.error || baseline.stderr}`);
const EXPECTED = baseline.stdout.trim();
assert.ok(EXPECTED.length > 0, "unprotected sample produced no output");

// The protected chunk is embedded as a long-bracket literal so the host can install the
// attack first and only then compile the target. Bracket level is chosen so no container
// inside the target can close it early.
function embed(source) {
  for (let level = 2; level <= 14; level++) {
    const closer = `]${"=".repeat(level)}]`;
    if (!source.includes(closer)) return `[${"=".repeat(level)}[${source}${closer}`;
  }
  throw new Error("no free long-bracket level to embed the target chunk");
}

const HOSTS = {
  // Baseline: same host, same embedding, no instrumentation.
  control: (target) => `local chunk = (loadstring or load)(${embed(target)}, "target")
local ok, err = pcall(chunk)
print("GUARD", ok, tostring(err))`,

  // _G gets a logging metatable: __index records reads that miss the table, __newindex
  // records every global the protected script creates. The handlers must be raw fields of
  // the metatable, otherwise Lua never dispatches the events and the attack tests nothing.
  globalLogger: (target) => `local real = _G
local log = {}
local meta = setmetatable({}, {})
meta.__index = function(_, key) log[#log + 1] = "@" .. tostring(key); return rawget(real, key) end
meta.__newindex = function(_, key, value) log[#log + 1] = "=" .. tostring(key); rawset(real, key, value) end
local installed = pcall(setmetatable, real, meta)
if not installed or getmetatable(real) ~= meta then print("ATTACK-UNAVAILABLE") return end
local chunk = (loadstring or load)(${embed(target)}, "target")
local ok, err = pcall(chunk)
setmetatable(real, nil)
print("GUARD", ok, tostring(err))
print("WITNESSED", #log)`,

  // Standard library replaced with recording Lua closures before the chunk is compiled.
  stdlibLogger: (target) => `local seen = {}
local sub, concat, byte = string.sub, table.concat, string.byte
string.sub = function(s, i, j) seen[#seen + 1] = sub(s, 1, 6); return sub(s, i, j) end
table.concat = function(l, s, i, j) seen[#seen + 1] = "cat"; return concat(l, s, i, j) end
string.byte = function(s, p, q) seen[#seen + 1] = "byte"; return byte(s, p, q) end
local chunk = (loadstring or load)(${embed(target)}, "target")
local ok, err = pcall(chunk)
print("GUARD", ok, tostring(err))
print("WITNESSED", #seen)`,

  // A logging environment hook (which the guard must reject) combined with a neutralised
  // `error`, so a tripped guard would return instead of aborting. The guard has to stop the
  // program through its own VM-intrinsic trap even then.
  guardBypass: (target) => `local real = _G
local log = {}
local stubbed = 0
error = function() stubbed = stubbed + 1 end
local meta = setmetatable({}, {})
meta.__index = function(_, key) log[#log + 1] = "@" .. tostring(key); return rawget(real, key) end
meta.__newindex = function(_, key, value) log[#log + 1] = "=" .. tostring(key); rawset(real, key, value) end
local installed = pcall(setmetatable, real, meta)
if not installed or getmetatable(real) ~= meta then print("ATTACK-UNAVAILABLE") return end
local chunk = (loadstring or load)(${embed(target)}, "target")
local ok, err = pcall(chunk)
setmetatable(real, nil)
print("GUARD", ok, tostring(err))
print("WITNESSED", #log)
print("STUBBED", stubbed)`
};

function run(hostSource, runtime, label) {
  const result = runProgram(runtime, hostSource, label);
  assert.ok(!result.error, `${label} host failed to launch: ${result.error}`);
  const combined = `${result.stdout || ""}${result.stderr || ""}`;
  const guard = /GUARD\s+(true|false)/.exec(combined);
  const witnessed = /WITNESSED\s+(\d+)/.exec(combined);
  const stubbed = /STUBBED\s+(\d+)/.exec(combined);
  return {
    ok: result.ok,
    ran: guard ? guard[1] === "true" : null,
    witnessed: witnessed ? Number(witnessed[1]) : null,
    stubbed: stubbed ? Number(stubbed[1]) : null,
    unavailable: /ATTACK-UNAVAILABLE/.test(combined),
    output: (result.stdout || "").trim(),
    combined
  };
}

const builds = [];
for (const mode of ["stack", "register"]) {
  for (const seed of [4242, 90210]) {
    const built = obfuscate(SAMPLE, { preset: "lz", mode, seed });
    assert.ok(built && built.output.length > 1000, "sample build must be produced");
    builds.push({ mode, seed, output: built.output });
  }
}

// --- control: the embedding/host itself must not interfere ---------------------------
for (const build of builds) {
  for (const [label, runtime] of [["lua", lua], ["luau", luau]]) {
    const outcome = run(HOSTS.control(build.output), runtime, label);
    assert.ok(outcome.output.includes(EXPECTED), `control run lost the program output (${label} ${build.mode}/${build.seed}): ${outcome.combined.slice(0, 200)}`);
  }
}

// --- Lua 5.4: instrumented environments must fail closed, with the guard's own reason ----
const EXPECTED_REASON = {
  globalLogger: /environment (index logger|index supply hook|write hook) detected/,
  stdlibLogger: /runtime API provenance mismatch/,
  guardBypass: /attempt to index a nil value/
};
const luaEvidence = {};
for (const attack of Object.keys(EXPECTED_REASON)) {
  let failed = 0, reasoned = 0, leaked = 0;
  for (const build of builds) {
    const outcome = run(HOSTS[attack](build.output), lua, "lua");
    assert.ok(!outcome.unavailable, `${attack} attack must be installable on Lua 5.4`);
    assert.equal(outcome.ran, false, `${attack} attack survived on Lua 5.4 (${build.mode}/${build.seed}): ${outcome.combined.slice(0, 200)}`);
    assert.ok(!outcome.output.split("\n").includes(EXPECTED), `${attack} attack produced the cleartext program output (${build.mode}/${build.seed})`);
    if (EXPECTED_REASON[attack].test(outcome.combined)) reasoned++;
    if (attack === "guardBypass") assert.ok(outcome.stubbed > 0, `guardBypass must reach the neutralised error (${build.mode}/${build.seed}): ${outcome.combined.slice(0, 200)}`);
    leaked += (outcome.witnessed || 0);
  }
  luaEvidence[attack] = { builds: builds.length, failedClosed: failed + builds.length, withGuardReason: reasoned, witnessReads: leaked };
}

// --- Luau: report what the platform allows, then assert the invariant -------------------
const luauEvidence = { globalLogger: [], stdlibLogger: [], guardBypass: [] };
const luauRefused = { globalLogger: 0, stdlibLogger: 0, guardBypass: 0 };
for (const attack of Object.keys(EXPECTED_REASON)) {
  for (const build of builds) {
    const outcome = run(HOSTS[attack](build.output), luau, "luau");
    // Either the host declares the attack unavailable, or it died before the protected
    // chunk ever started (Luau refuses writes to the stdlib tables): in both cases the
    // attack does not exist on that platform and must not be counted as a defence.
    if (outcome.unavailable || outcome.ran === null) {
      luauRefused[attack]++;
      continue;
    }
    luauEvidence[attack].push({ mode: build.mode, seed: build.seed, blocked: !outcome.ran, witnessed: outcome.witnessed });
  }
}
// Where Luau accepts the instrumentation, the build must either stop running or give the
// hook nothing: a host that keeps executing while witnessing script names is a leak.
for (const [attack, records] of Object.entries(luauEvidence)) {
  for (const record of records) {
    assert.ok(record.blocked || record.witnessed === 0,
      `Luau accepted ${attack}, the build kept running, and the hook witnessed names (${record.mode}/${record.seed})`);
  }
}

const reasonSummary = Object.keys(EXPECTED_REASON)
  .map((attack) => `${attack} ${luaEvidence[attack].withGuardReason}/${builds.length}`)
  .join(", ");
const luauSummary = Object.entries(luauEvidence)
  .map(([attack, records]) => `${attack} accepted ${records.length}/${builds.length}, refused ${luauRefused[attack]}/${builds.length}`)
  .join("; ");
console.log(`ByteVeil v5.9 environment-logger suite: PASS (${builds.length} builds x 3 attacks;`
  + ` Lua 5.4 fail-closed ${Object.values(luaEvidence).map((e) => e.failedClosed).join("/")}`
  + `; guard reason surfaced ${reasonSummary}`
  + `; Luau ${getRuntimeVersion(luau) || "unknown"}: ${luauSummary})`);

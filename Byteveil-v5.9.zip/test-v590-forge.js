"use strict";

// ByteVeil v5.9 JunkForge density suite.
//
// JunkForge pads the emitted body with `[==[byteveil&...]==]` containers until the file
// reaches the preset floor, and every one of those containers is load-bearing: the block
// that holds them re-computes a digest over their lengths, sampled bytes and bank
// character-class counts at load time and aborts before the payload runs if anything was
// removed, shortened or edited. The block also returns a folded digest of five key-bed
// containers, and the VM adds that number to the seed every region key is derived from, so
// deleting the block costs the payload its decode key instead of only shrinking the file.
// This suite checks the whole claim from the outside - a measured byte envelope per preset
// and per target, container telemetry that matches the real text, and fail-closed mutation
// censuses executed on the native Lua 5.4 and Luau binaries.
//
// Nothing here is assumed: floors, budgets and padding byte counts are compared against what
// the engine reports for the build, and the unpadded cost is measured from the same build
// with the forge switched off.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");
const { findBlobLiterals, stripBlobLiterals } = require("./src/obfuscation/veil_blob");
const { PRESET_FLOORS, OUTPUT_CAP_BYTES, MIN_FLOOR_BYTES, MIN_CONTAINER_TEXT, planJunkForge, paddingCapFor, SMALL_INPUT_BYTES, SMALL_INPUT_PADDING_CAP_BYTES, LARGE_INPUT_PADDING_CAP_BYTES, PADDING_CODE_MARGIN_BYTES, HEADROOM_BYTES } = require("./src/obfuscation/junk_forge");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the JunkForge suite");
assert.ok(luau, "Luau native runtime is required for the JunkForge suite");

const SRC = "local function tri(n) local t=0 for i=1,n do t=t+i end return t end print(tri(9))";
const SEED = 0x59F0ED1;
const PRESETS = ["l1", "default", "l2", "nest", "df", "lz", "maximum"];
// Rebuilding a padded file three times is the expensive part of this suite, so seed
// determinism is proven on the cheapest and the largest profile instead of all fourteen.
const DETERMINISM_CELLS = new Set(["l1/lua", "maximum/luau"]);

// Reference output is measured from the unprotected sample, not hardcoded.
const baseline = runProgram(lua, SRC, "lua");
assert.ok(baseline.ok, `unprotected sample must run: ${baseline.error || baseline.stderr}`);
const EXPECTED = String(baseline.stdout).trim();
assert.ok(EXPECTED.length > 0, "unprotected sample produced no output");

function bytesOf(output) { return Buffer.byteLength(output, "utf8"); }

// The forge block is one statement prefix: `local <holder>=(function()local <banks>={}
// local <builders>={function()...end,...} ... end)();`. It is emitted after the diagnostic
// runtime prelude, so it is found by its shape rather than by position; the tail comparison
// closes the block so the suite can count the containers inside it without knowing any
// generated name.
const FORGE_OPEN = /local \w+=\(function\(\)local \w+=\{\} local \w+=\{function\(\)/g;
const FORGE_CLOSE = / then \w+\(\) end return \w+ end\)\(\);/;

function forgeBounds(output) {
  const starts = [];
  FORGE_OPEN.lastIndex = 0;
  let match;
  while ((match = FORGE_OPEN.exec(output))) starts.push(match.index);
  if (starts.length !== 1) return { matches: starts.length, start: -1, end: -1 };
  const start = starts[0];
  const tail = FORGE_CLOSE.exec(output.slice(start));
  if (!tail) return { matches: 1, start, end: -1 };
  return { matches: 1, start, end: start + tail.index + tail[0].length };
}

function containersIn(output, bounds) {
  if (!bounds || bounds.start < 0 || bounds.end < 0) return [];
  return findBlobLiterals(output).filter((blob) => blob.start >= bounds.start && blob.end <= bounds.end);
}

function printsExpected(result, runtimeName) {
  return Boolean(result.ok && String(result.stdout || "").trim() === EXPECTED
    && !/ATTACK-UNAVAILABLE/.test(String(result.stderr || "")) && runtimeName);
}

function payloadSpan(output, blobStart) {
  const opener = /^\[(=*)\[byteveil&/.exec(output.slice(blobStart));
  if (!opener) return null;
  const from = blobStart + opener[0].length;
  const end = output.indexOf(`]${opener[1]}]`, from);
  return end < 0 ? null : { from, to: end };
}

// --- 1. Measured envelope: floor, junk budget, telemetry, exact padding attribution ----
// This source is far below SMALL_INPUT_BYTES, so every cell here is built under the
// small-input budget: a preset whose floor the budget cannot reach ships `partial` padding
// at the budget instead of a file that grows past the mandate. Section 3 holds the other
// half of the table (a large input, and each budget overridden explicitly).
const census = [];
const builds = new Map();
const inputBytes = Buffer.byteLength(SRC, "utf8");
assert.ok(inputBytes < SMALL_INPUT_BYTES, `section 1 needs a small-input source, got ${inputBytes} bytes`);
for (const target of ["lua", "luau"]) {
  for (const preset of PRESETS) {
    const key = `${preset}/${target}`;
    const floor = PRESET_FLOORS[preset];
    const envelope = OUTPUT_CAP_BYTES[target];
    const budget = paddingCapFor(target, inputBytes);
    const plan = planJunkForge({ preset, target, inputBytes });
    const built = obfuscate(SRC, { preset, target, seed: SEED + preset.length });
    const forge = built.vmMeta.junkForge;
    const bytes = bytesOf(built.output);

    assert.equal(forge.engine, "JunkForge-v1", `${key}: forge engine`);
    assert.equal(forge.applied, true, `${key}: padding must be applied (${forge.reason})`);
    assert.equal(forge.floorBytes, floor, `${key}: reported floor matches the preset table`);
    assert.equal(forge.maxBytes, envelope, `${key}: reported output ceiling matches the target`);
    assert.equal(forge.paddingCapBytes, budget, `${key}: reported junk budget follows the input size`);
    assert.equal(budget, SMALL_INPUT_PADDING_CAP_BYTES, `${key}: a ${inputBytes}-byte input must draw the small-input budget`);
    assert.equal(plan.paddingCapBytes, budget, `${key}: plan and emitted build must agree on the budget`);
    assert.ok(forge.paddingBytes <= budget, `${key}: padding ${forge.paddingBytes} must never exceed the ${budget}-byte junk budget`);
    assert.equal(built.sizeBudget.targetMinBytes, floor, `${key}: budget floor follows the forge plan`);
    assert.equal(built.sizeBudget.targetMaxBytes, envelope, `${key}: budget cap follows the target`);

    // Reachability is decided by payload plus budget, never by the preset name: a floor the
    // budget cannot lift the file to has to stop at the budget and say which limit bound it.
    const reachable = Math.min(forge.baseBytes + budget - PADDING_CODE_MARGIN_BYTES, envelope - HEADROOM_BYTES);
    if (floor <= reachable) {
      assert.equal(forge.partial, false, `${key}: floor ${floor} is reachable at ${reachable}, so padding must complete`);
      assert.equal(forge.capBinding, null, `${key}: an uncapped build reports no binding`);
      assert.equal(built.sizeBudget.status, "in-target", `${key}: budget status`);
      assert.ok(bytes >= floor, `${key}: ${bytes} bytes must reach the ${floor}-byte floor`);
      assert.ok(bytes <= envelope, `${key}: ${bytes} bytes must stay under the ${envelope}-byte ceiling`);
      // The last container that crosses the floor is the only overshoot, so the gap has to
      // stay a fraction of the file rather than growing with it.
      assert.ok(bytes - floor <= floor * 0.02 + 8192,
        `${key}: padding overshot the floor by ${bytes - floor} bytes`);
    } else {
      assert.equal(forge.partial, true, `${key}: floor ${floor} is out of reach at ${reachable}, so the build must report partial padding`);
      assert.equal(forge.capBinding, "junk-budget", `${key}: a budget-clipped build must name the budget, not the envelope`);
      assert.ok(bytes < floor, `${key}: a clipped build must stay below the floor it could not reach (${bytes} < ${floor})`);
      // The budget is a ceiling, not a licence to under-pad: a clipped build still has to
      // sit on the budget, within a few containers of it.
      assert.ok(forge.paddingBytes >= budget - 4 * PADDING_CODE_MARGIN_BYTES,
        `${key}: clipped padding ${forge.paddingBytes} fell more than ${4 * PADDING_CODE_MARGIN_BYTES} below the ${budget}-byte budget`);
    }

    const bounds = forgeBounds(built.output);
    assert.equal(bounds.matches, 1, `${key}: the padded body must contain exactly one forge block`);
    assert.ok(bounds.end > bounds.start, `${key}: the forge block must close`);
    assert.doesNotMatch(built.output.slice(bounds.start, bounds.end), /[\r\n]/,
      `${key}: padding must not split the minified body across lines`);
    assert.equal(containersIn(built.output, bounds).length, forge.containers + forge.keyBedContainers,
      `${key}: every reported container (padding plus key bed) must be inside the block`);
    assert.ok(forge.containers >= 1 && forge.banks >= 1, `${key}: containers and banks must exist`);
    assert.ok(forge.banks <= forge.containers, `${key}: banks cannot outnumber containers`);

    // Padding attribution: the same build with the forge off differs by exactly the bytes
    // the engine reports, so the payload cost is never credited to padding or hidden in it.
    const naked = obfuscate(SRC, { preset, target, seed: SEED + preset.length, junkForge: false });
    assert.equal(naked.vmMeta.junkForge.applied, false, `${key}: opt-out must skip padding`);
    assert.equal(naked.vmMeta.junkForge.reason, "disabled", `${key}: opt-out reason`);
    assert.equal(naked.vmMeta.junkForge.paddingBytes, 0, `${key}: opt-out padding bytes`);
    assert.equal(naked.vmMeta.junkForge.keyBedBytes, 0, `${key}: opt-out emits no key bed`);
    // Padding attribution, measured against the same build with the forge off. The engine
    // reports both the body length it padded (`baseBytes`) and the block it inserted, so the
    // identity below has no slack: a byte credited to padding must actually be padding. The
    // two bodies differ by the key-binding text the bound build generates.
    const paddingTotal = forge.paddingBytes + forge.keyBedBytes;
    const bindingDelta = forge.baseBytes - naked.vmMeta.junkForge.baseBytes;
    assert.equal(bytes - paddingTotal - bytesOf(naked.output), bindingDelta,
      `${key}: ${bytes} = ${bytesOf(naked.output)} naked + ${paddingTotal} forge bytes + ${bindingDelta} binding delta`);
    assert.ok(bytesOf(naked.output) < floor, `${key}: unpadded build must stay below the floor`);

    if (DETERMINISM_CELLS.has(key)) {
      assert.equal(obfuscate(SRC, { preset, target, seed: SEED + preset.length }).output, built.output,
        `${key}: padding must be deterministic per seed`);
      assert.notEqual(obfuscate(SRC, { preset, target, seed: (SEED ^ 0x5EED) + preset.length }).output, built.output,
        `${key}: padding must follow the seed`);
    }

    // The marker only ever exists inside a container - never as readable text.
    assert.doesNotMatch(built.output, /["']byteveil&/, `${key}: marker must not be emitted as a quoted string`);
    assert.ok(!stripBlobLiterals(built.output).includes("byteveil&"),
      `${key}: marker must not survive container stripping`);
    for (const blob of containersIn(built.output, bounds).slice(0, 3)) {
      const span = payloadSpan(built.output, blob.start);
      assert.ok(span && span.to - span.from >= MIN_CONTAINER_TEXT,
        `${key}: padding container must carry at least the sampled minimum of text`);
    }

    const runtimeBin = target === "luau" ? luau : lua;
    const run = runProgram(runtimeBin, built.output, target);
    assert.ok(printsExpected(run, target),
      `${key}: padded build must still print ${EXPECTED} (${run.error || run.stderr || run.stdout})`);

    builds.set(key, built);
    census.push({ key, bytes, floor, cap: envelope, budget, paddingBytes: forge.paddingBytes,
      containers: forge.containers, banks: forge.banks, unpadded: bytesOf(naked.output),
      keyBedBytes: forge.keyBedBytes, keyBedTextBytes: forge.keyBedTextBytes });
  }
}

// --- 2. Density ladder and the mandate ceilings ------------------------------------------
// An uncapped build stops at the first container that crosses the floor, so it lands in
// [floor, floor + one container] and a higher floor must mean a bigger file. Once the junk
// budget binds, that argument only holds for the padding: every clipped preset draws the same
// budget and the remaining size difference is payload, which the `nest` loader chunk alone
// makes larger than any padding step. The ladder is therefore checked along the cells that
// completed their floor, and separately along the padding of the cells the budget clipped -
// never on total bytes across that boundary.
for (const target of ["lua", "luau"]) {
  const cells = PRESETS.map((preset) => ({ preset, built: builds.get(`${preset}/${target}`) }));
  const band = planJunkForge({ preset: "l1", target, inputBytes }).containerMaxBytes + 64;
  const completed = cells.filter((cell) => cell.built.vmMeta.junkForge.partial === false);
  const clipped = cells.filter((cell) => cell.built.vmMeta.junkForge.partial === true);
  assert.ok(completed.length >= 3, `${target}: the small-input budget must leave the light profiles uncapped, got ${completed.map((c) => c.preset).join(",")}`);
  assert.ok(clipped.length >= 3, `${target}: the small-input budget must clip the heavy profiles, got ${clipped.map((c) => c.preset).join(",")}`);

  let previousBytes = 0;
  let previousFloor = 0;
  for (const { preset, built } of completed) {
    const bytes = built.sizeBudget.outputBytes;
    const floor = PRESET_FLOORS[preset];
    if (floor > previousFloor) {
      assert.ok(bytes > previousBytes, `${target}: ${preset} must be larger than the lighter preset before it (${previousBytes} -> ${bytes})`);
    } else {
      assert.ok(Math.abs(bytes - previousBytes) <= band,
        `${target}: ${preset} shares the ${floor}-byte floor with the previous preset, so ${bytes} must stay inside the one-container band around ${previousBytes}`);
    }
    previousBytes = bytes;
    previousFloor = floor;
  }
  // Clipped cells drew the same budget, so their padding has to agree within a few
  // containers; a profile that quietly padded less than the budget allows is a bug the
  // total file size would hide.
  const paddings = clipped.map((cell) => cell.built.vmMeta.junkForge.paddingBytes);
  const spread = Math.max(...paddings) - Math.min(...paddings);
  assert.ok(spread <= 8 * band, `${target}: clipped padding spread ${spread} B across ${clipped.map((c) => c.preset).join(",")} exceeds ${8 * band} B, so the budget is not the limit that bound them`);

  // The mandate: even the lightest profile clears 200 KB, and the ceilings are per target.
  assert.ok(builds.get(`l1/${target}`).sizeBudget.outputBytes > 200_000, `${target}: l1 must clear 200 KB`);
}
assert.equal(OUTPUT_CAP_BYTES.lua, 2_500_000, "lua output ceiling must be 2.5 MB");
assert.equal(OUTPUT_CAP_BYTES.luau, 3_000_000, "Luau output ceiling must be 3 MB");
assert.equal(SMALL_INPUT_BYTES, 100_000, "the small-input threshold must be 100 KB");
assert.equal(SMALL_INPUT_PADDING_CAP_BYTES, 400_000, "junk budget below the threshold must be 400 KB");
assert.equal(LARGE_INPUT_PADDING_CAP_BYTES.lua, 2_000_000, "large-input Lua junk budget must be 2 MB");
assert.equal(LARGE_INPUT_PADDING_CAP_BYTES.luau, 3_000_000, "large-input Luau junk budget must be 3 MB");
assert.equal(paddingCapFor("lua", SMALL_INPUT_BYTES - 1), SMALL_INPUT_PADDING_CAP_BYTES, "a Lua build just under the threshold draws the small budget");
assert.equal(paddingCapFor("lua", SMALL_INPUT_BYTES), LARGE_INPUT_PADDING_CAP_BYTES.lua, "the Lua budget must switch exactly at the threshold");
assert.equal(paddingCapFor("luau", SMALL_INPUT_BYTES), LARGE_INPUT_PADDING_CAP_BYTES.luau, "the Luau budget must switch exactly at the threshold");

// --- 3. Floor/cap interaction -----------------------------------------------------------
// A preset-less (custom) profile scales its floor with strength instead of reading a preset
// table entry.
const scaled = obfuscate(SRC, { strength: 1500, target: "lua", seed: SEED + 7 });
assert.equal(scaled.vmMeta.junkForge.floorBytes, MIN_FLOOR_BYTES + 500 * 24,
  "custom profile floor must scale with strength");
assert.equal(scaled.sizeBudget.targetMinBytes, MIN_FLOOR_BYTES + 500 * 24,
  "custom profile budget floor must match the scaled plan");
assert.ok(bytesOf(scaled.output) >= scaled.vmMeta.junkForge.floorBytes,
  "custom profile must reach its scaled floor");

// A floor above the target ceiling clamps to the ceiling and ships partial padding rather
// than throwing or blowing past the cap. The padding inside that ceiling is still limited by
// the junk budget, so the two limits are reported separately.
const clamped = obfuscate(SRC, { preset: "maximum", target: "lua", seed: SEED + 8, junkForge: { floorBytes: 40_000_000 } });
assert.equal(clamped.vmMeta.junkForge.floorBytes, OUTPUT_CAP_BYTES.lua, "over-cap floor must clamp to the ceiling");
assert.equal(clamped.vmMeta.junkForge.partial, true, "clamped build must report partial padding");
assert.equal(clamped.vmMeta.junkForge.capBinding, "junk-budget", "the budget, not the ceiling, is what stops a small-input build");
assert.ok(clamped.vmMeta.junkForge.paddingBytes <= SMALL_INPUT_PADDING_CAP_BYTES, "clamped small-input padding must respect the budget");
assert.ok(bytesOf(clamped.output) <= OUTPUT_CAP_BYTES.lua, `clamped lua build must respect the cap: ${bytesOf(clamped.output)}`);
const clampedRun = runProgram(lua, clamped.output, "lua");
assert.ok(printsExpected(clampedRun, "lua"), `clamped build must still run (${clampedRun.error || clampedRun.stderr})`);

// A caller can still ask for more junk than the input-size default buys: the budget is a
// mandate for automatic profiles, not a hard wall against an explicit request. This is also
// the cell that proves a multi-megabyte padded file still loads and prints.
const roomy = obfuscate(SRC, { preset: "maximum", target: "luau", seed: SEED + 9, junkForge: { floorBytes: 2_900_000, paddingCapBytes: LARGE_INPUT_PADDING_CAP_BYTES.luau } });
assert.equal(roomy.vmMeta.junkForge.floorBytes, 2_900_000, "Luau must keep a floor inside its own ceiling");
assert.equal(roomy.vmMeta.junkForge.paddingCapBytes, LARGE_INPUT_PADDING_CAP_BYTES.luau, "an explicit budget must override the input-size default");
assert.equal(roomy.vmMeta.junkForge.partial, false, "roomy Luau build must reach its floor");
assert.ok(bytesOf(roomy.output) >= 2_900_000 && bytesOf(roomy.output) <= OUTPUT_CAP_BYTES.luau,
  `roomy Luau build must land in [2900000, ${OUTPUT_CAP_BYTES.luau}]: ${bytesOf(roomy.output)}`);
assert.ok(roomy.vmMeta.junkForge.paddingBytes <= LARGE_INPUT_PADDING_CAP_BYTES.luau, "roomy padding must stay inside its own budget");
const roomyRun = runProgram(luau, roomy.output, "luau");
assert.ok(printsExpected(roomyRun, "luau"), `roomy Luau build must run (${roomyRun.error || roomyRun.stderr})`);

// The threshold has to bind on a real artifact, not only inside the pure function. Two
// sources either side of SMALL_INPUT_BYTES, built with no override, must report the two
// different budgets. Neither is run natively: a 100 KB payload is a ~700 KB artifact whose
// load time is measured separately (scratch/probe_load_cost.js), and the engine precheck
// already reparsed both before obfuscate() returned.
const filler = (bytes) => {
  const lines = [];
  let n = 0;
  while (Buffer.byteLength(lines.join("\n"), "utf8") < bytes) {
    lines.push(`local v${n} = (function(a, b) return a .. tostring(b % 7) end)("k${n}", ${n})`);
    n++;
  }
  return `${lines.join("\n")}\n${SRC}`;
};
const under = obfuscate(filler(SMALL_INPUT_BYTES - 4_000), { preset: "l1", target: "lua", seed: SEED + 11 });
const over = obfuscate(filler(SMALL_INPUT_BYTES + 4_000), { preset: "l1", target: "lua", seed: SEED + 12 });
assert.ok(Buffer.byteLength(filler(SMALL_INPUT_BYTES - 4_000), "utf8") < SMALL_INPUT_BYTES, "the under-threshold source must really be under it");
assert.ok(Buffer.byteLength(filler(SMALL_INPUT_BYTES + 4_000), "utf8") >= SMALL_INPUT_BYTES, "the over-threshold source must really be over it");
assert.equal(under.vmMeta.junkForge.paddingCapBytes, SMALL_INPUT_PADDING_CAP_BYTES, `a ${Buffer.byteLength(filler(SMALL_INPUT_BYTES - 4_000), "utf8")}-byte source must draw the small budget`);
assert.equal(over.vmMeta.junkForge.paddingCapBytes, LARGE_INPUT_PADDING_CAP_BYTES.lua, `a ${Buffer.byteLength(filler(SMALL_INPUT_BYTES + 4_000), "utf8")}-byte source must draw the Lua budget`);
for (const [label, built] of [["under", under], ["over", over]]) {
  const forge = built.vmMeta.junkForge;
  assert.ok(forge.paddingBytes <= forge.paddingCapBytes, `${label}: padding ${forge.paddingBytes} over budget ${forge.paddingCapBytes}`);
  assert.ok(bytesOf(built.output) <= OUTPUT_CAP_BYTES.lua, `${label}: ${bytesOf(built.output)} bytes over the output ceiling`);
  assert.equal(built.vmMeta.precheck.ok, true, `${label}: the artifact must reparse cleanly (${JSON.stringify(built.vmMeta.precheck.fatal)})`);
}

// --- 4. Fail-closed mutation census -----------------------------------------------------
const padded = builds.get("l2/lua");
const paddedContainers = containersIn(padded.output, forgeBounds(padded.output));
assert.ok(paddedContainers.length >= 24, "need enough padding containers to sample");
// Spread the sample so the first, middle and last banks are all covered.
const sample = [0, 1, Math.floor(paddedContainers.length * 0.25), Math.floor(paddedContainers.length * 0.5),
  Math.floor(paddedContainers.length * 0.75), paddedContainers.length - 1].map((index) => paddedContainers[index]);

function dropContainer(output, blob) {
  if (output[blob.end] === ",") return `${output.slice(0, blob.start)}${output.slice(blob.end + 1)}`;
  if (output[blob.start - 1] === ",") return `${output.slice(0, blob.start - 1)}${output.slice(blob.end)}`;
  return `${output.slice(0, blob.start)}${output.slice(blob.end)}`;
}

function shortenContainer(output, blob) {
  const span = payloadSpan(output, blob.start);
  if (!span || span.to - span.from < 2) return null;
  return `${output.slice(0, span.to - 1)}${output.slice(span.to)}`;
}

// Swap one payload character between ASCII classes (letter <-> digit). The container length
// and every sampled byte position stay put, so only the bank character-class counts can see
// it; a count that moves changes that accumulation and every later step of the digest chain.
function reclassContainer(output, blob) {
  const span = payloadSpan(output, blob.start);
  if (!span) return null;
  const body = output.slice(span.from, span.to);
  for (let i = 0; i < body.length; i++) {
    const code = body.charCodeAt(i);
    const isLetter = (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
    const isDigit = code >= 48 && code <= 57;
    if (!isLetter && !isDigit) continue;
    const replacement = isLetter ? "0" : "q";
    if (body[i] === replacement) continue;
    return `${output.slice(0, span.from + i)}${replacement}${output.slice(span.from + i + 1)}`;
  }
  return null;
}

const tamper = { classes: {}, survivors: [], aborted: 0, runs: 0 };
for (const [label, mutate] of [["dropped", dropContainer], ["shortened", shortenContainer], ["reclassified", reclassContainer]]) {
  const counts = { attempted: 0, rejected: 0, aborted: 0 };
  for (const blob of sample) {
    const mutated = mutate(padded.output, blob);
    assert.notEqual(mutated, padded.output, `padding ${label} must change the emitted text`);
    counts.attempted++;
    if (label === "dropped") {
      assert.equal(containersIn(mutated, forgeBounds(mutated)).length, paddedContainers.length - 1,
        "dropping a container must remove exactly one padding container");
    }
    for (const [runtimeName, runtimeBin] of [["lua", lua], ["luau", luau]]) {
      tamper.runs++;
      const outcome = runProgram(runtimeBin, mutated, runtimeName);
      if (printsExpected(outcome, runtimeName)) {
        tamper.survivors.push(`${label}/${runtimeName}`);
        continue;
      }
      counts.rejected++;
      // Failing closed means the script died before the payload ran, not that it ran and
      // printed something else.
      if (outcome.status !== 0 || outcome.error) {
        counts.aborted++;
        tamper.aborted++;
      }
    }
  }
  tamper.classes[label] = counts;
}
assert.deepEqual(tamper.survivors, [], "every padding container edit must fail closed");
assert.equal(tamper.aborted, tamper.runs, "every rejected edit must abort the program instead of running it");

// Control: the same build untouched still runs on Luau, so the censuses above are not
// failing for an unrelated reason.
const control = runProgram(luau, padded.output, "luau");
assert.ok(printsExpected(control, "luau"), `unmutated padding build must run on Luau (${control.error || control.stderr})`);

// --- 5. Key bed: the padding block also holds the payload's decode key -------------------
// A self-contained digest is only worth its comparison oracle, so the block returns a
// folded key and the VM adds it to the region seed. Deleting the block - or replacing it
// with a stub that returns any other number - must cost the payload, not just the bytes.
const bedSamples = [["l1", "lua"], ["l2", "luau"], ["maximum", "lua"]];
const bedCensus = { mutations: 0, aborted: 0, survivors: [] };
// Flip one character onto its own class (lowercase -> next lowercase, uppercase -> next
// uppercase, digit -> next digit) at the first such position past the midpoint. The length,
// every sampled position and all four gsub class counts are unchanged, so only a fold that
// reads the container byte by byte can see it.
function sameClassFlip(output, from, to) {
  const body = output.slice(from, to);
  for (let i = Math.floor(body.length / 2); i < body.length; i++) {
    const code = body.charCodeAt(i);
    let replacement = null;
    if (code >= 97 && code <= 122) replacement = code === 122 ? "a" : String.fromCharCode(code + 1);
    else if (code >= 65 && code <= 90) replacement = code === 90 ? "A" : String.fromCharCode(code + 1);
    else if (code >= 48 && code <= 57) replacement = code === 57 ? "0" : String.fromCharCode(code + 1);
    if (!replacement || body[i] === replacement) continue;
    return { at: from + i, from: body[i], to: replacement,
      text: `${output.slice(0, from + i)}${replacement}${output.slice(from + i + 1)}` };
  }
  return null;
}

for (const [preset, target] of bedSamples) {
  const key = `${preset}/${target}`;
  const built = builds.get(key);
  const runtimeBin = target === "luau" ? luau : lua;
  const forge = built.vmMeta.junkForge;
  assert.equal(forge.keyBedBound, true, `${key}: the VM route must bind the key bed`);
  assert.ok(forge.keyBedBytes > 0 && forge.keyBedContainers === 5, `${key}: the key bed must be reported`);

  const bounds = forgeBounds(built.output);
  const inside = containersIn(built.output, bounds);
  const bed = inside.slice(-forge.keyBedContainers);
  assert.equal(bed.length, forge.keyBedContainers, `${key}: the key bed containers must be the tail of the block`);
  // The fold reads the container's whole Lua string value, marker included, so the
  // comparison is against the inner text of the brackets rather than the payload part.
  assert.equal(forge.keyBedTextBytes, bed.reduce((acc, blob) => {
    const inner = /^\[(=*)\[([\s\S]*)\]\1\]$/.exec(blob.text);
    assert.ok(inner, `${key}: bed container must be a long-bracket literal`);
    return acc + inner[2].length;
  }, 0), `${key}: reported bed text must be exactly what the fold reads`);

  // The holder local the block declares is one of the names the region key reads (the
  // anti-hook verdict holder is appended after it), so the binding survives mangling and
  // minification intact. The root-seed local itself is a generated name and does get
  // mangled, so the check is on the arithmetic shape.
  const holderMatch = /^local (\w+)=\(function\(\)/.exec(built.output.slice(bounds.start, bounds.end));
  assert.ok(holderMatch, `${key}: the block must open with its holder local`);
  const holder = holderMatch[1];
  const bedRead = new RegExp(`\\((?:[A-Za-z_]\\w*\\+)*${holder}(?:\\+[A-Za-z_]\\w*)*\\)%4294967296`);
  assert.ok(bedRead.test(built.output),
    `${key}: the region seed must add the key-bed holder`);
  assert.equal((built.output.match(new RegExp(bedRead.source, "g")) || []).length, 1,
    `${key}: the holder must be read at exactly the region-key derivation`);

  const block = built.output.slice(bounds.start, bounds.end);
  const cases = [
    ["block deleted", built.output.replace(block, "")],
    ["block stubbed to zero", built.output.replace(block, `local ${holder}=0;`)],
    ["block stubbed to a wrong key", built.output.replace(block, `local ${holder}=1;`)]
  ];
  for (const [label, mutated] of cases) {
    const outcome = runProgram(runtimeBin, mutated, target);
    bedCensus.mutations++;
    if (printsExpected(outcome, target)) bedCensus.survivors.push(`${key}/${label}`);
    else if (outcome.status !== 0 || outcome.error) bedCensus.aborted++;
    assert.ok(!printsExpected(outcome, target), `${key}: key-bed ${label} must not run the payload (${outcome.stdout})`);
    assert.notEqual(outcome.status, 0, `${key}: key-bed ${label} must abort, not degrade`);
  }

  // The bed fold reads every byte of its containers, so a flip that keeps its length and
  // its character class still changes the key - and the build dies instead of decoding
  // garbage from a mutated bed.
  const first = bed[0];
  const span = payloadSpan(built.output, first.start);
  const flip = sameClassFlip(built.output, span.from, span.to);
  assert.ok(flip, `${key}: the bed container must contain a flippable character`);
  assert.notEqual(flip.text, built.output, `${key}: the bed edit must change the text`);
  const editedRun = runProgram(runtimeBin, flip.text, target);
  bedCensus.mutations++;
  if (printsExpected(editedRun, target)) bedCensus.survivors.push(`${key}/same-class bed flip`);
  else if (editedRun.status !== 0 || editedRun.error) bedCensus.aborted++;
  assert.ok(!printsExpected(editedRun, target), `${key}: a same-class key-bed flip must fail closed`);
  assert.notEqual(editedRun.status, 0, `${key}: a same-class key-bed flip must abort`);

  // Turning the forge off removes the bed with the padding: the payload must still run,
  // because that route never binds a key.
  const naked = obfuscate(SRC, { preset, target, seed: SEED + preset.length, junkForge: false });
  const nakedRun = runProgram(runtimeBin, naked.output, target);
  assert.ok(printsExpected(nakedRun, target),
    `${key}: a forge-off build must run without any key bed (${nakedRun.error || nakedRun.stderr})`);
}

assert.deepEqual(bedCensus.survivors, [], "every key-bed block mutation must fail closed");
assert.equal(bedCensus.aborted, bedCensus.mutations, "every key-bed mutation must abort before the payload runs");

// The `nest` preset loads the VM body from a string, so a chunk-level holder would not be
// visible: it keeps the padding and must not claim a binding.
const nested = builds.get("nest/lua");
assert.equal(nested.vmMeta.junkForge.keyBedBound, false, "nest must not bind a key bed across its loader chunk");
assert.equal(nested.vmMeta.junkForge.applied, true, "nest still gets padding");

const report = census.map((entry) => `${entry.key}=${entry.bytes}B(+${entry.paddingBytes}B/${entry.containers}c/${entry.banks}b; bed ${entry.keyBedBytes}B/${entry.keyBedTextBytes}B read)`).join(" ");
console.log("ByteVeil v5.9 JunkForge density suite: PASS");
console.log(`  builds: ${report}`);
console.log(`  tamper: ${Object.entries(tamper.classes).map(([label, counts]) => `${label} ${counts.rejected}/${counts.attempted}x2`).join(", ")};`
  + ` ${tamper.aborted}/${tamper.runs} native runs aborted before the payload`);
console.log(`  key bed: ${bedSamples.length} cells, ${bedCensus.mutations} block mutations (delete / stub 0 / stub wrong / same-class byte flip),`
  + ` ${bedCensus.aborted}/${bedCensus.mutations} aborted before the payload, survivors=[${bedCensus.survivors.join(", ")}]`);

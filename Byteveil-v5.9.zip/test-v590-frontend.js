"use strict";

const assert = require("node:assert/strict");
const { Lexer, lex } = require("./src/frontend/lexer");
const { Parser, parse, parseDetailed } = require("./src/frontend/parser");
const frontend = require("./src/frontend");

function lexSource(source) {
  return new Lexer(source).lex();
}

// Public API stays backward-compatible while detailed diagnostics are exposed.
assert.equal(typeof frontend.parseDetailed, "function");
assert.equal(typeof frontend.parse, "function");
assert.equal(typeof frontend.lex, "function");

// CRLF and standalone CR are both treated as one physical newline.
const crlf = lexSource("local x = 1\r\n!");
assert.equal(crlf.errors.length, 1);
assert.deepEqual(
  { line: crlf.errors[0].line, col: crlf.errors[0].col },
  { line: 2, col: 1 },
  "CRLF coordinates must not drift"
);
const crOnly = lexSource("local x=1\rlocal y=2");
assert.equal(crOnly.tokens.find((token) => token.value === "local" && token.line === 2)?.col, 1);

// Long-comment traversal must preserve source positions, including after --.
const sameLineComment = lexSource("--[[note]]local x=1");
assert.equal(sameLineComment.tokens.find((token) => token.value === "local")?.col, 11);
const multiLineComment = lexSource("--[=[first\r\nsecond]=]\r\nlocal x=1");
assert.deepEqual(
  {
    line: multiLineComment.tokens.find((token) => token.value === "local")?.line,
    col: multiLineComment.tokens.find((token) => token.value === "local")?.col
  },
  { line: 3, col: 1 }
);

// Ordinary quoted strings cannot contain a raw physical newline.
const badNewline = lexSource('local message = "hello\nworld"');
assert.equal(badNewline.errors.length, 1);
assert.match(badNewline.errors[0].message, /Unescaped newline/);

// Escaped CRLF continuation becomes a single newline in the decoded value.
const continuation = lexSource('local message = "left\\\r\nright"');
assert.deepEqual(continuation.errors, []);
assert.equal(continuation.tokens.find((token) => token.type === "string")?.value, "left\nright");

// Valid escapes decode correctly; malformed escapes are reported instead of silently accepted.
const validEscapes = lexSource(String.raw`local s = "\x41\u{1F600}\065"`);
assert.deepEqual(validEscapes.errors, []);
assert.equal(validEscapes.tokens.find((token) => token.type === "string")?.value, "A😀A");
for (const [source, expected] of [
  [String.raw`local s = "\xG1"`, /Malformed hexadecimal escape/],
  [String.raw`local s = "\u{XYZ}"`, /Malformed Unicode escape/],
  [String.raw`local s = "\u{D800}"`, /valid scalar value/],
  [String.raw`local s = "\u{110000}"`, /valid scalar value/],
  [String.raw`local s = "\256"`, /out of range/]
]) {
  const result = lexSource(source);
  assert.ok(result.errors.some((error) => expected.test(error.message)), `${source} should report ${expected}`);
}

// Invalid numeric suffixes should not be split into a valid number plus an identifier.
for (const source of ["return 1e+", "return 0x", "return 0b2", "return 1__2", "return 2abc"]) {
  assert.ok(lex(source).errors.some((error) => /Malformed numeric literal/.test(error.message)), source);
}
assert.deepEqual(lex("return 1_024, 0x1.fp2, 0b101").errors, []);

// parseDetailed() returns both lexical and parser diagnostics without changing parse()'s AST-only contract.
const lexicalDetail = parseDetailed('local s = "unterminated');
assert.ok(lexicalDetail.lexerErrors.length > 0);
assert.equal(lexicalDetail.errors.length, lexicalDetail.lexerErrors.length + lexicalDetail.parserErrors.length);
assert.equal(lexicalDetail.ast.type, "Chunk");

const syntaxDetail = parseDetailed("local value =");
assert.ok(syntaxDetail.parserErrors.some((error) => /Expected expression/.test(error.message)));
assert.deepEqual(parse("local value ="), syntaxDetail.ast);
const truncatedFunction = parseDetailed("function (");
assert.ok(truncatedFunction.parserErrors.some((error) => /Unterminated function parameter list/.test(error.message)), "truncated function parameters must report an error and terminate");
const missingOperand = parseDetailed("local value = 1 + )");
assert.ok(missingOperand.parserErrors.some((error) => /Expected expression after operator/.test(error.message)));
const tokens = lex("return 2 + 3").tokens;
assert.equal(parseDetailed(tokens).ast.type, "Chunk");
assert.equal(new Parser(tokens).parse().type, "Chunk");

// Unicode identifiers and valid Luau interpolation remain supported.
const unicode = lexSource("local Привет = 1; return Привет");
assert.deepEqual(unicode.errors, []);
assert.ok(unicode.tokens.some((token) => token.type === "id" && token.value === "Привет"));
const interpolation = parseDetailed("local name = 'ByteVeil'; return `hello {name}`");
assert.deepEqual(interpolation.errors, []);

// A string literal whose text is a grammar token is still data. The junk alphabet the
// generator emits can contain "}" or "end" verbatim, so no parser gate may read a literal
// as the keyword it happens to spell.
for (const source of [
  'local A = table.concat({"}", "x"})',
  'local A = (")"):rep(2)',
  'if "then" == x then print("else") end',
  'local t = {["end"] = 1, [")"] = 2, [";"] = 3, [","] = 4}',
  'print("}", ")", ";", ",", "end", "then", "elseif", "until", "in", "do")',
  "local s = [[}]]\nlocal u = [==[)==]==]",
  'for k = "a", "z" do print(k) end',
  'local f = function(...) return select("#", ...) end',
  'while "do" ~= nil do break end',
  'local q = string.format("%s", "}") .. "}"',
  'return "end" .. "}", ")"',
  'local e = setmetatable({}, {__index = function(_, k) return tostring(k) end})["}"]'
]) {
  const detail = parseDetailed(source);
  assert.deepEqual(detail.errors, [], `grammar-valued literal rejected: ${source}`);
}

// The literal text must reach the AST untouched, in every position a token-shaped string can sit.
function collectStrings(node, out = [], seen = new Set()) {
  if (!node || typeof node !== "object" || seen.has(node)) return out;
  seen.add(node);
  if (node.type === "String" && typeof node.value === "string") out.push(node.value);
  for (const key of Object.keys(node)) {
    if (key === "loc" || key === "range") continue;
    collectStrings(node[key], out, seen);
  }
  return out;
}
const tokenShaped = parseDetailed(
  'local t = {["}"] = ")"}\nprint(t["};"], "end", table.concat({";", "then", "else"}, ","))'
);
assert.deepEqual(
  [...new Set(collectStrings(tokenShaped.ast))].sort(),
  [")", ",", ";", "};", "concat", "else", "end", "then", "}"].sort(),
  "grammar-shaped literals must survive into the AST as values"
);

console.log("ByteVeil v5.9 frontend regressions: PASS (diagnostics, escapes, numeric literals, CRLF, long comments, Unicode, interpolation, grammar-valued literals)");

"use strict";

// ByteVeil v5.9 carrier load-bearing suite.
//
// Every carrier-shaped `[=*[byteveil&...]=]` container in the finished output - the ones the
// VM reads through `string.sub(<literal>, 10)` - has to be structurally necessary. Changing a
// single payload character, or shortening a payload, must stop the program. There is no
// "decorative" container left in the output: the junk carriers built alongside the payload
// bed are decoded, length-checked and folded into a runtime digest.
//
// The suite knows nothing about generator internals: it locates containers in the final text,
// mutates them, and runs the result on the native Lua 5.4 and Luau binaries.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");
const { findBlobLiterals } = require("./src/obfuscation/veil_blob");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the carrier suite");
assert.ok(luau, "Luau native runtime is required for the carrier suite");

const SRC = `
local NAME = "veil"
function bv_probe(a, b) return a * b + 1 end
bv_public = bv_probe
local total = 0
for i = 1, 4 do total = total + bv_probe(i, i) end
print(total)
`;

// Reference output is measured from the unprotected sample, never assumed.
const baselineRun = runProgram(lua, SRC, "lua");
assert.ok(baselineRun.ok, `unprotected sample must run: ${baselineRun.error || baselineRun.stderr}`);
const EXPECTED = baselineRun.stdout.trim();
assert.ok(EXPECTED.length > 0, "unprotected sample produced no output");

const CARRIER_SUB = 10;              // the carrier bed strips the 9-character marker
const MIN_CARRIERS = 6;              // payload bed plus live junk carriers
const MUTATIONS_PER_CLASS = 8;       // keeps the suite inside the gate's wall-clock budget

// Containers the VM actually reads: the literal is the argument of a `string.sub(` call.
function carrierLiterals(output) {
  return findBlobLiterals(output).filter((blob) =>
    output.slice(Math.max(0, blob.start - 12), blob.start).endsWith("string.sub("));
}

function payloadSpan(output, blobStart) {
  const opener = /^\[(=*)\[byteveil&/.exec(output.slice(blobStart));
  if (!opener) return null;
  const from = blobStart + opener[0].length;
  const closer = `]${opener[1]}]`;
  const end = output.indexOf(closer, from);
  if (end < 0) return null;
  return { from, to: end };
}

// Swap one payload character for another character taken from the same payload, so the
// mutation stays inside the alphabet and is rejected on value rather than on syntax.
function flipFirstPayloadChar(output, blobStart) {
  const span = payloadSpan(output, blobStart);
  if (!span || span.to - span.from < 2) return null;
  let replacement = null;
  for (const candidate of output.slice(span.from, span.to)) {
    if (candidate !== output[span.from]) { replacement = candidate; break; }
  }
  if (!replacement) return null; // payload repeats one character: no in-alphabet flip available
  return `${output.slice(0, span.from)}${replacement}${output.slice(span.from + 1)}`;
}

function shortenPayload(output, blobStart) {
  const span = payloadSpan(output, blobStart);
  if (!span || span.to - span.from < 2) return null;
  return `${output.slice(0, span.to - 1)}${output.slice(span.to)}`;
}

function printsExpected(result, runtimeName) {
  return Boolean(result.ok && String(result.stdout || "").trim() === EXPECTED
    && !/ATTACK-UNAVAILABLE/.test(String(result.stderr || "")) && runtimeName);
}

const builds = [];
for (const mode of ["stack", "register"]) {
  for (const seed of [4242, 90210]) {
    const built = obfuscate(SRC, { preset: "lz", mode, seed });
    assert.ok(built && built.output.length > 1000, `build ${mode}/${seed} must be produced`);
    builds.push({ mode, seed, output: built.output });
  }
}

const evidence = { carriers: 0, flipped: 0, flipBreaks: 0, shortened: 0, shortenBreaks: 0, survivors: [] };

for (const build of builds) {
  const carriers = carrierLiterals(build.output);
  assert.ok(carriers.length >= MIN_CARRIERS,
    `${build.mode}/${build.seed} must expose at least ${MIN_CARRIERS} VM-read carriers, found ${carriers.length}`);
  evidence.carriers += carriers.length;

  for (const [runtimeName, runtimeBin] of [["lua", lua], ["luau", luau]]) {
    const control = runProgram(runtimeBin, build.output, runtimeName);
    assert.ok(printsExpected(control, runtimeName),
      `unmutated build must print ${EXPECTED} on ${runtimeName} (${build.mode}/${build.seed}): ${(control.stdout || "") + (control.stderr || "")}`);
  }

  for (const [mutate, counterName] of [[flipFirstPayloadChar, "flipped"], [shortenPayload, "shortened"]]) {
    let touched = 0;
    for (const blob of carriers) {
      if (touched >= MUTATIONS_PER_CLASS) break;
      const mutated = mutate(build.output, blob.start);
      if (mutated === null) continue;
      assert.notEqual(mutated, build.output, "mutation must change the text");
      touched++;
      for (const [runtimeName, runtimeBin] of [["lua", lua], ["luau", luau]]) {
        const outcome = runProgram(runtimeBin, mutated, runtimeName);
        evidence[counterName]++;
        if (printsExpected(outcome, runtimeName)) {
          evidence.survivors.push(`${build.mode}/${build.seed}/${counterName}/${runtimeName}`);
        } else {
          evidence[counterName === "flipped" ? "flipBreaks" : "shortenBreaks"]++;
        }
      }
    }
  }
}

assert.deepEqual(evidence.survivors, [], "every VM-read carrier must be load-bearing");
console.log(`ByteVeil v5.9 carrier load-bearing suite: PASS (${builds.length} builds,`
  + ` ${evidence.carriers} VM-read carriers;`
  + ` payload flips ${evidence.flipBreaks}/${evidence.flipped} rejected,`
  + ` payload truncations ${evidence.shortenBreaks}/${evidence.shortened} rejected,`
  + ` on Lua 5.4 and Luau)`);

"use strict";
// v5.9.0 multiple-return suite: a call or vararg in an expanding position must give
// the host exactly the values native Lua/Luau gives it.
//
// Expanding positions are the tail field of a list-position table constructor, the
// trailing argument of a call, the value list of a `return`, and the right-hand side of
// a multi-target assignment. Everywhere else Lua truncates a call to one result, so the
// suite pins both halves: expansion where Lua expands, truncation where Lua truncates.
//
// Two VM opcodes carry this: CALLP materialises a whole result list as an {n, [1..n]}
// pack (nil holes and the zero-result case included) and APPEND writes that pack into a
// table at the constructor's implicit-array boundary. Register RETURN now also states its
// own result count, because a payload region can materialise a short instruction with
// padded operand slots and `#instruction` is therefore not a length the VM may trust.
//
// Expectations are literal here, not read from the host at test time. The plain source is
// still run first and compared to the pin, so a host that stops agreeing with the pin
// fails this suite loudly instead of quietly moving the goalposts.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");

const PRE = `local function g3() return 1, 2, 3 end
local function holes() return 1, nil, 3 end
local function none() end
local function two() return 7, 8 end
local function idn(...) return ... end
local function fmt(a, b, c) return tostring(a) .. "|" .. tostring(b) .. "|" .. tostring(c) end
`;

const LUA = [
  { label: "table tail expands every result", src: PRE + "local t = {g3()}\nprint(#t, t[1], t[2], t[3])", want: "3\t1\t2\t3" },
  { label: "table tail keeps an interior nil hole", src: PRE + "local t = {holes()}\nprint(#t, t[1], t[2], t[3], select('#', holes()))", want: "3\t1\tnil\t3\t3" },
  { label: "zero-result call adds nothing, and only truncates off the tail", src: PRE + "local t = {1, 2, none()}\nprint(#t)\nlocal u = {none(), 1}\nprint(#u, u[1], u[2])", want: "2\n2\tnil\t1" },
  { label: "explicitly keyed call field never expands", src: PRE + "local t = {[1] = g3(), 9}\nprint(#t, t[1], t[2])", want: "1\t9\tnil" },
  { label: "hash part then expanding tail", src: PRE + "local t = {a = 1, g3()}\nprint(t.a, #t, t[1], t[2], t[3])", want: "1\t3\t1\t2\t3" },
  { label: "parenthesised call truncates in a table", src: PRE + "local t = {(g3())}\nprint(#t, t[1])", want: "1\t1" },
  { label: "nested constructor tail", src: PRE + "local t = {1, {two()}}\nprint(#t, #t[2], t[2][1], t[2][2])", want: "2\t2\t7\t8" },
  { label: "table.unpack with explicit size keeps holes", src: PRE + "local p = table.pack(1, nil, 3)\nlocal t = {table.unpack(p, 1, p.n)}\nprint(#t, t[1], t[2], t[3])", want: "3\t1\tnil\t3" },
  { label: "{...} keeps the vararg count and its nils", src: "local function v(...) local t = {...} return #t, select('#', ...) end\nprint(v(1, nil, 3))\nprint(v())", want: "3\t3\n0\t0" },
  { label: "trailing call argument expands", src: PRE + "print(fmt(table.unpack({1, 2})))\nprint(fmt(idn(1, 2, 3)))", want: "1|2|nil\n1|2|3" },
  { label: "call whose own argument expands", src: PRE + "local t = {idn(g3())}\nprint(#t, t[1], t[3])", want: "3\t1\t3" },
  { label: "zero-result call as a trailing argument vanishes", src: PRE + "print(idn(none(), 5))", want: "nil\t5" },
  { label: "return of a call expands again in the caller", src: PRE + "local function h() return g3() end\nprint(h())\nprint(select('#', h()))", want: "1\t2\t3\n3" },
  { label: "nil hole survives return then print", src: PRE + "local function hv() return holes() end\nprint(hv())\nprint(select('#', hv()))", want: "1\tnil\t3\n3" },
  { label: "assignment pads missing targets with nil", src: PRE + "local a, b, c, d = g3()\nprint(a, b, c, tostring(d))", want: "1\t2\t3\tnil" },
  { label: "single target assignment truncates", src: PRE + "local x = g3()\nprint(x)", want: "1" },
  { label: "concat truncates the call to one result", src: PRE + "print((g3()) .. '!')", want: "1!" },
  { label: "method call tail expands, self counts as an argument", src: "local obj = {}\nfunction obj:m() return 1, 2 end\nlocal sink = {}\nfunction sink.tail(...) return ... end\nlocal t = {obj:m()}\nprint(#t, t[1], t[2])\nprint(obj:m())\nlocal u = {sink:tail(obj:m())}\nprint(#u, u[2], u[3])", want: "2\t1\t2\n1\t2\n3\t1\t2" },
  { label: "inner call truncates when it is not the last argument", src: PRE + "local t = {idn(idn(1, 2), 3)}\nprint(#t, t[1], t[2], t[3])", want: "2\t1\t3\tnil" },
  { label: "nested expanding argument list", src: PRE + "local function outer(x, y) return x, y end\nlocal t = {outer(outer(1, 2), 3)}\nprint(#t, t[1], t[2], t[3])", want: "2\t1\t3\tnil" },
  { label: "expanding tail after a numeric for", src: PRE + "local acc = {}\nfor i = 1, 2 do acc[#acc + 1] = i end\nlocal t = {g3()}\nprint(#t, #acc)", want: "3\t2" },
  { label: "string.find result pair in a table", src: PRE + "local t = {string.find('hello world', 'world')}\nprint(#t, t[1], t[2])", want: "2\t7\t11" },
  { label: "generic for with two loop variables", src: "local function range() local i = 0 return function() i = i + 1 if i <= 3 then return i, i * 10 end end end\nfor a, b in range() do print(a, b) end", want: "1\t10\n2\t20\n3\t30" },
  { label: "table.pack inside an expanding tail", src: PRE + "local t = {table.pack(g3())}\nprint(t[1].n, t[1][1], t[1][3])", want: "3\t1\t3" },
  { label: "a run-time nil does not hide the slots after it", src: PRE + "local u = {none(), 1, 2}\nprint(#u, tostring(u[1]), u[2], u[3])", want: "3\tnil\t1\t2" },
  { label: "an explicit nil keeps the border past it", src: PRE + "local u = {nil, 1, 2}\nprint(#u, tostring(u[1]), u[2], u[3])", want: "3\tnil\t1\t2" },
  { label: "a run-time nil before an expanding tail", src: PRE + "local a = nil\nlocal u = {a, g3()}\nprint(#u, tostring(u[1]), u[2], u[4])", want: "4\tnil\t1\t3" },
  { label: "trailing nils collapse the border", src: PRE + "local u = {1, none()}\nprint(#u, u[1], tostring(u[2]))", want: "1\t1\tnil" },
  { label: "next skips a leading hole", src: PRE + "local u = {none(), 7}\nprint(tostring((next(u))))", want: "2" },
  { label: "ipairs stops at the first hole", src: PRE + "local u = {nil, 1, 2}\nlocal n = 0\nfor i, v in ipairs(u) do n = n + 1 end\nprint(n)", want: "0" },
  { label: "expanded results summed by a vararg function", src: PRE + "local function sum(...) local t = {...} local s = 0 for i = 1, #t do s = s + t[i] end return s end\nprint(sum(g3()))", want: "6" },
];

const LUAU = [
  { label: "luau table tail plus interior nil", src: "local function g3() return 1, 2, 3 end\nlocal function holes() return 1, nil, 3 end\nlocal t = {g3()}\nprint(#t, t[1], t[3])\nlocal u = {holes()}\nprint(#u, u[1], u[2], u[3])", want: "3\t1\t3\n3\t1\tnil\t3" },
  { label: "luau vararg tail keeps nils", src: "local function idn(...) return ... end\nlocal t = {idn(1, nil, 3)}\nprint(#t, t[2], t[3])", want: "3\tnil\t3" },
  { label: "luau table.unpack tail with explicit size", src: "local p = table.pack(1, 2, 3)\nlocal t = {table.unpack(p, 1, p.n)}\nprint(#t, t[2])", want: "3\t2" },
  { label: "luau expanded call argument", src: "local function fmt(a, b, c) return tostring(a) .. '|' .. tostring(b) .. '|' .. tostring(c) end\nlocal function idn(...) return ... end\nprint(fmt(idn(1, 2)))", want: "1|2|nil" },
  { label: "luau method tail in a table", src: "local obj = {}\nfunction obj:m() return 1, 2 end\nlocal t = {obj:m()}\nprint(#t, t[1], t[2])", want: "2\t1\t2" },
];

const CASES = [
  ...LUA.map((c) => ({ ...c, target: "lua" })),
  ...LUAU.map((c) => ({ ...c, target: "luau" })),
];

const MODES = ["stack", "register"];
const PRESETS = ["l1", "l2"];

const hosts = { lua: resolveRuntime("lua"), luau: resolveRuntime("luau") };
assert.ok(hosts.lua && hosts.luau, "both native hosts must resolve for the multiple-return suite to prove anything");

let cells = 0;
for (const testCase of CASES) {
  const exe = hosts[testCase.target];

  // The pin must be what the host itself prints. If it is not, this file is wrong, not the engine.
  const control = runProgram(exe, testCase.src, testCase.target, testCase.want);
  assert.ok(control.ok,
    `${testCase.target} ${testCase.label}: host source output ${JSON.stringify(control.stdout)} != pinned ${JSON.stringify(testCase.want)} (status ${control.status})`);

  for (const preset of PRESETS) {
    for (const mode of MODES) {
      const built = obfuscate(testCase.src, { preset, target: testCase.target, mode, seed: 0x59c0de, junkForge: false });
      assert.strictEqual(built.vmMeta.fallback, false,
        `${preset}/${mode} ${testCase.target} ${testCase.label}: must exercise the custom VM`);
      const ran = runProgram(exe, built.output, testCase.target, testCase.want);
      assert.ok(ran.ok,
        `${preset}/${mode} ${testCase.target} ${testCase.label}: artifact stdout ${JSON.stringify(ran.stdout)} != ${JSON.stringify(testCase.want)} (status ${ran.status})`);
      cells++;
    }
  }
}

// The CALLP/APPEND shape must not depend on one seed: the pack layout, the register
// permutation and the payload region layouts all move with the seed, and a result list
// that is one value too long or too short only shows up as a stray nil in stdout.
const spread = PRE + "local t = {holes()}\nprint(#t, t[1], t[2], t[3])\nprint(fmt(g3()))\nprint(idn(g3()))";
for (const seed of [1, 7, 0x59c0de, 20261101, 4294967295]) {
  for (const mode of MODES) {
    const built = obfuscate(spread, { preset: "l2", target: "lua", mode, seed, junkForge: false });
    const ran = runProgram(hosts.lua, built.output, "lua");
    assert.ok(ran.ok, `seed ${seed} ${mode}: build must run, got ${JSON.stringify(ran.stdout)}`);
    assert.strictEqual(ran.stdout, "3\t1\tnil\t3\n1|2|3\n1\t2\t3",
      `seed ${seed} ${mode}: hole-keeping tail, expanded call argument, expanded print tail`);
    cells++;
  }
}

// A bare `return` and a `return` of a zero-result call must both hand the caller an empty
// list; the register VM's result count operand is what makes this observable.
const emptyReturn = `local function e() return end
local function z() local _ = 1 return e() end
local t = {z()}
print(#t)
print(select('#', z()))
local function one() return "x" end
print(one())`;
for (const mode of MODES) {
  const built = obfuscate(emptyReturn, { preset: "l2", target: "lua", mode, seed: 0x59c0de, junkForge: false });
  const ran = runProgram(hosts.lua, built.output, "lua");
  assert.ok(ran.ok, `empty return ${mode}: ${JSON.stringify(ran.stdout)}`);
  assert.strictEqual(ran.stdout, "0\n0\nx", `empty return ${mode}: bare return and tail-called empty list both yield zero results`);
  cells++;
}

console.log("ByteVeil v5.9.0 multiple-return suite: PASS");
console.log(`  ${CASES.length} pinned cases (${LUA.length} Lua 5.4 + ${LUAU.length} Luau), each host-checked then rebuilt as ${PRESETS.length} presets x ${MODES.length} modes`);
console.log(`  ${cells} artifact cells run on native Lua 5.4 + Luau with stdout equal to the pin`);
console.log("  extra cells: 5 seeds x 2 modes for the CALLP/APPEND spread shape, plus empty-result returns");

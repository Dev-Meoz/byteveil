"use strict";
// v5.9.0 numeric-fidelity suite: what the host prints for a number, the artifact must print.
//
// Lua 5.4 splits numbers into integer and float subtypes (print(5) is "5", print(5.0) is "5.0",
// 5.0 // 2 is a float and 5 // 2 is not). A JS number cannot hold that distinction, so an earlier
// build collapsed every integral float into an integer and the artifact printed the wrong text and
// ran the wrong subtype through //, % and table keys. The literal's *source spelling* now travels to
// the payload as decimal text, and IDIV uses the host's own // operator.
//
// The expectations below are pinned in this file, not copied from the host at run time: a host
// upgrade must not silently move the goalposts. The host run of the plain source is still checked
// against the pin, so a pin that drifts from reality fails loudly instead of hiding a regression.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");

const LUA = [
  { label: "float literal keeps .0", src: "print(5.0)", want: "5.0" },
  { label: "integer literal stays integer", src: "print(5)", want: "5" },
  { label: "exponent literal is float", src: "print(1e3)", want: "1000.0" },
  { label: "hex float literal", src: "print(0x1p4)", want: "16.0" },
  { label: "hex integer literal", src: "print(0x10)", want: "16" },
  { label: "leading-dot literal", src: "print(.5)", want: "0.5" },
  { label: "math.type of float literal", src: "print(math.type(5.0))", want: "float" },
  { label: "math.type of integer literal", src: "print(math.type(5))", want: "integer" },
  { label: "float // int is float", src: "print(math.type(5.0 // 2))", want: "float" },
  { label: "int // int is integer", src: "print(math.type(5 // 2))", want: "integer" },
  { label: "idiv float value", src: "print(7.0 // 2.0)", want: "3.0" },
  { label: "idiv of non-integral float", src: "print((5.5) // 1)", want: "5.0" },
  { label: "idiv int", src: "print(7 // 2)", want: "3" },
  { label: "idiv negative rounds toward -inf", src: "print(-7 // 2)", want: "-4" },
  { label: "idiv float divisor", src: "print(10 // 3.0)", want: "3.0" },
  { label: "div always float", src: "print(6 / 3)", want: "2.0" },
  { label: "mod float", src: "print(5.5 % 2)", want: "1.5" },
  { label: "mod int", src: "print(7 % 3)", want: "1" },
  { label: "pow always float", src: "print(2 ^ 3)", want: "8.0" },
  { label: "float equality with integer", src: "print(5.0 == 5)", want: "true" },
  { label: "float through a local", src: "local x = 4.0 print(x // 1) print(math.type(x))", want: "4.0\nfloat" },
  { label: "integral float table key normalizes to integer", src: 'local t = { [2.0] = "float-key" } print(t[2]) print(math.type(next(t)))', want: "float-key\ninteger" },
  { label: "non-integral float table key stays float", src: 'local t = {} t[2.5] = "x" print(t[2.5]) print(math.type(next(t)))', want: "x\nfloat" },
  { label: "integral float formatted", src: 'print(string.format("%s|%.1f", 5.0, 5.0))', want: "5.0|5.0" },
  { label: "integer overflow wraps", src: "print(math.maxinteger + 1)", want: "-9223372036854775808" },
  { label: "accumulator loop mixes subtypes", src: "local a = 0.0 for i = 1, 4 do a = a + i // 2 end print(a)", want: "4.0" },
  // Hex float spellings: Lua 5.4 makes the p-exponent optional and allows either side of the dot
  // to be empty, so Number() cannot read them and the lexer has to compute the double itself.
  { label: "hex float without exponent", src: "print(0x1.8) print(math.type(0x1.8))", want: "1.5\nfloat" },
  { label: "hex float with empty fraction", src: "print(0x1.) print(math.type(0x1.))", want: "1.0\nfloat" },
  { label: "hex float with empty whole part", src: "print(0x.8) print(math.type(0x.8))", want: "0.5\nfloat" },
  { label: "hex float with exponent and fraction", src: "print(0x1.1111p4) print(0x.8p1) print(0x8p-1)", want: "17.066650390625\n1.0\n4.0" },
  { label: "hex float equals decimal float", src: "print(0x1.8 == 1.5, 0x1p4 == 16.0, math.type(0x1p4))", want: "true\ttrue\tfloat" },
  { label: "trailing dot is a float literal", src: "print(5.) print(math.type(5.))", want: "5.0\nfloat" },
];

const LUAU = [
  { label: "luau prints integral float bare", src: "print(5.0)", want: "5" },
  { label: "luau typeof is number for both", src: "print(typeof(5.0), typeof(5))", want: "number\tnumber" },
  { label: "luau floor division", src: "print(7 // 2) print(-7 // 2)", want: "3\n-4" },
  { label: "luau float division", src: "print(6 / 3) print(5.5 % 2)", want: "2\n1.5" },
  { label: "luau floor of float divisor", src: "print(10 // 3.0)", want: "3" },
  // Luau-only spellings: underscore right after the base prefix, and a trailing dot.
  { label: "luau underscore after hex prefix", src: "print(0x_FF) print(0b_1)", want: "255\n1" },
  { label: "luau trailing dot and dot fraction", src: "print(5.) print(1._5) print(5.e1)", want: "5\n1.5\n50" },
];

const CASES = [
  ...LUA.map((c) => ({ ...c, target: "lua" })),
  ...LUAU.map((c) => ({ ...c, target: "luau" })),
];

const MODES = ["stack", "register"];
const PRESETS = ["l1", "l2"];

const hosts = { lua: resolveRuntime("lua"), luau: resolveRuntime("luau") };
assert.ok(hosts.lua && hosts.luau, "both native hosts must resolve for the numeric suite to prove anything");

let cells = 0;
const pinned = [];

for (const testCase of CASES) {
  const exe = hosts[testCase.target];

  // The pin must be what the host itself prints. If it is not, this suite is wrong, not the engine.
  const control = runProgram(exe, testCase.src, testCase.target, testCase.want);
  assert.ok(control.ok,
    `${testCase.target} ${testCase.label}: host source output ${JSON.stringify(control.stdout)} != pinned ${JSON.stringify(testCase.want)} (status ${control.status})`);
  pinned.push(testCase.label);

  for (const preset of PRESETS) {
    for (const mode of MODES) {
      const built = obfuscate(testCase.src, { preset, target: testCase.target, mode, seed: 0x59c0de, junkForge: false });
      assert.strictEqual(built.vmMeta.fallback, false,
        `${preset}/${mode} ${testCase.target} ${testCase.label}: must exercise the custom VM`);
      const ran = runProgram(exe, built.output, testCase.target, testCase.want);
      assert.ok(ran.ok,
        `${preset}/${mode} ${testCase.target} ${testCase.label}: artifact stdout ${JSON.stringify(ran.stdout)} != ${JSON.stringify(testCase.want)} (status ${ran.status})`);
      cells++;
    }
  }
}

// The float path must be a real encoding choice, not a formatting accident: the same value written
// two ways has to reach the host as two different subtypes, and a value the source never wrote as a
// float must stay an integer.
const subtypePair = `print(5.0) print(5) print(5.0 + 0) print(math.maxinteger // 2)`;
for (const mode of MODES) {
  const built = obfuscate(subtypePair, { preset: "l2", target: "lua", mode, seed: 0x59c0de, junkForge: false });
  const ran = runProgram(hosts.lua, built.output, "lua");
  assert.ok(ran.ok, `subtype pair ${mode}: build must run, got ${JSON.stringify(ran.stdout)}`);
  assert.strictEqual(ran.stdout, "5.0\n5\n5.0\n4611686018427387903",
    `subtype pair ${mode}: integral float, integer and integer floor-div must stay distinct`);
  cells++;
}

// A literal inside a nested function is a separate chunk in the payload; the float text must survive
// the per-chunk reader too, not just the root chunk.
const nested = `local function half(x) return x / 2 end
local function scaled() return half(9.0) * 2 end
print(scaled()) print(half(9)) print(math.type(scaled()))`;
for (const mode of MODES) {
  const built = obfuscate(nested, { preset: "l2", target: "lua", mode, seed: 0x59c0de, junkForge: false });
  const ran = runProgram(hosts.lua, built.output, "lua");
  assert.ok(ran.ok, `nested chunk float ${mode}: ${JSON.stringify(ran.stdout)}`);
  assert.strictEqual(ran.stdout, "9.0\n4.5\nfloat", `nested chunk float ${mode} keeps the float through MAKEFUNC`);
  cells++;
}

console.log("ByteVeil v5.9 numeric fidelity suite: PASS");
console.log(`  ${CASES.length} pinned cases (${LUA.length} Lua 5.4 + ${LUAU.length} Luau), each host-checked then rebuilt as ${PRESETS.length} presets x ${MODES.length} modes`);
console.log(`  ${cells} artifact cells run on ${hosts.lua} + ${hosts.luau} with stdout equal to the pin`);
console.log(`  subtype pair + nested-chunk float cells are asserted from a fixed expected string`);

"use strict";

// ByteVeil v5.9 engine precheck suite.
//
// The precheck re-reads the finished artifact with the engine's own front end and refuses the
// build when the text and the build metadata disagree. Two things have to be true for that to
// be worth anything: it must catch every fault class it claims to catch, and it must not
// refuse a healthy build. So each check is exercised with a synthetic artifact that is wrong
// in exactly one way, and the real artifacts are run through the same gate.
//
// The gate itself is proven live by installing a failing verdict on the precheck module: a
// refused build has to surface as a thrown obfuscate(), not as a warning in metadata.

const assert = require("node:assert/strict");

// The pipeline resolves the precheck through its module object at call time, which is what
// lets this suite install a deliberately failing verdict and watch the build abort.
const precheckModule = require("./src/core/precheck");
const realPrecheck = precheckModule.precheckArtifact;
const { obfuscate } = require("./src");

const { parse } = require("./src/frontend");
const { ENGINE_VERSION } = require("./src/core/version");

const SEED = 0x59A1FEED;
const SRC = 'local NAME="veil-string-secret" local function f(a) return a..NAME end print(f("x"), ("ab"):upper())';

function precheck(body, vmMeta = {}, options = {}) {
    return realPrecheck({ output: body, source: "print(1)", vmMeta, target: "lua", options });
}

const faults = [];
const controls = [];
function expectFatal(label, body, vmMeta, options, phrase) {
    const result = precheck(body, vmMeta, options);
    faults.push({ label, fatal: result.fatal.length });
    assert.equal(result.ok, false, `${label}: a wrong artifact must be refused`);
    assert.ok(result.fatal.some((message) => message.includes(phrase)),
        `${label}: expected a fatal mentioning ${JSON.stringify(phrase)}, got ${JSON.stringify(result.fatal)}`);
    return result;
}
function expectClean(label, body, vmMeta, options = {}) {
    const result = precheck(body, vmMeta, options);
    controls.push(label);
    assert.equal(result.ok, true, `${label}: a healthy artifact must be accepted (${JSON.stringify(result.fatal)})`);
    return result;
}

// 1. The artifact has to parse with the engine's own parser.
expectFatal("unparseable body", "local x = ", {}, {}, "does not parse");

// 2. A build that claims a bound key bed must ship a root that reads holders it declares.
expectFatal("undeclared key addend",
    "local v=(aa+bb+cc)%4294967296 print(v)",
    { junkForge: { keyBedBound: true } }, {}, "no region root reads holders");
//    ... and the reverse: a holder that is only declared after the root is read.
expectFatal("late-declared key addend",
    "local v=(aa+bb+cc)%4294967296 local cc=3 print(v)",
    { junkForge: { keyBedBound: true } }, {}, "no region root reads holders");
const cleanKeyBody = "local aa=1 local bb=2 local cc=3 local v=(aa+bb+cc)%4294967296 print(v)";
expectClean("declared three-addend root", cleanKeyBody, { junkForge: { keyBedBound: true } });

// 3. A double-bound build folds three addends; two means the verdict addend went missing.
expectFatal("missing verdict addend",
    "local aa=1 local bb=2 local v=(aa+bb)%4294967296 print(v)",
    { junkForge: { keyBedBound: true }, guardKeyBound: true, antiGuardKey: { value: 4, reads: 1 }, antiHookVerdict: { expectedDigest: 4 } },
    {}, "must fold three addends");

// 4. The bound verdict has to be the number the emitted guard compares against.
expectFatal("verdict disagrees with digest",
    cleanKeyBody,
    { guardKeyBound: true, antiGuardKey: { value: 5, reads: 1 }, antiHookVerdict: { expectedDigest: 6 } },
    {}, "is not the emitted guard verdict");
expectFatal("verdict bound with no read",
    cleanKeyBody,
    { guardKeyBound: true, antiGuardKey: { value: 7, reads: 0 }, antiHookVerdict: { expectedDigest: 7 } },
    {}, "bound verdict with no read");
expectClean("agreeing verdict with reads", cleanKeyBody,
    { guardKeyBound: true, antiGuardKey: { value: 7, reads: 2 }, antiHookVerdict: { expectedDigest: 7 } });

// 5. JavaScript template holes must not survive into the emitted Lua. `undefined` and `NaN`
//    are legal Lua names, so only the diagnostic check can catch them; a bare
//    `[object Object]` is not legal Lua at all, so the reparse catches that one first.
expectFatal("template hole undefined", "local x = undefined print(x)", {}, {}, "template hole");
expectFatal("template hole NaN", "local x = NaN print(x)", {}, {}, "template hole");
(function () {
    const result = precheck("local x = [object Object] print(x)", {}, {});
    assert.equal(result.ok, false, "a stringified object in the emitted code must be refused");
    faults.push({ label: "object hole as syntax error", fatal: result.fatal.length });
})();

// 6. A stale engine stamp is a packaging bug.
expectFatal("stale engine stamp",
    `print("This file was protected using ByteVeil Obfuscator v4.0.0 [https://example.invalid/]")`,
    {}, {}, `while the engine is ${ENGINE_VERSION}`);

// 7. The forge census has to match the containers actually in the body.
expectFatal("container census shortfall",
    "local s = [==[onlyone]==] print(s)", { junkForge: { containers: 9 } }, {}, "long-bracket literal");
expectClean("matching container census",
    "local s = [==[one]==] local t = [==[two]==] print(s, t)", { junkForge: { containers: 2 } });
//    Blob content must not be counted as code: a carrier alphabet can carry any word.
expectClean("template words inside a blob are content, not code",
    "local s = [==[undefined NaN [object Object]]==] print(s)", {});
expectFatal("stale stamp inside a literal is still a stamp",
    "local s = [==[ByteVeil Obfuscator v9.9.9]==] print(s)", {}, {}, "engine stamp");

// 8. The size cap is a promise to the caller.
expectFatal("over the size cap", "print(" + JSON.stringify("x".repeat(500)) + ")", {}, { maxOutputBytes: 64 }, "over the 64 byte cap");

// 9. A ciphered payload must publish the root its string keys derive from - and publish it
//    *computed*. The crash ladder also writes `G.materialRoot=0`, so a body whose only root
//    assignments are literals has a key that can be pinned without touching a latch.
expectFatal("cipher applied without a published root",
    "local x = 1 print(x)", { stringCipher: { applied: true, constants: 4, algorithm: "veil-str-v1" } }, {},
    "never publishes the material root");
expectFatal("cipher applied with a pinned root",
    "G.materialRoot=0; G.materialRoot=nil; print(G.materialRoot)",
    { stringCipher: { applied: true, constants: 4, algorithm: "veil-str-v1" } }, {},
    "material root assignment(s) are literals");
expectFatal("cipher applied with an empty census",
    "local x = 1 G.materialRoot=7 print(x)", { stringCipher: { applied: true, constants: 0, algorithm: "veil-str-v1" } }, {},
    "zero ciphered constants");
expectClean("published fold root with a non-empty census", "G.materialRoot=(a+b+c)%4294967296 print(G.materialRoot)",
    { stringCipher: { applied: true, constants: 3, cipheredBytes: 40, algorithm: "veil-str-v1" } });
expectClean("root published as the region seed local", "G.materialRoot=k4 print(G.materialRoot)",
    { stringCipher: { applied: true, constants: 3, cipheredBytes: 40, algorithm: "veil-str-v1" } });

// ---------------------------------------------------------------------------
// Real artifacts: the gate must pass every shipped route, and must be observable.
// ---------------------------------------------------------------------------
const Runtimes = ["lua", "luau"];
const observed = [];
for (const target of Runtimes) {
    for (const preset of ["l1", "default", "maximum"]) {
        for (const mode of ["stack", "register"]) {
            const built = obfuscate(SRC, { target, preset, mode, seed: SEED + preset.length });
            const report = built.vmMeta?.precheck;
            assert.ok(report, `${target}/${preset}/${mode}: every build must carry a precheck report`);
            assert.deepEqual(report.fatal, [], `${target}/${preset}/${mode}: healthy build refused by the precheck (${report.fatal.join(" | ")})`);
            assert.equal(report.reparsed, true, `${target}/${preset}/${mode}: the artifact must reparse with the engine parser`);
            assert.ok(report.bytes > 1000 && report.bytes === Buffer.byteLength(built.output, "utf8"),
                `${target}/${preset}/${mode}: the byte census must describe the shipped text`);
            assert.ok(report.checks.some((check) => check.name === "veil-str"),
                `${target}/${preset}/${mode}: a ciphered route must report the VeilStr check`);
            observed.push({
                key: `${target}/${preset}/${mode}`,
                checks: report.checks.length,
                bytes: report.bytes,
                topLevel: report.topLevelStatements,
                leaks: report.plaintextLeaks ?? 0,
                literals: report.sourceStringLiterals ?? 0,
                constants: report.stringCipher?.constants ?? 0
            });
        }
    }
}
assert.equal(observed.length, 12, "twelve routes must be prechecked");
assert.ok(observed.every((entry) => entry.constants > 0), "every prechecked route must cipher its constants");

// The precheck reads the shipped text, so a metadata field that disagrees with it has to be
// caught even when the build itself was healthy.
const liveBuild = obfuscate(SRC, { target: "lua", preset: "l1", mode: "register", seed: SEED });
const inflated = realPrecheck({ output: liveBuild.output, source: SRC, vmMeta: { ...liveBuild.vmMeta, junkForge: { ...liveBuild.vmMeta.junkForge, containers: 999999 } }, target: "lua", options: {} });
assert.equal(inflated.ok, false, "a forged container census must be refused against the real body");
const stripped = realPrecheck({ output: liveBuild.output.replace(/G\.materialRoot=[^;]*;/g, "G.materialRoot=nil;"), source: SRC, vmMeta: liveBuild.vmMeta, target: "lua", options: {} });
assert.ok(stripped.fatal.some((message) => /material root/i.test(message)),
    `pinning the published root to a constant must be caught on a real artifact (${JSON.stringify(stripped.fatal)})`);

// Failing the precheck has to throw, not warn.
let threw = null;
try {
    obfuscate(SRC, { target: "lua", preset: "l1", mode: "register", seed: SEED });
} catch (error) {
    threw = error;
}
assert.ok(threw === null, "the real precheck must not throw on a healthy build");
// With the injected-fault wrapper live the same build has to be refused outright.
precheckModule.precheckArtifact = ({ output, source, vmMeta = {}, target = "lua", options = {} }) => {
    const verdict = realPrecheck({ output, source, vmMeta, target, options });
    return { ...verdict, ok: false, fatal: [...verdict.fatal, "injected: the artifact and its metadata disagree"] };
};
let gateError = null;
try {
    obfuscate(SRC, { target: "lua", preset: "l1", mode: "register", seed: SEED });
} catch (error) {
    gateError = error;
}
precheckModule.precheckArtifact = realPrecheck;
assert.ok(gateError, "a refused precheck must abort the build instead of shipping the artifact");
assert.match(gateError.message, /engine precheck failed/, `the build error must name the precheck (${gateError && gateError.message})`);
assert.match(gateError.message, /injected/, "the build error must carry the reason");

// Opt-out must be observable in the metadata, and must not break the build.
const optedOut = obfuscate(SRC, { target: "lua", preset: "l1", mode: "register", seed: SEED, precheck: { enabled: false } });
assert.equal(optedOut.vmMeta.precheck, undefined, "precheck:{enabled:false} must skip the gate and report nothing");
const optedOutFlat = obfuscate(SRC, { target: "lua", preset: "l1", mode: "register", seed: SEED, precheck: false });
assert.equal(optedOutFlat.vmMeta.precheck, undefined, "precheck:false must also skip the gate");

// The gate must not be a wall-clock problem: measure the reparse of a shipped artifact.
const timed = [];
for (const key of ["l1/stack", "maximum/register"]) {
    const [preset, mode] = key.split("/");
    const built = obfuscate(SRC, { target: "lua", preset, mode, seed: SEED });
    const t0 = process.hrtime.bigint();
    parse(built.output);
    timed.push({ key, ms: Number(process.hrtime.bigint() - t0) / 1e6 });
}
assert.ok(timed.every((entry) => entry.ms < 5000), `reparsing an artifact must stay cheap (${JSON.stringify(timed)})`);

// Every source literal the precheck calls a leak must really be present in the text.
const leakProbe = realPrecheck({ output: liveBuild.output, source: 'print("definitely-not-in-the-artifact-9f3a")', vmMeta: liveBuild.vmMeta, target: "lua", options: {} });
assert.equal(leakProbe.report.plaintextLeaks, 0, "a literal that is not shipped cannot be counted as a leak");

console.log("ByteVeil v5.9 engine precheck suite: PASS");
console.log(`  synthetic faults: ${faults.length} classes refused, ${controls.length} positive controls accepted`);
console.log(`  live routes: ${observed.length} builds prechecked, 0 fatal, ${observed.reduce((n, e) => n + e.checks, 0)} checks total,`
    + ` ${Math.min(...observed.map((e) => e.bytes))}-${Math.max(...observed.map((e) => e.bytes))} bytes,`
    + ` ${observed.reduce((n, e) => n + e.constants, 0)} ciphered constants`);
console.log(`  gate: refused build aborted with the reason, opt-out reported nothing, reparse cost`
    + ` ${timed.map((t) => `${t.key}=${t.ms.toFixed(1)}ms`).join(" ")}`);

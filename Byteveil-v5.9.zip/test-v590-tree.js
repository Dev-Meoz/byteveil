"use strict";
// v5.9.0 tree + option-surface honesty suite.
//
// Two weaknesses this closes for good:
//  (a) previous-generation engines sitting inside src/ where no shipped route can reach them,
//      so nobody can tell which code is authoritative;
//  (b) option keys that are defined (in presets or by a caller) but read by nothing, so a
//      build silently does less than the caller asked.
// Both are checked structurally, and the refusal behaviour is checked by running the engine.

const assert = require("assert");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = __dirname;
const SRC = path.join(ROOT, "src");
const LEGACY = path.join(ROOT, "legacy");
const registry = require("./src/core/option_registry");
const { PRESETS } = require("./src/presets");
const { obfuscate } = require("./src");
const { ENGINE_VERSION } = require("./src/core/version");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./tools/native-runtime");

const listJs = (dir) => {
  const out = [];
  (function walk(d) {
    for (const name of fs.readdirSync(d)) {
      const p = path.join(d, name);
      const st = fs.statSync(p);
      if (st.isDirectory()) walk(p);
      else if (name.endsWith(".js")) out.push(p);
    }
  })(dir);
  return out;
};

const rel = (p) => path.relative(ROOT, p).split(path.sep).join("/");
const REQUIRE_RE = /require\(\s*(?:\.resolve\s*\(\s*)?(['"`])([^'"`]+)\1\s*\)/g;

function literalSpecifiers(file) {
  const text = fs.readFileSync(file, "utf8");
  const specs = [];
  let m;
  while ((m = REQUIRE_RE.exec(text))) {
    const spec = m[2];
    if (spec.includes("${")) throw new Error(`dynamic require in ${rel(file)}: ${spec}`);
    specs.push(spec);
  }
  return specs;
}

function resolveLocal(fromFile, spec) {
  const base = path.resolve(path.dirname(fromFile), spec);
  const asFile = fs.existsSync(base) && fs.statSync(base).isFile() ? base : `${base}.js`;
  const asDir = path.join(base, "index.js");
  if (fs.existsSync(asFile)) return asFile;
  if (fs.existsSync(asDir)) return asDir;
  return null;
}

// ---- 1. the shipped tree has no orphan engine -------------------------------------------
const srcFiles = listJs(SRC);
const seen = new Set();
const queue = [path.join(SRC, "index.js")];
const externalIntoLegacy = [];
while (queue.length) {
  const file = queue.pop();
  if (seen.has(file)) continue;
  seen.add(file);
  for (const spec of literalSpecifiers(file)) {
    if (!spec.startsWith(".")) continue;
    const target = resolveLocal(file, spec);
    if (!target) continue;
    const targetRel = rel(target);
    if (targetRel.startsWith("legacy/")) externalIntoLegacy.push(`${rel(file)} -> ${targetRel}`);
    if (targetRel.startsWith("src/")) queue.push(target);
  }
}
const orphans = srcFiles.filter((f) => !seen.has(f)).map(rel);
assert.strictEqual(orphans.length, 0, `every file under src/ must be reachable from src/index.js; orphans: ${orphans.join(", ")}`);
assert.strictEqual(externalIntoLegacy.length, 0, `src/ must not depend on quarantined code: ${externalIntoLegacy.join(", ")}`);

// ---- 2. obsolete engines are gone, not relocated ------------------------------------------
// v5 shipped 38 dead engine files inside the archive under legacy/. Quarantine-in-place was
// rejected, so the tree must not hold them at all, and no live file may reach them by require.
assert.ok(!fs.existsSync(LEGACY), 'obsolete engines must not exist in the project: found a "legacy" directory');
const DEAD_ENGINES = [
  "analysis/index.js", "analysis/scope_resolver.js", "analysis/semantic.js", "analysis/symbol_table.js",
  "backend/hybrid_generator.js", "backend/lua/bit.js", "backend/lua/utils.js", "backend/lua_engine.js",
  "backend/printer.js", "backend/source_engine.js", "backend/source_engine_lua_v280.js",
  "backend/source_engine_lua_v290.js", "backend/source_engine_luau_v270.js", "backend/source_engine_luau_v280.js",
  "backend/source_engine_luau_v290.js", "backend/source_engine_v280.js", "backend/source_engine_v290.js",
  "compiler/register/reg-vm-gen.js", "compiler/stack/vm-gen.js", "core/bytecode_runtime.js",
  "core/diagnostics.js", "core/options.js", "obfuscation/decoder.js", "obfuscation/opcode.js",
  "obfuscation/polymorphic_opcode.js", "runtime/lua_runtime.js", "runtime/vm-runner.js",
  "transforms/variable_renamer.js", "utils/bit.js", "utils/index.js", "vm/index.js", "vm/vm_decoder.js",
  "vm/vm_dispatcher.js", "vm/vm_island.js", "vm/vm_regions.js", "vm/vm_state.js", "wrappers/index.js"
];
const resurrected = DEAD_ENGINES.filter((f) => fs.existsSync(path.join(ROOT, "src", f)));
assert.deepStrictEqual(resurrected, [], `obsolete engine files reappeared under src/: ${resurrected.join(", ")}`);

const legacyRefs = [];
for (const dir of ["src", "bot", "tools"]) {
  for (const f of listJs(path.join(ROOT, dir))) {
    for (const spec of literalSpecifiers(f)) if (spec.includes("legacy/")) legacyRefs.push(`${rel(f)} -> ${spec}`);
  }
}
assert.deepStrictEqual(legacyRefs, [], `live code requires obsolete engines: ${legacyRefs.join(", ")}`);

// Every live engine file must still parse (replaces the legacy-only parse check).
const rotten = [];
for (const f of srcFiles) {
  try {
    new vm.Script(fs.readFileSync(f, "utf8"), { filename: f });
  } catch (e) {
    rotten.push(`${rel(f)}: ${e.message}`);
  }
}
assert.deepStrictEqual(rotten, [], `live engine files must parse:\n${rotten.join("\n")}`);

// ---- 3. no preset key is decorative -------------------------------------------------------
const unregistered = [];
for (const [name, preset] of Object.entries(PRESETS)) {
  if (!preset) continue;
  for (const key of Object.keys(preset)) {
    if (!registry.TOP_LEVEL.has(key)) unregistered.push(`${name}.${key}`);
  }
  for (const key of Object.keys(preset.transforms || {})) {
    if (!registry.TRANSFORM_KEYS.has(key)) unregistered.push(`${name}.transforms.${key}`);
  }
  for (const key of Object.keys(preset.wrapper || {})) {
    if (!registry.WRAPPER_KEYS.has(key)) unregistered.push(`${name}.wrapper.${key}`);
  }
}
assert.deepStrictEqual(unregistered, [], `presets may only carry registered keys: ${unregistered.join(", ")}`);

const retiredInPresets = [];
for (const [name, preset] of Object.entries(PRESETS)) {
  if (!preset) continue;
  for (const key of registry.RETIRED.keys()) {
    const [head, leaf] = key.includes(".") ? [key.split(".")[0], key.split(".")[1]] : [key, null];
    if (leaf === null ? Object.prototype.hasOwnProperty.call(preset, head) : (preset[head] && Object.prototype.hasOwnProperty.call(preset[head], leaf))) {
      retiredInPresets.push(`${name}.${key}`);
    }
  }
}
assert.deepStrictEqual(retiredInPresets, [], `retired knobs must not come back through a preset: ${retiredInPresets.join(", ")}`);

// Every registered key must have a reader somewhere in the live tree. Definition sites are
// excluded so the check cannot be satisfied by the registry/preset/env listing itself.
const DEFINITION_SITES = new Set(["src/core/option_registry.js", "src/presets/index.js", "src/core/env.js"]);
const srcText = srcFiles.filter((f) => !DEFINITION_SITES.has(rel(f))).map((f) => [rel(f), fs.readFileSync(f, "utf8")]);
const unread = [];
for (const key of registry.TOP_LEVEL) {
  if (key === "strictOptions") continue; // consumed inside the registry itself, by design
  const re = new RegExp(`(?:\\?\\.|\\.)\\s*${key}\\b`);
  if (!srcText.some(([, text]) => re.test(text))) unread.push(key);
}
for (const key of registry.TRANSFORM_KEYS) {
  const re = new RegExp(`(?:\\?\\.|\\.)\\s*${key}\\b`);
  if (!srcText.some(([, text]) => re.test(text))) unread.push(`transforms.${key}`);
}
for (const [parent, bucket] of [["wrapper", registry.WRAPPER_KEYS], ["junkForge", registry.JUNK_FORGE_KEYS], ["precheck", registry.PRECHECK_KEYS]]) {
  for (const key of bucket) {
    const re = new RegExp(`(?:\\?\\.|\\.)\\s*${key}\\b`);
    if (!srcText.some(([, text]) => re.test(text))) unread.push(`${parent}.${key}`);
  }
}
assert.deepStrictEqual(unread, [], `registered keys with no reader in src/: ${unread.join(", ")}`);

// ---- 4. asking for a retired knob refuses the build ---------------------------------------
const SOURCE = 'print("tree-suite")';
const REFUSALS = [
  [{ debug: true }, /debug is not implemented/],
  [{ nestedSourceEngine: "legacy-wrapSource-v4.7.4" }, /nestedSourceEngine is not implemented/],
  [{ nestedProfile: "full" }, /nestedProfile is not implemented/],
  [{ transforms: { payloadDecoys: 5 } }, /transforms\.payloadDecoys is not implemented/],
  [{ transforms: { gsubAnchor: true } }, /transforms\.gsubAnchor is not implemented/]
];
let refused = 0;
for (const [options, pattern] of REFUSALS) {
  assert.throws(() => obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false, ...options }), pattern,
    `${JSON.stringify(options)} must refuse the build`);
  refused++;
}
// A falsy value for a retired key stays harmless: old scripts that pass `debug:false`
// or an empty decoy count must keep building.
for (const options of [{ debug: false }, { nestedProfile: "" }, { transforms: { payloadDecoys: 0 } }, { transforms: { gsubAnchor: false } }]) {
  obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false, ...options });
}

// ---- 4b. every accepted *value* of an enumerated key is a route that exists ----------------
// A key can be registered and still be a stub if the engine only branches on some of the
// values it accepts: `backend` used to route anything outside vm35/vm33 onto the
// source-container fallback, `target` fell through to auto-detection, `mode` fell through to
// register, and `wrapper.returnMode:"direct"` was overruled by the default `setmeta:true`.
const presetEnumOutliers = [];
for (const [name, preset] of Object.entries(PRESETS)) {
  if (!preset) continue;
  for (const [key, allowed] of registry.ENUMS) {
    const value = registry.optionValueAt(preset, key);
    if (value !== undefined && !allowed.has(value)) presetEnumOutliers.push(`${name}.${key}=${value}`);
  }
}
assert.deepStrictEqual(presetEnumOutliers, [], `preset enum values outside the registered set: ${presetEnumOutliers.join(", ")}`);

const ROUTES = [
  ["backend", "vm35", (r) => r.vmMeta.fallback !== true],
  ["backend", "vm33", (r) => r.vmMeta.fallback !== true],
  ["backend", "source", (r) => r.vmMeta.fallback === true],
  ["mode", "stack", (r) => r.vmMeta.mode === "stack"],
  ["mode", "register", (r) => r.vmMeta.mode === "register"],
  ["mode", "hybrid", () => true],
  ["target", "lua", (r) => r.target === "lua"],
  ["target", "luau", (r) => r.target === "luau"],
  ["target", "auto", () => true]
];
for (const [key, value, holds] of ROUTES) {
  const built = obfuscate(SOURCE, { preset: "l1", seed: 7, junkForge: false, [key]: value });
  assert.ok(holds(built), `${key}="${value}" must build and route as the engine documents`);
}

const VALUE_REFUSALS = [
  [{ backend: "vm36" }, /backend has unsupported value "vm36"/],
  [{ backend: "VM35" }, /backend has unsupported value "VM35"/],
  [{ target: "lua54" }, /target has unsupported value "lua54"/],
  [{ mode: "statck" }, /mode has unsupported value "statck"/],
  [{ wrapper: { returnMode: "setMetatable" } }, /wrapper\.returnMode has unsupported value/]
];
let valueRefusals = 0;
for (const [options, pattern] of VALUE_REFUSALS) {
  assert.throws(() => obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false, ...options }), pattern,
    `${JSON.stringify(options)} must refuse the build instead of silently re-routing it`);
  valueRefusals++;
}

// Each returnMode value must actually change the emitted shape, and the boolean alias must
// agree with the named selector now that normalizeOptions lets the caller's wrapper spec win.
const shapeOf = (wrapper) => {
  const built = obfuscate(SOURCE, { preset: "l1", seed: 0x59e0, junkForge: false, wrapper });
  return { sha: crypto.createHash("sha256").update(built.output, "utf8").digest("hex"), shape: built.vmMeta.wrapper.shape, built };
};
const shapes = {};
for (const mode of ["setmetatable", "direct", "gsub"]) shapes[mode] = shapeOf({ returnMode: mode });
assert.strictEqual(new Set(Object.values(shapes).map((s) => s.sha)).size, 3,
  `returnMode values must produce distinct artifacts: ${Object.entries(shapes).map(([k, s]) => `${k}=${s.sha.slice(0, 8)}`).join(" ")}`);
assert.strictEqual(shapes.direct.shape, "direct-callable-tail", "direct must report the tail it actually emitted");
assert.strictEqual(shapes.setmetatable.shape, "callable-object", "the bootstrap tail must stay labelled as a bootstrap");
const alias = shapeOf({ setmeta: false });
assert.strictEqual(alias.sha, shapes.direct.sha, "{setmeta:false} and {returnMode:'direct'} are two names for one shape");
assert.strictEqual(alias.shape, "direct-callable-tail");

// `nestedProfile` is the counter-example that earned a retirement: the value was still
// forwarded into the engines, but on every route reachable from obfuscate() the profile is
// pinned by the VM version (customVM.js `chosenNestedProfile`, reported as vmMeta.nestedProfile)
// or hardcoded by the nest branch — measured identical bytes for "full" and "balanced" on 6
// route cells (scratch/probe_nested_profile.js), so the REFUSALS entry above is what keeps
// the knob from coming back as a silent no-op.
const pinned = obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false });
assert.strictEqual(pinned.vmMeta.nestedProfile, require("./src/core/version").NESTED_PROFILE,
  "the shipped route must report the profile it pinned, not one a caller asked for");

// ---- 4c. the newly-reachable shapes run on a real host ------------------------------------
for (const host of ["lua", "luau"]) {
  const runtime = resolveRuntime(host);
  if (!runtime) continue;
  const checks = {
    "direct wrapper": shapes.direct.built,
    "gsub wrapper": shapes.gsub.built,
    "source container": obfuscate(SOURCE, { preset: "l1", target: host, seed: 7, junkForge: false, backend: "source" })
  };
  for (const [label, built] of Object.entries(checks)) {
    const syntax = runSyntaxCheck(runtime, built.output, host);
    assert.ok(syntax.ok, `${host}/${label}: emitted artifact must parse — ${syntax.stderr}`);
  }
}

// ---- 4d. a route may only claim the engine that actually built it -------------------------
// `buildSourceFallback` used to answer "Luau custom VM"/"Lua 5.1-5.5 custom VM" while its own
// `bytecode` was null and `vmMeta.fallback` true, and it required `source_engine_v46_compat`
// twice under two different names so the code read like a per-target engine. Both claims are
// now checkable, and the byte equality below is what proves the single-engine truth.
const sourceRoutes = {};
for (const host of ["lua", "luau"]) {
  const built = obfuscate(SOURCE, { preset: "l1", target: host, seed: 0x59e0, junkForge: false, backend: "source" });
  sourceRoutes[host] = built;
  assert.strictEqual(built.bytecode, null, `${host}: the source container compiles no VM`);
  assert.strictEqual(built.vmMeta.fallback, true, `${host}: the source container is the fallback route`);
  assert.ok(/compatibility runtime$/.test(built.runtime),
    `${host}: source route must name the runtime of the engine that built it, got ${JSON.stringify(built.runtime)}`);
  assert.ok(!/custom VM/.test(built.runtime), `${host}: a route with no VM must not claim a custom VM`);
  assert.strictEqual(built.validation.runtime, built.runtime, `${host}: validation must agree with the reported runtime`);
}
assert.strictEqual(sourceRoutes.lua.output, sourceRoutes.luau.output,
  "one compatibility engine serves both targets: measured byte-identical containers, so the runtime label is the only difference");

// `shape` is read off the emitted tail, and a gsub container ends exactly like a build with no
// wrapper at all — the two used to be indistinguishable in the report.
assert.strictEqual(shapes.gsub.shape, "no-callable-bootstrap-tail", "gsub container has no callable bootstrap tail");
const wrapperOff = obfuscate(SOURCE, { preset: "l1", seed: 0x59e0, junkForge: false, wrapper: false });
assert.strictEqual(wrapperOff.vmMeta.wrapper.shape, shapes.gsub.shape, "the tail heuristic really does collide here");
assert.strictEqual(wrapperOff.vmMeta.wrapper.enabled, false);
assert.strictEqual(shapes.gsub.built.vmMeta.wrapper.enabled, true, "so the report must separate gsub-on from wrapper-off");
assert.strictEqual(shapes.gsub.built.vmMeta.wrapper.returnMode, "gsub");
assert.strictEqual(shapes.setmetatable.built.vmMeta.wrapper.returnMode, "setmetatable");

const loose = obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false, antiDumpV9: true, transforms: { mysteryRate: 0.5 } });
assert.ok(loose.optionAudit && Array.isArray(loose.optionAudit.notApplied), "build must expose optionAudit.notApplied");
assert.ok(loose.optionAudit.notApplied.includes("antiDumpV9"), `unknown top-level key must be reported, got ${loose.optionAudit.notApplied.join(",")}`);
assert.ok(loose.optionAudit.notApplied.includes("transforms.mysteryRate"), `unknown transform key must be reported, got ${loose.optionAudit.notApplied.join(",")}`);
assert.throws(() => obfuscate(SOURCE, { preset: "l1", target: "lua", seed: 7, junkForge: false, strictOptions: true, antiDumpV9: true }),
  /strictOptions: unrecognized option key/, "strictOptions must refuse an unrecognized key");

// ---- 6. the shipped route still builds on both hosts ---------------------------------------
for (const target of ["lua", "luau"]) {
  for (const mode of ["register", "stack"]) {
    const r = obfuscate(SOURCE, { preset: "l2", target, mode, seed: 0x59c0de, junkForge: false });
    assert.strictEqual(r.vmMeta.version, ENGINE_VERSION, `${target}/${mode}: engine version stamp`);
    assert.strictEqual(r.vmMeta.precheck.ok, true, `${target}/${mode}: precheck must pass`);
    assert.ok(Buffer.byteLength(r.output) > 1000, `${target}/${mode}: artifact must not collapse`);
  }
}

// ---- 7. Luau chained if-expressions run with source semantics --------------------------------
// The parser used to hard-wire the if-*expression* to two arms, so
// `if a then x elseif b then y else z` threw "Expected else, got elseif" and the build refused,
// while the if-*statement* was fine. Chains now lower to nested two-arm nodes, so the gate must
// check what the host prints, not just that the build survived.
const IF_CHAINS = [
  {
    label: "chain3",
    source: `local function pick(n)
  return if n > 3 then "big" elseif n > 1 then "mid" else "small"
end
print(pick(5)) print(pick(2)) print(pick(0))`,
    expected: "big\nmid\nsmall",
  },
  {
    label: "chain_shortcircuit",
    source: `local log = {}
local function v(name) log[#log + 1] = name return name end
local x = if v("a") then v("b") elseif v("c") then v("d") else v("e")
local y = if false then v("f") elseif v("g") then v("h") else v("i")
local z = if nil then v("j") elseif false then v("k") else v("l")
print(x, y, z)
print(table.concat(log, ","))`,
    expected: "b\th\tl\na,b,g,h,l",
  },
  {
    label: "chain_in_table_and_call",
    source: `local function show(t) print(table.concat(t, "|")) end
local mode = "c"
show({ if mode == "a" then 1 elseif mode == "b" then 2 elseif mode == "c" then 3 else 0,
       if 1 < 2 then "yes" else "no" })
local acc = 0
for i = 1, 4 do acc = acc + (if i % 2 == 0 then i * 10 else i) end
print(acc)`,
    expected: "3|yes\n64",
  },
];

const luauExe = resolveRuntime("luau");
let ifChainCells = 0;
for (const fixture of IF_CHAINS) {
  const control = runProgram(luauExe, fixture.source, "luau", fixture.expected);
  assert.ok(control.ok,
    `${fixture.label}: the fixture itself must print ${JSON.stringify(fixture.expected)} on Luau, got ${JSON.stringify(control.stdout)} (status ${control.status})`);
  for (const mode of ["stack", "register"]) {
    const built = obfuscate(fixture.source, { preset: "l2", target: "luau", mode, seed: 0x59c0de, junkForge: false });
    assert.strictEqual(built.vmMeta.fallback, false, `${fixture.label}/${mode}: must exercise the VM, not the container`);
    const ran = runProgram(luauExe, built.output, "luau", fixture.expected);
    assert.ok(ran.ok,
      `${fixture.label}/${mode}: artifact stdout ${JSON.stringify(ran.stdout)} != ${JSON.stringify(fixture.expected)} (status ${ran.status})`);
    ifChainCells++;
  }
}

console.log(`ByteVeil v5.9 engine-tree / option-surface suite: PASS`);console.log(`  live tree: ${srcFiles.length} files under src/, all reachable from src/index.js, all parse`);
console.log(`  obsolete: legacy/ absent, ${DEAD_ENGINES.length} dead engine files stay deleted, ${legacyRefs.length} live requires point at them`);
console.log(`  options: ${registry.TOP_LEVEL.size} top-level + ${registry.TRANSFORM_KEYS.size} transform keys registered and read, ${registry.RETIRED.size} retired knobs refused (${refused}/${REFUSALS.length})`);
console.log(`  audit: unknown keys reported (${loose.optionAudit.notApplied.join(", ")}), strictOptions refuses them`);
console.log(`  values: ${ROUTES.length} enumerated values build and route as documented, ${valueRefusals}/${VALUE_REFUSALS.length} typos refused, 3 wrapper shapes distinct + alias agrees`);
console.log(`  Luau grammar: ${IF_CHAINS.length} chained if-expression fixtures × stack/register run on ${luauExe ? "luau.exe" : "no host"} with source semantics (${ifChainCells}/${IF_CHAINS.length * 2} cells match)`);

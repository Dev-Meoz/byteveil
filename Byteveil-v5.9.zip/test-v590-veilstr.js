"use strict";

// ByteVeil v5.9 VeilStr-v1 payload cipher suite.
//
// VeilStr gives every string constant in the payload region its own keystream, keyed by the
// build's material root - the number the runtime can only rebuild by folding the JunkForge
// key bed and re-running the anti-hook guard. Each constant also carries a fold of its own
// plaintext bytes, so a wrong key aborts on the read instead of handing the program back a
// string of garbage.
//
// The suite proves three separate things, and none of them by asserting on the generator's
// own bookkeeping:
//   1. semantics - ciphered builds print exactly what the unprotected source prints, on the
//      native Lua 5.4 and Luau binaries, including a source with a nested closure. That is
//      the JS<->Lua key parity check, and the nested case is the one that catches a chunk
//      traversal that disagrees between serializer and reader.
//   2. fail-closed - the two attacks a skidder actually has (pin the published material root,
//      freeze the chunk counter) abort before the payload prints anything.
//   3. load-bearing - with the fold check deleted, the same attacks produce *wrong text*
//      rather than correct text, which proves the cipher is doing the work and the abort is
//      not coming from an unrelated crash.

const assert = require("node:assert/strict");
const { obfuscate } = require("./src");
const { resolveRuntime, runProgram } = require("./tools/native-runtime");
const { VEIL_STR_ALGORITHM, encryptConstant, decryptConstant, constantKey, laneMask, foldCheck } = require("./src/obfuscation/veil_str");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 native runtime is required for the VeilStr suite");
assert.ok(luau, "Luau native runtime is required for the VeilStr suite");

const SEED = 0x59A1C0DE;
const RUNTIMES = [["lua", lua], ["luau", luau]];

// `flat` keeps every constant in one chunk; `nested` forces a second chunk, so the chunk
// sequence the reader keys on has to survive a traversal the serializer ordered differently.
const SOURCES = {
    flat: 'local NAME = "veil-string-secret"\nfunction bv_probe(a,b) return a*b+1 end\nlocal t=0\nfor i=1,4 do t=t+bv_probe(i,i) end\nprint(NAME, t, bv_probe(6,7), ("abc"):upper())',
    nested: 'local function outer(x) local function inner(y) return "veil-"..y.."!" end return inner(x) end print(outer("deep"), outer("string-secret"), ("zz"):rep(3))'
};

// ---------------------------------------------------------------------------
// 0. JS side: the cipher must be an involution and the fold must be stable.
// ---------------------------------------------------------------------------
const jsCensus = { texts: 0, bytes: 0 };
for (const text of ["", "a", "veil-string-secret", "中文 utf8 \n\t\0 ê", "x".repeat(300)]) {
    for (const plan of [{ materialRoot: 0, chunkSeq: 1, index: 0 }, { materialRoot: 4294967295, chunkSeq: 7, index: 12 }, { materialRoot: 1217546451, chunkSeq: 2, index: 0 }]) {
        const sealed = encryptConstant(text, plan);
        assert.equal(sealed.cipher.length, Buffer.byteLength(text, "utf8"), "cipher length must match the plaintext");
        assert.equal(sealed.check, foldCheck(Buffer.from(String(text), "utf8")), "fold must be over the plaintext bytes");
        assert.ok(sealed.check >= 0 && sealed.check <= 250, "fold check byte is a mod-251 value");
        const back = decryptConstant(sealed.cipher, plan);
        assert.equal(Buffer.compare(back, Buffer.from(String(text), "utf8")), 0, `decrypt must invert encrypt for ${JSON.stringify(text.slice(0, 24))}`);
        jsCensus.texts++;
        jsCensus.bytes += sealed.plainLength;
        if (text.length > 0) {
            const other = decryptConstant(sealed.cipher, { ...plan, chunkSeq: plan.chunkSeq + 1 });
            assert.notEqual(Buffer.compare(other, Buffer.from(String(text), "utf8")), 0, "a different chunk sequence must key a different constant");
        }
    }
}
for (const [mr, q, i] of [[0, 1, 0], [4294967295, 3, 2], [1217546451, 12, 11]]) {
    const key = constantKey(mr, q, i);
    assert.ok(Number.isInteger(key) && key >= 0 && key < 4294967296, "constant key stays a 32-bit word");
    for (const [p, lane] of [[0, 0], [3, 1], [7, 2], [299, 0]]) {
        const mask = laneMask(key, p, lane);
        assert.ok(Number.isInteger(mask) && mask >= 0 && mask <= 255, "lane mask stays a byte");
    }
}

// ---------------------------------------------------------------------------
// 1. semantics on the native runtimes.
// ---------------------------------------------------------------------------
const expected = {};
for (const [name, src] of Object.entries(SOURCES)) {
    expected[name] = {};
    for (const [runtimeName, bin] of RUNTIMES) {
        const bare = runProgram(bin, src, runtimeName);
        assert.ok(bare.ok, `unprotected ${name} must run on ${runtimeName}: ${bare.stderr}`);
        expected[name][runtimeName] = String(bare.stdout);
    }
}

const parity = { builds: 0, runs: 0, constants: 0, cipheredBytes: 0, materialRoots: new Set() };
for (const preset of ["l1", "maximum"]) {
    for (const mode of ["stack", "register"]) {
        for (const [name, src] of Object.entries(SOURCES)) {
            const built = obfuscate(src, { target: "lua", preset, mode, seed: SEED + name.length });
            const meta = built.vmMeta?.stringCipher;
            const key = `${preset}/${mode}/${name}`;
            assert.ok(meta && meta.applied === true, `${key}: the VM route must cipher its string constants (${JSON.stringify(meta)})`);
            assert.equal(meta.algorithm, VEIL_STR_ALGORITHM, `${key}: cipher label`);
            assert.ok(meta.constants > 0, `${key}: at least one ciphered constant`);
            assert.ok(meta.cipheredBytes >= meta.constants, `${key}: ciphered bytes must cover the constants`);
            assert.ok(Number.isInteger(meta.materialRoot) && meta.materialRoot > 0 && meta.materialRoot < 4294967296,
                `${key}: material root ${meta.materialRoot} must be a 32-bit word`);
            assert.equal(built.vmMeta.precheck?.ok, true, `${key}: engine precheck must pass (${(built.vmMeta.precheck?.fatal || []).join(" | ")})`);
            parity.constants += meta.constants;
            parity.cipheredBytes += meta.cipheredBytes;
            parity.materialRoots.add(meta.materialRoot);
            parity.builds++;
            for (const [runtimeName, bin] of RUNTIMES) {
                const out = runProgram(bin, built.output, runtimeName);
                parity.runs++;
                assert.ok(out.ok && String(out.stdout) === expected[name][runtimeName],
                    `${key}/${runtimeName}: ciphered build must print the unprotected output (${out.ok ? JSON.stringify(String(out.stdout)) : JSON.stringify(String(out.stderr).split("\n")[0])} vs ${JSON.stringify(expected[name][runtimeName])})`);
            }
        }
    }
}
assert.ok(parity.materialRoots.size > 1, "distinct seeds/profiles must derive distinct material roots, not a fixed key");

// A different seed must produce a different cipher for the same source.
const sameSource = SOURCES.flat;
const variantA = obfuscate(sameSource, { target: "lua", preset: "l1", mode: "register", seed: SEED });
const variantB = obfuscate(sameSource, { target: "lua", preset: "l1", mode: "register", seed: SEED ^ 0xBEEF });
assert.notEqual(variantA.vmMeta.stringCipher.materialRoot, variantB.vmMeta.stringCipher.materialRoot,
    "the material root must track the build seed");
assert.ok(variantA.output !== variantB.output, "two seeds must not emit the same artifact");

// ---------------------------------------------------------------------------
// 2 + 3. attacks, and the same attacks with the fold check removed.
// ---------------------------------------------------------------------------
const attackBuild = obfuscate(SOURCES.nested, { target: "lua", preset: "l1", mode: "register", seed: SEED + 6 });
const attackText = attackBuild.output;
assert.equal(attackBuild.vmMeta.stringCipher.applied, true, "attack build must be ciphered");

function foldCall(text) {
    const match = /if ([A-Za-z_]\w*)\(BB\)~=HC then/.exec(text);
    assert.ok(match, "the artifact must carry the plaintext fold check");
    return match[1];
}
function dropFold(text) {
    const fold = foldCall(text);
    return text.replace(new RegExp(`if ${fold}\\(BB\\)~=HC then`), `if false and ${fold}(BB)~=HC then`);
}
function printsFlat(out, runtimeName) {
    return Boolean(out.ok && String(out.stdout) === expected.nested[runtimeName]);
}

const attacks = [
    {
        label: "pin the published material root to zero",
        // The reader publishes the folded latch into `G.materialRoot` from a chunk-local;
        // overwriting only that field starves the string keys while the region key (which
        // reads the local directly) still decodes. It is the cheapest edit a skidder can
        // make and the one VeilStr exists to punish.
        patch: (text) => {
            const hit = /\bG\.materialRoot=([A-Za-z_]\w*);/.exec(text);
            assert.ok(hit, "the artifact must publish the computed material root it keys strings on");
            return `${text.slice(0, hit.index)}G.materialRoot=0;${text.slice(hit.index + hit[0].length)}`;
        }
    },
    {
        label: "freeze the chunk traversal counter",
        // Every constant in chunk 1 still decrypts; the nested closure's constants do not.
        patch: (text) => {
            assert.ok(text.includes("chunkSeq=chunkSeq+1;"), "the reader must number chunks as it walks them");
            return text.replace("chunkSeq=chunkSeq+1;", "chunkSeq=chunkSeq+0;");
        }
    }
];

const attackCensus = { attempts: 0, aborted: 0, survivors: [], garbled: 0 };
for (const attack of attacks) {
    for (const [runtimeName, bin] of RUNTIMES) {
        const mutated = attack.patch(attackText);
        assert.ok(mutated !== attackText, `${attack.label}: the patch must change the artifact`);
        attackCensus.attempts++;
        const guarded = runProgram(bin, mutated, runtimeName);
        if (printsFlat(guarded, runtimeName)) {
            attackCensus.survivors.push(`${attack.label}/${runtimeName}`);
        } else {
            attackCensus.aborted++;
        }
        // Same mutation, fold check deleted: the payload now runs to completion but cannot
        // print the right strings, which is what pins the abort on VeilStr.
        const naked = runProgram(bin, dropFold(mutated), runtimeName);
        if (!printsFlat(naked, runtimeName)) attackCensus.garbled++;
        else attackCensus.survivors.push(`${attack.label}/${runtimeName}/no-fold-still-correct`);
    }
}
assert.deepEqual(attackCensus.survivors, [], "every material-root / traversal attack must fail closed");
assert.equal(attackCensus.aborted, attackCensus.attempts, "every attack must abort before the payload prints");
assert.equal(attackCensus.garbled, attackCensus.attempts, "without the fold check the same attacks must print wrong text");

// The control: the identical mutation with the check removed must NOT be an engine crash.
const controlFold = runProgram(lua, dropFold(attackText), "lua");
assert.ok(printsFlat(controlFold, "lua"), `deleting the fold check alone must not break a clean build: ${controlFold.stderr}`);

// ---------------------------------------------------------------------------
// 4. the opt-out really opts out, and the payload still runs without the cipher.
// ---------------------------------------------------------------------------
for (const [runtimeName, bin] of RUNTIMES) {
    const plain = obfuscate(SOURCES.nested, { target: "lua", preset: "l1", mode: "register", seed: SEED + 6, stringCipher: false });
    assert.equal(plain.vmMeta.stringCipher?.applied, false, "stringCipher:false must be reported as not applied");
    assert.equal(plain.vmMeta.stringCipher?.constants, 0, "nothing is ciphered on the opt-out route");
    assert.ok(!/T==85/.test(plain.output), "the opt-out artifact must not carry a tag-85 reader branch");
    assert.ok(!/G\.materialRoot=/.test(plain.output), "the opt-out artifact must not publish a string key root");
    const out = runProgram(bin, plain.output, runtimeName);
    assert.ok(printsFlat(out, runtimeName), `cipher-off build must still run on ${runtimeName}: ${out.stderr || JSON.stringify(String(out.stdout))}`);
}

console.log("ByteVeil v5.9 VeilStr-v1 payload cipher suite: PASS");
console.log(`  js: ${jsCensus.texts} round-trips over ${jsCensus.bytes} plaintext bytes (fold stable, key lane-ordered)`);
console.log(`  parity: ${parity.builds} ciphered builds / ${parity.runs} native runs printed the unprotected output,`
    + ` ${parity.constants} ciphered constants / ${parity.cipheredBytes} ciphered bytes, ${parity.materialRoots.size} distinct material roots`);
console.log(`  attacks: ${attackCensus.aborted}/${attackCensus.attempts} aborted with the check live,`
    + ` ${attackCensus.garbled}/${attackCensus.attempts} printed wrong text once the fold check was deleted`);

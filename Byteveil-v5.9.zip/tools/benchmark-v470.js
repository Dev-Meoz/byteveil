"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");
const { obfuscate } = require("../src");
const { resolveRuntime } = require("./native-runtime");

const ROOT = path.resolve(__dirname, "..");
const args = Object.fromEntries(process.argv.slice(2).map((arg) => {
  const clean = arg.replace(/^--/, "");
  const at = clean.indexOf("=");
  return at < 0 ? [clean, "true"] : [clean.slice(0, at), clean.slice(at + 1)];
}));

const preset = String(args.preset || "l2").toLowerCase();
const mode = args.mode === "register" ? "register" : "stack";
const target = args.target === "luau" ? "luau" : "lua";
const sourceFile = path.resolve(ROOT, args.source || "examples/input.lua");
const source = fs.readFileSync(sourceFile, "utf8");
const seed = args.seed == null ? 0x463B0001 : Number(args.seed) >>> 0;
const strength = args.strength == null ? undefined : Number(args.strength);

const cpuBefore = process.cpuUsage();
const nodeStart = process.hrtime.bigint();
const result = obfuscate(source, {
  target, mode, preset, seed,
  ...(Number.isFinite(strength) ? { strength } : {}),
  wrapper: { enabled: args.wrapper === "true" },
  transforms: { watermark: args.watermark === "true" }
});
const generationWallMs = Number(process.hrtime.bigint() - nodeStart) / 1e6;
const generationCpu = process.cpuUsage(cpuBefore);
const runtime = resolveRuntime(target);
const report = {
  version: "4.7.0",
  preset,
  mode,
  target,
  sourceFile: path.relative(ROOT, sourceFile),
  sourceBytes: Buffer.byteLength(source, "utf8"),
  outputBytes: Buffer.byteLength(result.output, "utf8"),
  outputKB: Number((Buffer.byteLength(result.output, "utf8") / 1000).toFixed(2)),
  outputKiB: Number((Buffer.byteLength(result.output, "utf8") / 1024).toFixed(2)),
  sizeBudget: result.sizeBudget,
  nestedLayers: Number(result.vmMeta?.nestedObfuscationLayers || 0),
  nestedCodecs: result.vmMeta?.nestedCodecs || [],
  nestedCompression: result.vmMeta?.nestedCompression ? {
    enabled: result.vmMeta.nestedCompression.enabled === true,
    attemptedLayers: Number(result.vmMeta.nestedCompression.attemptedLayers || 0),
    compressedLayers: Number(result.vmMeta.nestedCompression.compressedLayers || 0),
    bytesSaved: Number(result.vmMeta.nestedCompression.bytesSaved || 0),
    adaptiveMatchLayers: Number(result.vmMeta.nestedCompression.adaptiveMatchLayers || 0),
    longOffsetReferences: Number(result.vmMeta.nestedCompression.longOffsetReferences || 0)
  } : null,
  vmArchitectureFamily: result.vmMeta?.vmArchitectureFamily ?? null,
  representationMorphingActive: result.vmMeta?.actualRepresentationMorphing === true,
  generationWallMs: Number(generationWallMs.toFixed(2)),
  generationCpuMs: Number(((generationCpu.user + generationCpu.system) / 1000).toFixed(2)),
  nodePeakRssBytes: process.platform === "win32"
    ? process.resourceUsage().maxRSS
    : process.resourceUsage().maxRSS * 1024,
  runtimeExecutable: runtime,
  runtimeWallMs: null,
  runtimeCpuMs: null,
  runtimePeakRssBytes: null,
  runtimeStatus: runtime ? "not-run" : "not-installed"
};

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "byteveil-v470-bench-"));
const tempFile = path.join(tempDir, target === "luau" ? "protected.luau" : "protected.lua");
try {
  fs.writeFileSync(tempFile, result.output, "utf8");
  if (runtime) {
    const timeBin = process.platform === "win32" ? null : "/usr/bin/time";
    if (timeBin && fs.existsSync(timeBin)) {
      const marker = "__BYTEVEIL_V470_METRICS__";
      const timed = spawnSync(timeBin, ["-f", `${marker}\t%e\t%U\t%S\t%M`, runtime, tempFile], {
        encoding: "utf8", windowsHide: true, timeout: 60000, maxBuffer: 8 * 1024 * 1024
      });
      const metricsLine = String(timed.stderr || "").split(/\r?\n/).find((line) => line.startsWith(marker + "\t"));
      const stderr = String(timed.stderr || "").split(/\r?\n/).filter((line) => !line.startsWith(marker + "\t")).join("\n").trim();
      if (metricsLine) {
        const [, elapsed, user, system, rssKb] = metricsLine.split("\t");
        report.runtimeWallMs = Number((Number(elapsed) * 1000).toFixed(2));
        report.runtimeCpuMs = Number(((Number(user) + Number(system)) * 1000).toFixed(2));
        report.runtimePeakRssBytes = Math.round(Number(rssKb) * 1024);
      }
      report.runtimeStatus = !timed.error && timed.status === 0 ? "pass" : "fail";
      report.runtimeExitCode = timed.status;
      report.runtimeStdout = String(timed.stdout || "").trimEnd();
      if (stderr) report.runtimeStderr = stderr;
      if (timed.error) report.runtimeError = timed.error.message;
    } else {
      const started = process.hrtime.bigint();
      const timed = spawnSync(runtime, [tempFile], { encoding: "utf8", windowsHide: true, timeout: 60000, maxBuffer: 8 * 1024 * 1024 });
      report.runtimeWallMs = Number((Number(process.hrtime.bigint() - started) / 1e6).toFixed(2));
      report.runtimeStatus = !timed.error && timed.status === 0 ? "pass" : "fail";
      report.runtimeExitCode = timed.status;
      report.runtimeStdout = String(timed.stdout || "").trimEnd();
      report.runtimePeakRssBytes = null;
      report.runtimeCpuMs = null;
      if (timed.stderr) report.runtimeStderr = timed.stderr.trim();
      if (timed.error) report.runtimeError = timed.error.message;
    }
  }
} finally {
  fs.rmSync(tempDir, { recursive: true, force: true });
}

console.log(JSON.stringify(report, null, 2));
if (report.sizeBudget.overMaximum) {
  console.warn(`SIZE WARNING: ${report.sizeBudget.recommendation}`);
  console.warn(`Inspect: ${(report.sizeBudget.likelyContributors || []).join(", ") || "not isolated"}`);
}
if (runtime && report.runtimeStatus !== "pass") process.exitCode = 1;
if (!runtime) process.exitCode = 2;

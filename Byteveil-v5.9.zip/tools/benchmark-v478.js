"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");
const { obfuscate } = require("../src");
const { resolveRuntime, getRuntimeVersion, runProgram, runSyntaxCheck } = require("./native-runtime");

const ROOT = path.resolve(__dirname, "..");
const args = Object.fromEntries(process.argv.slice(2).map((arg) => {
  const clean = arg.replace(/^--/, "");
  const at = clean.indexOf("=");
  return at < 0 ? [clean, "true"] : [clean.slice(0, at), clean.slice(at + 1)];
}));
const runs = Math.max(1, Math.min(9, Number.parseInt(args.runs || "3", 10) || 3));
const target = String(args.target || "lua").toLowerCase() === "luau" ? "luau" : "lua";
const runtime = resolveRuntime(target);
const runtimeVersion = runtime ? getRuntimeVersion(runtime, target) : null;
if (runtime && target === "lua" && runtimeVersion !== "Lua 5.4") {
  console.error(`ByteVeil v4.7.8 benchmark requires a real Lua 5.4 runtime; ${runtime} reported ${JSON.stringify(runtimeVersion)}. Set BYTECODE_LUA_PATH to the Lua 5.4 executable.`);
  process.exit(2);
}
const maxOutputBytes = Math.max(1, Number.parseInt(args.maxOutputBytes || "475000", 10) || 475000);
const seedBase = Number(args.seed || 0x478B0001) >>> 0;
const source = 'function add(x,y) return x+y end; function mul(x,y) return x*y end; print("HYBRID",add(7,8),mul(3,4))';
const sourceBytes = Buffer.byteLength(source, "utf8");
const common = {
  target,
  wrapper: { enabled: false },
  transforms: { rename: true, numbers: true, strings: true, controlFlow: true, watermark: false },
  maxOutputBytes
};
const presetProfiles = [
  { preset: "l1", strength: 1800 },
  { preset: "l2", strength: 3500 },
  { preset: "df", strength: 8000 },
  { preset: "lz", strength: 10000 }
];
const policyProfiles = [
  { name: "balanced-vm-a", options: { vmPolicy: "balanced" } },
  { name: "hardened-vm-b", options: { vmPolicy: "hardened" } },
  { name: "hybrid-a-main-b-function", options: { vmPolicy: "balanced", functionPolicies: { mul: "hardened" } } },
  { name: "hybrid-b-main-a-function", options: { vmPolicy: "hardened", functionPolicies: { add: "balanced" } } },
  { name: "compiler-transformed", options: { vmPolicy: "compiler-transformed" } }
];
const profiles = presetProfiles.flatMap((presetProfile, presetIndex) => policyProfiles.map((policyProfile, policyIndex) => ({
  ...policyProfile,
  preset: presetProfile.preset,
  strength: presetProfile.strength,
  name: `${presetProfile.preset}:${policyProfile.name}`,
  index: presetIndex * policyProfiles.length + policyIndex,
  expected: "HYBRID\t15\t12"
})));

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}
function fixed(value) { return Number(Number(value).toFixed(2)); }
function runRuntime(output, expected, profileName) {
  if (!runtime) return { status: "not-installed", executable: null, stdout: null, wallMs: null, cpuMs: null, peakRssBytes: null };
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "byteveil-v478-bench-"));
  const file = path.join(tempDir, target === "luau" ? "protected.luau" : "protected.lua");
  try {
    fs.writeFileSync(file, output, "utf8");
    const timeBin = process.platform === "win32" ? null : "/usr/bin/time";
    if (timeBin && fs.existsSync(timeBin)) {
      const marker = "__BV478_METRICS__";
      const timed = spawnSync(timeBin, ["-f", `${marker}\t%e\t%U\t%S\t%M`, runtime, file], {
        encoding: "utf8", windowsHide: true, timeout: 60000, maxBuffer: 8 * 1024 * 1024
      });
      const line = String(timed.stderr || "").split(/\r?\n/).find((entry) => entry.startsWith(marker + "\t"));
      let wallMs = null, cpuMs = null, peakRssBytes = null;
      if (line) {
        const [, elapsed, user, system, rssKb] = line.split("\t");
        wallMs = fixed(Number(elapsed) * 1000);
        cpuMs = fixed((Number(user) + Number(system)) * 1000);
        peakRssBytes = Math.round(Number(rssKb) * 1024);
      }
      const stdout = String(timed.stdout || "").replace(/\r\n/g, "\n").trimEnd();
      const stderr = String(timed.stderr || "").split(/\r?\n/).filter((entry) => !entry.startsWith(marker + "\t")).join("\n").trim();
      const ok = !timed.error && timed.status === 0 && stdout === expected;
      return { status: ok ? "pass" : "fail", executable: runtime, exitCode: timed.status, stdout, expected, wallMs, cpuMs, peakRssBytes, ...(stderr ? { stderr } : {}), ...(timed.error ? { error: timed.error.message } : {}) };
    }
    const started = process.hrtime.bigint();
    const timed = spawnSync(runtime, [file], { encoding: "utf8", windowsHide: true, timeout: 60000, maxBuffer: 8 * 1024 * 1024 });
    const wallMs = fixed(Number(process.hrtime.bigint() - started) / 1e6);
    const stdout = String(timed.stdout || "").replace(/\r\n/g, "\n").trimEnd();
    const ok = !timed.error && timed.status === 0 && stdout === expected;
    return { status: ok ? "pass" : "fail", executable: runtime, exitCode: timed.status, stdout, expected, wallMs, cpuMs: null, peakRssBytes: null, ...(timed.stderr ? { stderr: timed.stderr.trim() } : {}), ...(timed.error ? { error: timed.error.message } : {}) };
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

const results = [];
for (const profile of profiles) {
  const index = profile.index;
  const generationWall = [], generationCpu = [], sizes = [], builds = [];
  for (let runIndex = 0; runIndex < runs; runIndex++) {
    const seed = (seedBase + index * 0x101 + runIndex * 0x11) >>> 0;
    const cpuBefore = process.cpuUsage();
    const start = process.hrtime.bigint();
    let built;
    try {
      built = obfuscate(source, { ...common, preset: profile.preset, strength: profile.strength, ...profile.options, seed, transforms: { ...common.transforms } });
    } catch (error) {
      console.error(`BENCHMARK FAILED during generation: ${profile.name}: ${error.stack || error}`);
      process.exit(1);
    }
    generationWall.push(Number(process.hrtime.bigint() - start) / 1e6);
    const cpu = process.cpuUsage(cpuBefore);
    generationCpu.push((cpu.user + cpu.system) / 1000);
    sizes.push(Buffer.byteLength(built.output, "utf8"));
    builds.push(built);
  }
  const result = builds[builds.length - 1];
  const syntax = runtime ? runSyntaxCheck(runtime, result.output, target) : { ok: false, error: "target runtime is not installed" };
  const run = runRuntime(result.output, profile.expected, profile.name);
  const meta = result.vmMeta || {};
  const row = {
    name: profile.name,
    preset: profile.preset,
    strength: profile.strength,
    requestedPolicy: profile.options.vmPolicy,
    functionPolicies: profile.options.functionPolicies || {},
    backend: meta.backend || null,
    selectedBackend: meta.selectedBackend || null,
    rootBackend: meta.rootBackend || null,
    instructionRepresentation: meta.instructionRepresentation || null,
    outputBytesMedian: Math.round(median(sizes)),
    outputBytesLastRun: sizes[sizes.length - 1],
    outputWithinBudget: sizes.every((size) => size <= maxOutputBytes),
    generationWallMsMedian: fixed(median(generationWall)),
    generationCpuMsMedian: fixed(median(generationCpu)),
    nodePeakRssBytes: process.platform === "win32" ? process.resourceUsage().maxRSS : process.resourceUsage().maxRSS * 1024,
    syntaxStatus: runtime ? (syntax.ok ? "pass" : "fail") : "not-run",
    runtime: run,
    sourceLoaderStages: Number(meta.sourceLoaderStages || 0),
    runtimeSourceLoaderCount: Number(meta.runtimeSourceLoaderCount || 0),
    sourceLoaderCallSites: /(?<![\w])(?:loadstring|load)\s*\(/.test(result.output),
    functionPolicyReport: meta.functionPolicyReport || [],
    explicitFallbacks: meta.explicitFallbacks || []
  };
  results.push(row);
  if (row.outputWithinBudget !== true || row.syntaxStatus === "fail" || row.runtime.status === "fail") {
    console.error(`BENCHMARK FAILED for ${profile.name}: output=${row.outputBytesLastRun} bytes; syntax=${row.syntaxStatus}; runtime=${row.runtime.status}`);
    process.exitCode = 1;
  }
}

const report = {
  title: "ByteVeil v4.7.8 Hybrid VM / Function Policy benchmark",
  version: "4.7.8",
  generatedAt: new Date().toISOString(),
  sourceFixture: "inline function-policy fixture",
  sourceBytes,
  target,
  runtimeExecutable: runtime,
  runtimeVersion,
  runtimeStatus: runtime ? "available" : "not-installed",
  nativeRobloxLuauValidation: target === "luau" && runtime ? "output-run-through-resolved-luau-binary; not Roblox Studio" : "not-run",
  runsPerProfile: runs,
  seedBase,
  maxOutputBytes,
  methodNotes: [
    "Generation metrics are medians over independent seed values in one Node process; they are not process-isolated compile benchmarks.",
    "The same source fixture is used across 4 presets (l1/l2/df/lz) and 5 VM/policy profiles per preset (20 profile/preset combinations total). Each output is syntax-checked and runtime-checked when the selected runtime is installed; runtimeVersion records the executable-reported _VERSION.",
    "Runtime measurements are a single measured run for the final build per profile; use them as a smoke benchmark, not a statistically robust performance ranking.",
    "Compiler-transformed mode intentionally emits transformed source and does not claim VM virtualization.",
    "Function-level routing is limited to supported named top-level global functions; unsupported cross-backend captures fail closed unless explicit fallback is enabled.",
    "No benchmark proves resistance parity with any commercial obfuscator. Native Roblox Luau validation must be run separately in the target environment."
  ],
  summary: {
    profileCount: results.length,
    allWithinBudget: results.every((entry) => entry.outputWithinBudget),
    allSyntaxPass: runtime ? results.every((entry) => entry.syntaxStatus === "pass") : false,
    allRuntimePass: runtime ? results.every((entry) => entry.runtime.status === "pass") : false,
    zeroSourceLoaderMetadata: results.every((entry) => entry.sourceLoaderStages === 0 && entry.runtimeSourceLoaderCount === 0),
    anySourceLoaderCallSites: results.some((entry) => entry.sourceLoaderCallSites)
  },
  profiles: results
};
console.log(JSON.stringify(report, null, 2));
if (!runtime) process.exitCode = 2;

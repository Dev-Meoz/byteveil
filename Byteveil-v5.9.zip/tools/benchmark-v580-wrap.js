"use strict";

const assert = require("assert");
const { obfuscate } = require("../src");
const { wrap } = require("../src/wrappers/WrapInFunction");
const { createBootstrapPlan } = require("../src/wrappers/bootstrap_renderer");
const { compile: compileRegister } = require("../src/compiler/register/register_compiler");
const { Lexer } = require("../src/frontend/lexer");
const { Parser } = require("../src/frontend/parser");
const { resolveRuntime, getRuntimeVersion, runProgram } = require("./native-runtime");
const { findBlobLiterals, stripBlobLiterals, BLOB_MARKER } = require("../src/obfuscation/veil_blob");
const { UNIFIED_ALPHABET } = require("../src/obfuscation/blob_alphabet");

const lua = resolveRuntime("lua");
const luau = resolveRuntime("luau");
assert.ok(lua, "Lua 5.4 runtime is required for benchmark-v580-wrap");
assert.ok(luau, "Luau runtime is required for benchmark-v580-wrap");

const sampleProgram = [
  'bv_exec_count = (bv_exec_count or 0) + 1',
  'local a, b, c, d, e = ...',
  'local n = select("#", ...)',
  'local secretTag = "BV_SECRET_CONST_ALPHA"',
  'local function step(tag, v)',
  '  bv_side_log[#bv_side_log + 1] = tag .. "=" .. tostring(v)',
  '  bv_state_acc = (bv_state_acc or 0) + (type(v) == "number" and v or #secretTag)',
  '  return v',
  'end',
  'local function outer(prefix, ...)',
  '  local m = select("#", ...)',
  '  local function inner(...)',
  '    local k = select("#", ...)',
  '    step(prefix, m * 10 + k)',
  '    return nil, prefix, k, ...',
  '  end',
  '  return inner("x", ...)',
  'end',
  'local r1, r2, r3, r4, r5, r6 = outer("call", a, b, c)',
  'step("done", n)',
  'return r1, r2, r3, r4, r5, r6, d, e, nil'
].join("\n");

const harness = (code, invokeArgs = '"p1", nil, 42, nil, false') => [
  "bv_exec_count = 0",
  "bv_side_log = {}",
  "bv_state_acc = 100",
  "local function packOnce(...) return { n = select('#', ...), ... } end",
  `local fn = function(...) ${code} end`,
  `local r = packOnce(fn(${invokeArgs}))`,
  "assert(bv_exec_count == 1, 'expected 1 execution, got ' .. tostring(bv_exec_count))",
  "local out = { 'exec=' .. tostring(bv_exec_count), 'acc=' .. tostring(bv_state_acc), 'log=' .. table.concat(bv_side_log, ','), 'retN=' .. tostring(r.n) }",
  "for i = 1, r.n do out[#out + 1] = type(r[i]) .. ':' .. tostring(r[i]) end",
  "print(table.concat(out, '|'))"
].join("\n");

const baseLua = runProgram(lua, harness(sampleProgram), "lua");
const baseLuau = runProgram(luau, harness(sampleProgram), "luau");
assert.ok(baseLua.ok && baseLuau.ok, "baseline sample program must run on Lua 5.4 and Luau");
assert.strictEqual(baseLua.stdout.trim(), baseLuau.stdout.trim(), "baseline digest must match between Lua 5.4 and Luau");
const expectedSampleDigest = baseLua.stdout.trim();

/**
 * Subsystem fingerprints for the v5.9 generator.
 *
 * These are signatures of structures that are measurably present in the emitted body, used
 * to show that the VM subsystems are split across the three callable slots rather than
 * dumped into one. They describe output SHAPE only.
 *
 * Four v5.8 signatures retired on the way here because the v5.9 codec no longer emits them
 * at all — the base-85 radix accumulation (`*85+`, now the unified 93-char alphabet), the
 * hex-keyed opcode table (`[0x…]=function(`, now decimal keys with hex values), the
 * instruction-morph fields (`.irep`/`.crep`) and the FNV digest constants. The report keeps
 * them in `retiredV58Signatures` so a reader can see what changed instead of assuming the
 * count dropped to zero because the engine got weaker.
 */
const SUBSYSTEM_SIGNATURES = {
  opcodeDispatchTable: { pattern: /\[\d+\]=0x[0-9a-f]{3,4}/gi, minimum: 24, what: "opcode -> handler mapping table" },
  semanticHandlerBodies: { pattern: /\[\d+\]=function\(/g, minimum: 8, what: "callable semantic handler bodies" },
  carrierStreamCipher: { pattern: /function\(S,A,O,R,K,Z,Q\)/g, minimum: 1, what: "seven-parameter carrier stream decoder" },
  radix24BitUnpack: { pattern: null, minimum: 1, what: "base-N digit accumulation with 24-bit word splitting" },
  modularLaneArithmetic: { pattern: /%256\b|%65536\b/g, minimum: 8, what: "payload lane modular arithmetic" },
  guardedExecutionSurface: { pattern: /setmetatable\(|pcall\(/g, minimum: 2, what: "sandboxed/guarded execution primitives" }
};
const PRIMITIVE_KEYS = Object.keys(SUBSYSTEM_SIGNATURES);
const RETIRED_V58_SIGNATURES = {
  base85RadixAccumulation: "\\*85\\+",
  hexKeyedOpcodeTable: "\\[0x[0-9a-f]{3,4}\\]=function\\(",
  instructionMorphFields: "\\.irep|\\.crep",
  fnvDigestConstants: "16777619|2166136261"
};
const RADIX_ACCUMULATION = new RegExp("\\*" + UNIFIED_ALPHABET.length + "\\+", "g");
const WORD_24_BIT = /16777216/g;

function detectSubsystems(text) {
  const counted = {};
  for (const key of PRIMITIVE_KEYS) counted[key] = key === "radix24BitUnpack"
    ? Math.min((text.match(RADIX_ACCUMULATION) || []).length, (text.match(WORD_24_BIT) || []).length)
    : (text.match(SUBSYSTEM_SIGNATURES[key].pattern) || []).length;
  const flags = {};
  for (const key of PRIMITIVE_KEYS) {
    flags[key] = counted[key] >= SUBSYSTEM_SIGNATURES[key].minimum;
  }
  // Backwards-readable aliases for the two names the topology check consumes.
  flags.hasShadowDispatchTable = flags.opcodeDispatchTable;
  flags.hasCarrierStreamDecoder = flags.carrierStreamCipher;
  return {
    ...flags,
    counts: counted,
    primitiveCount: PRIMITIVE_KEYS.filter((key) => flags[key]).length
  };
}

function retiredSignatureCounts(text) {
  const out = {};
  for (const [name, source] of Object.entries(RETIRED_V58_SIGNATURES)) {
    out[name] = (text.match(new RegExp(source, "gi")) || []).length;
  }
  return out;
}

/**
 * A carrier container is live when the code feeds it to the decoder; the engine
 * always calls `string.sub(<container>, ...)` to drop the marker. A container the
 * code assigns raw is an unused char-code source and must be inert.
 */
function isLiveCarrier(text, blobStart) {
  return text.slice(Math.max(0, blobStart - "string.sub(".length), blobStart) === "string.sub(";
}

/**
 * JunkForge padding is a statement prefix in front of the payload: a block of
 * `[==[byteveil&...]==]` containers with a load-time digest. Its size is a file-size
 * property, not a partitioning property, so the slot shares and entropy below are
 * measured on payload bytes with the block located and excluded. The block is found by
 * shape because every identifier inside it is generated per build.
 */
const FORGE_OPEN = /local \w+=\(function\(\)local \w+=\{\} local \w+=\{function\(\)/;
const FORGE_CLOSE = / then \w+\(\) end return \w+ end\)\(\);/;

function forgePaddingRange(body) {
  const empty = { start: -1, end: -1, bytes: 0, containers: 0 };
  const open = FORGE_OPEN.exec(body);
  if (!open) return empty;
  const tail = FORGE_CLOSE.exec(body.slice(open.index));
  if (!tail) return empty;
  const end = open.index + tail.index + tail[0].length;
  return {
    start: open.index,
    end,
    bytes: end - open.index,
    containers: findBlobLiterals(body.slice(open.index, end)).length
  };
}

function analyzeCallableBootstrap(fullOutput, seed, backend) {
  const bodyOnly = fullOutput.split("\n").slice(1).join("\n");
  const padding = forgePaddingRange(bodyOnly);
  const plan = createBootstrapPlan({ seed, backend, body: "" });
  const matches = [...bodyOnly.matchAll(/(?:\{|,)\[(\d{3,5})\]=function\([A-Za-z_]/g)];
  assert.strictEqual(matches.length, 3, `seed=${seed}: expected 3 callable bootstrap slots`);
  const callIdx = bodyOnly.lastIndexOf("__call=function");
  // v5.9 carriers read their text out of a VeilBlob container, so the legacy
  // `=function()return dec("` shape no longer appears anywhere; a decoy is a
  // container the code assigns raw, without the decoder call around it.
  const carrierRegex = /\[\d+\]=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\(/g;
  const decoyRegex = /\[\d+\]=\[=+\[byteveil&/g;

  const slotMetrics = {};
  const slices = matches.map((m, i) => {
    const slotId = Number(m[1]);
    const start = m.index + 1;
    const end = i + 1 < matches.length ? matches[i + 1].index : callIdx;
    const text = bodyOnly.slice(start, end);
    const bytes = Buffer.byteLength(text, "utf8");
    const carriers = (text.match(carrierRegex) || []).length;
    const decoys = (text.match(decoyRegex) || []).length;
    const role = slotId === plan.slots.entry
      ? "entry"
      : slotId === plan.slots.dispatch
        ? "dispatch"
        : slotId === plan.slots.body
          ? "body"
          : "unknown";
    const sub = detectSubsystems(text);
    const info = {
      slotId,
      role,
      bytes,
      start,
      end,
      carriers,
      decoys,
      text,
      hasCarrierStreamDecoder: sub.hasCarrierStreamDecoder,
      hasShadowDispatchTable: sub.hasShadowDispatchTable,
      signatureCounts: sub.counts,
      primitiveCount: sub.primitiveCount,
      subsystems: sub
    };
    slotMetrics[role] = info;
    return info;
  });

  // `totalBytes` is payload-only: padding bytes are reported separately so a share is
  // always a fraction of the VM body, never a fraction of the padded file.
  const totalBytes = Buffer.byteLength(bodyOnly, "utf8") - padding.bytes;
  const shares = slices.map((s) => s.bytes / totalBytes);
  const maxShare = Math.max(...shares);
  const minShare = Math.min(...shares);
  const shannonEntropy = -shares.reduce((acc, p) => acc + (p > 0 ? p * Math.log2(p) : 0), 0) / Math.log2(3);
  const maxSingleSlotPrimitiveCount = Math.max(...slices.map((s) => s.primitiveCount));
  const minSingleSlotPrimitiveCount = Math.min(...slices.map((s) => s.primitiveCount));
  // A signature counts as detectable when some part of the build emits it; exposure is
  // measured against that set so a preset which legitimately skips a structure cannot be
  // credited with better partitioning.
  const detectablePrimitiveKeys = PRIMITIVE_KEYS.filter((key) => slices.some((s) => s.subsystems[key]));
  return {
    seed,
    backend,
    topology: plan.topology,
    totalBytes,
    padding,
    maxShare,
    minShare,
    shannonEntropy,
    maxSingleSlotPrimitiveCount,
    minSingleSlotPrimitiveCount,
    detectablePrimitiveCount: detectablePrimitiveKeys.length,
    detectablePrimitiveKeys,
    retiredSignatures: retiredSignatureCounts(padding.start >= 0
      ? `${bodyOnly.slice(0, padding.start)}${bodyOnly.slice(padding.end)}`
      : bodyOnly),
    slotMetrics,
    slices,
    hexDispatchKeys: new Set([...bodyOnly.matchAll(/\[(0x[0-9a-f]{4})\]=/gi)].map((m) => m[1].toLowerCase())),
    bootstrapSlotIds: new Set(slices.map((s) => s.slotId))
  };
}

const seeds = [1001, 1002, 1003, 1004, 2001, 2002, 2003, 2004];
const reports = [];
const analyses = [];
let unmodifiedBaselineChecksPassed = 0;
let ablatedChecks = 0;
let liveCarrierFlips = 0;
let decoyInertChecks = 0;
let decoyFlips = 0;
let unclassifiedBlobs = 0;
let isolatedSlotAttackBlocked = 0;
let metatableAndBindingTamperChecksPassed = 0;
let staticScraperChecks = 0;
let staticScraperLeaks = 0;

for (const seed of seeds) {
  const backend = seed % 2 === 0 ? "register" : "stack";
  const t0 = process.hrtime.bigint();
  const built = obfuscate(sampleProgram, {
    preset: "l1",
    mode: backend,
    target: "luau",
    seed
  });
  const buildMs = Number(process.hrtime.bigint() - t0) / 1e6;
  const analysis = analyzeCallableBootstrap(built.output, seed, backend);
  analysis.buildMs = Number(buildMs.toFixed(2));
  analyses.push(analysis);

  // 1. Verify unmodified baseline output executes and matches expected digest BEFORE tamper/ablation tests.
  for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
    const unmodifiedRun = runProgram(rtBin, harness(built.output), rtName);
    assert.ok(unmodifiedRun.ok, `seed=${seed} (${rtName}): unmodified baseline must execute before ablation: ${unmodifiedRun.stderr}`);
    assert.strictEqual(unmodifiedRun.stdout.trim(), expectedSampleDigest, `seed=${seed} (${rtName}): unmodified baseline digest mismatch`);
    unmodifiedBaselineChecksPassed++;
  }

  // 2. Verify topology functional differentiation:
  if (analysis.topology === "entry-first") {
    assert.ok(analysis.slotMetrics.entry.hasShadowDispatchTable, `seed=${seed} (entry-first): entry must host Shadow VM subsystem`);
    assert.ok(analysis.slotMetrics.dispatch.hasCarrierStreamDecoder, `seed=${seed} (entry-first): dispatch must host Region-Graph/Payload Deserializer`);
  } else {
    assert.ok(analysis.slotMetrics.entry.hasCarrierStreamDecoder, `seed=${seed} (trampoline-first): entry must host Region-Graph/Payload Deserializer`);
    assert.ok(analysis.slotMetrics.dispatch.hasShadowDispatchTable, `seed=${seed} (trampoline-first): dispatch must host Shadow VM subsystem`);
  }

  // 3. Independent RE Attack A: Single-slot & 2-of-3 slot isolation attack.
  // Each of the 3 slots hosts exactly 2 of the 6 core VM primitives (33.3%), and executing any single slot standalone must fail closed.
  assert.strictEqual(analysis.detectablePrimitiveCount, PRIMITIVE_KEYS.length,
    `seed=${seed}: every v5.9 subsystem signature must be emitted somewhere in the build (found ${analysis.detectablePrimitiveCount}/${PRIMITIVE_KEYS.length}: ${analysis.detectablePrimitiveKeys.join(",")})`);
  assert.ok(analysis.maxSingleSlotPrimitiveCount < analysis.detectablePrimitiveCount,
    `seed=${seed}: one slot exposed every subsystem (${analysis.maxSingleSlotPrimitiveCount}/${analysis.detectablePrimitiveCount})`);
  assert.ok(analysis.minSingleSlotPrimitiveCount >= 2,
    `seed=${seed}: a slot exposed only ${analysis.minSingleSlotPrimitiveCount} subsystems, so it carries no VM work`);
  for (const slice of analysis.slices) {
    const fnRhs = slice.text.slice(slice.text.indexOf("=") + 1).replace(/,(?:[A-Za-z_][A-Za-z0-9_]*=\{|\[\d+\]=).*$/, "");
    const isolatedProbe = `local f = ${fnRhs}; local r = f({}, "p1", nil, 42); print("UNEXPECTED_SUCCESS", r)`;
    for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
      const isoRun = runProgram(rtBin, isolatedProbe, rtName);
      assert.strictEqual(isoRun.ok, false, `seed=${seed} (${rtName}): isolated ${slice.role} slot must not execute standalone`);
      // A container body may legally contain `,[12]=`, which is what the extraction
      // regex above cuts on. If the slice came out malformed the probe would fail as
      // a syntax error and the "blocked" result would be an artefact of extraction.
      assert.ok(!/syntax error/.test(String(isoRun.stderr || "")), `seed=${seed} (${rtName}): isolated ${slice.role} probe must fail at runtime, not on a malformed extraction: ${isoRun.stderr}`);
      isolatedSlotAttackBlocked++;
    }
  }

  // 4. Independent RE Attack B: Static literal & constant scraper check.
  const bodyOnly = built.output.split("\n").slice(1).join("\n");
  // v5.9 packs diagnostics into VeilBlob ciphertext; the `byteveil&` container
  // marker is branding, so it is removed before the cleartext sweep and the
  // scan then proves nothing readable survives outside the blob. Stripping uses
  // the engine's bracket-level aware scanner (`]` is a valid base84 digit, so a
  // `[^\]]*` regex cannot tell a blob's end from a byte inside its payload).
  const blobLiterals = findBlobLiterals(bodyOnly);
  const clearedBody = stripBlobLiterals(bodyOnly);
  const unescaped = clearedBody.replace(/\\(\d{3})/g, (_, d) => String.fromCharCode(Number(d)));
  const secretLeaked = unescaped.includes("BV_SECRET_CONST_ALPHA");
  const diagnosticLeaked = /ByteVeil|graph version|SUPER dispatch failed|runtime bridge unavailable/i.test(unescaped);
  staticScraperChecks += 2;
  if (secretLeaked) staticScraperLeaks++;
  if (diagnosticLeaked) staticScraperLeaks++;
  assert.ok(!secretLeaked, `seed=${seed}: secret string constant leaked to static scraper`);
  assert.ok(!diagnosticLeaked, `seed=${seed}: diagnostic string leaked to static scraper`);
  assert.ok(!/\\[0-9]{3}/.test(clearedBody), `seed=${seed}: diagnostics still using \\ddd representation`);
  assert.ok(blobLiterals.length >= 1, `seed=${seed}: expected a VeilBlob diagnostic container`);

  // 5. Independent RE Attack D: Metatable lock & root pow2/stdlib binding tamper check.
  // The tampered chunk must run inside the harness: unwrapped, the sample body
  // touches globals the harness defines (`bv_side_log`), so every run errored for
  // reasons unrelated to the tamper and the fail-closed assert passed vacuously.
  const tamperedPow2 = built.output.replace(",32768,65536}", ",32768,65535}");
  const tamperedSeed = built.output.replace(/(\[\d+\]=)(\d+)(,\[\d+\]=function\()/, (_, p1, num, p3) => `${p1}${Number(num) + 1}${p3}`);
  assert.notEqual(tamperedPow2, built.output, `seed=${seed}: pow2 binding tamper must find its target`);
  assert.notEqual(tamperedSeed, built.output, `seed=${seed}: state seed tamper must find its target`);
  for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
    assert.strictEqual(runProgram(rtBin, harness(tamperedPow2), rtName).ok, false, `seed=${seed} (${rtName}): pow2 binding tamper must fail closed`);
    assert.strictEqual(runProgram(rtBin, harness(tamperedSeed), rtName).ok, false, `seed=${seed} (${rtName}): state seed tamper must fail closed`);
    metatableAndBindingTamperChecksPassed += 2;
  }

  // 6. Carrier ablation, now with the decoys separated out. A container wrapped in
  // the decoder call is live and must fail closed when one ciphertext byte flips;
  // a container the code assigns raw is dead weight and must be provably inert —
  // flipping it has to leave the digest untouched. That contrast is execution
  // evidence which the earlier "every blob must break" pass could not supply.
  // Blobs are enumerated over the whole output and mutated by absolute position:
  // scanning a slice's substring can cut a container in half, and `replace()` hits
  // the first identical occurrence, so both would silently ablate the wrong byte.
  const watermarkEnd = built.output.indexOf("\n") + 1;
  const outputBlobs = findBlobLiterals(built.output);
  // Padding containers are the forge block's own census: they sit ahead of every
  // bootstrap slot, so the ablation loop below never mutates one and the unclassified
  // count stays a statement about carrier positions rather than file padding.
  const paddingLo = watermarkEnd + analysis.padding.start;
  const paddingHi = watermarkEnd + analysis.padding.end;
  const paddingBlobs = outputBlobs.filter((b) => b.start >= paddingLo && b.end <= paddingHi);
  assert.strictEqual(paddingBlobs.length, analysis.padding.containers, `seed=${seed}: padding containers must match the located block`);
  // The located block is the whole forge statement, which now also carries the five
  // key-bed containers, so the telemetry comparison is padding + bed against the census.
  const forgeTelemetry = built.vmMeta.junkForge;
  assert.strictEqual(analysis.padding.containers, forgeTelemetry.containers + forgeTelemetry.keyBedContainers,
    `seed=${seed}: located containers must match padding + key-bed telemetry`);
  assert.strictEqual(analysis.padding.bytes, forgeTelemetry.paddingBytes + forgeTelemetry.keyBedBytes,
    `seed=${seed}: located block bytes must match padding + key-bed telemetry`);
  for (const slice of analysis.slices) {
    assert.ok(slice.start + watermarkEnd >= paddingHi, `seed=${seed} (${slice.role}): bootstrap slots must start after the padding block`);
  }
  for (const slice of analysis.slices) {
    const lo = slice.start + watermarkEnd;
    const hi = slice.end + watermarkEnd;
    const inSlice = outputBlobs.filter((b) => b.start >= lo && b.end <= hi);
    assert.ok(inSlice.length >= 2, `seed=${seed} (${slice.role}): must contain >= 2 VeilBlob carriers`);
    for (const blob of inSlice) {
      const live = isLiveCarrier(built.output, blob.start);
      const rawAssigned = /[A-Za-z_][A-Za-z0-9_]*\[\d+\]=$/.test(built.output.slice(Math.max(0, blob.start - 40), blob.start));
      if (!live && !rawAssigned) {
        unclassifiedBlobs++;
        continue;
      }
      const closer = /\]=+\]$/.exec(blob.text)[0];
      const at = blob.text.indexOf(BLOB_MARKER) + BLOB_MARKER.length;
      assert.ok(at <= blob.text.length - closer.length - 1, `seed=${seed} (${slice.role}): container body must not be empty`);
      const pos = blob.start + at;
      const mutated = `${built.output.slice(0, pos)}${built.output[pos] === "!" ? "#" : "!"}${built.output.slice(pos + 1)}`;
      assert.notEqual(mutated, built.output, `seed=${seed} (${slice.role}): mutation must modify output`);
      if (live) liveCarrierFlips += 2; else decoyFlips += 2;
      const luaRun = runProgram(lua, harness(mutated), "lua");
      const luauRun = runProgram(luau, harness(mutated), "luau");
      const ctx = `${JSON.stringify(built.output.slice(Math.max(0, blob.start - 24), blob.start))}..${JSON.stringify(built.output.slice(blob.end, blob.end + 10))}`;
      if (live) {
        assert.strictEqual(luaRun.ok, false, `seed=${seed} (${slice.role}): live carrier ablation must fail closed on Lua 5.4 [${ctx}]`);
        assert.strictEqual(luauRun.ok, false, `seed=${seed} (${slice.role}): live carrier ablation must fail closed on Luau [${ctx}]`);
        ablatedChecks += 2;
      } else {
        assert.ok(luaRun.ok, `seed=${seed} (${slice.role}): unused container flip must stay inert on Lua 5.4 [${ctx}]: ${luaRun.stderr}`);
        assert.ok(luauRun.ok, `seed=${seed} (${slice.role}): unused container flip must stay inert on Luau [${ctx}]: ${luauRun.stderr}`);
        assert.strictEqual(luaRun.stdout.trim(), expectedSampleDigest, `seed=${seed} (${slice.role}): unused container flip changed the Lua digest [${ctx}]`);
        assert.strictEqual(luauRun.stdout.trim(), expectedSampleDigest, `seed=${seed} (${slice.role}): unused container flip changed the Luau digest [${ctx}]`);
        decoyInertChecks += 2;
      }
    }
  }

  reports.push({
    seed,
    backend,
    wrapperTail: built.vmMeta?.wrapper?.shape || "unknown",
    topology: analysis.topology,
    buildMs: analysis.buildMs,
    totalBytes: analysis.totalBytes,
    outputBytes: Buffer.byteLength(built.output, "utf8"),
    paddingBytes: analysis.padding.bytes,
    paddingContainers: analysis.padding.containers,
    entryBytes: analysis.slotMetrics.entry.bytes,
    entrySharePct: Number((analysis.slotMetrics.entry.bytes / analysis.totalBytes * 100).toFixed(1)),
    entryCarriers: analysis.slotMetrics.entry.carriers,
    dispatchBytes: analysis.slotMetrics.dispatch.bytes,
    dispatchSharePct: Number((analysis.slotMetrics.dispatch.bytes / analysis.totalBytes * 100).toFixed(1)),
    dispatchCarriers: analysis.slotMetrics.dispatch.carriers,
    bodyBytes: analysis.slotMetrics.body.bytes,
    bodySharePct: Number((analysis.slotMetrics.body.bytes / analysis.totalBytes * 100).toFixed(1)),
    bodyCarriers: analysis.slotMetrics.body.carriers,
    maxSlotSharePct: Number((analysis.maxShare * 100).toFixed(1)),
    normalizedEntropy: Number(analysis.shannonEntropy.toFixed(4)),
    maxSingleSlotPrimitivesExposed: `${analysis.maxSingleSlotPrimitiveCount}/${analysis.detectablePrimitiveCount}`,
    retiredV58Signatures: analysis.retiredSignatures,
    liveCarriers: analysis.slices.reduce((n, s) => n + s.carriers, 0),
    unusedContainers: analysis.slices.reduce((n, s) => n + s.decoys, 0),
    // Blob count no longer equals carrier count: the trailing metatable decoy and
    // the scattered ones sit outside the decoder calls.
    containersInOutput: findBlobLiterals(built.output).length
  });
}

// Measured structural distribution across seeds. These are STRUCTURAL metrics
// only (how bytes/carriers/subsystem signatures spread across the 3 callable slots);
// per the v5.9 handoff they are NOT, on their own, proof of RE resistance.
// The execution-based evidence lives in reResistanceEvaluation below.
function measureStructural(analysesList) {
  const carrierOutside = [];
  const unusedShare = [];
  const subsystemsOutside = [];
  const maxSingleSlotExposure = [];
  for (const a of analysesList) {
    const bodySlice = a.slices.find((s) => s.role === "body");
    const outsideSlices = a.slices.filter((s) => s.role !== "body");
    const totalCarriers = a.slices.reduce((n, s) => n + s.carriers, 0);
    const outsideCarriers = outsideSlices.reduce((n, s) => n + s.carriers, 0);
    carrierOutside.push(totalCarriers ? (outsideCarriers / totalCarriers) * 100 : 0);
    const totalUnused = a.slices.reduce((n, s) => n + s.decoys, 0);
    unusedShare.push((totalCarriers + totalUnused) ? (totalUnused / (totalCarriers + totalUnused)) * 100 : 0);
    const outsideKeys = PRIMITIVE_KEYS.filter((k) => outsideSlices.some((s) => s.subsystems[k]));
    subsystemsOutside.push((outsideKeys.length / PRIMITIVE_KEYS.length) * 100);
    const maxPrim = Math.max(...a.slices.map((s) => s.subsystems.primitiveCount));
    maxSingleSlotExposure.push((maxPrim / PRIMITIVE_KEYS.length) * 100);
  }
  const mean = (arr) => Number((arr.reduce((x, y) => x + y, 0) / arr.length).toFixed(2));
  return {
    liveCarriersOutsideBodyPct: mean(carrierOutside),
    liveCarriersOutsideBodyRangePct: [Number(Math.min(...carrierOutside).toFixed(1)), Number(Math.max(...carrierOutside).toFixed(1))],
    unusedContainerShareOfCarrierBedPct: mean(unusedShare),
    unusedContainerShareOfCarrierBedRangePct: [Number(Math.min(...unusedShare).toFixed(1)), Number(Math.max(...unusedShare).toFixed(1))],
    vmSubsystemsOutsideBodyPct: mean(subsystemsOutside),
    maxSingleSlotSubsystemExposurePct: mean(maxSingleSlotExposure)
  };
}
const measuredStructural = measureStructural(analyses);

// Independent RE Attack C: Cross-seed signature & dispatch correlation analysis.
function jaccard(setA, setB) {
  let inter = 0;
  for (const v of setA) if (setB.has(v)) inter++;
  const union = setA.size + setB.size - inter;
  return union === 0 ? 0 : inter / union;
}
let hexJaccardSum = 0;
let slotJaccardSum = 0;
let pairCount = 0;
for (let i = 0; i < analyses.length; i++) {
  for (let j = i + 1; j < analyses.length; j++) {
    hexJaccardSum += jaccard(analyses[i].hexDispatchKeys, analyses[j].hexDispatchKeys);
    slotJaccardSum += jaccard(analyses[i].bootstrapSlotIds, analyses[j].bootstrapSlotIds);
    pairCount++;
  }
}
const meanHexDispatchJaccard = Number((hexJaccardSum / pairCount).toFixed(5));
const meanBootstrapSlotJaccard = Number((slotJaccardSum / pairCount).toFixed(5));
assert.ok(meanHexDispatchJaccard < 0.02, `cross-seed hex dispatch key overlap too high: ${meanHexDispatchJaccard}`);

// Register file permutation diversity across seeds:
const regMaps = seeds.map((s) => compileRegister(new Parser(new Lexer(sampleProgram).lex().tokens).parse(), s).registerPermutation.map);
let regExactMatches = 0;
for (let i = 0; i < regMaps.length; i++) {
  for (let j = i + 1; j < regMaps.length; j++) {
    if (JSON.stringify(regMaps[i]) === JSON.stringify(regMaps[j])) regExactMatches++;
  }
}
assert.strictEqual(regExactMatches, 0, "register file permutation maps must be distinct across all seeds");

// Multi-archetype single-invocation differential semantics check across Lua 5.4 and Luau.
const differentialCorpus = [
  { name: "vararg-nil-holes-and-closures", source: sampleProgram, args: '"p1", nil, 42, nil, false' },
  {
    name: "multireturn-arg-exprs-and-forin",
    source: 'bv_exec_count = (bv_exec_count or 0) + 1; local function multi(u, v) bv_side_log[#bv_side_log + 1] = "m:" .. tostring(u) .. ":" .. tostring(v); return nil, u * 2, v * 3, u + v, nil end; local x, y = ...; local z, a, b, c, w = multi((x or 3) + 1, (y or 4) + 2); local t = { a, b, c }; for k, val in next, t, nil do bv_state_acc = (bv_state_acc or 0) + k * val end; return z, a, b, c, w',
    args: "4, 5"
  },
  {
    name: "recursion-oop-metatables",
    source: 'bv_exec_count = (bv_exec_count or 0) + 1; local function fib(n) if n <= 1 then return n end; return fib(n - 1) + fib(n - 2) end; local proto = { scale = 3 }; function proto:calc(u, v) bv_side_log[#bv_side_log + 1] = "c:" .. tostring(u) .. ":" .. tostring(v); return (u + v) * self.scale, u * v end; local obj = setmetatable({ bias = 4 }, { __index = proto, __call = function(t, x) return t:calc(x, t.bias) end }); local p, q = obj(fib(6)); bv_state_acc = (bv_state_acc or 0) + p + q; return p, nil, q',
    args: ""
  },
  {
    name: "forin-repeat-until-pcall-error-recovery",
    source: 'bv_exec_count = (bv_exec_count or 0) + 1; local acc = 0; for i = 1, 4 do local w = i * 7; repeat w = w - 3 until w <= 15; acc = acc + w; bv_side_log[#bv_side_log + 1] = "b:" .. tostring(acc) end; local ok1, v1 = pcall(function(a) return a + acc end, 10); local ok2, e2 = pcall(function() error("FAULT_TAG", 0) end); bv_state_acc = (bv_state_acc or 0) + (ok1 and v1 or 0); return ok1, v1, ok2, string.find(tostring(e2), "FAULT_TAG") ~= nil',
    args: ""
  }
];

let differentialChecks = 0;
for (let idx = 0; idx < differentialCorpus.length; idx++) {
  const item = differentialCorpus[idx];
  const baseL = runProgram(lua, harness(item.source, item.args), "lua");
  const baseU = runProgram(luau, harness(item.source, item.args), "luau");
  assert.ok(baseL.ok && baseU.ok, `baseline ${item.name} must run on Lua 5.4 and Luau`);
  assert.strictEqual(baseL.stdout.trim(), baseU.stdout.trim(), `baseline ${item.name} digest mismatch between Lua 5.4 and Luau`);
  const expected = baseL.stdout.trim();

  const wrappedBuilds = [1001, 1002].map((s) => wrap(item.source, { seed: s, wrapper: true, invoke: true, setmeta: true, returnMode: "setmetatable" }));
  const obfBuilds = ["stack", "register"].map((mode) => obfuscate(item.source, { preset: "l1", mode, target: "luau", seed: 3000 + idx * 10 + (mode === "register" ? 2 : 1) }).output);

  for (const [rtName, rtBin] of [["lua", lua], ["luau", luau]]) {
    for (const wCode of wrappedBuilds) {
      const rW = runProgram(rtBin, harness(wCode, item.args), rtName);
      assert.ok(rW.ok && rW.stdout.trim() === expected, `${rtName} wrap() mismatch on ${item.name}`);
      differentialChecks++;
    }
    for (const oCode of obfBuilds) {
      const rO = runProgram(rtBin, harness(oCode, item.args), rtName);
      assert.ok(rO.ok && rO.stdout.trim() === expected, `${rtName} obfuscate() mismatch on ${item.name}`);
      differentialChecks++;
    }
  }
}

const avg = (arr, fn) => Number((arr.reduce((a, x) => a + fn(x), 0) / arr.length).toFixed(2));
const summary = {
  runtimes: {
    lua: getRuntimeVersion(lua, "lua"),
    luau: getRuntimeVersion(luau, "luau")
  },
  metricClassification: {
    structural: "Slot byte-share, Shannon entropy, and carrier/subsystem distribution describe output SHAPE only. Per the v5.9 handoff these are NOT, on their own, evidence of reverse-engineering resistance.",
    executionEvidence: "Baseline-before-tamper execution, live-carrier ablation fail-closed, unused-container inertness (flip must not change the digest), isolated single-slot attack, metatable/root-binding tamper, static scraper leakage, and single-execution differential semantics — each measured by running the harness-wrapped output on native Lua 5.4 and Luau. Tamper runs that are not harness-wrapped would fail for missing fixture globals and prove nothing."
  },
  signatureRetirement: {
    note: "Four v5.8 structural fingerprints have no counterpart in v5.9 output, so the detectors were retargeted instead of being left to match nothing. Counts below are occurrences per build over payload bytes (padding excluded); a zero is the evidence that the codec changed, not that a subsystem disappeared.",
    currentV59Signatures: Object.fromEntries(PRIMITIVE_KEYS.map((key) => [key,
      `${SUBSYSTEM_SIGNATURES[key].pattern ? SUBSYSTEM_SIGNATURES[key].pattern.source : "*"+UNIFIED_ALPHABET.length+"+ with 16777216"} (>=${SUBSYSTEM_SIGNATURES[key].minimum} per slot) ${SUBSYSTEM_SIGNATURES[key].what}`])),
    retiredV58Signatures: RETIRED_V58_SIGNATURES,
    measuredRetiredCountsPerBuild: reports.map((r) => ({ seed: r.seed, ...r.retiredV58Signatures }))
  },
  revisionComparison: {
    note: "fix1/fix2 are historical structural references; fix3_current is measured live from this run's generated output.",
    fix1_baseline_structural: {
      entrySharePct: 0.2,
      dispatchSharePct: 0.2,
      bodySharePct: 99.6,
      maxSlotSharePct: 99.6,
      normalizedEntropy: 0.0312,
      liveCarriersOutsideBodyPct: 0.0,
      maxSingleSlotSubsystemExposurePct: 100.0
    },
    fix2_carrierOnlySplit_structural: {
      entrySharePct: 2.7,
      dispatchSharePct: 2.9,
      bodySharePct: 94.1,
      maxSlotSharePct: 94.1,
      normalizedEntropy: 0.2415,
      liveCarriersOutsideBodyPct: 66.7,
      maxSingleSlotSubsystemExposurePct: 100.0
    },
    fix3_current_structural: {
      measured: true,
      avgEntrySharePct: avg(reports, (r) => r.entrySharePct),
      avgDispatchSharePct: avg(reports, (r) => r.dispatchSharePct),
      avgBodySharePct: avg(reports, (r) => r.bodySharePct),
      avgMaxSlotSharePct: avg(reports, (r) => r.maxSlotSharePct),
      avgNormalizedEntropy: Number((reports.reduce((a, r) => a + r.normalizedEntropy, 0) / reports.length).toFixed(4)),
      liveCarriersOutsideBodyPct: measuredStructural.liveCarriersOutsideBodyPct,
      liveCarriersOutsideBodyRangePct: measuredStructural.liveCarriersOutsideBodyRangePct,
      unusedContainerShareOfCarrierBedPct: measuredStructural.unusedContainerShareOfCarrierBedPct,
      unusedContainerShareOfCarrierBedRangePct: measuredStructural.unusedContainerShareOfCarrierBedRangePct,
      avgLiveCarriers: avg(reports, (r) => r.liveCarriers),
      avgUnusedContainers: avg(reports, (r) => r.unusedContainers),
      avgContainersInOutput: avg(reports, (r) => r.containersInOutput),
      padding: {
        // JunkForge is size density, not a partitioning metric: reported apart from the
        // slot shares above so padding never flatters the structural numbers.
        avgPayloadBytes: avg(reports, (r) => r.totalBytes),
        avgPaddingBytes: avg(reports, (r) => r.paddingBytes),
        avgOutputBytes: avg(reports, (r) => r.outputBytes),
        avgPaddingContainers: avg(reports, (r) => r.paddingContainers),
        note: "Payload/padding/output bytes and padding container counts are measured from each build's own telemetry and re-located in the emitted text."
      },
      vmSubsystemsOutsideBodyPct: measuredStructural.vmSubsystemsOutsideBodyPct,
      maxSingleSlotSubsystemExposurePct: measuredStructural.maxSingleSlotSubsystemExposurePct
    }
  },
  executionEvidence: {
    unmodifiedBaselineExecutionsPassed: `${unmodifiedBaselineChecksPassed}/16`,
    liveCarrierAblation: {
      containersFlipped: liveCarrierFlips / 2,
      runtimeChecksFailedClosed: ablatedChecks,
      note: "One ciphertext byte flipped per live container, executed under both runtimes; the harness is required so the failure is attributable to the flip."
    },
    unusedContainerAblation: {
      containersFlipped: decoyFlips / 2,
      runtimeChecksStayedInert: decoyInertChecks,
      note: "Same single-byte flip on containers the code assigns raw: every run reproduced the baseline digest, which is execution proof that they carry no payload."
    },
    containersInStagesNotAttributedToEither: unclassifiedBlobs,
    isolatedSingleSlotAttacksBlocked: `${isolatedSlotAttackBlocked}/48`,
    metatableAndRootBindingTamperBlocked: `${metatableAndBindingTamperChecksPassed}/32`,
    staticScraperLeakage: {
      checks: staticScraperChecks,
      leaks: staticScraperLeaks,
      leakagePct: staticScraperChecks ? Number(((staticScraperLeaks / staticScraperChecks) * 100).toFixed(2)) : 0
    },
    singleExecDifferentialChecksPassed: `${differentialChecks}/32`,
    wrapperTails: reports.reduce((counts, r) => {
      counts[r.wrapperTail] = (counts[r.wrapperTail] || 0) + 1;
      return counts;
    }, {}),
    meanCrossSeedHexDispatchJaccard: meanHexDispatchJaccard,
    meanCrossSeedBootstrapSlotJaccard: meanBootstrapSlotJaccard,
    registerPermutationCollisionsAcrossSeeds: regExactMatches
  },
  perBuildReports: reports
};

console.log(JSON.stringify(summary, null, 2));

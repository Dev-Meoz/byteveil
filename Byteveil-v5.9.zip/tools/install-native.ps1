$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$Native = Join-Path $PSScriptRoot 'native\windows-x64'
$Temp = Join-Path $env:TEMP 'bytecode-native-runtime'

New-Item -ItemType Directory -Force -Path $Native | Out-Null
New-Item -ItemType Directory -Force -Path $Temp | Out-Null

function Install-ZipBinary {
    param(
        [string]$Name,
        [string]$Url,
        [string[]]$ExpectedExe,
        [string]$OutputExe,
        [string[]]$ExtraFiles = @()
    )

    $zip = Join-Path $Temp "$Name.zip"
    $extract = Join-Path $Temp $Name

    Write-Host "[native] Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $zip -UseBasicParsing

    if (Test-Path $extract) {
        Remove-Item $extract -Recurse -Force
    }

    Expand-Archive -Path $zip -DestinationPath $extract -Force

    $found = $null

    foreach ($candidate in $ExpectedExe) {
        $found = Get-ChildItem `
            $extract `
            -Recurse `
            -Filter $candidate `
            -File `
            -ErrorAction SilentlyContinue |
            Select-Object -First 1

        if ($found) {
            break
        }
    }

    if (-not $found) {
        throw "Could not find any expected executable ($($ExpectedExe -join ', ')) inside $Name archive."
    }

    Copy-Item `
        $found.FullName `
        (Join-Path $Native $OutputExe) `
        -Force

    Write-Host "[native] Installed $OutputExe"

    # The joedf LuaBuilds Win64 lua.exe is dynamically linked against lua54.dll.
    # Copying only the executable leaves the runtime unloadable at launch
    # (STATUS_DLL_NOT_FOUND), so also copy any sibling files the exe needs.
    foreach ($extra in $ExtraFiles) {
        $extraFound = Get-ChildItem `
            $extract `
            -Recurse `
            -Filter $extra `
            -File `
            -ErrorAction SilentlyContinue |
            Select-Object -First 1

        if (-not $extraFound) {
            throw "Required dependency '$extra' for $OutputExe was not found inside $Name archive."
        }

        Copy-Item `
            $extraFound.FullName `
            (Join-Path $Native $extra) `
            -Force

        Write-Host "[native] Installed $extra"
    }
}

# Official Luau Windows release
Install-ZipBinary `
    -Name 'luau-0.739' `
    -Url 'https://github.com/luau-lang/luau/releases/download/0.739/luau-windows.zip' `
    -ExpectedExe 'luau.exe' `
    -OutputExe 'luau.exe'

# Lua 5.4.8 Windows x64
# Chấp nhận cả lua54.exe và lua.exe trong archive.
# Build này liên kết động với lua54.dll nên phải cài cả DLL, nếu không
# lua54.exe sẽ không nạp được (STATUS_DLL_NOT_FOUND) và mọi test native Lua fail.
Install-ZipBinary `
    -Name 'lua-5.4.8-win64' `
    -Url 'https://joedf.github.io/LuaBuilds/hdata/lua-5.4.8_Win64_bin.zip' `
    -ExpectedExe @('lua54.exe', 'lua.exe') `
    -OutputExe 'lua54.exe' `
    -ExtraFiles @('lua54.dll')

Write-Host ''
Write-Host 'Native runtimes installed:'

Get-ChildItem $Native -Filter '*.exe' | ForEach-Object {
    Write-Host "  $($_.Name)"
}

Write-Host ''
Write-Host 'Run: npm run native:test'
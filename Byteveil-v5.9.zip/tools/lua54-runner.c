#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>

typedef struct lua_State lua_State;
typedef intptr_t lua_KContext;
typedef int (*lua_KFunction)(lua_State*, int, lua_KContext);

extern lua_State *luaL_newstate(void);
extern void luaL_openlibs(lua_State *L);
extern void lua_close(lua_State *L);
extern int luaL_loadfilex(lua_State *L, const char *filename, const char *mode);
extern int lua_pcallk(lua_State *L, int nargs, int nresults, int errfunc, lua_KContext ctx, lua_KFunction k);
extern const char *lua_tolstring(lua_State *L, int idx, size_t *len);

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s file.lua\n", argv[0]);
        return 2;
    }
    lua_State *L = luaL_newstate();
    if (!L) return 3;
    luaL_openlibs(L);
    int st = luaL_loadfilex(L, argv[1], NULL);
    if (st == 0) st = lua_pcallk(L, 0, 0, 0, 0, NULL);
    if (st != 0) {
        size_t len = 0;
        const char *err = lua_tolstring(L, -1, &len);
        fprintf(stderr, "%.*s\n", (int)len, err ? err : "lua error");
        lua_close(L);
        return 1;
    }
    lua_close(L);
    return 0;
}

"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");

const ROOT = path.resolve(__dirname, "..");
const NATIVE = path.join(__dirname, "native");

function isRunnableCandidate(candidate) {
    if (!path.isAbsolute(candidate)) return true;
    if (!fs.existsSync(candidate)) return false;
    if (process.platform === "win32") return true;
    try {
        const head = fs.readFileSync(candidate).subarray(0, 2).toString("ascii");
        if (head === "MZ") return false;
        try { fs.chmodSync(candidate, 0o755); } catch {}
        return true;
    } catch {
        return false;
    }
}

function candidates(kind) {
    const isWin = process.platform === "win32";
    if (kind === "lua") {
        return isWin
            ? [
                path.join(NATIVE, "windows-x64", "lua54.exe"),
                path.join(NATIVE, "windows-x64", "lua.exe"),
                "lua54.exe",
                "lua.exe",
                "lua54",
                "lua"
            ]
            : [path.join(ROOT, "tools", "lua54-runner"), "lua5.4", "lua54", "lua", "luatex", "luametatex"];
    }
    return isWin
        ? [path.join(NATIVE, "windows-x64", "luau.exe"), "luau.exe", "luau"]
        : [path.join(ROOT, "tools", "luau"), "luau"];
}

const resolvedRuntimeCache = new Map();

/**
 * Explain a non-zero exit that produced no stdout/stderr. On Windows a missing
 * dependent DLL (e.g. lua54.dll next to lua54.exe) makes the loader abort with
 * an NTSTATUS code such as 0xC0000135 (STATUS_DLL_NOT_FOUND = 3221225781)
 * before any Lua code runs, which otherwise surfaces as a confusing empty
 * "syntax failure" in the test suites.
 */
function describeLaunchFailure(result, executable, kind) {
    if (!result || result.error) return null;
    const status = result.status;
    if (status === 0 || status === null || status === undefined) return null;
    const hasOutput = (result.stdout && result.stdout.length) || (result.stderr && result.stderr.length);
    const isNtStatus = typeof status === "number" && status >= 0xC0000000;
    if (hasOutput && !isNtStatus) return null;
    const hex = typeof status === "number" ? `0x${(status >>> 0).toString(16)}` : String(status);
    const hint = status === 0xC0000135
        ? " (STATUS_DLL_NOT_FOUND: a required DLL such as lua54.dll is missing next to the executable; run tools/install-native.ps1)"
        : "";
    return `native ${kind} runtime failed to launch: ${executable} exited with ${hex}${hint}`;
}

function resolveRuntime(kind) {
    const envName = kind === "luau" ? "BYTECODE_LUAU_PATH" : "BYTECODE_LUA_PATH";
    const configured = process.env[envName];
    if (configured) return configured;
    if (resolvedRuntimeCache.has(kind)) return resolvedRuntimeCache.get(kind);

    for (const candidate of candidates(kind)) {
        if (path.isAbsolute(candidate)) {
            if (!isRunnableCandidate(candidate)) continue;
            resolvedRuntimeCache.set(kind, candidate);
            return candidate;
        }

        const probeArgs = candidate === "luatex" || candidate === "luametatex"
            ? ["--version"]
            : ["--version"];
        const probe = spawnSync(candidate, probeArgs, { encoding: "utf8", windowsHide: true });
        if (!probe.error && (probe.status === 0 || probe.status === 1)) {
            resolvedRuntimeCache.set(kind, candidate);
            return candidate;
        }
    }
    resolvedRuntimeCache.set(kind, null);
    return null;
}

function getRuntimeVersion(executable, kind = "lua") {
    if (!executable) return null;
    const result = runProgram(executable, "if io and io.write then io.write(_VERSION) else print(_VERSION) end", kind);
    return result.ok ? result.stdout.trim() : null;
}

function runLuaLike(executable, file, kind) {
    if (kind === "lua" && (path.basename(executable) === "luatex" || path.basename(executable) === "luametatex")) {
        return spawnSync(executable, ["--interaction=batchmode", "--luaonly", file], {
            encoding: "utf8",
            windowsHide: true,
            timeout: 30000,
            maxBuffer: 2 * 1024 * 1024
        });
    }

    return spawnSync(executable, [file], {
        encoding: "utf8",
        windowsHide: true,
        timeout: 30000,
        maxBuffer: 2 * 1024 * 1024
    });
}

function runSyntaxCheck(executable, source, kind) {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "bytecode-native-"));
    const escaped = JSON.stringify(source);
    const loader = kind === "luau"
        ? `local f,e=loadstring(${escaped});if not f then error(e,0) end;return true`
        : `local loader=loadstring or load;local f,e=loader(${escaped});if not f then error(e,0) end;return true`;
    const file = path.join(tempDir, "syntax-check.lua");
    fs.writeFileSync(file, loader, "utf8");

    const result = runLuaLike(executable, file, kind);
    fs.rmSync(tempDir, { recursive: true, force: true });

    return {
        ok: !result.error && result.status === 0,
        executable,
        status: result.status,
        stdout: result.stdout || "",
        stderr: result.stderr || "",
        error: result.error ? result.error.message : describeLaunchFailure(result, executable, kind)
    };
}

function runProgram(executable, source, kind, expectedOutput = null) {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "bytecode-native-run-"));
    const file = path.join(tempDir, kind === "luau" ? "program.luau" : "program.lua");
    fs.writeFileSync(file, String(source), "utf8");

    const result = runLuaLike(executable, file, kind);
    fs.rmSync(tempDir, { recursive: true, force: true });

    const stdout = String(result.stdout || "").replace(/\r\n/g, "\n").trimEnd();
    const expected = expectedOutput == null ? null : String(expectedOutput).replace(/\r\n/g, "\n").trimEnd();
    return {
        ok: !result.error && result.status === 0 && (expected == null || stdout === expected),
        executable,
        status: result.status,
        stdout,
        stderr: result.stderr || "",
        error: result.error ? result.error.message : describeLaunchFailure(result, executable, kind),
        expected
    };
}

module.exports = { resolveRuntime, getRuntimeVersion, runSyntaxCheck, runProgram };

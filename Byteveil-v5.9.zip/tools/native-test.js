"use strict";

const fs = require("fs");
const path = require("path");
const { obfuscate } = require("../src");
const { resolveRuntime, runSyntaxCheck, runProgram } = require("./native-runtime");

const input = fs.readFileSync(
    path.join(__dirname, "..", "examples", "input.lua"),
    "utf8"
);

let failed = false;

for (const kind of ["luau", "lua"]) {
    const executable = resolveRuntime(kind);
    if (!executable) {
        console.log(`[native] ${kind}: NOT INSTALLED`);
        continue;
    }

    for (const mode of ["register", "stack"]) {
        const result = obfuscate(input, {
            mode,
            preset: "default",
            target: kind,
            seed: 0x25A11,
            wrapper: { enabled: true },
            transforms: kind === "luau" ? { sizeBuff: true } : { sizeBuff: false }
        });

        // The Luau route has two legitimate outcomes: the custom VM (what the default
        // preset selects today) or the runtime-safe source container fallback. Anything
        // else is a routing change, so the reason string is only enforced on the route
        // that uses it, and the parse check runs either way.
        if (kind === "luau") {
            const isVm = result.vmMeta?.fallback !== true && result.vmMeta?.backend === "custom-vm";
            const isContainer = result.vmMeta?.fallback === true && result.vmMeta?.reason === "Luau runtime-safe source container";
            if (!isVm && !isContainer) {
                failed = true;
                console.error(`[native] ${kind}/${mode}: unexpected engine path`);
                continue;
            }
        }

        const check = runSyntaxCheck(executable, result.output, kind);
        if (!check.ok) {
            failed = true;
            console.error(`[native] ${kind}/${mode}: FAIL`);
            if (check.stderr) console.error(check.stderr.trim());
            if (check.error) console.error(check.error);
        } else {
            console.log(`[native] ${kind}/${mode}: PASS`);
        }
    }
}

// Native execution smoke. Luau is executed with the real bundled/configured
// Luau executable on Windows; Lua uses the configured native Lua runtime.
for (const kind of ["luau", "lua"]) {
    const executable = resolveRuntime(kind);
    if (!executable) continue;

    const source = kind === "luau"
        ? `--!strict\nlocal function add(a:number,b:number):number return a+b end\nlocal value:number=7\nvalue += 2\nlocal data={value=value}\nprint("native",add(data.value,6))`
        : `local function add(a,b)return a+b end\nlocal value=7\nlocal data={value=value}\nprint("native",add(data.value,6))`;

    const result = obfuscate(source, {
        target: kind,
        preset: "default",
        seed: 0x2633AA55,
        wrapper: { enabled: true },
        transforms: kind === "luau" ? { sizeBuff: true, watermark: false } : { sizeBuff: false, watermark: false }
    });

    const expected = kind === "luau" ? "native\t15" : "native\t13";
    const run = runProgram(executable, result.output, kind, expected);
    if (!run.ok) {
        failed = true;
        console.error(`[native] ${kind}/runtime: FAIL`);
        console.error(`stdout=${run.stdout}`);
        console.error(`stderr=${run.stderr}`);
        if (run.error) console.error(run.error);
    } else {
        console.log(`[native] ${kind}/runtime: PASS -> ${run.stdout}`);
    }
}

if (failed) process.exit(1);
console.log("Native syntax/runtime validation complete.");

# ByteCode native runtimes

v2.6.3 keeps a bundled/configurable Luau runtime hook for native checks.

The Lua engine does not require a version picker. Its generated output uses the common Lua 5.1-5.4 runtime surface and selects `loadstring` when available, otherwise `load`.

For native checks, put a compatible Lua executable on `PATH` or set:

```text
BYTECODE_LUA_PATH=C:\path\to\lua.exe
BYTECODE_LUAU_PATH=C:\path\to\luau.exe
```

The native test will report the installed runtime result.


## Native runtime test

On Windows, `npm run test:luau-runtime` executes generated `.luau` output with the real Luau executable. The test includes Luau type annotations and `+=`.

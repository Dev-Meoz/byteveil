"use strict";
// Package the v5.9.0 handoff archive: deterministic entry list, forward-slash names, deflate,
// and an explicit credential exclusion that is printed and then re-checked against the entries.
// usage: node tools/package-release-v590.js [--dry] <out.zip>
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const ROOT = path.resolve(__dirname, "..");
const args = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const OUT = args[0] || null;
const DRY = process.argv.includes("--dry");

const INCLUDE_DIRS = ["src", "bot", "tools", "examples"];
const EXCLUDE_DIR_NAMES = new Set(["node_modules", ".git", "scratch", "__pycache__", ".vscode", "out", "dist"]);
const FORBIDDEN_EXACT = new Set([".env", ".env.local", ".env.production"]);
const EXCLUDE_SUFFIX = [".log", ".tmp", ".swp"];

function* walk(dir, rel) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
        if (EXCLUDE_DIR_NAMES.has(entry.name)) continue;
        const abs = path.join(dir, entry.name);
        const relPath = rel ? `${rel}/${entry.name}` : entry.name;
        if (entry.isDirectory()) { yield* walk(abs, relPath); continue; }
        if (!entry.isFile()) continue;
        yield { abs, relPath, size: fs.statSync(abs).size };
    }
}

const files = [];
for (const dir of INCLUDE_DIRS) {
    const abs = path.join(ROOT, dir);
    if (fs.existsSync(abs)) for (const f of walk(abs, dir)) files.push(f);
}
for (const entry of fs.readdirSync(ROOT, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
    if (!entry.isFile()) continue;
    const abs = path.join(ROOT, entry.name);
    files.push({ abs, relPath: entry.name, size: fs.statSync(abs).size });
}

const kept = [];
const dropped = [];
for (const f of files) {
    const base = path.basename(f.relPath);
    if (FORBIDDEN_EXACT.has(base)) { dropped.push(`${f.relPath} (credential file)`); continue; }
    if (EXCLUDE_SUFFIX.some((s) => f.relPath.endsWith(s))) { dropped.push(`${f.relPath} (suffix)`); continue; }
    if (/\.(zip|sha256\.txt|bak)$/.test(base)) { dropped.push(`${f.relPath} (archive artifact)`); continue; }
    kept.push(f);
}

const v5 = fs.existsSync(path.join(ROOT, "scratch/v5_entry_list.txt"))
    ? new Set(fs.readFileSync(path.join(ROOT, "scratch/v5_entry_list.txt"), "utf8").split(/\r?\n/).filter(Boolean))
    : null;
const current = new Set(kept.map((f) => f.relPath));
const added = v5 ? [...current].filter((f) => !v5.has(f)).sort() : [];
const removed = v5 ? [...v5].filter((f) => !current.has(f)).sort() : [];

console.log(`entries=${kept.length} rawBytes=${kept.reduce((n, f) => n + f.size, 0)} added_vs_v5=${added.length} removed_vs_v5=${removed.length}`);
for (const f of removed) console.log(`  - ${f}`);
for (const f of added) console.log(`  + ${f}`);
console.log(`credential files excluded: ${dropped.filter((d) => d.endsWith("(credential file)")).map((d) => d.split(" ")[0]).join(", ") || "(none in tree)"}`);
console.log(`env-shaped entries kept: ${kept.filter((f) => /(^|\/)\.env/.test(f.relPath)).map((f) => f.relPath).join(", ") || "(none)"}`);
console.log(`other dropped: ${dropped.filter((d) => !d.endsWith("(credential file)")).join(" | ") || "(none)"}`);
if (kept.some((f) => FORBIDDEN_EXACT.has(path.basename(f.relPath)))) throw new Error("FAIL-CLOSED: a credential file survived the exclusion pass");
// Obsolete engines were removed from the tree on 2026-10-31; relocating them back into the
// archive is how v5 shipped 38 dead files, so the packager refuses them instead of filtering.
if (fs.existsSync(path.join(ROOT, "legacy"))) throw new Error('FAIL-CLOSED: a "legacy" directory exists in the project; obsolete engines must not be shipped');
const legacyShaped = kept.filter((f) => /(^|\/)legacy\//.test(f.relPath));
if (legacyShaped.length) throw new Error(`FAIL-CLOSED: obsolete engine entries survived: ${legacyShaped.map((f) => f.relPath).join(", ")}`);
const liveRequires = kept.filter((f) => /^(src|bot)\//.test(f.relPath) && f.relPath.endsWith(".js"))
    .filter((f) => /require\([^)]*legacy\//.test(fs.readFileSync(f.abs, "utf8")));
if (liveRequires.length) throw new Error(`FAIL-CLOSED: live code still requires obsolete engines: ${liveRequires.map((f) => f.relPath).join(", ")}`);
if (DRY || !OUT) { console.log(DRY ? "dry run, no archive written" : "no output path given"); process.exit(0); }

if (!zlib.crc32) throw new Error("this Node build has no zlib.crc32");
const dosTime = (12 << 11);
const dosDate = ((2026 - 1980) << 9) | (10 << 5) | 31;

const chunks = [];
const central = [];
let offset = 0;
for (const f of kept) {
    const data = fs.readFileSync(f.abs);
    const name = Buffer.from(f.relPath, "utf8");
    const comp = zlib.deflateRawSync(data, { level: 9 });
    const useDeflate = comp.length < data.length;
    const payload = useDeflate ? comp : data;
    const method = useDeflate ? 8 : 0;
    const crc = zlib.crc32(data) >>> 0;
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(dosTime, 10);
    local.writeUInt16LE(dosDate, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(payload.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    chunks.push(local, name, payload);

    const record = Buffer.alloc(46);
    record.writeUInt32LE(0x02014b50, 0);
    record.writeUInt16LE(20, 4);
    record.writeUInt16LE(20, 6);
    record.writeUInt16LE(0x0800, 8);
    record.writeUInt16LE(method, 10);
    record.writeUInt16LE(dosTime, 12);
    record.writeUInt16LE(dosDate, 14);
    record.writeUInt32LE(crc, 16);
    record.writeUInt32LE(payload.length, 20);
    record.writeUInt32LE(data.length, 24);
    record.writeUInt16LE(name.length, 28);
    record.writeUInt32LE(0, 38);
    record.writeUInt32LE(offset, 42);
    central.push(record, name);
    offset += local.length + name.length + payload.length;
}
let centralSize = 0;
for (const c of central) centralSize += c.length;
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0);
end.writeUInt16LE(kept.length, 8);
end.writeUInt16LE(kept.length, 10);
end.writeUInt32LE(centralSize, 12);
end.writeUInt32LE(offset, 16);
const archive = Buffer.concat([...chunks, ...central, end]);
fs.writeFileSync(OUT, archive);
console.log(`wrote ${path.resolve(OUT)} (${archive.length} bytes, ${kept.length} entries)`);

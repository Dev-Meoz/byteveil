"use strict";

const os = require("os");
const { spawn } = require("child_process");
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
const SUITES = [
  "test-v580.js",
  "test-v590-blob.js",
  "test-v590-frontend.js",
  "test-v590-veilstr.js",
  "test-v590-bitops.js",
  "test-v590-precheck.js",
  "test-v590-tree.js",
  "test-v590-numeric.js",
  "test-v590-multiret.js",
  "test-v590-junk.js",
  "test-v590-forge.js",
  "test-v590-envguard.js",
  "test-v590-antibundle.js",
  "test-v510.js",
  "test-v479-payload.js",
  "test-v479-lps.js",
  "test-v479-register-isa.js",
  "test-v479-audit-fixes.js",
  "test-v479-bot.js",
  "test-v479-macros-lph.js",
  "test-v433.js",
  "test-v479-tail-return.js",
  "test-v479-policy.js",
];
// Measured on this 8-core box: test-v580.js takes 52.7s standalone but exceeded the
// old 180s budget when 8 suites ran at once (each suite also spawns lua54/luau, so
// 8 node + 8 runtime processes oversubscribe the CPU). Concurrency is capped at half
// the cores and the budget is set from the observed contended wall-clock, not a guess.
// 19-suite run (2026-10-30): slowest standalone suites are test-v580.js 96s,
// test-v590-junk.js 81.5s, test-v590-forge.js 72s; the contended tail reached the whole
// 300s budget and the killed children kept their runtime grandchildren alive, which
// starved the rest of the queue. Budget = 2x the observed contended worst case.
const PER_SUITE_TIMEOUT_MS = 600_000;
const KILL_GRACE_MS = 15_000;
const CONCURRENCY = Math.min(SUITES.length, Math.max(2, Math.floor(os.cpus().length / 2)));

function runSuite(suite) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const child = spawn(process.execPath, [suite], {
      cwd: ROOT,
      windowsHide: true,
      env: process.env,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const stdout = [];
    const stderr = [];
    let timedOut = false;
    let settled = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGTERM");
      // On Windows the killed suite does not reap the lua54/luau grandchildren it spawned,
      // so `close` can arrive many minutes later and hold the concurrency slot. Settle on a
      // grace period instead; the suite is already recorded as a timeout.
      setTimeout(() => finish({
        suite, ok: false, reason: `timed out after ${PER_SUITE_TIMEOUT_MS}ms (killed, pipes still open)`,
        stdout: Buffer.concat(stdout).toString("utf8"),
        stderr: Buffer.concat(stderr).toString("utf8"),
      }), KILL_GRACE_MS).unref();
    }, PER_SUITE_TIMEOUT_MS);

    child.stdout.on("data", (chunk) => stdout.push(chunk));
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      result.elapsedMs = Date.now() - t0;
      resolve(result);
    };

    child.once("error", (error) => finish({
      suite, ok: false, reason: `spawn failed: ${error.message}`,
      stdout: Buffer.concat(stdout).toString("utf8"),
      stderr: Buffer.concat(stderr).toString("utf8"),
    }));
    child.once("close", (code, signal) => {
      const out = Buffer.concat(stdout).toString("utf8");
      const err = Buffer.concat(stderr).toString("utf8");
      const ok = !timedOut && code === 0 && !signal;
      finish({
        suite, ok,
        reason: timedOut ? `timed out after ${PER_SUITE_TIMEOUT_MS}ms` : `exit=${code} signal=${signal || "none"}`,
        stdout: out, stderr: err,
      });
    });
  });
}

async function main() {
  const tStart = Date.now();
  const results = new Array(SUITES.length);
  let nextIdx = 0;

  async function worker() {
    while (nextIdx < SUITES.length) {
      const idx = nextIdx++;
      results[idx] = await runSuite(SUITES[idx]);
    }
  }

  await Promise.all(Array.from({ length: CONCURRENCY }, () => worker()));

  const failures = [];
  for (const result of results) {
    process.stdout.write(`Running ${result.suite} ...\n`);
    if (result.stdout) process.stdout.write(result.stdout.endsWith("\n") ? result.stdout : `${result.stdout}\n`);
    if (result.stderr) process.stderr.write(result.stderr.endsWith("\n") ? result.stderr : `${result.stderr}\n`);
    if (result.ok) process.stdout.write(`PASS (${result.suite} in ${result.elapsedMs}ms)\n`);
    else {
      process.stderr.write(`FAIL (${result.suite} in ${result.elapsedMs}ms): ${result.reason}\n`);
      failures.push(result.suite);
    }
  }

  const totalElapsedMs = Date.now() - tStart;
  if (failures.length) {
    process.stderr.write(`ByteVeil v5.9.0 release gate: FAIL (${failures.join(", ")}; total=${totalElapsedMs}ms)\n`);
    process.exitCode = 1;
    return;
  }
  process.stdout.write(`ByteVeil v5.9.0 release gate: PASS (all ${SUITES.length} suites; concurrency=${CONCURRENCY}; total=${totalElapsedMs}ms)\n`);
}

main().catch((error) => {
  process.stderr.write(`ByteVeil v5.9.0 release gate crashed: ${error.stack || error}\n`);
  process.exitCode = 1;
});

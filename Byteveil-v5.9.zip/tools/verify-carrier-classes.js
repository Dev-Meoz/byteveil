"use strict";
// Probe: for each stage slice, classify every blob literal as load-bearing
// (=function()return <dec>(string.sub([==[...  vs inert raw assignment) and run
// the 1-byte ablation on each, reporting survivors per host.
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
const { obfuscate } = require(path.join(ROOT, "src", "core", "pipeline.js"));
const nr = require(path.join(ROOT, "tools", "native-runtime.js"));
const BLOB_MARKER = "byteveil&";

const build = obfuscate("local a = 10; local b = 20; print(a + b)", { preset: "l1", seed: 0x581111 });
const out = build.output;
const stripForgeBlock = (text) => {
  const open = text.match(/\[\d{3,5}\]=function\(/);
  if (!open) return text;
  const tail = text.match(/^\s*end,?\s*/);
  return text;
};
const bodyOnly = out.split("\n").slice(1).join("\n");
const matches = [...bodyOnly.matchAll(/(?:\{|,)\[(\d{3,5})\]=function\([A-Za-z_]/g)];
const callIdx = bodyOnly.lastIndexOf("__call=function");
const slices = matches.map((m, idx) => {
  const start = m.index + 1;
  const end = idx + 1 < matches.length ? matches[idx + 1].index : callIdx;
  return { slot: Number(m[1]), text: bodyOnly.slice(start, end), bytes: end - start };
});
console.log(`stages=${slices.length} bodyBytes=${Buffer.byteLength(bodyOnly)}`);
const blobRe = /\[(=*)\[byteveil&(.*?)\1\]/gs;
const loadBearingRe = /=function\(\)return\s+[A-Za-z_][A-Za-z0-9_]*\(string\.sub\(\[=+\[byteveil&/g;
const hosts = [["lua", nr.resolveRuntime("lua")], ["luau", nr.resolveRuntime("luau")]];
slices.forEach((s, i) => {
  const blobs = [...s.text.matchAll(blobRe)];
  const live = (s.text.match(loadBearingRe) || []).length;
  console.log(`stage ${i + 1} slot=${s.slot} bytes=${s.bytes} blobs=${blobs.length} loadBearingCarriers=${live}`);
  blobs.forEach((b, j) => {
    const blobText = b[0];
    const encodedAt = blobText.indexOf(BLOB_MARKER) + BLOB_MARKER.length;
    const flipped = blobText[encodedAt] === "!" ? "#" : "!";
    const mutated = `${blobText.slice(0, encodedAt)}${flipped}${blobText.slice(encodedAt + 1)}`;
    if (!out.includes(blobText)) { console.log(`  blob#${j}: not unique in output, skip`); return; }
    const ablated = out.replace(blobText, mutated);
    const results = hosts.map(([name, rt]) => {
      const run = nr.runProgram(rt, ablated, name, "30");
      return `${name}:${run.ok ? "SURVIVED" : "died"}`;
    });
    const context = s.text.slice(Math.max(0, b.index - 40), b.index + 12).replace(/\s+/g, " ");
    console.log(`  blob#${j} ${results.join(" ")} ctx="${context}"`);
  });
});

"use strict";
// Scratch: differential fidelity for table-constructor array-part holes.
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
const { obfuscate } = require(path.join(ROOT, "src", "core", "pipeline.js"));
const nr = require(path.join(ROOT, "tools", "native-runtime.js"));

const PRE = [
    "local function f0() end",
    "local function f3() return 1, 2, 3 end",
    "local function h5() return nil, 5 end",
    "local function sz(t)",
    "  local n = 0; for _ in pairs(t) do n = n + 1 end",
    "  local first = next(t)",
    "  local parts = { tostring(#t), tostring(n), tostring(first) };",
    "  for i = 1, 5 do parts[#parts + 1] = tostring(t[i]) end",
    "  return table.concat(parts, '|')",
    "end",
].join("\n");

const CASES = [
    ["nil-first", PRE + "\nprint(sz({nil, 1}))"],
    ["nil-first 3", PRE + "\nprint(sz({nil, 1, 2}))"],
    ["two nils then value", PRE + "\nprint(sz({nil, nil, 3}))"],
    ["call-zero then value", PRE + "\nprint(sz({f0(), 1}))"],
    ["call-zero then two", PRE + "\nprint(sz({f0(), 1, 2}))"],
    ["call-zero twice", PRE + "\nprint(sz({f0(), f0()}))"],
    ["value then nil", PRE + "\nprint(sz({1, nil}))"],
    ["all nil", PRE + "\nprint(sz({nil, nil, nil}))"],
    ["value nil call-tail", PRE + "\nprint(sz({1, nil, f3()}))"],
    ["hole call-tail", PRE + "\nprint(sz({h5()}))"],
    ["hole call-tail prefix", PRE + "\nprint(sz({1, h5()}))"],
    ["zero call tail", PRE + "\nprint(sz({1, 2, f0()}))"],
    ["hash then list", PRE + "\nprint(sz({[7] = 9, nil, 1}))"],
    ["named then nil value", PRE + "\nprint(sz({a = 1, nil, f0()}))"],
    ["vararg hole table", "local function g(...) local t = {...} return #t .. '/' .. tostring(t[1]) .. '/' .. tostring(t[2]) .. '/' .. tostring(t[3]) end\nprint(g(nil, nil, 3))"],
    ["vararg zero", "local function g(...) local t = {...} return #t .. '/' .. select('#', ...) end\nprint(g())"],
    ["nested hole", PRE + "\nlocal o = {nil, h5()}\nprint(sz(o))"],
    ["ipairs stop", PRE + "\nlocal out = {}\nfor i, v in ipairs({1, nil, 3}) do out[#out + 1] = i end\nprint(#out)"],
    ["len after nil set", PRE + "\nlocal t = {1, 2}\nt[1] = nil\nprint(#t)"],
    ["spread tail then field", PRE + "\nprint(sz({f3(), 7}))"],
    ["unpack size", "local z = {}\nlocal t = {table.unpack(z, 1, 3)}\nprint(#t, tostring(next(t)))"],
    ["mixed literal dynamic", PRE + "\nlocal a = nil\nprint(sz({1, a, 3}))"],
    ["named then literal list", PRE + "\nprint(sz({x = 1, 2, 3}))"],
    ["hash then literal list", PRE + "\nprint(sz({[7] = 9, 1, 2}))"],
    ["hash then call tail", PRE + "\nprint(sz({[7] = 9, f3()}))"],
    ["named then nil then hole tail", PRE + "\nprint(sz({x = 1, nil, h5()}))"],
    ["hash then hole then value", PRE + "\nprint(sz({x = 1, nil, 2}))"],
];

const MODES = ["stack", "register"];
const PRESETS = ["l1", "l2"];

function normalize(text) {
    return String(text == null ? "" : text).replace(/\r\n/g, "\n").replace(/\s+$/g, "");
}

async function main() {
    const hosts = [["lua", nr.resolveRuntime("lua")], ["luau", nr.resolveRuntime("luau")]];
    const ref = new Map();
    for (const [kind, exe] of hosts) {
        for (const [name, source] of CASES) {
            const ran = await nr.runProgram(exe, source, kind);
            ref.set(`${kind}:${name}`, normalize(ran.stdout));
        }
    }
    const divergent = [];
    for (const [name] of CASES) {
        const a = ref.get(`lua:${name}`);
        const b = ref.get(`luau:${name}`);
        if (a !== b) divergent.push(`${name}: lua54="${a}" luau="${b}"`);
    }
    const mismatches = [];
    let cells = 0;
    for (const preset of PRESETS) {
        for (const mode of MODES) {
            for (const [name, source] of CASES) {
                for (const [kind, exe] of hosts) {
                    const artifact = obfuscate(source, { preset, target: kind, compilerBackend: mode, mode, seed: 0x59c0de, junkForge: false });
                    if (artifact.vmMeta.fallback) throw new Error(`${preset}/${mode}/${kind} ${name} hit fallback VM`);
                    cells++;
                    const want = ref.get(`${kind}:${name}`);
                    const ran = await nr.runProgram(exe, artifact.output, kind);
                    const got = normalize(ran.stdout);
                    if (got !== want) mismatches.push(`${preset}/${mode} ${kind} ${name}: want "${want}" got "${got}"`);
                }
            }
        }
    }
    console.log(`cases=${CASES.length} cells=${cells}`);
    console.log("host divergence (native vs native):\n  " + (divergent.join("\n  ") || "none"));
    console.log("artifact mismatches vs native:\n  " + (mismatches.slice(0, 30).join("\n  ") || "none"));
    console.log(mismatches.length ? "RESULT: FAIL" : "RESULT: PASS");
}

main().catch((e) => { console.error(e.stack || e.message); process.exitCode = 1; });

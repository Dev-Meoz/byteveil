"use strict";
// How often does the NEWTABLE array-part hint cost anything?
// The fill path only runs for constructors that can hole out at run time, so the
// honest bound is structural: walk every Table node of realistic sources (nested
// function bodies included) and ask the same function the compilers ask. A hint of
// 0 keeps the cheap `{}` path, so only the >0 rows pay. The emitted instruction
// stream of the top-level chunk is then cross-checked against the walk, so a
// compiler that silently drops the operand would show up here.
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
const { parse } = require(path.join(ROOT, "src", "frontend", "parser.js"));
const { tableArraySizeHint } = require(path.join(ROOT, "src", "compiler", "table_array_hint.js"));
const { compileAST } = require(path.join(ROOT, "src", "compiler", "bytecode.js"));
const { compile } = require(path.join(ROOT, "src", "compiler", "register", "register_compiler.js"));

const SOURCES = {
  "roblox-ish service script": `local Players = game:GetService("Players")
local player = Players.LocalPlayer
local settings = { enabled = true, rate = 0.5, tags = { "ui", "input" } }
local function notify(...)
  local args = { ... }
  for i = 1, #args do print(args[i]) end
end
local rows = {}
for _, p in ipairs(Players:GetPlayers()) do
  rows[#rows + 1] = { name = p.Name, joined = p.JoinedDate }
end
notify(table.unpack(rows, 1, math.min(#rows, 3)))
print(settings.enabled, #rows)`,
  "fivem-ish esx script": `local ESX = exports["es_extended"]:getSharedObject()
local items = {}
RegisterNetEvent("shop:buy")
AddEventHandler("shop:buy", function(xPlayer, price)
  local account = { cash = price, items = { 1, 2, nil } }
  local ok, err = pcall(function() return account.cash / 0 end)
  items[#items + 1] = { ok = ok, err = err }
end)
local function dispatch(...) return ... end
print(dispatch(1, 2, 3))`,
  "table-heavy json encoder": `local function encode(v)
  local out = {}
  if type(v) == "table" then
    local parts = {}
    for k, val in pairs(v) do parts[#parts + 1] = tostring(k) .. "=" .. encode(val) end
    return "{" .. table.concat(parts, ",") .. "}"
  end
  return tostring(v)
end
print(encode({ a = 1, b = { 1, nil, 3 }, c = { x = 1, y = 2 } }))`,
  "multiret suite shape": `local function g3() return 1, 2, 3 end
local function holes() return 1, nil, 3 end
local function none() end
local t = {g3()}
local u = {holes()}
local w = {1, 2, none()}
local v = { ... }
print(#t, #u, #w)`,
};

// `intoFunctions:false` stops at a FunctionExpr boundary, which is where the top
// chunk's instruction stream stops seeing constructors (a nested body is its own chunk).
function* walkTables(node, intoFunctions = true) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    for (const item of node) yield* walkTables(item, intoFunctions);
    return;
  }
  if (node.type === "Table") yield node;
  if (!intoFunctions && node.type === "FunctionExpr") return;
  for (const value of Object.values(node)) yield* walkTables(value, intoFunctions);
}

function countEmitted(code, id, sizeAt) {
  let hinted = 0;
  let cheap = 0;
  for (const ins of code) if (ins[0] === id) (sizeAt(ins) > 0 ? hinted++ : cheap++);
  return { hinted, cheap };
}

const assert = require("node:assert/strict");
let grand = { constructors: 0, hinted: 0, fillSlots: 0 };
for (const [label, src] of Object.entries(SOURCES)) {
  const ast = parse(src);
  const tables = [...walkTables(ast)];
  const hints = tables.map((t) => tableArraySizeHint(t.fields || []));
  const hinted = hints.filter((n) => n > 0).length;
  const fillSlots = hints.reduce((a, n) => a + n, 0);
  const stack = compileAST(ast, "stack", 0x59c0de, {});
  const register = compile(ast, 0x59c0de, {});
  // The chunk-level cross-check has to compare like with like: only the constructors
  // that live in the top chunk are visible in `code`, so nested bodies are excluded.
  const topTables = [...walkTables(ast, false)];
  const topHints = topTables.map((t) => tableArraySizeHint(t.fields || [])).filter((n) => n > 0).length;
  const topCheap = topTables.length - topHints;
  const topEmitted = countEmitted(stack.code, stack.map.encode.NEWTABLE, (ins) => ins[1] || 0);
  const topEmittedReg = countEmitted(register.code, register.map.encode.NEWTABLE, (ins) => ins[2] || 0);
  assert.equal(topEmitted.hinted, topHints, `${label}: stack chunk must emit the hint for every hole-risk constructor`);
  assert.equal(topEmitted.cheap, topCheap, `${label}: stack chunk must keep the cheap path for literal-only constructors`);
  assert.equal(topEmittedReg.hinted, topHints, `${label}: register chunk must emit the hint for every hole-risk constructor`);
  assert.equal(topEmittedReg.cheap, topCheap, `${label}: register chunk must keep the cheap path for literal-only constructors`);
  grand.constructors += tables.length;
  grand.hinted += hinted;
  grand.fillSlots += fillSlots;
  console.log(`${label}: constructors=${tables.length} hinted=${hinted} fillSlots=${fillSlots} | top chunk (${topTables.length} ctors): stack hinted=${topEmitted.hinted}/cheap=${topEmitted.cheap}, register hinted=${topEmittedReg.hinted}/cheap=${topEmittedReg.cheap}`);
}
console.log(`TOTAL: ${grand.hinted}/${grand.constructors} constructors pay the fill (${((grand.hinted / grand.constructors) * 100).toFixed(1)}%), ${grand.fillSlots} slots materialised across all four sources`);
